# MS-Eval 实测中难题

manifest.json 列出每题的上游来源、实测档和包指纹。harbor/<ID> 是独立 Harbor 题目录。checks/<ID> 保存五次独立的原始评分和离线验收。protocol.json 记录条件续测与定档规则；runtime.json 记录本次校准的实际镜像和 harness 指纹。

## 复核与运行

用 Python 3 执行以下命令，可从压缩包中的原始记录复算 50 次成绩并校验题包。

```sh
python verify_release.py MS-Eval中难题发布包.zip
```

在 Docker 和 Harbor 0.24.0 环境中，解压后可用随包构建说明重建等效环境并运行参考解。已有冻结镜像的实验机可直接运行第二条命令。

```sh
docker build -f Dockerfile.runtime -t capstone-core4b-cpp:20261118 .
harbor run -p harbor/MS02 -a oracle
```

给受测 agent 的输入限于 instruction.md 和 environment 工作区。题解、隐藏用例、作者卡和历史成绩保存在评测端。
