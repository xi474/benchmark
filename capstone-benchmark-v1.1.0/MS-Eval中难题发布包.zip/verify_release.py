"""Verify the portable archive itself; Python standard library only."""
from decimal import Decimal, ROUND_HALF_UP
from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile


def verify(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert z.testzip() is None and len(names) == len(set(names))
        data = lambda filename: json.loads(z.read(filename))
        manifest = data('manifest.json')
        ids = {r['id'] for r in manifest}
        assert len(ids) == len(manifest) == 10
        assert len({r['source'] for r in manifest}) == 10
        assert ids == {n.split('/')[1] for n in names if n.startswith('harbor/')}
        totals = {'中': 0, '难': 0}
        request_hashes = set()
        for row in manifest:
            ident = row['id']
            prefix = f'harbor/{ident}/'
            h = sha256()
            for name in sorted(n for n in names if n.startswith(prefix)):
                h.update(name[len(prefix):].encode() + bytes([0]) + sha256(z.read(name)).digest())
            offline = data(f'checks/{ident}/offline.json')
            assert h.hexdigest() == row['package_sha256'] == offline['package_sha256']
            assert offline['passed'] and offline['checks']['starter']['reward'] == 0
            assert offline['checks']['reference']['strict_pass'] and offline['checks']['reference']['reward'] == 3
            trials = data(f'checks/{ident}/trials.json')
            assert sorted(t['repeat'] for t in trials) == list(range(1, 6)) and row['repeats'] == 5
            assert not all(t['strict_pass'] and t['reward'] == 3 for t in trials if t['repeat'] <= 2)
            for t in trials:
                assert t['task'] == ident and t['model'] == 'deepseek-v4-pro' and t['thinking'] == 'disabled'
                assert t['model_mode_proven'] and t['receipts'] > 0 and t['elapsed_seconds'] > 0
                ids_used = t['provider_request_id_hashes']
                assert len(ids_used) == len(set(ids_used)) == t['receipts']
                assert all(len(h) == 64 for h in ids_used) and request_hashes.isdisjoint(ids_used)
                request_hashes.update(ids_used)
                raw = z.read(f"checks/{ident}/round-{t['repeat']}.json")
                assert sha256(raw).hexdigest() == t['score_sha256']
                score = json.loads(raw)
                checks = score['checks']
                good = bool(score['integrity_pass'])
                passed = sum(c['passed'] for c in checks) if good else 0
                strict = good and passed == len(checks)
                expected = (Decimal('1.5') * (Decimal(passed)/len(checks) + int(strict))).quantize(
                    Decimal('.00000001'), rounding=ROUND_HALF_UP)
                assert t['strict_pass'] == score['strict_pass'] == strict
                assert t['public_pass'] == score['public_pass']
                assert t['max_reward'] == score['max_reward'] == 3
                assert Decimal(str(t['reward'])) == Decimal(str(score['reward'])) == expected
                core = [c['passed'] for c in checks if c['category'] == 'A']
                assert t['core_passed'] == (sum(core) if good else 0) and t['core_total'] == len(core)
            strict_count = sum(t['strict_pass'] for t in trials)
            assert row['strict'] == strict_count < 4
            assert row['grade'] == ('难' if strict_count < 2 else '中')
            totals[row['grade']] += 1
        return dict(tasks=len(ids), valid_trials=len(ids)*5, distinct_provider_requests=len(request_hashes),
                    grades=totals, sha256=sha256(path.read_bytes()).hexdigest())


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1])), ensure_ascii=False, indent=2))
