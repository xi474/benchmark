# C/MS 30 题 · 自研 harness 接入包

每题的运行根目录是 tasks/<ID>/environment/workspace。启动时读取同目录的 work_units.json，它列出两个组件分别编辑哪个文件、从哪里读、写到哪里、怎样局部验证，以及最终汇总读哪些文件。两个组件可以由不同 worker 同时完成，汇总读取它们各自的 result.json。所有实验在独立的工作区副本中执行。

Python 命令使用 -B。已有镜像为 capstone-upstream59:2.0，需要时可用 runtime/Dockerfile 构建。镜像中的 Linux PTY、NumPy 与 cryptography 等运行依赖沿用原题。本包预建的是共享业务工作区内的模块与交付槽位；C031 的真实 PTY 仍需要操作系统提供可写临时目录。

具体业务目标及文件契约见每题 instruction.md。index.json 可供批量导入。正式评分使用同版完整包的 tasks/<ID>/tests/，每次运行仅向 agent 暴露本接入包的题面与对应工作区。
