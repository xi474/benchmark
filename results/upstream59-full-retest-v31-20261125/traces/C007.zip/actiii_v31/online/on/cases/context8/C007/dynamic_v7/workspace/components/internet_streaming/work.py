import re

_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _digits(text):
    return re.sub(r"[^0-9]", "", text or "")


def _text(text):
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def _iso_date(value):
    if not value:
        return ""
    value = value.strip()
    # YYYY-MM-DD
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", value)
    if m:
        return "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    # MM/DD/YYYY
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", value)
    if m:
        return "%04d-%02d-%02d" % (int(m.group(3)), int(m.group(1)), int(m.group(2)))
    # DD Mon YYYY
    m = re.match(r"^(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})$", value)
    if m:
        mon = _MONTHS.get(m.group(2).lower())
        if mon is not None:
            return "%04d-%02d-%02d" % (int(m.group(3)), mon, int(m.group(1)))
    return ""


def _normalize(record):
    source = record.get("source")
    fields = record.get("fields") or {}
    if source == "internet":
        full_name = (fields.get("full_name") or "").strip()
        parts = full_name.split()
        first = parts[0] if parts else ""
        last = parts[-1] if len(parts) > 1 else ""
        dob = _iso_date(fields.get("birth_date") or "")
        ssn = ""
        mail = _text(fields.get("mail") or "")
        phone = _digits(fields.get("tel") or "")
        address = _text(fields.get("street") or "")
    elif source == "streaming":
        customer = (fields.get("customer") or "").strip()
        parts = customer.split()
        first = parts[0] if parts else ""
        last = parts[-1] if len(parts) > 1 else ""
        dob = _iso_date(fields.get("date_of_birth") or "")
        ssn = ""
        mail = _text(fields.get("email") or "")
        phone = _digits(fields.get("telephone") or "")
        address = _text(fields.get("address") or "")
    else:
        return None
    return {
        "id": record.get("id", ""),
        "first": _text(first),
        "last": _text(last),
        "dob": dob,
        "ssn": ssn,
        "mail": mail,
        "phone": phone,
        "address": address,
    }


def compute(payload):
    """标准化 ('internet', 'streaming') 渠道记录，返回 [原位置,字段对象] 数组。对象字段 id,first,last,dob,ssn,mail,phone,address，日期 ISO，文字小写去非字母数字，电话及证件仅留数字。"""
    records = payload.get("records", [])
    out = []
    for i, record in enumerate(records):
        if record.get("source") in ("internet", "streaming"):
            obj = _normalize(record)
            if obj is not None:
                out.append([i, obj])
    return out
