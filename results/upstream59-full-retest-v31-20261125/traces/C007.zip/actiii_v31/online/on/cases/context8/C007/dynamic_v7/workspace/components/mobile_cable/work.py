import re

_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _digits(value):
    if value is None:
        return ""
    return re.sub(r"[^0-9]", "", str(value))


def _text(value):
    if value is None:
        return ""
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def _iso_date(value):
    if value is None:
        return ""
    value = str(value).strip()
    if not value:
        return ""
    # YYYY-MM-DD
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", value)
    if m:
        return "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    # YYYYMMDD
    m = re.match(r"^(\d{4})(\d{2})(\d{2})$", value)
    if m:
        return "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    # DD Mon YYYY
    m = re.match(r"^(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})$", value)
    if m:
        mon = _MONTHS.get(m.group(2).lower())
        if mon is not None:
            return "%04d-%02d-%02d" % (int(m.group(3)), mon, int(m.group(1)))
    return ""


def _normalize_mobile(record):
    fields = record.get("fields", {})
    return {
        "id": record.get("id", ""),
        "first": _text(fields.get("first")),
        "last": _text(fields.get("last")),
        "dob": _iso_date(fields.get("dob")),
        "ssn": _digits(fields.get("ssn")),
        "mail": _text(fields.get("email")),
        "phone": _digits(fields.get("phone")),
        "address": _text(fields.get("address")),
    }


def _normalize_cable(record):
    fields = record.get("fields", {})
    last_first = fields.get("last_first", "")
    last = ""
    first = ""
    if last_first:
        parts = str(last_first).split(",", 1)
        last = parts[0]
        first = parts[1] if len(parts) > 1 else ""
    return {
        "id": record.get("id", ""),
        "first": _text(first),
        "last": _text(last),
        "dob": _iso_date(fields.get("birth")),
        "ssn": _digits(fields.get("government_id")),
        "mail": _text(fields.get("contact")),
        "phone": _digits(fields.get("phone")),
        "address": _text(fields.get("location")),
    }


def compute(payload):
    """标准化 ('mobile', 'cable') 渠道记录，返回 [原位置,字段对象] 数组。"""
    records = payload.get("records", [])
    out = []
    for pos, record in enumerate(records):
        source = record.get("source")
        fields = record.get("fields", {})
        if source == "mobile":
            out.append([pos, _normalize_mobile(record)])
        elif source == "cable":
            out.append([pos, _normalize_cable(record)])
    return out
