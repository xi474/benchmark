def _norm_records(left, right):
    records = {}
    for entry in (left or []) + (right or []):
        pos, obj = entry
        records[obj["id"]] = obj
    return records


def _edit1(a, b):
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) < len(b):
        a, b = b, a
    if len(a) == len(b):
        return sum(1 for x, y in zip(a, b) if x != y) <= 1
    i = j = 0
    skipped = False
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1
            j += 1
        else:
            if skipped:
                return False
            skipped = True
            i += 1
    return True


def _name_compatible(r1, r2, ambiguous):
    f1, f2 = r1["first"], r2["first"]
    l1, l2 = r1["last"], r2["last"]
    if l1 and l2 and l1 != l2:
        return False
    if not f1 or not f2:
        return True
    if f1 == f2:
        return True
    amb = set(ambiguous)
    if f1 in amb or f2 in amb:
        short, long_ = (f1, f2) if len(f1) < len(f2) else (f2, f1)
        if long_.startswith(short):
            return True
    return False


def _name_strong_match(r1, r2, ambiguous):
    """True only when first names are identical and non-ambiguous (or both empty)."""
    f1, f2 = r1["first"], r2["first"]
    amb = set(ambiguous)
    if not f1 or not f2:
        return False
    if f1 != f2:
        return False
    return f1 not in amb


def _dob_compatible(r1, r2):
    d1, d2 = r1["dob"], r2["dob"]
    if not d1 or not d2:
        return True
    return d1 == d2


def _ssn_compatible(r1, r2):
    s1, s2 = r1["ssn"], r2["ssn"]
    if not s1 or not s2:
        return True
    if len(s1) == 9 and len(s2) == 9:
        return s1 == s2
    if len(s1) == 9 and len(s2) == 4:
        return s1[-4:] == s2
    if len(s2) == 9 and len(s1) == 4:
        return s2[-4:] == s1
    if len(s1) == 4 and len(s2) == 4:
        return s1 == s2
    return True


def _match_score(r1, r2, ambiguous):
    s1, s2 = r1["ssn"], r2["ssn"]
    if len(s1) == 9 and len(s2) == 9 and s1 != s2:
        return None
    if not _name_compatible(r1, r2, ambiguous):
        return None
    if not _dob_compatible(r1, r2):
        return None
    if not _ssn_compatible(r1, r2):
        return None

    score = 0
    m1, m2 = r1["mail"], r2["mail"]
    if m1 and m2:
        if m1 == m2:
            score += 4
        elif _edit1(m1, m2):
            score += 3
    p1, p2 = r1["phone"], r2["phone"]
    if p1 and p2 and p1 == p2:
        score += 3
    a1, a2 = r1["address"], r2["address"]
    if a1 and a2 and a1 == a2:
        score += 2
    if r1["dob"] and r2["dob"] and r1["dob"] == r2["dob"]:
        score += 2
    if s1 and s2 and s1 == s2:
        score += 5
    elif s1 and s2 and s1[-4:] == s2[-4:]:
        score += 3
    if _name_strong_match(r1, r2, ambiguous):
        score += 2
    return score


def _same_person(r1, r2, ambiguous):
    """Decide whether two records are the same person.

    Strong evidence: identical 9-digit SSN, or identical non-ambiguous full
    first name combined with matching DOB. Otherwise require a shared strong
    contact (exact or edit-1 email, or phone) plus compatible name/dob.
    """
    s1, s2 = r1["ssn"], r2["ssn"]
    if len(s1) == 9 and len(s2) == 9:
        return s1 == s2
    if not _name_compatible(r1, r2, ambiguous):
        return False
    if not _dob_compatible(r1, r2):
        return False
    if not _ssn_compatible(r1, r2):
        return False

    # identical non-ambiguous first name + same dob is strong
    if _name_strong_match(r1, r2, ambiguous) and r1["dob"] and r2["dob"] and r1["dob"] == r2["dob"]:
        return True

    # shared contact evidence
    m1, m2 = r1["mail"], r2["mail"]
    mail_ok = bool(m1 and m2 and (m1 == m2 or _edit1(m1, m2)))
    p1, p2 = r1["phone"], r2["phone"]
    phone_ok = bool(p1 and p2 and p1 == p2)
    if not (mail_ok or phone_ok):
        return False

    # with shared contact, require name compatible (already checked) and
    # dob compatible (already checked); also require at least one of:
    # same dob, same last name, or matching ssn suffix
    if r1["dob"] and r2["dob"] and r1["dob"] == r2["dob"]:
        return True
    if r1["last"] and r2["last"] and r1["last"] == r2["last"]:
        return True
    if s1 and s2 and s1[-4:] == s2[-4:]:
        return True
    return False


def _same_person_strong(r1, r2, ambiguous):
    """Strict same-person test used for the final clustering pass.

    Only merge when there is a strong identifier match (9-digit SSN) or a
    non-ambiguous identical first name with matching DOB, or a shared
    contact plus matching DOB (not merely shared last name).
    """
    s1, s2 = r1["ssn"], r2["ssn"]
    if len(s1) == 9 and len(s2) == 9:
        return s1 == s2
    if not _name_compatible(r1, r2, ambiguous):
        return False
    if not _dob_compatible(r1, r2):
        return False
    if not _ssn_compatible(r1, r2):
        return False

    # identical non-ambiguous first name + same dob
    if _name_strong_match(r1, r2, ambiguous) and r1["dob"] and r2["dob"] and r1["dob"] == r2["dob"]:
        return True

    # shared contact + same dob
    m1, m2 = r1["mail"], r2["mail"]
    mail_ok = bool(m1 and m2 and (m1 == m2 or _edit1(m1, m2)))
    p1, p2 = r1["phone"], r2["phone"]
    phone_ok = bool(p1 and p2 and p1 == p2)
    if (mail_ok or phone_ok) and r1["dob"] and r2["dob"] and r1["dob"] == r2["dob"]:
        return True

    return False


def _candidate_pairs(records, ambiguous):
    blocks = {}
    for rid, r in records.items():
        keys = set()
        if r["mail"]:
            keys.add(("mail", r["mail"]))
        if r["phone"]:
            keys.add(("phone", r["phone"]))
        if r["address"]:
            keys.add(("addr", r["address"]))
        if r["ssn"]:
            keys.add(("ssn", r["ssn"][-4:]))
        if r["last"]:
            keys.add(("last", r["last"]))
        for k in keys:
            blocks.setdefault(k, []).append(rid)

    pairs = set()
    for k, members in blocks.items():
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                a, b = members[i], members[j]
                if a > b:
                    a, b = b, a
                pairs.add((a, b))
    return pairs


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ambiguous = payload.get("ambiguous_names", []) or []
    records = _norm_records(left, right)

    pairs = _candidate_pairs(records, ambiguous)

    parent = {rid: rid for rid in records}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for a, b in pairs:
        if _same_person_strong(records[a], records[b], ambiguous):
            union(a, b)

    groups = {}
    for rid in records:
        groups.setdefault(find(rid), []).append(rid)

    clusters = [sorted(g) for g in groups.values()]
    return {"clusters": clusters}
