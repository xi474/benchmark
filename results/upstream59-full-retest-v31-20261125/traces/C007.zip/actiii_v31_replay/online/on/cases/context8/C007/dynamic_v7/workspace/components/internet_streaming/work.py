import re
from datetime import datetime


def _digits(s):
    return re.sub(r"[^0-9]", "", s or "")


def _alnum_lower(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _iso_date(s):
    if not s:
        return ""
    s = s.strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d %b %Y", "%Y%m%d"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return ""


def _split_name(full_name):
    parts = (full_name or "").strip().lower().split()
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], ""
    return parts[0], parts[-1]


def compute(payload):
    out = []
    for idx, rec in enumerate(payload["records"]):
        src = rec["source"]
        f = rec["fields"]
        if src == "internet":
            first, last = _split_name(f.get("full_name", ""))
            dob = _iso_date(f.get("birth_date", ""))
            ssn = ""
            mail = _alnum_lower(f.get("mail", ""))
            phone = _digits(f.get("tel", ""))
            address = _alnum_lower(f.get("street", ""))
        elif src == "streaming":
            first, last = _split_name(f.get("customer", ""))
            dob = _iso_date(f.get("date_of_birth", ""))
            ssn = ""
            mail = _alnum_lower(f.get("email", ""))
            phone = _digits(f.get("telephone", ""))
            address = _alnum_lower(f.get("address", ""))
        else:
            continue
        out.append([idx, {
            "id": rec["id"],
            "first": first,
            "last": last,
            "dob": dob,
            "ssn": ssn,
            "mail": mail,
            "phone": phone,
            "address": address,
        }])
    return out
