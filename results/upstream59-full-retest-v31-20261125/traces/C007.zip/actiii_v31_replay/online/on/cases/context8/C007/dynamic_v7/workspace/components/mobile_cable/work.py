import re


def _digits(s):
    return re.sub(r"[^0-9]", "", s or "")


def _alnum_lower(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _iso_date(s):
    # YYYY-MM-DD (mobile) or YYYYMMDD (cable)
    s = (s or "").strip()
    if "-" in s:
        return s
    return f"{s[0:4]}-{s[4:6]}-{s[6:8]}"


def compute(payload):
    out = []
    for pos, rec in enumerate(payload["records"]):
        src = rec["source"]
        f = rec["fields"]
        if src == "mobile":
            first = _alnum_lower(f.get("first"))
            last = _alnum_lower(f.get("last"))
            dob = _iso_date(f.get("dob"))
            ssn = _digits(f.get("ssn"))
            mail = _alnum_lower(f.get("email"))
            phone = _digits(f.get("phone"))
            address = _alnum_lower(f.get("address"))
        elif src == "cable":
            lf = f.get("last_first", "")
            if "," in lf:
                last, first = lf.split(",", 1)
            else:
                last, first = lf, ""
            first = _alnum_lower(first)
            last = _alnum_lower(last)
            dob = _iso_date(f.get("birth"))
            ssn = _digits(f.get("government_id"))
            mail = _alnum_lower(f.get("contact"))
            phone = _digits(f.get("phone"))
            address = _alnum_lower(f.get("location"))
        else:
            continue
        out.append([pos, {
            "id": rec["id"],
            "first": first,
            "last": last,
            "dob": dob,
            "ssn": ssn,
            "mail": mail,
            "phone": phone,
            "address": address,
        }])
    return out
