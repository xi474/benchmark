import re
from collections import defaultdict


def _digits(s):
    return re.sub(r"[^0-9]", "", s or "")


def _alnum(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _edit1(a, b):
    """True if a and b differ by at most one char (sub/ins/del)."""
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) > len(b):
        a, b = b, a
    i = 0
    j = 0
    diffs = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1
            j += 1
        else:
            diffs += 1
            if diffs > 1:
                return False
            if len(a) == len(b):
                i += 1
                j += 1
            else:
                j += 1
    diffs += (len(a) - i) + (len(b) - j)
    return diffs <= 1


def combine(payload, left, right):
    ambiguous = set(_alnum(n) for n in payload.get("ambiguous_names", []))

    records = []
    for entry in left:
        pos, obj = entry
        records.append((obj["id"], obj))
    for entry in right:
        pos, obj = entry
        records.append((obj["id"], obj))

    n = len(records)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    blocks = defaultdict(list)
    for i, (rid, r) in enumerate(records):
        ssn = r.get("ssn", "")
        phone = r.get("phone", "")
        address = r.get("address", "")
        mail = r.get("mail", "")
        if len(ssn) == 9:
            blocks[("ssn9", ssn)].append(i)
        if phone:
            blocks[("phone", phone)].append(i)
        if address:
            blocks[("addr", address)].append(i)
        if mail:
            blocks[("mail", mail)].append(i)

    pairs = set()
    for key, idxs in blocks.items():
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                pairs.add((idxs[a], idxs[b]))

    name_dob = defaultdict(list)
    for i, (rid, r) in enumerate(records):
        last = r.get("last", "")
        dob = r.get("dob", "")
        if last and dob:
            name_dob[(last, dob)].append(i)
    for key, idxs in name_dob.items():
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                pairs.add((idxs[a], idxs[b]))

    def _names_compatible(fi, fj):
        if not fi or not fj:
            return True
        if fi == fj:
            return True
        if fi in ambiguous or fj in ambiguous:
            return True
        return False

    # A nickname map: ambiguous names that are known variants of a full name.
    # "pat" -> patrick/patricia, "robbie" -> robert/roberta.
    # We only use this to decide whether two first names could be the same
    # person; it never forces a merge on its own.
    def _first_variants(f):
        if f == "pat":
            return {"pat", "patrick", "patricia"}
        if f == "robbie":
            return {"robbie", "robert", "roberta"}
        return {f}

    def same_person(i, j):
        ri = records[i][1]
        rj = records[j][1]
        si, sj = ri.get("ssn", ""), rj.get("ssn", "")
        if len(si) == 9 and len(sj) == 9:
            return si == sj
        last_i, last_j = ri.get("last", ""), rj.get("last", "")
        dob_i, dob_j = ri.get("dob", ""), rj.get("dob", "")
        phone_i, phone_j = ri.get("phone", ""), rj.get("phone", "")
        addr_i, addr_j = ri.get("address", ""), rj.get("address", "")
        mail_i, mail_j = ri.get("mail", ""), rj.get("mail", "")

        if last_i and last_i == last_j and dob_i and dob_i == dob_j:
            if phone_i and phone_i == phone_j and addr_i and addr_i == addr_j:
                if _names_compatible(ri.get("first", ""), rj.get("first", "")):
                    return True
            if mail_i and mail_j and (mail_i == mail_j or _edit1(mail_i, mail_j)):
                if _names_compatible(ri.get("first", ""), rj.get("first", "")):
                    return True

        if mail_i and mail_i == mail_j and last_i and last_i == last_j and dob_i and dob_i == dob_j:
            if _names_compatible(ri.get("first", ""), rj.get("first", "")):
                return True

        if last_i and last_i == last_j and dob_i and dob_i == dob_j and phone_i and phone_i == phone_j:
            if _names_compatible(ri.get("first", ""), rj.get("first", "")):
                return True

        return False

    # Second pass: split clusters that contain two distinct non-ambiguous
    # first names with different 9-digit SSNs (they are different people).
    # This is a post-union refinement to avoid over-merging families.
    def _refine():
        # Group records by current root.
        by_root = defaultdict(list)
        for i in range(n):
            by_root[find(i)].append(i)
        for root, idxs in by_root.items():
            # Collect distinct full 9-digit SSNs and distinct non-ambiguous first names.
            ssn_groups = defaultdict(list)
            for i in idxs:
                s = records[i][1].get("ssn", "")
                if len(s) == 9:
                    ssn_groups[s].append(i)
            if len(ssn_groups) > 1:
                # Split: each distinct 9-digit SSN becomes its own cluster.
                # Reassign parents.
                for s, members in ssn_groups.items():
                    new_root = members[0]
                    for m in members[1:]:
                        parent[m] = new_root
                # Remaining records without 9-digit ssn stay with first group.
                first_root = next(iter(ssn_groups.values()))[0]
                for i in idxs:
                    if len(records[i][1].get("ssn", "")) != 9:
                        parent[i] = first_root

    _refine()

    # Second pass: split clusters that contain two distinct non-ambiguous
    # first names with different 9-digit SSNs (they are different people).
    # This is a post-union refinement to avoid over-merging families.
    def _refine():
        # Group records by current root.
        by_root = defaultdict(list)
        for i in range(n):
            by_root[find(i)].append(i)
        for root, idxs in by_root.items():
            # Collect distinct full 9-digit SSNs and distinct non-ambiguous first names.
            ssn_groups = defaultdict(list)
            for i in idxs:
                s = records[i][1].get("ssn", "")
                if len(s) == 9:
                    ssn_groups[s].append(i)
            if len(ssn_groups) > 1:
                # Split: each distinct 9-digit SSN becomes its own cluster.
                # Reassign parents.
                for s, members in ssn_groups.items():
                    new_root = members[0]
                    for m in members[1:]:
                        parent[m] = new_root
                # Remaining records without 9-digit ssn stay with first group.
                first_root = next(iter(ssn_groups.values()))[0]
                for i in idxs:
                    if len(records[i][1].get("ssn", "")) != 9:
                        parent[i] = first_root

    _refine()

    for i, j in pairs:
        if same_person(i, j):
            union(i, j)

    groups = defaultdict(list)
    for i, (rid, r) in enumerate(records):
        groups[find(i)].append(rid)

    clusters = [sorted(g) for g in groups.values()]
    return {"clusters": clusters}
