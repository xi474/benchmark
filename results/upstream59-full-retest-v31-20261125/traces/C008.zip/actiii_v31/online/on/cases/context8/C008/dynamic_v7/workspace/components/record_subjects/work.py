def compute(payload):
    """按记录顺序产生 [表名,行号,时间,[租户,主体]]，为跨表归一化保留租户作用域。"""
    out = []
    for rec in payload["records"]:
        out.append([rec["table"], rec["id"], rec["time"], [rec["tenant"], rec["subject"]]])
    return out
