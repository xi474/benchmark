import json
from hashlib import sha256


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    seed = payload["seed"]
    records = payload["records"]
    windows = left  # [start, end, from, to]
    subjects = right  # [table, id, time, [tenant, subject]]

    nodes = set()
    for a, b, _f, _t in windows:
        nodes.add(tuple(a))
        nodes.add(tuple(b))
    for _table, _id, _time, subj in subjects:
        nodes.add(tuple(subj))

    results = []
    for rec, subj in zip(records, subjects):
        t = rec["time"]
        parent = {n: n for n in nodes}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            rx, ry = find(x), find(y)
            if rx != ry:
                parent[rx] = ry

        for a, b, f, to in windows:
            if f <= t < to:
                union(tuple(a), tuple(b))

        comp = {}
        for n in nodes:
            comp.setdefault(find(n), []).append(n)
        key = tuple(subj)
        canonical = min(comp[find(key)])

        raw = json.dumps(
            [str(seed), canonical[0], canonical[1]],
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8")
        token = "ref_" + sha256(raw).hexdigest()[:12]

        results.append({
            "table": rec["table"],
            "id": rec["id"],
            "time": rec["time"],
            "token": token,
        })

    return {"records": results}
