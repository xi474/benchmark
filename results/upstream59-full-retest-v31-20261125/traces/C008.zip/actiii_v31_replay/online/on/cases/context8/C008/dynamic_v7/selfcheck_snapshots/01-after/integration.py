import json
from hashlib import sha256


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    seed = payload["seed"]
    records = payload["records"]

    # left: relationship windows [start, end, from, to]
    # right: record subjects [table, id, time, [tenant, subject]]
    windows = left
    subjects = right

    parent = {}

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    def ensure(x):
        if x not in parent:
            parent[x] = x

    for rec in subjects:
        ensure((rec[3][0], rec[3][1]))

    def token_for(canon):
        raw = json.dumps(
            [str(seed), canon[0], canon[1]],
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return "ref_" + sha256(raw).hexdigest()[:12]

    out_records = []
    for rec in records:
        time = rec["time"]
        # Build the equivalence relation valid at this record's own time.
        p = {}
        def f(x):
            r = x
            while p[r] != r:
                r = p[r]
            while p[x] != r:
                p[x], x = r, p[x]
            return r
        def u(a, b):
            ra, rb = f(a), f(b)
            if ra != rb:
                p[rb] = ra
        def e(x):
            if x not in p:
                p[x] = x
        key = (rec["tenant"], rec["subject"])
        e(key)
        for w in windows:
            start, end, frm, to = w
            if frm <= time < to:
                a = (start[0], start[1])
                b = (end[0], end[1])
                e(a)
                e(b)
                u(a, b)
        comps = {}
        for k in p:
            r = f(k)
            comps.setdefault(r, []).append(k)
        canon = min(comps[f(key)])
        out_records.append({
            "table": rec["table"],
            "id": rec["id"],
            "time": rec["time"],
            "token": token_for(canon),
        })

    return {"records": out_records}
