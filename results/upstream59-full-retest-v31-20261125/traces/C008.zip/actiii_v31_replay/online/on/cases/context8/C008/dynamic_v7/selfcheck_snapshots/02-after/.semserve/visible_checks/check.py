import json
import unittest

from hashlib import sha256


def _token(seed, tenant, subject):
    raw = json.dumps([str(seed), tenant, subject], ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    return "ref_" + sha256(raw).hexdigest()[:12]


class TestTransform(unittest.TestCase):
    def test_output_shape_and_order(self):
        payload = {
            "seed": 7,
            "records": [
                {"table": "t1", "id": "r1", "tenant": "a", "subject": "x", "time": 0},
                {"table": "t2", "id": "r2", "tenant": "b", "subject": "y", "time": 0},
            ],
            "links": [],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertEqual(list(result.keys()), ["records"])
        self.assertEqual(len(result["records"]), 2)
        for i, rec in enumerate(result["records"]):
            self.assertEqual(list(rec.keys()), ["table", "id", "time", "token"])
            self.assertEqual(rec["table"], payload["records"][i]["table"])
            self.assertEqual(rec["id"], payload["records"][i]["id"])
            self.assertEqual(rec["time"], payload["records"][i]["time"])
            self.assertNotIn("tenant", rec)
            self.assertNotIn("subject", rec)

    def test_token_matches_spec(self):
        payload = {
            "seed": 1,
            "records": [{"table": "t", "id": "r", "tenant": "a", "subject": "t", "time": 0}],
            "links": [],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["records"][0]["token"], _token(1, "a", "t"))

    def test_canonical_lexicographic_and_cross_table(self):
        # link merges (b,u) and (a,t); canonical is (a,t) lexicographically.
        payload = {
            "seed": 1,
            "records": [
                {"table": "orders", "id": "o1", "tenant": "a", "subject": "t", "time": 1},
                {"table": "events", "id": "e1", "tenant": "b", "subject": "u", "time": 1},
            ],
            "links": [{"a": ["b", "u"], "b": ["a", "t"]}],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        tokens = [r["token"] for r in result["records"]]
        self.assertEqual(tokens[0], tokens[1])
        self.assertEqual(tokens[0], _token(1, "a", "t"))

    def test_tenant_scope_not_mixed(self):
        # same subject id "x" in two tenants must not merge.
        payload = {
            "seed": 1,
            "records": [
                {"table": "t1", "id": "r1", "tenant": "a", "subject": "x", "time": 0},
                {"table": "t2", "id": "r2", "tenant": "b", "subject": "x", "time": 0},
            ],
            "links": [],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertNotEqual(result["records"][0]["token"], result["records"][1]["token"])

    def test_interval_half_open(self):
        # merge valid only for from <= time < to; at time == to it is inactive.
        payload = {
            "seed": 1,
            "records": [
                {"table": "t1", "id": "r1", "tenant": "a", "subject": "s", "time": 10},
                {"table": "t2", "id": "r2", "tenant": "a", "subject": "t", "time": 10},
            ],
            "links": [],
            "merges": [{"a": ["a", "s"], "b": ["a", "t"], "from": 5, "to": 10}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertNotEqual(result["records"][0]["token"], result["records"][1]["token"])

    def test_seed_changes_token(self):
        base = {
            "records": [{"table": "t", "id": "r", "tenant": "a", "subject": "x", "time": 0}],
            "links": [],
            "merges": [],
        }
        r1 = call_candidate("solution.py", "transform", args=[dict(base, seed=1)])
        r2 = call_candidate("solution.py", "transform", args=[dict(base, seed=2)])
        self.assertNotEqual(r1["records"][0]["token"], r2["records"][0]["token"])


if __name__ == "__main__":
    unittest.main()
