"""C009 integration: combine component values and complete the scheduling computation."""


def combine(payload, left, right):
    events = left
    crew = right

    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}

    committed = []
    committed_jobs = set()
    cancelled = []
    ignored_cancellations = []
    pending = []

    stock_used = {sid: 0 for sid in suppliers}
    driver_tasks = {did: [] for did in drivers}
    vehicle_intervals = {vid: [] for vid in vehicles}
    jobs = {}

    rounds_out = []

    for rnd in payload["rounds"]:
        cutoff = rnd["cutoff"]
        commit = rnd.get("commit", False)

        visible = [e for e in events if e["visible"] <= cutoff]
        visible.sort(key=lambda e: (e["visible"], e["id"]))

        round_cancelled = []
        round_ignored = []

        for e in visible:
            if e["kind"] == "request":
                job = e["job"]
                if job["id"] not in jobs:
                    jobs[job["id"]] = job
            elif e["kind"] == "cancel":
                jid = e["job"]
                committed_match = None
                for a in committed:
                    if a["job"] == jid:
                        committed_match = a
                        break
                if committed_match is not None and committed_match["start"] < cutoff:
                    round_ignored.append(jid)
                else:
                    pending = [a for a in pending if a["job"] != jid]
                    removed_committed = [a for a in committed if a["job"] == jid and a["start"] >= cutoff]
                    for a in removed_committed:
                        committed.remove(a)
                        committed_jobs.discard(jid)
                        stock_used[a["supplier"]] -= a["quantity"]
                        driver_tasks[a["driver"]] = [
                            t for t in driver_tasks[a["driver"]]
                            if not (t[0] == a["start"] and t[1] == a["end"])
                        ]
                        vehicle_intervals[a["vehicle"]] = [
                            iv for iv in vehicle_intervals[a["vehicle"]]
                            if not (iv[0] == a["start"] and iv[1] == a["end"])
                        ]
                    round_cancelled.append(jid)

        available_jobs = {}
        for jid, job in jobs.items():
            if jid not in committed_jobs and jid not in cancelled:
                available_jobs[jid] = job

        candidates = []
        for jid, job in available_jobs.items():
            for vid, veh in vehicles.items():
                if veh["type"] != job["type"]:
                    continue
                if veh["capacity"] < job["quantity"]:
                    continue
                for did in crew.get(vid, []):
                    drv = drivers[did]
                    if veh["type"] not in drv["types"]:
                        continue
                    for sid in job["suppliers"]:
                        sup = suppliers[sid]
                        lo = max(cutoff, job["release"])
                        hi = job["deadline"] - job["duration"]
                        for start in range(lo, hi + 1):
                            end = start + job["duration"]
                            if start > sup["close"]:
                                continue
                            if stock_used[sid] + job["quantity"] > sup["stock"]:
                                continue
                            if any(not (end <= s or start >= e) for s, e in vehicle_intervals[vid]):
                                continue
                            if any(not (end <= s or start >= e) for s, e in driver_tasks[did]):
                                continue
                            if not _driver_ok(drv, driver_tasks[did], start, end):
                                continue
                            profit = job["revenue"] - job["quantity"] * sup["unit_cost"] - veh["cost"] * job["duration"]
                            candidates.append({
                                "job": jid,
                                "vehicle": vid,
                                "driver": did,
                                "supplier": sid,
                                "start": start,
                                "end": end,
                                "quantity": job["quantity"],
                                "profit": profit,
                            })

        selected = _select(candidates, committed, driver_tasks, vehicle_intervals, stock_used, suppliers, drivers)

        all_assignments = list(committed) + selected
        all_assignments.sort(key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))

        total_profit = sum(a["profit"] for a in all_assignments)

        all_cancelled = sorted(set(cancelled) | set(round_cancelled))
        all_ignored = sorted(set(ignored_cancellations) | set(round_ignored))

        rounds_out.append({
            "cutoff": cutoff,
            "assignments": all_assignments,
            "profit": total_profit,
            "cancelled": all_cancelled,
            "ignored_cancellations": all_ignored,
        })

        if commit:
            for a in selected:
                committed.append(a)
                committed_jobs.add(a["job"])
                stock_used[a["supplier"]] += a["quantity"]
                driver_tasks[a["driver"]].append((a["start"], a["end"]))
                vehicle_intervals[a["vehicle"]].append((a["start"], a["end"]))
            cancelled = all_cancelled
            ignored_cancellations = all_ignored
            pending = []
        else:
            pending = selected
            cancelled = all_cancelled
            ignored_cancellations = all_ignored

    return {"rounds": rounds_out}


def _driver_ok(drv, tasks, start, end):
    max_work = drv["max_work"]
    max_continuous = drv["max_continuous"]
    brk = drv["break"]

    all_tasks = sorted(tasks + [(start, end)])
    total = sum(e - s for s, e in all_tasks)
    if total > max_work:
        return False

    continuous = 0
    prev_end = None
    for s, e in all_tasks:
        if prev_end is not None and s - prev_end >= brk:
            continuous = 0
        continuous += (e - s)
        if continuous > max_continuous:
            return False
        prev_end = e
    return True


def _select(candidates, committed, driver_tasks, vehicle_intervals, stock_used, suppliers, drivers):
    by_job = {}
    for c in candidates:
        by_job.setdefault(c["job"], []).append(c)

    job_ids = list(by_job.keys())
    best = None
    best_key = None

    n = len(job_ids)
    for mask in range(1 << n):
        chosen_jobs = [job_ids[i] for i in range(n) if mask & (1 << i)]
        choices = [by_job[j] for j in chosen_jobs]
        for combo in _product(choices):
            if not _feasible(combo, committed, driver_tasks, vehicle_intervals, stock_used, suppliers, drivers):
                continue
            total_profit = sum(c["profit"] for c in combo)
            count = len(combo)
            sorted_combo = sorted(combo, key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))
            key = (total_profit, count, tuple((a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]) for a in sorted_combo))
            if best_key is None or key > best_key:
                best_key = key
                best = sorted_combo

    return best if best is not None else []


def _product(choices):
    if not choices:
        return [()]
    result = [()]
    for lst in choices:
        new_result = []
        for prefix in result:
            for item in lst:
                new_result.append(prefix + (item,))
        result = new_result
    return result


def _feasible(combo, committed, driver_tasks, vehicle_intervals, stock_used, suppliers, drivers):
    stock = dict(stock_used)
    for c in combo:
        stock[c["supplier"]] = stock.get(c["supplier"], 0) + c["quantity"]
        if stock[c["supplier"]] > suppliers[c["supplier"]]["stock"]:
            return False

    veh_iv = {vid: list(ivs) for vid, ivs in vehicle_intervals.items()}
    for c in combo:
        if any(not (c["end"] <= s or c["start"] >= e) for s, e in veh_iv[c["vehicle"]]):
            return False
        veh_iv[c["vehicle"]].append((c["start"], c["end"]))

    drv_tasks = {did: list(ts) for did, ts in driver_tasks.items()}
    for c in combo:
        if any(not (c["end"] <= s or c["start"] >= e) for s, e in drv_tasks[c["driver"]]):
            return False
        if not _driver_ok(drivers[c["driver"]], drv_tasks[c["driver"]], c["start"], c["end"]):
            return False
        drv_tasks[c["driver"]].append((c["start"], c["end"]))

    return True
