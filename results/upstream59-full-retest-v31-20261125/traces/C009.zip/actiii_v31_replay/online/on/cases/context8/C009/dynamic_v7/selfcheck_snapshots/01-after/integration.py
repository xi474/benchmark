"""C009 integration: consume component business values and compute the schedule."""


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  -> visible_events value: list of events sorted by (visible, id)
    right -> crew_compatibility value: {vehicle_id: [driver_id, ...]}
    """
    vehicles = payload["vehicles"]
    drivers = payload["drivers"]
    suppliers = payload["suppliers"]
    events = left
    rounds = payload["rounds"]

    vehicle_by_id = {v["id"]: v for v in vehicles}
    driver_by_id = {d["id"]: d for d in drivers}
    supplier_by_id = {s["id"]: s for s in suppliers}
    compat = right  # vehicle_id -> list of driver ids

    # Persistent state across rounds.
    committed = []          # list of assignment dicts (committed tasks)
    pending = []            # list of assignment dicts (this round's tentative)
    cancelled = []          # list of job ids cancelled (dedup, ascending)
    ignored_cancellations = []  # list of job ids whose cancel was ignored
    seen_jobs = set()       # job ids that have appeared (request events)
    assigned_jobs = set()   # job ids currently assigned (committed or pending)

    result_rounds = []

    for rnd in rounds:
        cutoff = rnd["cutoff"]
        commit = rnd.get("commit", False)

        # Process events visible <= cutoff, in (visible, id) order.
        for ev in events:
            if ev["visible"] > cutoff:
                break
            if ev["kind"] == "request":
                seen_jobs.add(ev["job"]["id"])
            elif ev["kind"] == "cancel":
                job_id = ev["job"]
                committed_task = None
                for a in committed:
                    if a["job"] == job_id:
                        committed_task = a
                        break
                if committed_task is not None and committed_task["start"] < cutoff:
                    if job_id not in ignored_cancellations:
                        ignored_cancellations.append(job_id)
                else:
                    pending = [a for a in pending if a["job"] != job_id]
                    committed = [a for a in committed if a["job"] != job_id]
                    assigned_jobs.discard(job_id)
                    if job_id not in cancelled:
                        cancelled.append(job_id)

        # Build the set of jobs available for assignment this round.
        available_jobs = []
        for ev in events:
            if ev["visible"] > cutoff:
                break
            if ev["kind"] == "request":
                jid = ev["job"]["id"]
                if jid in assigned_jobs or jid in cancelled:
                    continue
                available_jobs.append(ev["job"])

        new_assignments = _optimize_round(
            available_jobs, committed, pending, cutoff,
            vehicle_by_id, driver_by_id, supplier_by_id, compat,
        )

        pending = pending + new_assignments
        for a in new_assignments:
            assigned_jobs.add(a["job"])

        if commit:
            committed = committed + pending
            pending = []

        all_assignments = committed + pending
        all_assignments.sort(key=lambda a: (
            a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"],
        ))
        total_profit = sum(a["profit"] for a in all_assignments)

        result_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments,
            "profit": total_profit,
            "cancelled": sorted(cancelled),
            "ignored_cancellations": sorted(ignored_cancellations),
        })

    return {"rounds": result_rounds}


def _optimize_round(jobs, committed, pending, cutoff,
                    vehicle_by_id, driver_by_id, supplier_by_id, compat):
    """Choose new assignments maximizing total profit, then count, then lexicographic min."""
    candidates = []
    for job in jobs:
        for vid, v in vehicle_by_id.items():
            if v["type"] != job["type"]:
                continue
            if v["capacity"] < job["quantity"]:
                continue
            for did in compat.get(vid, []):
                d = driver_by_id[did]
                if v["type"] not in d["types"]:
                    continue
                for sid in job["suppliers"]:
                    s = supplier_by_id[sid]
                    start_min = max(cutoff, job["release"])
                    start_max = job["deadline"] - job["duration"]
                    for start in range(start_min, start_max + 1):
                        end = start + job["duration"]
                        if start > s["close"]:
                            continue
                        profit = (job["revenue"]
                                  - job["quantity"] * s["unit_cost"]
                                  - v["cost"] * job["duration"])
                        candidates.append({
                            "job": job["id"],
                            "vehicle": vid,
                            "driver": did,
                            "supplier": sid,
                            "start": start,
                            "end": end,
                            "quantity": job["quantity"],
                            "profit": profit,
                        })

    best = None  # (total_profit, count, sorted_tuple_list, chosen)

    job_options = {}
    for c in candidates:
        job_options.setdefault(c["job"], []).append(c)

    job_ids = list(job_options.keys())

    def feasible(assignments):
        all_a = list(committed) + list(pending) + list(assignments)
        for vid in vehicle_by_id:
            times = sorted([a for a in all_a if a["vehicle"] == vid],
                           key=lambda a: a["start"])
            for i in range(len(times) - 1):
                if times[i]["end"] > times[i + 1]["start"]:
                    return False
        for did in driver_by_id:
            times = sorted([a for a in all_a if a["driver"] == did],
                           key=lambda a: a["start"])
            for i in range(len(times) - 1):
                if times[i]["end"] > times[i + 1]["start"]:
                    return False
        for sid in supplier_by_id:
            total = sum(a["quantity"] for a in all_a if a["supplier"] == sid)
            if total > supplier_by_id[sid]["stock"]:
                return False
        for did in driver_by_id:
            d = driver_by_id[did]
            times = sorted([a for a in all_a if a["driver"] == did],
                           key=lambda a: a["start"])
            total_work = sum(a["end"] - a["start"] for a in times)
            if total_work > d["max_work"]:
                return False
            continuous = 0
            prev_end = None
            for a in times:
                if prev_end is not None and a["start"] - prev_end >= d["break"]:
                    continuous = 0
                continuous += a["end"] - a["start"]
                if continuous > d["max_continuous"]:
                    return False
                prev_end = a["end"]
        return True

    def search(idx, chosen):
        nonlocal best
        if idx == len(job_ids):
            if not feasible(chosen):
                return
            total_profit = sum(c["profit"] for c in chosen)
            count = len(chosen)
            key = sorted(chosen, key=lambda c: (
                c["job"], c["start"], c["vehicle"], c["driver"], c["supplier"],
            ))
            key_tuple = tuple(
                (c["job"], c["start"], c["vehicle"], c["driver"], c["supplier"])
                for c in key
            )
            if best is None:
                best = (total_profit, count, key_tuple, chosen)
            else:
                bp, bc, bk, _ = best
                if (total_profit > bp
                        or (total_profit == bp and count > bc)
                        or (total_profit == bp and count == bc and key_tuple < bk)):
                    best = (total_profit, count, key_tuple, chosen)
            return

        jid = job_ids[idx]
        search(idx + 1, chosen)
        for c in job_options[jid]:
            search(idx + 1, chosen + [c])

    search(0, [])

    if best is None:
        return []
    return best[3]
