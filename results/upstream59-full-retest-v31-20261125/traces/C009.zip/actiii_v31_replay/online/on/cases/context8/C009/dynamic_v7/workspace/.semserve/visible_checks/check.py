import unittest

# Injected by the SDK runner; do not import.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type for expected candidate failures

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "只使用题内正常输入域，不考察NaN、任意畸形JSON或错误文本。",
                "reason": "The public spec explicitly excludes NaN and malformed JSON from the tested domain.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "只使用题内正常输入域，不考察NaN、任意畸形JSON或错误文本。",
                "reason": "The public spec excludes malformed input types from the tested domain.",
            },
        },
    },
]


class TestVisibleContract(unittest.TestCase):
    def test_transform_returns_rounds_container(self):
        # Output contract: transform returns a dict with a "rounds" list.
        payload = {
            "vehicles": [{"id": "v1", "type": "bulk", "capacity": 3, "cost": 1}],
            "drivers": [{"id": "d1", "types": ["bulk"], "max_work": 4,
                         "max_continuous": 2, "break": 1}],
            "suppliers": [{"id": "s1", "stock": 4, "close": 5, "unit_cost": 2}],
            "events": [],
            "rounds": [{"cutoff": 1, "commit": True}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertIn("rounds", result)
        self.assertIsInstance(result["rounds"], list)
        self.assertEqual(len(result["rounds"]), 1)
        r = result["rounds"][0]
        self.assertEqual(r["cutoff"], 1)
        self.assertEqual(r["assignments"], [])
        self.assertEqual(r["profit"], 0)
        self.assertEqual(r["cancelled"], [])
        self.assertEqual(r["ignored_cancellations"], [])

    def test_cancel_committed_before_cutoff_is_ignored(self):
        # A committed task with start < cutoff cannot be cancelled.
        payload = {
            "vehicles": [{"id": "v1", "type": "bulk", "capacity": 3, "cost": 1}],
            "drivers": [{"id": "d1", "types": ["bulk"], "max_work": 10,
                         "max_continuous": 10, "break": 1}],
            "suppliers": [{"id": "s1", "stock": 10, "close": 10, "unit_cost": 1}],
            "events": [
                {"id": "e1", "visible": 1, "kind": "request",
                 "job": {"id": "j1", "type": "bulk", "quantity": 1,
                         "release": 1, "deadline": 3, "duration": 1,
                         "revenue": 10, "suppliers": ["s1"]}},
                {"id": "e2", "visible": 2, "kind": "cancel", "job": "j1"},
            ],
            "rounds": [
                {"cutoff": 1, "commit": True},
                {"cutoff": 2, "commit": True},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        r1 = result["rounds"][0]
        r2 = result["rounds"][1]
        self.assertEqual(len(r1["assignments"]), 1)
        self.assertEqual(r1["assignments"][0]["job"], "j1")
        # The committed task started at 1 < cutoff 2, so cancel is ignored.
        self.assertEqual(r2["ignored_cancellations"], ["j1"])
        self.assertEqual(r2["cancelled"], [])
        self.assertEqual(len(r2["assignments"]), 1)

    def test_cancel_uncommitted_job_removes_it(self):
        # A job that was never committed can be cancelled and removed.
        payload = {
            "vehicles": [{"id": "v1", "type": "bulk", "capacity": 3, "cost": 1}],
            "drivers": [{"id": "d1", "types": ["bulk"], "max_work": 10,
                         "max_continuous": 10, "break": 1}],
            "suppliers": [{"id": "s1", "stock": 10, "close": 10, "unit_cost": 1}],
            "events": [
                {"id": "e1", "visible": 1, "kind": "request",
                 "job": {"id": "j1", "type": "bulk", "quantity": 1,
                         "release": 1, "deadline": 3, "duration": 1,
                         "revenue": 10, "suppliers": ["s1"]}},
                {"id": "e2", "visible": 2, "kind": "cancel", "job": "j1"},
            ],
            "rounds": [
                {"cutoff": 1, "commit": False},
                {"cutoff": 2, "commit": True},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        r2 = result["rounds"][1]
        self.assertEqual(r2["cancelled"], ["j1"])
        self.assertEqual(r2["ignored_cancellations"], [])
        self.assertEqual(r2["assignments"], [])

    def test_driver_continuous_work_limit(self):
        # Two back-to-back tasks exceed max_continuous, so only one is assigned.
        payload = {
            "vehicles": [{"id": "v1", "type": "bulk", "capacity": 3, "cost": 1}],
            "drivers": [{"id": "d1", "types": ["bulk"], "max_work": 10,
                         "max_continuous": 1, "break": 1}],
            "suppliers": [{"id": "s1", "stock": 10, "close": 10, "unit_cost": 1}],
            "events": [
                {"id": "e1", "visible": 1, "kind": "request",
                 "job": {"id": "j1", "type": "bulk", "quantity": 1,
                         "release": 1, "deadline": 3, "duration": 1,
                         "revenue": 10, "suppliers": ["s1"]}},
                {"id": "e2", "visible": 1, "kind": "request",
                 "job": {"id": "j2", "type": "bulk", "quantity": 1,
                         "release": 2, "deadline": 4, "duration": 1,
                         "revenue": 10, "suppliers": ["s1"]}},
            ],
            "rounds": [{"cutoff": 1, "commit": True}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        r = result["rounds"][0]
        # max_continuous=1 means a single duration-1 task is the max.
        self.assertLessEqual(len(r["assignments"]), 1)
        # If two tasks were assigned, they must not be back-to-back on the
        # same driver (gap >= break resets continuous work).
        if len(r["assignments"]) == 2:
            starts = sorted(a["start"] for a in r["assignments"])
            self.assertGreaterEqual(starts[1] - starts[0], 2)


if __name__ == "__main__":
    unittest.main()
