def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload["orders"]
    released = payload.get("released", [])
    routing = payload.get("routing", {})
    lines = payload.get("lines", [])
    wip = payload.get("wip", [])
    freeze = payload.get("freeze", 0)
    changeover = payload.get("changeover", 0)

    # 每条产线上所有 wip 的结束时间，用于确定其他任务的最早起点。
    wip_end_by_line = {}
    for w in wip:
        line = w["line"]
        end = w["end"]
        if line not in wip_end_by_line or end > wip_end_by_line[line]:
            wip_end_by_line[line] = end

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]
        r = routing.get(sku, {})
        duration = r.get("setup", 0) + r.get("per_unit", 0) * qty

        triples = []
        if sku in released:
            for line in lines:
                lid = line["id"]
                if sku not in line.get("qualified", []):
                    continue
                # 其他任务 start >= 本线所有 wip 结束 + changeover。
                min_start = freeze
                if lid in wip_end_by_line:
                    wip_min = wip_end_by_line[lid] + changeover
                    if wip_min > min_start:
                        min_start = wip_min
                for ws, we in line.get("windows", []):
                    start = max(ws, min_start)
                    while start + duration <= we:
                        end = start + duration
                        if end <= due:
                            triples.append([lid, start, end])
                        start += 1
        result[oid] = triples
    return result
