def compute(payload):
    """按工单 ID 输出递归展开后的基础物料需求映射。"""
    orders = payload["orders"]
    bom = payload["bom"]

    def expand(sku, mult):
        result = {}
        if sku not in bom:
            result[sku] = mult
            return result
        for child, per in bom[sku].items():
            sub = expand(child, mult * per)
            for comp, qty in sub.items():
                result[comp] = result.get(comp, 0) + qty
        return result

    out = {}
    for order in orders:
        out[order["id"]] = expand(order["sku"], order["qty"])
    return out
