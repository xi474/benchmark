"""C011 integration: combine material demand and line windows into a full plan."""


def combine(payload, left, right):
    """left = material demand per order; right = feasible (line,start,end) per order."""
    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload.get("changeover", 0)
    orders = payload["orders"]
    released = payload.get("released", [])
    routing = payload.get("routing", {})
    lines = payload.get("lines", [])
    wip = payload.get("wip", [])
    substitutes = payload.get("substitutes", {})
    lots = payload.get("lots", [])

    order_by_id = {o["id"]: o for o in orders}
    wip_by_line = {}
    for w in wip:
        wip_by_line.setdefault(w["line"], []).append(w)

    windows = right  # {order_id: [[line, start, end], ...]}
    demand = left  # {order_id: {component: qty}}

    order_seq = sorted(orders, key=lambda o: (o["priority"], o["due"], o["id"]))
    win_by_id = {oid: windows.get(oid, []) for oid in order_by_id}

    def feasible_material(selected_assignments):
        # Per-task expiry: a lot can serve a task only if lot.expiry >= task.end.
        # Build per-component demand with the max end among tasks needing it.
        comp_max_end = {}
        total_demand = {}
        for oid, line, start, end in selected_assignments:
            for comp, qty in demand.get(oid, {}).items():
                total_demand[comp] = total_demand.get(comp, 0) + qty
                if end > comp_max_end.get(comp, -1):
                    comp_max_end[comp] = end
        components = sorted(total_demand.keys())
        remaining = {l["id"]: l["qty"] for l in lots}

        def rec(ci):
            if ci == len(components):
                return True
            c = components[ci]
            need = total_demand[c]
            subs = substitutes.get(c, [c])
            max_end = comp_max_end[c]
            cand = sorted([l for l in lots if l["material"] in subs and l["status"] == "PASS" and l["expiry"] >= max_end], key=lambda l: l["id"])
            return rec_comp(c, need, cand, remaining, ci)

        def rec_comp(c, need, cand, remaining, ci):
            if need == 0:
                return rec(ci + 1)
            for lot in cand:
                avail = remaining.get(lot["id"], 0)
                if avail <= 0:
                    continue
                take = min(avail, need)
                remaining[lot["id"]] = avail - take
                if rec_comp(c, need - take, cand, remaining, ci):
                    return True
                remaining[lot["id"]] = avail
            return False

        return rec(0)

    def line_feasible(selected_assignments):
        by_line = {}
        for oid, line, start, end in selected_assignments:
            by_line.setdefault(line, []).append((start, end, oid))
        for line, tasks in by_line.items():
            wip_tasks = sorted(wip_by_line.get(line, []), key=lambda w: w["start"])
            prev_end = None
            for w in wip_tasks:
                if prev_end is not None and w["start"] < prev_end + changeover:
                    return False
                prev_end = w["end"]
            min_start = 0
            if wip_tasks:
                min_start = max(w["end"] for w in wip_tasks) + changeover
            for start, end, oid in tasks:
                if start < min_start:
                    return False
            tasks_sorted = sorted(tasks, key=lambda t: (t[0], t[1], t[2]))
            prev_end = None
            for start, end, oid in tasks_sorted:
                if prev_end is not None and start < prev_end + changeover:
                    return False
                prev_end = end
        return True

    def compute_global_alloc(selected_assignments):
        total_demand = {}
        for oid, line, start, end in selected_assignments:
            for comp, qty in demand.get(oid, {}).items():
                total_demand[comp] = total_demand.get(comp, 0) + qty
        components = sorted(total_demand.keys())
        remaining = {l["id"]: l["qty"] for l in lots}
        alloc = {}
        order_ids = sorted(oid for oid, _, _, _ in selected_assignments)
        for c in components:
            subs = substitutes.get(c, [c])
            cand = sorted([l for l in lots if l["material"] in subs and l["status"] == "PASS"], key=lambda l: l["id"])
            need_by_order = {}
            for oid in order_ids:
                q = demand.get(oid, {}).get(c, 0)
                if q > 0:
                    need_by_order[oid] = q
            for lot in cand:
                avail = remaining.get(lot["id"], 0)
                if avail <= 0:
                    continue
                for oid in order_ids:
                    if need_by_order.get(oid, 0) <= 0:
                        continue
                    take = min(avail, need_by_order[oid])
                    if take > 0:
                        alloc.setdefault(oid, []).append((c, lot["id"], take))
                        need_by_order[oid] -= take
                        avail -= take
                        remaining[lot["id"]] = avail
                    if avail <= 0:
                        break
        for oid in alloc:
            alloc[oid].sort()
        return alloc

    best = None

    def better(a, b):
        if a[0] != b[0]:
            return a[0] > b[0]
        if a[1] != b[1]:
            return a[1] > b[1]
        if a[2] != b[2]:
            return a[2] > b[2]
        if a[3] != b[3]:
            return a[3] > b[3]
        return a[4] < b[4]

    def backtrack(idx, selected_assignments):
        nonlocal best
        if idx == len(order_seq):
            if not line_feasible(selected_assignments):
                return
            if not feasible_material(selected_assignments):
                return
            selected_ids = set(oid for oid, _, _, _ in selected_assignments)
            p1 = sum(1 for o in orders if o["id"] in selected_ids and o["priority"] == 1)
            p2 = sum(1 for o in orders if o["id"] in selected_ids and o["priority"] == 2)
            p3 = sum(1 for o in orders if o["id"] in selected_ids and o["priority"] == 3)
            comp_vec = tuple(1 if o["id"] in selected_ids else 0 for o in order_seq)
            assign_list = []
            for oid, line, start, end in selected_assignments:
                alloc = compute_global_alloc(selected_assignments).get(oid, [])
                assign_list.append((oid, line, start, end, alloc))
            assign_list.sort(key=lambda x: x[0])
            candidate = (p1, p2, p3, comp_vec, assign_list)
            if best is None or better(candidate, best):
                best = candidate
            return

        o = order_seq[idx]
        oid = o["id"]
        backtrack(idx + 1, selected_assignments)
        for line, start, end in win_by_id.get(oid, []):
            backtrack(idx + 1, selected_assignments + [(oid, line, start, end)])

    backtrack(0, [])

    if best is None:
        selected_ids = []
        assignments = {}
    else:
        p1, p2, p3, comp_vec, assign_list = best
        selected_ids = sorted(oid for oid, _, _, _, _ in assign_list)
        assignments = {oid: (line, start, end) for oid, line, start, end, _ in assign_list}

    selected = selected_ids

    erp_orders = []
    for oid in selected:
        o = order_by_id[oid]
        line, start, end = assignments[oid]
        erp_orders.append({
            "wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
            "due": o["due"], "start": start, "end": end, "line": line,
            "status": "PLANNED", "parent": oid,
        })
    for w in wip:
        erp_orders.append({
            "wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
            "due": w["due"], "start": w["start"], "end": w["end"], "line": w["line"],
            "status": "WIP_CONT", "parent": None,
        })
    erp_orders.sort(key=lambda x: x["wo"])

    mes = []
    by_line = {}
    for w in wip:
        by_line.setdefault(w["line"], []).append({
            "wo": w["id"], "qty": w["qty"], "start": w["start"], "end": w["end"], "status": "WIP_CONT",
        })
    for oid in selected:
        o = order_by_id[oid]
        line, start, end = assignments[oid]
        by_line.setdefault(line, []).append({
            "wo": oid, "qty": o["qty"], "start": start, "end": end, "status": "PLANNED",
        })
    for line in sorted(by_line.keys()):
        tasks = sorted(by_line[line], key=lambda t: (t["start"], t["wo"]))
        for seq, t in enumerate(tasks, 1):
            mes.append({
                "run": run_id, "line": line, "seq": seq, "wo": t["wo"],
                "qty": t["qty"], "start": t["start"], "end": t["end"], "status": t["status"],
            })

    wms = []
    if best is not None:
        alloc = compute_global_alloc([(oid, line, start, end) for oid, line, start, end, _ in assign_list])
        for oid in selected:
            for comp, lot, qty in alloc.get(oid, []):
                wms.append({
                    "reservation": None, "run": run_id, "wo": oid,
                    "component": comp, "lot": lot, "qty": qty, "status": "RESERVED",
                })
    wms.sort(key=lambda x: (x["wo"], x["component"], x["lot"], x["qty"]))
    for i, w in enumerate(wms, 1):
        w["reservation"] = "r%04d" % i

    return {
        "selected": selected,
        "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": erp_orders},
        "mes": mes,
        "wms": wms,
    }
