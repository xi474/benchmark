def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload["orders"]
    released = payload.get("released", [])
    routing = payload["routing"]
    lines = payload["lines"]
    wip = payload.get("wip", [])
    freeze = payload.get("freeze", 0)
    changeover = payload.get("changeover", 0)

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]
        triples = []
        if sku in released and sku in routing:
            duration = routing[sku]["setup"] + routing[sku]["per_unit"] * qty
            for line in lines:
                if sku not in line.get("qualified", []):
                    continue
                min_start = freeze
                for w in wip:
                    if w.get("line") == line["id"]:
                        min_start = max(min_start, w["end"] + changeover)
                for window in line.get("windows", []):
                    ws, we = window
                    lo = max(min_start, ws)
                    hi = we - duration + 1
                    for start in range(lo, hi):
                        end = start + duration
                        if end <= due:
                            triples.append([line["id"], start, end])
        result[oid] = triples
    return result
