def compute(payload):
    """按工单 ID 输出递归展开后的基础物料需求映射。"""
    orders = payload["orders"]
    bom = payload["bom"]

    def expand(sku, qty, acc):
        if sku in bom:
            for child, per in bom[sku].items():
                expand(child, qty * per, acc)
        else:
            acc[sku] = acc.get(sku, 0) + qty

    result = {}
    for order in orders:
        acc = {}
        expand(order["sku"], order["qty"], acc)
        result[order["id"]] = acc
    return result
