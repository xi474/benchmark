"""C011 integration: combine material demand and line windows into a full plan."""


def combine(payload, left, right):
    """left = material demand per order id; right = line windows per order id."""
    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    lines = payload["lines"]
    routing = payload["routing"]
    released = payload.get("released", [])
    substitutes = payload.get("substitutes", {})
    lots = payload.get("lots", [])
    orders = payload["orders"]
    wip = payload.get("wip", [])

    demand = left
    windows = right

    order_by_id = {o["id"]: o for o in orders}

    line_wip_end = {}
    for w in wip:
        lid = w["line"]
        line_wip_end[lid] = max(line_wip_end.get(lid, -1), w["end"])

    candidates = []
    for oid, triples in windows.items():
        for (line, start, end) in triples:
            candidates.append((oid, line, start, end))

    order_seq = sorted(orders, key=lambda o: (o["priority"], o["due"], o["id"]))

    def try_allocate(subset, placement):
        lot_rem = {}
        lot_info = {}
        for lot in lots:
            if lot.get("status") == "PASS":
                lot_rem[lot["id"]] = lot["qty"]
                lot_info[lot["id"]] = lot
        alloc = {}
        for o in sorted(subset, key=lambda o: o["id"]):
            oid = o["id"]
            line, start, end = placement[oid]
            comps = demand.get(oid, {})
            order_alloc = []
            for comp in sorted(comps):
                need = comps[comp]
                subs = substitutes.get(comp, [comp])
                cand_lots = []
                for lid, info in lot_info.items():
                    if info["material"] in subs and info["expiry"] >= end:
                        cand_lots.append(lid)
                cand_lots.sort()
                remaining = need
                # Spread demand across lots one unit at a time to minimize the
                # lexicographic (component, lot, qty) allocation list.
                while remaining > 0:
                    progressed = False
                    for lid in cand_lots:
                        if remaining <= 0:
                            break
                        avail = lot_rem.get(lid, 0)
                        if avail <= 0:
                            continue
                        take = 1
                        lot_rem[lid] = avail - take
                        remaining -= take
                        progressed = True
                        # merge into existing entry for this lot
                        merged = False
                        for i, (c, l, q) in enumerate(order_alloc):
                            if c == comp and l == lid:
                                order_alloc[i] = (c, l, q + take)
                                merged = True
                                break
                        if not merged:
                            order_alloc.append((comp, lid, take))
                    if not progressed:
                        return None
                order_alloc.sort()
            alloc[oid] = order_alloc
        return alloc

    def feasible(subset_ids):
        subset = [order_by_id[i] for i in subset_ids]
        cands = {}
        for o in subset:
            cands[o["id"]] = list(windows.get(o["id"], []))
        import itertools
        order_list = sorted(subset, key=lambda o: o["id"])
        placement_options = [cands[o["id"]] for o in order_list]
        for combo in itertools.product(*placement_options):
            placement = {}
            ok = True
            by_line = {}
            for o, (line, start, end) in zip(order_list, combo):
                if line in by_line:
                    for (s2, e2) in by_line[line]:
                        if not (end + changeover <= s2 or e2 + changeover <= start):
                            ok = False
                            break
                if not ok:
                    break
                by_line.setdefault(line, []).append((start, end))
                placement[o["id"]] = (line, start, end)
            if not ok:
                continue
            alloc = try_allocate(subset, placement)
            if alloc is not None:
                return placement, alloc
        return None

    def priority_score(subset_ids):
        s = [0, 0, 0]
        for i in subset_ids:
            o = order_by_id[i]
            s[o["priority"] - 1] += o["qty"]
        return tuple(s)

    def completion_vector(subset_ids):
        sset = set(subset_ids)
        return tuple(1 if o["id"] in sset else 0 for o in order_seq)

    def schedule_key(subset_ids, placement, alloc):
        items = []
        for oid in sorted(subset_ids):
            line, start, end = placement[oid]
            a = sorted(alloc[oid])
            items.append((oid, line, start, end, a))
        return items

    best = None
    best_key = None
    all_ids = [o["id"] for o in orders]
    n = len(all_ids)

    for mask in range(1 << n):
        subset_ids = [all_ids[i] for i in range(n) if (mask >> i) & 1]
        res = feasible(subset_ids)
        if res is None:
            continue
        placement, alloc = res
        key = (
            priority_score(subset_ids),
            completion_vector(subset_ids),
            schedule_key(subset_ids, placement, alloc),
        )
        if best_key is None:
            best = (subset_ids, placement, alloc)
            best_key = key
        else:
            ps = priority_score(subset_ids)
            bps = best_key[0]
            if ps > bps:
                best = (subset_ids, placement, alloc)
                best_key = key
                continue
            elif ps < bps:
                continue
            cv = completion_vector(subset_ids)
            bcv = best_key[1]
            if cv > bcv:
                best = (subset_ids, placement, alloc)
                best_key = key
                continue
            elif cv < bcv:
                continue
            sk = schedule_key(subset_ids, placement, alloc)
            bsk = best_key[2]
            if sk < bsk:
                best = (subset_ids, placement, alloc)
                best_key = key

    if best is None:
        selected_ids = []
        placement = {}
        alloc = {}
    else:
        selected_ids, placement, alloc = best
    selected_ids = sorted(selected_ids)

    erp_orders = []
    for oid in selected_ids:
        o = order_by_id[oid]
        line, start, end = placement[oid]
        erp_orders.append({
            "wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
            "due": o["due"], "start": start, "end": end, "line": line,
            "status": "PLANNED", "parent": oid,
        })
    for w in wip:
        erp_orders.append({
            "wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
            "due": w["due"], "start": w["start"], "end": w["end"],
            "line": w["line"], "status": "WIP_CONT", "parent": None,
        })
    erp_orders.sort(key=lambda x: x["wo"])

    mes = []
    line_tasks = {}
    for w in wip:
        line_tasks.setdefault(w["line"], []).append({
            "wo": w["id"], "qty": w["qty"], "start": w["start"],
            "end": w["end"], "status": "WIP_CONT",
        })
    for oid in selected_ids:
        o = order_by_id[oid]
        line, start, end = placement[oid]
        line_tasks.setdefault(line, []).append({
            "wo": oid, "qty": o["qty"], "start": start,
            "end": end, "status": "PLANNED",
        })
    for line in sorted(line_tasks):
        tasks = sorted(line_tasks[line], key=lambda t: (t["start"], t["wo"]))
        for seq, t in enumerate(tasks, 1):
            mes.append({
                "run": run_id, "line": line, "seq": seq, "wo": t["wo"],
                "qty": t["qty"], "start": t["start"], "end": t["end"],
                "status": t["status"],
            })

    wms = []
    for oid in selected_ids:
        for (comp, lot, qty) in sorted(alloc[oid]):
            wms.append({"wo": oid, "component": comp, "lot": lot, "qty": qty})
    wms.sort(key=lambda x: (x["wo"], x["component"], x["lot"], x["qty"]))
    for i, r in enumerate(wms, 1):
        wms[i - 1] = {
            "reservation": "r%04d" % i,
            "run": run_id,
            "wo": r["wo"],
            "component": r["component"],
            "lot": r["lot"],
            "qty": r["qty"],
            "status": "RESERVED",
        }

    return {
        "selected": selected_ids,
        "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": erp_orders},
        "mes": mes,
        "wms": wms,
    }
