import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "只使用题内正常输入域，不考察NaN、任意畸形JSON或错误文本。",
                "reason": "Public spec explicitly excludes NaN and malformed JSON from the tested domain.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "只使用题内正常输入域，不考察NaN、任意畸形JSON或错误文本。",
                "reason": "Public spec excludes malformed inputs; no ValueError contract is stated.",
            },
        },
    },
]


class TestPlanBehavior(unittest.TestCase):
    def test_transform_output_shape_and_ordering(self):
        payload = {
            "run_id": "run-0", "freeze": 1, "changeover": 1,
            "lines": [{"id": "L1", "qualified": ["A"], "windows": [[1, 8]]}],
            "bom": {"A": {"M": 1}},
            "released": ["A"],
            "routing": {"A": {"setup": 1, "per_unit": 1}},
            "substitutes": {"M": ["M"]},
            "lots": [{"id": "m1", "material": "M", "qty": 5, "status": "PASS", "expiry": 10}],
            "orders": [
                {"id": "o2", "sku": "A", "qty": 1, "priority": 1, "due": 6},
                {"id": "o1", "sku": "A", "qty": 1, "priority": 1, "due": 4},
            ],
            "wip": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertEqual(set(result.keys()), {"selected", "erp", "mes", "wms"})
        self.assertEqual(result["selected"], sorted(result["selected"]))
        self.assertEqual(result["erp"]["run"]["id"], "run-0")
        self.assertEqual(result["erp"]["run"]["freeze"], 1)
        for i, r in enumerate(result["wms"], 1):
            self.assertEqual(r["reservation"], "r%04d" % i)
            self.assertEqual(r["status"], "RESERVED")

    def test_infeasible_order_excluded(self):
        payload = {
            "run_id": "r", "freeze": 0, "changeover": 0,
            "lines": [{"id": "L1", "qualified": ["A"], "windows": [[0, 10]]}],
            "bom": {"A": {"M": 1}},
            "released": ["A"],
            "routing": {"A": {"setup": 1, "per_unit": 1}},
            "substitutes": {"M": ["M"]},
            "lots": [{"id": "m1", "material": "M", "qty": 5, "status": "PASS", "expiry": 10}],
            "orders": [
                {"id": "o1", "sku": "A", "qty": 1, "priority": 1, "due": 5},
                {"id": "o2", "sku": "X", "qty": 1, "priority": 1, "due": 5},
            ],
            "wip": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["selected"], ["o1"])
        wos = [o["wo"] for o in result["erp"]["orders"]]
        self.assertNotIn("o2", wos)

    def test_wip_preserved_and_first(self):
        payload = {
            "run_id": "r", "freeze": 0, "changeover": 1,
            "lines": [{"id": "L1", "qualified": ["A"], "windows": [[0, 10]]}],
            "bom": {"A": {"M": 1}},
            "released": ["A"],
            "routing": {"A": {"setup": 1, "per_unit": 1}},
            "substitutes": {"M": ["M"]},
            "lots": [{"id": "m1", "material": "M", "qty": 5, "status": "PASS", "expiry": 10}],
            "orders": [{"id": "o1", "sku": "A", "qty": 1, "priority": 1, "due": 8}],
            "wip": [{"id": "w0", "sku": "A", "qty": 1, "line": "L1", "start": 0, "end": 2, "due": 2}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        mes = result["mes"]
        self.assertEqual(mes[0]["wo"], "w0")
        self.assertEqual(mes[0]["status"], "WIP_CONT")
        self.assertEqual(mes[0]["seq"], 1)
        planned = [m for m in mes if m["wo"] == "o1"]
        self.assertTrue(planned[0]["start"] >= 2 + 1)


if __name__ == "__main__":
    unittest.main()
