def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    batches = payload["batches"]
    keys = left   # list of batches of cleaned emails
    profiles = right  # list of batches of {name, city, source, time}

    # records: email -> {name, city, first_contact, sources:set, complete:bool}
    records = {}
    # sources view: source -> set of emails
    sources = {}

    result_batches = []

    for bi, batch in enumerate(batches):
        emails = keys[bi]
        profs = profiles[bi]

        # snapshot for rollback
        snapshot_records = {e: dict(v, sources=set(v["sources"])) for e, v in records.items()}
        snapshot_sources = {s: set(v) for s, v in sources.items()}

        items = []
        conflict = False

        for i, rec in enumerate(batch):
            email = emails[i]
            p = profs[i]
            name = p["name"]
            city = p["city"]
            source = p["source"]
            time = p["time"]

            existing = records.get(email)

            # conflict check against existing record (complete or incomplete)
            if existing is not None:
                if existing["name"] and name and existing["name"] != name:
                    conflict = True
                    break
                if existing["city"] and city and existing["city"] != city:
                    conflict = True
                    break

            if conflict:
                break

            if existing is None:
                # new record
                complete = bool(name) and bool(city)
                records[email] = {
                    "name": name,
                    "city": city,
                    "first_contact": time,
                    "sources": {source},
                    "complete": complete,
                }
                sources.setdefault(source, set()).add(email)
                items.append("accepted" if complete else "incomplete")
            else:
                # existing record
                was_complete = existing["complete"]
                # fill non-empty fields
                if not existing["name"] and name:
                    existing["name"] = name
                if not existing["city"] and city:
                    existing["city"] = city
                # first_contact stays earliest
                if time < existing["first_contact"]:
                    existing["first_contact"] = time
                # sources merge
                existing["sources"].add(source)
                sources.setdefault(source, set()).add(email)

                now_complete = bool(existing["name"]) and bool(existing["city"])
                existing["complete"] = now_complete

                if not was_complete and now_complete:
                    items.append("promoted")
                elif was_complete:
                    items.append("duplicate")
                else:
                    items.append("incomplete")

        if conflict:
            # rollback
            records = snapshot_records
            sources = snapshot_sources
            result_batches.append({"status": "rejected", "items": []})
        else:
            result_batches.append({"status": "committed", "items": items})

    # build accepted/incomplete lists
    accepted = []
    incomplete = []
    for email in sorted(records):
        r = records[email]
        row = {
            "email": email,
            "name": r["name"],
            "city": r["city"],
            "first_contact": r["first_contact"],
            "sources": sorted(r["sources"]),
        }
        if r["complete"]:
            accepted.append(row)
        else:
            incomplete.append(row)

    sources_out = {s: sorted(v) for s, v in sources.items()}

    return {
        "batches": result_batches,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_out,
    }
