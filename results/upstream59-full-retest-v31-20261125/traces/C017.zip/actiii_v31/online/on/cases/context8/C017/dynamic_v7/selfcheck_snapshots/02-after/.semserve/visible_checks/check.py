import unittest

# Injected names (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict
# check_api_boundary(...) -> raises on failure


class TestContactKeys(unittest.TestCase):
    def test_cleans_email_preserving_order(self):
        payload = {
            "batches": [
                [{"email": "  A@Example.COM ", "name": "A", "city": "C", "source": "s", "time": 1}],
                [{"email": "b@x.com", "name": "B", "city": "D", "source": "t", "time": 2}],
            ]
        }
        result = call_candidate("components/contact_keys/work.py", "compute", args=[payload])
        self.assertEqual(result, [["a@example.com"], ["b@x.com"]])


class TestContactProfiles(unittest.TestCase):
    def test_collapses_whitespace(self):
        payload = {
            "batches": [
                [{"email": "a@x.com", "name": "  Alice   Bob ", "city": "  New   York ", "source": "web", "time": 5}]
            ]
        }
        result = call_candidate("components/contact_profiles/work.py", "compute", args=[payload])
        self.assertEqual(result, [[{"name": "Alice Bob", "city": "New York", "source": "web", "time": 5}]])


class TestIntegration(unittest.TestCase):
    def _combine(self, payload):
        left = call_candidate("components/contact_keys/work.py", "compute", args=[payload])
        right = call_candidate("components/contact_profiles/work.py", "compute", args=[payload])
        return call_candidate("integration.py", "combine", args=[payload, left, right])

    def test_conflict_rolls_back_batch(self):
        payload = {
            "batches": [
                [{"email": "a@x.com", "name": "Alice", "city": "Paris", "source": "web", "time": 1}],
                [{"email": "a@x.com", "name": "Bob", "city": "Paris", "source": "cli", "time": 2}],
            ]
        }
        result = self._combine(payload)
        self.assertEqual(result["batches"][0]["status"], "committed")
        self.assertEqual(result["batches"][1]["status"], "rejected")
        self.assertEqual(result["batches"][1]["items"], [])
        # record unchanged
        self.assertEqual(result["accepted"][0]["name"], "Alice")
        self.assertEqual(result["accepted"][0]["first_contact"], 1)
        self.assertEqual(result["accepted"][0]["sources"], ["web"])

    def test_incomplete_promotion_keeps_first_contact(self):
        payload = {
            "batches": [
                [{"email": "a@x.com", "name": "Alice", "city": "", "source": "web", "time": 10}],
                [{"email": "a@x.com", "name": "", "city": "Paris", "source": "cli", "time": 5}],
            ]
        }
        result = self._combine(payload)
        self.assertEqual(result["batches"][0]["items"], ["incomplete"])
        self.assertEqual(result["batches"][1]["items"], ["promoted"])
        self.assertEqual(result["accepted"][0]["name"], "Alice")
        self.assertEqual(result["accepted"][0]["city"], "Paris")
        self.assertEqual(result["accepted"][0]["first_contact"], 5)
        self.assertEqual(result["accepted"][0]["sources"], ["cli", "web"])

    def test_duplicate_complete_immutable(self):
        payload = {
            "batches": [
                [{"email": "a@x.com", "name": "Alice", "city": "Paris", "source": "web", "time": 3}],
                [{"email": "a@x.com", "name": "Alice", "city": "Paris", "source": "cli", "time": 1}],
            ]
        }
        result = self._combine(payload)
        self.assertEqual(result["batches"][1]["items"], ["duplicate"])
        self.assertEqual(result["accepted"][0]["first_contact"], 1)
        self.assertEqual(result["accepted"][0]["sources"], ["cli", "web"])

    def test_sources_view_sorted(self):
        payload = {
            "batches": [
                [{"email": "b@x.com", "name": "B", "city": "C", "source": "web", "time": 1}],
                [{"email": "a@x.com", "name": "A", "city": "C", "source": "web", "time": 2}],
            ]
        }
        result = self._combine(payload)
        self.assertEqual(result["sources"]["web"], ["a@x.com", "b@x.com"])
        self.assertEqual([r["email"] for r in result["accepted"]], ["a@x.com", "b@x.com"])


if __name__ == "__main__":
    unittest.main()
