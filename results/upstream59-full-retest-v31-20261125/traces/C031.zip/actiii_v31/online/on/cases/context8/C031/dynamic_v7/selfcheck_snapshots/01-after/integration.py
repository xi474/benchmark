import os
import pty
import select
import signal
import tempfile
import time


def _normalize(data):
    text = data.decode("utf-8", errors="replace")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text


def _read_until(fd, marker, timeout):
    buf = b""
    deadline = time.monotonic() + timeout
    while True:
        if marker is not None and marker.encode("utf-8") in buf:
            return _normalize(buf), False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return _normalize(buf), False
        r, _, _ = select.select([fd], [], [], remaining)
        if not r:
            return _normalize(buf), False
        try:
            chunk = os.read(fd, 4096)
        except OSError:
            return _normalize(buf), True
        if not chunk:
            return _normalize(buf), True
        buf += chunk


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    rc = right["rc"]
    timeout = right["timeout"]
    markers = right["markers"]
    steps = payload["steps"]

    tmpdir = tempfile.mkdtemp(prefix="c031_")
    home = os.path.join(tmpdir, "home")
    os.makedirs(home, exist_ok=True)
    open(os.path.join(home, ".hushlogin"), "w").close()

    rcfile = os.path.join(tmpdir, "rcfile")
    with open(rcfile, "w") as f:
        f.write(rc)

    env = dict(os.environ)
    env["HOME"] = home
    env["TERM"] = "dumb"
    env["LC_ALL"] = "C"
    env["HISTFILE"] = "/dev/null"

    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(home)
        os.environ.clear()
        os.environ.update(env)
        os.execvpe(
            "/bin/bash",
            ["/bin/bash", "--noprofile", "--rcfile", rcfile, "-i"],
            env,
        )

    chunks = []
    closed = False
    try:
        text, eof = _read_until(fd, "PROMPT> ", timeout)
        chunks.append(text)
        if eof:
            closed = True
            return {"chunks": chunks, "closed": closed}

        for i, step in enumerate(steps):
            data = bytes.fromhex(left[i])
            os.write(fd, data)
            marker = markers[i]
            text, eof = _read_until(fd, marker, timeout)
            chunks.append(text)
            if eof:
                closed = True
                break
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.killpg(pid, signal.SIGKILL)
        except OSError:
            pass
        try:
            os.waitpid(pid, 0)
        except OSError:
            pass
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)

    return {"chunks": chunks, "closed": closed}
