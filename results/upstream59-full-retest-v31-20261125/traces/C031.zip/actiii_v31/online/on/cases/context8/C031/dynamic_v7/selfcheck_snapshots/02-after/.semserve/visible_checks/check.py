import unittest

# Injected names (call_candidate, CandidateCallError, check_api_boundary,
# visible_document) are provided by the SDK harness at runtime.

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "The public contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "输入steps，每步keys为字符串列表",
                "reason": "The contract does not specify ValueError for a non-object payload.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_transform_returns_chunks_and_closed(self):
        # Output contract: transform returns a dict with chunks (list) and closed (bool).
        payload = {
            "steps": [
                {"keys": ["printf 'X\\n'", "Enter"], "until": "PROMPT> "}
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertIn("chunks", result)
        self.assertIn("closed", result)
        self.assertIsInstance(result["chunks"], list)
        self.assertIsInstance(result["closed"], bool)
        self.assertEqual(len(result["chunks"]), 2)
        self.assertEqual(result["chunks"][0], "PROMPT> ")
        self.assertIn("X\n", result["chunks"][1])
        self.assertFalse(result["closed"])

    def test_transform_does_not_mutate_input(self):
        payload = {
            "steps": [
                {"keys": ["printf 'X\\n'", "Enter"], "until": "PROMPT> "}
            ]
        }
        snapshot = {"steps": [dict(payload["steps"][0])]}
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)

    def test_empty_steps_yields_single_prompt_chunk(self):
        # Valid rare path: no steps -> only the initial prompt chunk, not closed.
        payload = {"steps": []}
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertEqual(result["chunks"], ["PROMPT> "])
        self.assertFalse(result["closed"])


if __name__ == "__main__":
    unittest.main()
