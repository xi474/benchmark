import struct


def compute(payload):
    """输出 [入口地址, [[地址,字节],…]]，按加载后的地址升序排列，包括 PT_LOAD 零填充。"""
    elf_hex = payload["elf_hex"]
    data = bytes.fromhex(elf_hex)

    # ELF32 little-endian header
    e_entry = struct.unpack_from("<I", data, 24)[0]
    e_phoff = struct.unpack_from("<I", data, 28)[0]
    e_phentsize = struct.unpack_from("<H", data, 42)[0]
    e_phnum = struct.unpack_from("<H", data, 44)[0]

    PT_LOAD = 1

    # Collect (address, byte) pairs from all PT_LOAD segments.
    pairs = []
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        p_type = struct.unpack_from("<I", data, off)[0]
        if p_type != PT_LOAD:
            continue
        p_offset = struct.unpack_from("<I", data, off + 4)[0]
        p_vaddr = struct.unpack_from("<I", data, off + 8)[0]
        p_filesz = struct.unpack_from("<I", data, off + 16)[0]
        p_memsz = struct.unpack_from("<I", data, off + 20)[0]

        # File-backed bytes.
        for j in range(p_filesz):
            pairs.append((p_vaddr + j, data[p_offset + j]))
        # BSS zero-fill.
        for j in range(p_filesz, p_memsz):
            pairs.append((p_vaddr + j, 0))

    pairs.sort(key=lambda p: p[0])

    return [e_entry, [[addr, byte] for addr, byte in pairs]]
