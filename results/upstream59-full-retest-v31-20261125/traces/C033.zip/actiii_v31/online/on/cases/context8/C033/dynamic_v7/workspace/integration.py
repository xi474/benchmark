"""MIPS32 interpreter integration: combine ELF segments and IO buffers into the full result."""

MASK = 0xFFFFFFFF


def _s32(v):
    v &= MASK
    return v - (1 << 32) if v & (1 << 31) else v


def _signext(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v & (1 << (bits - 1)) else v


def combine(payload, left, right):
    entry, segments = left
    files, stdin = right

    mem = {}
    for addr, byte in segments:
        mem[addr] = byte

    def read_byte(addr):
        return mem.get(addr & MASK, 0)

    def read_word(addr):
        addr &= MASK
        return (read_byte(addr) | (read_byte(addr + 1) << 8)
                | (read_byte(addr + 2) << 16) | (read_byte(addr + 3) << 24))

    def read_half(addr):
        addr &= MASK
        return read_byte(addr) | (read_byte(addr + 1) << 8)

    def write_byte(addr, val):
        mem[addr & MASK] = val & 0xFF

    def write_word(addr, val):
        addr &= MASK
        write_byte(addr, val & 0xFF)
        write_byte(addr + 1, (val >> 8) & 0xFF)
        write_byte(addr + 2, (val >> 16) & 0xFF)
        write_byte(addr + 3, (val >> 24) & 0xFF)

    def write_half(addr, val):
        addr &= MASK
        write_byte(addr, val & 0xFF)
        write_byte(addr + 1, (val >> 8) & 0xFF)

    regs = [0] * 32
    sp = payload.get("stack_pointer", 0x7FFF0000)
    regs[29] = sp & MASK
    hi = 0
    lo = 0
    pc = entry & MASK

    max_steps = payload.get("max_steps", 20000)

    file_data = {name: list(data) for name, data in files.items()}
    stdin_data = list(stdin)
    stdout_data = []
    stderr_data = []
    fds = {
        0: ['stdin', stdin_data, 0],
        1: ['stdout', stdout_data, 0],
        2: ['stderr', stderr_data, 0],
    }
    next_fd = 3

    syscalls = []
    steps = 0
    exit_code = 0
    exited = False

    def _do_syscall():
        nonlocal next_fd, exit_code, exited
        num = regs[2] & MASK
        a0 = regs[4] & MASK
        a1 = regs[5] & MASK
        a2 = regs[6] & MASK
        syscalls.append({"number": num, "args": [a0, a1, a2]})
        if num == 4001:
            exit_code = a0 & 0xFF
            exited = True
        elif num == 4003:  # read
            fd = a0
            buf = a1
            n = a2
            if fd in fds:
                kind, data, off = fds[fd]
                chunk = data[off:off + n]
                for i, b in enumerate(chunk):
                    write_byte(buf + i, b)
                fds[fd][2] = off + len(chunk)
                regs[2] = len(chunk)
            else:
                regs[2] = 0
            regs[7] = 0
        elif num == 4004:  # write
            fd = a0
            buf = a1
            n = a2
            data_out = bytes(read_byte(buf + i) for i in range(n))
            if fd in fds:
                fds[fd][1].extend(data_out)
                fds[fd][2] += n
                regs[2] = n
            else:
                regs[2] = 0
            regs[7] = 0
        elif num == 4005:  # open
            # filename is a NUL-terminated string at a0
            name_bytes = []
            i = 0
            while True:
                b = read_byte(a0 + i)
                if b == 0:
                    break
                name_bytes.append(b)
                i += 1
            name = bytes(name_bytes).decode('utf-8')
            flags = a1
            mode = a2
            if flags == 0:
                data = list(file_data.get(name, []))
            elif flags == 1:
                data = []
                file_data[name] = data
            elif flags == 9:
                data = list(file_data.get(name, []))
                file_data[name] = data
            else:
                data = list(file_data.get(name, []))
            fd = next_fd
            next_fd += 1
            fds[fd] = ['file', data, 0]
            regs[2] = fd
            regs[7] = 0
        elif num == 4006:  # close
            fd = a0
            if fd in fds and fd >= 3:
                del fds[fd]
            regs[2] = 0
            regs[7] = 0

    def _execute_delay(instr, delay_pc):
        opcode = instr >> 26
        rs = (instr >> 21) & 0x1F
        rt = (instr >> 16) & 0x1F
        rd = (instr >> 11) & 0x1F
        shamt = (instr >> 6) & 0x1F
        funct = instr & 0x3F
        imm = instr & 0xFFFF

        def get(reg):
            return regs[reg] & MASK

        def setr(reg, val):
            if reg != 0:
                regs[reg] = val & MASK

        if opcode == 0:
            if funct == 0x00:
                setr(rd, get(rt) << shamt)
            elif funct == 0x02:
                setr(rd, get(rt) >> shamt)
            elif funct == 0x03:
                setr(rd, (_s32(get(rt)) >> shamt) & MASK)
            elif funct == 0x10:
                setr(rd, hi)
            elif funct == 0x11:
                nonlocal_hi()
            elif funct == 0x12:
                setr(rd, lo)
            elif funct == 0x13:
                nonlocal_lo()
            elif funct == 0x18:
                prod = _s32(get(rs)) * _s32(get(rt))
                set_lo(prod & MASK)
                set_hi((_s32(prod >> 32)) & MASK)
            elif funct == 0x19:
                prod = get(rs) * get(rt)
                set_lo(prod & MASK)
                set_hi((prod >> 32) & MASK)
            elif funct == 0x1A:
                a = _s32(get(rs))
                b = _s32(get(rt))
                set_lo((int(a / b)) & MASK if b != 0 else 0)
                set_hi((a - (int(a / b) * b)) & MASK if b != 0 else 0)
            elif funct == 0x1B:
                a = get(rs)
                b = get(rt)
                set_lo((a // b) & MASK if b != 0 else 0)
                set_hi((a % b) & MASK if b != 0 else 0)
            elif funct == 0x20:
                setr(rd, get(rs) + get(rt))
            elif funct == 0x21:
                setr(rd, get(rs) + get(rt))
            elif funct == 0x22:
                setr(rd, get(rs) - get(rt))
            elif funct == 0x23:
                setr(rd, get(rs) - get(rt))
            elif funct == 0x24:
                setr(rd, get(rs) & get(rt))
            elif funct == 0x25:
                setr(rd, get(rs) | get(rt))
            elif funct == 0x26:
                setr(rd, get(rs) ^ get(rt))
            elif funct == 0x27:
                setr(rd, ~(get(rs) | get(rt)))
            elif funct == 0x2A:
                setr(rd, 1 if _s32(get(rs)) < _s32(get(rt)) else 0)
            elif funct == 0x2B:
                setr(rd, 1 if get(rs) < get(rt) else 0)
            elif funct == 0x0C:
                _do_syscall()
        elif opcode == 0x08:
            setr(rt, get(rs) + _signext(imm, 16))
        elif opcode == 0x09:
            setr(rt, get(rs) + _signext(imm, 16))
        elif opcode == 0x0A:
            setr(rt, 1 if _s32(get(rs)) < _signext(imm, 16) else 0)
        elif opcode == 0x0B:
            setr(rt, 1 if get(rs) < (_signext(imm, 16) & MASK) else 0)
        elif opcode == 0x0C:
            setr(rt, get(rs) & imm)
        elif opcode == 0x0D:
            setr(rt, get(rs) | imm)
        elif opcode == 0x0E:
            setr(rt, get(rs) ^ imm)
        elif opcode == 0x0F:
            setr(rt, imm << 16)
        elif opcode == 0x20:
            setr(rt, _signext(read_byte(get(rs) + _signext(imm, 16)), 8))
        elif opcode == 0x24:
            setr(rt, read_byte(get(rs) + _signext(imm, 16)))
        elif opcode == 0x21:
            setr(rt, _signext(read_half(get(rs) + _signext(imm, 16)), 16))
        elif opcode == 0x25:
            setr(rt, read_half(get(rs) + _signext(imm, 16)))
        elif opcode == 0x23:
            setr(rt, read_word(get(rs) + _signext(imm, 16)))
        elif opcode == 0x28:
            write_byte(get(rs) + _signext(imm, 16), get(rt))
        elif opcode == 0x29:
            write_half(get(rs) + _signext(imm, 16), get(rt))
        elif opcode == 0x2B:
            write_word(get(rs) + _signext(imm, 16), get(rt))

    while not exited:
        if steps >= max_steps:
            break
        steps += 1
        instr = read_word(pc)
        if steps > max_steps:
            break
        opcode = instr >> 26
        rs = (instr >> 21) & 0x1F
        rt = (instr >> 16) & 0x1F
        rd = (instr >> 11) & 0x1F
        shamt = (instr >> 6) & 0x1F
        funct = instr & 0x3F
        imm = instr & 0xFFFF
        target = instr & 0x3FFFFFF

        next_pc = (pc + 4) & MASK
        branch_taken = False
        branch_target = next_pc

        def get(reg):
            return regs[reg] & MASK

        def setr(reg, val):
            if reg != 0:
                regs[reg] = val & MASK

        if opcode == 0:
            if funct == 0x00:
                setr(rd, get(rt) << shamt)
            elif funct == 0x02:
                setr(rd, get(rt) >> shamt)
            elif funct == 0x03:
                setr(rd, (_s32(get(rt)) >> shamt) & MASK)
            elif funct == 0x08:  # jr
                next_pc = get(rs)
            elif funct == 0x09:  # jalr
                setr(rd, (pc + 8) & MASK)
                next_pc = get(rs)
            elif funct == 0x10:
                setr(rd, hi)
            elif funct == 0x11:
                hi = get(rs)
            elif funct == 0x12:
                setr(rd, lo)
            elif funct == 0x13:
                lo = get(rs)
            elif funct == 0x18:
                prod = _s32(get(rs)) * _s32(get(rt))
                lo = prod & MASK
                hi = (_s32(prod >> 32)) & MASK
            elif funct == 0x19:
                prod = get(rs) * get(rt)
                lo = prod & MASK
                hi = (prod >> 32) & MASK
            elif funct == 0x1A:
                a = _s32(get(rs))
                b = _s32(get(rt))
                lo = (int(a / b)) & MASK if b != 0 else 0
                hi = (a - (int(a / b) * b)) & MASK if b != 0 else 0
            elif funct == 0x1B:
                a = get(rs)
                b = get(rt)
                lo = (a // b) & MASK if b != 0 else 0
                hi = (a % b) & MASK if b != 0 else 0
            elif funct == 0x20:
                setr(rd, get(rs) + get(rt))
            elif funct == 0x21:
                setr(rd, get(rs) + get(rt))
            elif funct == 0x22:
                setr(rd, get(rs) - get(rt))
            elif funct == 0x23:
                setr(rd, get(rs) - get(rt))
            elif funct == 0x24:
                setr(rd, get(rs) & get(rt))
            elif funct == 0x25:
                setr(rd, get(rs) | get(rt))
            elif funct == 0x26:
                setr(rd, get(rs) ^ get(rt))
            elif funct == 0x27:
                setr(rd, ~(get(rs) | get(rt)))
            elif funct == 0x2A:
                setr(rd, 1 if _s32(get(rs)) < _s32(get(rt)) else 0)
            elif funct == 0x2B:
                setr(rd, 1 if get(rs) < get(rt) else 0)
            elif funct == 0x0C:
                _do_syscall()
        elif opcode == 0x02:
            next_pc = ((pc + 4) & 0xF0000000) | (target << 2)
        elif opcode == 0x03:
            setr(31, (pc + 8) & MASK)
            next_pc = ((pc + 4) & 0xF0000000) | (target << 2)
        elif opcode == 0x04:
            if get(rs) == get(rt):
                branch_taken = True
                branch_target = (pc + 4 + (_signext(imm, 16) << 2)) & MASK
        elif opcode == 0x05:
            if get(rs) != get(rt):
                branch_taken = True
                branch_target = (pc + 4 + (_signext(imm, 16) << 2)) & MASK
        elif opcode == 0x06:
            if _s32(get(rs)) <= 0:
                branch_taken = True
                branch_target = (pc + 4 + (_signext(imm, 16) << 2)) & MASK
        elif opcode == 0x07:
            if _s32(get(rs)) > 0:
                branch_taken = True
                branch_target = (pc + 4 + (_signext(imm, 16) << 2)) & MASK
        elif opcode == 0x08:
            setr(rt, get(rs) + _signext(imm, 16))
        elif opcode == 0x09:
            setr(rt, get(rs) + _signext(imm, 16))
        elif opcode == 0x0A:
            setr(rt, 1 if _s32(get(rs)) < _signext(imm, 16) else 0)
        elif opcode == 0x0B:
            setr(rt, 1 if get(rs) < (_signext(imm, 16) & MASK) else 0)
        elif opcode == 0x0C:
            setr(rt, get(rs) & imm)
        elif opcode == 0x0D:
            setr(rt, get(rs) | imm)
        elif opcode == 0x0E:
            setr(rt, get(rs) ^ imm)
        elif opcode == 0x0F:
            setr(rt, imm << 16)
        elif opcode == 0x20:
            setr(rt, _signext(read_byte(get(rs) + _signext(imm, 16)), 8))
        elif opcode == 0x24:
            setr(rt, read_byte(get(rs) + _signext(imm, 16)))
        elif opcode == 0x21:
            setr(rt, _signext(read_half(get(rs) + _signext(imm, 16)), 16))
        elif opcode == 0x25:
            setr(rt, read_half(get(rs) + _signext(imm, 16)))
        elif opcode == 0x23:
            setr(rt, read_word(get(rs) + _signext(imm, 16)))
        elif opcode == 0x28:
            write_byte(get(rs) + _signext(imm, 16), get(rt))
        elif opcode == 0x29:
            write_half(get(rs) + _signext(imm, 16), get(rt))
        elif opcode == 0x2B:
            write_word(get(rs) + _signext(imm, 16), get(rt))

        # Delay slot: execute instruction at next_pc unconditionally.
        delay_pc = next_pc
        delay_instr = read_word(delay_pc)
        _execute_delay(delay_instr, delay_pc)

        if branch_taken:
            pc = branch_target
        else:
            pc = next_pc

    inspect_out = []
    for item in payload.get("inspect", []):
        addr = item["address"] & MASK
        length = item["length"]
        data = bytes(read_byte(addr + i) for i in range(length))
        inspect_out.append({"address": addr, "hex": data.hex()})

    final_files = {}
    for name, data in file_data.items():
        final_files[name] = bytes(data).hex()

    return {
        "exit_code": exit_code,
        "registers": [r & MASK for r in regs],
        "hi": hi & MASK,
        "lo": lo & MASK,
        "steps": steps,
        "stdout_hex": bytes(stdout_data).hex(),
        "stderr_hex": bytes(stderr_data).hex(),
        "files": final_files,
        "inspect": inspect_out,
        "syscalls": syscalls,
    }
