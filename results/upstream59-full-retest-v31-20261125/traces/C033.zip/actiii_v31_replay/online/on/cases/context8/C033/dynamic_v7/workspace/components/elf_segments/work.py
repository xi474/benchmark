import struct


def compute(payload):
    """输出 [入口地址, [[地址,字节],…]]，按加载后的地址升序排列，包括 PT_LOAD 零填充。"""
    data = bytes.fromhex(payload["elf_hex"])

    e_entry = struct.unpack_from("<I", data, 24)[0]
    e_phoff = struct.unpack_from("<I", data, 28)[0]
    e_phentsize = struct.unpack_from("<H", data, 42)[0]
    e_phnum = struct.unpack_from("<H", data, 44)[0]

    segments = []
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        p_type = struct.unpack_from("<I", data, off)[0]
        if p_type != 1:  # PT_LOAD
            continue
        p_offset = struct.unpack_from("<I", data, off + 4)[0]
        p_vaddr = struct.unpack_from("<I", data, off + 8)[0]
        p_filesz = struct.unpack_from("<I", data, off + 16)[0]
        p_memsz = struct.unpack_from("<I", data, off + 20)[0]
        segments.append((p_vaddr, p_offset, p_filesz, p_memsz))

    segments.sort(key=lambda s: s[0])

    memory = []
    for p_vaddr, p_offset, p_filesz, p_memsz in segments:
        for j in range(p_memsz):
            if j < p_filesz:
                byte = data[p_offset + j]
            else:
                byte = 0
            memory.append([p_vaddr + j, byte])

    return [e_entry, memory]
