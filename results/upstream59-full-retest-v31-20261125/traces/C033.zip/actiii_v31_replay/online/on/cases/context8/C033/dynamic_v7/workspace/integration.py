import struct

MASK32 = 0xFFFFFFFF


def _s32(v):
    v &= MASK32
    return v - (1 << 32) if v & (1 << 31) else v


def _signext(v, bits):
    v &= (1 << bits) - 1
    if v & (1 << (bits - 1)):
        v -= 1 << bits
    return v


def combine(payload, left, right):
    entry, segments = left
    files_map, stdin_bytes = right

    memory = {}
    for addr, byte in segments:
        memory[addr] = byte

    def read_byte(addr):
        return memory.get(addr & MASK32, 0)

    def read_word(addr):
        addr &= MASK32
        return (read_byte(addr) | (read_byte(addr + 1) << 8)
                | (read_byte(addr + 2) << 16) | (read_byte(addr + 3) << 24))

    def read_half(addr):
        addr &= MASK32
        return read_byte(addr) | (read_byte(addr + 1) << 8)

    def write_byte(addr, val):
        memory[addr & MASK32] = val & 0xFF

    def write_half(addr, val):
        addr &= MASK32
        write_byte(addr, val & 0xFF)
        write_byte(addr + 1, (val >> 8) & 0xFF)

    def write_word(addr, val):
        addr &= MASK32
        write_byte(addr, val & 0xFF)
        write_byte(addr + 1, (val >> 8) & 0xFF)
        write_byte(addr + 2, (val >> 16) & 0xFF)
        write_byte(addr + 3, (val >> 24) & 0xFF)

    regs = [0] * 32
    hi = 0
    lo = 0
    pc = entry

    sp = payload.get("stack_pointer")
    if sp is None:
        sp = 0x7FFF0000
    regs[29] = sp & MASK32

    max_steps = payload.get("max_steps", 20000)

    files = {name: list(bytes.fromhex(h)) for name, h in files_map.items()}
    stdin_data = list(stdin_bytes)
    stdout_data = []
    stderr_data = []
    fds = {
        0: ["stdin", stdin_data, 0],
        1: ["stdout", stdout_data, 0],
        2: ["stderr", stderr_data, 0],
    }
    next_fd = 3

    syscalls = []
    steps = 0
    exit_code = 0

    def syscall(number, a0, a1, a2):
        nonlocal next_fd
        if number == 4001:
            return a0 & 0xFF, True
        if number == 4003:
            fd, buf, n = a0, a1, a2
            kind, data, off = fds[fd]
            chunk = data[off:off + n]
            fds[fd][2] = off + len(chunk)
            for i, b in enumerate(chunk):
                write_byte(buf + i, b)
            return len(chunk), False
        if number == 4004:
            fd, buf, n = a0, a1, a2
            kind, data, off = fds[fd]
            for i in range(n):
                data.append(read_byte(buf + i))
            fds[fd][2] = off + n
            return n, False
        if number == 4005:
            filename, flags, mode = a0, a1, a2
            name = ""
            i = 0
            while True:
                b = read_byte(filename + i)
                if b == 0:
                    break
                name += chr(b)
                i += 1
            if flags == 0:
                data = files.get(name, [])
                fds[next_fd] = ["file", data, 0]
            elif flags == 1:
                data = []
                files[name] = data
                fds[next_fd] = ["file", data, 0]
            elif flags == 9:
                data = files.get(name, [])
                files[name] = data
                fds[next_fd] = ["file", data, len(data)]
            else:
                data = files.get(name, [])
                fds[next_fd] = ["file", data, 0]
            fd = next_fd
            next_fd += 1
            return fd, False
        if number == 4006:
            fd = a0
            if fd in fds and fd >= 3:
                del fds[fd]
            return 0, False
        return 0, False

    while steps < max_steps:
        instr = read_word(pc)
        opcode = instr >> 26
        rs = (instr >> 21) & 0x1F
        rt = (instr >> 16) & 0x1F
        rd = (instr >> 11) & 0x1F
        shamt = (instr >> 6) & 0x1F
        funct = instr & 0x3F
        imm = instr & 0xFFFF
        target = instr & 0x3FFFFFF

        next_pc = (pc + 4) & MASK32
        delay_pc = None

        def set_reg(r, v):
            if r != 0:
                regs[r] = v & MASK32

        if opcode == 0:
            if funct == 0x00:
                set_reg(rd, regs[rt] << shamt)
            elif funct == 0x02:
                set_reg(rd, regs[rt] >> shamt)
            elif funct == 0x03:
                set_reg(rd, _s32(regs[rt]) >> shamt)
            elif funct == 0x08:
                delay_pc = next_pc
                next_pc = regs[rs]
            elif funct == 0x09:
                delay_pc = next_pc
                set_reg(rd, (pc + 8) & MASK32)
                next_pc = regs[rs]
            elif funct == 0x20:
                set_reg(rd, regs[rs] + regs[rt])
            elif funct == 0x21:
                set_reg(rd, regs[rs] + regs[rt])
            elif funct == 0x22:
                set_reg(rd, regs[rs] - regs[rt])
            elif funct == 0x23:
                set_reg(rd, regs[rs] - regs[rt])
            elif funct == 0x24:
                set_reg(rd, regs[rs] & regs[rt])
            elif funct == 0x25:
                set_reg(rd, regs[rs] | regs[rt])
            elif funct == 0x26:
                set_reg(rd, regs[rs] ^ regs[rt])
            elif funct == 0x27:
                set_reg(rd, ~(regs[rs] | regs[rt]))
            elif funct == 0x2A:
                set_reg(rd, 1 if _s32(regs[rs]) < _s32(regs[rt]) else 0)
            elif funct == 0x2B:
                set_reg(rd, 1 if regs[rs] < regs[rt] else 0)
            elif funct == 0x10:
                set_reg(rd, hi)
            elif funct == 0x12:
                set_reg(rd, lo)
            elif funct == 0x11:
                hi = regs[rs] & MASK32
            elif funct == 0x13:
                lo = regs[rs] & MASK32
            elif funct == 0x18:
                prod = _s32(regs[rs]) * _s32(regs[rt])
                lo = prod & MASK32
                hi = (_s32(prod >> 32)) & MASK32
            elif funct == 0x19:
                prod = regs[rs] * regs[rt]
                lo = prod & MASK32
                hi = (prod >> 32) & MASK32
            elif funct == 0x1A:
                a = _s32(regs[rs])
                b = _s32(regs[rt])
                if b == 0:
                    lo = 0
                    hi = 0
                else:
                    q = int(a / b)
                    r = a - q * b
                    lo = q & MASK32
                    hi = r & MASK32
            elif funct == 0x1B:
                a = regs[rs]
                b = regs[rt]
                if b == 0:
                    lo = 0
                    hi = 0
                else:
                    lo = (a // b) & MASK32
                    hi = (a % b) & MASK32
            elif funct == 0x0C:
                syscalls.append({"number": regs[2], "args": [regs[4], regs[5], regs[6]]})
                result, exited = syscall(regs[2], regs[4], regs[5], regs[6])
                set_reg(2, result)
                set_reg(7, 0)
                if exited:
                    exit_code = result
                    steps += 1
                    break
        elif opcode == 0x02:
            delay_pc = next_pc
            next_pc = ((pc + 4) & 0xF0000000) | (target << 2)
        elif opcode == 0x03:
            delay_pc = next_pc
            set_reg(31, (pc + 8) & MASK32)
            next_pc = ((pc + 4) & 0xF0000000) | (target << 2)
        elif opcode == 0x04:
            if regs[rs] == regs[rt]:
                delay_pc = next_pc
                next_pc = (pc + 4 + (_signext(imm, 16) << 2)) & MASK32
        elif opcode == 0x05:
            if regs[rs] != regs[rt]:
                delay_pc = next_pc
                next_pc = (pc + 4 + (_signext(imm, 16) << 2)) & MASK32
        elif opcode == 0x06:
            if _s32(regs[rs]) <= 0:
                delay_pc = next_pc
                next_pc = (pc + 4 + (_signext(imm, 16) << 2)) & MASK32
        elif opcode == 0x07:
            if _s32(regs[rs]) > 0:
                delay_pc = next_pc
                next_pc = (pc + 4 + (_signext(imm, 16) << 2)) & MASK32
        elif opcode == 0x08:
            set_reg(rt, regs[rs] + _signext(imm, 16))
        elif opcode == 0x09:
            set_reg(rt, regs[rs] + _signext(imm, 16))
        elif opcode == 0x0A:
            set_reg(rt, 1 if _s32(regs[rs]) < _signext(imm, 16) else 0)
        elif opcode == 0x0B:
            set_reg(rt, 1 if regs[rs] < (imm & 0xFFFF) else 0)
        elif opcode == 0x0C:
            set_reg(rt, regs[rs] & imm)
        elif opcode == 0x0D:
            set_reg(rt, regs[rs] | imm)
        elif opcode == 0x0E:
            set_reg(rt, regs[rs] ^ imm)
        elif opcode == 0x0F:
            set_reg(rt, imm << 16)
        elif opcode == 0x20:
            set_reg(rt, _signext(read_byte(regs[rs] + _signext(imm, 16)), 8))
        elif opcode == 0x24:
            set_reg(rt, read_byte(regs[rs] + _signext(imm, 16)))
        elif opcode == 0x21:
            set_reg(rt, _signext(read_half(regs[rs] + _signext(imm, 16)), 16))
        elif opcode == 0x25:
            set_reg(rt, read_half(regs[rs] + _signext(imm, 16)))
        elif opcode == 0x23:
            set_reg(rt, read_word(regs[rs] + _signext(imm, 16)))
        elif opcode == 0x28:
            write_byte(regs[rs] + _signext(imm, 16), regs[rt])
        elif opcode == 0x29:
            write_half(regs[rs] + _signext(imm, 16), regs[rt])
        elif opcode == 0x2B:
            write_word(regs[rs] + _signext(imm, 16), regs[rt])

        steps += 1
        pc = next_pc
        if delay_pc is not None:
            instr = read_word(delay_pc)
            opcode = instr >> 26
            rs = (instr >> 21) & 0x1F
            rt = (instr >> 16) & 0x1F
            rd = (instr >> 11) & 0x1F
            shamt = (instr >> 6) & 0x1F
            funct = instr & 0x3F
            imm = instr & 0xFFFF
            target = instr & 0x3FFFFFF

            if opcode == 0:
                if funct == 0x00:
                    set_reg(rd, regs[rt] << shamt)
                elif funct == 0x02:
                    set_reg(rd, regs[rt] >> shamt)
                elif funct == 0x03:
                    set_reg(rd, _s32(regs[rt]) >> shamt)
                elif funct == 0x20:
                    set_reg(rd, regs[rs] + regs[rt])
                elif funct == 0x21:
                    set_reg(rd, regs[rs] + regs[rt])
                elif funct == 0x22:
                    set_reg(rd, regs[rs] - regs[rt])
                elif funct == 0x23:
                    set_reg(rd, regs[rs] - regs[rt])
                elif funct == 0x24:
                    set_reg(rd, regs[rs] & regs[rt])
                elif funct == 0x25:
                    set_reg(rd, regs[rs] | regs[rt])
                elif funct == 0x26:
                    set_reg(rd, regs[rs] ^ regs[rt])
                elif funct == 0x27:
                    set_reg(rd, ~(regs[rs] | regs[rt]))
                elif funct == 0x2A:
                    set_reg(rd, 1 if _s32(regs[rs]) < _s32(regs[rt]) else 0)
                elif funct == 0x2B:
                    set_reg(rd, 1 if regs[rs] < regs[rt] else 0)
                elif funct == 0x10:
                    set_reg(rd, hi)
                elif funct == 0x12:
                    set_reg(rd, lo)
                elif funct == 0x11:
                    hi = regs[rs] & MASK32
                elif funct == 0x13:
                    lo = regs[rs] & MASK32
                elif funct == 0x18:
                    prod = _s32(regs[rs]) * _s32(regs[rt])
                    lo = prod & MASK32
                    hi = (_s32(prod >> 32)) & MASK32
                elif funct == 0x19:
                    prod = regs[rs] * regs[rt]
                    lo = prod & MASK32
                    hi = (prod >> 32) & MASK32
                elif funct == 0x1A:
                    a = _s32(regs[rs])
                    b = _s32(regs[rt])
                    if b == 0:
                        lo = 0
                        hi = 0
                    else:
                        q = int(a / b)
                        r = a - q * b
                        lo = q & MASK32
                        hi = r & MASK32
                elif funct == 0x1B:
                    a = regs[rs]
                    b = regs[rt]
                    if b == 0:
                        lo = 0
                        hi = 0
                    else:
                        lo = (a // b) & MASK32
                        hi = (a % b) & MASK32
                elif funct == 0x0C:
                    syscalls.append({"number": regs[2], "args": [regs[4], regs[5], regs[6]]})
                    result, exited = syscall(regs[2], regs[4], regs[5], regs[6])
                    set_reg(2, result)
                    set_reg(7, 0)
                    if exited:
                        exit_code = result
                        steps += 1
                        break
            elif opcode == 0x08:
                set_reg(rt, regs[rs] + _signext(imm, 16))
            elif opcode == 0x09:
                set_reg(rt, regs[rs] + _signext(imm, 16))
            elif opcode == 0x0A:
                set_reg(rt, 1 if _s32(regs[rs]) < _signext(imm, 16) else 0)
            elif opcode == 0x0B:
                set_reg(rt, 1 if regs[rs] < (imm & 0xFFFF) else 0)
            elif opcode == 0x0C:
                set_reg(rt, regs[rs] & imm)
            elif opcode == 0x0D:
                set_reg(rt, regs[rs] | imm)
            elif opcode == 0x0E:
                set_reg(rt, regs[rs] ^ imm)
            elif opcode == 0x0F:
                set_reg(rt, imm << 16)
            elif opcode == 0x20:
                set_reg(rt, _signext(read_byte(regs[rs] + _signext(imm, 16)), 8))
            elif opcode == 0x24:
                set_reg(rt, read_byte(regs[rs] + _signext(imm, 16)))
            elif opcode == 0x21:
                set_reg(rt, _signext(read_half(regs[rs] + _signext(imm, 16)), 16))
            elif opcode == 0x25:
                set_reg(rt, read_half(regs[rs] + _signext(imm, 16)))
            elif opcode == 0x23:
                set_reg(rt, read_word(regs[rs] + _signext(imm, 16)))
            elif opcode == 0x28:
                write_byte(regs[rs] + _signext(imm, 16), regs[rt])
            elif opcode == 0x29:
                write_half(regs[rs] + _signext(imm, 16), regs[rt])
            elif opcode == 0x2B:
                write_word(regs[rs] + _signext(imm, 16), regs[rt])

            steps += 1

    inspect_out = []
    for item in payload.get("inspect", []):
        addr = item["address"]
        length = item["length"]
        hexstr = "".join("%02x" % read_byte(addr + i) for i in range(length))
        inspect_out.append({"address": addr, "hex": hexstr})

    final_files = {}
    for name, data in files.items():
        final_files[name] = "".join("%02x" % b for b in data)

    return {
        "exit_code": exit_code,
        "registers": [r & MASK32 for r in regs],
        "hi": hi & MASK32,
        "lo": lo & MASK32,
        "steps": steps,
        "stdout_hex": "".join("%02x" % b for b in stdout_data),
        "stderr_hex": "".join("%02x" % b for b in stderr_data),
        "files": final_files,
        "inspect": inspect_out,
        "syscalls": syscalls,
    }
