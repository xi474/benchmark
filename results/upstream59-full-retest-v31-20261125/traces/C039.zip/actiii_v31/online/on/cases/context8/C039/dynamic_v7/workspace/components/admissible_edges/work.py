def compute(payload):
    """排除指向根的边，按 allowed 顺序返回节点下标对。"""
    nodes = payload["nodes"]
    index = {name: i for i, name in enumerate(nodes)}
    root = index[payload["root"]]
    result = []
    for parent, child in payload["allowed"]:
        if index[child] == root:
            continue
        result.append([index[parent], index[child]])
    return result
