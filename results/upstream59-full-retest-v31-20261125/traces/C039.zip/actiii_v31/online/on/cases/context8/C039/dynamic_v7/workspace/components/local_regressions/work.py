from itertools import combinations


def _solve(cov, parents, child):
    """Return regression coefficients of child on parents (unrounded)."""
    if not parents:
        return []
    n = len(parents)
    # Build C[P,P] and C[P,child]
    a = [[cov[p][q] for q in parents] for p in parents]
    b = [cov[p][child] for p in parents]
    # Gaussian elimination with partial pivoting
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-15:
            raise ValueError("singular parent covariance")
        a[col], a[pivot] = a[pivot], a[col]
        b[col], b[pivot] = b[pivot], b[col]
        for r in range(col + 1, n):
            f = a[r][col] / a[col][col]
            for c in range(col, n):
                a[r][c] -= f * a[col][c]
            b[r] -= f * b[col]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = b[i]
        for j in range(i + 1, n):
            s -= a[i][j] * x[j]
        x[i] = s / a[i][i]
    return x


def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，
    以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    covariance = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload.get("max_parents", len(nodes))

    index = {name: i for i, name in enumerate(nodes)}
    root_idx = index[root]

    # Allowed parent indices per child node.
    allowed_parents = [[] for _ in nodes]
    for p, c in allowed:
        pi, ci = index[p], index[c]
        allowed_parents[ci].append(pi)

    result = []
    for child in range(len(nodes)):
        table = {}
        if child == root_idx:
            parents_pool = []
        else:
            parents_pool = sorted(allowed_parents[child])
        # Empty parent set.
        table[""] = []
        for size in range(1, min(max_parents, len(parents_pool)) + 1):
            for combo in combinations(parents_pool, size):
                key = ",".join(str(p) for p in combo)
                table[key] = _solve(covariance, list(combo), child)
        result.append(table)
    return result
