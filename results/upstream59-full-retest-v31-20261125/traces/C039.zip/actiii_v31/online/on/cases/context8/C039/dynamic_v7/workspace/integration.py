from itertools import combinations
from collections import deque
import math


def _round9(x):
    return round(x, 9)


def _round6(x):
    return round(x, 6)


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    nodes = payload["nodes"]
    n = len(nodes)
    covariance = payload["covariance"]
    mean = payload["mean"]
    sample_size = payload["sample_size"]
    root = payload["root"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload.get("intervention")

    index = {name: i for i, name in enumerate(nodes)}
    root_idx = index[root]

    admissible = [tuple(e) for e in left]
    regressions = right

    def residual_var(child, parents):
        cyy = covariance[child][child]
        if not parents:
            return cyy
        m = len(parents)
        a = [[covariance[p][q] for q in parents] for p in parents]
        b = [covariance[p][child] for p in parents]
        for col in range(m):
            pivot = max(range(col, m), key=lambda r: abs(a[r][col]))
            if abs(a[pivot][col]) < 1e-15:
                raise ValueError("singular parent covariance")
            a[col], a[pivot] = a[pivot], a[col]
            b[col], b[pivot] = b[pivot], b[col]
            for r in range(col + 1, m):
                f = a[r][col] / a[col][col]
                for c2 in range(col, m):
                    a[r][c2] -= f * a[col][c2]
                b[r] -= f * b[col]
        beta = [0.0] * m
        for i in range(m - 1, -1, -1):
            s = b[i]
            for j in range(i + 1, m):
                s -= a[i][j] * beta[j]
            beta[i] = s / a[i][i]
        res = cyy
        for i in range(m):
            res -= b[i] * beta[i]
        return res

    def node_score(child, parents):
        rv = residual_var(child, parents)
        return sample_size * _round9(math.log(rv)) + len(parents) * _round9(math.log(sample_size))

    best = None

    for combo in combinations(admissible, edge_count):
        indeg = [0] * n
        for p, c in combo:
            indeg[c] += 1
        if indeg[root_idx] != 0:
            continue
        if any(d > max_parents for d in indeg):
            continue
        adj = [[] for _ in range(n)]
        for p, c in combo:
            adj[p].append(c)
        indeg2 = indeg[:]
        q = deque([i for i in range(n) if indeg2[i] == 0])
        seen = 0
        while q:
            u = q.popleft()
            seen += 1
            for v in adj[u]:
                indeg2[v] -= 1
                if indeg2[v] == 0:
                    q.append(v)
        if seen != n:
            continue
        parents_of = [[] for _ in range(n)]
        for p, c in combo:
            parents_of[c].append(p)
        total = 0.0
        for c in range(n):
            parents_of[c].sort()
            total += node_score(c, parents_of[c])
        total = _round9(total)
        edge_list = sorted(combo)
        if best is None or total < best[0] or (total == best[0] and edge_list < best[1]):
            best = (total, edge_list, combo)

    if best is None:
        return {"feasible": False}

    total_score, edge_list, combo = best
    parents_of = [[] for _ in range(n)]
    for p, c in combo:
        parents_of[c].append(p)
    for c in range(n):
        parents_of[c].sort()

    coefficients = []
    for p, c in sorted(combo):
        parents = parents_of[c]
        key = ",".join(str(x) for x in parents)
        betas = regressions[c][key]
        pos = parents.index(p)
        slope = betas[pos]
        coefficients.append([nodes[p], nodes[c], _round6(slope)])

    intervened_edges = []
    iv_node = None
    iv_value = None
    if intervention is not None:
        iv_node = index[intervention["node"]]
        iv_value = intervention["value"]
        for p, c in sorted(combo):
            if c == iv_node:
                intervened_edges.append([nodes[p], nodes[c]])

    adj = [[] for _ in range(n)]
    for p, c in combo:
        adj[p].append(c)
    indeg = [0] * n
    for p, c in combo:
        indeg[c] += 1
    q = deque([i for i in range(n) if indeg[i] == 0])
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)

    intercept = [0.0] * n
    for c in range(n):
        parents = parents_of[c]
        key = ",".join(str(x) for x in parents)
        betas = regressions[c][key]
        ic = mean[c]
        for i, p in enumerate(parents):
            ic -= betas[i] * mean[p]
        intercept[c] = ic

    result_mean = [0.0] * n
    for c in order:
        if intervention is not None and c == iv_node:
            result_mean[c] = iv_value
            continue
        parents = parents_of[c]
        key = ",".join(str(x) for x in parents)
        betas = regressions[c][key]
        val = intercept[c]
        for i, p in enumerate(parents):
            if intervention is not None and p == iv_node:
                val += betas[i] * iv_value
            else:
                val += betas[i] * result_mean[p]
        result_mean[c] = val

    return {
        "feasible": True,
        "edges": [[nodes[p], nodes[c]] for p, c in edge_list],
        "score": _round6(total_score),
        "coefficients": coefficients,
        "intervened_edges": intervened_edges,
        "mean": [_round6(x) for x in result_mean],
    }
