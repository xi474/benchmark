def compute(payload):
    """排除指向根的边，按 allowed 顺序返回节点下标对。"""
    nodes = payload["nodes"]
    index = {name: i for i, name in enumerate(nodes)}
    root = payload["root"]
    root_index = index[root]
    result = []
    for parent, child in payload["allowed"]:
        if index[child] == root_index:
            continue
        result.append([index[parent], index[child]])
    return result
