def _solve(a, b):
    """Solve a * x = b for a square matrix a and column vector b via Gaussian elimination."""
    n = len(a)
    m = [row[:] + [b[i]] for i, row in enumerate(a)]
    for col in range(n):
        pivot = col
        for r in range(col + 1, n):
            if abs(m[r][col]) > abs(m[pivot][col]):
                pivot = r
        m[col], m[pivot] = m[pivot], m[col]
        pv = m[col][col]
        for r in range(col + 1, n):
            factor = m[r][col] / pv
            for c in range(col, n + 1):
                m[r][c] -= factor * m[col][c]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = m[i][n]
        for j in range(i + 1, n):
            s -= m[i][j] * x[j]
        x[i] = s / m[i][i]
    return x


def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    covariance = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload["max_parents"]

    index = {name: i for i, name in enumerate(nodes)}
    n = len(nodes)

    # Parents allowed for each node: edges in allowed whose child is the node.
    parents_of = [[] for _ in range(n)]
    for p, c in allowed:
        parents_of[index[c]].append(index[p])

    result = []
    for node in range(n):
        table = {}
        parents = sorted(parents_of[node])
        m = len(parents)
        # Enumerate all subsets of parents with size <= max_parents.
        for mask in range(1 << m):
            subset = [parents[i] for i in range(m) if mask & (1 << i)]
            if len(subset) > max_parents:
                continue
            key = ",".join(str(p) for p in subset)
            if not subset:
                table[key] = []
                continue
            # Build CPP and CyP.
            k = len(subset)
            cpp = [[covariance[a][b] for b in subset] for a in subset]
            cyp = [covariance[node][b] for b in subset]
            coeffs = _solve(cpp, cyp)
            table[key] = coeffs
        result.append(table)
    return result
