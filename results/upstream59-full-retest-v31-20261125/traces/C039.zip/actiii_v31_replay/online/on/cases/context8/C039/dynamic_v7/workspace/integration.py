import math
from itertools import combinations


def _solve(a, b):
    n = len(a)
    m = [row[:] + [b[i]] for i, row in enumerate(a)]
    for col in range(n):
        pivot = col
        for r in range(col + 1, n):
            if abs(m[r][col]) > abs(m[pivot][col]):
                pivot = r
        m[col], m[pivot] = m[pivot], m[col]
        pv = m[col][col]
        for r in range(col + 1, n):
            factor = m[r][col] / pv
            for c in range(col, n + 1):
                m[r][c] -= factor * m[col][c]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = m[i][n]
        for j in range(i + 1, n):
            s -= m[i][j] * x[j]
        x[i] = s / m[i][i]
    return x


def _residual_variance(cov, node, parents):
    if not parents:
        return cov[node][node]
    k = len(parents)
    cpp = [[cov[a][b] for b in parents] for a in parents]
    cyp = [cov[node][b] for b in parents]
    coeffs = _solve(cpp, cyp)
    cyy = cov[node][node]
    resid = cyy - sum(cyp[i] * coeffs[i] for i in range(k))
    return resid, coeffs


def _topological_order(n, edges):
    indeg = [0] * n
    adj = [[] for _ in range(n)]
    for p, c in edges:
        adj[p].append(c)
        indeg[c] += 1
    order = []
    stack = [i for i in range(n) if indeg[i] == 0]
    while stack:
        u = stack.pop()
        order.append(u)
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                stack.append(v)
    return order if len(order) == n else None


def combine(payload, left, right):
    nodes = payload["nodes"]
    n = len(nodes)
    index = {name: i for i, name in enumerate(nodes)}
    cov = payload["covariance"]
    mean = payload["mean"]
    sample_size = payload["sample_size"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    root = payload["root"]
    root_index = index[root]

    admissible = [tuple(e) for e in left]
    regressions = right

    ln_n = math.log(sample_size)

    best = None
    best_key = None
    for combo in combinations(admissible, edge_count):
        if any(c == root_index for p, c in combo):
            continue
        indeg = [0] * n
        ok = True
        for p, c in combo:
            indeg[c] += 1
            if indeg[c] > max_parents:
                ok = False
                break
        if not ok:
            continue
        if _topological_order(n, combo) is None:
            continue

        parents_of = [[] for _ in range(n)]
        for p, c in combo:
            parents_of[c].append(p)
        total = 0.0
        for node in range(n):
            parents = sorted(parents_of[node])
            key = ",".join(str(p) for p in parents)
            table = regressions[node]
            if key in table:
                coeffs = table[key]
            else:
                _, coeffs = _residual_variance(cov, node, parents)
            if parents:
                k = len(parents)
                cyp = [cov[node][b] for b in parents]
                cyy = cov[node][node]
                resid = cyy - sum(cyp[i] * coeffs[i] for i in range(k))
            else:
                resid = cov[node][node]
            total += sample_size * math.log(resid) + len(parents) * ln_n

        score = round(total, 9)
        key = sorted(combo)
        if best is None or score < best[0] or (score == best[0] and key < best_key):
            best = (score, combo, parents_of)
            best_key = key

    if best is None:
        return {"feasible": False}

    score, combo, parents_of = best
    edges = sorted(combo)

    coefficients = []
    for p, c in edges:
        parents = sorted(parents_of[c])
        key = ",".join(str(x) for x in parents)
        coeffs = regressions[c][key]
        idx = parents.index(p)
        coefficients.append([nodes[p], nodes[c], round(coeffs[idx], 6)])

    intervention = payload.get("intervention")
    intervened_edges = []
    if intervention is not None:
        iv_node = index[intervention["node"]]
        iv_value = intervention["value"]
        intervened_edges = [[nodes[p], nodes[c]] for p, c in edges if p == iv_node]
        order = _topological_order(n, edges)
        result_mean = [0.0] * n
        for node in order:
            if node == iv_node:
                result_mean[node] = iv_value
                continue
            parents = sorted(parents_of[node])
            key = ",".join(str(x) for x in parents)
            coeffs = regressions[node][key]
            intercept = mean[node]
            for i, p in enumerate(parents):
                intercept -= coeffs[i] * mean[p]
            val = intercept
            for i, p in enumerate(parents):
                val += coeffs[i] * result_mean[p]
            result_mean[node] = val
        result_mean = [round(x, 6) for x in result_mean]
    else:
        result_mean = [round(x, 6) for x in mean]

    return {
        "feasible": True,
        "edges": [[nodes[p], nodes[c]] for p, c in edges],
        "score": round(score, 6),
        "coefficients": coefficients,
        "intervened_edges": intervened_edges,
        "mean": result_mean,
    }
