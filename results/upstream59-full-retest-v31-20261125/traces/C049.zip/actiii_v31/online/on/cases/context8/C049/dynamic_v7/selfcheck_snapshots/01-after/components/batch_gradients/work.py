import math


def compute(payload):
    """按实际 stage 保留每个微批激活并反传；返回整题格式的 loss 和各层 gradients，采用微批等权和 float64。"""
    layers = payload["layers"]
    microbatches = payload["microbatches"]

    L = len(layers)
    weights = [layer["weight"] for layer in layers]
    biases = [layer["bias"] for layer in layers]

    grad_w = [[[0.0] * len(w[0]) for _ in range(len(w))] for w in weights]
    grad_b = [[0.0] * len(b) for b in biases]

    total_loss = 0.0
    num_micro = len(microbatches)

    for mb in microbatches:
        x = mb["inputs"]
        targets = mb["targets"]
        batch = len(x)

        # Forward pass, caching pre-activations and activations.
        acts = [x]
        preacts = []
        for i in range(L):
            # z is batch x out
            z = [ [sum(weights[i][o][j] * acts[-1][s][j] for j in range(len(weights[i][0]))) + biases[i][o]
                   for o in range(len(weights[i]))] for s in range(batch) ]
            preacts.append(z)
            if i < L - 1:
                acts.append([[math.tanh(v) for v in row] for row in z])
            else:
                acts.append(z)  # logits

        # Softmax cross-entropy loss (mean over batch).
        logits = acts[-1]
        probs = []
        for s in range(batch):
            row = logits[s]
            mx = max(row)
            exps = [math.exp(v - mx) for v in row]
            total = sum(exps)
            probs.append([e / total for e in exps])
        loss = -sum(math.log(probs[s][targets[s]]) for s in range(batch)) / batch
        total_loss += loss

        # Backward pass.
        dlogits = [row[:] for row in probs]
        for s in range(batch):
            dlogits[s][targets[s]] -= 1.0
        for s in range(batch):
            for o in range(len(dlogits[s])):
                dlogits[s][o] /= batch

        dact = dlogits
        for i in range(L - 1, -1, -1):
            a_prev = acts[i]
            # grad_w[i] += dact^T @ a_prev  (out x in)
            for o in range(len(weights[i])):
                for j in range(len(weights[i][0])):
                    grad_w[i][o][j] += sum(dact[s][o] * a_prev[s][j] for s in range(batch))
            # grad_b[i] += sum over batch of dact
            for o in range(len(biases[i])):
                grad_b[i][o] += sum(dact[s][o] for s in range(batch))
            if i > 0:
                # dz = dact @ weights[i]  (batch x in)
                dz = [[sum(dact[s][o] * weights[i][o][j] for o in range(len(weights[i])))
                       for j in range(len(weights[i][0]))] for s in range(batch)]
                # multiply by tanh'(preacts[i-1])
                prev = preacts[i - 1]
                dact = [[dz[s][j] * (1.0 - math.tanh(prev[s][j]) ** 2)
                         for j in range(len(dz[s]))] for s in range(batch)]

    loss = total_loss / num_micro

    gradients = [
        {"weight": grad_w[i], "bias": grad_b[i]}
        for i in range(L)
    ]

    return {"loss": loss, "gradients": gradients}
