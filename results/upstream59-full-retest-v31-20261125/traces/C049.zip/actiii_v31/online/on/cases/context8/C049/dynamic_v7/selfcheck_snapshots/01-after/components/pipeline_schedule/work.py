import math


def compute(payload):
    """输出 partitions 和 AFAB 的 events；层边界为 floor(n*r/world)，保留正序前向、逆序反向及跨 stage 发送。"""
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]

    n = len(layers)
    num_microbatches = len(microbatches)

    partitions = []
    for r in range(world_size):
        start = math.floor(n * r / world_size)
        stop = math.floor(n * (r + 1) / world_size)
        partitions.append({"stage": r, "start": start, "stop": stop})

    events = []

    # Forward: each microbatch in order, each stage in order.
    for mb in range(num_microbatches):
        for stage in range(world_size):
            events.append({"kind": "forward", "microbatch": mb, "stage": stage})
            if stage < world_size - 1:
                events.append({
                    "kind": "send_activation",
                    "source": stage,
                    "target": stage + 1,
                })

    # Backward: each microbatch in reverse order, each stage in reverse order.
    for mb in range(num_microbatches - 1, -1, -1):
        for stage in range(world_size - 1, -1, -1):
            events.append({"kind": "backward", "microbatch": mb, "stage": stage})
            if stage > 0:
                events.append({
                    "kind": "send_gradient",
                    "source": stage,
                    "target": stage - 1,
                })

    return {"partitions": partitions, "events": events}
