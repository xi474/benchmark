def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    result = {}
    result["loss"] = left["loss"]
    result["gradients"] = left["gradients"]
    result["partitions"] = right["partitions"]
    result["events"] = right["events"]
    return result
