import unittest

# Injected by the SDK runner; present here only for local import fallback.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None


class TestTransformBehavior(unittest.TestCase):
    def test_world_size_2_partitions_and_events(self):
        # world_size=2 with 4 layers: partitions [0,2) and [2,4).
        payload = {
            "world_size": 2,
            "layers": [
                {"weight": [[0.1, 0.2], [0.3, 0.4]], "bias": [0.0, 0.0]},
                {"weight": [[0.5, 0.6], [0.7, 0.8]], "bias": [0.0, 0.0]},
                {"weight": [[0.9, 1.0], [1.1, 1.2]], "bias": [0.0, 0.0]},
                {"weight": [[1.3, 1.4], [1.5, 1.6]], "bias": [0.0, 0.0]},
            ],
            "microbatches": [
                {"inputs": [[1.0, 2.0]], "targets": [0]},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(len(result["partitions"]), 2)
        self.assertEqual(result["partitions"][0], {"stage": 0, "start": 0, "stop": 2})
        self.assertEqual(result["partitions"][1], {"stage": 1, "start": 2, "stop": 4})
        # Forward: microbatch 0 stage 0, send_activation 0->1, stage 1.
        kinds = [(e["kind"], e.get("stage"), e.get("source"), e.get("target")) for e in result["events"]]
        self.assertIn(("forward", 0, None, None), kinds)
        self.assertIn(("send_activation", None, 0, 1), kinds)
        self.assertIn(("forward", 1, None, None), kinds)
        # Backward: stage 1 then send_gradient 1->0 then stage 0.
        self.assertIn(("backward", 1, None, None), kinds)
        self.assertIn(("send_gradient", None, 1, 0), kinds)
        self.assertIn(("backward", 0, None, None), kinds)

    def test_two_microbatches_unequal_batch_equal_weight(self):
        # Two microbatches with different batch sizes; loss must be the plain
        # average of the two per-microbatch mean cross-entropies.
        payload = {
            "world_size": 1,
            "layers": [
                {"weight": [[0.5, -0.5], [0.25, 0.75]], "bias": [0.1, -0.1]},
                {"weight": [[0.4, -0.4], [-0.3, 0.6]], "bias": [0.05, -0.05]},
            ],
            "microbatches": [
                {"inputs": [[1.0, -1.0], [0.5, 0.5]], "targets": [0, 1]},
                {"inputs": [[2.0, 0.0]], "targets": [1]},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result["loss"], float)
        self.assertTrue(result["loss"] >= 0.0)
        self.assertEqual(len(result["gradients"]), 2)
        for g in result["gradients"]:
            self.assertEqual(len(g["weight"]), 2)
            self.assertEqual(len(g["bias"]), 2)

    def test_transform_does_not_mutate_input(self):
        import copy
        payload = {
            "world_size": 1,
            "layers": [
                {"weight": [[0.5, -0.5], [0.25, 0.75]], "bias": [0.1, -0.1]},
                {"weight": [[0.4, -0.4], [-0.3, 0.6]], "bias": [0.05, -0.05]},
            ],
            "microbatches": [
                {"inputs": [[1.0, -1.0]], "targets": [0]},
            ],
        }
        before = copy.deepcopy(payload)
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, before)


if __name__ == "__main__":
    unittest.main()
