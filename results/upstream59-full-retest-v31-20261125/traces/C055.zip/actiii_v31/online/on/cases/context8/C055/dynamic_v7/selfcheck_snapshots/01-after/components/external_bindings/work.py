def compute(payload):
    """解析不受信任文档的覆盖和文档内锚点。每个有效键输出 [原源序号,声明位置,[值位置,文本,是否密文,来源是否可信]]；位置为 [源名,行,列]。"""
    sources = payload.get("sources", [])
    result = {}
    for src_index, source in enumerate(sources):
        if source.get("trusted", False):
            continue
        name = source["name"]
        yaml = source["yaml"]
        anchors = {}
        lines = yaml.split("\n")
        for line_no, line in enumerate(lines, start=1):
            if line == "":
                continue
            if line == "---":
                anchors = {}
                continue
            colon = line.find(":")
            if colon == -1:
                continue
            key = line[:colon]
            value_text = line[colon + 2:]
            value_col = colon + 3
            is_vault = False
            resolved_text = value_text
            resolved_pos = [name, line_no, value_col]
            if value_text.startswith("&"):
                space = value_text.find(" ")
                anchor_name = value_text[1:space]
                rest = value_text[space + 1:]
                anchors[anchor_name] = {
                    "text": rest,
                    "pos": [name, line_no, value_col],
                    "is_vault": rest.startswith("!vault"),
                }
                resolved_text = rest
            elif value_text.startswith("*"):
                anchor_name = value_text[1:]
                if anchor_name in anchors:
                    a = anchors[anchor_name]
                    resolved_text = a["text"]
                    resolved_pos = a["pos"]
                    is_vault = a["is_vault"]
                else:
                    resolved_text = value_text
            else:
                is_vault = value_text.startswith("!vault")
            result[key] = [
                src_index,
                [name, line_no, 1],
                [resolved_pos, resolved_text, is_vault, False],
            ]
    return result
