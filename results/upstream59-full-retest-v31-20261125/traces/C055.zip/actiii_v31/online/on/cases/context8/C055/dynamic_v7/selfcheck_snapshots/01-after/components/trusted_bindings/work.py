def compute(payload):
    """解析受信任文档的覆盖和文档内锚点。每个有效键输出 [原源序号,声明位置,[值位置,文本,是否密文,来源是否可信]]；位置为 [源名,行,列]。"""
    sources = payload["sources"]
    result = {}
    for src_idx, src in enumerate(sources):
        if not src["trusted"]:
            continue
        name = src["name"]
        anchors = {}
        for line_no, line in enumerate(src["yaml"].split("\n"), start=1):
            if line == "":
                continue
            if line == "---":
                anchors = {}
                continue
            idx = line.find(": ")
            if idx == -1:
                continue
            key = line[:idx]
            rest = line[idx + 2:]
            value_col = idx + 3
            decl_pos = [name, line_no, 1]
            value_pos = [name, line_no, value_col]

            anchor_name = None
            if rest.startswith("&"):
                sp = rest.find(" ")
                anchor_name = rest[1:sp]
                rest = rest[sp + 1:]

            if rest.startswith("*"):
                ref = rest[1:]
                vpos, text, is_vault = anchors[ref]
                result[key] = [src_idx, decl_pos, [vpos, text, is_vault, src["trusted"]]]
                continue

            if rest.startswith("!vault"):
                text = rest[len("!vault "):]
                is_vault = True
            else:
                text = rest
                is_vault = False

            if anchor_name is not None:
                anchors[anchor_name] = (value_pos, text, is_vault)
            result[key] = [src_idx, decl_pos, [value_pos, text, is_vault, src["trusted"]]]
    return result
