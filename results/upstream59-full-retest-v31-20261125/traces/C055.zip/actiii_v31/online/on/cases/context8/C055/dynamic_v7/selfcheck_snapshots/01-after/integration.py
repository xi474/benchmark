import json


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tags = payload.get("tags", True)
    keys = payload.get("keys", {})

    # Merge: later source index wins. left = trusted docs, right = untrusted docs.
    # Each value: [src_index, decl_pos, [value_pos, text, is_vault, src_trusted]]
    merged = {}
    for entry in (left, right):
        for key, val in entry.items():
            merged[key] = val

    # Determine final view: key -> (decl_pos, value_pos, text, is_vault, trusted)
    final = {}
    for key, val in merged.items():
        src_idx, decl_pos, v = val
        value_pos, text, is_vault, src_trusted = v
        final[key] = {
            "decl_pos": decl_pos,
            "value_pos": value_pos,
            "text": text,
            "is_vault": is_vault,
            "trusted": src_trusted,
        }

    # Resolve vaults
    if not tags:
        for key, info in final.items():
            if info["is_vault"]:
                if info["text"] not in keys:
                    return {"status": "sealed"}
                info["text"] = keys[info["text"]]
                info["is_vault"] = False
                info["trusted"] = True

    # Render recursively
    def render(key, seen):
        if key in seen:
            return ""
        info = final[key]
        if info["is_vault"]:
            if tags:
                return "[sealed]"
            # already unsealed above
            return info["text"]
        if not info["trusted"]:
            return info["text"]
        text = info["text"]
        seen = seen | {key}
        out = []
        i = 0
        while i < len(text):
            j = text.find("${", i)
            if j == -1:
                out.append(text[i:])
                break
            out.append(text[i:j])
            k = text.find("}", j)
            ref = text[j + 2:k]
            out.append(render(ref, seen))
            i = k + 1
        return "".join(out)

    entries = []
    for key in sorted(final):
        info = final[key]
        trusted = info["trusted"]
        if info["is_vault"] and tags:
            trusted = False
            r = "[sealed]"
        else:
            r = render(key, frozenset())
        entries.append([key, info["decl_pos"], info["value_pos"], trusted, r])

    # Build dump
    lines = []
    for key in sorted(final):
        info = final[key]
        prefix = key + ": "
        if info["is_vault"] and tags:
            prefix += "!vault "
        lines.append(prefix + json.dumps(info["text"], ensure_ascii=False))

    dump = "\n".join(lines) + "\n"

    return {"status": "ok", "entries": entries, "dump": dump}
