import unittest


class TestTransform(unittest.TestCase):
    def test_public_fixture_roundtrip(self):
        # Public example: tags=true, no keys. Verify final entries and dump.
        payload = {
            "sources": [
                {"name": "base", "trusted": True,
                 "yaml": "x: &base first\ny: *base\nz: see-${x}\n"},
                {"name": "override", "trusted": False,
                 "yaml": "x: plain-${y}\n"},
            ],
            "tags": True,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(
            result["entries"],
            [
                ["x", ["override", 1, 1], ["override", 1, 4], False, "plain-${y}"],
                ["y", ["base", 2, 1], ["base", 1, 4], True, "first"],
                ["z", ["base", 3, 1], ["base", 3, 4], True, "see-plain-${y}"],
            ],
        )
        self.assertEqual(
            result["dump"],
            'x: "plain-${y}"\ny: "first"\nz: "see-${x}"\n',
        )

    def test_vault_sealed_when_missing_key(self):
        # tags=false with a vault that has no key -> {"status":"sealed"}.
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: !vault v1\n"},
            ],
            "tags": False,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, {"status": "sealed"})

    def test_vault_unsealed_with_key(self):
        # tags=false with a matching key -> unsealed plaintext, trusted=true.
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: !vault v1\n"},
            ],
            "tags": False,
            "keys": {"v1": "secret"},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["entries"][0][3], True)
        self.assertEqual(result["entries"][0][4], "secret")
        self.assertEqual(result["dump"], 'a: "secret"\n')

    def test_vault_sealed_render_when_tags_true(self):
        # tags=true keeps the ciphertext and renders "[sealed]".
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: !vault v1\n"},
            ],
            "tags": True,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["entries"][0][3], False)
        self.assertEqual(result["entries"][0][4], "[sealed]")
        self.assertEqual(result["dump"], 'a: !vault "v1"\n')


if __name__ == "__main__":
    unittest.main()
