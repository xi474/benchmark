def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tasks = payload["tasks"]
    pools = payload["pools"]
    feeds = payload["feeds"]
    initial = payload["initial"]

    by_id = {t["id"]: t for t in tasks}
    waves = left  # list of batches, each a list of task ids ascending

    # Stateful selectors: per-pool round-robin index, per (host, stream) round-robin index.
    pool_idx = {p: 0 for p in pools}
    feed_idx = {}
    for host, streams in feeds.items():
        for stream in streams:
            feed_idx[(host, stream)] = 0

    facts = dict(initial)
    committed = {}  # task id -> delta (committed after success)
    pool_reads = {p: 0 for p in pools}
    feed_reads = {host: {stream: 0 for stream in streams} for host, streams in feeds.items()}

    result_tasks = {}

    for wave in waves:
        # All tasks in this wave are released simultaneously at round start.
        # They share the same fact snapshot (base) and parent deltas.
        # Consume selectors in task-id lexicographic order.
        wave_tasks = sorted(wave)
        # base for each host at round start
        base_snapshot = dict(facts)
        # parent = sum of committed deltas of direct parents
        parent_map = {}
        for tid in wave_tasks:
            t = by_id[tid]
            parent = sum(committed.get(p, 0) for p in t.get("needs", []))
            parent_map[tid] = parent

        # Assign host and batch for each task (consume selectors in id order).
        assignments = {}
        for tid in wave_tasks:
            t = by_id[tid]
            pool = t["pool"]
            hosts = pools[pool]
            host = hosts[pool_idx[pool]]
            pool_idx[pool] = (pool_idx[pool] + 1) % len(hosts)
            pool_reads[pool] += 1

            stream = t["stream"]
            batches = feeds[host][stream]
            items = batches[feed_idx[(host, stream)]]
            feed_idx[(host, stream)] = (feed_idx[(host, stream)] + 1) % len(batches)
            feed_reads[host][stream] += 1

            assignments[tid] = (host, items)

        # Compute deltas using the round-start snapshot.
        deltas = {}
        for tid in wave_tasks:
            t = by_id[tid]
            host, items = assignments[tid]
            base = base_snapshot[host]
            parent = parent_map[tid]
            delta = sum((base + item) * (1 + parent) for item in items)
            deltas[tid] = delta
            result_tasks[tid] = {
                "host": host,
                "items": list(items),
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": t["attempts"],
            }

        # After all successful commits in this round, apply deltas to facts.
        for tid in wave_tasks:
            host = assignments[tid][0]
            facts[host] += deltas[tid]
            committed[tid] = deltas[tid]

    return {
        "tasks": result_tasks,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads,
    }
