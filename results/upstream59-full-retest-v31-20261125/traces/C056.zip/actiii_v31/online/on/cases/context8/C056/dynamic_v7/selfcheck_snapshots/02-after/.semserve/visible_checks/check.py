import json
import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that unknown fields or non-finite values must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that a non-object payload must raise ValueError.",
            },
        },
    },
]


def _load_public():
    with open("public_input.json", encoding="utf-8") as f:
        return json.load(f)


class TestTransformBehavior(unittest.TestCase):
    def test_output_contract_shape(self):
        # Output contract: raw container type and required fields.
        payload = _load_public()
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        for key in ("tasks", "facts", "pool_reads", "feed_reads"):
            self.assertIn(key, result)
        self.assertIsInstance(result["tasks"], dict)
        self.assertIsInstance(result["facts"], dict)
        self.assertIsInstance(result["pool_reads"], dict)
        self.assertIsInstance(result["feed_reads"], dict)

    def test_input_not_mutated(self):
        # "保持输入值完整": transform must not mutate the input payload.
        payload = _load_public()
        snapshot = json.dumps(payload, sort_keys=True)
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(json.dumps(payload, sort_keys=True), snapshot)

    def test_single_task_no_deps(self):
        # A minimal valid input with one task and no dependencies.
        payload = {
            "initial": {"h": 5},
            "pools": {"p": ["h"]},
            "feeds": {"h": {"s": [[10]]}},
            "tasks": [{"id": "t", "needs": [], "pool": "p", "stream": "s", "attempts": 1}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["facts"], {"h": 20})
        self.assertEqual(result["pool_reads"], {"p": 1})
        self.assertEqual(result["feed_reads"], {"h": {"s": 1}})
        self.assertEqual(result["tasks"]["t"]["delta"], 15)
        self.assertEqual(result["tasks"]["t"]["base"], 5)
        self.assertEqual(result["tasks"]["t"]["parent"], 0)

    def test_parent_delta_propagates(self):
        # A child's parent is the committed delta of its direct parent.
        payload = {
            "initial": {"h": 0},
            "pools": {"p": ["h"]},
            "feeds": {"h": {"s": [[2], [3]]}},
            "tasks": [
                {"id": "a", "needs": [], "pool": "p", "stream": "s", "attempts": 1},
                {"id": "b", "needs": ["a"], "pool": "p", "stream": "s", "attempts": 1},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # a: base 0, item 2 -> delta 2
        self.assertEqual(result["tasks"]["a"]["delta"], 2)
        # b: base 2 (after a commits), item 3, parent 2 -> (2+3)*(1+2)=15
        self.assertEqual(result["tasks"]["b"]["delta"], 15)
        self.assertEqual(result["tasks"]["b"]["parent"], 2)
        self.assertEqual(result["facts"], {"h": 17})


if __name__ == "__main__":
    unittest.main()
