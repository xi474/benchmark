STAGES = ["pre", "roles", "includes", "tasks", "post"]
BRANCHES = ["tasks", "rescue", "always"]


def compute(payload):
    """输出 [处理器声明顺序映射, 叶节点到通知清单的映射]。

    处理器声明顺序映射: {handler_name: declaration_index}。
    叶节点到通知清单的映射: {tree_path: [notify_names]}，通知名去重并按声明顺序排列。
    叶节点按树位置编码（各级整数以 / 分隔），含 rescue、always 分支。
    """
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})
    handler_order = {name: i for i, name in enumerate(handlers)}
    leaf_notify = {}

    def process_item(item, path):
        if isinstance(item, dict) and "block" in item:
            block = item["block"]
            for branch_idx, branch_name in enumerate(BRANCHES):
                branch_items = block.get(branch_name, [])
                for j, sub in enumerate(branch_items):
                    process_item(sub, "%s/%d/%d" % (path, branch_idx, j))
        else:
            notify = item.get("notify", []) if isinstance(item, dict) else []
            if notify:
                ordered = sorted(set(notify), key=lambda n: handler_order.get(n, len(handlers)))
                leaf_notify[path] = ordered

    for stage_idx, stage_name in enumerate(STAGES):
        items = program.get(stage_name, [])
        for item_idx, item in enumerate(items):
            process_item(item, "%d/%d" % (stage_idx, item_idx))

    return [handler_order, leaf_notify]
