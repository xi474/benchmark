STAGES = ["pre", "roles", "includes", "tasks", "post"]


def _only_ok(node, host):
    only = node.get("only")
    return only is None or host in only


def _node_fails(node, host):
    """Whether a node fails when it runs, assuming its parent is executable."""
    if isinstance(node, dict) and "block" in node:
        if not _only_ok(node, host):
            return False
        return _block_fails(node["block"], host)
    if not _only_ok(node, host):
        return False
    return host in node.get("fail_hosts", [])


def _block_fails(block, host):
    tasks = block.get("tasks", [])
    rescue = block.get("rescue", [])
    always = block.get("always", [])
    normal_fails = any(_node_fails(c, host) for c in tasks)
    rescued = len(rescue) > 0 and not any(_node_fails(c, host) for c in rescue)
    always_fails = any(_node_fails(c, host) for c in always)
    return (normal_fails and not rescued) or always_fails


def _walk(node, path, host, parent_exec, table):
    if isinstance(node, dict) and "block" in node:
        block = node["block"]
        exec_ = parent_exec and _only_ok(node, host)
        table[path] = [exec_, exec_ and _block_fails(block, host)]
        for branch, key in ((0, "tasks"), (1, "rescue"), (2, "always")):
            for j, child in enumerate(block.get(key, [])):
                _walk(child, "%s/%d/%d" % (path, branch, j), host, exec_, table)
    else:
        exec_ = parent_exec and _only_ok(node, host)
        table[path] = [exec_, exec_ and (host in node.get("fail_hosts", []))]


def compute(payload):
    """每个 host 对应一张节点表，按树位置（各级整数以 / 分隔）记录 [可执行,会失败]；包含块节点。"""
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})
    result = {}
    for host in hosts:
        table = {}
        for si, stage in enumerate(STAGES):
            for i, item in enumerate(program.get(stage, [])):
                _walk(item, "%d/%d" % (si, i), host, True, table)
        result[host] = table
    return result
