STAGES = ["pre", "roles", "includes", "tasks", "post"]


def _only_ok(node, host):
    only = node.get("only")
    return only is None or host in only


def _node_fails(node, host):
    """Whether a node fails when it runs, assuming its parent is executable."""
    if isinstance(node, dict) and "block" in node:
        if not _only_ok(node, host):
            return False
        return _block_fails(node["block"], host)
    if not _only_ok(node, host):
        return False
    return host in node.get("fail_hosts", [])


def _block_fails(block, host):
    tasks = block.get("tasks", [])
    rescue = block.get("rescue", [])
    always = block.get("always", [])
    normal_fails = any(_node_fails(c, host) for c in tasks)
    rescued = len(rescue) > 0 and not any(_node_fails(c, host) for c in rescue)
    always_fails = any(_node_fails(c, host) for c in always)
    return (normal_fails and not rescued) or always_fails


def _walk(node, path, host, parent_exec, table):
    if isinstance(node, dict) and "block" in node:
        block = node["block"]
        exec_ = parent_exec and _only_ok(node, host)
        table[path] = [exec_, exec_ and _block_fails(block, host)]
        for branch, key in ((0, "tasks"), (1, "rescue"), (2, "always")):
            for j, child in enumerate(block.get(key, [])):
                _walk(child, "%s/%d/%d" % (path, branch, j), host, exec_, table)
    else:
        exec_ = parent_exec and _only_ok(node, host)
        table[path] = [exec_, exec_ and (host in node.get("fail_hosts", []))]


def _host_table(host, program):
    table = {}
    for si, stage in enumerate(STAGES):
        for i, item in enumerate(program.get(stage, [])):
            _walk(item, "%d/%d" % (si, i), host, True, table)
    return table


def _collect(node, path, out):
    """Collect program nodes in canonical pre-order, including block nodes."""
    if isinstance(node, dict) and "block" in node:
        out.append(("block", path, node))
        block = node["block"]
        for branch, key in ((0, "tasks"), (1, "rescue"), (2, "always")):
            for j, child in enumerate(block.get(key, [])):
                _collect(child, "%s/%d/%d" % (path, branch, j), out)
    else:
        out.append(("task", path, node))


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    hosts = payload.get("hosts", [])
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    host_tables = {host: _host_table(host, program) for host in hosts}

    def path_key(path):
        parts = path.split("/")
        if parts[-1] == "flush":
            parts = parts[:-1]
        return tuple(int(x) for x in parts)

    # Per-host canonical node sequence: program nodes then a flush marker per stage.
    host_seq = {}
    for host in hosts:
        seq = []
        for si, stage in enumerate(STAGES):
            for i, item in enumerate(program.get(stage, [])):
                _collect(item, "%d/%d" % (si, i), seq)
            seq.append(("flush", "%d/flush" % si, None))
        host_seq[host] = seq

    host_state = {}
    for host in hosts:
        host_state[host] = {
            "cursor": 0,
            "failed": False,
            "pending_notify": [],
            "stage_index": -1,
        }

    batches = []

    while True:
        candidates = []
        for host in hosts:
            st = host_state[host]
            if st["failed"] or st["cursor"] >= len(host_seq[host]):
                continue
            path, kind, node = host_seq[host][st["cursor"]]
            candidates.append((path_key(path), host, kind, node, path))
        if not candidates:
            break
        candidates.sort(key=lambda x: (x[0], hosts.index(x[1])))
        min_key = candidates[0][0]
        advancing = [c for c in candidates if c[0] == min_key]
        advancing.sort(key=lambda x: hosts.index(x[1]))

        for _, host, kind, node, path in advancing:
            st = host_state[host]
            st["cursor"] += 1
            stage_idx = int(path.split("/")[0]) if kind != "flush" else int(path.split("/")[0])
            if st["stage_index"] != stage_idx:
                st["stage_index"] = stage_idx
                st["pending_notify"] = []

            if kind == "flush":
                if st["pending_notify"]:
                    ordered = [h for h in handlers if h in st["pending_notify"]]
                    batches.append({
                        "host": host,
                        "task": "flush",
                        "kind": "flush",
                        "status": "ok",
                        "handlers": ordered,
                    })
                    for h in ordered:
                        batches.append({
                            "host": host,
                            "task": h,
                            "kind": "handler",
                            "status": "ok",
                        })
                    st["pending_notify"] = []
                continue

            exec_ = host_tables[host].get(path, [False, False])[0]
            fails = host_tables[host].get(path, [False, False])[1]
            if not exec_:
                continue
            if kind == "task":
                if fails:
                    batches.append({
                        "host": host,
                        "task": node.get("id"),
                        "kind": "task",
                        "status": "failed",
                    })
                    st["failed"] = True
                else:
                    batches.append({
                        "host": host,
                        "task": node.get("id"),
                        "kind": "task",
                        "status": "ok",
                    })
                    for n in node.get("notify", []):
                        if n not in st["pending_notify"]:
                            st["pending_notify"].append(n)
            # block nodes are structural; no batch entry.

    final = {host: ("failed" if host_state[host]["failed"] else "ok") for host in hosts}
    return {"batches": batches, "final": final}
