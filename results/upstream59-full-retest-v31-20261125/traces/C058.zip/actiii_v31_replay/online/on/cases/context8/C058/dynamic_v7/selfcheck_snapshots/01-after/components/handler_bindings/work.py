STAGES = ["pre", "roles", "includes", "tasks", "post"]


def compute(payload):
    """输出 [处理器声明顺序映射,叶节点到通知清单的映射]。

    叶节点按树位置编码（各级整数以 / 分隔）；通知名去重并按声明顺序排列，
    含 rescue、always。
    """
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    handler_order = {name: i for i, name in enumerate(handlers)}

    leaf_to_notify = {}

    def add_leaf(path, task):
        notify = task.get("notify", [])
        if not notify:
            return
        seen = set()
        ordered = []
        for name in notify:
            if name not in seen:
                seen.add(name)
                ordered.append(name)
        ordered.sort(key=lambda n: handler_order.get(n, len(handlers)))
        leaf_to_notify[path] = ordered

    for si, stage in enumerate(STAGES):
        items = program.get(stage, [])
        if not isinstance(items, list):
            items = []
        for ii, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            if "block" in item:
                block = item.get("block") or {}
                for branch, key in ((0, "tasks"), (1, "rescue"), (2, "always")):
                    branch_items = block.get(key, [])
                    if not isinstance(branch_items, list):
                        branch_items = []
                    for bi, task in enumerate(branch_items):
                        if isinstance(task, dict):
                            add_leaf(f"{si}/{ii}/{branch}/{bi}", task)
            else:
                add_leaf(f"{si}/{ii}", item)

    return [handler_order, leaf_to_notify]
