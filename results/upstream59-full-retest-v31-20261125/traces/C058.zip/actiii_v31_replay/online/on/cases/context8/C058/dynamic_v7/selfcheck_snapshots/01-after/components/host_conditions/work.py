STAGES = ("pre", "roles", "includes", "tasks", "post")


def _contains(collection, host):
    return collection is not None and host in collection


def _add_task(table, host, task, path):
    only = task.get("only")
    table[path] = [
        True if only is None else host in only,
        _contains(task.get("fail_hosts"), host),
    ]


def _add_block(table, host, item, path):
    block = item.get("block") or {}
    only = item.get("only")
    table[path] = [
        True if only is None else host in only,
        False,
    ]
    for j, task in enumerate(block.get("tasks") or []):
        _add_task(table, host, task, "%s/0/%d" % (path, j))
    for j, task in enumerate(block.get("rescue") or []):
        _add_task(table, host, task, "%s/1/%d" % (path, j))
    for j, task in enumerate(block.get("always") or []):
        _add_task(table, host, task, "%s/2/%d" % (path, j))


def compute(payload):
    """每个 host 对应一张节点表，按树位置（各级整数以 / 分隔）记录 [可执行,会失败]；包含块节点。"""
    hosts = payload.get("hosts") or []
    program = payload.get("program") or {}
    result = {}
    for host in hosts:
        table = {}
        for stage_index, stage_name in enumerate(STAGES):
            stage = program.get(stage_name) or []
            for item_index, item in enumerate(stage):
                path = "%d/%d" % (stage_index, item_index)
                if "block" in item:
                    _add_block(table, host, item, path)
                else:
                    _add_task(table, host, item, path)
        result[host] = table
    return result
