import unittest

# Injected names available at runtime (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...)
# CandidateCallError

visible_document = "TASK.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": visible_document,
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "The visible contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": visible_document,
                "requirement_quote": "输入hosts为有序唯一主机列表",
                "reason": "The contract does not specify ValueError for non-object payloads.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_empty_program_returns_empty_batches_and_ok_final(self):
        payload = {"hosts": ["h0", "h1"], "handlers": [], "program": {}}
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["batches"], [])
        self.assertEqual(result["final"], {"h0": "ok", "h1": "ok"})

    def test_single_task_success_produces_task_batch(self):
        payload = {
            "hosts": ["h0"],
            "handlers": [],
            "program": {"tasks": [{"id": "t1"}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(len(result["batches"]), 1)
        batch = result["batches"][0]
        self.assertEqual(len(batch), 1)
        self.assertEqual(batch[0]["host"], "h0")
        self.assertEqual(batch[0]["task"], "t1")
        self.assertEqual(batch[0]["kind"], "task")
        self.assertEqual(batch[0]["status"], "ok")
        self.assertEqual(result["final"], {"h0": "ok"})

    def test_failing_task_marks_host_failed(self):
        payload = {
            "hosts": ["h0"],
            "handlers": [],
            "program": {"tasks": [{"id": "t1", "fail_hosts": ["h0"]}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["final"], {"h0": "failed"})
        self.assertEqual(result["batches"][0][0]["status"], "failed")

    def test_only_skips_non_matching_host(self):
        payload = {
            "hosts": ["h0", "h1"],
            "handlers": [],
            "program": {"tasks": [{"id": "t1", "only": ["h1"]}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # only h1 runs t1
        self.assertEqual(len(result["batches"]), 1)
        batch = result["batches"][0]
        self.assertEqual(len(batch), 1)
        self.assertEqual(batch[0]["host"], "h1")
        self.assertEqual(result["final"], {"h0": "ok", "h1": "ok"})

    def test_notify_produces_flush_and_handler(self):
        payload = {
            "hosts": ["h0"],
            "handlers": ["h1"],
            "program": {"tasks": [{"id": "t1", "notify": ["h1"]}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        kinds = [e["kind"] for b in result["batches"] for e in b]
        self.assertIn("flush", kinds)
        self.assertIn("handler", kinds)
        # flush carries handlers list
        flush = [e for b in result["batches"] for e in b if e["kind"] == "flush"][0]
        self.assertEqual(flush["handlers"], ["h1"])

    def test_block_rescue_recovers_failure(self):
        payload = {
            "hosts": ["h0"],
            "handlers": [],
            "program": {
                "tasks": [
                    {
                        "block": {
                            "tasks": [{"id": "a", "fail_hosts": ["h0"]}],
                            "rescue": [{"id": "r"}],
                            "always": [],
                        }
                    }
                ]
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # rescue succeeds, so host is ok
        self.assertEqual(result["final"], {"h0": "ok"})
        tasks = [e["task"] for b in result["batches"] for e in b if e["kind"] == "task"]
        self.assertIn("a", tasks)
        self.assertIn("r", tasks)


if __name__ == "__main__":
    unittest.main()
