STAGES = ("pre", "roles", "includes", "tasks", "post")


def _path_key(path):
    return tuple(int(x) for x in path.split("/"))


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    hosts = payload.get("hosts") or []
    handlers = payload.get("handlers") or []
    program = payload.get("program") or {}

    host_conditions = left
    handler_order, leaf_to_notify = right

    batches = []
    final = {}

    # Per-host execution simulation producing a list of entries in canonical
    # order. Each entry is (canonical_key, dict) where canonical_key is a tuple
    # of ints used for interleaving. Flush entries get a key that sorts after
    # all program nodes of their stage.
    per_host = {}

    for host in hosts:
        table = host_conditions.get(host, {})
        entries = []
        stage_failed = False

        for stage_index, stage_name in enumerate(STAGES):
            if stage_failed:
                break
            stage = program.get(stage_name) or []
            stage_notify = []
            stage_notify_seen = set()

            def run_task(path, task):
                nonlocal stage_failed
                executable, will_fail = table.get(path, [True, False])
                if not executable:
                    return None
                status = "failed" if will_fail else "ok"
                entries.append((_path_key(path), {
                    "host": host,
                    "task": task.get("id"),
                    "kind": "task",
                    "status": status,
                }))
                if status == "failed":
                    stage_failed = True
                if status == "ok":
                    for name in leaf_to_notify.get(path, []):
                        if name not in stage_notify_seen:
                            stage_notify_seen.add(name)
                            stage_notify.append(name)
                return status

            def run_block(item, path):
                nonlocal stage_failed
                block = item.get("block") or {}
                only = item.get("only")
                if only is not None and host not in only:
                    return
                block_failed = False
                for j, task in enumerate(block.get("tasks") or []):
                    status = run_task("%s/0/%d" % (path, j), task)
                    if status == "failed":
                        block_failed = True
                        break
                if block_failed:
                    rescue = block.get("rescue") or []
                    if rescue:
                        rescue_ok = True
                        for j, task in enumerate(rescue):
                            status = run_task("%s/1/%d" % (path, j), task)
                            if status == "failed":
                                rescue_ok = False
                                break
                        if rescue_ok:
                            block_failed = False
                            stage_failed = False
                    if block_failed:
                        stage_failed = True
                for j, task in enumerate(block.get("always") or []):
                    status = run_task("%s/2/%d" % (path, j), task)
                    if status == "failed":
                        stage_failed = True

            for item_index, item in enumerate(stage):
                path = "%d/%d" % (stage_index, item_index)
                if "block" in item:
                    run_block(item, path)
                else:
                    run_task(path, item)
                if stage_failed:
                    break

            if stage_notify:
                # flush key: (stage_index, large) so it sorts after all nodes
                # of this stage but before next stage.
                flush_key = (stage_index, 1 << 30)
                entries.append((flush_key, {
                    "host": host,
                    "kind": "flush",
                    "status": "ok",
                    "handlers": stage_notify,
                }))
                # handler entries follow flush
                for name in stage_notify:
                    entries.append((flush_key, {
                        "host": host,
                        "task": name,
                        "kind": "handler",
                        "status": "ok",
                    }))

        per_host[host] = entries
        final[host] = "failed" if stage_failed else "ok"

    # Linear interleaving: repeatedly pick the earliest canonical key among
    # hosts' next entries; advance all hosts whose next entry has that key.
    # Hosts keep input order within a batch.
    idx = {h: 0 for h in hosts}
    while True:
        candidates = []
        for h in hosts:
            if idx[h] < len(per_host[h]):
                candidates.append((per_host[h][idx[h]][0], h))
        if not candidates:
            break
        min_key = min(k for k, _ in candidates)
        batch = []
        for h in hosts:
            if idx[h] < len(per_host[h]) and per_host[h][idx[h]][0] == min_key:
                batch.append(per_host[h][idx[h]][1])
                idx[h] += 1
        batches.append(batch)

    return {"batches": batches, "final": final}
