def compute(payload):
    """对每个 complete 事件按原始位置记录 [正常完成事件名,新 revision 或 null]。取消与关闭优先级由整合逻辑决定。"""
    result = {}
    for index, event in enumerate(payload["events"]):
        if event.get("op") != "complete":
            continue
        changed = bool(event.get("changed", False))
        if changed:
            name = "snapshot_updated"
            revision = event.get("revision")
        else:
            name = "poll_unchanged"
            revision = None
        result[str(index)] = [name, revision]
    return result
