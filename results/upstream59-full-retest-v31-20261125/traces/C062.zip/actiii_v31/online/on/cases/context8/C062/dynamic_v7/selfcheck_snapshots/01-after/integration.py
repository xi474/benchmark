def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    events = payload["events"]

    # Build store name -> initial state by matching open events to left keys.
    store_init = {}
    for i, ev in enumerate(events):
        if ev.get("op") == "open":
            store_init[ev["store"]] = left[str(i)]

    stores = {name: dict(init) for name, init in store_init.items()}
    state = {name: "open" for name in stores}
    job = {name: None for name in stores}
    cancelled = {name: set() for name in stores}

    audit = []

    def emit(time, store, event, **extra):
        rec = {"time": time, "store": store, "event": event}
        rec.update(extra)
        audit.append(rec)

    for ev in events:
        op = ev.get("op")
        store = ev["store"]
        time = ev["time"]
        if op == "open":
            emit(time, store, "opened")
            continue
        if op == "poll":
            j = ev["job"]
            if state[store] == "open":
                if job[store] is None:
                    job[store] = j
                    emit(time, store, "poll_started", job=j)
                else:
                    emit(time, store, "poll_coalesced")
            else:
                emit(time, store, "poll_rejected")
            continue
        if op == "close":
            if state[store] == "closed":
                emit(time, store, "close_returned")
                continue
            if job[store] is None:
                state[store] = "closed"
                stores[store]["state"] = "closed"
                stores[store]["closed_at"] = time
                emit(time, store, "close_returned")
            else:
                if state[store] == "open":
                    state[store] = "closing"
                    stores[store]["state"] = "closing"
                    cancelled[store].add(job[store])
                    emit(time, store, "cancel_sent", job=job[store])
                emit(time, store, "close_waiting")
            continue
        if op == "complete":
            j = ev["job"]
            changed = bool(ev.get("changed", False))
            revision = ev.get("revision")
            if j in cancelled[store]:
                emit(time, store, "callback_cancelled", job=j)
                job[store] = None
                state[store] = "closed"
                stores[store]["state"] = "closed"
                stores[store]["closed_at"] = time
                emit(time, store, "close_returned")
            else:
                if changed:
                    stores[store]["revision"] = revision
                    stores[store]["updates"] += 1
                    emit(time, store, "snapshot_updated", job=j)
                else:
                    emit(time, store, "poll_unchanged", job=j)
                job[store] = None
            continue

    return {"events": audit, "stores": stores}
