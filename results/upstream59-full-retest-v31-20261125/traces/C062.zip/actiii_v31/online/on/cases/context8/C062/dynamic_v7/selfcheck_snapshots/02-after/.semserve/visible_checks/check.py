import unittest


class TestTransform(unittest.TestCase):
    def test_open_close_basic(self):
        payload = {
            "events": [
                {"time": 0, "store": "s", "op": "open", "backend": "git"},
                {"time": 1, "store": "s", "op": "close"},
            ]
        }
        expected = {
            "events": [
                {"time": 0, "store": "s", "event": "opened"},
                {"time": 1, "store": "s", "event": "close_returned"},
            ],
            "stores": {
                "s": {
                    "backend": "git",
                    "state": "closed",
                    "job": None,
                    "revision": 0,
                    "closed_at": 1,
                    "updates": 0,
                }
            },
        }
        result = call_candidate("component_runtime.py", "transform", args=[payload])
        self.assertEqual(result, expected)

    def test_poll_start_and_unchanged(self):
        payload = {
            "events": [
                {"time": 0, "store": "s", "op": "open", "backend": "local"},
                {"time": 1, "store": "s", "op": "poll", "job": "j1"},
                {"time": 2, "store": "s", "op": "complete", "job": "j1", "changed": False},
                {"time": 3, "store": "s", "op": "close"},
            ]
        }
        result = call_candidate("component_runtime.py", "transform", args=[payload])
        events = [e["event"] for e in result["events"]]
        self.assertEqual(
            events,
            ["opened", "poll_started", "poll_unchanged", "close_returned"],
        )
        self.assertEqual(result["stores"]["s"]["updates"], 0)
        self.assertEqual(result["stores"]["s"]["revision"], 0)

    def test_poll_coalesced(self):
        payload = {
            "events": [
                {"time": 0, "store": "s", "op": "open", "backend": "s3"},
                {"time": 1, "store": "s", "op": "poll", "job": "j1"},
                {"time": 2, "store": "s", "op": "poll", "job": "j2"},
                {"time": 3, "store": "s", "op": "complete", "job": "j1", "changed": True, "revision": 5},
                {"time": 4, "store": "s", "op": "close"},
            ]
        }
        result = call_candidate("component_runtime.py", "transform", args=[payload])
        events = [e["event"] for e in result["events"]]
        self.assertEqual(
            events,
            ["opened", "poll_started", "poll_coalesced", "snapshot_updated", "close_returned"],
        )
        self.assertEqual(result["stores"]["s"]["revision"], 5)
        self.assertEqual(result["stores"]["s"]["updates"], 1)

    def test_close_barrier_cancel(self):
        payload = {
            "events": [
                {"time": 0, "store": "s", "op": "open", "backend": "azure"},
                {"time": 1, "store": "s", "op": "poll", "job": "j1"},
                {"time": 2, "store": "s", "op": "close"},
                {"time": 3, "store": "s", "op": "complete", "job": "j1", "changed": True, "revision": 9},
            ]
        }
        result = call_candidate("component_runtime.py", "transform", args=[payload])
        events = [e["event"] for e in result["events"]]
        self.assertEqual(
            events,
            ["opened", "poll_started", "cancel_sent", "close_waiting",
             "callback_cancelled", "close_returned"],
        )
        # Cancelled complete must not publish a snapshot.
        self.assertEqual(result["stores"]["s"]["revision"], 0)
        self.assertEqual(result["stores"]["s"]["updates"], 0)
        self.assertEqual(result["stores"]["s"]["state"], "closed")

    def test_poll_rejected_when_closing(self):
        payload = {
            "events": [
                {"time": 0, "store": "s", "op": "open", "backend": "oci"},
                {"time": 1, "store": "s", "op": "poll", "job": "j1"},
                {"time": 2, "store": "s", "op": "close"},
                {"time": 3, "store": "s", "op": "poll", "job": "j2"},
                {"time": 4, "store": "s", "op": "complete", "job": "j1", "changed": False},
            ]
        }
        result = call_candidate("component_runtime.py", "transform", args=[payload])
        events = [e["event"] for e in result["events"]]
        self.assertIn("poll_rejected", events)
        self.assertIn("callback_cancelled", events)
        self.assertIn("close_returned", events)


if __name__ == "__main__":
    unittest.main()
