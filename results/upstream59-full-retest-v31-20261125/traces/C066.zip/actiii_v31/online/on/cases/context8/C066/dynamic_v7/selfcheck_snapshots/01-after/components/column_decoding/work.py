def compute(payload):
    """按事务、语句、行变更生成已解码的列映射。D 用空对象；类型错误用 null，使整合端按事务回滚。"""
    result = []
    for tx in payload["txs"]:
        tx_result = []
        for statement in tx["statements"]:
            stmt_result = []
            for change in statement:
                op = change["op"]
                if op == "D":
                    stmt_result.append({})
                    continue
                cols = change.get("cols", [])
                decoded = {}
                bad = False
                for col in cols:
                    name = col["name"]
                    ctype = col["type"]
                    value = col["value"]
                    if ctype == "text":
                        if value is not None and not isinstance(value, str):
                            bad = True
                            break
                        decoded[name] = value
                    elif ctype == "int":
                        if value is None:
                            decoded[name] = None
                        elif isinstance(value, str):
                            try:
                                decoded[name] = int(value)
                            except ValueError:
                                bad = True
                                break
                        elif isinstance(value, int) and not isinstance(value, bool):
                            decoded[name] = value
                        else:
                            bad = True
                            break
                    else:
                        bad = True
                        break
                if bad:
                    stmt_result.append(None)
                else:
                    stmt_result.append(decoded)
            tx_result.append(stmt_result)
        result.append(tx_result)
    return result
