def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    initial = payload["initial"]
    rows = {k: dict(v) for k, v in initial.items()}
    committed = set()
    log = []

    txs = payload["txs"]
    for ti, tx in enumerate(txs):
        lsn = tx["lsn"]
        if lsn in committed:
            log.append([lsn, "REPLAY"])
            continue

        statements = tx["statements"]
        tx_left = left[ti]
        tx_right = right[ti]

        snapshot = dict(rows)
        aborted = False
        for si, statement in enumerate(statements):
            consumed = tx_left[si]
            decoded = tx_right[si]

            seen_old = set()
            for change in statement:
                op = change["op"]
                if op in ("U", "D"):
                    old = change["old"]
                    if old in seen_old:
                        aborted = True
                        break
                    seen_old.add(old)
                    if old not in snapshot:
                        aborted = True
                        break
            if aborted:
                break

            for change, cols in zip(statement, decoded):
                if cols is None:
                    aborted = True
                    break
            if aborted:
                break

            for change in statement:
                op = change["op"]
                if op in ("U", "D"):
                    del snapshot[change["old"]]

            new_rows = {}
            for change, cols in zip(statement, decoded):
                op = change["op"]
                if op == "D":
                    continue
                if "key" in cols:
                    new_key = cols["key"]
                else:
                    new_key = change["old"]
                if new_key is None or new_key == "":
                    aborted = True
                    break
                if new_key in snapshot or new_key in new_rows:
                    aborted = True
                    break

                if op == "I":
                    if not ("key" in cols and "body" in cols and "rank" in cols):
                        aborted = True
                        break
                    new_rows[new_key] = {"body": cols["body"], "rank": cols["rank"]}
                else:
                    old = change["old"]
                    base = dict(rows[old]) if old in rows else {}
                    merged = dict(base)
                    for name in ("body", "rank"):
                        if name in cols:
                            merged[name] = cols[name]
                    new_rows[new_key] = merged
            if aborted:
                break

            for k, v in new_rows.items():
                snapshot[k] = v

        if aborted:
            log.append([lsn, "ABORT"])
        else:
            rows = snapshot
            committed.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": rows}
