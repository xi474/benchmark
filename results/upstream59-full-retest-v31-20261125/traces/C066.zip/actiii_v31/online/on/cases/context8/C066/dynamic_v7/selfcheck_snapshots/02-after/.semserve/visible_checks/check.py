import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "公开规格未声明 transform 对未知字段或非有限数值抛出 ValueError。",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "公开规格未声明 transform 对非对象 payload 抛出 ValueError。",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_primary_key_swap_commit(self):
        # 公开规则：一条语句同时移除所有 U/D 的旧身份，再放置 I/U 的新行，允许主键置换。
        payload = {
            "initial": {"a": {"body": "one", "rank": 1}, "b": {"body": "", "rank": 2}},
            "txs": [
                {
                    "lsn": 1,
                    "statements": [
                        [
                            {"op": "U", "old": "a", "cols": [{"name": "key", "type": "text", "value": "b"}]},
                            {"op": "U", "old": "b", "cols": [{"name": "key", "type": "text", "value": "a"}, {"name": "body", "type": "text", "value": None}]},
                        ]
                    ],
                }
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[1, "COMMIT"]])
        self.assertEqual(result["rows"], {"b": {"body": "one", "rank": 1}, "a": {"body": None, "rank": 2}})

    def test_replay_skips_committed_lsn(self):
        # 公开规则：若 lsn 已成功提交过，返回 REPLAY 并跳过。
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}},
            "txs": [
                {"lsn": 5, "statements": [[{"op": "U", "old": "a", "cols": [{"name": "body", "type": "text", "value": "y"}]}]]},
                {"lsn": 5, "statements": [[{"op": "U", "old": "a", "cols": [{"name": "body", "type": "text", "value": "z"}]}]]},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[5, "COMMIT"], [5, "REPLAY"]])
        self.assertEqual(result["rows"], {"a": {"body": "y", "rank": 1}})

    def test_abort_on_missing_old_rolls_back(self):
        # 公开规则：不存在的 old 会使整个事务 ABORT 并回滚先前语句。
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}},
            "txs": [
                {
                    "lsn": 7,
                    "statements": [
                        [{"op": "U", "old": "a", "cols": [{"name": "body", "type": "text", "value": "changed"}]}],
                        [{"op": "U", "old": "missing", "cols": [{"name": "body", "type": "text", "value": "nope"}]}],
                    ],
                }
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[7, "ABORT"]])
        self.assertEqual(result["rows"], {"a": {"body": "x", "rank": 1}})

    def test_abort_on_new_key_collision(self):
        # 公开规则：新键碰撞会使整个事务 ABORT。
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}, "b": {"body": "y", "rank": 2}},
            "txs": [
                {
                    "lsn": 9,
                    "statements": [
                        [{"op": "U", "old": "a", "cols": [{"name": "key", "type": "text", "value": "b"}]}],
                    ],
                }
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[9, "ABORT"]])
        self.assertEqual(result["rows"], {"a": {"body": "x", "rank": 1}, "b": {"body": "y", "rank": 2}})

    def test_insert_requires_all_columns(self):
        # 公开规则：I 必须提供 key、body、rank 三列。
        payload = {
            "initial": {},
            "txs": [
                {
                    "lsn": 3,
                    "statements": [
                        [{"op": "I", "cols": [{"name": "key", "type": "text", "value": "k"}, {"name": "body", "type": "text", "value": "b"}]}],
                    ],
                }
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[3, "ABORT"]])
        self.assertEqual(result["rows"], {})

    def test_type_mismatch_aborts(self):
        # 公开规则：类型标记不符会使整个事务 ABORT。
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}},
            "txs": [
                {
                    "lsn": 11,
                    "statements": [
                        [{"op": "U", "old": "a", "cols": [{"name": "rank", "type": "int", "value": "not-an-int"}]}],
                    ],
                }
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[11, "ABORT"]])
        self.assertEqual(result["rows"], {"a": {"body": "x", "rank": 1}})


if __name__ == "__main__":
    unittest.main()
