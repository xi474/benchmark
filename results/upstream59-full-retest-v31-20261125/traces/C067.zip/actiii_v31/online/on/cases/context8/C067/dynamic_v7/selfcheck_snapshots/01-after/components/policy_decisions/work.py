def compute(payload):
    """按输入顺序重放策略变更，为每个 request 原位置生成授权布尔值。"""
    policies = payload.get("policies", {})
    # 当前允许规则表：user -> set of (cluster, verb, service)
    allow = {}
    for user, rules in policies.items():
        allow[user] = set()
        for rule in rules:
            allow[user].add((
                rule.get("cluster"),
                rule.get("verb"),
                rule.get("service"),
            ))

    result = {}
    for idx, event in enumerate(payload.get("events", [])):
        if event.get("op") == "policy":
            user = event.get("user")
            rules = event.get("allow", [])
            allow[user] = set()
            for rule in rules:
                allow[user].add((
                    rule.get("cluster"),
                    rule.get("verb"),
                    rule.get("service"),
                ))
        elif event.get("op") == "request":
            user = event.get("user")
            cluster = event.get("cluster")
            verb = event.get("verb")
            service = event.get("service")
            user_rules = allow.get(user, set())
            authorized = False
            for (c, v, s) in user_rules:
                if c != cluster or v != verb:
                    continue
                if s is None or s == "*" or s == service:
                    authorized = True
                    break
            result[str(idx)] = authorized

    return result
