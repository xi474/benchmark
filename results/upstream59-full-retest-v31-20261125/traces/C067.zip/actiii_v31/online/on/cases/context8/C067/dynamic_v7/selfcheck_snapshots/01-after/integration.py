def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # left: policy_decisions -> {str(index): bool} for request events
    # right: service_routes -> {str(index): [mode, available]} for request events
    auth = left
    routes = right

    replies = []
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0

    # cache keyed by (user, cluster, service) -> {"credential": str, "expires": int}
    cache = {}

    request_index = 0
    for event in events:
        if event.get("op") != "request":
            continue
        idx = str(request_index)
        request_index += 1

        rid = event["id"]
        user = event["user"]
        cluster = event["cluster"]
        service = event["service"]
        now = event["time"]

        # Every request must be re-authorized.
        authorizer_calls += 1
        allowed = auth.get(idx, False)
        if not allowed:
            replies.append({"id": rid, "status": "denied"})
            continue

        # After authorization, must look up current service availability.
        service_lookups += 1
        mode, available = routes.get(idx, [None, False])
        if not available:
            replies.append({"id": rid, "status": "not_found"})
            continue

        if mode == "local":
            replies.append({
                "id": rid,
                "status": "ok",
                "credential": "local",
                "route": "local",
            })
            continue

        # remote: resolve reverse_tunnel route each time.
        remote_routes += 1

        # Cleanup happens on cache access after successfully finding remote service.
        key = (user, cluster, service)
        expired = [k for k, v in cache.items() if v["expires"] <= now]
        for k in expired:
            del cache[k]

        if key in cache:
            credential = cache[key]["credential"]
        else:
            certificates_issued += 1
            credential = "cert-%d" % certificates_issued
            cache[key] = {"credential": credential, "expires": now + ttl}

        replies.append({
            "id": rid,
            "status": "ok",
            "credential": credential,
            "route": "reverse_tunnel",
        })

    # Final cache sorted by user/cluster/service lexicographically.
    cache_list = []
    for key in sorted(cache.keys()):
        user, cluster, service = key
        cache_list.append({
            "user": user,
            "cluster": cluster,
            "service": service,
            "credential": cache[key]["credential"],
            "expires": cache[key]["expires"],
        })

    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": cache_list,
    }
