import unittest

# Injected by the self-check SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None


class TestTransform(unittest.TestCase):
    def test_denied_request_no_service_lookup(self):
        # A request not allowed by policy must be denied without service lookup
        # or credential issuance.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "remote", "services": {"s": True}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "write"}
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"], [{"id": "r1", "status": "denied"}])
        self.assertEqual(result["authorizer_calls"], 1)
        self.assertEqual(result["service_lookups"], 0)
        self.assertEqual(result["certificates_issued"], 0)
        self.assertEqual(result["cache"], [])

    def test_not_found_service(self):
        # Allowed but unavailable service yields not_found and no credential.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "remote", "services": {"s": False}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"}
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"], [{"id": "r1", "status": "not_found"}])
        self.assertEqual(result["service_lookups"], 1)
        self.assertEqual(result["certificates_issued"], 0)
        self.assertEqual(result["cache"], [])

    def test_local_credential_no_cache(self):
        # Local mode uses local credential and never builds a cache entry.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "local", "services": {"s": True}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"}
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"], [{
            "id": "r1", "status": "ok", "credential": "local", "route": "local"}])
        self.assertEqual(result["certificates_issued"], 0)
        self.assertEqual(result["cache"], [])

    def test_cache_expiry_evicts(self):
        # A remote credential expires at now+ttl; a later request at time >=
        # expires must issue a new certificate.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "remote", "services": {"s": True}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
                {"op": "request", "id": "r2", "time": 5, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["certificates_issued"], 2)
        self.assertEqual(result["replies"][0]["credential"], "cert-1")
        self.assertEqual(result["replies"][1]["credential"], "cert-2")
        self.assertEqual(len(result["cache"]), 1)
        self.assertEqual(result["cache"][0]["credential"], "cert-2")
        self.assertEqual(result["cache"][0]["expires"], 10)

    def test_cache_hit_no_reissue(self):
        # A second remote request within ttl reuses the same certificate.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "remote", "services": {"s": True}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
                {"op": "request", "id": "r2", "time": 4, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["certificates_issued"], 1)
        self.assertEqual(result["replies"][0]["credential"], "cert-1")
        self.assertEqual(result["replies"][1]["credential"], "cert-1")
        self.assertEqual(len(result["cache"]), 1)

    def test_policy_event_replaces_allow(self):
        # A policy event replaces the user's allow list; a previously allowed
        # verb becomes denied.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "remote", "services": {"s": True}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
                {"op": "policy", "time": 1, "user": "u",
                 "allow": [{"cluster": "c", "verb": "write"}]},
                {"op": "request", "id": "r2", "time": 2, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "ok")
        self.assertEqual(result["replies"][1], {"id": "r2", "status": "denied"})

    def test_service_event_updates_availability(self):
        # A service event toggling availability off yields not_found on the
        # next request.
        payload = {
            "ttl": 5,
            "clusters": {"c": {"mode": "remote", "services": {"s": True}}},
            "policies": {"u": [{"cluster": "c", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "r1", "time": 0, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
                {"op": "service", "time": 1, "cluster": "c", "service": "s",
                 "available": False},
                {"op": "request", "id": "r2", "time": 2, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
                {"op": "service", "time": 3, "cluster": "c", "service": "s",
                 "available": True},
                {"op": "request", "id": "r3", "time": 4, "user": "u",
                 "cluster": "c", "service": "s", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "ok")
        self.assertEqual(result["replies"][1], {"id": "r2", "status": "not_found"})
        self.assertEqual(result["replies"][2]["status"], "ok")


if __name__ == "__main__":
    unittest.main()
