def compute(payload):
    """按事件位置返回请求当时的 [集群模式,服务是否可用]；合并端负责授权优先和实际计数。"""
    clusters = payload["clusters"]
    events = payload["events"]
    # 服务可用性状态：cluster -> service -> bool
    availability = {}
    for cluster, info in clusters.items():
        availability[cluster] = dict(info.get("services", {}))
    result = {}
    request_pos = 0
    for idx, event in enumerate(events):
        op = event.get("op")
        if op == "service":
            cluster = event["cluster"]
            service = event["service"]
            available = event["available"]
            availability.setdefault(cluster, {})[service] = available
        elif op == "request":
            cluster = event["cluster"]
            service = event["service"]
            mode = clusters[cluster]["mode"]
            available = availability.get(cluster, {}).get(service, False)
            result[str(request_pos)] = [mode, available]
            request_pos += 1
    return result
