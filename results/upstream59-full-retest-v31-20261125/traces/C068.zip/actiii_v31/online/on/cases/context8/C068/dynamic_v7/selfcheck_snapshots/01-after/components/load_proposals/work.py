def compute(payload):
    """为每个 get 的原始位置生成 [若启动时的完成时刻,value,error]；只有命中未复用时才实际启动。"""
    result = {}
    for pos, event in enumerate(payload["events"]):
        if event.get("op") != "get":
            continue
        finish = event["time"] + event["delay"]
        result[str(pos)] = [finish, event["value"], event.get("error")]
    return result
