def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # left: cleanup_clock -> {position_string: next_cleanup_after_trigger}
    # right: load_proposals -> {position_string: [finish_time, value, error]}
    cleanup_triggers = left if isinstance(left, dict) else {}
    proposals = right if isinstance(right, dict) else {}

    results = []
    loads = []
    cache = {}  # key -> {"value":..., "error":..., "expires":...}

    next_cleanup = 16 * ttl
    now = 0

    # in-flight loads: key -> {"started_at":..., "finished_at":..., "value":..., "error":...}
    in_flight = {}
    # load start order for same-time completion ordering
    load_order = []

    # pending waiters: id -> {"key":..., "cancelled": bool}
    waiters = {}

    def complete_load(key):
        load = in_flight.pop(key)
        load_order.remove(key)
        cache[key] = {
            "value": load["value"],
            "error": load["error"],
            "expires": load["finished_at"] + ttl,
        }
        loads.append({
            "key": key,
            "started_at": load["started_at"],
            "finished_at": load["finished_at"],
        })
        # resolve waiters for this key
        for wid in list(waiters):
            w = waiters[wid]
            if w["key"] != key:
                continue
            del waiters[wid]
            if w["cancelled"]:
                results.append({
                    "id": wid,
                    "status": "cancelled",
                    "value": None,
                    "error": "cancelled",
                    "finished_at": load["finished_at"],
                })
            else:
                results.append({
                    "id": wid,
                    "status": "error" if load["error"] is not None else "ok",
                    "value": None if load["error"] is not None else load["value"],
                    "error": load["error"],
                    "finished_at": load["finished_at"],
                })

    def complete_due_loads(now_time):
        # complete loads whose finished_at <= now_time, in start order
        due = [k for k in load_order if in_flight[k]["finished_at"] <= now_time]
        for k in due:
            complete_load(k)

    for i, event in enumerate(events):
        op = event.get("op")
        t = event.get("time", now)
        now = t

        # Before each external event, complete due loads.
        complete_due_loads(now)

        if op == "get":
            key = event["key"]
            wid = event["id"]
            delay = event.get("delay", 0)
            value = event.get("value")
            error = event.get("error")

            # cleanup check on get access
            if now >= next_cleanup:
                # remove all expired items
                for k in list(cache):
                    if cache[k]["expires"] <= now:
                        del cache[k]
                next_cleanup = now + 16 * ttl

            # remove expired item for this specific key
            if key in cache and cache[key]["expires"] <= now:
                del cache[key]

            # check cache hit
            if key in cache:
                entry = cache[key]
                results.append({
                    "id": wid,
                    "status": "error" if entry["error"] is not None else "ok",
                    "value": None if entry["error"] is not None else entry["value"],
                    "error": entry["error"],
                    "finished_at": now,
                })
                continue

            # check in-flight
            if key in in_flight:
                waiters[wid] = {"key": key, "cancelled": False}
                continue

            # miss -> start load
            finish = now + delay
            in_flight[key] = {
                "started_at": now,
                "finished_at": finish,
                "value": value,
                "error": error,
            }
            load_order.append(key)
            waiters[wid] = {"key": key, "cancelled": False}

            # delay == 0 completes within this get
            if delay == 0:
                complete_due_loads(now)

        elif op == "cancel":
            wid = event.get("id")
            if wid in waiters:
                waiters[wid]["cancelled"] = True

        elif op == "advance":
            pass

    # At end, all gets are completed or cancelled. Complete any remaining loads.
    # (Guaranteed by contract, but resolve anyway.)
    for k in list(load_order):
        complete_load(k)

    # Build cache output sorted by key
    cache_out = [
        {
            "key": k,
            "value": cache[k]["value"],
            "error": cache[k]["error"],
            "expires": cache[k]["expires"],
        }
        for k in sorted(cache)
    ]

    return {
        "results": results,
        "loads": loads,
        "cache": cache_out,
        "next_cleanup": next_cleanup,
    }
