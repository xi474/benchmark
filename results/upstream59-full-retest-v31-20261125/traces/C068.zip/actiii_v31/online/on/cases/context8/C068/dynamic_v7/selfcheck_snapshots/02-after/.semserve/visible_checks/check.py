import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "Public contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "输入ttl为正整数；events的time为非负非递减整数",
                "reason": "Contract specifies field types but not that transform must raise ValueError on a non-object payload.",
            },
        },
    },
]


class TestVisibleContract(unittest.TestCase):
    def test_transform_public_fixture(self):
        # Output contract: results/loads/cache/next_cleanup present and correct.
        import json
        from pathlib import Path
        payload = json.loads(Path("public_input.json").read_text(encoding="utf-8"))
        expected = json.loads(Path("public_expected.json").read_text(encoding="utf-8"))
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, expected)

    def test_transform_does_not_mutate_input(self):
        # Contract: transform must not modify the input object.
        import json
        from pathlib import Path
        payload = json.loads(Path("public_input.json").read_text(encoding="utf-8"))
        snapshot = json.dumps(payload, sort_keys=True)
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(json.dumps(payload, sort_keys=True), snapshot)

    def test_cancel_waiter_does_not_cancel_shared_load(self):
        # Contract: cancel only cancels the waiter; the shared load still completes
        # and its result is cached even if all waiters cancel.
        payload = {
            "ttl": 5,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 3, "value": 1, "error": None},
                {"op": "get", "time": 1, "id": "b", "key": "k", "delay": 9, "value": 9, "error": None},
                {"op": "cancel", "time": 2, "id": "a"},
                {"op": "cancel", "time": 2, "id": "b"},
                {"op": "advance", "time": 3},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        statuses = {r["id"]: r["status"] for r in result["results"]}
        self.assertEqual(statuses["a"], "cancelled")
        self.assertEqual(statuses["b"], "cancelled")
        # The shared load still completed and is cached.
        self.assertEqual(len(result["loads"]), 1)
        self.assertEqual(result["loads"][0]["key"], "k")
        self.assertEqual(result["loads"][0]["finished_at"], 3)
        self.assertEqual(len(result["cache"]), 1)
        self.assertEqual(result["cache"][0]["key"], "k")
        self.assertEqual(result["cache"][0]["value"], 1)

    def test_error_load_caches_error_with_null_value(self):
        # Contract: error results are cached; value is null on error.
        payload = {
            "ttl": 5,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 2, "value": 7, "error": "boom"},
                {"op": "advance", "time": 2},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["results"][0]["status"], "error")
        self.assertIsNone(result["results"][0]["value"])
        self.assertEqual(result["results"][0]["error"], "boom")
        self.assertEqual(result["cache"][0]["error"], "boom")
        self.assertEqual(result["cache"][0]["value"], 7)

    def test_expiry_removes_stale_entry(self):
        # Contract: expires <= access time means expired; accessing a key removes it.
        payload = {
            "ttl": 5,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 0, "value": 1, "error": None},
                {"op": "advance", "time": 5},
                {"op": "get", "time": 5, "id": "b", "key": "k", "delay": 0, "value": 2, "error": None},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # First entry expires at 5, so second get is a miss and starts a new load.
        self.assertEqual(len(result["loads"]), 2)
        self.assertEqual(result["results"][1]["value"], 2)
        self.assertEqual(result["cache"][0]["value"], 2)


if __name__ == "__main__":
    unittest.main()
