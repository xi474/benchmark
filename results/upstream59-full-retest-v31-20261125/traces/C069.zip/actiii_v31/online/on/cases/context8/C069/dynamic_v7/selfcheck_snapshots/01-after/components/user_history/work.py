import copy


def compute(payload):
    """记录各续期事件发生时的用户快照，重放 update_user 的 roles、traits；以原位置字符串为键。"""
    events = payload.get("events", [])
    user = payload.get("user", {})
    current = copy.deepcopy(user)
    result = {}
    for i, event in enumerate(events):
        op = event.get("op")
        if op == "update_user":
            if "roles" in event:
                current["roles"] = list(event["roles"])
            if "traits" in event:
                current["traits"] = copy.deepcopy(event["traits"])
        elif op == "renew":
            result[str(i)] = copy.deepcopy(current)
    return result
