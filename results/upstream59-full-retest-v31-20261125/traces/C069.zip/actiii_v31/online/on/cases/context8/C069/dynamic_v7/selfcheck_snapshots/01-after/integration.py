import base64
import copy
import json


def _b64url(obj):
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return base64.urlsafe_b64encode(text.encode("utf-8")).decode("ascii").rstrip("=")


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    user = payload.get("user", {})
    start_time = payload.get("start_time", 0)
    session_ttl = payload.get("session_ttl", 0)
    access_requests = payload.get("access_requests", {})
    events = payload.get("events", [])
    initial_id = payload.get("initial_id", "s0")

    sessions = {}
    sessions[initial_id] = {
        "user": copy.deepcopy(user),
        "login_time": start_time,
        "expiry": start_time + session_ttl,
        "active_requests": {},
    }

    session_ids = [initial_id]
    replies = []

    for i, event in enumerate(events):
        op = event.get("op")
        if op == "update_user":
            if "roles" in event:
                user["roles"] = list(event["roles"])
            if "traits" in event:
                user["traits"] = copy.deepcopy(event["traits"])
            continue

        if op != "renew":
            continue

        now = event.get("time", 0)
        rid = event.get("id")
        prev_id = event.get("prev")

        if prev_id not in sessions:
            replies.append({"id": rid, "status": "expired"})
            continue

        prev = sessions[prev_id]
        if prev["expiry"] <= now:
            replies.append({"id": rid, "status": "expired"})
            continue

        if event.get("reload_user"):
            cached_user = copy.deepcopy(user)
        else:
            cached_user = copy.deepcopy(prev["user"])

        active = copy.deepcopy(prev["active_requests"])

        if event.get("switchback"):
            active = {}
        elif event.get("access_request") is not None:
            req_id = event["access_request"]
            req = access_requests.get(req_id)
            if req is None or not req.get("approved") or req.get("expiry", 0) <= now:
                replies.append({"id": rid, "status": "request_unavailable"})
                continue
            has_resources = bool(req.get("resources"))
            if has_resources:
                if any(bool(r.get("resources")) for r in active.values()):
                    replies.append({"id": rid, "status": "resource_already_active"})
                    continue
            active[req_id] = copy.deepcopy(req)

        active = {k: v for k, v in active.items() if v.get("expiry", 0) > now}

        roles = set(cached_user.get("roles", []))
        resources = set()
        for r in active.values():
            roles.update(r.get("roles", []))
            resources.update(r.get("resources", []))

        roles = sorted(roles)
        resources = sorted(resources)

        if active:
            expiry = min(now + session_ttl, min(r["expiry"] for r in active.values()))
        else:
            expiry = now + session_ttl

        new_session = {
            "user": cached_user,
            "login_time": prev["login_time"],
            "expiry": expiry,
            "active_requests": active,
        }
        sessions[rid] = new_session
        session_ids.append(rid)

        ssh_obj = {
            "roles": roles,
            "allowed_resources": resources,
            "extensions": copy.deepcopy(cached_user.get("traits", {})),
            "login_time": new_session["login_time"],
            "expires": expiry,
        }
        tls_obj = {
            "user": cached_user.get("name"),
            "active_requests": sorted(active.keys()),
            "login_time": new_session["login_time"],
            "expires": expiry,
        }

        replies.append({
            "id": rid,
            "status": "ok",
            "ssh_certificate": "SSH-MODEL1." + _b64url(ssh_obj),
            "tls_certificate": "TLS-MODEL1." + _b64url(tls_obj),
        })

    return {
        "replies": replies,
        "session_ids": session_ids,
    }
