import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "The public contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "核心接口transform(payload)返回下述JSON结果",
                "reason": "The contract does not specify ValueError for non-object payloads.",
            },
        },
    },
]


def _payload():
    return {
        "user": {"name": "alice", "roles": ["base"], "traits": {"logins": ["alice"], "db_users": ["db1"]}},
        "start_time": 0,
        "session_ttl": 100,
        "access_requests": {},
        "events": [{"op": "renew", "id": "s1", "time": 10, "prev": "s0"}],
    }


class TestSessionRenewal(unittest.TestCase):
    def test_renew_default_extends_prev_user(self):
        result = call_candidate("solution.py", "transform", args=[_payload()])
        self.assertEqual(result["session_ids"], ["s0", "s1"])
        self.assertEqual(result["replies"][0]["status"], "ok")
        self.assertEqual(result["replies"][0]["id"], "s1")

    def test_expired_prev_yields_expired(self):
        payload = _payload()
        payload["session_ttl"] = 10
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["session_ids"], ["s0"])
        self.assertEqual(result["replies"][0]["status"], "expired")

    def test_assume_role_request_accumulates(self):
        payload = _payload()
        payload["access_requests"] = {
            "r1": {"approved": True, "expiry": 70, "roles": ["reader"]},
            "r2": {"approved": True, "expiry": 60, "roles": ["writer"]},
        }
        payload["events"] = [
            {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "r1"},
            {"op": "renew", "id": "s2", "time": 20, "prev": "s1", "access_request": "r2"},
        ]
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["session_ids"], ["s0", "s1", "s2"])
        self.assertEqual(result["replies"][1]["status"], "ok")

    def test_resource_already_active(self):
        payload = _payload()
        payload["access_requests"] = {
            "q1": {"approved": True, "expiry": 50, "resources": ["db:one"]},
            "q2": {"approved": True, "expiry": 40, "resources": ["db:two"]},
        }
        payload["events"] = [
            {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "q1"},
            {"op": "renew", "id": "s2", "time": 20, "prev": "s1", "access_request": "q2"},
        ]
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][1]["status"], "resource_already_active")

    def test_request_unavailable_when_not_approved(self):
        payload = _payload()
        payload["access_requests"] = {"no": {"approved": False, "expiry": 90, "roles": ["admin"]}}
        payload["events"] = [{"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "no"}]
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "request_unavailable")

    def test_switchback_clears_requests(self):
        import base64
        import json
        payload = _payload()
        payload["access_requests"] = {"r1": {"approved": True, "expiry": 70, "roles": ["reader"]}}
        payload["events"] = [
            {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "r1"},
            {"op": "renew", "id": "s2", "time": 20, "prev": "s1", "switchback": True},
        ]
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][1]["status"], "ok")
        tls = result["replies"][1]["tls_certificate"]
        body = tls[len("TLS-MODEL1."):]
        obj = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)).decode("utf-8"))
        self.assertEqual(obj["active_requests"], [])

    def test_update_user_reload(self):
        import base64
        import json
        payload = _payload()
        payload["events"] = [
            {"op": "update_user", "time": 5, "roles": ["base", "admin"]},
            {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "reload_user": True},
        ]
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "ok")
        ssh = result["replies"][0]["ssh_certificate"]
        body = ssh[len("SSH-MODEL1."):]
        obj = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)).decode("utf-8"))
        self.assertEqual(obj["roles"], ["admin", "base"])


if __name__ == "__main__":
    unittest.main()
