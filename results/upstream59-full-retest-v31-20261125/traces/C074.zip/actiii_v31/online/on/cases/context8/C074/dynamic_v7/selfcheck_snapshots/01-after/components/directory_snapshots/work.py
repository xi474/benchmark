def _resolve(path, mounts, nodes):
    """Resolve a logical path to its node definition."""
    parts = path.split("/")
    node_id = mounts[parts[0]]
    node = nodes[node_id]
    for part in parts[1:]:
        node_id = node["dirs"][part]
        node = nodes[node_id]
    return node


def compute(payload):
    """按扫描轮次生成映射，从每个完成目录的逻辑路径映射至 [保留文件映射,可见子目录名升序数组]。按轮累计替换节点。"""
    mounts = payload["mounts"]

    # Mutable copy of the node graph; replaces accumulate across rounds.
    nodes = {}
    for nid, node in payload["nodes"].items():
        nodes[nid] = {
            "files": dict(node.get("files", {})),
            "dirs": dict(node.get("dirs", {})),
            "ignore": set(node.get("ignore", [])),
        }

    result = []
    for scan in payload["scans"]:
        # Replaces take effect simultaneously for this round.
        for nid, definition in scan.get("replace", {}).items():
            nodes[nid] = {
                "files": dict(definition.get("files", {})),
                "dirs": dict(definition.get("dirs", {})),
                "ignore": set(definition.get("ignore", [])),
            }

        round_map = {}
        for path in scan.get("finish", []):
            node = _resolve(path, mounts, nodes)
            files = {
                name: track_id
                for name, track_id in node["files"].items()
                if name not in node["ignore"]
            }
            subdirs = sorted(
                name for name in node["dirs"] if name not in node["ignore"]
            )
            round_map[path] = [files, subdirs]
        result.append(round_map)

    return result
