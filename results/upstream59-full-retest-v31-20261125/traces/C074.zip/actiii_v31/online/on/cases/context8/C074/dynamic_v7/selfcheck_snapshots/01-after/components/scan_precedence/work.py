def compute(payload):
    """每轮返回完成的逻辑路径，按深度先父后子，同深度维持输入顺序。"""
    result = []
    for scan in payload["scans"]:
        finish = scan["finish"]
        # Stable sort by depth (number of path separators), preserving input
        # order for paths of equal depth.
        ordered = sorted(finish, key=lambda p: p.count("/"))
        result.append(ordered)
    return result
