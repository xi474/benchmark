def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    # left  = directory_snapshots: per-round {logical_path: [files_map, sorted_subdirs]}
    # right = scan_precedence: per-round ordered finished logical paths
    nodes = payload["nodes"]
    mounts = payload["mounts"]
    scans = payload["scans"]

    # Mutable node graph; replaces accumulate across rounds.
    graph = {}
    for nid, node in nodes.items():
        graph[nid] = {
            "files": dict(node.get("files", {})),
            "dirs": dict(node.get("dirs", {})),
            "ignore": set(node.get("ignore", [])),
        }

    def resolve(path):
        parts = path.split("/")
        node = graph[mounts[parts[0]]]
        for part in parts[1:]:
            node = graph[node["dirs"][part]]
        return node

    index = dict(payload["initial"])
    results = []

    for round_idx, scan in enumerate(scans):
        # Apply replaces simultaneously.
        for nid, definition in scan.get("replace", {}).items():
            graph[nid] = {
                "files": dict(definition.get("files", {})),
                "dirs": dict(definition.get("dirs", {})),
                "ignore": set(definition.get("ignore", [])),
            }

        finished = right[round_idx]
        snapshots = left[round_idx]

        # Track old/new path sets per track id.
        old_paths = {}
        new_paths = {}
        for path, tid in index.items():
            old_paths.setdefault(tid, []).append(path)

        # For each finished directory, apply its snapshot.
        for path in finished:
            files_map, subdirs = snapshots[path]
            subdir_set = set(subdirs)
            prefix = path + "/"

            # Remove old entries under this directory that are no longer
            # visible (disappeared or ignored direct entries).
            for old_path in list(index.keys()):
                if not old_path.startswith(prefix):
                    continue
                rest = old_path[len(prefix):]
                if "/" in rest:
                    # Nested entry: keep only if its direct child dir is still visible.
                    direct = rest.split("/", 1)[0]
                    if direct not in subdir_set:
                        del index[old_path]
                else:
                    # Direct file entry: keep only if still a visible file.
                    if rest not in files_map:
                        del index[old_path]

            # Overwrite direct files with current results.
            for name, tid in files_map.items():
                index[path + "/" + name] = tid

        for path, tid in index.items():
            new_paths.setdefault(tid, []).append(path)

        changed = {}
        all_ids = set(old_paths) | set(new_paths)
        for tid in all_ids:
            old = sorted(old_paths.get(tid, []))
            new = sorted(new_paths.get(tid, []))
            if old != new:
                changed[tid] = [old, new]

        results.append({"index": dict(index), "changed": changed})

    return results
