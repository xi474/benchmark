import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "components/directory_snapshots/work.py",
        "function": "compute",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "components/directory_snapshots/README.md",
                "requirement_quote": "输入字段为 nodes, mounts, scans。缺省字段沿用原题约定。",
                "reason": "README does not state a ValueError rule for non-finite values.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "components/directory_snapshots/README.md",
                "requirement_quote": "输入字段为 nodes, mounts, scans。缺省字段沿用原题约定。",
                "reason": "README does not state a ValueError rule for invalid payload types.",
            },
        },
    },
    {
        "target_path": "components/scan_precedence/work.py",
        "function": "compute",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "components/scan_precedence/README.md",
                "requirement_quote": "输入字段为 scans。缺省字段沿用原题约定。",
                "reason": "README does not state a ValueError rule for non-finite values.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "components/scan_precedence/README.md",
                "requirement_quote": "输入字段为 scans。缺省字段沿用原题约定。",
                "reason": "README does not state a ValueError rule for invalid payload types.",
            },
        },
    },
]


class TestScanPrecedence(unittest.TestCase):
    def test_parent_before_child_same_depth_input_order(self):
        # Public rule: parent before child, same depth keeps input order.
        payload = {
            "scans": [
                {"finish": ["A/d/e", "B", "A/d", "C/x"], "replace": {}},
            ]
        }
        expected = [["B", "A/d", "C/x", "A/d/e"]]
        result = call_candidate(
            "components/scan_precedence/work.py", "compute", args=[payload]
        )
        self.assertEqual(result, expected)


class TestDirectorySnapshots(unittest.TestCase):
    def test_ignore_filters_files_and_subdirs(self):
        payload = {
            "nodes": {
                "root": {
                    "files": {"a": "1", "b": "2"},
                    "dirs": {"sub": "child", "hidden": "child"},
                    "ignore": ["b", "hidden"],
                },
                "child": {"files": {}, "dirs": {}, "ignore": []},
            },
            "mounts": {"M": "root"},
            "scans": [{"finish": ["M"], "replace": {}}],
        }
        result = call_candidate(
            "components/directory_snapshots/work.py", "compute", args=[payload]
        )
        self.assertEqual(result, [{"M": [{"a": "1"}, ["sub"]]}])


class TestIntegrationCombine(unittest.TestCase):
    def test_public_contract_output(self):
        payload = {
            "nodes": {
                "root": {
                    "files": {"old": "1"},
                    "dirs": {"d": "disk", "mirror": "disk"},
                    "ignore": [],
                },
                "disk": {"files": {"intro": "2", "end": "3"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root", "B": "disk"},
            "initial": {
                "A/old": "1",
                "A/d/intro": "2",
                "A/d/gone": "4",
                "A/mirror/intro": "2",
                "B/intro": "2",
            },
            "scans": [{"finish": ["A/d", "B"], "replace": {}}],
        }
        left = [{"A/d": [{"intro": "2", "end": "3"}, []], "B": [{"intro": "2", "end": "3"}, []]}]
        right = [["B", "A/d"]]
        result = call_candidate(
            "integration.py", "combine", args=[payload, left, right]
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(
            result[0]["index"],
            {
                "A/old": "1",
                "A/d/intro": "2",
                "A/mirror/intro": "2",
                "B/intro": "2",
                "A/d/end": "3",
                "B/end": "3",
            },
        )
        self.assertEqual(
            result[0]["changed"],
            {
                "3": [[], ["A/d/end", "B/end"]],
                "4": [["A/d/gone"], []],
            },
        )

    def test_replace_removes_old_branch(self):
        payload = {
            "nodes": {
                "root": {"files": {}, "dirs": {"d": "disk"}, "ignore": []},
                "disk": {"files": {"x": "1"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root"},
            "initial": {"A/d/x": "1"},
            "scans": [
                {
                    "finish": ["A/d"],
                    "replace": {"disk": {"files": {}, "dirs": {}, "ignore": []}},
                }
            ],
        }
        left = [{"A/d": [{}, []]}]
        right = [["A/d"]]
        result = call_candidate(
            "integration.py", "combine", args=[payload, left, right]
        )
        self.assertEqual(result[0]["index"], {})
        self.assertEqual(result[0]["changed"], {"1": [["A/d/x"], []]})


if __name__ == "__main__":
    unittest.main()
