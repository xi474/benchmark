def compute(payload):
    """对 start/finish 事件按输入位置给出处理后仍活动的修改 ID 有序列表。"""
    events = payload.get("events", [])
    active = []
    result = {}
    for pos, event in enumerate(events):
        op = event.get("op")
        if op == "start":
            active.append(event["id"])
            result[str(pos)] = list(active)
        elif op == "finish":
            if event["id"] in active:
                active.remove(event["id"])
            result[str(pos)] = list(active)
    return result
