def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    events = payload.get("events", [])
    membership = left
    deadlines = right

    fetches = []
    commits = []
    audit = []

    active = []
    owed = False
    loading = False
    in_flight = None
    retry_at = None
    items = []

    fetch_counter = 0
    current_request = None  # id of the in-flight network request

    def emit_fetch(time):
        nonlocal fetch_counter, current_request, loading, owed
        fetch_counter += 1
        fid = "fetch-%d" % fetch_counter
        fetches.append({"id": fid, "time": time})
        audit.append({"time": time, "event": "fetch", "id": fid})
        current_request = fid
        loading = True
        owed = False

    def emit_retry_scheduled(time, due, reason):
        nonlocal retry_at
        retry_at = due
        audit.append({"time": time, "event": "retry_scheduled", "due": due, "reason": reason})

    def try_fetch(time):
        nonlocal owed
        if active:
            # modification in flight blocks fetch; keep obligation
            owed = True
            return
        if current_request is not None or retry_at is not None:
            # existing network request or retry timer merges obligation
            owed = True
            return
        emit_fetch(time)

    # Process events in order. Timers fire before external events at the same time.
    i = 0
    n = len(events)
    while i < n:
        event = events[i]
        time = event["time"]
        op = event.get("op")

        # Fire any due retry timer before external events at this time.
        if retry_at is not None and retry_at <= time:
            retry_at = None
            in_flight = None
            # clear old request marker and retry immediately
            current_request = None
            if active:
                owed = True
            else:
                emit_fetch(time)
            # continue processing same event after timer

        if op == "start":
            active.append(event["id"])
            audit.append({"time": time, "event": "modification_started", "id": event["id"]})
        elif op == "finish":
            if event["id"] in active:
                active.remove(event["id"])
            audit.append({"time": time, "event": "modification_finished", "id": event["id"]})
            owed = True
            # if no modification in flight and no request/timer, fetch now
            if not active and current_request is None and retry_at is None:
                emit_fetch(time)
        elif op == "refresh":
            owed = True
            if not active and current_request is None and retry_at is None:
                emit_fetch(time)
        elif op == "response":
            rid = event.get("id")
            # response corresponds to current network request
            if event.get("failed"):
                # failed: no commit, set unique now+2000 timer
                emit_retry_scheduled(time, time + 2000, "failure")
                in_flight = rid
                current_request = None
                loading = True
            elif event.get("stale") == 1:
                # stale: no commit, set unique now+1000 timer, keep in_flight
                emit_retry_scheduled(time, time + 1000, "stale")
                in_flight = rid
                current_request = None
                loading = True
            else:
                # success: commit items
                new_items = event.get("items", [])
                items.extend(new_items)
                commits.append({"time": time, "items": list(new_items)})
                audit.append({"time": time, "event": "committed", "id": rid})
                current_request = None
                in_flight = None
                # if extra obligation and no modification blocking, fetch again same processing
                if owed and not active:
                    emit_fetch(time)
                elif not owed and not active:
                    loading = False
        elif op == "advance":
            pass

        i += 1

    state = {
        "active": sorted(active),
        "owed": owed,
        "loading": loading,
        "placeholders": loading,
        "in_flight": in_flight,
        "retry_at": retry_at,
        "items": items,
    }

    return {
        "fetches": fetches,
        "commits": commits,
        "events": audit,
        "state": state,
    }
