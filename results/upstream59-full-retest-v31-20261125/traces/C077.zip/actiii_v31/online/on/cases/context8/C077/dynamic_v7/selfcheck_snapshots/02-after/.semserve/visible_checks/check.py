import unittest

# Injected by the SDK runner; present here only for local import fallback.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None


class TestTransform(unittest.TestCase):
    def test_public_fixture(self):
        payload = {
            "events": [
                {"time": 0, "op": "refresh"},
                {"time": 1, "op": "response", "id": "fetch-1", "items": ["a"]},
            ]
        }
        expected = {
            "fetches": [{"id": "fetch-1", "time": 0}],
            "commits": [{"time": 1, "items": ["a"]}],
            "events": [
                {"time": 0, "event": "fetch", "id": "fetch-1"},
                {"time": 1, "event": "committed", "id": "fetch-1"},
            ],
            "state": {
                "active": [],
                "owed": False,
                "loading": False,
                "placeholders": False,
                "in_flight": None,
                "retry_at": None,
                "items": ["a"],
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, expected)

    def test_failed_response_schedules_retry(self):
        # failed response: no commit, retry_scheduled due=now+2000 reason=failure
        payload = {
            "events": [
                {"time": 0, "op": "refresh"},
                {"time": 5, "op": "response", "id": "fetch-1", "failed": True},
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["commits"], [])
        self.assertEqual(result["state"]["items"], [])
        self.assertEqual(result["state"]["retry_at"], 2005)
        self.assertEqual(result["state"]["in_flight"], "fetch-1")
        self.assertTrue(result["state"]["loading"])
        audit = result["events"]
        self.assertIn(
            {"time": 5, "event": "retry_scheduled", "due": 2005, "reason": "failure"},
            audit,
        )

    def test_stale_response_schedules_retry(self):
        # stale=1: no commit, retry_scheduled due=now+1000 reason=stale
        payload = {
            "events": [
                {"time": 0, "op": "refresh"},
                {"time": 5, "op": "response", "id": "fetch-1", "stale": 1},
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["commits"], [])
        self.assertEqual(result["state"]["retry_at"], 1005)
        self.assertEqual(result["state"]["in_flight"], "fetch-1")
        audit = result["events"]
        self.assertIn(
            {"time": 5, "event": "retry_scheduled", "due": 1005, "reason": "stale"},
            audit,
        )

    def test_modification_blocks_fetch(self):
        # start(id) in flight: no fetch until finish
        payload = {
            "events": [
                {"time": 0, "op": "refresh"},
                {"time": 1, "op": "start", "id": "m1"},
                {"time": 2, "op": "finish", "id": "m1"},
                {"time": 3, "op": "response", "id": "fetch-1", "items": ["x"]},
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # refresh at t=0 blocked by nothing -> fetch-1 at t=0
        self.assertEqual(result["fetches"][0], {"id": "fetch-1", "time": 0})
        # finish at t=2 produces obligation; response at t=3 commits and
        # the pending obligation triggers a second fetch at t=3.
        self.assertEqual(result["fetches"], [
            {"id": "fetch-1", "time": 0},
            {"id": "fetch-2", "time": 3},
        ])
        self.assertEqual(result["state"]["items"], ["x"])

    def test_does_not_modify_input(self):
        payload = {
            "events": [
                {"time": 0, "op": "refresh"},
                {"time": 1, "op": "response", "id": "fetch-1", "items": ["a"]},
            ]
        }
        snapshot = {
            "events": [
                {"time": 0, "op": "refresh"},
                {"time": 1, "op": "response", "id": "fetch-1", "items": ["a"]},
            ]
        }
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)


if __name__ == "__main__":
    unittest.main()
