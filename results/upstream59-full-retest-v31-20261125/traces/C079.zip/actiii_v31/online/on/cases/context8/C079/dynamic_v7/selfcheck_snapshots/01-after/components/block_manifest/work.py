def compute(payload):
    """返回 [kind,index,hex] 列表；若有缩略图则排首，再按块大小顺序切出文件块。"""
    blocks = []
    thumbnail_hex = payload.get("thumbnail_hex")
    if thumbnail_hex:
        blocks.append(["thumbnail", 0, thumbnail_hex])
    file_hex = payload.get("file_hex", "")
    chunk_size = payload.get("chunk_size", 0)
    index = 0
    for i in range(0, len(file_hex), chunk_size * 2):
        blocks.append(["file", index, file_hex[i:i + chunk_size * 2]])
        index += 1
    return blocks
