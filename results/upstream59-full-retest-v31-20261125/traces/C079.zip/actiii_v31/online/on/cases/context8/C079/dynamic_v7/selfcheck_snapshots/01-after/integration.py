from hashlib import sha256

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def _sha256_hex(data: bytes) -> str:
    return sha256(data).hexdigest()


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = block_manifest value: list of [kind, index, hex]
    right = retry_faults value: dict label -> sorted unique corrupt attempt numbers
    """
    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce = int.from_bytes(bytes.fromhex(payload["base_nonce_hex"]), "big")
    max_retries = payload["max_retries"]
    corrupt_attempts = payload.get("corrupt_attempts") or {}

    aesgcm = AESGCM(session_key)

    blocks = []
    attempts = []
    notifications = []
    file_hasher = sha256()

    global_attempt = 0
    failed_block = None

    for kind, index, hex_data in left:
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(hex_data)
        aad = label.encode("utf-8")

        corrupt_set = set(corrupt_attempts.get(label, []))

        published = False
        notified = False
        for attempt in range(max_retries + 1):
            nonce_int = base_nonce + global_attempt
            nonce = nonce_int.to_bytes(12, "big")
            global_attempt += 1

            ciphertext = aesgcm.encrypt(nonce, plaintext, aad)

            if attempt in corrupt_set:
                # Flip the lowest bit of the last byte of the encrypted result.
                data = bytearray(ciphertext)
                data[-1] ^= 0x01
                ciphertext = bytes(data)

            verified = False
            try:
                decrypted = aesgcm.decrypt(nonce, ciphertext, aad)
                verified = decrypted == plaintext
            except Exception:
                verified = False

            attempts.append({"block": label, "attempt": attempt, "verified": verified})

            if verified:
                blocks.append({
                    "kind": kind,
                    "index": index,
                    "nonce_hex": nonce.hex(),
                    "ciphertext_hex": ciphertext.hex(),
                    "plaintext_sha256": _sha256_hex(plaintext),
                })
                if kind == "file":
                    file_hasher.update(plaintext)
                published = True
                break
            else:
                if not notified:
                    notifications.append({"block": label, "error": "verification_failed"})
                    notified = True

        if not published:
            failed_block = label
            break

    status = "ok" if failed_block is None else "verification_failed"

    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks,
        "attempts": attempts,
        "notifications": notifications,
        "file_sha256": file_hasher.hexdigest(),
    }
