import unittest

from hashlib import sha256


def _sha256_hex(data: bytes) -> str:
    return sha256(data).hexdigest()


class TransformContractTests(unittest.TestCase):
    """Independent visible-contract checks for C079 transform behavior."""

    def test_retry_and_corruption_verification(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "616263",
            "max_retries": 1,
            "corrupt_attempts": {"file:0": [0]},
            "environment": "production",
        }
        result = call_candidate("integration.py", "combine", args=[payload, [["file", 0, "616263"]], {}])
        self.assertEqual(result["status"], "ok")
        self.assertIsNone(result["failed_block"])
        self.assertEqual(len(result["blocks"]), 1)
        self.assertEqual(result["blocks"][0]["kind"], "file")
        self.assertEqual(result["blocks"][0]["index"], 0)
        self.assertEqual(result["blocks"][0]["plaintext_sha256"], _sha256_hex(b"abc"))
        self.assertEqual(len(result["attempts"]), 2)
        self.assertFalse(result["attempts"][0]["verified"])
        self.assertTrue(result["attempts"][1]["verified"])
        self.assertEqual(len(result["notifications"]), 1)
        self.assertEqual(result["notifications"][0]["block"], "file:0")
        self.assertEqual(result["notifications"][0]["error"], "verification_failed")
        self.assertEqual(result["file_sha256"], _sha256_hex(b"abc"))

    def test_exhaustion_stops_and_reports_failed_block(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "616263646566",
            "max_retries": 0,
            "corrupt_attempts": {"file:1": [0]},
            "environment": "production",
        }
        left = [["file", 0, "616263"], ["file", 1, "646566"]]
        result = call_candidate("integration.py", "combine", args=[payload, left, {}])
        self.assertEqual(result["status"], "verification_failed")
        self.assertEqual(result["failed_block"], "file:1")
        self.assertEqual(len(result["blocks"]), 1)
        self.assertEqual(result["blocks"][0]["index"], 0)
        self.assertEqual(result["file_sha256"], _sha256_hex(b"abc"))

    def test_thumbnail_excluded_from_file_digest(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "616263",
            "thumbnail_hex": "ff",
            "max_retries": 0,
            "environment": "production",
        }
        left = [["thumbnail", 0, "ff"], ["file", 0, "616263"]]
        result = call_candidate("integration.py", "combine", args=[payload, left, {}])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(len(result["blocks"]), 2)
        self.assertEqual(result["blocks"][0]["kind"], "thumbnail")
        self.assertEqual(result["blocks"][1]["kind"], "file")
        self.assertEqual(result["file_sha256"], _sha256_hex(b"abc"))


if __name__ == "__main__":
    unittest.main()
