import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    # Unwrap name/result envelope if present.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        data = payload["result"]
    else:
        data = payload
    if not isinstance(data, dict):
        raise ValueError("fit result must be an object")

    classes = data.get("classes")
    members = data.get("members")
    if not isinstance(classes, list) or not isinstance(members, list):
        raise ValueError("missing classes/members")

    sample_count = None
    for m in members:
        if not isinstance(m, dict):
            raise ValueError("member must be object")
        preds = m.get("predictions")
        if not isinstance(preds, list):
            raise ValueError("member predictions missing")
        if sample_count is None:
            sample_count = len(preds)
        elif len(preds) != sample_count:
            raise ValueError("member prediction length mismatch")

    if sample_count is None:
        sample_count = 0

    class_index = {c: i for i, c in enumerate(classes)}
    predictions = []
    scores = []
    for s in range(sample_count):
        tally = [0.0] * len(classes)
        for m in members:
            w = m.get("weight")
            if not _is_finite_number(w) or w < 0:
                raise ValueError("invalid member weight")
            pred = m["predictions"][s]
            if pred not in class_index:
                raise ValueError("prediction not in global classes")
            tally[class_index[pred]] += w
        best = max(tally)
        chosen = None
        for i, v in enumerate(tally):
            if v == best:
                chosen = classes[i]
                break
        predictions.append(chosen)
        scores.append(tally)

    return {"name": contract["name"], "result": {"predictions": predictions, "scores": scores}}
