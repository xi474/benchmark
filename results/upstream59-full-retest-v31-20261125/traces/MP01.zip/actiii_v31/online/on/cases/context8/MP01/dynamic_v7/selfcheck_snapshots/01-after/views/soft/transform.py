import copy


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    fit = _unwrap(payloads[0])
    if not isinstance(fit, dict):
        raise ValueError("fit result must be object")

    classes = fit["classes"]
    members = fit["members"]
    sample_count = fit["sample_count"]

    n_classes = len(classes)
    class_index = {c: i for i, c in enumerate(classes)}

    # weighted average of probabilities mapped to global classes
    totals = [[0.0] * n_classes for _ in range(sample_count)]
    weight_sum = 0.0
    for m in members:
        w = m["weight"]
        weight_sum += w
        m_classes = m["classes"]
        probs = m["probabilities"]
        for s in range(sample_count):
            row = probs[s]
            for j, cls in enumerate(m_classes):
                totals[s][class_index[cls]] += w * row[j]

    probabilities = []
    predictions = []
    for s in range(sample_count):
        row = totals[s]
        if weight_sum > 0:
            row = [v / weight_sum for v in row]
        probabilities.append(row)
        best = max(row)
        pred = classes[row.index(best)]
        predictions.append(pred)

    return {"name": contract["name"], "result": {"predictions": predictions, "probabilities": probabilities}}
