import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/fit/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/hard/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/soft/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/comparison/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        fit_payload = {
            "classes": ["red", "blue"],
            "sample_weight": [1],
            "members": [
                {
                    "id": "a",
                    "active": True,
                    "weight": 1,
                    "predictions": ["red"],
                    "classes": ["red", "blue"],
                    "probabilities": [[1.0, 0.0]],
                }
            ],
        }
        fit_contract = {"name": "fit", "operation": "fit_members", "inputs": ["x"], "output": "y"}
        fit_args = [[fit_payload], fit_contract]
        hard_payload = {
            "classes": ["red", "blue"],
            "sample_count": 1,
            "members": [{"id": "a", "weight": 1, "predictions": ["red"], "classes": ["red", "blue"]}],
        }
        hard_contract = {"name": "hard", "operation": "hard_vote", "inputs": ["x"], "output": "y"}
        hard_args = [[hard_payload], hard_contract]
        soft_payload = {
            "classes": ["red", "blue"],
            "sample_count": 1,
            "members": [{"id": "a", "weight": 1, "classes": ["red", "blue"], "probabilities": [[1.0, 0.0]]}],
        }
        soft_contract = {"name": "soft", "operation": "soft_vote", "inputs": ["x"], "output": "y"}
        soft_args = [[soft_payload], soft_contract]
        cmp_payloads = [{"predictions": ["red"]}, {"predictions": ["red"]}]
        cmp_contract = {"name": "comparison", "operation": "vote_comparison", "inputs": ["x", "y"], "output": "z"}
        cmp_args = [cmp_payloads, cmp_contract]

        probes = [
            ("domains/fit/transform.py", "nonfinite_unknown_field", "README.md", "未知额外字段可忽略，但其中非有限JSON仍非法。", fit_args),
            ("domains/fit/transform.py", "invalid_payload_type", "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。", fit_args),
            ("views/hard/transform.py", "nonfinite_unknown_field", "README.md", "未知额外字段可忽略，但其中非有限JSON仍非法。", hard_args),
            ("views/hard/transform.py", "invalid_payload_type", "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。", hard_args),
            ("views/soft/transform.py", "nonfinite_unknown_field", "README.md", "未知额外字段可忽略，但其中非有限JSON仍非法。", soft_args),
            ("views/soft/transform.py", "invalid_payload_type", "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。", soft_args),
            ("views/comparison/transform.py", "nonfinite_unknown_field", "README.md", "未知额外字段可忽略，但其中非有限JSON仍非法。", cmp_args),
            ("views/comparison/transform.py", "invalid_payload_type", "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。", cmp_args),
        ]
        for target, rule, doc, quote, args in probes:
            with self.subTest(target=target, rule=rule):
                check_api_boundary(target, rule=rule, contract_path=doc, requirement_quote=quote, args=args)


class TestFitMembers(unittest.TestCase):
    def test_fit_members_output(self):
        payload = {
            "classes": ["red", "blue"],
            "sample_weight": [1, 2],
            "members": [
                {
                    "id": "a",
                    "active": True,
                    "weight": 1,
                    "predictions": ["red", "blue"],
                    "classes": ["red", "blue"],
                    "probabilities": [[0.9, 0.1], [0.2, 0.8]],
                },
                {
                    "id": "b",
                    "active": False,
                    "weight": 5,
                    "predictions": ["blue", "red"],
                    "classes": ["blue", "red"],
                    "probabilities": [[0.1, 0.9], [0.8, 0.2]],
                },
            ],
        }
        contract = {"name": "fit", "operation": "fit_members", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/fit/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "fit")
        r = result["result"]
        self.assertEqual(r["classes"], ["red", "blue"])
        self.assertEqual(r["sample_count"], 2)
        self.assertEqual(len(r["members"]), 1)
        m = r["members"][0]
        self.assertEqual(m["id"], "a")
        self.assertEqual(m["fit_weight"], [1, 2])
        self.assertNotIn("b", [x["id"] for x in r["members"]])

    def test_fit_members_inactive_ignores_bad_fields(self):
        payload = {
            "classes": ["red", "blue"],
            "sample_weight": [1],
            "members": [
                {
                    "id": "a",
                    "active": True,
                    "weight": 1,
                    "predictions": ["red"],
                    "classes": ["red", "blue"],
                    "probabilities": [[1.0, 0.0]],
                },
                {
                    "id": "b",
                    "active": False,
                },
            ],
        }
        contract = {"name": "fit", "operation": "fit_members", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/fit/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(len(result["result"]["members"]), 1)


class TestHardVote(unittest.TestCase):
    def test_hard_vote_weighted_tiebreak(self):
        fit = {
            "classes": ["red", "blue"],
            "sample_count": 2,
            "members": [
                {
                    "id": "a",
                    "weight": 1,
                    "predictions": ["red", "blue"],
                    "classes": ["red", "blue"],
                },
                {
                    "id": "b",
                    "weight": 2,
                    "predictions": ["blue", "red"],
                    "classes": ["blue", "red"],
                },
            ],
        }
        contract = {"name": "hard", "operation": "hard_vote", "inputs": ["x"], "output": "y"}
        result = call_candidate("views/hard/transform.py", "transform", args=[[fit], contract])
        r = result["result"]
        # sample 0: red=1, blue=2 -> blue; sample 1: blue=1, red=2 -> red
        self.assertEqual(r["predictions"], ["blue", "red"])
        self.assertEqual(r["scores"], [[1, 2], [2, 1]])


class TestSoftVote(unittest.TestCase):
    def test_soft_vote_maps_member_classes(self):
        fit = {
            "classes": ["red", "blue"],
            "sample_count": 1,
            "members": [
                {
                    "id": "a",
                    "weight": 1,
                    "classes": ["blue", "red"],
                    "probabilities": [[0.2, 0.8]],
                },
                {
                    "id": "b",
                    "weight": 1,
                    "classes": ["red", "blue"],
                    "probabilities": [[0.6, 0.4]],
                },
            ],
        }
        contract = {"name": "soft", "operation": "soft_vote", "inputs": ["x"], "output": "y"}
        result = call_candidate("views/soft/transform.py", "transform", args=[[fit], contract])
        r = result["result"]
        # member a: red=0.8, blue=0.2; member b: red=0.6, blue=0.4
        # avg: red=0.7, blue=0.3
        self.assertEqual(r["predictions"], ["red"])
        self.assertAlmostEqual(r["probabilities"][0][0], 0.7)
        self.assertAlmostEqual(r["probabilities"][0][1], 0.3)


class TestComparison(unittest.TestCase):
    def test_comparison_disagreements(self):
        hard = {"predictions": ["red", "blue", "red"]}
        soft = {"predictions": ["red", "red", "red"]}
        contract = {"name": "comparison", "operation": "vote_comparison", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("views/comparison/transform.py", "transform", args=[[hard, soft], contract])
        r = result["result"]
        self.assertEqual(r["hard"], ["red", "blue", "red"])
        self.assertEqual(r["soft"], ["red", "red", "red"])
        self.assertEqual(r["disagreements"], [1])

    def test_comparison_sample_count_mismatch(self):
        hard = {"predictions": ["red"]}
        soft = {"predictions": ["red", "blue"]}
        contract = {"name": "comparison", "operation": "vote_comparison", "inputs": ["x", "y"], "output": "z"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("views/comparison/transform.py", "transform", args=[[hard, soft], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
