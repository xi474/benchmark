import copy
import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _require(cond, msg="invalid input"):
    if not cond:
        raise ValueError(msg)


def transform(payloads, contract):
    _require(len(payloads) == len(contract["inputs"]), "payload count mismatch")
    raw = payloads[0]
    _reject_nonfinite(raw)
    # If the object has exactly keys name/result, only result is business input.
    if isinstance(raw, dict) and set(raw) == {"name", "result"}:
        raw = raw["result"]
    _require(isinstance(raw, dict), "input must be object")

    classes = raw.get("classes")
    _require(isinstance(classes, list) and len(classes) > 0, "classes required")
    seen = set()
    for c in classes:
        _require(isinstance(c, str) and c.strip() != "", "class must be non-empty string")
        _require(c not in seen, "duplicate class")
        seen.add(c)

    sample_weight = raw.get("sample_weight")
    _require(isinstance(sample_weight, list), "sample_weight required")
    for w in sample_weight:
        _require(_is_finite_number(w) and w >= 0, "sample_weight must be non-negative finite number")
    sample_count = len(sample_weight)

    members = raw.get("members")
    _require(isinstance(members, list), "members required")

    active_members = []
    ids = set()
    for m in members:
        _require(isinstance(m, dict), "member must be object")
        _require("id" in m and isinstance(m["id"], str) and m["id"].strip() != "", "member id required")
        _require(m["id"] not in ids, "duplicate member id")
        ids.add(m["id"])
        _require("active" in m and isinstance(m["active"], bool), "member active must be bool")
        if not m["active"]:
            continue
        # active member: validate weight, predictions, classes, probabilities
        _require("weight" in m and _is_finite_number(m["weight"]) and m["weight"] >= 0,
                 "member weight must be non-negative finite number")
        _require("predictions" in m and isinstance(m["predictions"], list), "predictions required")
        _require(len(m["predictions"]) == sample_count, "predictions length mismatch")
        for p in m["predictions"]:
            _require(p in classes, "prediction label not in global classes")
        _require("classes" in m and isinstance(m["classes"], list), "member classes required")
        _require(sorted(m["classes"]) == sorted(classes), "member classes must be permutation of global classes")
        _require("probabilities" in m and isinstance(m["probabilities"], list), "probabilities required")
        _require(len(m["probabilities"]) == sample_count, "probabilities length mismatch")
        for row in m["probabilities"]:
            _require(isinstance(row, list) and len(row) == len(m["classes"]),
                     "probability row size mismatch")
            for v in row:
                _require(_is_finite_number(v) and v >= 0, "probability must be non-negative finite number")
            _require(abs(sum(row) - 1.0) <= 1e-9, "probability row must sum to 1")
        active_members.append(m)

    _require(len(active_members) >= 1, "at least one active member required")
    total_weight = sum(m["weight"] for m in active_members)
    _require(total_weight > 0, "active member weight sum must be positive")

    result_members = []
    for m in active_members:
        nm = copy.deepcopy(m)
        nm["fit_weight"] = list(sample_weight)
        result_members.append(nm)

    return {
        "name": contract["name"],
        "result": {
            "classes": list(classes),
            "sample_count": sample_count,
            "members": result_members,
        },
    }
