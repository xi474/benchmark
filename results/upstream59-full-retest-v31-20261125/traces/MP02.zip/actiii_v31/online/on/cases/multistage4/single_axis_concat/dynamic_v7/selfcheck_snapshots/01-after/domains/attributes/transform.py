def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = _unwrap(payloads[0])
    if not isinstance(payload, dict):
        raise ValueError("input must be an object")
    pieces = payload.get("pieces")
    if pieces is None:
        raise ValueError("missing pieces")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    policy = payload.get("attribute_policy")
    if policy not in ("drop_conflicts", "first"):
        raise ValueError("invalid attribute_policy")

    merged = {}
    conflicts = set()
    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be an object")
        attrs = piece.get("attrs")
        if attrs is None:
            raise ValueError("missing attrs")
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be an object")
        for key, value in attrs.items():
            if policy == "first":
                if key not in merged:
                    merged[key] = value
            else:  # drop_conflicts
                if key not in merged:
                    merged[key] = value
                elif key not in conflicts and merged[key] != value:
                    conflicts.add(key)

    if policy == "drop_conflicts":
        for key in conflicts:
            del merged[key]

    return {
        "name": contract["name"],
        "result": {
            "attrs": merged,
            "conflicts": sorted(conflicts),
        },
    }
