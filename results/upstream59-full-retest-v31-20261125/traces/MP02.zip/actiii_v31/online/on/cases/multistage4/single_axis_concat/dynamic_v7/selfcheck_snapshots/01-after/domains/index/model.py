import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively reject any non-finite float (NaN/Infinity)."""
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def load_payload(path):
    """Read a UTF-8 JSON file; only object/array top-level is legal.

    Illegal JSON, other top-level types, and any nested NaN/Infinity raise
    ValueError.
    """
    try:
        text = Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        raise ValueError("cannot read payload") from exc
    try:
        data = json.loads(text)
    except ValueError as exc:
        raise ValueError("invalid JSON") from exc
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data)
    return data
