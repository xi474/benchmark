import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, transform, write output, return wrapper."""
    contract = load_payload(contract_path)
    payloads = [load_payload(Path(root) / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    out = Path(root) / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
    return result


def _write_json(path, obj):
    text = json.dumps(
        obj, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
    ) + "\n"
    Path(path).write_text(text, encoding="utf-8")


if __name__ == "__main__":
    root = Path.cwd()
    contract_path = Path(__file__).with_name("contract.json")
    contract = load_payload(contract_path)
    result = build_component(root, contract_path)
    out = Path(root) / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
