import json
import subprocess
import sys
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = [
        x for x in ROOT.rglob('contract.json')
        if 'outputs' not in x.relative_to(ROOT).parts
    ]
    if not contracts:
        raise ValueError('no contracts')

    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        by_name[c['name']] = (cp, c)

    output_to_name = {}
    for name, (cp, c) in by_name.items():
        output_to_name[str(ROOT / c['output'])] = name

    deps = {}
    for name, (cp, c) in by_name.items():
        d = set()
        for inp in c['inputs']:
            key = str(ROOT / inp)
            if key in output_to_name:
                d.add(output_to_name[key])
        deps[name] = d

    indeg = {name: len(deps[name]) for name in by_name}
    ready = deque(sorted(name for name in by_name if indeg[name] == 0))
    order = []
    while ready:
        name = ready.popleft()
        order.append(name)
        for other, d in deps.items():
            if name in d:
                indeg[other] -= 1
                if indeg[other] == 0:
                    ready.append(other)
    if len(order) != len(by_name):
        raise ValueError('dependency cycle detected')

    for name in order:
        cp, c = by_name[name]
        subprocess.run(
            [sys.executable, str(cp.with_name('render.py'))],
            cwd=ROOT, check=True, timeout=180,
        )

    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT, check=True, timeout=180,
    )
    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT, check=True, timeout=180,
    )


if __name__ == '__main__':
    main()
