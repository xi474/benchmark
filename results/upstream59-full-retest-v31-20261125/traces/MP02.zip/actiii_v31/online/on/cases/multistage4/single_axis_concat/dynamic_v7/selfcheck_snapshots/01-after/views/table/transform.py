def _unwrap(payload):
    # When an input object has keys exactly name/result, only its result is
    # the business input; other objects are interpreted as-is.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    original = _unwrap(payloads[0])
    index_result = _unwrap(payloads[1])
    attributes_result = _unwrap(payloads[2])

    columns = list(original["columns"])
    pieces = original["pieces"]
    by_id = {p["id"]: p for p in pieces}

    order = index_result["order"]
    coordinates = []
    data = []
    for entry in order:
        piece = by_id[entry["piece"]]
        row = entry["row"]
        coordinates.append(entry["coordinate"])
        data.append(list(piece["data"][row]))

    attrs = attributes_result["attrs"]
    attribute_conflicts = attributes_result["conflicts"]

    return {
        "name": contract["name"],
        "result": {
            "coordinates": coordinates,
            "columns": columns,
            "data": data,
            "attrs": attrs,
            "attribute_conflicts": attribute_conflicts,
        },
    }
