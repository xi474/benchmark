import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/index/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/attributes/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/table/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_index_boundary(self):
        payload = {
            "columns": ["a"],
            "pieces": [{"id": "p1", "coordinates": [1], "data": [[1]], "attrs": {}}],
        }
        contract = {"name": "index", "inputs": ["x"], "output": "y"}
        check_api_boundary("domains/index/transform.py", rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[payload], contract])
        check_api_boundary("domains/index/transform.py", rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[[payload], contract])

    def test_attributes_boundary(self):
        payload = {
            "columns": ["a"],
            "attribute_policy": "first",
            "pieces": [{"id": "p1", "coordinates": [1], "data": [[1]], "attrs": {}}],
        }
        contract = {"name": "attributes", "inputs": ["x"], "output": "y"}
        check_api_boundary("domains/attributes/transform.py", rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[payload], contract])
        check_api_boundary("domains/attributes/transform.py", rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[[payload], contract])

    def test_table_boundary(self):
        original = {
            "columns": ["a"],
            "pieces": [{"id": "p1", "coordinates": [1], "data": [[1]], "attrs": {}}],
        }
        index = {"columns": ["a"], "order": [{"coordinate": 1, "piece": "p1", "row": 0}]}
        attrs = {"attrs": {}, "conflicts": []}
        contract = {"name": "table", "inputs": ["a", "b", "c"], "output": "y"}
        check_api_boundary("views/table/transform.py", rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[original, index, attrs], contract])
        check_api_boundary("views/table/transform.py", rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[[original, index, attrs], contract])


class TestSegmentIndex(unittest.TestCase):
    def test_order_sorted_by_coordinate(self):
        payload = {
            "columns": ["a", "b"],
            "pieces": [
                {"id": "p1", "coordinates": [5, 1], "data": [[50, 51], [10, 11]], "attrs": {}},
                {"id": "p2", "coordinates": [3, 7], "data": [[30, 31], [70, 71]], "attrs": {}},
            ],
        }
        contract = {"name": "index", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/index/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "index")
        order = result["result"]["order"]
        coords = [e["coordinate"] for e in order]
        self.assertEqual(coords, [1, 3, 5, 7])
        self.assertEqual(result["result"]["columns"], ["a", "b"])

    def test_overlapping_coordinate_raises(self):
        payload = {
            "columns": ["a"],
            "pieces": [
                {"id": "p1", "coordinates": [1], "data": [[1]], "attrs": {}},
                {"id": "p2", "coordinates": [1], "data": [[2]], "attrs": {}},
            ],
        }
        contract = {"name": "index", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/index/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestSegmentAttributes(unittest.TestCase):
    def test_drop_conflicts(self):
        payload = {
            "columns": ["a"],
            "attribute_policy": "drop_conflicts",
            "pieces": [
                {"id": "p1", "coordinates": [1], "data": [[1]], "attrs": {"x": 1, "y": 2}},
                {"id": "p2", "coordinates": [2], "data": [[2]], "attrs": {"x": 1, "y": 3}},
            ],
        }
        contract = {"name": "attributes", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/attributes/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["attrs"], {"x": 1})
        self.assertEqual(result["result"]["conflicts"], ["y"])

    def test_first_policy(self):
        payload = {
            "columns": ["a"],
            "attribute_policy": "first",
            "pieces": [
                {"id": "p1", "coordinates": [1], "data": [[1]], "attrs": {"x": 1}},
                {"id": "p2", "coordinates": [2], "data": [[2]], "attrs": {"x": 2}},
            ],
        }
        contract = {"name": "attributes", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/attributes/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["attrs"], {"x": 1})
        self.assertEqual(result["result"]["conflicts"], [])


class TestSegmentAssemble(unittest.TestCase):
    def test_assemble_preserves_column_order(self):
        original = {
            "columns": ["a", "c", "b"],
            "pieces": [
                {"id": "p1", "coordinates": [2, 0], "data": [[20, 21, 22], [0, 1, 2]], "attrs": {}},
            ],
        }
        index = {"columns": ["a", "c", "b"], "order": [
            {"coordinate": 0, "piece": "p1", "row": 1},
            {"coordinate": 2, "piece": "p1", "row": 0},
        ]}
        attrs = {"attrs": {"u": "m"}, "conflicts": []}
        contract = {"name": "table", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate("views/table/transform.py", "transform", args=[[original, index, attrs], contract])
        r = result["result"]
        self.assertEqual(r["coordinates"], [0, 2])
        self.assertEqual(r["columns"], ["a", "c", "b"])
        self.assertEqual(r["data"], [[0, 1, 2], [20, 21, 22]])
        self.assertEqual(r["attrs"], {"u": "m"})
        self.assertEqual(r["attribute_conflicts"], [])


if __name__ == "__main__":
    unittest.main()
