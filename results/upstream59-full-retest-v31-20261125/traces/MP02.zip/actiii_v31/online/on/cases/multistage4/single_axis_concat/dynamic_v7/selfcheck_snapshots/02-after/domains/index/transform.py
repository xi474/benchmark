import math


def _check_finite(obj):
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def _is_finite_number(value):
    """True for int/float that is finite and not bool."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    return False


def transform(payloads, contract):
    """segment_index: order rows by the single varying coordinate axis.

    payloads must match contract['inputs'] order and count. Returns
    {"name": contract["name"], "result": {...}}.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("input must be an object")
    _check_finite(payload)

    columns = payload.get("columns")
    pieces = payload.get("pieces")
    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")

    # columns: unique non-empty strings
    seen_cols = set()
    for col in columns:
        if not isinstance(col, str) or not col.strip():
            raise ValueError("column must be non-empty string")
        if col in seen_cols:
            raise ValueError("duplicate column")
        seen_cols.add(col)

    piece_ids = set()
    all_coords = set()
    order = []

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be an object")
        pid = piece.get("id")
        coords = piece.get("coordinates")
        data = piece.get("data")
        if not isinstance(pid, str) or not pid.strip():
            raise ValueError("piece id must be non-empty string")
        if pid in piece_ids:
            raise ValueError("duplicate piece id")
        piece_ids.add(pid)
        if not isinstance(coords, list):
            raise ValueError("coordinates must be a list")
        if not isinstance(data, list):
            raise ValueError("data must be a list")
        if len(coords) != len(data):
            raise ValueError("coordinates/data length mismatch")

        for coord in coords:
            if not _is_finite_number(coord):
                raise ValueError("coordinate must be finite number")
            if coord in all_coords:
                raise ValueError("overlapping coordinate")
            all_coords.add(coord)

        for row in data:
            if not isinstance(row, list):
                raise ValueError("data row must be a list")
            if len(row) != len(columns):
                raise ValueError("data row width mismatch")
            for value in row:
                if not _is_finite_number(value):
                    raise ValueError("data value must be finite number")

        for i, coord in enumerate(coords):
            order.append({"coordinate": coord, "piece": pid, "row": i})

    order.sort(key=lambda entry: entry["coordinate"])

    return {"name": contract["name"], "result": {"columns": columns, "order": order}}
