import math


def _check_finite(obj):
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def _unwrap(payload):
    # When an input object has keys exactly name/result, only its result is
    # the business input; other objects are interpreted as-is.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    original = _unwrap(payloads[0])
    index_result = _unwrap(payloads[1])
    attributes_result = _unwrap(payloads[2])

    if not isinstance(original, dict):
        raise ValueError("input must be an object")
    _check_finite(original)
    _check_finite(index_result)
    _check_finite(attributes_result)

    columns = list(original["columns"])
    pieces = original["pieces"]
    by_id = {p["id"]: p for p in pieces}

    order = index_result["order"]
    coordinates = []
    data = []
    for entry in order:
        piece = by_id[entry["piece"]]
        row = entry["row"]
        coordinates.append(entry["coordinate"])
        data.append(list(piece["data"][row]))

    attrs = attributes_result["attrs"]
    attribute_conflicts = attributes_result["conflicts"]

    return {
        "name": contract["name"],
        "result": {
            "coordinates": coordinates,
            "columns": columns,
            "data": data,
            "attrs": attrs,
            "attribute_conflicts": attribute_conflicts,
        },
    }
