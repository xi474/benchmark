def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if "aix" not in payload:
        raise ValueError("missing aix")
    text = payload["aix"]
    if not isinstance(text, str):
        raise ValueError("aix must be string")

    records = []
    current = None  # dict with mount, dev, vfs, options

    def flush():
        nonlocal current
        if current is None:
            return
        if "dev" not in current:
            raise ValueError("missing dev")
        records.append({
            "device": current["dev"],
            "mount": current["mount"],
            "fstype": current.get("vfs", "jfs2"),
            "options": current.get("options", "rw"),
        })
        current = None

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith(":"):
            # section header: mount point
            flush()
            mount = line[:-1].strip()
            if not mount:
                raise ValueError("empty mount")
            current = {"mount": mount}
            continue
        if "=" not in line:
            raise ValueError("bad aix line")
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if current is None:
            raise ValueError("attribute without section header")
        if key not in ("dev", "vfs", "options"):
            raise ValueError("unknown key")
        if key in current:
            raise ValueError("duplicate key")
        current[key] = value
    flush()

    return {"name": contract["name"], "result": {"records": records}}
