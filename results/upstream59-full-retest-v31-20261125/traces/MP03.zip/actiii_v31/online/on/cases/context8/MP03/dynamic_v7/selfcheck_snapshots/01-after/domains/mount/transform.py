import re


def _unescape(s):
    return s.replace("\\040", " ").replace("\\011", "\t").replace("\\134", "\\")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict) or "mount" not in payload:
        raise ValueError("missing mount field")
    text = payload["mount"]
    if not isinstance(text, str):
        raise ValueError("mount must be string")

    records = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(
            r"^(\S+) on (\S+) type (\S+) \(([^)]*)\)$", line
        )
        if m is None:
            raise ValueError("invalid mount line")
        device, mountpoint, fstype, opts = m.groups()
        if not opts:
            raise ValueError("empty options")
        device = _unescape(device)
        mountpoint = _unescape(mountpoint)
        options = sorted(set(o for o in opts.split(",") if o))
        records.append({
            "device": device,
            "mount": mountpoint,
            "fstype": fstype,
            "options": options,
        })

    return {"name": contract["name"], "result": {"records": records}}
