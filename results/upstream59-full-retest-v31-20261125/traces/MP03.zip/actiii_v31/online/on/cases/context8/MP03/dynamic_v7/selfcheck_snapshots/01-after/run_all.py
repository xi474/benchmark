import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise ValueError("no contracts")

    # topological order by dependency: inputs that are outputs of other
    # components must be produced first.
    produced = set()
    remaining = list(contracts)
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [
                (ROOT / p).resolve()
                for p in c.get("inputs", [])
                if str(ROOT / p).startswith(str(ROOT / "outputs"))
            ]
            if all(d in produced for d in deps):
                subprocess.run(
                    [sys.executable, str(cp.with_name("render.py"))],
                    cwd=ROOT, check=True, timeout=60,
                )
                produced.add((ROOT / c["output"]).resolve())
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise ValueError("dependency cycle or missing dependency")

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT, check=True, timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT, check=True, timeout=60,
    )


if __name__ == "__main__":
    main()
