def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    sources = []
    for payload in payloads:
        if isinstance(payload, dict) and set(payload) == {"name", "result"}:
            payload = payload["result"]
        if not isinstance(payload, dict) or "records" not in payload:
            raise ValueError("missing records")
        records = payload["records"]
        if not isinstance(records, list):
            raise ValueError("records must be list")
        sources.append(records)

    source_names = ["fstab", "aix", "mount"]

    evidence = {}
    for si, records in enumerate(sources):
        for rec in records:
            if not isinstance(rec, dict):
                raise ValueError("record must be object")
            mount = rec.get("mount")
            if mount is None:
                raise ValueError("record missing mount")
            evidence.setdefault(mount, []).append(
                {"source": source_names[si], **rec}
            )

    records_out = []
    conflicts = []
    for mount in sorted(evidence.keys()):
        ev = evidence[mount]
        winner = ev[0]
        winner_rec = {k: v for k, v in winner.items() if k != "source"}
        records_out.append({"source": winner["source"], **winner_rec})

        base = (winner_rec.get("device"), winner_rec.get("fstype"),
                tuple(winner_rec.get("options", [])))
        is_conflict = False
        for rec in ev:
            r = {k: v for k, v in rec.items() if k != "source"}
            cur = (r.get("device"), r.get("fstype"),
                   tuple(r.get("options", [])))
            if cur != base:
                is_conflict = True
                break
        if is_conflict:
            conflicts.append({"mount": mount, "evidence": ev})

    return {"name": contract["name"],
            "result": {"records": records_out, "conflicts": conflicts}}
