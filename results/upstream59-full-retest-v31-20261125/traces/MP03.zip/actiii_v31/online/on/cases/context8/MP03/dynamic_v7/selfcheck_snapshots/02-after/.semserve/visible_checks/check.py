import unittest

# Injected names provided by the visible-contract SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:  # pragma: no cover - names are injected at runtime
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None

README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/fstab/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/aix/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/mount/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/merged/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class ApiBoundaryTests(unittest.TestCase):
    def test_api_boundary_probes(self):
        cases = [
            ("domains/fstab/transform.py", {"fstab": "/dev/sda1 / ext4 rw 0 0\n"}),
            ("domains/aix/transform.py", {"aix": "/data:\n  dev = /dev/aix\n"}),
            ("domains/mount/transform.py", {"mount": "/dev/sda1 on / type ext4 (rw)\n"}),
        ]
        for target, payload in cases:
            with self.subTest(target=target):
                check_api_boundary(
                    target, rule="nonfinite_unknown_field",
                    contract_path="README.md",
                    requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
                    args=[[payload], {"name": "x", "operation": "op",
                                      "inputs": ["i"], "output": "o"}],
                )
                check_api_boundary(
                    target, rule="invalid_payload_type",
                    contract_path="README.md",
                    requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                    args=[[payload], {"name": "x", "operation": "op",
                                      "inputs": ["i"], "output": "o"}],
                )

    def test_merged_api_boundary_probes(self):
        fstab = {"name": "fstab", "result": {"records": []}}
        aix = {"name": "aix", "result": {"records": []}}
        mount = {"name": "mount", "result": {"records": []}}
        payloads = [fstab, aix, mount]
        contract = {"name": "merged", "operation": "mount_merge",
                    "inputs": ["a", "b", "c"], "output": "o"}
        check_api_boundary(
            "views/merged/transform.py", rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[payloads, contract],
        )
        check_api_boundary(
            "views/merged/transform.py", rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[payloads, contract],
        )


class FstabParseTests(unittest.TestCase):
    def test_fstab_parse_basic(self):
        payload = {"fstab": "/dev/sda1 / ext4 rw 0 0\n"}
        contract = {"name": "fstab", "operation": "fstab_parse",
                    "inputs": ["inputs/case.json"], "output": "outputs/fstab.json"}
        result = call_candidate("domains/fstab/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "fstab")
        self.assertEqual(result["result"]["records"], [
            {"device": "/dev/sda1", "mount": "/", "fstype": "ext4",
             "options": ["rw"]},
        ])

    def test_fstab_parse_escape_and_options(self):
        payload = {"fstab": "/dev/x /with\\040space xfs ro,ro,nosuid\n"}
        contract = {"name": "fstab", "operation": "fstab_parse",
                    "inputs": ["inputs/case.json"], "output": "outputs/fstab.json"}
        result = call_candidate("domains/fstab/transform.py", "transform",
                                args=[[payload], contract])
        rec = result["result"]["records"][0]
        self.assertEqual(rec["mount"], "/with space")
        self.assertEqual(rec["options"], ["nosuid", "ro"])


class AixParseTests(unittest.TestCase):
    def test_aix_parse_defaults(self):
        payload = {"aix": "/data:\n  dev = /dev/aix\n"}
        contract = {"name": "aix", "operation": "aix_parse",
                    "inputs": ["inputs/case.json"], "output": "outputs/aix.json"}
        result = call_candidate("domains/aix/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["records"], [
            {"device": "/dev/aix", "mount": "/data", "fstype": "jfs2",
             "options": "rw"},
        ])

    def test_aix_parse_missing_dev_raises(self):
        payload = {"aix": "/data:\n  vfs = jfs2\n"}
        contract = {"name": "aix", "operation": "aix_parse",
                    "inputs": ["inputs/case.json"], "output": "outputs/aix.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/aix/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"],
                         "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class MountParseTests(unittest.TestCase):
    def test_mount_parse_basic(self):
        payload = {"mount": "/dev/sda1 on / type ext4 (rw,relatime)\n"}
        contract = {"name": "mount", "operation": "mount_parse",
                    "inputs": ["inputs/case.json"], "output": "outputs/mount.json"}
        result = call_candidate("domains/mount/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["records"], [
            {"device": "/dev/sda1", "mount": "/", "fstype": "ext4",
             "options": ["relatime", "rw"]},
        ])

    def test_mount_parse_empty_options_raises(self):
        payload = {"mount": "/dev/sda1 on / type ext4 ()\n"}
        contract = {"name": "mount", "operation": "mount_parse",
                    "inputs": ["inputs/case.json"], "output": "outputs/mount.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/mount/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"],
                         "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class MergeTests(unittest.TestCase):
    def test_merge_priority_and_conflict(self):
        fstab = {"name": "fstab", "result": {"records": [
            {"device": "/dev/a", "mount": "/m", "fstype": "ext4",
             "options": ["rw"]}]}}
        aix = {"name": "aix", "result": {"records": [
            {"device": "/dev/b", "mount": "/m", "fstype": "jfs2",
             "options": "rw"}]}}
        mount = {"name": "mount", "result": {"records": []}}
        contract = {"name": "merged", "operation": "mount_merge",
                    "inputs": ["outputs/fstab.json", "outputs/aix.json",
                               "outputs/mount.json"],
                    "output": "outputs/merged.json"}
        result = call_candidate("views/merged/transform.py", "transform",
                                args=[[fstab, aix, mount], contract])
        self.assertEqual(result["result"]["records"], [
            {"source": "fstab", "device": "/dev/a", "mount": "/m",
             "fstype": "ext4", "options": ["rw"]},
        ])
        self.assertEqual(len(result["result"]["conflicts"]), 1)
        self.assertEqual(result["result"]["conflicts"][0]["mount"], "/m")
        self.assertEqual(len(result["result"]["conflicts"][0]["evidence"]), 2)


if __name__ == "__main__":
    unittest.main()
