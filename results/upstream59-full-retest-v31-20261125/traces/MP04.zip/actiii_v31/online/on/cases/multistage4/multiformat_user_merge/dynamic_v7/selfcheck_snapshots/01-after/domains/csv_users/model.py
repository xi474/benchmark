import json
from pathlib import Path


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if obj != obj or obj in (float("inf"), float("-inf")):
            raise ValueError("non-finite number")
        return
    if isinstance(obj, list):
        for item in obj:
            _reject_nonfinite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _reject_nonfinite(value)


def load_payload(path):
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text, parse_constant=lambda c: (_ for _ in ()).throw(ValueError("non-finite number")))
    except ValueError:
        raise
    if isinstance(data, (dict, list)):
        _reject_nonfinite(data)
        return data
    raise ValueError("top-level must be object or array")
