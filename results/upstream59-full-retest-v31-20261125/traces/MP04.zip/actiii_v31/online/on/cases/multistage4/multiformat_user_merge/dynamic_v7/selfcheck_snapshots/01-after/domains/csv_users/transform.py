import csv
import io
from datetime import datetime


def _parse_joined(value):
    # value is a non-empty string
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    raise ValueError("invalid joined date")


def _normalize_id(raw):
    if isinstance(raw, bool):
        raise ValueError("bool id not allowed")
    if isinstance(raw, int):
        return str(raw)
    if isinstance(raw, str):
        s = raw.strip()
        if s == "":
            raise ValueError("empty id")
        return s
    raise ValueError("invalid id type")


def _field_value(row, *names):
    # first present (non-missing) value wins among the alias names
    for n in names:
        if n in row and row[n] != "":
            return row[n]
    return None


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    csv_text = payload["csv_text"]
    if not isinstance(csv_text, str):
        raise ValueError("csv_text must be str")

    if csv_text == "":
        return {"name": contract["name"], "result": {"records": []}}

    reader = csv.reader(io.StringIO(csv_text))
    rows = list(reader)
    if not rows:
        return {"name": contract["name"], "result": {"records": []}}

    header = rows[0]
    if len(set(header)) != len(header):
        raise ValueError("duplicate columns")
    if "id" not in header and "user_id" not in header:
        raise ValueError("missing id column")

    # column names must be unique and no missing/extra columns
    # (extra columns are not allowed per spec: "列名唯一且无缺列/额外列")
    # We interpret: header must contain exactly the recognized columns.
    allowed = {"id", "user_id", "name", "full_name", "email", "mail", "joined", "joined_at"}
    for col in header:
        if col not in allowed:
            raise ValueError("extra column")

    merged = {}
    order = []
    for row in rows[1:]:
        if len(row) != len(header):
            raise ValueError("row column count mismatch")
        rec = dict(zip(header, row))
        raw_id = _field_value(rec, "id", "user_id")
        if raw_id is None:
            raise ValueError("missing id")
        uid = _normalize_id(raw_id)
        if uid not in merged:
            merged[uid] = {}
            order.append(uid)
        entry = merged[uid]
        # name
        name = _field_value(rec, "name", "full_name")
        if name is not None:
            entry["name"] = name
        email = _field_value(rec, "email", "mail")
        if email is not None:
            entry["email"] = email
        joined = _field_value(rec, "joined", "joined_at")
        if joined is not None:
            entry["joined"] = _parse_joined(joined)

    records = []
    for uid in sorted(merged):
        entry = merged[uid]
        rec = {"id": uid}
        if "name" in entry:
            rec["name"] = entry["name"]
        if "email" in entry:
            rec["email"] = entry["email"]
        if "joined" in entry:
            rec["joined"] = entry["joined"]
        records.append(rec)

    return {"name": contract["name"], "result": {"records": records}}
