import json
from pathlib import Path


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if obj != obj or obj in (float("inf"), float("-inf")):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _reject_nonfinite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _reject_nonfinite(value)


def _reject_constant(value):
    raise ValueError("non-finite number")


def load_payload(path):
    text = Path(path).read_text(encoding="utf-8")
    data = json.loads(text, parse_constant=_reject_constant)
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _reject_nonfinite(data)
    return data
