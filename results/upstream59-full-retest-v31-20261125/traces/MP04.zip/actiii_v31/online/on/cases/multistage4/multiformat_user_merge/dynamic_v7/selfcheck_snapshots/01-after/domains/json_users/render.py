import json
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    c = load_payload(contract_path)
    payloads = [load_payload(Path(root) / p) for p in c["inputs"]]
    return transform(payloads, c)


if __name__ == "__main__":
    import sys
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    contract_path = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("contract.json")
    c = load_payload(contract_path)
    result = build_component(root, contract_path)
    out = Path(root) / c["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
