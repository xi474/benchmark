import datetime


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _normalize_id(value):
    if isinstance(value, str):
        s = value.strip()
        if not s:
            raise ValueError("empty id")
        return s
    if _is_int(value):
        return str(value)
    raise ValueError("invalid id type")


def _normalize_joined(value):
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("joined must be string")
    s = value.strip()
    if not s:
        raise ValueError("empty joined")
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            d = datetime.datetime.strptime(s, fmt)
            return d.strftime("%Y-%m-%d")
        except ValueError:
            continue
    raise ValueError("invalid joined date")


def _pick(obj, *keys):
    for k in keys:
        if k in obj and obj[k] is not None:
            return obj[k]
    return None


def _merge_record(acc, obj):
    # id
    if "id" in obj and obj["id"] is not None:
        acc["id"] = _normalize_id(obj["id"])
    elif "user_id" in obj and obj["user_id"] is not None:
        acc["id"] = _normalize_id(obj["user_id"])

    name = _pick(obj, "name", "full_name")
    if name is not None:
        acc["name"] = name
    email = _pick(obj, "email", "mail")
    if email is not None:
        acc["email"] = email
    joined = _pick(obj, "joined", "joined_at")
    if joined is not None:
        acc["joined"] = _normalize_joined(joined)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    json_text = payload.get("json_text")
    if not isinstance(json_text, str):
        raise ValueError("json_text must be string")

    import json as _json
    data = _json.loads(json_text, parse_constant=_reject_constant)
    if not isinstance(data, list):
        raise ValueError("json_text must be an array")

    records = {}
    for obj in data:
        if not isinstance(obj, dict):
            raise ValueError("each element must be object")
        if "id" not in obj and "user_id" not in obj:
            raise ValueError("missing id")
        rid = _normalize_id(obj["id"] if "id" in obj else obj["user_id"])
        acc = records.setdefault(rid, {})
        _merge_record(acc, obj)

    out = []
    for rid in sorted(records):
        rec = records[rid]
        item = {"id": rid}
        for k in ("name", "email", "joined"):
            if k in rec:
                item[k] = rec[k]
        out.append(item)

    return {"name": contract["name"], "result": {"records": out}}


def _reject_constant(value):
    raise ValueError("non-finite number")
