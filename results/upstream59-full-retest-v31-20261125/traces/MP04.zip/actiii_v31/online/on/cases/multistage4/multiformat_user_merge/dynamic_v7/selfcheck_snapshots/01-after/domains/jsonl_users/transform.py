import json
from datetime import datetime


def _parse_id(rec):
    if "id" not in rec:
        raise ValueError("missing id")
    raw = rec["id"]
    if isinstance(raw, bool):
        raise ValueError("bool id illegal")
    if isinstance(raw, int):
        return str(raw)
    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            raise ValueError("empty id")
        return s
    raise ValueError("invalid id type")


def _pick(rec, new_key, old_key):
    for key in (new_key, old_key):
        if key in rec and rec[key] is not None:
            return rec[key]
    return None


def _parse_joined(v):
    if not isinstance(v, str):
        raise ValueError("joined must be str")
    if v == "":
        return ""
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(v, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    raise ValueError("invalid joined date")


def _normalize(rec):
    uid = _parse_id(rec)
    out = {"id": uid}
    name = _pick(rec, "name", "full_name")
    if name is not None:
        if not isinstance(name, str):
            raise ValueError("name must be str")
        out["name"] = name
    email = _pick(rec, "email", "mail")
    if email is not None:
        if not isinstance(email, str):
            raise ValueError("email must be str")
        out["email"] = email
    joined = _pick(rec, "joined", "joined_at")
    if joined is not None:
        out["joined"] = _parse_joined(joined)
    return out


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict) or "jsonl_text" not in payload:
        raise ValueError("missing jsonl_text")
    text = payload["jsonl_text"]
    if not isinstance(text, str):
        raise ValueError("jsonl_text must be str")

    merged = {}
    for line in text.split("\n"):
        if line.strip() == "":
            continue
        try:
            obj = json.loads(line)
        except ValueError as exc:
            raise ValueError("bad JSON line") from exc
        if not isinstance(obj, dict):
            raise ValueError("line must be JSON object")
        rec = _normalize(obj)
        uid = rec["id"]
        if uid in merged:
            existing = merged[uid]
            for key in ("name", "email", "joined"):
                if key in rec:
                    existing[key] = rec[key]
        else:
            merged[uid] = rec

    records = [merged[k] for k in sorted(merged)]
    return {"name": contract["name"], "result": {"records": records}}
