import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all component contracts (domains and views), excluding outputs.
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts")

    # Topologically order by input dependency on other component outputs.
    outputs = {json.loads(cp.read_text(encoding="utf-8"))["output"]: cp for cp in contracts}
    names = {json.loads(cp.read_text(encoding="utf-8"))["name"]: cp for cp in contracts}

    remaining = set(contracts)
    order = []
    while remaining:
        progressed = False
        for cp in sorted(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [p for p in c["inputs"] if p in outputs]
            if all(outputs[d] not in remaining for d in deps):
                order.append(cp)
                remaining.discard(cp)
                progressed = True
                break
        if not progressed:
            raise ValueError("dependency cycle detected")

    for cp in order:
        render = cp.with_name("render.py")
        subprocess.run([sys.executable, str(render)], cwd=ROOT, check=True)

    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
