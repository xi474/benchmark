def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    sources = ["json", "csv", "jsonl"]
    records_by_source = []
    for payload in payloads:
        if not isinstance(payload, dict) or "result" not in payload:
            raise ValueError("payload must be component wrapper")
        result = payload["result"]
        if not isinstance(result, dict) or "records" not in result:
            raise ValueError("result must contain records")
        records = result["records"]
        if not isinstance(records, list):
            raise ValueError("records must be a list")
        records_by_source.append(records)

    users = {}
    for source, records in zip(sources, records_by_source):
        for rec in records:
            if not isinstance(rec, dict) or "id" not in rec:
                raise ValueError("record must be object with id")
            uid = rec["id"]
            if uid not in users:
                users[uid] = {}
            entry = users[uid]
            for field in ("name", "email", "joined"):
                if field in rec and field not in entry:
                    entry[field] = rec[field]

    field_values = {}
    for source, records in zip(sources, records_by_source):
        for rec in records:
            uid = rec["id"]
            for field in ("name", "email", "joined"):
                if field in rec:
                    key = (uid, field)
                    field_values.setdefault(key, []).append(
                        {"source": source, "value": rec[field]}
                    )

    conflicts = []
    for (uid, field) in sorted(field_values):
        values = field_values[(uid, field)]
        distinct = []
        seen = set()
        for item in values:
            marker = (item["source"], repr(item["value"]))
            if marker not in seen:
                seen.add(marker)
                distinct.append(item)
        if len(distinct) >= 2:
            conflicts.append({"id": uid, "field": field, "values": distinct})

    user_list = []
    for uid in sorted(users):
        entry = users[uid]
        rec = {"id": uid}
        for field in ("name", "email", "joined"):
            if field in entry:
                rec[field] = entry[field]
        user_list.append(rec)

    return {"name": contract["name"], "result": {"users": user_list, "conflicts": conflicts}}
