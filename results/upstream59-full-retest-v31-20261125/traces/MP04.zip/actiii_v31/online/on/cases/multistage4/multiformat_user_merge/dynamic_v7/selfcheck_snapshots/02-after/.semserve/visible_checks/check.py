import unittest

# Injected names (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict
# check_api_boundary(...) -> raises on failure

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/json_users/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/csv_users/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/jsonl_users/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/directory/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for entry in API_BOUNDARY_REQUIREMENTS:
            target = entry["target_path"]
            for rule, spec in entry["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target, rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"json_text": "[]", "csv_text": "", "jsonl_text": ""}],
                                  {"name": "x", "inputs": ["a"], "operation": "users_json"}],
                        )
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target, rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"json_text": "[]", "csv_text": "", "jsonl_text": ""}],
                                  {"name": "x", "inputs": ["a"], "operation": "users_json"}],
                        )


class TestJsonUsers(unittest.TestCase):
    def test_records_sorted_and_normalized(self):
        payload = {"json_text": '[{"id": 2, "name": "B"}, {"id": 1, "name": "A"}]'}
        contract = {"name": "json_users", "inputs": ["x"], "operation": "users_json"}
        result = call_candidate("domains/json_users/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "json_users")
        records = result["result"]["records"]
        self.assertEqual([r["id"] for r in records], ["1", "2"])
        self.assertEqual(records[0]["name"], "A")

    def test_duplicate_id_last_value_wins(self):
        payload = {"json_text": '[{"id": 1, "name": "A"}, {"id": 1, "name": "B"}]'}
        contract = {"name": "json_users", "inputs": ["x"], "operation": "users_json"}
        result = call_candidate("domains/json_users/transform.py", "transform", args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["name"], "B")


class TestCsvUsers(unittest.TestCase):
    def test_empty_text_empty_records(self):
        payload = {"csv_text": ""}
        contract = {"name": "csv_users", "inputs": ["x"], "operation": "users_csv"}
        result = call_candidate("domains/csv_users/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["records"], [])

    def test_csv_parse_and_sort(self):
        payload = {"csv_text": "user_id,name\n2,B\n1,A\n"}
        contract = {"name": "csv_users", "inputs": ["x"], "operation": "users_csv"}
        result = call_candidate("domains/csv_users/transform.py", "transform", args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual([r["id"] for r in records], ["1", "2"])


class TestJsonlUsers(unittest.TestCase):
    def test_jsonl_parse_and_sort(self):
        payload = {"jsonl_text": '{"id": 2, "name": "B"}\n{"id": 1, "name": "A"}\n'}
        contract = {"name": "jsonl_users", "inputs": ["x"], "operation": "users_jsonl"}
        result = call_candidate("domains/jsonl_users/transform.py", "transform", args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual([r["id"] for r in records], ["1", "2"])

    def test_bad_json_line_raises(self):
        payload = {"jsonl_text": '{"id": 1}\nnot json\n'}
        contract = {"name": "jsonl_users", "inputs": ["x"], "operation": "users_jsonl"}
        with self.assertRaises(CandidateCallError) as ctx:
            call_candidate("domains/jsonl_users/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(ctx.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(ctx.exception.details["error_type"], "ValueError")


class TestDirectory(unittest.TestCase):
    def test_merge_priority_and_conflicts(self):
        json_rec = {"name": "json_users", "result": {"records": [{"id": "1", "name": "A", "email": "a@x"}]}}
        csv_rec = {"name": "csv_users", "result": {"records": [{"id": "1", "name": "B", "email": "a@x"}]}}
        jsonl_rec = {"name": "jsonl_users", "result": {"records": [{"id": "2", "name": "C"}]}}
        contract = {"name": "directory", "inputs": ["a", "b", "c"], "operation": "users_merge"}
        result = call_candidate(
            "views/directory/transform.py", "transform",
            args=[[json_rec, csv_rec, jsonl_rec], contract],
        )
        users = result["result"]["users"]
        self.assertEqual([u["id"] for u in users], ["1", "2"])
        self.assertEqual(users[0]["name"], "A")  # json priority wins
        conflicts = result["result"]["conflicts"]
        # name differs (A vs B); email is equal across sources so no conflict.
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["field"], "name")
        self.assertEqual([v["source"] for v in conflicts[0]["values"]], ["json", "csv"])


if __name__ == "__main__":
    unittest.main()
