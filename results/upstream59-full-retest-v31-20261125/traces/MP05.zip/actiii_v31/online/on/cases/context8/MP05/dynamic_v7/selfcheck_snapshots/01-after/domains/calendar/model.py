import json
import math
from pathlib import Path


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    data = json.loads(text, parse_constant=_reject_constant)
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data)
    return data


def _reject_constant(value):
    raise ValueError("non-finite number")


def _check_finite(node):
    if isinstance(node, float):
        if not math.isfinite(node):
            raise ValueError("non-finite number")
    elif isinstance(node, dict):
        for v in node.values():
            _check_finite(v)
    elif isinstance(node, list):
        for v in node:
            _check_finite(v)
