def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    contacts = data["contacts"]
    self_id = data["self_id"]
    window = data["window"]
    events = data["events"]

    start, end = window
    if end <= start:
        raise ValueError("window end must be after start")

    contact_ids = set()
    for c in contacts:
        cid = c["id"]
        if cid in contact_ids:
            raise ValueError("duplicate contact id")
        contact_ids.add(cid)

    minutes = {c["id"]: 0 for c in contacts if c["id"] != self_id}

    for ev in events:
        if ev["end"] <= ev["start"]:
            raise ValueError("event end must be after start")
        attendees = ev["attendees"]
        if self_id not in attendees:
            continue
        lo = max(ev["start"], start)
        hi = min(ev["end"], end)
        if hi <= lo:
            continue
        dur = hi - lo
        seen = set()
        for a in attendees:
            if a == self_id:
                continue
            if a not in contact_ids:
                raise ValueError("unknown attendee")
            if a in seen:
                continue
            seen.add(a)
            minutes[a] = minutes.get(a, 0) + dur

    return {"name": contract["name"], "result": {"minutes": minutes}}
