def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {'name', 'result'}:
        data = data['result']

    contacts = data['contacts']
    self_id = data['self_id']
    keyword = data['keyword']
    emails = data['emails']

    contact_ids = set()
    for c in contacts:
        cid = c['id']
        if cid in contact_ids:
            raise ValueError('duplicate contact id')
        contact_ids.add(cid)

    kw = keyword.casefold()
    ids = set()
    for e in emails:
        sender = e['sender']
        if sender not in contact_ids:
            raise ValueError('unknown sender')
        if kw in e['subject'].casefold():
            if sender != self_id:
                ids.add(sender)

    return {'name': contract['name'], 'result': {'ids': sorted(ids)}}
