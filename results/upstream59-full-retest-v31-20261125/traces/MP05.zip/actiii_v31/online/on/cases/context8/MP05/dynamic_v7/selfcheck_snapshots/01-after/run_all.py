import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _contracts():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    return contracts


def main():
    contracts = _contracts()
    if not contracts:
        raise ValueError('no contracts')

    produced = {}
    remaining = list(contracts)
    ordered = []
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding='utf-8'))
            ready = True
            for inp in c['inputs']:
                if inp in produced:
                    continue
                if not (ROOT / inp).is_file():
                    ready = False
                    break
            if ready:
                ordered.append(cp)
                produced[c['output']] = cp
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise ValueError('missing dependency or cycle')

    for cp in ordered:
        subprocess.run(
            [sys.executable, str(cp.with_name('render.py'))],
            cwd=ROOT,
            check=True,
            timeout=180,
        )

    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        check=True,
        timeout=180,
    )

    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        check=True,
        timeout=180,
    )


if __name__ == '__main__':
    main()
