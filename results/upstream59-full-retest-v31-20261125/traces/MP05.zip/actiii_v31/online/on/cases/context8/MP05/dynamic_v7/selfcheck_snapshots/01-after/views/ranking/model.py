import json
from pathlib import Path


def _reject_constant(value):
    raise ValueError("non-finite number not allowed")


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    data = json.loads(text, parse_constant=_reject_constant)
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    return data
