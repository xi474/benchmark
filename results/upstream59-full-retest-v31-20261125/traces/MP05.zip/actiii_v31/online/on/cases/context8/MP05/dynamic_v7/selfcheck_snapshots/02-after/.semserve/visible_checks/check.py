import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/groups/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/mail/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/ranking/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    payload = {"contacts": [{"id": "self", "age": 1}], "self_id": "self", "keyword": "dinner", "groups": [], "emails": [], "events": [], "window": [0, 1]}
                    contract = {"name": "x", "operation": "y", "inputs": ["a"], "output": "b"}
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target,
                            rule="invalid_payload_type",
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[payload], contract],
                        )
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target,
                            rule="nonfinite_unknown_field",
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[payload], contract],
                        )


class TestGroups(unittest.TestCase):
    def test_group_candidates_union(self):
        payload = {
            "contacts": [{"id": "self", "age": 1}, {"id": "a", "age": 2}, {"id": "b", "age": 3}],
            "self_id": "self",
            "keyword": "dinner",
            "groups": [
                {"id": "g1", "members": ["self", "a"], "messages": ["DINNER now"]},
                {"id": "g2", "members": ["self", "b"], "messages": ["lunch"]},
            ],
        }
        contract = {"name": "groups", "operation": "group_candidates", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/groups/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result, {"name": "groups", "result": {"ids": ["a"]}})


class TestMail(unittest.TestCase):
    def test_mail_candidates(self):
        payload = {
            "contacts": [{"id": "self", "age": 1}, {"id": "a", "age": 2}],
            "self_id": "self",
            "keyword": "dinner",
            "emails": [
                {"id": "e1", "sender": "a", "subject": "DINNER plan"},
                {"id": "e2", "sender": "self", "subject": "dinner"},
            ],
        }
        contract = {"name": "mail", "operation": "mail_candidates", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/mail/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result, {"name": "mail", "result": {"ids": ["a"]}})


class TestCalendar(unittest.TestCase):
    def test_shared_durations_clip(self):
        payload = {
            "contacts": [{"id": "self", "age": 1}, {"id": "a", "age": 2}, {"id": "b", "age": 3}],
            "self_id": "self",
            "window": [0, 100],
            "events": [
                {"id": "v1", "start": -10, "end": 20, "attendees": ["self", "a", "a"]},
                {"id": "v2", "start": 50, "end": 80, "attendees": ["self", "b"]},
            ],
        }
        contract = {"name": "calendar", "operation": "shared_durations", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/calendar/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["minutes"], {"a": 20, "b": 30})


class TestRanking(unittest.TestCase):
    def test_ranking_union_and_order(self):
        snapshot = {
            "contacts": [
                {"id": "self", "age": 1},
                {"id": "a", "age": 20},
                {"id": "b", "age": 30},
                {"id": "c", "age": 25},
            ],
            "self_id": "self",
        }
        groups = {"name": "groups", "result": {"ids": ["a", "b"]}}
        mail = {"name": "mail", "result": {"ids": ["b", "c"]}}
        calendar = {"name": "calendar", "result": {"minutes": {"a": 10, "b": 10, "c": 5}}}
        contract = {"name": "ranking", "operation": "contact_rank", "inputs": ["a", "b", "c", "d"], "output": "y"}
        result = call_candidate(
            "views/ranking/transform.py", "transform",
            args=[[snapshot, groups, mail, calendar], contract],
        )
        self.assertEqual(result["name"], "ranking")
        ranking = result["result"]["ranking"]
        self.assertEqual([r["id"] for r in ranking], ["b", "a", "c"])
        self.assertEqual(result["result"]["winner"], "b")


if __name__ == "__main__":
    unittest.main()
