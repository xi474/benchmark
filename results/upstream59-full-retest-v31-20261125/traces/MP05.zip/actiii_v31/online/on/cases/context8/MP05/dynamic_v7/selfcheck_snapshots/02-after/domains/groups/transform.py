def _check_finite(node):
    if isinstance(node, float):
        import math
        if not math.isfinite(node):
            raise ValueError("non-finite number")
    elif isinstance(node, dict):
        for v in node.values():
            _check_finite(v)
    elif isinstance(node, list):
        for v in node:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("payload must be object")
    _check_finite(data)

    contacts = data["contacts"]
    self_id = data["self_id"]
    keyword = data["keyword"]
    groups = data["groups"]

    contact_ids = set()
    for c in contacts:
        contact_ids.add(c["id"])

    if self_id not in contact_ids:
        raise ValueError("self_id not in contacts")

    kw = keyword.casefold()
    ids = set()
    for g in groups:
        members = g["members"]
        for m in members:
            if m not in contact_ids:
                raise ValueError("unknown member")
        if any(m.casefold().find(kw) >= 0 for m in g["messages"]):
            for m in members:
                if m != self_id:
                    ids.add(m)

    return {"name": contract["name"], "result": {"ids": sorted(ids)}}
