def _check_finite(node):
    if isinstance(node, float):
        import math
        if not math.isfinite(node):
            raise ValueError("non-finite number")
    elif isinstance(node, dict):
        for v in node.values():
            _check_finite(v)
    elif isinstance(node, list):
        for v in node:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {'name', 'result'}:
        data = data['result']
    if not isinstance(data, dict):
        raise ValueError('payload must be object')
    _check_finite(data)

    contacts = data['contacts']
    self_id = data['self_id']
    keyword = data['keyword']
    emails = data['emails']

    contact_ids = set()
    for c in contacts:
        cid = c['id']
        if cid in contact_ids:
            raise ValueError('duplicate contact id')
        contact_ids.add(cid)

    kw = keyword.casefold()
    ids = set()
    for e in emails:
        sender = e['sender']
        if sender not in contact_ids:
            raise ValueError('unknown sender')
        if kw in e['subject'].casefold():
            if sender != self_id:
                ids.add(sender)

    return {'name': contract['name'], 'result': {'ids': sorted(ids)}}
