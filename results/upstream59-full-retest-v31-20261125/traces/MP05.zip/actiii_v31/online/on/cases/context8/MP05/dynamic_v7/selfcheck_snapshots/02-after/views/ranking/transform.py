def _check_finite(node):
    if isinstance(node, float):
        import math
        if not math.isfinite(node):
            raise ValueError("non-finite number")
    elif isinstance(node, dict):
        for v in node.values():
            _check_finite(v)
    elif isinstance(node, list):
        for v in node:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = payloads[0]
    groups = payloads[1]
    mail = payloads[2]
    calendar = payloads[3]

    if isinstance(snapshot, dict) and set(snapshot) == {"name", "result"}:
        snapshot = snapshot["result"]
    if isinstance(groups, dict) and set(groups) == {"name", "result"}:
        groups = groups["result"]
    if isinstance(mail, dict) and set(mail) == {"name", "result"}:
        mail = mail["result"]
    if isinstance(calendar, dict) and set(calendar) == {"name", "result"}:
        calendar = calendar["result"]

    if not isinstance(snapshot, dict):
        raise ValueError("payload must be object")
    _check_finite(snapshot)
    _check_finite(groups)
    _check_finite(mail)
    _check_finite(calendar)

    contacts = snapshot["contacts"]
    age_by_id = {}
    for c in contacts:
        cid = c["id"]
        age = c["age"]
        if isinstance(age, bool) or not isinstance(age, int) or age < 0:
            raise ValueError("age must be non-negative integer")
        age_by_id[cid] = age

    group_ids = groups["ids"]
    mail_ids = mail["ids"]
    minutes = calendar["minutes"]

    candidate_ids = set(group_ids) | set(mail_ids)

    ranking = []
    for cid in candidate_ids:
        if cid not in age_by_id:
            raise ValueError("unknown contact id")
        ranking.append({
            "id": cid,
            "minutes": minutes.get(cid, 0),
            "age": age_by_id[cid],
        })

    ranking.sort(key=lambda r: (-r["minutes"], -r["age"], r["id"]))

    winner = ranking[0]["id"] if ranking else None

    return {"name": contract["name"], "result": {"ranking": ranking, "winner": winner}}
