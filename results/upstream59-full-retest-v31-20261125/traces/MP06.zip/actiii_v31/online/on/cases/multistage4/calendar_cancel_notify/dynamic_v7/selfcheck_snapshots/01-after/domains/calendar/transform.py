def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count must match contract inputs")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("business input must be an object")

    events = data.get("events")
    day = data.get("day")
    contacts = data.get("contacts")
    if not isinstance(events, list):
        raise ValueError("events must be a list")
    if isinstance(day, bool) or not isinstance(day, (int, float)):
        raise ValueError("day must be a finite number")
    if day != day or day in (float("inf"), float("-inf")):
        raise ValueError("day must be finite")
    if day < 0:
        raise ValueError("day must be >= 0")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be a list")

    lo = day * 1440
    hi = lo + 720

    cancelled = []
    snapshots = {}
    remaining = {}

    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be an object")
        eid = ev.get("id")
        start = ev.get("start")
        end = ev.get("end")
        social = ev.get("social")
        cancelled_flag = ev.get("cancelled")
        attendees = ev.get("attendees")

        if isinstance(start, bool) or not isinstance(start, (int, float)):
            raise ValueError("start must be a finite number")
        if isinstance(end, bool) or not isinstance(end, (int, float)):
            raise ValueError("end must be a finite number")
        if start != start or end != end:
            raise ValueError("start/end must be finite")
        if not isinstance(social, bool):
            raise ValueError("social must be bool")
        if not isinstance(cancelled_flag, bool):
            raise ValueError("cancelled must be bool")
        if not isinstance(attendees, list):
            raise ValueError("attendees must be a list")
        if end <= start:
            raise ValueError("end must be > start")

        if lo <= start < hi and social and not cancelled_flag:
            cancelled.append(eid)
            snapshots[eid] = ev
        else:
            remaining[eid] = ev

    cancelled.sort()
    return {
        "name": contract["name"],
        "result": {
            "cancelled": cancelled,
            "snapshots": {k: snapshots[k] for k in sorted(snapshots)},
            "remaining": {k: remaining[k] for k in sorted(remaining)},
        },
    }
