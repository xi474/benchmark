import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = [
        x for x in ROOT.rglob('contract.json')
        if 'outputs' not in x.relative_to(ROOT).parts
    ]
    if not contracts:
        raise ValueError('no contracts')

    produced = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        produced[c['name']] = str(ROOT / c['output'])

    pending = {cp: json.loads(cp.read_text(encoding='utf-8')) for cp in contracts}
    done = set()
    while pending:
        progressed = False
        for cp in list(pending):
            c = pending[cp]
            deps = []
            for inp in c['inputs']:
                p = str(ROOT / inp)
                for name, out in produced.items():
                    if p == out and name not in done:
                        deps.append(name)
            if deps:
                continue
            render = cp.parent / 'render.py'
            subprocess.run(
                [sys.executable, str(render), str(ROOT), str(cp)],
                cwd=ROOT, check=True, timeout=60,
            )
            done.add(c['name'])
            del pending[cp]
            progressed = True
        if not progressed:
            raise ValueError('dependency cycle or missing dependency')

    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT, check=True, timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT, check=True, timeout=60,
    )


if __name__ == '__main__':
    main()
