import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file and return its parsed value.

    Only object/array top-level values are legal. Invalid JSON, any other
    top-level type, and any nested NaN/Infinity raise ValueError.
    """
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError("invalid JSON: %s" % exc) from exc
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be an object or array")
    _reject_non_finite(data)
    return data


def _reject_non_finite(value):
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("non-finite number is not allowed")
    elif isinstance(value, dict):
        for v in value.values():
            _reject_non_finite(v)
    elif isinstance(value, list):
        for v in value:
            _reject_non_finite(v)
