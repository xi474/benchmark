import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, run transform, return the wrapper."""
    root = Path(root)
    cp = Path(contract_path)
    contract = load_payload(cp)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, value):
    text = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    ) + "\n"
    Path(path).write_text(text, encoding="utf-8")


if __name__ == "__main__":
    # Support any current directory: locate the workspace root as the
    # directory containing this render.py's parent (the component dir).
    here = Path(__file__).resolve()
    component_dir = here.parent
    root = component_dir.parent.parent
    contract_path = component_dir / "contract.json"
    contract = load_payload(contract_path)
    result = build_component(root, contract_path)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
