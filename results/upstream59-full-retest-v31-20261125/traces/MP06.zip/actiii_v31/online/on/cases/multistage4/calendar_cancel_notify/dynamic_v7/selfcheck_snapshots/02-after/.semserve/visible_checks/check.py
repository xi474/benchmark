import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/channels/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/notifications/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class ApiBoundaryTests(unittest.TestCase):
    def test_api_boundary_probes(self):
        calendar_payload = {
            "events": [{"id": "a", "start": 0, "end": 10, "social": True, "cancelled": False, "attendees": []}],
            "day": 0,
            "contacts": [],
        }
        calendar_contract = {"name": "calendar", "operation": "cancel_morning", "inputs": ["x"], "output": "y"}
        channels_payload = {
            "events": [],
            "day": 0,
            "contacts": [{"id": "c", "email": None, "message": None, "chat": None}],
        }
        channels_contract = {"name": "channels", "operation": "channel_directory", "inputs": ["x"], "output": "y"}
        notif_cancel = {"cancelled": [], "snapshots": {}, "remaining": {}}
        notif_channels = {"contacts": {}}
        notif_contract = {"name": "notifications", "operation": "cancel_notifications", "inputs": ["x", "y"], "output": "z"}

        with self.subTest(component="calendar", rule="invalid_payload_type"):
            check_api_boundary(
                "domains/calendar/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                args=[[calendar_payload], calendar_contract],
            )
        with self.subTest(component="calendar", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "domains/calendar/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
                args=[[calendar_payload], calendar_contract],
            )
        with self.subTest(component="channels", rule="invalid_payload_type"):
            check_api_boundary(
                "domains/channels/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                args=[[channels_payload], channels_contract],
            )
        with self.subTest(component="channels", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "domains/channels/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
                args=[[channels_payload], channels_contract],
            )
        with self.subTest(component="notifications", rule="invalid_payload_type"):
            check_api_boundary(
                "views/notifications/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                args=[[notif_cancel, notif_channels], notif_contract],
            )
        with self.subTest(component="notifications", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "views/notifications/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
                args=[[notif_cancel, notif_channels], notif_contract],
            )


class CalendarBehaviorTests(unittest.TestCase):
    def test_cancel_morning_selects_morning_social_not_cancelled(self):
        payload = {
            "events": [
                {"id": "a", "start": 0, "end": 10, "social": True, "cancelled": False, "attendees": ["c1"]},
                {"id": "b", "start": 100, "end": 200, "social": True, "cancelled": False, "attendees": ["c2"]},
                {"id": "c", "start": 300, "end": 400, "social": True, "cancelled": True, "attendees": ["c3"]},
                {"id": "d", "start": 500, "end": 600, "social": False, "cancelled": False, "attendees": ["c4"]},
                {"id": "e", "start": 800, "end": 900, "social": True, "cancelled": False, "attendees": ["c5"]},
            ],
            "day": 0,
            "contacts": [{"id": "c1", "email": None, "message": None, "chat": None}],
        }
        contract = {"name": "calendar", "operation": "cancel_morning", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/calendar/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "calendar")
        r = result["result"]
        # morning window is [0, 720); social and not cancelled -> a, b
        self.assertEqual(r["cancelled"], ["a", "b"])
        self.assertEqual(set(r["snapshots"]), {"a", "b"})
        self.assertEqual(set(r["remaining"]), {"c", "d", "e"})

    def test_cancel_morning_rejects_end_not_after_start(self):
        payload = {
            "events": [{"id": "a", "start": 10, "end": 10, "social": True, "cancelled": False, "attendees": []}],
            "day": 0,
            "contacts": [],
        }
        contract = {"name": "calendar", "operation": "cancel_morning", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/calendar/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class ChannelsBehaviorTests(unittest.TestCase):
    def test_channel_directory_prefers_message_then_chat(self):
        payload = {
            "events": [],
            "day": 0,
            "contacts": [
                {"id": "m", "email": None, "message": "msg", "chat": "chat"},
                {"id": "c", "email": None, "message": None, "chat": "chat"},
                {"id": "n", "email": None, "message": None, "chat": None},
                {"id": "e", "email": "e@x", "message": None, "chat": None},
            ],
        }
        contract = {"name": "channels", "operation": "channel_directory", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/channels/transform.py", "transform", args=[[payload], contract])
        contacts = result["result"]["contacts"]
        self.assertEqual(contacts["m"]["primary"], "message")
        self.assertEqual(contacts["m"]["address"], "msg")
        self.assertEqual(contacts["c"]["primary"], "chat")
        self.assertEqual(contacts["c"]["address"], "chat")
        self.assertIsNone(contacts["n"]["primary"])
        self.assertIsNone(contacts["n"]["address"])
        self.assertEqual(contacts["e"]["email"], "e@x")

    def test_channel_directory_rejects_duplicate_id(self):
        payload = {
            "events": [],
            "day": 0,
            "contacts": [
                {"id": "x", "email": None, "message": None, "chat": None},
                {"id": "x", "email": None, "message": None, "chat": None},
            ],
        }
        contract = {"name": "channels", "operation": "channel_directory", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/channels/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class NotificationsBehaviorTests(unittest.TestCase):
    def test_cancel_notifications_routes_channels_and_unreachable(self):
        cancel = {
            "cancelled": ["e1"],
            "snapshots": {"e1": {"id": "e1", "start": 0, "end": 10, "social": True, "cancelled": False, "attendees": ["m", "c", "n", "e"]}},
            "remaining": {},
        }
        channels = {
            "contacts": {
                "m": {"email": None, "primary": "message", "address": "msg"},
                "c": {"email": None, "primary": "chat", "address": "chat"},
                "n": {"email": None, "primary": None, "address": None},
                "e": {"email": "e@x", "primary": None, "address": None},
            }
        }
        contract = {"name": "notifications", "operation": "cancel_notifications", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("views/notifications/transform.py", "transform", args=[[cancel, channels], contract])
        r = result["result"]
        self.assertEqual(r["unreachable"], ["n"])
        self.assertEqual(r["group"]["id"], "cancelled-social")
        self.assertEqual(r["group"]["members"], ["m"])
        channels_seen = [(o["channel"], o["to"]) for o in r["outbox"]]
        self.assertIn(("email", "e@x"), channels_seen)
        self.assertIn(("chat", "chat"), channels_seen)
        self.assertIn(("message_group", "cancelled-social"), channels_seen)
        # outbox sorted by (channel, to)
        self.assertEqual(channels_seen, sorted(channels_seen))

    def test_cancel_notifications_rejects_unknown_attendee(self):
        cancel = {
            "cancelled": ["e1"],
            "snapshots": {"e1": {"id": "e1", "start": 0, "end": 10, "social": True, "cancelled": False, "attendees": ["ghost"]}},
            "remaining": {},
        }
        channels = {"contacts": {}}
        contract = {"name": "notifications", "operation": "cancel_notifications", "inputs": ["x", "y"], "output": "z"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("views/notifications/transform.py", "transform", args=[[cancel, channels], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
