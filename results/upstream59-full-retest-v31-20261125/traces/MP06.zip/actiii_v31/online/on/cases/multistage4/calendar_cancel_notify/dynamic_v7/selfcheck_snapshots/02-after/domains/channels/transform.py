import math


def _reject_non_finite(value):
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise ValueError("non-finite number is not allowed")
    elif isinstance(value, dict):
        for v in value.values():
            _reject_non_finite(v)
    elif isinstance(value, list):
        for v in value:
            _reject_non_finite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _require_str_or_null(value, field):
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field} must be null or string")
    if not value.strip():
        raise ValueError(f"{field} must be non-empty string")
    return value


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _reject_non_finite(payloads)
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    contacts = data.get("contacts")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")

    seen = set()
    result_contacts = {}
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        cid = c.get("id")
        if not isinstance(cid, str) or not cid.strip():
            raise ValueError("contact id must be non-empty string")
        if cid in seen:
            raise ValueError("duplicate contact id")
        seen.add(cid)

        email = _require_str_or_null(c.get("email"), "email")
        message = _require_str_or_null(c.get("message"), "message")
        chat = _require_str_or_null(c.get("chat"), "chat")

        if message is not None:
            primary = "message"
            address = message
        elif chat is not None:
            primary = "chat"
            address = chat
        else:
            primary = None
            address = None

        result_contacts[cid] = {
            "email": email,
            "primary": primary,
            "address": address,
        }

    return {"name": contract["name"], "result": {"contacts": result_contacts}}
