import math


def _reject_non_finite(value):
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise ValueError("non-finite number is not allowed")
    elif isinstance(value, dict):
        for v in value.values():
            _reject_non_finite(v)
    elif isinstance(value, list):
        for v in value:
            _reject_non_finite(v)


def transform(payloads, contract):
    """Compute cancel_notifications from cancel_morning and channel_directory.

    payloads[0] is the cancel_morning result:
        {cancelled:[id], snapshots:{id:event}, remaining:{id:event}}
    payloads[1] is the channel_directory result:
        {contacts:{id:{email, primary, address}}}

    Returns {"name": contract["name"], "result": {...}}.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _reject_non_finite(payloads)

    cancel = _unwrap(payloads[0])
    channels = _unwrap(payloads[1])
    if not isinstance(cancel, dict):
        raise ValueError("invalid cancel_morning result")
    if not isinstance(channels, dict):
        raise ValueError("invalid channel_directory result")

    cancelled = cancel.get("cancelled")
    snapshots = cancel.get("snapshots")
    if not isinstance(cancelled, list) or not isinstance(snapshots, dict):
        raise ValueError("invalid cancel_morning result")

    contacts = channels.get("contacts")
    if not isinstance(contacts, dict):
        raise ValueError("invalid channel_directory result")

    # Union of attendees across target snapshots, deduplicated.
    attendee_set = set()
    for eid in cancelled:
        ev = snapshots.get(eid)
        if not isinstance(ev, dict):
            raise ValueError("missing snapshot for cancelled event")
        for a in ev.get("attendees", []):
            attendee_set.add(a)

    # Unknown contact ids error.
    for a in attendee_set:
        if a not in contacts:
            raise ValueError("unknown contact id: %r" % (a,))

    requires = sorted(cancelled)

    outbox = []
    unreachable = []
    message_members = []

    for cid in sorted(attendee_set):
        info = contacts[cid]
        email = info.get("email")
        primary = info.get("primary")
        address = info.get("address")

        has_email = email is not None
        has_primary = primary is not None and address is not None

        if has_email:
            outbox.append({
                "channel": "email",
                "to": email,
                "recipients": [cid],
                "requires": requires,
            })
        if primary == "message":
            message_members.append(cid)
        elif primary == "chat":
            outbox.append({
                "channel": "chat",
                "to": address,
                "recipients": [cid],
                "requires": requires,
            })
        # primary == "message" handled via group below.

        if not has_email and not has_primary:
            unreachable.append(cid)

    group = None
    if message_members:
        group = {
            "id": "cancelled-social",
            "members": sorted(message_members),
            "requires": requires,
        }
        outbox.append({
            "channel": "message_group",
            "to": "cancelled-social",
            "recipients": sorted(message_members),
            "requires": requires,
        })

    outbox.sort(key=lambda o: (o["channel"], o["to"]))
    unreachable.sort()

    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox,
            "unreachable": unreachable,
            "group": group,
        },
    }


def _unwrap(payload):
    """If payload is an object with exactly keys name/result, return result."""
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload
