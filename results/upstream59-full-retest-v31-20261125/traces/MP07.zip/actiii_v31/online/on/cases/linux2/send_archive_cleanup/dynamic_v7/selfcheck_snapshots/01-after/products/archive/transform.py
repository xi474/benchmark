def _unwrap(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    receipts = _unwrap(payloads[1])
    cleanup = _unwrap(payloads[2])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    if not isinstance(receipts, dict):
        raise ValueError("receipts must be an object")
    if not isinstance(cleanup, dict):
        raise ValueError("cleanup must be an object")

    files = snapshot["files"]
    attachments = snapshot["attachments"]
    archive_prefix = snapshot["archive_prefix"]
    receipts_list = receipts["receipts"]
    delete_list = cleanup["delete"]

    file_map = {}
    for f in files:
        file_map[f["path"]] = f["hex"]

    all_ok = len(receipts_list) > 0 and all(r["ok"] for r in receipts_list)

    moves = []
    if all_ok:
        prefix = archive_prefix.rstrip("/")
        for att in attachments:
            moves.append({"from": att, "to": prefix + "/" + att})

    moves.sort(key=lambda m: m["from"])

    targets = [m["to"] for m in moves]
    if len(targets) != len(set(targets)):
        raise ValueError("duplicate target")

    for m in moves:
        if m["to"] in file_map and m["to"] != m["from"]:
            raise ValueError("target already exists")

    move_sources = set(m["from"] for m in moves)
    for d in delete_list:
        if d in move_sources:
            raise ValueError("cleanup and move source overlap")

    for m in moves:
        hexval = file_map.pop(m["from"])
        file_map[m["to"]] = hexval

    for d in delete_list:
        file_map.pop(d, None)

    files_out = [{"path": p, "hex": h} for p, h in sorted(file_map.items())]

    return {
        "name": contract["name"],
        "result": {
            "moves": moves,
            "deleted": sorted(delete_list),
            "blocked": not all_ok,
            "files": files_out,
        },
    }
