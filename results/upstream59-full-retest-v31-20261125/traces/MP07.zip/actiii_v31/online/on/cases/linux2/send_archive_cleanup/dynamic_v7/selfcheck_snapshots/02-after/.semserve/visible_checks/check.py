import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/receipts/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/cleanup/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/archive/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        contract = {"name": "c", "operation": "op", "inputs": ["x"], "output": "y"}
        cases = [
            ("products/receipts/transform.py", {"files": [], "attachments": [], "recipients": [], "send_ok": {}}),
            ("products/cleanup/transform.py", {"cleanup_prefix": "home/tmp", "files": []}),
            ("products/archive/transform.py", [
                {"archive_prefix": "archive", "attachments": [], "files": []},
                {"receipts": []},
                {"delete": []},
            ]),
        ]
        for target, payload in cases:
            with self.subTest(target=target):
                check_api_boundary(
                    target,
                    rule="nonfinite_unknown_field",
                    contract_path="README.md",
                    requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
                    args=[payload, contract],
                )
                check_api_boundary(
                    target,
                    rule="invalid_payload_type",
                    contract_path="README.md",
                    requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                    args=[payload, contract],
                )


class TestReceipts(unittest.TestCase):
    def test_receipts_output_shape_and_ordering(self):
        payload = {
            "files": [
                {"path": "b.txt", "hex": "6262"},
                {"path": "a.txt", "hex": "6161"},
            ],
            "attachments": ["b.txt", "a.txt", "b.txt"],
            "recipients": ["z", "a"],
            "send_ok": {"z": True, "a": False},
        }
        contract = {"name": "receipts", "operation": "attachment_receipts", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/receipts/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "receipts")
        r = result["result"]
        self.assertEqual([a["path"] for a in r["attachments"]], ["a.txt", "b.txt"])
        self.assertEqual([a["sha256"] for a in r["attachments"]],
                         ["961b6dd3ede3cb8ecbaacbd68de040cd78eb2ed5889130cceb4c49268ea4d506",
                          "3b64db95cb55c763391c707108489ae18b4112d783300de38e033b4c98c3deaf"])
        self.assertEqual(r["receipts"], [{"recipient": "a", "ok": False}, {"recipient": "z", "ok": True}])


class TestCleanup(unittest.TestCase):
    def test_cleanup_segment_boundary(self):
        payload = {
            "cleanup_prefix": "home/tmp",
            "files": [
                {"path": "home/tmp/a.tmp", "hex": "61"},
                {"path": "home/tmp-old/b.tmp", "hex": "62"},
                {"path": "home/tmp/c.txt", "hex": "63"},
                {"path": "home/tmp/d.tmp", "hex": "64"},
            ],
        }
        contract = {"name": "cleanup", "operation": "independent_cleanup", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/cleanup/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["delete"], ["home/tmp/a.tmp", "home/tmp/d.tmp"])


class TestArchive(unittest.TestCase):
    def test_archive_blocked_when_not_all_ok(self):
        snapshot = {
            "archive_prefix": "archive",
            "attachments": ["d/a.txt"],
            "files": [{"path": "d/a.txt", "hex": "61"}],
        }
        receipts = {"receipts": [{"recipient": "a", "ok": True}, {"recipient": "b", "ok": False}]}
        cleanup = {"delete": []}
        contract = {"name": "archive", "operation": "archive_after_send", "inputs": ["x", "y", "z"], "output": "w"}
        result = call_candidate("products/archive/transform.py", "transform", args=[[snapshot, receipts, cleanup], contract])
        r = result["result"]
        self.assertTrue(r["blocked"])
        self.assertEqual(r["moves"], [])
        self.assertEqual([f["path"] for f in r["files"]], ["d/a.txt"])

    def test_archive_moves_when_all_ok(self):
        snapshot = {
            "archive_prefix": "archive",
            "attachments": ["d/a.txt"],
            "files": [{"path": "d/a.txt", "hex": "61"}],
        }
        receipts = {"receipts": [{"recipient": "a", "ok": True}]}
        cleanup = {"delete": []}
        contract = {"name": "archive", "operation": "archive_after_send", "inputs": ["x", "y", "z"], "output": "w"}
        result = call_candidate("products/archive/transform.py", "transform", args=[[snapshot, receipts, cleanup], contract])
        r = result["result"]
        self.assertFalse(r["blocked"])
        self.assertEqual(r["moves"], [{"from": "d/a.txt", "to": "archive/d/a.txt"}])
        self.assertEqual([f["path"] for f in r["files"]], ["archive/d/a.txt"])


if __name__ == "__main__":
    unittest.main()
