import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _is_safe_rel(path):
    if not isinstance(path, str):
        return False
    if path == "":
        return False
    if path.startswith("/") or "\\" in path or ":" in path:
        return False
    parts = path.split("/")
    if any(seg in ("", ".", "..") for seg in parts):
        return False
    return True


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    _check_finite(payload)

    cleanup_prefix = payload.get("cleanup_prefix")
    files = payload.get("files")

    if not isinstance(cleanup_prefix, str):
        raise ValueError("cleanup_prefix must be string")
    if cleanup_prefix == "" or cleanup_prefix.strip() == "":
        raise ValueError("cleanup_prefix must be non-empty")
    if cleanup_prefix.endswith("/"):
        raise ValueError("cleanup_prefix must not have trailing slash")
    if not _is_safe_rel(cleanup_prefix):
        raise ValueError("cleanup_prefix must be safe relative path")

    if not isinstance(files, list):
        raise ValueError("files must be list")

    prefix_parts = cleanup_prefix.split("/")
    delete = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        path = f.get("path")
        if not isinstance(path, str):
            raise ValueError("file path must be string")
        if not _is_safe_rel(path):
            raise ValueError("file path must be safe relative path")
        parts = path.split("/")
        if len(parts) <= len(prefix_parts):
            continue
        if parts[:len(prefix_parts)] != prefix_parts:
            continue
        if not parts[-1].endswith(".tmp"):
            continue
        delete.append(path)

    delete.sort()
    return {"name": contract["name"], "result": {"delete": delete}}
