def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _safe_relative(value):
    if not isinstance(value, str):
        raise ValueError("destination must be a string")
    if value == "" or value.strip() != value:
        raise ValueError("destination must be non-empty")
    if value.startswith("/") or "\\" in value or ":" in value:
        raise ValueError("destination must be a safe relative path")
    parts = value.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("destination must be a safe relative path")
    return value


def transform(payloads, contract):
    snapshot = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    if not isinstance(classification, dict):
        raise ValueError("classification must be an object")

    destination = _safe_relative(snapshot.get("destination"))
    files = snapshot.get("files")
    selected = classification.get("selected")

    if not isinstance(files, list):
        raise ValueError("files must be a list")
    if not isinstance(selected, list):
        raise ValueError("selected must be a list")

    # Build a lookup of hex by path from the original snapshot.
    hex_by_path = {}
    for f in files:
        if not isinstance(f, dict) or "path" not in f or "hex" not in f:
            raise ValueError("file entry must have path and hex")
        hex_by_path[f["path"]] = f["hex"]

    # Determine which paths are selected.
    selected_paths = set()
    festival_by_path = {}
    for s in selected:
        if not isinstance(s, dict) or "path" not in s or "festival" not in s:
            raise ValueError("selected entry must have path and festival")
        selected_paths.add(s["path"])
        festival_by_path[s["path"]] = s["festival"]

    # Compute moves and new file list.
    moves = []
    new_files = []
    existing_paths = set(hex_by_path.keys())

    for f in files:
        path = f["path"]
        if path in selected_paths:
            to = destination + "/" + path
            if to in existing_paths:
                raise ValueError("target already exists")
            moves.append({"from": path, "to": to, "festival": festival_by_path[path]})
            new_files.append({"path": to, "hex": f["hex"]})
        else:
            new_files.append({"path": path, "hex": f["hex"]})

    moves.sort(key=lambda m: (m["from"], m["to"]))
    new_files.sort(key=lambda f: f["path"])

    result = {"moves": moves, "files": new_files}
    return {"name": contract["name"], "result": result}
