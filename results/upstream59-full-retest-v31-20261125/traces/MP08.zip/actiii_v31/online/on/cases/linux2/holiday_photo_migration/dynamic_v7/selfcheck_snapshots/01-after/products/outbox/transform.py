def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])
    migration = _unwrap(payloads[2])

    recipient = snapshot["recipient"]
    missing = classification["missing"]
    attachments = sorted(m["to"] for m in migration["moves"])

    if missing:
        message = "Missing: " + ", ".join(missing)
    else:
        message = "Photos ready"

    result = {
        "to": recipient,
        "attachments": attachments,
        "missing": missing,
        "message": message,
    }
    return {"name": contract["name"], "result": result}
