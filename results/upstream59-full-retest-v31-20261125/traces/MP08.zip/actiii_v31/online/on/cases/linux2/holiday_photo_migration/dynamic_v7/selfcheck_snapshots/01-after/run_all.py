import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Run each component's render.py CLI in dependency order.
    components = [
        ROOT / "products" / "classify" / "render.py",
        ROOT / "products" / "migrate" / "render.py",
        ROOT / "products" / "outbox" / "render.py",
    ]
    for comp in components:
        subprocess.run([sys.executable, str(comp)], cwd=ROOT, check=True)

    # Integrate component outputs into the core manifest.
    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)

    # Produce the final report.
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
