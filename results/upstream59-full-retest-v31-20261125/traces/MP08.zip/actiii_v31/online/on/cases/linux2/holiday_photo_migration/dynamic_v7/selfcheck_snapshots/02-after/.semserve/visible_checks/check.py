import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/classify/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/migrate/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/outbox/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestClassify(unittest.TestCase):
    def test_classify_api_boundary(self):
        payload = {
            "files": [{"path": "photos/a.jpg", "hex": "00"}],
            "photos": [{"path": "photos/a.jpg", "festival": "spring"}],
            "festivals": ["spring"],
            "destination": "holiday",
            "recipient": "friend",
        }
        contract = {"name": "classify", "inputs": ["x"], "output": "y"}
        check_api_boundary(
            "products/classify/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="任意嵌套NaN/Infinity抛ValueError",
            args=[[payload], contract],
        )
        check_api_boundary(
            "products/classify/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[payload], contract],
        )

    def test_classify_selection_and_missing(self):
        payload = {
            "files": [
                {"path": "photos/a.jpg", "hex": "00"},
                {"path": "photos/b.jpg", "hex": "01"},
                {"path": "photos/c.jpg", "hex": "02"},
            ],
            "photos": [
                {"path": "photos/a.jpg", "festival": "spring"},
                {"path": "photos/b.jpg", "festival": "winter"},
                {"path": "photos/c.jpg", "festival": "spring"},
            ],
            "festivals": ["spring", "summer"],
            "destination": "holiday",
            "recipient": "friend",
        }
        contract = {"name": "classify", "inputs": ["x"], "output": "y"}
        result = call_candidate(
            "products/classify/transform.py", "transform", args=[[payload], contract]
        )
        self.assertEqual(result["name"], "classify")
        r = result["result"]
        self.assertEqual(
            r["selected"],
            [
                {"path": "photos/a.jpg", "festival": "spring"},
                {"path": "photos/c.jpg", "festival": "spring"},
            ],
        )
        self.assertEqual(r["missing"], ["summer"])


class TestMigrate(unittest.TestCase):
    def test_migrate_api_boundary(self):
        snapshot = {
            "destination": "holiday",
            "files": [{"path": "photos/a.jpg", "hex": "00"}],
        }
        classification = {
            "selected": [{"path": "photos/a.jpg", "festival": "spring"}],
            "missing": [],
        }
        contract = {"name": "migrate", "inputs": ["x", "y"], "output": "z"}
        check_api_boundary(
            "products/migrate/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="任意嵌套NaN/Infinity抛ValueError",
            args=[[snapshot, classification], contract],
        )
        check_api_boundary(
            "products/migrate/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[snapshot, classification], contract],
        )

    def test_migrate_moves_and_files(self):
        snapshot = {
            "destination": "holiday",
            "files": [
                {"path": "photos/a.jpg", "hex": "00"},
                {"path": "photos/b.jpg", "hex": "01"},
            ],
        }
        classification = {
            "selected": [{"path": "photos/a.jpg", "festival": "spring"}],
            "missing": [],
        }
        contract = {"name": "migrate", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate(
            "products/migrate/transform.py",
            "transform",
            args=[[snapshot, classification], contract],
        )
        r = result["result"]
        self.assertEqual(
            r["moves"],
            [{"from": "photos/a.jpg", "to": "holiday/photos/a.jpg", "festival": "spring"}],
        )
        self.assertEqual(
            r["files"],
            [
                {"path": "holiday/photos/a.jpg", "hex": "00"},
                {"path": "photos/b.jpg", "hex": "01"},
            ],
        )


class TestOutbox(unittest.TestCase):
    def test_outbox_api_boundary(self):
        snapshot = {"recipient": "friend"}
        classification = {"missing": ["winter"]}
        migration = {
            "moves": [
                {"from": "photos/a.jpg", "to": "holiday/photos/a.jpg", "festival": "spring"}
            ]
        }
        contract = {"name": "outbox", "inputs": ["x", "y", "z"], "output": "w"}
        check_api_boundary(
            "products/outbox/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="任意嵌套NaN/Infinity抛ValueError",
            args=[[snapshot, classification, migration], contract],
        )
        check_api_boundary(
            "products/outbox/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[snapshot, classification, migration], contract],
        )

    def test_outbox_message_and_attachments(self):
        snapshot = {"recipient": "friend"}
        classification = {"missing": ["winter"]}
        migration = {
            "moves": [
                {"from": "photos/a.jpg", "to": "holiday/photos/a.jpg", "festival": "spring"}
            ]
        }
        contract = {"name": "outbox", "inputs": ["x", "y", "z"], "output": "w"}
        result = call_candidate(
            "products/outbox/transform.py",
            "transform",
            args=[[snapshot, classification, migration], contract],
        )
        r = result["result"]
        self.assertEqual(r["to"], "friend")
        self.assertEqual(r["attachments"], ["holiday/photos/a.jpg"])
        self.assertEqual(r["missing"], ["winter"])
        self.assertEqual(r["message"], "Missing: winter")


if __name__ == "__main__":
    unittest.main()
