import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _reject_nonfinite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _reject_nonfinite(value)


def _require_str(value, field):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("invalid " + field)
    return value


def _safe_rel_path(value):
    s = _require_str(value, "path")
    if s.startswith("/") or "\\" in s or ":" in s:
        raise ValueError("unsafe path")
    parts = s.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("unsafe path")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    _reject_nonfinite(data)

    files = data["files"]
    photos = data["photos"]
    festivals = data["festivals"]
    destination = data["destination"]
    recipient = data["recipient"]

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(photos, list):
        raise ValueError("photos must be list")
    if not isinstance(festivals, list):
        raise ValueError("festivals must be list")

    _safe_rel_path(destination)
    _require_str(recipient, "recipient")

    file_paths = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        fp = _safe_rel_path(f["path"])
        if fp in file_paths:
            raise ValueError("duplicate file path")
        file_paths[fp] = f

    festival_set = set()
    for fest in festivals:
        fs = _require_str(fest, "festival")
        if fs in festival_set:
            raise ValueError("duplicate festival")
        festival_set.add(fs)

    seen_photos = set()
    selected = []
    for ph in photos:
        if not isinstance(ph, dict):
            raise ValueError("photo entry must be object")
        pp = _safe_rel_path(ph["path"])
        pf = _require_str(ph["festival"], "festival")
        if pp in seen_photos:
            raise ValueError("duplicate photo path")
        seen_photos.add(pp)
        if pp not in file_paths:
            raise ValueError("photo path not in files")
        if pf in festival_set:
            selected.append({"path": pp, "festival": pf})

    selected.sort(key=lambda x: (x["festival"], x["path"]))

    selected_paths = {x["path"] for x in selected}
    missing = sorted(f for f in festivals if f not in {x["festival"] for x in selected})

    return {
        "name": contract["name"],
        "result": {
            "selected": selected,
            "missing": missing,
        },
    }
