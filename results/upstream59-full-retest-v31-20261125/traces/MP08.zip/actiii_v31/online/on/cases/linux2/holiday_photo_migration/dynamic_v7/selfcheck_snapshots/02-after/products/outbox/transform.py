import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _reject_nonfinite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _reject_nonfinite(value)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])
    migration = _unwrap(payloads[2])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    if not isinstance(classification, dict):
        raise ValueError("classification must be an object")
    if not isinstance(migration, dict):
        raise ValueError("migration must be an object")

    _reject_nonfinite(snapshot)
    _reject_nonfinite(classification)
    _reject_nonfinite(migration)

    recipient = snapshot["recipient"]
    missing = classification["missing"]
    attachments = sorted(m["to"] for m in migration["moves"])

    if missing:
        message = "Missing: " + ", ".join(missing)
    else:
        message = "Photos ready"

    result = {
        "to": recipient,
        "attachments": attachments,
        "missing": missing,
        "message": message,
    }
    return {"name": contract["name"], "result": result}
