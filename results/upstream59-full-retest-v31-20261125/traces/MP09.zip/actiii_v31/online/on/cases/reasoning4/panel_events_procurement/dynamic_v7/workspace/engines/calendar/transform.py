import math


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    now = data["now"]
    duration = data["duration"]
    gap = data["gap"]
    windows = data["windows"]
    busy = data["busy"]

    if not _is_int(now):
        raise ValueError("now must be int")
    if not _is_int(duration) or duration < 1:
        raise ValueError("duration must be int >= 1")
    if not _is_int(gap) or gap < 0:
        raise ValueError("gap must be int >= 0")

    if not isinstance(windows, list):
        raise ValueError("windows must be list")
    if not isinstance(busy, list):
        raise ValueError("busy must be list")

    # Build free intervals: union of windows minus busy, clipped at now.
    intervals = []
    for w in windows:
        if not isinstance(w, dict):
            raise ValueError("window must be object")
        start = w["start"]
        end = w["end"]
        if not _is_int(start) or not _is_int(end):
            raise ValueError("window start/end must be int")
        if end <= start:
            raise ValueError("window must have end > start")
        intervals.append((start, end))

    busy_intervals = []
    for b in busy:
        if not isinstance(b, dict):
            raise ValueError("busy must be object")
        start = b["start"]
        end = b["end"]
        if not _is_int(start) or not _is_int(end):
            raise ValueError("busy start/end must be int")
        if end <= start:
            raise ValueError("busy must have end > start")
        busy_intervals.append((start, end))

    # Merge windows union.
    merged = []
    for s, e in sorted(intervals):
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append([s, e])

    # Subtract busy intervals.
    free = []
    for s, e in merged:
        cur = s
        for bs, be in sorted(busy_intervals):
            if be <= cur:
                continue
            if bs >= e:
                break
            if bs > cur:
                free.append((cur, min(bs, e)))
            cur = max(cur, be)
            if cur >= e:
                break
        if cur < e:
            free.append((cur, e))

    # Clip at now.
    free = [(max(s, now), e) for s, e in free if e > now]

    slots = []
    # First slot: earliest free interval that can hold duration.
    first = None
    for s, e in free:
        if e - s >= duration:
            first = (s, s + duration)
            break
    if first is not None:
        slots.append({"start": first[0], "end": first[1]})
        # Second slot: earliest start >= first.end + gap.
        min_start = first[1] + gap
        for s, e in free:
            start = max(s, min_start)
            if e - start >= duration:
                slots.append({"start": start, "end": start + duration})
                break

    complete = len(slots) == 2
    return {"name": contract["name"], "result": {"slots": slots, "complete": complete}}
