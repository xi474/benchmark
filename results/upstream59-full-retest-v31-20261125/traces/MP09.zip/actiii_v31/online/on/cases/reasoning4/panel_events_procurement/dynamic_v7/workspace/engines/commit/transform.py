def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    slots = _unwrap(payloads[0])
    invitees = _unwrap(payloads[1])
    supply = _unwrap(payloads[2])

    if not isinstance(slots, dict) or not isinstance(invitees, dict) or not isinstance(supply, dict):
        raise ValueError("inputs must be objects")

    complete = slots.get("complete")
    if not isinstance(complete, bool):
        raise ValueError("complete must be bool")

    group_id = invitees.get("group_id")
    members = invitees.get("members")
    if not isinstance(group_id, str) or not group_id.strip():
        raise ValueError("group_id must be non-empty string")
    if not isinstance(members, list):
        raise ValueError("members must be list")

    events = []
    notification = None
    if complete:
        slot_list = slots.get("slots")
        if not isinstance(slot_list, list) or len(slot_list) != 2:
            raise ValueError("slots must be list of two")
        for i, s in enumerate(slot_list, start=1):
            if not isinstance(s, dict):
                raise ValueError("slot must be object")
            start = s.get("start")
            end = s.get("end")
            if not isinstance(start, int) or isinstance(start, bool):
                raise ValueError("slot start must be int")
            if not isinstance(end, int) or isinstance(end, bool):
                raise ValueError("slot end must be int")
            events.append({
                "id": group_id + "-" + str(i),
                "start": start,
                "end": end,
                "members": list(members),
            })
        notification = {
            "group_id": group_id,
            "members": list(members),
            "event_ids": [e["id"] for e in events],
        }

    purchase = supply

    return {"name": contract["name"], "result": {
        "events": events,
        "notification": notification,
        "purchase": purchase,
    }}
