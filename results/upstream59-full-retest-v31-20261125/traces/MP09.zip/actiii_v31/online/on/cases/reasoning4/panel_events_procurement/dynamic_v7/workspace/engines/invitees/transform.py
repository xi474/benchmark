def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    groups = data.get("groups")
    invite_groups = data.get("invite_groups")
    exclude = data.get("exclude")
    namespace = data.get("namespace")

    if not isinstance(groups, list):
        raise ValueError("groups must be list")
    if not isinstance(invite_groups, list):
        raise ValueError("invite_groups must be list")
    if not isinstance(exclude, list):
        raise ValueError("exclude must be list")
    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be non-empty string")

    group_map = {}
    for g in groups:
        if not isinstance(g, dict):
            raise ValueError("group must be object")
        gid = g.get("id")
        members = g.get("members")
        if not isinstance(gid, str) or not gid.strip():
            raise ValueError("group id must be non-empty string")
        if not isinstance(members, list) or len(members) == 0:
            raise ValueError("group members must be non-empty list")
        for m in members:
            if not isinstance(m, str) or not m.strip():
                raise ValueError("member id must be non-empty string")
        group_map[gid] = members

    member_set = set()
    for gid in invite_groups:
        if not isinstance(gid, str) or not gid.strip():
            raise ValueError("invite group id must be non-empty string")
        if gid not in group_map:
            raise ValueError("unknown group")
        for m in group_map[gid]:
            member_set.add(m)

    exclude_set = set()
    for e in exclude:
        if not isinstance(e, str) or not e.strip():
            raise ValueError("exclude id must be non-empty string")
        exclude_set.add(e)

    members = sorted(member_set - exclude_set)
    group_id = namespace + "-panel"

    return {"name": contract["name"], "result": {"members": members, "group_id": group_id}}
