import math


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _require_str(v, field):
    if not isinstance(v, str) or not v.strip():
        raise ValueError('invalid %s' % field)
    return v


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')

    products = payload['products']
    requirements = payload['requirements']
    if not isinstance(products, list):
        raise ValueError('products must be list')
    if not isinstance(requirements, list):
        raise ValueError('requirements must be list')

    # Validate products
    seen_ids = set()
    for p in products:
        if not isinstance(p, dict):
            raise ValueError('product must be object')
        pid = _require_str(p['id'], 'product.id')
        if pid in seen_ids:
            raise ValueError('duplicate product id')
        seen_ids.add(pid)
        _require_str(p['category'], 'product.category')
        stock = p['stock']
        price = p['price_cents']
        rating = p['rating']
        if not _is_int(stock) or stock < 0:
            raise ValueError('invalid stock')
        if not _is_int(price) or price < 0:
            raise ValueError('invalid price_cents')
        if not _is_int(rating) or rating < 0:
            raise ValueError('invalid rating')

    # Validate requirements: each category only one requirement
    req_by_cat = {}
    for r in requirements:
        if not isinstance(r, dict):
            raise ValueError('requirement must be object')
        cat = _require_str(r['category'], 'requirement.category')
        qty = r['quantity']
        if not _is_int(qty) or qty < 1:
            raise ValueError('invalid quantity')
        if cat in req_by_cat:
            raise ValueError('duplicate requirement category')
        req_by_cat[cat] = qty

    items = []
    unavailable = []
    for cat in sorted(req_by_cat):
        qty = req_by_cat[cat]
        candidates = [p for p in products if p['category'] == cat and p['stock'] >= qty]
        if not candidates:
            unavailable.append(cat)
            continue
        # max rating, then min price_cents, then min id
        best = min(candidates, key=lambda p: (-p['rating'], p['price_cents'], p['id']))
        items.append({
            'category': cat,
            'id': best['id'],
            'quantity': qty,
            'total_cents': best['price_cents'] * qty,
        })

    return {'name': contract['name'], 'result': {'items': items, 'unavailable': unavailable}}
