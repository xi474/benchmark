import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(ROOT.rglob("contract.json"))
    contracts = [c for c in contracts if "outputs" not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError("no contracts")

    # Topologically order by input dependency on other component outputs.
    outputs = {c.parent.name: str(ROOT / json.loads(c.read_text(encoding="utf-8"))["output"]) for c in contracts}
    names = {c.parent.name for c in contracts}

    def deps(c):
        data = json.loads(c.read_text(encoding="utf-8"))
        result = set()
        for p in data["inputs"]:
            for name in names:
                if str(ROOT / p) == Path(outputs[name]):
                    result.add(name)
        return result

    remaining = set(contracts)
    order = []
    while remaining:
        progressed = False
        for c in sorted(remaining, key=lambda x: x.parent.name):
            if deps(c) <= set(order):
                order.append(c)
                remaining.remove(c)
                progressed = True
                break
        if not progressed:
            raise ValueError("dependency cycle detected")

    for c in order:
        subprocess.run(
            [sys.executable, str(c.with_name("render.py")), str(ROOT), str(c)],
            cwd=ROOT,
            check=True,
        )

    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
