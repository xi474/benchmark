def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _require_int(value, field):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    return value


def _require_str(value, field):
    if not isinstance(value, str) or isinstance(value, bool):
        raise ValueError(f"{field} must be a string")
    if not value.strip():
        raise ValueError(f"{field} must be non-empty")
    return value


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    slots = _unwrap(payloads[0])
    invitees = _unwrap(payloads[1])
    supplies = _unwrap(payloads[2])

    if not isinstance(slots, dict) or not isinstance(invitees, dict) or not isinstance(supplies, dict):
        raise ValueError("inputs must be objects")

    # panel_slots
    slot_list = slots.get("slots")
    complete = slots.get("complete")
    if not isinstance(slot_list, list):
        raise ValueError("slots must be a list")
    if not isinstance(complete, bool):
        raise ValueError("complete must be a bool")

    # panel_invitees
    group_id = _require_str(invitees.get("group_id"), "group_id")
    members = invitees.get("members")
    if not isinstance(members, list):
        raise ValueError("members must be a list")
    for m in members:
        _require_str(m, "member id")

    # supply_selection
    items = supplies.get("items")
    unavailable = supplies.get("unavailable")
    if not isinstance(items, list):
        raise ValueError("items must be a list")
    if not isinstance(unavailable, list):
        raise ValueError("unavailable must be a list")

    events = []
    notification = None
    if complete:
        for i, slot in enumerate(slot_list, start=1):
            if not isinstance(slot, dict):
                raise ValueError("slot must be an object")
            start = _require_int(slot.get("start"), "start")
            end = _require_int(slot.get("end"), "end")
            events.append({
                "id": group_id + "-" + str(i),
                "start": start,
                "end": end,
                "members": list(members),
            })
        notification = {
            "group_id": group_id,
            "members": list(members),
            "event_ids": [e["id"] for e in events],
        }

    return {
        "name": contract["name"],
        "result": {
            "events": events,
            "notification": notification,
            "purchase": {
                "items": items,
                "unavailable": unavailable,
            },
        },
    }
