import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

_RUNNER = (
    "import sys, json\n"
    "from pathlib import Path\n"
    "sys.path.insert(0, sys.argv[1])\n"
    "from render import build_component\n"
    "root = Path(sys.argv[2])\n"
    "cp = Path(sys.argv[3])\n"
    "contract = json.loads(cp.read_text(encoding='utf-8'))\n"
    "result = build_component(root, cp)\n"
    "out = root / contract['output']\n"
    "out.parent.mkdir(parents=True, exist_ok=True)\n"
    "out.write_text(\n"
    "    json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\\n',\n"
    "    encoding='utf-8',\n"
    ")\n"
)


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts[c['name']] = (cp, c)
    return contracts


def _topo_order(contracts):
    producer = {}
    for name, (cp, c) in contracts.items():
        producer[str(ROOT / c['output'])] = name

    deps = {}
    for name, (cp, c) in contracts.items():
        d = set()
        for inp in c['inputs']:
            key = str(ROOT / inp)
            if key in producer and producer[key] != name:
                d.add(producer[key])
        deps[name] = d

    order = []
    remaining = set(contracts)
    while remaining:
        ready = sorted(n for n in remaining if deps[n] <= set(order))
        if not ready:
            raise ValueError('circular dependency among components')
        for n in ready:
            order.append(n)
            remaining.discard(n)
    return order


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError('no contracts')

    order = _topo_order(contracts)

    for name in order:
        cp, c = contracts[name]
        render = cp.with_name('render.py')
        if not render.is_file():
            raise ValueError('missing render.py for %s' % name)
        subprocess.run(
            [sys.executable, '-c', _RUNNER, str(cp.parent), str(ROOT), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == '__main__':
    main()
