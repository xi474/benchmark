import unittest

# Injected by the visible-contract SDK runner: call_candidate,
# check_api_boundary, and CandidateCallError are provided directly.


README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/invitees/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/supplies/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/commit/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class CalendarBehavior(unittest.TestCase):
    def test_slots_greedy_earliest(self):
        payload = {
            "now": 30,
            "windows": [{"id": "w1", "start": 0, "end": 600},
                        {"id": "w2", "start": 600, "end": 1200}],
            "busy": [{"id": "b", "start": 200, "end": 300}],
            "duration": 180,
            "gap": 60,
        }
        contract = {"name": "calendar", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/calendar/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "calendar")
        r = result["result"]
        self.assertEqual(r["slots"], [{"start": 300, "end": 480},
                                      {"start": 540, "end": 720}])
        self.assertTrue(r["complete"])

    def test_incomplete_when_no_second_slot(self):
        payload = {
            "now": 0,
            "windows": [{"id": "w1", "start": 0, "end": 100}],
            "busy": [],
            "duration": 60,
            "gap": 0,
        }
        contract = {"name": "calendar", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/calendar/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["slots"], [{"start": 0, "end": 60}])
        self.assertFalse(r["complete"])


class InviteesBehavior(unittest.TestCase):
    def test_union_exclude_sort(self):
        payload = {
            "groups": [{"id": "a", "members": ["one", "two"]},
                       {"id": "b", "members": ["two", "three"]}],
            "invite_groups": ["a", "b"],
            "exclude": ["one"],
            "namespace": "n47",
        }
        contract = {"name": "invitees", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/invitees/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["members"], ["three", "two"])
        self.assertEqual(r["group_id"], "n47-panel")

    def test_unknown_group_raises(self):
        payload = {
            "groups": [{"id": "a", "members": ["one"]}],
            "invite_groups": ["zzz"],
            "exclude": [],
            "namespace": "n",
        }
        contract = {"name": "invitees", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("engines/invitees/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class SuppliesBehavior(unittest.TestCase):
    def test_rating_then_price_then_id(self):
        payload = {
            "products": [
                {"id": "p1", "category": "c", "stock": 10, "price_cents": 100, "rating": 5},
                {"id": "p2", "category": "c", "stock": 10, "price_cents": 50, "rating": 5},
                {"id": "p3", "category": "c", "stock": 10, "price_cents": 50, "rating": 9},
            ],
            "requirements": [{"category": "c", "quantity": 2}],
        }
        contract = {"name": "supplies", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/supplies/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["items"], [{"category": "c", "id": "p3",
                                       "quantity": 2, "total_cents": 100}])
        self.assertEqual(r["unavailable"], [])

    def test_unavailable_when_insufficient_stock(self):
        payload = {
            "products": [{"id": "p1", "category": "c", "stock": 1,
                          "price_cents": 10, "rating": 5}],
            "requirements": [{"category": "c", "quantity": 5}],
        }
        contract = {"name": "supplies", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/supplies/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["items"], [])
        self.assertEqual(r["unavailable"], ["c"])


class CommitBehavior(unittest.TestCase):
    def test_two_events_and_notification(self):
        slots = {"slots": [{"start": 300, "end": 480}, {"start": 540, "end": 720}],
                 "complete": True}
        invitees = {"group_id": "n47-panel", "members": ["three", "two"]}
        supplies = {"items": [], "unavailable": []}
        contract = {"name": "commit", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate("engines/commit/transform.py", "transform",
                                args=[[slots, invitees, supplies], contract])
        r = result["result"]
        self.assertEqual([e["id"] for e in r["events"]],
                         ["n47-panel-1", "n47-panel-2"])
        self.assertEqual(r["notification"]["event_ids"],
                         ["n47-panel-1", "n47-panel-2"])
        self.assertEqual(r["notification"]["members"], ["three", "two"])
        self.assertEqual(r["purchase"], {"items": [], "unavailable": []})

    def test_incomplete_no_events(self):
        slots = {"slots": [{"start": 0, "end": 60}], "complete": False}
        invitees = {"group_id": "g-panel", "members": ["m"]}
        supplies = {"items": [], "unavailable": []}
        contract = {"name": "commit", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate("engines/commit/transform.py", "transform",
                                args=[[slots, invitees, supplies], contract])
        r = result["result"]
        self.assertEqual(r["events"], [])
        self.assertIsNone(r["notification"])
        self.assertEqual(r["purchase"], {"items": [], "unavailable": []})


class ApiBoundary(unittest.TestCase):
    def test_boundaries(self):
        seeds = {
            "engines/calendar/transform.py": [{"now": 0, "windows": [], "busy": [],
                                               "duration": 1, "gap": 0}],
            "engines/invitees/transform.py": [{"groups": [], "invite_groups": [],
                                               "exclude": [], "namespace": "n"}],
            "engines/supplies/transform.py": [{"products": [], "requirements": []}],
            "engines/commit/transform.py": [
                {"slots": [], "complete": False},
                {"group_id": "g", "members": []},
                {"items": [], "unavailable": []},
            ],
        }
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=req["target_path"], rule=rule):
                    seed = seeds[req["target_path"]]
                    n = len(seed)
                    check_api_boundary(
                        req["target_path"], rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=[seed, {"name": "x", "inputs": ["i"] * n,
                                     "output": "o"}])


if __name__ == "__main__":
    unittest.main()
