import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
        return obj
    if isinstance(obj, dict):
        return {k: _reject_nonfinite(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_reject_nonfinite(v) for v in obj]
    return obj


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _require_int(value, name):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(name)
    return value


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    data = _reject_nonfinite(data)

    now = _require_int(data["now"], "now")
    duration = _require_int(data["duration"], "duration")
    gap = _require_int(data["gap"], "gap")
    if duration < 1:
        raise ValueError("duration")
    if gap < 0:
        raise ValueError("gap")

    windows = data["windows"]
    busy = data["busy"]
    if not isinstance(windows, list) or not isinstance(busy, list):
        raise ValueError("windows/busy")

    # Build free intervals: union of windows minus busy, clipped at now.
    intervals = []
    for w in windows:
        if not isinstance(w, dict):
            raise ValueError("window")
        start = _require_int(w["start"], "start")
        end = _require_int(w["end"], "end")
        if end <= start:
            raise ValueError("window end<=start")
        intervals.append((start, end))

    for b in busy:
        if not isinstance(b, dict):
            raise ValueError("busy")
        start = _require_int(b["start"], "start")
        end = _require_int(b["end"], "end")
        if end <= start:
            raise ValueError("busy end<=start")
        intervals.append((start, end))

    # Merge intervals (union of windows), then subtract busy.
    # Simpler: compute free segments by sweeping.
    # Collect all boundary points.
    free = []
    # Sort windows and merge.
    merged = []
    for s, e in sorted(intervals):
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    # Subtract busy intervals.
    for s, e in merged:
        cur = s
        for b in busy:
            bs = _require_int(b["start"], "start")
            be = _require_int(b["end"], "end")
            if be <= cur:
                continue
            if bs >= e:
                break
            if bs > cur:
                free.append((cur, bs))
            cur = max(cur, be)
            if cur >= e:
                break
        if cur < e:
            free.append((cur, e))

    # Clip at now.
    free = [(max(s, now), e) for s, e in free if e > now]

    slots = []
    # First slot: earliest free interval that can hold duration.
    first = None
    for s, e in free:
        if e - s >= duration:
            first = (s, s + duration)
            break

    if first is not None:
        slots.append({"start": first[0], "end": first[1]})
        # Second slot: earliest start >= first.end + gap.
        min_start = first[1] + gap
        for s, e in free:
            start = max(s, min_start)
            if e - start >= duration:
                slots.append({"start": start, "end": start + duration})
                break

    complete = len(slots) == 2
    return {"name": contract["name"], "result": {"slots": slots, "complete": complete}}
