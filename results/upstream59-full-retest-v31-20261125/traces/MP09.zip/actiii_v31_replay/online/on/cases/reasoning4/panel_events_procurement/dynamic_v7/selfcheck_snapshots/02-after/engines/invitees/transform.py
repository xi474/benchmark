import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
        return obj
    if isinstance(obj, dict):
        return {k: _reject_nonfinite(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_reject_nonfinite(v) for v in obj]
    return obj


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _require_str(value, field):
    if not isinstance(value, str) or isinstance(value, bool):
        raise ValueError(f"{field} must be a string")
    if not value.strip():
        raise ValueError(f"{field} must be non-empty")
    return value


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    data = _reject_nonfinite(data)

    groups = data.get("groups")
    invite_groups = data.get("invite_groups")
    exclude = data.get("exclude")
    namespace = data.get("namespace")

    if not isinstance(groups, list):
        raise ValueError("groups must be a list")
    if not isinstance(invite_groups, list):
        raise ValueError("invite_groups must be a list")
    if not isinstance(exclude, list):
        raise ValueError("exclude must be a list")
    namespace = _require_str(namespace, "namespace")

    group_map = {}
    for g in groups:
        if not isinstance(g, dict):
            raise ValueError("group must be an object")
        gid = _require_str(g.get("id"), "group id")
        members = g.get("members")
        if not isinstance(members, list) or not members:
            raise ValueError("group members must be a non-empty list")
        for m in members:
            _require_str(m, "member id")
        group_map[gid] = members

    exclude_set = set()
    for e in exclude:
        exclude_set.add(_require_str(e, "exclude id"))

    selected = set()
    for gid in invite_groups:
        gid = _require_str(gid, "invite group id")
        if gid not in group_map:
            raise ValueError("unknown group")
        for m in group_map[gid]:
            selected.add(m)

    members = sorted(m for m in selected if m not in exclude_set)

    return {
        "name": contract["name"],
        "result": {
            "members": members,
            "group_id": namespace + "-panel",
        },
    }
