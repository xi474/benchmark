import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
        return obj
    if isinstance(obj, dict):
        return {k: _reject_nonfinite(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_reject_nonfinite(v) for v in obj]
    return obj


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _require_int(value, field):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    return value


def _require_finite_number(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a finite number")
    if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
        raise ValueError(f"{field} must be finite")
    return value


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    data = _reject_nonfinite(data)

    products = data.get("products")
    requirements = data.get("requirements")
    if not isinstance(products, list) or not isinstance(requirements, list):
        raise ValueError("products/requirements must be lists")

    # Validate products
    for p in products:
        if not isinstance(p, dict):
            raise ValueError("product must be object")
        for k in ("id", "category"):
            if not isinstance(p.get(k), str) or not p.get(k).strip():
                raise ValueError("product id/category must be non-empty string")
        _require_int(p.get("stock"), "stock")
        _require_int(p.get("price_cents"), "price_cents")
        _require_int(p.get("rating"), "rating")
        if p["stock"] < 0:
            raise ValueError("stock must be >= 0")
        if p["price_cents"] < 0:
            raise ValueError("price_cents must be >= 0")
        if p["rating"] < 0:
            raise ValueError("rating must be >= 0")

    # Validate requirements
    seen_categories = set()
    for r in requirements:
        if not isinstance(r, dict):
            raise ValueError("requirement must be object")
        cat = r.get("category")
        if not isinstance(cat, str) or not cat.strip():
            raise ValueError("requirement category must be non-empty string")
        if cat in seen_categories:
            raise ValueError("duplicate requirement category")
        seen_categories.add(cat)
        qty = _require_int(r.get("quantity"), "quantity")
        if qty < 1:
            raise ValueError("quantity must be >= 1")

    items = []
    unavailable = []
    for r in requirements:
        cat = r["category"]
        qty = r["quantity"]
        candidates = [p for p in products if p["category"] == cat and p["stock"] >= qty]
        if not candidates:
            unavailable.append(cat)
            continue
        # rating max, then price_cents min, then id min
        best = min(candidates, key=lambda p: (-p["rating"], p["price_cents"], p["id"]))
        items.append({
            "category": cat,
            "id": best["id"],
            "quantity": qty,
            "total_cents": best["price_cents"] * qty,
        })

    items.sort(key=lambda x: x["category"])
    unavailable.sort()

    return {"name": contract["name"], "result": {"items": items, "unavailable": unavailable}}
