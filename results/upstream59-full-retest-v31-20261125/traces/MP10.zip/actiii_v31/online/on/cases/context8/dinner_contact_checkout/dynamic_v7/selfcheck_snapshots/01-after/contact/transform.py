def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    conversations = data["conversations"]
    topic = data["topic"]
    needle = topic.casefold()
    best = None
    for conv in conversations:
        if needle in conv["topic"].casefold():
            if best is None or conv["ts"] > best["ts"] or (conv["ts"] == best["ts"] and conv["id"] < best["id"]):
                best = conv
    if best is None:
        result = {"contact_id": None, "conversation_id": None}
    else:
        result = {"contact_id": best["contact_id"], "conversation_id": best["id"]}
    return {"name": contract["name"], "result": result}
