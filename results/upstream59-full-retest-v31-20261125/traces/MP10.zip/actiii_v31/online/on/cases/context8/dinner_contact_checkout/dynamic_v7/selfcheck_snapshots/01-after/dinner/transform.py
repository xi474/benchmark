import datetime


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    today = payload["today"]
    weekday = payload["weekday"]
    hour = payload["hour"]
    guest_count = payload["guest_count"]

    if not isinstance(today, str):
        raise ValueError("today must be string")
    if not _is_int(weekday) or not (0 <= weekday <= 6):
        raise ValueError("weekday must be int 0..6")
    if not _is_int(hour) or not (0 <= hour <= 23):
        raise ValueError("hour must be int 0..23")
    if not _is_int(guest_count) or guest_count < 1:
        raise ValueError("guest_count must be int >= 1")

    d = datetime.date.fromisoformat(today)
    delta = (weekday - d.weekday()) % 7
    if delta == 0:
        delta = 7
    target = d + datetime.timedelta(days=delta)

    start = "%sT%02d:00" % (target.isoformat(), hour)
    return {"name": contract["name"], "result": {"start": start, "guest_count": guest_count}}
