import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(ROOT.rglob('contract.json'))
    contracts = [c for c in contracts if 'outputs' not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError('no contracts')

    names = []
    contracts_by_name = {}
    outputs = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        names.append(c['name'])
        contracts_by_name[c['name']] = cp
        outputs[c['name']] = str(ROOT / c['output'])

    done = set()
    order = []
    while len(order) < len(contracts):
        progressed = False
        for name in names:
            if name in done:
                continue
            cp = contracts_by_name[name]
            c = json.loads(cp.read_text(encoding='utf-8'))
            dep_names = []
            for p in c['inputs']:
                for n, o in outputs.items():
                    if str(ROOT / p) == o:
                        dep_names.append(n)
            if all(d in done for d in dep_names):
                order.append(name)
                done.add(name)
                progressed = True
        if not progressed:
            raise ValueError('dependency cycle or missing dependency')

    for name in order:
        cp = contracts_by_name[name]
        subprocess.run([sys.executable, str(cp.parent / 'render.py')], cwd=ROOT, check=True)

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
