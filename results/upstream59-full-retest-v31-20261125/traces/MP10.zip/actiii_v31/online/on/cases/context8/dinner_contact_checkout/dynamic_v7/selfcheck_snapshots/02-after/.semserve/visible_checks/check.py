import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "dinner/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "contact/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "shopping/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        dinner_payload = {"today": "2026-11-04", "weekday": 5, "hour": 19, "guest_count": 6}
        dinner_contract = {"name": "dinner", "inputs": ["x"], "output": "y"}
        contact_payload = {
            "conversations": [{"id": "a", "contact_id": "c1", "ts": 1, "topic": "dinner"}],
            "topic": "dinner",
        }
        contact_contract = {"name": "contact", "inputs": ["x"], "output": "y"}
        dinner_args = [[dinner_payload], dinner_contract]
        contact_args = [[contact_payload], contact_contract]
        snapshot = {
            "variants": [
                {"id": "v1", "kind": "plate", "attributes": {"c": "w"}, "stock": 10, "price_cents": 100},
            ],
            "wanted": [{"kind": "plate", "attributes": {"c": "w"}}],
        }
        dinner = {"start": "2026-11-07T19:00", "guest_count": 2}
        contact = {"contact_id": "c1", "conversation_id": "a"}
        shopping_contract = {"name": "shopping", "inputs": ["a", "b", "c"], "output": "y"}

        with self.subTest(component="dinner", rule="invalid_payload_type"):
            check_api_boundary(
                "dinner/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                args=dinner_args,
            )
        with self.subTest(component="dinner", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "dinner/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                args=dinner_args,
            )
        with self.subTest(component="contact", rule="invalid_payload_type"):
            check_api_boundary(
                "contact/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                args=contact_args,
            )
        with self.subTest(component="contact", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "contact/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                args=contact_args,
            )
        with self.subTest(component="shopping", rule="invalid_payload_type"):
            check_api_boundary(
                "shopping/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                args=[[snapshot, dinner, contact], shopping_contract],
            )
        with self.subTest(component="shopping", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "shopping/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                args=[[snapshot, dinner, contact], shopping_contract],
            )


class TestDinner(unittest.TestCase):
    def test_dinner_date_next_weekday(self):
        # today 2026-11-04 (Wed), weekday 5 (Sat) -> 2026-11-07
        payload = {"today": "2026-11-04", "weekday": 5, "hour": 19, "guest_count": 6}
        contract = {"name": "dinner", "inputs": ["x"], "output": "y"}
        result = call_candidate("dinner/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["start"], "2026-11-07T19:00")
        self.assertEqual(result["result"]["guest_count"], 6)

    def test_dinner_same_weekday_adds_seven(self):
        # today 2026-11-04 is Wednesday (weekday 2); request weekday 2 -> +7 days
        payload = {"today": "2026-11-04", "weekday": 2, "hour": 8, "guest_count": 1}
        contract = {"name": "dinner", "inputs": ["x"], "output": "y"}
        result = call_candidate("dinner/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["start"], "2026-11-11T08:00")


class TestContact(unittest.TestCase):
    def test_contact_max_ts_then_min_id(self):
        payload = {
            "conversations": [
                {"id": "b", "contact_id": "c2", "ts": 5, "topic": "Dinner plans"},
                {"id": "a", "contact_id": "c1", "ts": 5, "topic": "dinner"},
                {"id": "c", "contact_id": "c3", "ts": 9, "topic": "lunch"},
            ],
            "topic": "dinner",
        }
        contract = {"name": "contact", "inputs": ["x"], "output": "y"}
        result = call_candidate("contact/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"], {"contact_id": "c1", "conversation_id": "a"})

    def test_contact_no_match_nulls(self):
        payload = {
            "conversations": [{"id": "a", "contact_id": "c1", "ts": 1, "topic": "lunch"}],
            "topic": "dinner",
        }
        contract = {"name": "contact", "inputs": ["x"], "output": "y"}
        result = call_candidate("contact/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"], {"contact_id": None, "conversation_id": None})


class TestShopping(unittest.TestCase):
    def test_shopping_checkout_and_total(self):
        snapshot = {
            "variants": [
                {"id": "v1", "kind": "plate", "attributes": {"c": "w"}, "stock": 10, "price_cents": 100},
                {"id": "v2", "kind": "cup", "attributes": {"c": "w"}, "stock": 10, "price_cents": 50},
            ],
            "wanted": [
                {"kind": "plate", "attributes": {"c": "w"}},
                {"kind": "cup", "attributes": {"c": "w"}},
            ],
        }
        dinner = {"start": "2026-11-07T19:00", "guest_count": 2}
        contact = {"contact_id": "c1", "conversation_id": "a"}
        contract = {"name": "shopping", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate(
            "shopping/transform.py", "transform", args=[[snapshot, dinner, contact], contract]
        )
        r = result["result"]
        self.assertTrue(r["checkout"])
        self.assertEqual(r["recipient"], "c1")
        self.assertEqual(r["total_cents"], 300)
        self.assertEqual(r["unavailable"], [])
        self.assertEqual([i["kind"] for i in r["items"]], ["cup", "plate"])

    def test_shopping_unavailable_blocks_checkout(self):
        snapshot = {
            "variants": [
                {"id": "v1", "kind": "plate", "attributes": {"c": "w"}, "stock": 1, "price_cents": 100},
            ],
            "wanted": [
                {"kind": "plate", "attributes": {"c": "w"}},
                {"kind": "cup", "attributes": {"c": "w"}},
            ],
        }
        dinner = {"start": "2026-11-07T19:00", "guest_count": 2}
        contact = {"contact_id": "c1", "conversation_id": "a"}
        contract = {"name": "shopping", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate(
            "shopping/transform.py", "transform", args=[[snapshot, dinner, contact], contract]
        )
        r = result["result"]
        self.assertFalse(r["checkout"])
        self.assertEqual(r["unavailable"], ["cup", "plate"])


if __name__ == "__main__":
    unittest.main()
