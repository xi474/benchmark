import math


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
        return
    if isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("payload must be object")
    _reject_nonfinite(data)
    conversations = data["conversations"]
    topic = data["topic"]
    needle = topic.casefold()
    best = None
    for conv in conversations:
        if needle in conv["topic"].casefold():
            if best is None or conv["ts"] > best["ts"] or (conv["ts"] == best["ts"] and conv["id"] < best["id"]):
                best = conv
    if best is None:
        result = {"contact_id": None, "conversation_id": None}
    else:
        result = {"contact_id": best["contact_id"], "conversation_id": best["id"]}
    return {"name": contract["name"], "result": result}
