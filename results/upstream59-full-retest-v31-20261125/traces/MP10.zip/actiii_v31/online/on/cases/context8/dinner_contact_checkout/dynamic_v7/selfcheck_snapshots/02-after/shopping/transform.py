import math


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj) == {"name", "result"}:
        return obj["result"]
    return obj


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
        return
    if isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    dinner = _unwrap(payloads[1])
    contact = _unwrap(payloads[2])

    for p in (snapshot, dinner, contact):
        if not isinstance(p, dict):
            raise ValueError("payload must be object")
        _reject_nonfinite(p)

    guest_count = dinner["guest_count"]
    start = dinner["start"]
    recipient = contact["contact_id"]

    variants = snapshot["variants"]
    wanted = snapshot["wanted"]

    # kind -> wanted attributes
    wanted_by_kind = {}
    for w in wanted:
        kind = w["kind"]
        if kind in wanted_by_kind:
            raise ValueError("duplicate kind")
        wanted_by_kind[kind] = w["attributes"]

    # For each kind, find candidate variants: attributes exactly equal and stock >= guest_count
    items = []
    unavailable = []
    for kind in sorted(wanted_by_kind):
        attrs = wanted_by_kind[kind]
        candidates = [
            v for v in variants
            if v["kind"] == kind
            and v["attributes"] == attrs
            and v["stock"] >= guest_count
        ]
        if not candidates:
            unavailable.append(kind)
            continue
        # lowest price_cents, then id
        best = min(candidates, key=lambda v: (v["price_cents"], v["id"]))
        items.append({"id": best["id"], "kind": kind, "quantity": guest_count})

    items.sort(key=lambda it: it["kind"])
    unavailable.sort()

    total_cents = sum(it["quantity"] * _price_of(variants, it["id"]) for it in items)

    checkout = (len(unavailable) == 0) and (recipient is not None)

    return {
        "name": contract["name"],
        "result": {
            "items": items,
            "total_cents": total_cents,
            "checkout": checkout,
            "recipient": recipient,
            "start": start,
            "unavailable": unavailable,
        },
    }


def _price_of(variants, vid):
    for v in variants:
        if v["id"] == vid:
            return v["price_cents"]
    raise ValueError("variant not found")
