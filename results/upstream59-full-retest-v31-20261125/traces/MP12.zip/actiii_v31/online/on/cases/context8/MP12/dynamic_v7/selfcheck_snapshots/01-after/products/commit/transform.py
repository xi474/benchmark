import copy


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    archive = _unwrap(payloads[1])
    trash = _unwrap(payloads[2])
    reply = _unwrap(payloads[3])

    trash_ids = set(trash["trash_ids"])
    if reply["email_id"] in trash_ids:
        raise ValueError("reply target is in trash_ids")

    # Replay file migrations.
    files = {f["path"]: f["hex"] for f in snapshot["files"]}
    for move in archive["moves"]:
        src = move["from"]
        dst = move["to"]
        if src not in files:
            raise ValueError("move source not found")
        if dst in files:
            raise ValueError("move target already exists")
        files[dst] = files.pop(src)

    out_files = [
        {"path": p, "hex": h} for p, h in sorted(files.items())
    ]

    # Apply trash folder to matching emails.
    emails = []
    for email in snapshot["emails"]:
        e = copy.deepcopy(email)
        if e["id"] in trash_ids:
            e["folder"] = "TRASH"
        emails.append(e)
    emails.sort(key=lambda e: e["id"])

    return {
        "name": contract["name"],
        "result": {
            "files": out_files,
            "emails": emails,
            "reply": reply,
        },
    }
