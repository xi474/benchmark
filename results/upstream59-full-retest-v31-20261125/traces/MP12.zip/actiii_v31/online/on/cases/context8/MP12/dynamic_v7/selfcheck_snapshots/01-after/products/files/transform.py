import os


def _safe_relative(path):
    if not isinstance(path, str):
        raise ValueError("path must be str")
    if path == "" or path.startswith("/") or "\\" in path or ":" in path:
        raise ValueError("unsafe path")
    parts = path.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("unsafe path")
    return parts


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    files = data["files"]
    download_prefix = data["download_prefix"]
    archive_prefix = data["archive_prefix"]
    extensions = data["extensions"]

    moves = []
    seen_targets = set()
    for f in files:
        path = f["path"]
        parts = _safe_relative(path)
        if len(parts) != 2 or parts[0] != download_prefix:
            continue
        basename = parts[1]
        ext = os.path.splitext(basename)[1]
        subdir = None
        for e, d in extensions.items():
            if ext.lower() == e.lower():
                subdir = d
                break
        if subdir is None:
            continue
        target = "/".join([archive_prefix, subdir, basename])
        if target in seen_targets:
            raise ValueError("target already exists")
        seen_targets.add(target)
        moves.append({"from": path, "to": target})

    moves.sort(key=lambda m: m["from"])
    return {"name": contract["name"], "result": {"moves": moves}}
