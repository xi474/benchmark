import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise SystemExit("no contracts found")

    # Topologically order by input dependencies among component outputs.
    # Each contract's inputs may reference outputs/*.json produced by others.
    produced = {}
    remaining = list(contracts)
    ordered = []
    while remaining:
        progressed = False
        for cp in list(remaining):
            import json
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [
                (ROOT / p).resolve()
                for p in c["inputs"]
                if str(p).startswith("outputs/")
            ]
            if all(d in produced for d in deps):
                ordered.append(cp)
                produced[(ROOT / c["output"]).resolve()] = cp
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise SystemExit("dependency cycle or missing dependency among components")

    for cp in ordered:
        r = subprocess.run(
            [sys.executable, str(cp.with_name("render.py")), str(cp)],
            cwd=ROOT,
        )
        if r.returncode != 0:
            raise SystemExit(r.returncode)

    r = subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT)
    if r.returncode != 0:
        raise SystemExit(r.returncode)

    r = subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT)
    if r.returncode != 0:
        raise SystemExit(r.returncode)


if __name__ == "__main__":
    main()
