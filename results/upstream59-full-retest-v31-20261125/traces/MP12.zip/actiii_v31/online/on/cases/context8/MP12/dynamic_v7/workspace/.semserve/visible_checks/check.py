import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/files/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/mail/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/reply/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/commit/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestVisibleContract(unittest.TestCase):
    def test_api_boundary_rules(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule_name, rule in req["rules"].items():
                with self.subTest(target=req["target_path"], rule=rule_name):
                    if rule["applicable"]:
                        check_api_boundary(
                            req["target_path"],
                            rule=rule_name,
                            contract_path=rule["contract_path"],
                            requirement_quote=rule["requirement_quote"],
                            args=[[{"files": [], "download_prefix": "Downloads",
                                    "archive_prefix": "Archive", "extensions": {},
                                    "emails": [{"id": "e1", "date": "2026-11-01",
                                                "subject": "x", "folder": "INBOX",
                                                "sender": "manager", "thread_id": "t1"}],
                                    "month": "2026-11",
                                    "trash_keyword": "news", "reply_email_id": "e1",
                                    "manager": "manager", "reply_text": ""},
                                   {"moves": []}, {"trash_ids": []},
                                   {"email_id": "e1", "thread_id": "t1",
                                    "to": "manager", "text": ""}],
                                  {"name": "files", "operation": "download_archive",
                                   "inputs": ["inputs/case.json"], "output": "outputs/files.json"}],
                        )
                    else:
                        self.skipTest(rule["reason"])

    def test_files_archive_moves(self):
        payload = {
            "files": [
                {"path": "Downloads/a.PNG", "hex": "00"},
                {"path": "Downloads/b.txt", "hex": "01"},
                {"path": "Downloads/sub/c.PNG", "hex": "02"},
            ],
            "download_prefix": "Downloads",
            "archive_prefix": "Archive",
            "extensions": {".png": "images"},
        }
        contract = {"name": "files", "operation": "download_archive",
                    "inputs": ["inputs/case.json"], "output": "outputs/files.json"}
        result = call_candidate("products/files/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "files")
        self.assertEqual(result["result"]["moves"],
                         [{"from": "Downloads/a.PNG", "to": "Archive/images/a.PNG"}])

    def test_mail_trash_selection(self):
        payload = {
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "Newsletter",
                 "folder": "INBOX", "sender": "s", "thread_id": "t1"},
                {"id": "e2", "date": "2026-11-02", "subject": "News",
                 "folder": "TRASH", "sender": "s", "thread_id": "t2"},
                {"id": "e3", "date": "2026-10-01", "subject": "news",
                 "folder": "INBOX", "sender": "s", "thread_id": "t3"},
            ],
            "month": "2026-11",
            "trash_keyword": "news",
        }
        contract = {"name": "mail", "operation": "mail_trash",
                    "inputs": ["inputs/case.json"], "output": "outputs/mail.json"}
        result = call_candidate("products/mail/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["trash_ids"], ["e1"])

    def test_reply_manager(self):
        payload = {
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "x",
                 "folder": "INBOX", "sender": "manager", "thread_id": "t1"},
            ],
            "reply_email_id": "e1",
            "manager": "manager",
            "reply_text": "ok",
        }
        contract = {"name": "reply", "operation": "manager_reply",
                    "inputs": ["inputs/case.json"], "output": "outputs/reply.json"}
        result = call_candidate("products/reply/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"],
                         {"email_id": "e1", "thread_id": "t1",
                          "to": "manager", "text": "ok"})

    def test_reply_wrong_sender_raises(self):
        payload = {
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "x",
                 "folder": "INBOX", "sender": "other", "thread_id": "t1"},
            ],
            "reply_email_id": "e1",
            "manager": "manager",
            "reply_text": "ok",
        }
        contract = {"name": "reply", "operation": "manager_reply",
                    "inputs": ["inputs/case.json"], "output": "outputs/reply.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/reply/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")

    def test_commit_reply_in_trash_raises(self):
        snapshot = {
            "files": [], "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "x",
                 "folder": "INBOX", "sender": "manager", "thread_id": "t1"},
            ],
        }
        archive = {"moves": []}
        trash = {"trash_ids": ["e1"]}
        reply = {"email_id": "e1", "thread_id": "t1", "to": "manager", "text": "ok"}
        contract = {"name": "commit", "operation": "workspace_commit",
                    "inputs": ["inputs/case.json", "outputs/files.json",
                               "outputs/mail.json", "outputs/reply.json"],
                    "output": "outputs/commit.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/commit/transform.py", "transform",
                           args=[[snapshot, archive, trash, reply], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
