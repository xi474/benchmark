def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    records = payload["records"]

    ids = set()
    for r in records:
        if not isinstance(r, dict):
            raise ValueError("record must be object")
        if "id" not in r or "key" not in r or "value" not in r:
            raise ValueError("missing required field")
        rid = r["id"]
        if rid in ids:
            raise ValueError("duplicate record id")
        ids.add(rid)

    groups = {}
    for r in records:
        key = r["key"]
        value = r["value"]
        if value is None:
            groups.setdefault(key, [0, 0])
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("value must be finite number or null")
        if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
            raise ValueError("non-finite value")
        cnt, total = groups.setdefault(key, [0, 0])
        groups[key] = [cnt + 1, total + value]

    rows = []
    for key in sorted(groups):
        cnt, total = groups[key]
        mean = (total / cnt) if cnt else None
        rows.append({"key": key, "values": {"count": cnt, "sum": total, "mean": mean}})

    return {"name": contract["name"], "result": {"rows": rows}}
