import json
from pathlib import Path


def _validate(value):
    if isinstance(value, list):
        for item in value:
            _validate(item)
    elif isinstance(value, dict):
        for item in value.values():
            _validate(item)
    elif isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("non-finite number")
    return value


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError("invalid JSON") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _validate(data)
    return data
