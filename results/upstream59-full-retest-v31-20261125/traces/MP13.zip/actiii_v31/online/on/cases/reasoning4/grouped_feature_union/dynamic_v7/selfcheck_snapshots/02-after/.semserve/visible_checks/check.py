import unittest

# Injected names (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception with details dict

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/numeric/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/category/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/time/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/union/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestNumericBehavior(unittest.TestCase):
    def test_numeric_grouping_and_mean(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 10, "category": None, "time": None},
                {"id": "b", "key": "g1", "value": 20, "category": None, "time": None},
                {"id": "c", "key": "g2", "value": None, "category": None, "time": None},
            ],
            "vocabulary": [],
        }
        contract = {"name": "numeric", "operation": "numeric_features", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/numeric/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "numeric")
        rows = result["result"]["rows"]
        self.assertEqual([r["key"] for r in rows], ["g1", "g2"])
        self.assertEqual(rows[0]["values"], {"count": 2, "sum": 30, "mean": 15.0})
        self.assertEqual(rows[1]["values"], {"count": 0, "sum": 0, "mean": None})


class TestCategoryBehavior(unittest.TestCase):
    def test_category_unknown_not_added_and_all_null_omitted(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 1, "category": "red", "time": None},
                {"id": "b", "key": "g1", "value": 2, "category": "other", "time": None},
                {"id": "c", "key": "g2", "value": 3, "category": None, "time": None},
            ],
            "vocabulary": ["red", "blue"],
        }
        contract = {"name": "category", "operation": "category_features", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/category/transform.py", "transform", args=[[payload], contract])
        rows = result["result"]["rows"]
        self.assertEqual([r["key"] for r in rows], ["g1"])
        self.assertEqual(rows[0]["values"], {"red": True, "blue": False})


class TestTimeBehavior(unittest.TestCase):
    def test_time_min_max_span(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 1, "category": None, "time": 5},
                {"id": "b", "key": "g1", "value": 2, "category": None, "time": -3},
                {"id": "c", "key": "g2", "value": 3, "category": None, "time": None},
            ],
            "vocabulary": [],
        }
        contract = {"name": "time", "operation": "time_features", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/time/transform.py", "transform", args=[[payload], contract])
        rows = result["result"]["rows"]
        self.assertEqual([r["key"] for r in rows], ["g1"])
        self.assertEqual(rows[0]["values"], {"first": -3, "last": 5, "span": 8})


class TestUnionBehavior(unittest.TestCase):
    def test_union_outer_join_null_fill(self):
        numeric = {"name": "numeric", "result": {"rows": [{"key": "g1", "values": {"count": 1, "sum": 5, "mean": 5.0}}]}}
        category = {"name": "category", "result": {"rows": [{"key": "g2", "values": {"red": True}}]}}
        time = {"name": "time", "result": {"rows": [{"key": "g1", "values": {"first": 1, "last": 2, "span": 1}}]}}
        contract = {"name": "union", "operation": "feature_union", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate("engines/union/transform.py", "transform", args=[[numeric, category, time], contract])
        self.assertEqual(result["result"]["index"], ["g1", "g2"])
        cols = result["result"]["columns"]
        self.assertEqual(cols, ["cat.red", "num.count", "num.mean", "num.sum", "time.first", "time.last", "time.span"])
        data = result["result"]["data"]
        self.assertEqual(data[0], [None, 1, 5.0, 5, 1, 2, 1])
        self.assertEqual(data[1], [True, None, None, None, None, None, None])


def _seed_for(target_path):
    if target_path == "engines/union/transform.py":
        return [
            {"name": "numeric", "result": {"rows": [{"key": "g1", "values": {"count": 1, "sum": 5, "mean": 5.0}}]}},
            {"name": "category", "result": {"rows": [{"key": "g1", "values": {"red": True}}]}},
            {"name": "time", "result": {"rows": [{"key": "g1", "values": {"first": 1, "last": 2, "span": 1}}]}},
        ]
    return {
        "records": [
            {"id": "a", "key": "g1", "value": 10, "category": "red", "time": 5},
        ],
        "vocabulary": ["red"],
    }


class TestApiBoundaries(unittest.TestCase):
    def test_api_boundary_rules(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                with self.subTest(target=req["target_path"], rule=rule):
                    if not spec.get("applicable", False):
                        continue
                    seed = _seed_for(req["target_path"])
                    if req["target_path"] == "engines/union/transform.py":
                        contract = {"name": "x", "operation": "op", "inputs": ["a", "b", "c"], "output": "o"}
                        args = [seed, contract]
                    else:
                        contract = {"name": "x", "operation": "op", "inputs": ["i"], "output": "o"}
                        args = [[seed], contract]
                    check_api_boundary(
                        req["target_path"],
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=args,
                    )


if __name__ == "__main__":
    unittest.main()
