def _check_finite(obj):
    if isinstance(obj, float) and (obj != obj or obj in (float('inf'), float('-inf'))):
        raise ValueError('non-finite number')
    if isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if isinstance(payload, dict) and 'result' in payload and 'name' in payload:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    _check_finite(payload)
    records = payload['records']
    vocabulary = payload['vocabulary']

    seen = set()
    for w in vocabulary:
        if not isinstance(w, str) or not w.strip():
            raise ValueError('vocabulary must be non-empty strings')
        if w in seen:
            raise ValueError('duplicate vocabulary item')
        seen.add(w)

    groups = {}
    for rec in records:
        key = rec['key']
        cat = rec['category']
        if cat is None:
            continue
        if not isinstance(cat, str):
            raise ValueError('category must be str or null')
        groups.setdefault(key, set()).add(cat)

    rows = []
    for key in sorted(groups):
        cats = groups[key]
        values = {w: (w in cats) for w in vocabulary}
        rows.append({'key': key, 'values': values})

    return {'name': contract['name'], 'result': {'rows': rows}}
