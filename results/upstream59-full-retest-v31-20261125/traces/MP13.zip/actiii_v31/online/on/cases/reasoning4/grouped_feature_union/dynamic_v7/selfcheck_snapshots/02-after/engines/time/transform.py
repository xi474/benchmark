def _check_finite(obj):
    if isinstance(obj, float) and (obj != obj or obj in (float("inf"), float("-inf"))):
        raise ValueError("non-finite number")
    if isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    _check_finite(payload)
    records = payload["records"]
    groups = {}
    for rec in records:
        key = rec["key"]
        t = rec["time"]
        if t is None:
            continue
        if isinstance(t, bool) or not isinstance(t, int):
            raise ValueError("time must be int or null")
        groups.setdefault(key, []).append(t)
    rows = []
    for key in sorted(groups):
        times = groups[key]
        first = min(times)
        last = max(times)
        rows.append({"key": key, "values": {"first": first, "last": last, "span": last - first}})
    return {"name": contract["name"], "result": {"rows": rows}}
