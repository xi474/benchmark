def _check_finite(obj):
    if isinstance(obj, float) and (obj != obj or obj in (float("inf"), float("-inf"))):
        raise ValueError("non-finite number")
    if isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    branches = []
    for payload in payloads:
        if isinstance(payload, dict) and set(payload) == {"name", "result"}:
            payload = payload["result"]
        if not isinstance(payload, dict):
            raise ValueError("payload must be object")
        _check_finite(payload)
        branches.append(payload)

    prefixes = ["num.", "cat.", "time."]
    if len(branches) != len(prefixes):
        raise ValueError("expected three feature branches")

    key_to_values = {}
    for prefix, branch in zip(prefixes, branches):
        for row in branch["rows"]:
            key = row["key"]
            values = row["values"]
            entry = key_to_values.setdefault(key, {})
            for col, val in values.items():
                entry[prefix + col] = val

    index = sorted(key_to_values)
    columns = sorted({col for entry in key_to_values.values() for col in entry})
    data = []
    for key in index:
        entry = key_to_values[key]
        data.append([entry.get(col) for col in columns])

    return {"name": contract["name"], "result": {"index": index, "columns": columns, "data": data}}
