def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("business input must be object")
    root = data.get("root")
    nodes = data.get("nodes")
    if not isinstance(root, str) or not isinstance(nodes, list):
        raise ValueError("missing root/nodes")
    by_id = {}
    for n in nodes:
        if not isinstance(n, dict):
            raise ValueError("node must be object")
        nid = n.get("id")
        if not isinstance(nid, str):
            raise ValueError("node id must be string")
        if nid in by_id:
            raise ValueError("duplicate node id")
        by_id[nid] = n
    if root not in by_id:
        raise ValueError("root not found")

    # validate basic fields of every node
    for n in nodes:
        for f in ("id", "type", "message"):
            if not isinstance(n.get(f), str):
                raise ValueError("node field must be string")
        if "cause" not in n or "context" not in n:
            raise ValueError("missing cause/context")
        if n["cause"] is not None and not isinstance(n["cause"], str):
            raise ValueError("cause must be string or null")
        if n["context"] is not None and not isinstance(n["context"], str):
            raise ValueError("context must be string or null")
        if "suppress_context" not in n or not isinstance(n["suppress_context"], bool):
            raise ValueError("suppress_context must be bool")
        if "frames" not in n or not isinstance(n["frames"], list):
            raise ValueError("frames must be list")

    # walk chain from root following cause (or context if not suppressed)
    chain = []
    seen = set()
    cur = root
    while True:
        if cur in seen:
            raise ValueError("cycle detected")
        seen.add(cur)
        if len(seen) > 8:
            raise ValueError("chain too long")
        node = by_id[cur]
        chain.append(node)
        cause = node["cause"]
        if cause is not None:
            cur = cause
        elif not node["suppress_context"] and node["context"] is not None:
            cur = node["context"]
        else:
            break

    # chain is currently root -> ... -> innermost; reverse to innermost -> root
    chain.reverse()
    result_chain = []
    for i, node in enumerate(chain):
        if i == 0:
            link = None
        else:
            prev = chain[i - 1]
            if node["cause"] == prev["id"]:
                link = "cause"
            elif node["context"] == prev["id"]:
                link = "context"
            else:
                link = None
        result_chain.append({
            "id": node["id"],
            "type": node["type"],
            "message": node["message"],
            "link": link,
        })
    return {"name": contract["name"], "result": {"chain": result_chain}}
