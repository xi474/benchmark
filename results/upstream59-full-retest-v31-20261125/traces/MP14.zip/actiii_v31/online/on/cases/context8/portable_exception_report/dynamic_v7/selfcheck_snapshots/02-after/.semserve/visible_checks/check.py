import json
import unittest

from visible_contract_check_sdk import (
    CandidateCallError,
    call_candidate,
    check_api_boundary,
)

README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "chain/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "frames/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "report/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestChain(unittest.TestCase):
    def test_chain_output_shape_and_order(self):
        payload = {
            "root": "outer",
            "nodes": [
                {"id": "inner", "type": "KeyError", "message": "k",
                 "cause": None, "context": None, "suppress_context": False,
                 "frames": []},
                {"id": "outer", "type": "RuntimeError", "message": "f",
                 "cause": "inner", "context": None, "suppress_context": False,
                 "frames": []},
            ],
        }
        contract = {"name": "chain", "operation": "exception_chain",
                    "inputs": ["inputs/case.json"], "output": "outputs/chain.json"}
        result = call_candidate("chain/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "chain")
        chain = result["result"]["chain"]
        self.assertEqual([c["id"] for c in chain], ["inner", "outer"])
        self.assertEqual(chain[0]["link"], None)
        self.assertEqual(chain[1]["link"], "cause")

    def test_chain_cycle_raises(self):
        payload = {
            "root": "a",
            "nodes": [
                {"id": "a", "type": "T", "message": "m", "cause": "b",
                 "context": None, "suppress_context": False, "frames": []},
                {"id": "b", "type": "T", "message": "m", "cause": "a",
                 "context": None, "suppress_context": False, "frames": []},
            ],
        }
        contract = {"name": "chain", "operation": "exception_chain",
                    "inputs": ["inputs/case.json"], "output": "outputs/chain.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("chain/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"],
                         "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestFrames(unittest.TestCase):
    def test_frames_basename_and_locals_serialization(self):
        payload = {
            "root": "n",
            "nodes": [
                {"id": "n", "type": "T", "message": "m", "cause": None,
                 "context": None, "suppress_context": False,
                 "frames": [{"file": "C:\\dir\\mod.py", "line": 3,
                             "function": "f", "locals": {"k": "x"}}]},
            ],
        }
        contract = {"name": "frames", "operation": "portable_frames",
                    "inputs": ["inputs/case.json"], "output": "outputs/frames.json"}
        result = call_candidate("frames/transform.py", "transform",
                                args=[[payload], contract])
        fr = result["result"]["frames"]["n"][0]
        self.assertEqual(fr["file"], "mod.py")
        self.assertEqual(fr["locals"]["k"], '"x"')

    def test_frames_line_zero_raises(self):
        payload = {
            "root": "n",
            "nodes": [
                {"id": "n", "type": "T", "message": "m", "cause": None,
                 "context": None, "suppress_context": False,
                 "frames": [{"file": "a.py", "line": 0, "function": "f",
                             "locals": {}}]},
            ],
        }
        contract = {"name": "frames", "operation": "portable_frames",
                    "inputs": ["inputs/case.json"], "output": "outputs/frames.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("frames/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"],
                         "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestReport(unittest.TestCase):
    def test_report_text_separators(self):
        chain = {"chain": [
            {"id": "inner", "type": "KeyError", "message": "k", "link": None},
            {"id": "outer", "type": "RuntimeError", "message": "f",
             "link": "cause"},
        ]}
        frames = {"frames": {
            "inner": [{"file": "a.py", "line": 1, "function": "f",
                       "locals": {}}],
            "outer": [{"file": "b.py", "line": 2, "function": "g",
                       "locals": {}}],
        }}
        contract = {"name": "report", "operation": "exception_report",
                    "inputs": ["outputs/chain.json", "outputs/frames.json"],
                    "output": "outputs/report.json"}
        result = call_candidate("report/transform.py", "transform",
                                args=[[chain, frames], contract])
        text = result["result"]["text"]
        self.assertIn("--- direct cause ---", text)
        self.assertTrue(text.endswith("\n"))
        self.assertEqual(len(result["result"]["nodes"]), 2)


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_rules(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                with self.subTest(target=req["target_path"], rule=rule):
                    if not spec["applicable"]:
                        continue
                    if req["target_path"] == "report/transform.py":
                        seed = [
                            {"chain": [{"id": "r", "type": "T",
                                        "message": "m", "link": None}]},
                            {"frames": {"r": []}},
                        ]
                        contract = {"name": "x", "operation": "op",
                                    "inputs": ["i", "j"], "output": "o"}
                    else:
                        seed = [{"root": "r", "nodes": [
                            {"id": "r", "type": "T", "message": "m",
                             "cause": None, "context": None,
                             "suppress_context": False, "frames": []}]}]
                        contract = {"name": "x", "operation": "op",
                                    "inputs": ["i"], "output": "o"}
                    check_api_boundary(
                        req["target_path"],
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=[seed, contract],
                    )


if __name__ == "__main__":
    unittest.main()
