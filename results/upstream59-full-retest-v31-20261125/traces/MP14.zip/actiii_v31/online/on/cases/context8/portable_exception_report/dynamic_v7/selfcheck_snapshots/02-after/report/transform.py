def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if obj != obj or obj in (float("inf"), float("-inf")):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _reject_nonfinite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _reject_nonfinite(value)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    for p in payloads:
        _reject_nonfinite(p)
    if not isinstance(payloads[0], dict):
        raise ValueError("payload must be an object")
    if not isinstance(payloads[1], dict):
        raise ValueError("payload must be an object")
    chain = _unwrap(payloads[0])
    frames = _unwrap(payloads[1])

    chain_items = chain["chain"]
    frames_map = frames["frames"]

    nodes = []
    lines = []
    for i, item in enumerate(chain_items):
        node_id = item["id"]
        node_frames = frames_map.get(node_id, [])
        nodes.append({
            "id": node_id,
            "type": item["type"],
            "message": item["message"],
            "link": item["link"],
            "frames": node_frames,
        })
        if i > 0:
            if item["link"] == "cause":
                lines.append("--- direct cause ---")
            else:
                lines.append("--- during handling ---")
        for f in node_frames:
            lines.append("  %s:%s in %s" % (f["file"], f["line"], f["function"]))
        lines.append("%s: %s" % (item["type"], item["message"]))

    text = "\n".join(lines)
    if lines:
        text += "\n"

    return {"name": contract["name"], "result": {"nodes": nodes, "text": text}}


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj) == {"name", "result"}:
        return obj["result"]
    return obj
