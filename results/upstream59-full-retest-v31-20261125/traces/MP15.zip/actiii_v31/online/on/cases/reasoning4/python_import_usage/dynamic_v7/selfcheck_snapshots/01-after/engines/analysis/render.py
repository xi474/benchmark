def build_component(root, contract_path):
    import json
    from pathlib import Path

    from model import load_payload
    from transform import transform

    root = Path(root)
    cp = Path(contract_path)
    contract = load_payload(cp)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return result


if __name__ == "__main__":
    import sys
    from pathlib import Path

    root = Path.cwd()
    cp = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("contract.json")
    build_component(root, cp)
