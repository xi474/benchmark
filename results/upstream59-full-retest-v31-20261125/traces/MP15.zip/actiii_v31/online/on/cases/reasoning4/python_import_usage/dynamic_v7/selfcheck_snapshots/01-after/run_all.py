import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        if name in contracts:
            raise ValueError("duplicate component name")
        contracts[name] = {"path": cp, "contract": c}
    return contracts


def _topological_order(contracts):
    output_to_name = {}
    for name, info in contracts.items():
        output_to_name[info["contract"]["output"]] = name

    deps = {}
    for name, info in contracts.items():
        d = set()
        for inp in info["contract"]["inputs"]:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[name] = d

    result = []
    visited = set()
    temp = set()

    def visit(n):
        if n in temp:
            raise ValueError("cycle detected")
        if n in visited:
            return
        temp.add(n)
        for m in sorted(deps[n]):
            visit(m)
        temp.remove(n)
        visited.add(n)
        result.append(n)

    for name in sorted(contracts):
        visit(name)

    return result


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError("no contracts")

    order = _topological_order(contracts)

    for name in order:
        info = contracts[name]
        cp = info["path"]
        comp_dir = cp.parent
        render_py = comp_dir / "render.py"
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {name}")
        proc = subprocess.run(
            [sys.executable, str(render_py), str(cp)],
            cwd=ROOT,
            check=False,
            timeout=60,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"component {name} failed")

    integrate_py = ROOT / "integrate.py"
    proc = subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        check=False,
        timeout=60,
    )
    if proc.returncode != 0:
        raise RuntimeError("integrate failed")

    final_py = ROOT / "final_report.py"
    proc = subprocess.run(
        [sys.executable, str(final_py)],
        cwd=ROOT,
        check=False,
        timeout=60,
    )
    if proc.returncode != 0:
        raise RuntimeError("final_report failed")


if __name__ == "__main__":
    main()
