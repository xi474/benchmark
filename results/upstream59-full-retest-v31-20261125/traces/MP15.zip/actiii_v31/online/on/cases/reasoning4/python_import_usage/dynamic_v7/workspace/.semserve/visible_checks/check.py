import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/ordinary/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/annotations/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/comments/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/analysis/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target,
                            rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"source": "import os\n"}], {"name": "x", "operation": "op", "inputs": ["inputs/case.json"], "output": "outputs/x.json"}],
                        )
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target,
                            rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"source": "import os\n"}], {"name": "x", "operation": "op", "inputs": ["inputs/case.json"], "output": "outputs/x.json"}],
                        )


class TestOrdinaryUses(unittest.TestCase):
    def test_ordinary_load_names(self):
        # 普通表达式Load名字，排除注解/类型注释/字符串内容
        src = "import os\nx = os.path.join('a', 'b')\n"
        payload = {"source": src}
        contract = {"name": "ordinary", "operation": "ordinary_uses", "inputs": ["inputs/case.json"], "output": "outputs/ordinary.json"}
        result = call_candidate("engines/ordinary/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "ordinary")
        self.assertEqual(result["result"]["uses"], [{"scope": "module", "line": 2, "name": "os"}])


class TestAnnotationsUses(unittest.TestCase):
    def test_annotation_forward_string(self):
        # 最外层字符串前向注解作为表达式再解析
        src = "from typing import List\nvalue: 'List[int]' = []\n"
        payload = {"source": src}
        contract = {"name": "annotations", "operation": "annotation_uses", "inputs": ["inputs/case.json"], "output": "outputs/annotations.json"}
        result = call_candidate("engines/annotations/transform.py", "transform", args=[[payload], contract])
        names = sorted(u["name"] for u in result["result"]["uses"])
        self.assertEqual(names, ["List", "int"])


class TestCommentsUses(unittest.TestCase):
    def test_type_comment_uses(self):
        # 仅赋值Assign上的 # type: 表达式
        src = "import abc\nX = None  # type: abc.ABC\n"
        payload = {"source": src}
        contract = {"name": "comments", "operation": "type_comment_uses", "inputs": ["inputs/case.json"], "output": "outputs/comments.json"}
        result = call_candidate("engines/comments/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["uses"], [{"scope": "module", "line": 2, "name": "abc"}])


class TestAnalysisJoin(unittest.TestCase):
    def test_analysis_unused(self):
        # 合并三类uses，报告未使用导入
        src = "import os\nimport json as j\nvalue = j.dumps({})\n"
        ordinary = {"uses": [{"scope": "module", "line": 3, "name": "j"}]}
        annotations = {"uses": []}
        comments = {"uses": []}
        payloads = [{"source": src}, ordinary, annotations, comments]
        contract = {"name": "analysis", "operation": "import_usage_join", "inputs": ["inputs/case.json", "outputs/ordinary.json", "outputs/annotations.json", "outputs/comments.json"], "output": "outputs/analysis.json"}
        result = call_candidate("engines/analysis/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(result["result"]["unused"], ["module:os"])


if __name__ == "__main__":
    unittest.main()
