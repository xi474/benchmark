import ast
import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    _check_finite(payloads)
    _check_finite(contract)
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    if not isinstance(contract, dict) or "inputs" not in contract:
        raise ValueError("bad contract")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    if len(payloads) < 4:
        raise ValueError("payload count mismatch")
    if len(payloads) > 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != len(payloads):
        raise ValueError("payload count mismatch")
    if len(payloads) != 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != len(payloads) or len(payloads) != 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads):
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4 or len(payloads) < 4 or len(payloads) > 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4 or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4 or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4:
        raise ValueError("payload count mismatch")
    if len(contract["inputs"]) != 4 or len(payloads) != 4 or len(contract["inputs"]) != len(payloads) or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4 or len(payloads) < 4 or len(payloads) > 4 or len(contract["inputs"]) < 4 or len(contract["inputs"]) > 4 or len(contract["inputs"]) != len(payloads) or len(payloads) != 4 or len(payloads) < 4 or len(payloads) > 4:
        raise ValueError("payload count mismatch")

    source_payload = _unwrap(payloads[0])
    if not isinstance(source_payload, dict) or "source" not in source_payload:
        raise ValueError("missing source")
    source = source_payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")

    ordinary = _unwrap(payloads[1])
    annotations = _unwrap(payloads[2])
    comments = _unwrap(payloads[3])

    for p in (ordinary, annotations, comments):
        if not isinstance(p, dict) or "uses" not in p:
            raise ValueError("missing uses")

    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError("bad source") from e

    # reject global/nonlocal
    for node in ast.walk(tree):
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            raise ValueError("global/nonlocal not supported")

    # collect imports with correct scope
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            scope = _scope_of(tree, node)
            for alias in node.names:
                name = alias.asname if alias.asname else alias.name.split(".")[0]
                imports.append({
                    "scope": scope,
                    "name": name,
                    "module": alias.name,
                    "line": node.lineno,
                })
        elif isinstance(node, ast.ImportFrom):
            if node.level != 0:
                raise ValueError("relative import not supported")
            if any(a.name == "*" for a in node.names):
                raise ValueError("star import not supported")
            scope = _scope_of(tree, node)
            for alias in node.names:
                name = alias.asname if alias.asname else alias.name
                imports.append({
                    "scope": scope,
                    "name": name,
                    "module": node.module,
                    "line": node.lineno,
                })

    # duplicate check: each (scope, bound name) only once
    seen = set()
    for imp in imports:
        key = (imp["scope"], imp["name"])
        if key in seen:
            raise ValueError("duplicate import binding")
        seen.add(key)

    # collect shadowing stores per scope
    # function params and assignment Store names shadow module imports
    shadow = {}  # scope -> set of names
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            scope = node.name
            shadow.setdefault(scope, set())
            for arg in node.args.args + node.args.kwonlyargs:
                shadow[scope].add(arg.arg)
            if node.args.vararg:
                shadow[scope].add(node.args.vararg.arg)
            if node.args.kwarg:
                shadow[scope].add(node.args.kwarg.arg)
            for sub in ast.walk(node):
                if isinstance(sub, ast.Assign):
                    for t in sub.targets:
                        for n in ast.walk(t):
                            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                                shadow[scope].add(n.id)
                elif isinstance(sub, ast.AnnAssign):
                    t = sub.target
                    if isinstance(t, ast.Name):
                        shadow[scope].add(t.id)

    # build usage lookup: (scope, name) -> set of kinds
    usage = {}  # (scope, name) -> set
    for kind, payload in (("ordinary", ordinary), ("annotation", annotations), ("comment", comments)):
        for u in payload["uses"]:
            key = (u["scope"], u["name"])
            usage.setdefault(key, set()).add(kind)

    # resolve each import's used_by
    result_imports = []
    for imp in imports:
        scope = imp["scope"]
        name = imp["name"]
        used_by = []
        # function-local import: only function scope matches
        if scope != "module":
            key = (scope, name)
            kinds = usage.get(key, set())
            for k in ("ordinary", "annotation", "comment"):
                if k in kinds:
                    used_by.append(k)
        else:
            # module import: check module scope first, then fallback to functions
            # where name is not shadowed
            key = ("module", name)
            kinds = set(usage.get(key, set()))
            # fallback: functions without local import and without shadowing
            for fn_scope in _function_scopes(tree):
                if (fn_scope, name) in seen:
                    continue  # has local import
                if name in shadow.get(fn_scope, set()):
                    continue  # shadowed
                kinds |= usage.get((fn_scope, name), set())
            for k in ("ordinary", "annotation", "comment"):
                if k in kinds:
                    used_by.append(k)
        result_imports.append({
            "scope": scope,
            "name": name,
            "module": imp["module"],
            "line": imp["line"],
            "used_by": used_by,
        })

    result_imports.sort(key=lambda x: (x["scope"], x["line"], x["name"]))

    # unused: imports with empty used_by
    unused = []
    for imp in result_imports:
        if not imp["used_by"]:
            unused.append(f"{imp['scope']}:{imp['name']}")
    unused.sort()

    return {
        "name": contract["name"],
        "result": {
            "imports": result_imports,
            "unused": unused,
        },
    }


def _scope_of(tree, node):
    """Determine the scope of an import node: 'module' or enclosing function name."""
    for parent in ast.walk(tree):
        if isinstance(parent, ast.FunctionDef):
            for sub in ast.walk(parent):
                if sub is node:
                    return parent.name
    return "module"


def _function_scopes(tree):
    return [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
