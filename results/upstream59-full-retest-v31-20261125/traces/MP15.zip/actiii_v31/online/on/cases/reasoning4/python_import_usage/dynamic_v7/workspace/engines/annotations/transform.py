import ast
import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _load_names(node):
    """Collect Load-context names from an expression node."""
    names = []
    for n in ast.walk(node):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            names.append(n.id)
    return names


def _parse_annotation_expr(expr_node):
    """Resolve a string forward annotation into an expression AST.

    Returns the expression node (or None if not a string). Raises ValueError
    for a bad expression.
    """
    if isinstance(expr_node, ast.Constant) and isinstance(expr_node.value, str):
        try:
            parsed = ast.parse(expr_node.value, mode="eval")
        except SyntaxError as e:
            raise ValueError("bad forward annotation expression") from e
        return parsed.body
    return expr_node


def _collect_annotation(node, scope, line, uses):
    if node is None:
        return
    expr = _parse_annotation_expr(node)
    for name in _load_names(expr):
        uses.append({"scope": scope, "name": name, "line": line})


def transform(payloads, contract):
    _check_finite(payloads)
    _check_finite(contract)
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source")
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")

    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError("bad source") from e

    uses = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            # function signature annotations belong to module scope
            for arg in node.args.args + node.args.kwonlyargs:
                _collect_annotation(arg.annotation, "module", node.lineno, uses)
            if node.args.vararg is not None:
                _collect_annotation(node.args.vararg.annotation, "module", node.lineno, uses)
            if node.args.kwarg is not None:
                _collect_annotation(node.args.kwarg.annotation, "module", node.lineno, uses)
            _collect_annotation(node.returns, "module", node.lineno, uses)
            # function body AnnAssign annotations belong to the function scope
            for sub in ast.walk(node):
                if isinstance(sub, ast.AnnAssign):
                    _collect_annotation(sub.annotation, node.name, sub.lineno, uses)
        elif isinstance(node, ast.AnnAssign):
            _collect_annotation(node.annotation, "module", node.lineno, uses)

    # dedupe and sort by (scope, line, name)
    seen = set()
    result = []
    for u in sorted(uses, key=lambda x: (x["scope"], x["line"], x["name"])):
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            result.append(u)

    return {"name": contract["name"], "result": {"uses": result}}
