import ast
import math
import re


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _extract_load_names(expr_text):
    """Parse a type expression and return Load names in source order."""
    try:
        tree = ast.parse(expr_text, mode="eval")
    except SyntaxError as e:
        raise ValueError("bad type expression") from e
    names = []
    for node in ast.walk(tree.body):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            names.append(node.id)
    return names


def transform(payloads, contract):
    _check_finite(payloads)
    _check_finite(contract)
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source")
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")

    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError("bad source") from e

    uses = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.For, ast.AsyncFor, ast.With, ast.AsyncWith)):
            if getattr(node, "type_comment", None):
                raise ValueError("function signature/for/with type comment not supported")
        if isinstance(node, ast.Assign):
            # find the type comment on this assignment's line
            line = node.lineno
            src_line = source.splitlines()[line - 1]
            m = re.search(r"#\s*type\s*:\s*(.*)$", src_line)
            if not m:
                continue
            expr_text = m.group(1).strip()
            if expr_text.startswith("ignore"):
                continue
            for name in _extract_load_names(expr_text):
                uses.append({"scope": "module", "name": name, "line": line})

    # dedupe and sort by (scope, line, name)
    seen = set()
    result = []
    for u in sorted(uses, key=lambda x: (x["scope"], x["line"], x["name"])):
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            result.append(u)

    return {"name": contract["name"], "result": {"uses": result}}
