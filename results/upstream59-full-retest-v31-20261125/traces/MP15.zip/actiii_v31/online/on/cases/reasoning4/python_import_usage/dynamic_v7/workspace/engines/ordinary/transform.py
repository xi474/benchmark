import ast
import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _collect(node, scope, uses):
    if isinstance(node, ast.Name):
        if isinstance(node.ctx, ast.Load):
            uses.append((scope, node.lineno, node.id))
        return
    if isinstance(node, ast.AnnAssign):
        _collect(node.target, scope, uses)
        _collect(node.value, scope, uses)
        return
    if isinstance(node, ast.arg):
        return
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
        return
    for child in ast.iter_child_nodes(node):
        _collect(child, scope, uses)


def _ordinary_uses(source):
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError("invalid source") from e

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            raise ValueError("class not supported")
        if isinstance(node, ast.AsyncFunctionDef):
            raise ValueError("async function not supported")
        if isinstance(node, ast.Lambda):
            raise ValueError("lambda not supported")

    top_funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
    all_funcs = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    if len(top_funcs) != len(all_funcs):
        raise ValueError("nested or conditional function not supported")

    seen = set()
    for fn in top_funcs:
        if fn.name in seen:
            raise ValueError("duplicate function name")
        seen.add(fn.name)

    uses = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            for d in node.decorator_list:
                _collect(d, "module", uses)
            for d in node.args.defaults:
                _collect(d, "module", uses)
            for d in node.args.kw_defaults:
                if d is not None:
                    _collect(d, "module", uses)
            for stmt in node.body:
                _collect(stmt, node.name, uses)
        else:
            _collect(node, "module", uses)

    uses = sorted(set(uses), key=lambda t: (t[0], t[1], t[2]))
    return [{"scope": s, "line": l, "name": n} for (s, l, n) in uses]


def transform(payloads, contract):
    _check_finite(payloads)
    _check_finite(contract)
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source")
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    uses = _ordinary_uses(source)
    return {"name": contract["name"], "result": {"uses": uses}}
