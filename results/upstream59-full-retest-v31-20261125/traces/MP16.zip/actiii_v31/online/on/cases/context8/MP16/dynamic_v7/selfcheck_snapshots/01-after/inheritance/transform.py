def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    objects = payload["objects"]
    target = payload["target"]

    by_id = {o["id"]: o for o in objects}

    order = [target] + list(by_id[target]["mro"])
    provider = None
    for oid in order:
        obj = by_id[oid]
        doc = obj.get("doc", "")
        if isinstance(doc, str) and doc.strip():
            provider = obj
            break

    if provider is None:
        result = {"provider": None, "namespace": None, "aliases": {}}
    else:
        result = {
            "provider": provider["id"],
            "namespace": provider.get("namespace"),
            "aliases": provider.get("aliases", {}),
        }

    return {"name": contract["name"], "result": result}
