import re


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def _balanced(s):
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for ch in s:
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}":
            if not stack or stack[-1] != pairs[ch]:
                return False
            stack.pop()
    return not stack


def _parse_param_line(rest):
    idx = rest.find(":")
    if idx < 0:
        raise ValueError("bad param directive")
    left = rest[:idx]
    desc = rest[idx + 1:].strip()
    tokens = left.split()
    if not tokens:
        raise ValueError("bad param directive")
    name = tokens[-1]
    if not name.isidentifier():
        raise ValueError("bad param name")
    type_text = left[: left.rfind(name)].strip()
    if type_text and not _balanced(type_text):
        raise ValueError("unbalanced brackets")
    return name, (type_text or None), desc


def _parse_type_line(rest):
    idx = rest.find(":")
    if idx < 0:
        raise ValueError("bad type directive")
    name = rest[:idx].strip()
    if not name.isidentifier():
        raise ValueError("bad type name")
    type_text = rest[idx + 1:].strip()
    if not type_text:
        raise ValueError("bad type directive")
    if not _balanced(type_text):
        raise ValueError("unbalanced brackets")
    return name, type_text


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict) or "objects" not in data:
        raise ValueError("missing objects")
    objects = data["objects"]
    if not isinstance(objects, list):
        raise ValueError("objects must be list")

    docs = {}
    for obj in objects:
        if not isinstance(obj, dict):
            raise ValueError("object must be dict")
        oid = obj.get("id")
        doc = obj.get("doc")
        if not isinstance(oid, str) or not isinstance(doc, str):
            raise ValueError("object id/doc required")
        entries = {}
        param_seen = set()
        type_seen = set()
        for raw in doc.splitlines():
            line = raw.strip()
            if line.startswith(":param "):
                name, type_text, desc = _parse_param_line(line[len(":param "):])
                if name in param_seen:
                    raise ValueError("duplicate param")
                param_seen.add(name)
                entries[name] = {"name": name, "type": type_text, "description": desc}
            elif line.startswith(":type "):
                name, type_text = _parse_type_line(line[len(":type "):])
                if name in type_seen:
                    raise ValueError("duplicate type")
                type_seen.add(name)
                if name not in entries:
                    entries[name] = {"name": name, "type": None, "description": ""}
                entries[name]["type"] = type_text
        docs[oid] = [entries[k] for k in sorted(entries)]

    return {"name": contract["name"], "result": {"docs": docs}}
