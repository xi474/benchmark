import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _contracts():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    return contracts


def _topo_order(contracts):
    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        by_name[c["name"]] = (cp, c)

    output_owner = {}
    for name, (cp, c) in by_name.items():
        output_owner[str(ROOT / c["output"])] = name

    deps = {}
    for name, (cp, c) in by_name.items():
        d = set()
        for inp in c["inputs"]:
            p = str(ROOT / inp)
            if p in output_owner:
                d.add(output_owner[p])
        deps[name] = d

    order = []
    remaining = set(by_name)
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError("dependency cycle detected")
        ready.sort()
        for n in ready:
            order.append(n)
            remaining.discard(n)
    return [by_name[n] for n in order]


def main():
    contracts = _contracts()
    if not contracts:
        raise ValueError("no contracts")
    ordered = _topo_order(contracts)
    for cp, c in ordered:
        subprocess.run(
            [sys.executable, str(cp.with_name("render.py"))],
            cwd=ROOT,
            check=True,
            timeout=180,
        )
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=180,
    )
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=180,
    )


if __name__ == "__main__":
    main()
