import ast


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _parse_signature(sig):
    # Wrap as a function definition to reuse ast parsing.
    src = "def " + sig + ":\n    pass\n"
    tree = ast.parse(src)
    fn = tree.body[0]
    args = fn.args

    parameters = []

    def add(name, kind, annotation, default):
        parameters.append({
            "name": name,
            "kind": kind,
            "annotation": ast.unparse(annotation) if annotation is not None else None,
            "default": ast.unparse(default) if default is not None else None,
        })

    # posonly
    for a in args.posonlyargs:
        add(a.arg, "posonly", a.annotation, None)
    # positional (args)
    for a in args.args:
        add(a.arg, "positional", a.annotation, None)
    # vararg
    if args.vararg is not None:
        add(args.vararg.arg, "vararg", args.vararg.annotation, None)
    # kwonly
    for a in args.kwonlyargs:
        add(a.arg, "kwonly", a.annotation, None)
    # kwarg
    if args.kwarg is not None:
        add(args.kwarg.arg, "kwarg", args.kwarg.annotation, None)

    # defaults: positional defaults map to last len(defaults) positional args
    defaults = list(args.defaults)
    if defaults:
        pos = [a for a in args.args]
        for i, d in enumerate(defaults):
            idx = len(pos) - len(defaults) + i
            parameters[idx]["default"] = ast.unparse(d)

    # kwonly defaults
    kw_defaults = list(args.kw_defaults)
    kwonly = list(args.kwonlyargs)
    for i, d in enumerate(kw_defaults):
        if d is not None:
            parameters[len(args.posonlyargs) + len(args.args) + (1 if args.vararg else 0) + i]["default"] = ast.unparse(d)

    returns = ast.unparse(fn.returns) if fn.returns is not None else None

    return {
        "name": fn.name,
        "parameters": parameters,
        "returns": returns,
    }


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    overloads = data["overloads"]
    result = {"overloads": [_parse_signature(s) for s in overloads]}
    return {"name": contract["name"], "result": result}
