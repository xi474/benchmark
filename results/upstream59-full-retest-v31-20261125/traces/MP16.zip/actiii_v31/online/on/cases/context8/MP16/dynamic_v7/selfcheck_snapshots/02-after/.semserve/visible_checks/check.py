import unittest

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

# Visible documents used for requirement citations.
README = (ROOT / "README.md").read_text(encoding="utf-8")

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "signatures/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "parameters/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "inheritance/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "document/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestAPIBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target, rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"overloads": [],
                                    "objects": [{"id": "x", "doc": "", "mro": [],
                                                 "namespace": "n", "aliases": {}}],
                                    "target": "x"},
                                   {"overloads": [],
                                    "objects": [{"id": "x", "doc": "", "mro": [],
                                                 "namespace": "n", "aliases": {}}],
                                    "target": "x"},
                                   {"overloads": [],
                                    "objects": [{"id": "x", "doc": "", "mro": [],
                                                 "namespace": "n", "aliases": {}}],
                                    "target": "x"}],
                                  {"name": "x", "operation": "o",
                                   "inputs": ["a", "b", "c"], "output": "out"}],
                        )
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target, rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"overloads": [],
                                    "objects": [{"id": "x", "doc": "", "mro": [],
                                                 "namespace": "n", "aliases": {}}],
                                    "target": "x"},
                                   {"overloads": [],
                                    "objects": [{"id": "x", "doc": "", "mro": [],
                                                 "namespace": "n", "aliases": {}}],
                                    "target": "x"},
                                   {"overloads": [],
                                    "objects": [{"id": "x", "doc": "", "mro": [],
                                                 "namespace": "n", "aliases": {}}],
                                    "target": "x"}],
                                  {"name": "x", "operation": "o",
                                   "inputs": ["a", "b", "c"], "output": "out"}],
                        )


class TestDocumentBehavior(unittest.TestCase):
    def test_document_alias_substitution_and_merge(self):
        # Provider Base has alias Item -> base.Item; parameter y type "Item"
        # must become "base.Item", while x type "dict(str, str)" is unchanged.
        signatures = {
            "name": "signatures",
            "result": {
                "overloads": [
                    {
                        "name": "f",
                        "parameters": [
                            {"name": "x", "kind": "posonly", "annotation": "int", "default": None}
                        ],
                        "returns": "str",
                    }
                ]
            },
        }
        parameters = {
            "name": "parameters",
            "result": {
                "docs": {
                    "Base": [
                        {"name": "x", "type": "dict(str, str)", "description": "mapping"},
                        {"name": "y", "type": "Item", "description": "optional"},
                    ]
                }
            },
        }
        inherited = {
            "name": "inheritance",
            "result": {
                "provider": "Base",
                "namespace": "base",
                "aliases": {"Item": "base.Item"},
            },
        }
        contract = {
            "name": "document",
            "operation": "api_documentation",
            "inputs": ["a", "b", "c"],
            "output": "out",
        }
        result = call_candidate(
            "document/transform.py", "transform",
            args=[[signatures, parameters, inherited], contract],
        )
        self.assertEqual(result["name"], "document")
        r = result["result"]
        self.assertEqual(r["provider"], "Base")
        self.assertEqual(r["namespace"], "base")
        self.assertEqual(r["overloads"], signatures["result"]["overloads"])
        self.assertEqual(
            r["parameters"],
            [
                {"name": "x", "type": "dict(str, str)", "description": "mapping"},
                {"name": "y", "type": "base.Item", "description": "optional"},
            ],
        )

    def test_document_no_provider_empty_parameters(self):
        signatures = {"name": "s", "result": {"overloads": []}}
        parameters = {"name": "p", "result": {"docs": {}}}
        inherited = {"name": "i", "result": {"provider": None, "namespace": None, "aliases": {}}}
        contract = {"name": "document", "operation": "api_documentation",
                    "inputs": ["a", "b", "c"], "output": "out"}
        result = call_candidate(
            "document/transform.py", "transform",
            args=[[signatures, parameters, inherited], contract],
        )
        r = result["result"]
        self.assertIsNone(r["provider"])
        self.assertIsNone(r["namespace"])
        self.assertEqual(r["parameters"], [])


class TestInheritanceBehavior(unittest.TestCase):
    def test_inheritance_uses_first_nonempty_doc(self):
        payload = {
            "objects": [
                {"id": "Base", "doc": "  \n", "mro": [], "namespace": "base", "aliases": {}},
                {"id": "Mid", "doc": ":param x: hi", "mro": ["Base"], "namespace": "mid",
                 "aliases": {"A": "mid.A"}},
                {"id": "Child", "doc": "", "mro": ["Mid"], "namespace": "child", "aliases": {}},
            ],
            "target": "Child",
        }
        contract = {"name": "inheritance", "operation": "inherited_doc",
                    "inputs": ["a"], "output": "out"}
        result = call_candidate("inheritance/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["provider"], "Mid")
        self.assertEqual(r["namespace"], "mid")
        self.assertEqual(r["aliases"], {"A": "mid.A"})


class TestSignaturesBehavior(unittest.TestCase):
    def test_signature_default_none_vs_no_default(self):
        payload = {"overloads": ["f(x: int, y = None) -> str"]}
        contract = {"name": "signatures", "operation": "overload_signatures",
                    "inputs": ["a"], "output": "out"}
        result = call_candidate("signatures/transform.py", "transform",
                                args=[[payload], contract])
        params = result["result"]["overloads"][0]["parameters"]
        self.assertEqual(params[0]["default"], None)
        self.assertEqual(params[1]["default"], "None")


if __name__ == "__main__":
    unittest.main()
