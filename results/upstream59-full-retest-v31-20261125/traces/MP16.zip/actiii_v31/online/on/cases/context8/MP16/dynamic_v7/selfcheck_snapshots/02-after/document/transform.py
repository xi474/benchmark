import re
import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    for p in payloads:
        _check_finite(p)
    overloads_data = _unwrap(payloads[0])
    if not isinstance(overloads_data, dict):
        raise ValueError("payload must be object")
    params_data = _unwrap(payloads[1])
    if not isinstance(params_data, dict):
        raise ValueError("payload must be object")
    inherited_data = _unwrap(payloads[2])
    if not isinstance(inherited_data, dict):
        raise ValueError("payload must be object")

    overloads = overloads_data["overloads"]
    provider = inherited_data.get("provider")
    namespace = inherited_data.get("namespace")
    aliases = inherited_data.get("aliases", {})

    parameters = []
    if provider is not None:
        docs = params_data["docs"]
        entries = docs.get(provider, [])
        for entry in entries:
            name = entry["name"]
            typ = entry.get("type")
            description = entry.get("description", "")
            if typ is not None:
                typ = _substitute(typ, aliases)
            parameters.append({
                "name": name,
                "type": typ,
                "description": description,
            })

    return {
        "name": contract["name"],
        "result": {
            "overloads": overloads,
            "provider": provider,
            "namespace": namespace,
            "parameters": parameters,
        },
    }


def _substitute(typ, aliases):
    # Replace standalone identifiers not immediately adjacent to a dot.
    def repl(m):
        ident = m.group(0)
        return aliases.get(ident, ident)

    return re.sub(r"(?<!\.)\b[A-Za-z_][A-Za-z0-9_]*\b(?!\.)", repl, typ)
