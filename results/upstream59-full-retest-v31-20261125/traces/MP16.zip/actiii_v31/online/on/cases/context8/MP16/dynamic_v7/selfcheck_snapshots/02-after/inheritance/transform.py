import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    for p in payloads:
        _check_finite(p)
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    objects = payload["objects"]
    target = payload["target"]

    by_id = {o["id"]: o for o in objects}

    order = [target] + list(by_id[target]["mro"])
    provider = None
    for oid in order:
        obj = by_id[oid]
        doc = obj.get("doc", "")
        if isinstance(doc, str) and doc.strip():
            provider = obj
            break

    if provider is None:
        result = {"provider": None, "namespace": None, "aliases": {}}
    else:
        result = {
            "provider": provider["id"],
            "namespace": provider.get("namespace"),
            "aliases": provider.get("aliases", {}),
        }

    return {"name": contract["name"], "result": result}
