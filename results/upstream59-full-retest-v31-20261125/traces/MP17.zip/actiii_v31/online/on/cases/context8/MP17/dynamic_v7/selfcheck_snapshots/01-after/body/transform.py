import re


def _unwrap(p):
    if isinstance(p, dict) and set(p) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    encoded = _unwrap(payloads[1])

    boundary = snapshot["boundary"]
    if not isinstance(boundary, str) or not re.fullmatch(r"[A-Za-z0-9-]+", boundary):
        raise ValueError("invalid boundary")

    parts = encoded["parts"]
    boundary_bytes = boundary.encode("utf-8")

    body = bytearray()
    for part in parts:
        payload_bytes = bytes.fromhex(part["payload_hex"])
        if boundary_bytes in payload_bytes:
            raise ValueError("boundary appears in payload")

        body += b"--" + boundary_bytes + b"\r\n"
        if part["encoding"] == "base64":
            body += b"Content-Transfer-Encoding: base64\r\n"
        body += b"Content-Type: " + part["mimetype"].encode("utf-8") + b"\r\n"
        disp = 'form-data; name="' + part["name"] + '"'
        if part["filename"] is not None:
            disp += '; filename="' + part["filename"] + '"'
        body += b"Content-Disposition: " + disp.encode("utf-8") + b"\r\n"
        body += b"\r\n"
        body += payload_bytes
        body += b"\r\n"

    body += b"--" + boundary_bytes + b"--\r\n"

    result = {
        "content_type": "multipart/form-data; boundary=" + boundary,
        "body_hex": body.hex(),
    }
    return {"name": contract["name"], "result": result}
