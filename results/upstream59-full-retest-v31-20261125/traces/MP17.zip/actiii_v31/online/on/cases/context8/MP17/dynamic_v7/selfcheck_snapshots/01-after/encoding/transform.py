import base64


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict) or "parts" not in data:
        raise ValueError("missing parts")
    parts = data["parts"]
    if not isinstance(parts, list):
        raise ValueError("parts must be a list")

    out_parts = []
    for part in parts:
        if not isinstance(part, dict):
            raise ValueError("part must be object")
        encoding = part.get("encoding")
        if encoding not in ("raw", "base64"):
            raise ValueError("unknown encoding")
        hexval = part.get("hex")
        if not isinstance(hexval, str):
            raise ValueError("hex must be string")
        raw = bytes.fromhex(hexval)
        if encoding == "raw":
            payload = raw
        else:
            b64 = base64.b64encode(raw).decode("ascii")
            lines = [b64[i:i + 76] for i in range(0, len(b64), 76)]
            payload = ("\r\n".join(lines)).encode("ascii")
        new_part = dict(part)
        new_part["payload_hex"] = payload.hex()
        out_parts.append(new_part)

    return {"name": contract["name"], "result": {"parts": out_parts}}
