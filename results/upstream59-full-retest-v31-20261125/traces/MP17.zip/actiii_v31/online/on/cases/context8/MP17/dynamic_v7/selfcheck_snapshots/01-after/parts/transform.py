import re

_FIELD_NAME_RE = re.compile(r'^[A-Za-z0-9_.-]+$')
_FILENAME_RE = re.compile(r'^[A-Za-z0-9_.-]+$')
_BOUNDARY_RE = re.compile(r'^[A-Za-z0-9-]+$')
_MIME_RE = re.compile(r'^[A-Za-z0-9!#$%&\'*+.^_`|~-]+/[A-Za-z0-9!#$%&\'*+.^_`|~-]+$')

_EXT_MIME = {
    '.txt': 'text/plain',
    '.json': 'application/json',
    '.jpg': 'image/jpeg',
}


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return v == v and v not in (float('inf'), float('-inf'))
    return False


def _basename(filename):
    return filename.rsplit('/', 1)[-1]


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError('input must be object')

    fields = data.get('fields')
    files = data.get('files')
    boundary = data.get('boundary')

    if not isinstance(fields, dict):
        raise ValueError('fields must be object')
    if not isinstance(files, dict):
        raise ValueError('files must be object')
    if not isinstance(boundary, str) or not boundary:
        raise ValueError('boundary must be non-empty str')
    if not _BOUNDARY_RE.match(boundary):
        raise ValueError('invalid boundary')

    parts = []
    for name in sorted(fields.keys()):
        if not isinstance(name, str) or not _FIELD_NAME_RE.match(name):
            raise ValueError('invalid field name')
        value = fields[name]
        if isinstance(value, str):
            parts.append({
                'name': name,
                'filename': None,
                'mimetype': 'text/plain',
                'encoding': 'raw',
                'hex': value.encode('utf-8').hex(),
            })
        elif isinstance(value, dict):
            if not value:
                raise ValueError('empty sub-object')
            content = value.get('content')
            filename = value.get('filename')
            mimetype = value.get('mimetype')

            if content is not None:
                if not isinstance(content, str):
                    raise ValueError('content must be str')
                raw = content.encode('utf-8')
                encoding = 'raw'
                if filename is not None:
                    if not isinstance(filename, str) or not _FILENAME_RE.match(_basename(filename)):
                        raise ValueError('invalid filename')
                    filename = _basename(filename)
                else:
                    filename = None
            elif filename is not None:
                if not isinstance(filename, str):
                    raise ValueError('filename must be str')
                base = _basename(filename)
                if not _FILENAME_RE.match(base):
                    raise ValueError('invalid filename')
                if filename not in files:
                    raise ValueError('missing file')
                hexstr = files[filename]
                if not isinstance(hexstr, str):
                    raise ValueError('file hex must be str')
                raw = bytes.fromhex(hexstr)
                encoding = 'base64'
                filename = base
            else:
                raise ValueError('sub-object needs content or filename')

            if mimetype is not None:
                if not isinstance(mimetype, str) or not _MIME_RE.match(mimetype):
                    raise ValueError('invalid mimetype')
                mime = mimetype
            elif filename is not None:
                for ext, m in _EXT_MIME.items():
                    if filename.endswith(ext):
                        mime = m
                        break
                else:
                    mime = 'application/octet-stream'
            else:
                mime = 'application/octet-stream'

            parts.append({
                'name': name,
                'filename': filename,
                'mimetype': mime,
                'encoding': encoding,
                'hex': raw.hex(),
            })
        else:
            raise ValueError('field value must be str or object')

    return {'name': contract['name'], 'result': {'parts': parts}}
