import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        if name in contracts:
            raise ValueError('duplicate component name: %s' % name)
        contracts[name] = {'path': cp, 'contract': c}
    return contracts


def _topological_order(contracts):
    # Build dependency graph: component depends on components that produce
    # any of its input files (inputs that live under outputs/).
    producers = {}
    for name, info in contracts.items():
        out = info['contract']['output']
        producers[out] = name

    deps = {}
    for name, info in contracts.items():
        d = set()
        for inp in info['contract']['inputs']:
            if inp in producers and producers[inp] != name:
                d.add(producers[inp])
        deps[name] = d

    # Kahn's algorithm for topological sort.
    order = []
    remaining = set(contracts.keys())
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError('dependency cycle detected')
        ready.sort()
        for n in ready:
            order.append(n)
            remaining.discard(n)
    return order


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError('no contracts')

    order = _topological_order(contracts)

    for name in order:
        info = contracts[name]
        cp = info['path']
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError('missing render.py for %s' % name)
        # Run render.py as a module so relative imports resolve, passing the
        # root and contract path as argv (render CLIs that ignore argv use
        # cwd and __file__, which are also correct here).
        module = '.'.join(cp.parent.relative_to(ROOT).parts) + '.render'
        subprocess.run(
            [sys.executable, '-m', module, str(ROOT), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=180,
        )

    integrate_py = ROOT / 'integrate.py'
    subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        check=True,
        timeout=180,
    )

    final_report_py = ROOT / 'final_report.py'
    subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=ROOT,
        check=True,
        timeout=180,
    )


if __name__ == '__main__':
    main()
