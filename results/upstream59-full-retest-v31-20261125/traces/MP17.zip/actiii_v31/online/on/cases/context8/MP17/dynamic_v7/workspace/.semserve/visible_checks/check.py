import unittest

# Injected names (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "parts/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "encoding/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "body/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestPartsTransform(unittest.TestCase):
    def test_parts_output_shape_and_ordering(self):
        # multipart_parts: fields sorted by name, filename basename, mimetype mapping.
        payload = {
            "boundary": "Bnd-1",
            "fields": {
                "z": "plain",
                "a": {"content": "hello", "filename": "x.txt"},
            },
            "files": {},
        }
        contract = {"name": "parts", "operation": "multipart_parts", "inputs": ["x"], "output": "y"}
        result = call_candidate("parts/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "parts")
        parts = result["result"]["parts"]
        self.assertEqual([p["name"] for p in parts], ["a", "z"])
        self.assertEqual(parts[0]["filename"], "x.txt")
        self.assertEqual(parts[0]["mimetype"], "text/plain")
        self.assertEqual(parts[0]["encoding"], "raw")
        self.assertEqual(parts[0]["hex"], "hello".encode("utf-8").hex())
        self.assertEqual(parts[1]["filename"], None)
        self.assertEqual(parts[1]["mimetype"], "text/plain")

    def test_parts_file_base64(self):
        payload = {
            "boundary": "B",
            "fields": {"f": {"filename": "data/a.bin"}},
            "files": {"data/a.bin": "00ff"},
        }
        contract = {"name": "parts", "operation": "multipart_parts", "inputs": ["x"], "output": "y"}
        result = call_candidate("parts/transform.py", "transform", args=[[payload], contract])
        part = result["result"]["parts"][0]
        self.assertEqual(part["filename"], "a.bin")
        self.assertEqual(part["encoding"], "base64")
        self.assertEqual(part["hex"], "00ff")
        self.assertEqual(part["mimetype"], "application/octet-stream")

    def test_parts_missing_file_raises(self):
        payload = {
            "boundary": "B",
            "fields": {"f": {"filename": "data/missing.bin"}},
            "files": {},
        }
        contract = {"name": "parts", "operation": "multipart_parts", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("parts/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestEncodingTransform(unittest.TestCase):
    def test_encoding_base64_wrap_76(self):
        # 128 bytes -> base64 length 172 -> wraps at 76 with CRLF.
        raw = bytes(range(128))
        payload = {"parts": [{"name": "a", "filename": None, "mimetype": "application/octet-stream",
                              "encoding": "base64", "hex": raw.hex()}]}
        contract = {"name": "encoding", "operation": "multipart_encoding", "inputs": ["x"], "output": "y"}
        result = call_candidate("encoding/transform.py", "transform", args=[[payload], contract])
        part = result["result"]["parts"][0]
        import base64
        b64 = base64.b64encode(raw).decode("ascii")
        expected = "\r\n".join(b64[i:i + 76] for i in range(0, len(b64), 76))
        self.assertEqual(part["payload_hex"], expected.encode("ascii").hex())
        self.assertEqual(part["encoding"], "base64")

    def test_encoding_raw_preserved(self):
        payload = {"parts": [{"name": "a", "filename": None, "mimetype": "text/plain",
                              "encoding": "raw", "hex": "c3a9"}]}
        contract = {"name": "encoding", "operation": "multipart_encoding", "inputs": ["x"], "output": "y"}
        result = call_candidate("encoding/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["parts"][0]["payload_hex"], "c3a9")

    def test_encoding_unknown_encoding_raises(self):
        payload = {"parts": [{"name": "a", "filename": None, "mimetype": "text/plain",
                              "encoding": "bogus", "hex": "00"}]}
        contract = {"name": "encoding", "operation": "multipart_encoding", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("encoding/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestBodyTransform(unittest.TestCase):
    def test_body_content_type_and_structure(self):
        snapshot = {"boundary": "Bnd"}
        encoded = {"parts": [
            {"name": "t", "filename": None, "mimetype": "text/plain", "encoding": "raw",
             "payload_hex": "6869"},
        ]}
        contract = {"name": "body", "operation": "multipart_body", "inputs": ["a", "b"], "output": "y"}
        result = call_candidate("body/transform.py", "transform", args=[[snapshot, encoded], contract])
        self.assertEqual(result["result"]["content_type"], "multipart/form-data; boundary=Bnd")
        body = bytes.fromhex(result["result"]["body_hex"])
        expected = (b"--Bnd\r\n"
                    b"Content-Type: text/plain\r\n"
                    b'Content-Disposition: form-data; name="t"\r\n'
                    b"\r\n"
                    b"hi\r\n"
                    b"--Bnd--\r\n")
        self.assertEqual(body, expected)

    def test_body_boundary_in_payload_raises(self):
        snapshot = {"boundary": "Bnd"}
        encoded = {"parts": [
            {"name": "t", "filename": None, "mimetype": "text/plain", "encoding": "raw",
             "payload_hex": "426e64"},
        ]}
        contract = {"name": "body", "operation": "multipart_body", "inputs": ["a", "b"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("body/transform.py", "transform", args=[[snapshot, encoded], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestApiBoundaries(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                if not spec.get("applicable", False):
                    continue
                with self.subTest(target=req["target_path"], rule=rule):
                    if rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            req["target_path"], rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"boundary": "B", "fields": {}, "files": {}}], {"name": "x", "operation": "y", "inputs": ["i"], "output": "o"}],
                        )
                    elif rule == "invalid_payload_type":
                        check_api_boundary(
                            req["target_path"], rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"boundary": "B", "fields": {}, "files": {}}], {"name": "x", "operation": "y", "inputs": ["i"], "output": "o"}],
                        )


if __name__ == "__main__":
    unittest.main()
