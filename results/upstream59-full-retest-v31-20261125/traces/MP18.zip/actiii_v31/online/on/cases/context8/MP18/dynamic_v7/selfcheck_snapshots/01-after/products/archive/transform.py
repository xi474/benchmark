import hashlib


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    inventory = payloads[0]
    selection = payloads[1]

    # Unwrap name/result envelope if present.
    if isinstance(inventory, dict) and set(inventory) == {"name", "result"}:
        inventory = inventory["result"]
    if isinstance(selection, dict) and set(selection) == {"name", "result"}:
        selection = selection["result"]

    files = inventory["files"]
    selected = selection["selected"]

    # Build path -> hex lookup for ordinary files.
    hex_by_path = {}
    for f in files:
        hex_by_path[f["path"]] = f["hex"]

    # selected must be unique and each item must be an ordinary file.
    if len(set(selected)) != len(selected):
        raise ValueError("selected contains duplicates")
    for path in selected:
        if path not in hex_by_path:
            raise ValueError("selected path not in ordinary file list")

    entries = []
    total_bytes = 0
    for path in selected:
        raw = bytes.fromhex(hex_by_path[path])
        size = len(raw)
        sha256 = hashlib.sha256(raw).hexdigest()
        entries.append({"path": path, "size": size, "sha256": sha256})
        total_bytes += size

    return {"name": contract["name"], "result": {"entries": entries, "total_bytes": total_bytes}}
