import re


def _safe_rel_path(s):
    if not isinstance(s, str):
        raise ValueError("path must be string")
    if s != s.strip() or s == "":
        raise ValueError("path must be non-empty after strip")
    if s.startswith("/") or "\\" in s or ":" in s:
        raise ValueError("unsafe path")
    parts = s.split("/")
    if any(p == "" or p == "." or p == ".." for p in parts):
        raise ValueError("unsafe path segment")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    files = data.get("files")
    if files is None:
        raise ValueError("missing files")
    if not isinstance(files, list):
        raise ValueError("files must be list")

    seen = set()
    regular = []
    symlinks = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        path = f.get("path")
        kind = f.get("kind")
        if path is None or kind is None:
            raise ValueError("missing path/kind")
        path = _safe_rel_path(path)
        if path in seen:
            raise ValueError("duplicate path")
        seen.add(path)
        if kind == "file":
            hexv = f.get("hex")
            if not isinstance(hexv, str):
                raise ValueError("hex must be string")
            try:
                bytes.fromhex(hexv)
            except ValueError:
                raise ValueError("invalid hex")
            regular.append({"path": path, "hex": hexv})
        elif kind == "symlink":
            target = f.get("target")
            if target is None:
                raise ValueError("symlink missing target")
            _safe_rel_path(target)
            symlinks.append(path)
        else:
            raise ValueError("invalid kind")

    regular.sort(key=lambda x: x["path"])
    symlinks.sort()

    return {"name": contract["name"], "result": {"files": regular, "symlinks": symlinks}}
