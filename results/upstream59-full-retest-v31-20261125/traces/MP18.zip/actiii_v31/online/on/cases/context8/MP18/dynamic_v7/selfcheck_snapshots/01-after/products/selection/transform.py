import fnmatch


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj) == {"name", "result"}:
        return obj["result"]
    return obj


def _require(cond, msg="invalid input"):
    if not cond:
        raise ValueError(msg)


def transform(payloads, contract):
    _require(len(payloads) == len(contract["inputs"]), "payload count mismatch")

    snapshot = _unwrap(payloads[0])
    inventory = _unwrap(payloads[1])

    _require(isinstance(snapshot, dict), "snapshot must be object")
    _require(isinstance(inventory, dict), "inventory must be object")

    manifest = snapshot.get("manifest")
    build_ignore = snapshot.get("build_ignore")

    _require(manifest is None or isinstance(manifest, str), "manifest must be str or null")
    _require(build_ignore is None or isinstance(build_ignore, list), "build_ignore must be list or null")
    _require(not (manifest is not None and build_ignore is not None),
             "manifest and build_ignore cannot both be set")

    inv_files = inventory.get("files")
    _require(isinstance(inv_files, list), "inventory files must be list")
    regular_paths = []
    for f in inv_files:
        _require(isinstance(f, dict) and isinstance(f.get("path"), str), "bad inventory file entry")
        regular_paths.append(f["path"])

    selected = set()

    if manifest is None:
        selected = set(regular_paths)
        if build_ignore is not None:
            for pat in build_ignore:
                _require(isinstance(pat, str), "build_ignore pattern must be str")
            for p in list(selected):
                for pat in build_ignore:
                    if fnmatch.fnmatchcase(p, pat):
                        selected.discard(p)
                        break
    else:
        for raw_line in manifest.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            op = parts[0]
            if op == "include":
                _require(len(parts) == 2, "unknown manifest syntax")
                pat = parts[1]
                for p in regular_paths:
                    if fnmatch.fnmatchcase(p, pat):
                        selected.add(p)
            elif op == "exclude":
                _require(len(parts) == 2, "unknown manifest syntax")
                pat = parts[1]
                for p in list(selected):
                    if fnmatch.fnmatchcase(p, pat):
                        selected.discard(p)
            elif op == "recursive-include":
                _require(len(parts) == 3, "unknown manifest syntax")
                dir_, pat = parts[1], parts[2]
                prefix = dir_.rstrip("/") + "/"
                for p in regular_paths:
                    if p.startswith(prefix):
                        base = p.rsplit("/", 1)[-1]
                        if fnmatch.fnmatchcase(base, pat):
                            selected.add(p)
            elif op == "global-exclude":
                _require(len(parts) == 2, "unknown manifest syntax")
                pat = parts[1]
                for p in list(selected):
                    base = p.rsplit("/", 1)[-1]
                    if fnmatch.fnmatchcase(base, pat):
                        selected.discard(p)
            else:
                raise ValueError("unknown manifest syntax")

    # Unconditional exclusions.
    for p in list(selected):
        parts = p.split("/")
        if ".git" in parts:
            selected.discard(p)
        elif p.endswith(".pyc"):
            selected.discard(p)
        elif p == "MANIFEST.in":
            selected.discard(p)

    return {"name": contract["name"], "result": {"selected": sorted(selected)}}
