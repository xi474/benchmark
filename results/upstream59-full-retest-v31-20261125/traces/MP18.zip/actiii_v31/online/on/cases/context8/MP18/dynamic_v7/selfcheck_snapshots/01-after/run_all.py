import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise ValueError("no contracts")

    # Topologically order components by their declared input dependencies.
    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        by_name[c["name"]] = (cp, c)

    ordered = []
    done = set()

    def visit(name, stack):
        if name in done:
            return
        if name in stack:
            raise ValueError("dependency cycle")
        stack.add(name)
        cp, c = by_name[name]
        for inp in c["inputs"]:
            dep = inp.split("/")[0]
            if dep == "outputs":
                dep = inp.split("/")[1].split(".")[0]
            if dep in by_name:
                visit(dep, stack)
        stack.discard(name)
        done.add(name)
        ordered.append((cp, c))

    for name in by_name:
        visit(name, set())

    for cp, c in ordered:
        subprocess.run(
            [sys.executable, str(cp.with_name("render.py")), str(ROOT), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
