import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/inventory/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/selection/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/archive/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestAPIBoundary(unittest.TestCase):
    def test_inventory_boundary(self):
        check_api_boundary(
            "products/inventory/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
            args=[{"files": [], "manifest": None, "build_ignore": None},
                  {"name": "inventory", "operation": "manifest_inventory",
                   "inputs": ["inputs/case.json"], "output": "outputs/inventory.json"}],
        )
        check_api_boundary(
            "products/inventory/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            args=[{"files": [], "manifest": None, "build_ignore": None},
                  {"name": "inventory", "operation": "manifest_inventory",
                   "inputs": ["inputs/case.json"], "output": "outputs/inventory.json"}],
        )

    def test_selection_boundary(self):
        check_api_boundary(
            "products/selection/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
            args=[{"files": [], "manifest": None, "build_ignore": None},
                  {"files": [], "symlinks": []},
                  {"name": "selection", "operation": "manifest_selection",
                   "inputs": ["inputs/case.json", "outputs/inventory.json"],
                   "output": "outputs/selection.json"}],
        )
        check_api_boundary(
            "products/selection/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            args=[{"files": [], "manifest": None, "build_ignore": None},
                  {"files": [], "symlinks": []},
                  {"name": "selection", "operation": "manifest_selection",
                   "inputs": ["inputs/case.json", "outputs/inventory.json"],
                   "output": "outputs/selection.json"}],
        )

    def test_archive_boundary(self):
        check_api_boundary(
            "products/archive/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
            args=[{"files": [], "symlinks": []},
                  {"selected": []},
                  {"name": "archive", "operation": "manifest_archive",
                   "inputs": ["outputs/inventory.json", "outputs/selection.json"],
                   "output": "outputs/archive.json"}],
        )
        check_api_boundary(
            "products/archive/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            args=[{"files": [], "symlinks": []},
                  {"selected": []},
                  {"name": "archive", "operation": "manifest_archive",
                   "inputs": ["outputs/inventory.json", "outputs/selection.json"],
                   "output": "outputs/archive.json"}],
        )


class TestInventoryTransform(unittest.TestCase):
    def test_inventory_output_shape(self):
        payloads = [
            {
                "files": [
                    {"path": "a.txt", "kind": "file", "hex": "6162", "target": None},
                    {"path": "link", "kind": "symlink", "hex": "", "target": "a.txt"},
                ],
                "manifest": None,
                "build_ignore": None,
            }
        ]
        contract = {"name": "inventory", "operation": "manifest_inventory",
                    "inputs": ["inputs/case.json"], "output": "outputs/inventory.json"}
        result = call_candidate("products/inventory/transform.py", "transform",
                                args=[payloads, contract])
        self.assertEqual(set(result), {"name", "result"})
        self.assertEqual(result["name"], "inventory")
        self.assertEqual(result["result"]["files"], [{"path": "a.txt", "hex": "6162"}])
        self.assertEqual(result["result"]["symlinks"], ["link"])

    def test_inventory_duplicate_path_raises(self):
        payloads = [
            {
                "files": [
                    {"path": "a.txt", "kind": "file", "hex": "6162", "target": None},
                    {"path": "a.txt", "kind": "file", "hex": "6364", "target": None},
                ],
                "manifest": None,
                "build_ignore": None,
            }
        ]
        contract = {"name": "inventory", "operation": "manifest_inventory",
                    "inputs": ["inputs/case.json"], "output": "outputs/inventory.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/inventory/transform.py", "transform",
                           args=[payloads, contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestSelectionTransform(unittest.TestCase):
    def test_selection_manifest_include(self):
        snapshot = {
            "files": [
                {"path": "a.py", "kind": "file", "hex": "6162", "target": None},
                {"path": "b.txt", "kind": "file", "hex": "6364", "target": None},
            ],
            "manifest": "include *.py\n",
            "build_ignore": None,
        }
        inventory = {"files": [{"path": "a.py", "hex": "6162"},
                               {"path": "b.txt", "hex": "6364"}],
                     "symlinks": []}
        payloads = [snapshot, inventory]
        contract = {"name": "selection", "operation": "manifest_selection",
                    "inputs": ["inputs/case.json", "outputs/inventory.json"],
                    "output": "outputs/selection.json"}
        result = call_candidate("products/selection/transform.py", "transform",
                                args=[payloads, contract])
        self.assertEqual(result["result"]["selected"], ["a.py"])

    def test_selection_manifest_and_build_ignore_conflict(self):
        snapshot = {
            "files": [],
            "manifest": "include *.py\n",
            "build_ignore": ["*.txt"],
        }
        inventory = {"files": [], "symlinks": []}
        payloads = [snapshot, inventory]
        contract = {"name": "selection", "operation": "manifest_selection",
                    "inputs": ["inputs/case.json", "outputs/inventory.json"],
                    "output": "outputs/selection.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/selection/transform.py", "transform",
                           args=[payloads, contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestArchiveTransform(unittest.TestCase):
    def test_archive_entries_and_total(self):
        inventory = {"files": [{"path": "a.txt", "hex": "6162"}], "symlinks": []}
        selection = {"selected": ["a.txt"]}
        payloads = [inventory, selection]
        contract = {"name": "archive", "operation": "manifest_archive",
                    "inputs": ["outputs/inventory.json", "outputs/selection.json"],
                    "output": "outputs/archive.json"}
        result = call_candidate("products/archive/transform.py", "transform",
                                args=[payloads, contract])
        self.assertEqual(result["result"]["total_bytes"], 2)
        self.assertEqual(len(result["result"]["entries"]), 1)
        self.assertEqual(result["result"]["entries"][0]["path"], "a.txt")
        self.assertEqual(result["result"]["entries"][0]["size"], 2)

    def test_archive_selected_not_in_inventory_raises(self):
        inventory = {"files": [{"path": "a.txt", "hex": "6162"}], "symlinks": []}
        selection = {"selected": ["missing.txt"]}
        payloads = [inventory, selection]
        contract = {"name": "archive", "operation": "manifest_archive",
                    "inputs": ["outputs/inventory.json", "outputs/selection.json"],
                    "output": "outputs/archive.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/archive/transform.py", "transform",
                           args=[payloads, contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
