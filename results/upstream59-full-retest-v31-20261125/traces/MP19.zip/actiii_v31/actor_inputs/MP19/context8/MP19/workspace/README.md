# Python 支持模块发现与可重复 ZIP 载荷：接口与完整规格

静态发现入口模块需要的支持文件，解析依赖闭包和 six 别名，生成包含基础包文件的确定性 ZIP 载荷。

## 环境与实现范围

Python 3.11及以上，仅标准库；本地合成输入，无GPU、训练、网络、真实账号或实时等待。所有时间按本题显式规则处理，禁止读取当前日期替代输入日期。

engines/分别实现算法内核，输入/输出文件接口表达算法之间真实依赖。

组件实现model.py、transform.py、render.py，以及根run_all.py和final_report.py；可新增私有辅助模块。未提供的实现文件需要自行创建。

README.md、TASK.md、inputs/、contract.json、check_module.py、check.py、integrate.py以及适用的materialize.py、__init__.py、parser.py不可修改。初始输入和契约为任务规格，不是可以修正的错误数据。

## 稳定接口与通用边界

- model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。

- transform.transform(payloads:list,contract:dict)：payloads按contract.inputs顺序，数量必须一致。返回恰好{"name":contract["name"],"result":算法结果对象}；本说明中的输出均指result，不额外套一层封装。

- 当输入对象键恰为name/result时，仅其result为业务输入；其他对象原样解释。不修改payloads/contract（包括嵌套值），不硬编码公开输入或上游结果。

- render.build_component(root:Path,contract_path:Path)：从给定root读取所有输入，调用transform并返回封装。执行python3 <组件目录>/render.py时，将封装写入contract.output；必须支持任意当前目录。缺文件或子命令失败须失败。

- context包另外保留<package>.parser.parse(payloads,contract)，返回与transform完全一致的封装。不要修改稳定parser来绕过实现。

- 必需字段缺失、指定非法类型/重复/冲突均ValueError。整数排除bool，有限数允许int/float但排除bool及非有限数，布尔字段必须bool；无明示默认值不自行补默认。未知额外字段可忽略，但其中非有限JSON仍非法。所有合法空集/无解按照各operation输出。

- 字符串排序按Python通常字典序；非空字符串要求strip后非空，但除规则明示外保留原内容。安全相对路径使用/，禁止绝对路径、反斜线、冒号、空段、.和..。hex按bytes.fromhex解释，不将hex文本当字节计算摘要。

- 数值计算比较容差为相对/绝对1e-9；非数值结构、键集合、列表顺序、文本/字节格式必须精确。输入中的算法图是业务数据，不是Agent执行计划。

## 各组件业务规则

### engines/scanner

operation：`module_import_scan`。输入文件及顺序见`engines/scanner/contract.json`，输出为`outputs/scanner.json`。

输入{modules:{相对.py路径:源码},entry:存在的入口路径,externals:[允许外部模块名],aliases:{完整导入名:允许外部模块名}}。只做AST静态import/from，不执行源码；from*禁止。对from X import y先尝试X.y存在本地模块，否则依赖X；相对from根据当前package解析，超出根报错；import X依赖X。每个包__init__.py作为该包模块。返回{imports:{路径:[规范模块名去重排序]},module_paths:{模块名:路径}}。空根__init__.py模块名为""。

局部检查：`python3 engines/scanner/check_module.py`；先生成该契约所需输入及本组件输出，不跳过缺失依赖。

### engines/dependencies

operation：`module_dependency_closure`。输入文件及顺序见`engines/dependencies/contract.json`，输出为`outputs/dependencies.json`。

输入依次原模块输入、module_import_scan。从entry做可重复BFS：本地依赖加入对应.py，且加入所有存在的父package __init__.py；循环合法。外部模块只在externals精确命中或首段命中时允许，aliases先做精确名转换再按外部验证；未知模块ValueError。返回{paths:所有所需路径排序,external:[实际外部规范名排序]}。不能导入/执行候选源码来发现依赖。

局部检查：`python3 engines/dependencies/check_module.py`；先生成该契约所需输入及本组件输出，不跳过缺失依赖。

### engines/payload

operation：`module_zip`。输入文件及顺序见`engines/payload/contract.json`，输出为`outputs/payload.json`。

输入依次原模块输入、module_dependency_closure。将paths对应源码UTF8字节加入ZIP_STORED档案；如果根__init__.py缺失则增加空根__init__.py。ZIP项按路径排序，固定时间1980-01-01 00:00:00、create_system=3、external_attr=0o644<<16、无注释。返回{paths:[ZIP路径顺序],zip_hex,sha256:ZIP字节摘要,external:上游external}。不存在的源路径/重复paths报ValueError。不包含所有未使用模块。

局部检查：`python3 engines/payload/check_module.py`；先生成该契约所需输入及本组件输出，不跳过缺失依赖。

## 集成、JSON与最终报告

所有JSON产物按UTF8、ensure_ascii=False、sort_keys=True、indent=2、allow_nan=False写出，末尾一个真实换行。数值容差不允许省略字段、额外封装或改写字符串。

实现run_all.py，定位工作区并依据文件接口执行全部必要组件。每次调用应重新计算全部组件输出，不借用旧outputs；缺失依赖、环或子命令失败必须非零退出。已有python3 integrate.py读取所有组件产物，写outputs/core_manifest.json={"components":{组件名:result}}，不得修改集成器。

实现final_report.py，读取完整core对象，写outputs/final_report.json，恰含title、component_count、sha256、attention。title准确为'Python 支持模块发现与可重复 ZIP 载荷'，component_count为components键数。

sha256针对完整core对象（含外层components），序列化为json.dumps(core,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode("utf-8")，无末尾换行，再求SHA256小写hex。

attention为满足任一条件的组件名去重排序列表：result.blocked显式true；complete/checkout/committed/ok任一显式false；unavailable/missing/conflicts/unreachable任一非空。不存在字段不触发；false与0/null不混同。

## 运行与验收

在工作区运行python3 check.py。该命令清理outputs、执行适用的物化、运行run_all、检查结构和局部接口；公开冒烟不包含全部金标，也不决定正式得分。外部可信verifier检查受保护文件、所有产物、不同输入的API探针、load_payload和build_component。

Agent输入只有本题TASK.md与workspace。作者参考解、来源评审、DAG、隐藏向量、seal和正式验证器均保留在工作区外，不能作为被测Agent上下文。

