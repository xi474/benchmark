import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    cp = Path(contract_path)
    c = load_payload(cp)
    payloads = [load_payload(root / p) for p in c["inputs"]]
    return transform(payloads, c)


if __name__ == "__main__":
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    cp = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("contract.json")
    c = load_payload(cp)
    result = build_component(root, cp)
    out = root / c["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
