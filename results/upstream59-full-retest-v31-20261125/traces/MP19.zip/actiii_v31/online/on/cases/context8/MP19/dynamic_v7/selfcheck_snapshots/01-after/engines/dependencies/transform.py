def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _validate_inputs(modules, entry, externals, aliases):
    if not isinstance(modules, dict):
        raise ValueError("modules must be object")
    for k, v in modules.items():
        if not isinstance(k, str) or not isinstance(v, str):
            raise ValueError("modules keys/values must be strings")
    if not isinstance(entry, str):
        raise ValueError("entry must be string")
    if not isinstance(externals, list):
        raise ValueError("externals must be list")
    for e in externals:
        if not isinstance(e, str):
            raise ValueError("externals must be strings")
    if not isinstance(aliases, dict):
        raise ValueError("aliases must be object")
    for k, v in aliases.items():
        if not isinstance(k, str) or not isinstance(v, str):
            raise ValueError("aliases keys/values must be strings")


def _module_name(path):
    # path like "pkg/a.py" -> "pkg.a"; "main.py" -> "main"; "pkg/__init__.py" -> "pkg"
    if path.endswith(".py"):
        path = path[:-3]
    parts = path.split("/")
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _parent_packages(module_name):
    # "pkg.a.b" -> ["pkg.a", "pkg"]
    parts = module_name.split(".")
    result = []
    for i in range(len(parts) - 1, 0, -1):
        result.append(".".join(parts[:i]))
    return result


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    modules_payload = _unwrap(payloads[0])
    scan_payload = _unwrap(payloads[1])

    modules = modules_payload.get("modules")
    entry = modules_payload.get("entry")
    externals = modules_payload.get("externals")
    aliases = modules_payload.get("aliases")

    _validate_inputs(modules, entry, externals, aliases)

    imports = scan_payload.get("imports")
    module_paths = scan_payload.get("module_paths")
    if not isinstance(imports, dict) or not isinstance(module_paths, dict):
        raise ValueError("scan result malformed")

    # module name -> path mapping from scan
    name_to_path = {}
    for name, path in module_paths.items():
        name_to_path[name] = path

    # path -> module name
    path_to_name = {}
    for name, path in module_paths.items():
        path_to_name[path] = name

    # entry module name
    if entry not in path_to_name:
        raise ValueError("entry not found")
    entry_name = path_to_name[entry]

    externals_set = set(externals)

    def is_external(name):
        if name in externals_set:
            return True
        first = name.split(".")[0]
        if first in externals_set:
            return True
        return False

    def resolve_alias(name):
        # exact alias conversion
        if name in aliases:
            return aliases[name]
        return name

    # BFS
    visited_paths = set()
    external_names = set()
    queue = [entry_name]

    while queue:
        name = queue.pop(0)
        # resolve alias first
        resolved = resolve_alias(name)
        if resolved in name_to_path:
            # local module
            path = name_to_path[resolved]
            if path not in visited_paths:
                visited_paths.add(path)
                # add parent __init__.py
                for parent in _parent_packages(resolved):
                    if parent in name_to_path:
                        ppath = name_to_path[parent]
                        if ppath not in visited_paths:
                            visited_paths.add(ppath)
                # enqueue its imports
                for imp in imports.get(path, []):
                    queue.append(imp)
        else:
            # external module
            if is_external(resolved):
                external_names.add(resolved)
            else:
                raise ValueError("unknown module: %s" % resolved)

    paths = sorted(visited_paths)
    external = sorted(external_names)

    return {"name": contract["name"], "result": {"paths": paths, "external": external}}
