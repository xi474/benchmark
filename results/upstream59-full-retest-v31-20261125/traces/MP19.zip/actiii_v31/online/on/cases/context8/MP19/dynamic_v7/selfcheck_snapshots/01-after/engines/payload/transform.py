import hashlib
import io
import zipfile


def _require(cond, msg="invalid input"):
    if not cond:
        raise ValueError(msg)


def transform(payloads, contract):
    _require(len(payloads) == len(contract["inputs"]), "payload count mismatch")
    modules_payload, closure_payload = payloads

    # Unwrap name/result envelope if present.
    if isinstance(modules_payload, dict) and set(modules_payload) == {"name", "result"}:
        modules = modules_payload["result"]
    else:
        modules = modules_payload
    if isinstance(closure_payload, dict) and set(closure_payload) == {"name", "result"}:
        closure = closure_payload["result"]
    else:
        closure = closure_payload

    _require(isinstance(modules, dict), "modules must be object")
    _require(isinstance(closure, dict), "closure must be object")

    # The modules payload may itself be a name/result envelope.
    if isinstance(modules, dict) and set(modules) == {"name", "result"}:
        modules = modules["result"]
    _require(isinstance(modules, dict), "modules must be object")

    # The modules payload carries source under the "modules" key.
    if "modules" in modules and isinstance(modules["modules"], dict):
        modules = modules["modules"]
    _require(isinstance(modules, dict), "modules must be object")

    paths = closure["paths"]
    external = closure["external"]
    _require(isinstance(paths, list), "paths must be list")
    _require(isinstance(external, list), "external must be list")

    # Validate paths: no duplicates, all exist in modules.
    seen = set()
    for p in paths:
        _require(isinstance(p, str), "path must be string")
        _require(p not in seen, "duplicate path")
        seen.add(p)
        _require(p in modules, "source path missing")

    # Determine whether root __init__.py is needed.
    has_root_init = "__init__.py" in modules
    if not has_root_init:
        # Add empty root __init__.py.
        pass

    # Build ZIP entries sorted by path.
    sorted_paths = sorted(paths)
    if not has_root_init:
        sorted_paths = sorted(sorted_paths + ["__init__.py"])

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_STORED) as zf:
        for p in sorted_paths:
            if p == "__init__.py" and not has_root_init:
                data = b""
            else:
                data = modules[p].encode("utf-8")
            zi = zipfile.ZipInfo(p, (1980, 1, 1, 0, 0, 0))
            zi.create_system = 3
            zi.external_attr = 0o644 << 16
            zi.compress_type = zipfile.ZIP_STORED
            zf.writestr(zi, data)

    zip_bytes = buf.getvalue()
    sha = hashlib.sha256(zip_bytes).hexdigest()

    return {
        "name": contract["name"],
        "result": {
            "paths": sorted_paths,
            "zip_hex": zip_bytes.hex(),
            "sha256": sha,
            "external": external,
        },
    }

