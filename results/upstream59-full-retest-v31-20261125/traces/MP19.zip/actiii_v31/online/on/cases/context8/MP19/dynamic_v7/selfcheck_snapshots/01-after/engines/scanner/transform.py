import ast


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def _is_safe_rel_path(p):
    if not isinstance(p, str) or p == "":
        return False
    if p.startswith("/") or "\\" in p or ":" in p:
        return False
    for seg in p.split("/"):
        if seg in ("", ".", ".."):
            return False
    return True


def _path_to_module_name(path):
    parts = path.split("/")
    if parts[-1] == "__init__.py":
        parts = parts[:-1]
    else:
        parts[-1] = parts[-1][:-3]
    return ".".join(parts)


def _resolve_relative(current_package, level):
    parts = current_package.split(".") if current_package else []
    remove = level - 1
    if remove > len(parts):
        raise ValueError("relative import beyond root")
    parts = parts[: len(parts) - remove]
    return ".".join(parts)


def _scan_module(path, src, module_paths):
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        raise ValueError("invalid source") from e

    module_name = _path_to_module_name(path)
    if path.endswith("__init__.py"):
        current_package = module_name
    else:
        current_package = module_name.rsplit(".", 1)[0] if "." in module_name else ""

    deps = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                deps.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.level > 0:
                base = _resolve_relative(current_package, node.level)
                if node.module:
                    x = base + "." + node.module if base else node.module
                else:
                    x = base
            else:
                x = node.module
            for alias in node.names:
                if alias.name == "*":
                    raise ValueError("from* forbidden")
                candidate = x + "." + alias.name if x else alias.name
                if candidate in module_paths:
                    deps.add(candidate)
                else:
                    deps.add(x)
    return sorted(deps)


def transform(payloads, contract):
    if not isinstance(contract, dict):
        raise ValueError("contract must be object")
    if "inputs" not in contract or not isinstance(contract["inputs"], list):
        raise ValueError("contract.inputs required")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    if "modules" not in data or not isinstance(data["modules"], dict):
        raise ValueError("modules required")
    modules = data["modules"]
    for p, src in modules.items():
        if not _is_safe_rel_path(p):
            raise ValueError("invalid module path")
        if not isinstance(src, str):
            raise ValueError("module source must be string")

    if "entry" not in data or not isinstance(data["entry"], str):
        raise ValueError("entry required")
    if data["entry"] not in modules:
        raise ValueError("entry not in modules")

    if "externals" not in data or not isinstance(data["externals"], list):
        raise ValueError("externals required")
    for e in data["externals"]:
        if not isinstance(e, str):
            raise ValueError("external must be string")

    if "aliases" not in data or not isinstance(data["aliases"], dict):
        raise ValueError("aliases required")
    for k, v in data["aliases"].items():
        if not isinstance(k, str) or not isinstance(v, str):
            raise ValueError("alias must map string to string")

    module_paths = {}
    for p in modules:
        module_paths[_path_to_module_name(p)] = p

    imports = {}
    for p, src in modules.items():
        imports[p] = _scan_module(p, src, module_paths)

    result = {"imports": imports, "module_paths": module_paths}
    return {"name": contract["name"], "result": result}
