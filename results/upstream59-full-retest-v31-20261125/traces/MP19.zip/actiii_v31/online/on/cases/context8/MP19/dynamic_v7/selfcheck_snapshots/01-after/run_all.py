import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise SystemExit("no contracts found")

    # Topologically order components by their input dependencies.
    info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        info[str(cp)] = c

    produced = {}
    for cp, c in info.items():
        produced[c["output"]] = cp

    ordered = []
    remaining = set(info)
    while remaining:
        progressed = False
        for cp in sorted(remaining):
            c = info[cp]
            deps = [p for p in c["inputs"] if p in produced]
            if all(produced[p] not in remaining for p in deps):
                ordered.append(cp)
                remaining.discard(cp)
                progressed = True
        if not progressed:
            raise SystemExit("circular dependency among components")

    for cp in ordered:
        c = info[cp]
        render = Path(cp).with_name("render.py")
        if not render.is_file():
            raise SystemExit("missing render.py for %s" % cp)
        subprocess.run(
            [sys.executable, str(render), str(ROOT), str(cp)],
            cwd=ROOT,
            check=True,
        )

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
    )

    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
