import unittest

# Injected by the visible-contract SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:  # pragma: no cover - only for local import sanity
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None

README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/scanner/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/dependencies/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/payload/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestScannerTransform(unittest.TestCase):
    def test_api_boundary_probes(self):
        contract = {
            "name": "scanner",
            "operation": "module_import_scan",
            "inputs": ["inputs/case.json"],
            "output": "outputs/scanner.json",
        }
        payload = {
            "modules": {"main.py": "import json\n"},
            "entry": "main.py",
            "externals": ["json"],
            "aliases": {},
        }
        check_api_boundary("engines/scanner/transform.py", rule="nonfinite_unknown_field",
                          contract_path="README.md",
                          requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                          args=[[payload], contract])
        check_api_boundary("engines/scanner/transform.py", rule="invalid_payload_type",
                          contract_path="README.md",
                          requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                          args=[[payload], contract])

    def test_scan_output_shape_and_imports(self):
        # Public rule: module_import_scan returns imports and module_paths.
        contract = {
            "name": "scanner",
            "operation": "module_import_scan",
            "inputs": ["inputs/case.json"],
            "output": "outputs/scanner.json",
        }
        payload = {
            "modules": {
                "main.py": "import pkg.a\n",
                "pkg/__init__.py": "from . import b\n",
                "pkg/a.py": "from . import b\nimport six.moves.urllib.parse\n",
                "pkg/b.py": "from . import a\nimport json\n",
                "unused.py": "print('unused')\n",
            },
            "entry": "main.py",
            "externals": ["json", "urllib"],
            "aliases": {"six.moves.urllib.parse": "urllib.parse"},
        }
        result = call_candidate("engines/scanner/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(set(result), {"name", "result"})
        self.assertEqual(result["name"], "scanner")
        r = result["result"]
        self.assertEqual(set(r), {"imports", "module_paths"})
        self.assertEqual(r["imports"]["main.py"], ["pkg.a"])
        self.assertEqual(r["imports"]["pkg/a.py"], ["pkg.b", "six.moves.urllib.parse"])
        self.assertEqual(r["module_paths"]["pkg"], "pkg/__init__.py")
        self.assertEqual(r["module_paths"]["main"], "main.py")

    def test_from_star_forbidden(self):
        contract = {
            "name": "scanner",
            "operation": "module_import_scan",
            "inputs": ["x"],
            "output": "y",
        }
        payload = {
            "modules": {"main.py": "from pkg import *\n"},
            "entry": "main.py",
            "externals": [],
            "aliases": {},
        }
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("engines/scanner/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestDependenciesTransform(unittest.TestCase):
    def test_api_boundary_probes(self):
        contract = {
            "name": "dependencies",
            "operation": "module_dependency_closure",
            "inputs": ["inputs/case.json", "outputs/scanner.json"],
            "output": "outputs/dependencies.json",
        }
        modules_payload = {
            "modules": {"main.py": "import json\n"},
            "entry": "main.py",
            "externals": ["json"],
            "aliases": {},
        }
        scan = {
            "imports": {"main.py": ["json"]},
            "module_paths": {"main": "main.py"},
        }
        check_api_boundary("engines/dependencies/transform.py", rule="nonfinite_unknown_field",
                          contract_path="README.md",
                          requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                          args=[[modules_payload, scan], contract])
        check_api_boundary("engines/dependencies/transform.py", rule="invalid_payload_type",
                          contract_path="README.md",
                          requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                          args=[[modules_payload, scan], contract])

    def test_closure_paths_and_external(self):
        contract = {
            "name": "dependencies",
            "operation": "module_dependency_closure",
            "inputs": ["inputs/case.json", "outputs/scanner.json"],
            "output": "outputs/dependencies.json",
        }
        modules_payload = {
            "modules": {
                "main.py": "import pkg.a\n",
                "pkg/__init__.py": "from . import b\n",
                "pkg/a.py": "from . import b\nimport six.moves.urllib.parse\n",
                "pkg/b.py": "from . import a\nimport json\n",
                "unused.py": "print('unused')\n",
            },
            "entry": "main.py",
            "externals": ["json", "urllib"],
            "aliases": {"six.moves.urllib.parse": "urllib.parse"},
        }
        scan = {
            "imports": {
                "main.py": ["pkg.a"],
                "pkg/__init__.py": ["pkg.b"],
                "pkg/a.py": ["pkg.b", "six.moves.urllib.parse"],
                "pkg/b.py": ["json", "pkg.a"],
                "unused.py": [],
            },
            "module_paths": {
                "main": "main.py",
                "pkg": "pkg/__init__.py",
                "pkg.a": "pkg/a.py",
                "pkg.b": "pkg/b.py",
                "unused": "unused.py",
            },
        }
        result = call_candidate("engines/dependencies/transform.py", "transform",
                                args=[[modules_payload, scan], contract])
        r = result["result"]
        self.assertEqual(r["paths"], ["main.py", "pkg/__init__.py", "pkg/a.py", "pkg/b.py"])
        self.assertEqual(r["external"], ["json", "urllib.parse"])


class TestPayloadTransform(unittest.TestCase):
    def test_api_boundary_probes(self):
        contract = {
            "name": "payload",
            "operation": "module_zip",
            "inputs": ["inputs/case.json", "outputs/dependencies.json"],
            "output": "outputs/payload.json",
        }
        modules_payload = {
            "modules": {"main.py": "import json\n"},
            "entry": "main.py",
            "externals": ["json"],
            "aliases": {},
        }
        closure = {"paths": ["main.py"], "external": ["json"]}
        check_api_boundary("engines/payload/transform.py", rule="nonfinite_unknown_field",
                          contract_path="README.md",
                          requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                          args=[[modules_payload, closure], contract])
        check_api_boundary("engines/payload/transform.py", rule="invalid_payload_type",
                          contract_path="README.md",
                          requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                          args=[[modules_payload, closure], contract])

    def test_zip_deterministic_and_sha256(self):
        contract = {
            "name": "payload",
            "operation": "module_zip",
            "inputs": ["inputs/case.json", "outputs/dependencies.json"],
            "output": "outputs/payload.json",
        }
        modules_payload = {
            "modules": {
                "main.py": "import pkg.a\n",
                "pkg/__init__.py": "from . import b\n",
                "pkg/a.py": "from . import b\n",
                "pkg/b.py": "from . import a\n",
            },
            "entry": "main.py",
            "externals": [],
            "aliases": {},
        }
        closure = {
            "paths": ["main.py", "pkg/__init__.py", "pkg/a.py", "pkg/b.py"],
            "external": [],
        }
        result = call_candidate("engines/payload/transform.py", "transform",
                                args=[[modules_payload, closure], contract])
        r = result["result"]
        self.assertEqual(set(r), {"paths", "zip_hex", "sha256", "external"})
        self.assertEqual(r["paths"], ["__init__.py", "main.py", "pkg/__init__.py", "pkg/a.py", "pkg/b.py"])
        self.assertEqual(r["external"], [])
        self.assertEqual(len(r["sha256"]), 64)
        # Determinism: same input yields identical bytes.
        result2 = call_candidate("engines/payload/transform.py", "transform",
                                 args=[[modules_payload, closure], contract])
        self.assertEqual(result2["result"]["zip_hex"], r["zip_hex"])


if __name__ == "__main__":
    unittest.main()
