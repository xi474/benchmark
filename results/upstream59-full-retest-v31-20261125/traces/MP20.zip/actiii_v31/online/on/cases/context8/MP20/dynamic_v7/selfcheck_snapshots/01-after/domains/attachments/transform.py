import copy
import json


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count must match contract inputs")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    flags = payload.get("flags")
    if not isinstance(flags, list):
        raise ValueError("flags must be a list")
    attachments = {}
    for flag in flags:
        if not isinstance(flag, dict):
            raise ValueError("flag must be an object")
        fid = flag.get("id")
        if not isinstance(fid, str) or not fid.strip():
            raise ValueError("flag id must be a non-empty string")
        variants = flag.get("variants")
        if not isinstance(variants, list):
            raise ValueError("variants must be a list")
        inner = {}
        for variant in variants:
            if not isinstance(variant, dict):
                raise ValueError("variant must be an object")
            vid = variant.get("id")
            if not isinstance(vid, str) or not vid.strip():
                raise ValueError("variant id must be a non-empty string")
            attachment = variant.get("attachment")
            canonical = json.dumps(
                attachment,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
            inner[vid] = {"value": copy.deepcopy(attachment), "canonical": canonical}
        attachments[fid] = inner
    return {"name": contract["name"], "result": {"attachments": attachments}}
