import copy


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError('payload must be an object')
    if 'flags' not in payload or 'segments' not in payload:
        raise ValueError('missing required field')
    flags = payload['flags']
    segments = payload['segments']
    if not isinstance(flags, list) or not isinstance(segments, list):
        raise ValueError('flags and segments must be lists')

    flag_ids = set()
    for flag in flags:
        if not isinstance(flag, dict):
            raise ValueError('flag must be an object')
        if 'id' not in flag or 'variants' not in flag or 'rules' not in flag:
            raise ValueError('flag missing required field')
        fid = flag['id']
        if not isinstance(fid, str) or not fid.strip():
            raise ValueError('flag id must be non-empty string')
        if fid in flag_ids:
            raise ValueError('duplicate flag id')
        flag_ids.add(fid)

        variants = flag['variants']
        rules = flag['rules']
        if not isinstance(variants, list) or not isinstance(rules, list):
            raise ValueError('variants and rules must be lists')
        variant_ids = set()
        for variant in variants:
            if not isinstance(variant, dict):
                raise ValueError('variant must be an object')
            if 'id' not in variant or 'attachment' not in variant:
                raise ValueError('variant missing required field')
            vid = variant['id']
            if not isinstance(vid, str) or not vid.strip():
                raise ValueError('variant id must be non-empty string')
            if vid in variant_ids:
                raise ValueError('duplicate variant id')
            variant_ids.add(vid)
        rule_ids = set()
        for rule in rules:
            if not isinstance(rule, dict):
                raise ValueError('rule must be an object')
            if 'id' not in rule or 'segment' not in rule or 'variant' not in rule:
                raise ValueError('rule missing required field')
            rid = rule['id']
            if not isinstance(rid, str) or not rid.strip():
                raise ValueError('rule id must be non-empty string')
            if rid in rule_ids:
                raise ValueError('duplicate rule id')
            rule_ids.add(rid)
            if not isinstance(rule['segment'], str) or not rule['segment'].strip():
                raise ValueError('rule segment must be non-empty string')
            if not isinstance(rule['variant'], str) or not rule['variant'].strip():
                raise ValueError('rule variant must be non-empty string')

    segment_ids = set()
    for segment in segments:
        if not isinstance(segment, dict):
            raise ValueError('segment must be an object')
        if 'id' not in segment:
            raise ValueError('segment missing required field')
        sid = segment['id']
        if not isinstance(sid, str) or not sid.strip():
            raise ValueError('segment id must be non-empty string')
        if sid in segment_ids:
            raise ValueError('duplicate segment id')
        segment_ids.add(sid)

    return {
        'name': contract['name'],
        'result': {
            'flags': copy.deepcopy(flags),
            'segments': copy.deepcopy(segments),
        },
    }
