import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob('contract.json')
        if 'outputs' not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise SystemExit('no contracts found')

    # Topologically order components by input dependency on other outputs.
    outputs = {c['output'] for c in (json.loads(p.read_text(encoding='utf-8')) for p in contracts)}
    remaining = list(contracts)
    done = set()
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding='utf-8'))
            deps = [i for i in c['inputs'] if i in outputs]
            if all(d in done for d in deps):
                subprocess.run(
                    [sys.executable, str(cp.with_name('render.py'))],
                    cwd=ROOT, check=True, timeout=60,
                )
                done.add(c['output'])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise SystemExit('dependency cycle or missing dependency')

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=60)


if __name__ == '__main__':
    main()
