def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    flags = payload["flags"]
    segments = payload["segments"]

    segment_ids = {s["id"] for s in segments}

    ordered_flags = sorted(flags, key=lambda f: f["id"])
    for flag in ordered_flags:
        rules = sorted(flag["rules"], key=lambda r: r["id"])
        for rule in rules:
            target = rule["segment"]
            if target not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": flag["id"],
                            "rule": rule["id"],
                            "target": target,
                        },
                    },
                }
        variant_ids = {v["id"] for v in flag["variants"]}
        for rule in rules:
            target = rule["variant"]
            if target not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": flag["id"],
                            "rule": rule["id"],
                            "target": target,
                        },
                    },
                }

    return {"name": contract["name"], "result": {"ok": True, "error": None}}
