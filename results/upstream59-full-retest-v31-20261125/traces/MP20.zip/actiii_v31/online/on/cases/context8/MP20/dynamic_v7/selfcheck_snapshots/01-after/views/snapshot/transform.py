import copy
import json


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    original = _unwrap(payloads[0])
    schema = _unwrap(payloads[1])
    attachments = _unwrap(payloads[2])
    references = _unwrap(payloads[3])

    if not references.get('ok'):
        return {
            'name': contract['name'],
            'result': {
                'committed': False,
                'snapshot': copy.deepcopy(original.get('old_snapshot')),
                'error': copy.deepcopy(references.get('error')),
                'export': None,
            },
        }

    flags = schema['flags']
    segments = schema['segments']
    att_map = attachments['attachments']

    snapshot_flags = []
    for flag in sorted(flags, key=lambda f: f['id']):
        fid = flag['id']
        variants = []
        for variant in sorted(flag['variants'], key=lambda v: v['id']):
            vid = variant['id']
            variants.append({
                'id': vid,
                'attachment': copy.deepcopy(att_map[fid][vid]['value']),
            })
        rules = [copy.deepcopy(r) for r in sorted(flag['rules'], key=lambda r: r['id'])]
        snapshot_flags.append({'id': fid, 'variants': variants, 'rules': rules})

    snapshot_segments = [copy.deepcopy(s) for s in sorted(segments, key=lambda s: s['id'])]

    snapshot = {'flags': snapshot_flags, 'segments': snapshot_segments}
    export = json.dumps(
        snapshot,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False,
    )

    return {
        'name': contract['name'],
        'result': {
            'committed': True,
            'snapshot': snapshot,
            'error': None,
            'export': export,
        },
    }
