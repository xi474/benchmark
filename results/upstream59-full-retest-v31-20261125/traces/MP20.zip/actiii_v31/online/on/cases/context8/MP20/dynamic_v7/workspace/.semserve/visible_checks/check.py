import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/schema/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
                "args": [{"flags": [], "segments": []}, {"name": "schema", "inputs": ["x"]}],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                "args": [{"flags": [], "segments": []}, {"name": "schema", "inputs": ["x"]}],
            },
        },
    },
    {
        "target_path": "domains/attachments/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
                "args": [{"flags": [], "segments": []}, {"name": "attachments", "inputs": ["x"]}],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                "args": [{"flags": [], "segments": []}, {"name": "attachments", "inputs": ["x"]}],
            },
        },
    },
    {
        "target_path": "views/references/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
                "args": [{"flags": [], "segments": []}, {"name": "references", "inputs": ["x"]}],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                "args": [{"flags": [], "segments": []}, {"name": "references", "inputs": ["x"]}],
            },
        },
    },
    {
        "target_path": "views/snapshot/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
                "args": [
                    {"flags": [], "segments": [], "old_snapshot": {}},
                    {"flags": [], "segments": []},
                    {"attachments": {}},
                    {"ok": True, "error": None},
                    {"name": "snapshot", "inputs": ["a", "b", "c", "d"]},
                ],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                "args": [
                    {"flags": [], "segments": [], "old_snapshot": {}},
                    {"flags": [], "segments": []},
                    {"attachments": {}},
                    {"ok": True, "error": None},
                    {"name": "snapshot", "inputs": ["a", "b", "c", "d"]},
                ],
            },
        },
    },
]


class TestApiBoundaries(unittest.TestCase):
    def test_transform_api_boundaries(self):
        for entry in API_BOUNDARY_REQUIREMENTS:
            target = entry["target_path"]
            for rule, spec in entry["rules"].items():
                with self.subTest(target=target, rule=rule):
                    if not spec["applicable"]:
                        self.skipTest(spec.get("reason", "not applicable"))
                    check_api_boundary(
                        target,
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=spec["args"],
                    )


class TestReferencesBehavior(unittest.TestCase):
    def test_missing_segment_reports_first_error(self):
        payload = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "v1", "attachment": 1}],
                    "rules": [{"id": "r1", "segment": "missing", "variant": "v1"}],
                }
            ],
            "segments": [{"id": "s0"}],
        }
        contract = {"name": "references", "inputs": ["x"]}
        result = call_candidate(
            "views/references/transform.py", "transform", args=[[payload], contract]
        )
        self.assertFalse(result["result"]["ok"])
        self.assertEqual(result["result"]["error"]["kind"], "segment")
        self.assertEqual(result["result"]["error"]["flag"], "f1")
        self.assertEqual(result["result"]["error"]["rule"], "r1")
        self.assertEqual(result["result"]["error"]["target"], "missing")

    def test_missing_variant_reports_after_segments_valid(self):
        payload = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "v1", "attachment": 1}],
                    "rules": [{"id": "r1", "segment": "s0", "variant": "missing"}],
                }
            ],
            "segments": [{"id": "s0"}],
        }
        contract = {"name": "references", "inputs": ["x"]}
        result = call_candidate(
            "views/references/transform.py", "transform", args=[[payload], contract]
        )
        self.assertFalse(result["result"]["ok"])
        self.assertEqual(result["result"]["error"]["kind"], "variant")
        self.assertEqual(result["result"]["error"]["target"], "missing")


class TestSnapshotBehavior(unittest.TestCase):
    def test_snapshot_commits_and_exports(self):
        original = {"flags": [], "segments": [], "old_snapshot": {"version": 1}}
        schema = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "v1", "attachment": {"a": 1}}],
                    "rules": [{"id": "r1", "segment": "s0", "variant": "v1"}],
                }
            ],
            "segments": [{"id": "s0"}],
        }
        attachments = {"attachments": {"f1": {"v1": {"value": {"a": 1}, "canonical": "x"}}}}
        references = {"ok": True, "error": None}
        contract = {"name": "snapshot", "inputs": ["a", "b", "c", "d"]}
        result = call_candidate(
            "views/snapshot/transform.py",
            "transform",
            args=[[original, schema, attachments, references], contract],
        )
        r = result["result"]
        self.assertTrue(r["committed"])
        self.assertIsNone(r["error"])
        self.assertEqual(r["snapshot"]["flags"][0]["variants"][0]["attachment"], {"a": 1})
        self.assertIsInstance(r["export"], str)

    def test_snapshot_rolls_back_on_reference_failure(self):
        original = {"flags": [], "segments": [], "old_snapshot": {"version": 7}}
        schema = {"flags": [], "segments": []}
        attachments = {"attachments": {}}
        references = {"ok": False, "error": {"kind": "segment", "flag": "f", "rule": "r", "target": "t"}}
        contract = {"name": "snapshot", "inputs": ["a", "b", "c", "d"]}
        result = call_candidate(
            "views/snapshot/transform.py",
            "transform",
            args=[[original, schema, attachments, references], contract],
        )
        r = result["result"]
        self.assertFalse(r["committed"])
        self.assertEqual(r["snapshot"], {"version": 7})
        self.assertEqual(r["error"]["kind"], "segment")
        self.assertIsNone(r["export"])


if __name__ == "__main__":
    unittest.main()
