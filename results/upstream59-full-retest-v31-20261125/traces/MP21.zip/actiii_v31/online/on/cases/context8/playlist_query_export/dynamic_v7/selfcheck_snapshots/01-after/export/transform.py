from decimal import Decimal, ROUND_HALF_UP


def _require_str(value, field):
    if not isinstance(value, str):
        raise ValueError(f"{field} must be str")
    return value


def _require_finite_number(value, field):
    if isinstance(value, bool):
        raise ValueError(f"{field} must be a finite number")
    if not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a finite number")
    if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
        raise ValueError(f"{field} must be a finite number")
    return value


def transform(payloads, contract):
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("invalid arguments")
    inputs = contract.get("inputs")
    if not isinstance(inputs, list) or len(payloads) != len(inputs):
        raise ValueError("payload count mismatch")
    if len(payloads) != 1:
        raise ValueError("export expects exactly one input")

    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")

    playlist = data.get("playlist")
    tracks = data.get("tracks")
    if not isinstance(playlist, dict):
        raise ValueError("playlist must be an object")
    if not isinstance(tracks, list):
        raise ValueError("tracks must be a list")

    name = _require_str(playlist.get("name"), "playlist.name")
    if "\r" in name or "\n" in name:
        raise ValueError("playlist.name must not contain CR/LF")

    track_ids = playlist.get("track_ids")
    if not isinstance(track_ids, list):
        raise ValueError("track_ids must be a list")

    by_id = {}
    for track in tracks:
        if not isinstance(track, dict):
            raise ValueError("track must be an object")
        tid = track.get("id")
        if not isinstance(tid, str):
            raise ValueError("track.id must be str")
        by_id[tid] = track

    lines = ["#EXTM3U", "#PLAYLIST:" + name]
    for tid in track_ids:
        track = by_id.get(tid)
        if track is None:
            raise ValueError("unknown track id")
        duration = _require_finite_number(track.get("duration"), "track.duration")
        if duration < 0:
            raise ValueError("duration must be non-negative")
        artist = _require_str(track.get("artist"), "track.artist")
        title = _require_str(track.get("title"), "track.title")
        path = _require_str(track.get("path"), "track.path")
        if "\r" in artist or "\n" in artist or "\r" in title or "\n" in title or "\r" in path or "\n" in path:
            raise ValueError("CR/LF not allowed in M3U lines")
        seconds = int(Decimal(str(duration)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        lines.append("#EXTINF:%d,%s - %s" % (seconds, artist, title))
        lines.append(path)

    return {"name": contract["name"], "result": {"m3u": "\n".join(lines) + "\n"}}
