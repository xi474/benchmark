import math


def _is_bool(v):
    return isinstance(v, bool)


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _unwrap(payload):
    # When input object keys are exactly name/result, only result is business input.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(contract, dict):
        raise ValueError("contract must be object")
    name = contract.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("contract name required")
    inputs = contract.get("inputs")
    if not isinstance(inputs, list):
        raise ValueError("contract inputs required")
    if len(payloads) != len(inputs):
        raise ValueError("payload count mismatch")

    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    tracks = data.get("tracks")
    playlist = data.get("playlist")
    replacement = data.get("replacement")

    if not isinstance(tracks, list):
        raise ValueError("tracks required")
    if not isinstance(playlist, dict):
        raise ValueError("playlist required")
    if not isinstance(replacement, list):
        raise ValueError("replacement required")

    # Build track map; ids must be unique.
    track_map = {}
    for t in tracks:
        if not isinstance(t, dict):
            raise ValueError("track must be object")
        tid = t.get("id")
        if not isinstance(tid, str):
            raise ValueError("track id required")
        if tid in track_map:
            raise ValueError("duplicate track id")
        for field in ("title", "artist", "path"):
            v = t.get(field)
            if not isinstance(v, str):
                raise ValueError("track %s required" % field)
            if "\r" in v or "\n" in v:
                raise ValueError("CR/LF not allowed")
        dur = t.get("duration")
        if not _is_finite_number(dur) or dur < 0:
            raise ValueError("duration must be non-negative finite number")
        track_map[tid] = t

    # Validate playlist fields.
    pid = playlist.get("id")
    if not isinstance(pid, str):
        raise ValueError("playlist id required")
    pname = playlist.get("name")
    if not isinstance(pname, str):
        raise ValueError("playlist name required")
    if "\r" in pname or "\n" in pname:
        raise ValueError("CR/LF not allowed in name")
    track_ids = playlist.get("track_ids")
    if not isinstance(track_ids, list):
        raise ValueError("track_ids required")
    # track_count and duration may be stale; validate types only if present.
    if "track_count" in playlist and not _is_int(playlist["track_count"]):
        raise ValueError("track_count must be int")
    if "duration" in playlist and not _is_finite_number(playlist["duration"]):
        raise ValueError("duration must be finite number")

    # Resolve replacement ids.
    new_tracks = []
    new_duration = 0.0
    for rid in replacement:
        if not isinstance(rid, str):
            raise ValueError("replacement id must be str")
        if rid not in track_map:
            raise ValueError("unknown replacement id")
        t = track_map[rid]
        new_tracks.append(t)
        new_duration += t["duration"]

    result = {
        "playlist": {
            "id": pid,
            "name": pname,
            "track_ids": list(replacement),
            "track_count": len(replacement),
            "duration": new_duration,
        },
        "tracks": new_tracks,
    }
    return {"name": name, "result": result}
