import math

_FIELDS = ("id", "name", "track_count", "duration")
_STR_OPS = ("eq", "ne")
_NUM_OPS = ("eq", "ne", "gt", "ge", "lt", "le")


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("bad arguments")
    if "inputs" not in contract or not isinstance(contract["inputs"], list):
        raise ValueError("contract missing inputs")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    if "criteria" not in data or not isinstance(data["criteria"], dict):
        raise ValueError("missing criteria")
    criteria = data["criteria"]

    if "filters" not in criteria or not isinstance(criteria["filters"], list):
        raise ValueError("missing filters")
    filters = criteria["filters"]

    if "limit" not in criteria:
        raise ValueError("missing limit")
    limit = criteria["limit"]
    if isinstance(limit, bool) or not isinstance(limit, int):
        raise ValueError("limit must be int")
    if limit < 1 or limit > 100:
        raise ValueError("limit out of range")

    sql = "SELECT id FROM playlists"
    params = []
    where_parts = []
    for f in filters:
        if not isinstance(f, dict):
            raise ValueError("filter must be object")
        if "field" not in f or "op" not in f or "value" not in f:
            raise ValueError("filter missing field")
        field = f["field"]
        op = f["op"]
        value = f["value"]
        if field not in _FIELDS:
            raise ValueError("unknown field")
        if field in ("id", "name"):
            if not isinstance(value, str):
                raise ValueError("id/name value must be str")
            if op not in _STR_OPS:
                raise ValueError("id/name only eq/ne")
        else:
            if not _is_finite_number(value):
                raise ValueError("stat field value must be non-negative finite number")
            if value < 0:
                raise ValueError("stat field value must be non-negative")
            if op not in _NUM_OPS:
                raise ValueError("bad op")
        where_parts.append(f"{field} {op} ?")
        params.append(value)

    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)

    return {"name": contract["name"], "result": {"sql": sql, "params": params}}
