import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "playlist/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "query/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "export/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestAPIBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target,
                            rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"bad": "seed"}], {"name": "x", "inputs": ["x"], "output": "y"}],
                        )
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target,
                            rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"extra": 1}], {"name": "x", "inputs": ["x"], "output": "y"}],
                        )


class TestPlaylistReplace(unittest.TestCase):
    def test_replace_recomputes_stats(self):
        payload = {
            "tracks": [
                {"id": "a", "title": "T", "artist": "A", "path": "p.mp3", "duration": 1.5},
                {"id": "b", "title": "U", "artist": "B", "path": "q.mp3", "duration": 2.5},
            ],
            "playlist": {"id": "p", "name": "Mix", "track_ids": ["a"], "track_count": 99, "duration": 999},
            "replacement": ["b", "a", "b"],
        }
        contract = {"name": "playlist", "operation": "playlist_replace", "inputs": ["x"], "output": "y"}
        result = call_candidate("playlist/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "playlist")
        r = result["result"]
        self.assertEqual(r["playlist"]["track_ids"], ["b", "a", "b"])
        self.assertEqual(r["playlist"]["track_count"], 3)
        self.assertEqual(r["playlist"]["duration"], 6.5)
        self.assertEqual([t["id"] for t in r["tracks"]], ["b", "a", "b"])

    def test_unknown_replacement_id_raises(self):
        payload = {
            "tracks": [{"id": "a", "title": "T", "artist": "A", "path": "p.mp3", "duration": 1.0}],
            "playlist": {"id": "p", "name": "Mix", "track_ids": ["a"], "track_count": 1, "duration": 1.0},
            "replacement": ["zzz"],
        }
        contract = {"name": "playlist", "operation": "playlist_replace", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("playlist/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestPlaylistQuery(unittest.TestCase):
    def test_query_sql_and_params(self):
        payload = {
            "criteria": {
                "filters": [
                    {"field": "track_count", "op": "ge", "value": 2},
                    {"field": "name", "op": "ne", "value": "O'Reilly"},
                ],
                "limit": 10,
            }
        }
        contract = {"name": "query", "operation": "playlist_query", "inputs": ["x"], "output": "y"}
        result = call_candidate("query/transform.py", "transform", args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["sql"], "SELECT id FROM playlists WHERE track_count ge ? AND name ne ? ORDER BY id LIMIT ?")
        self.assertEqual(r["params"], [2, "O'Reilly", 10])

    def test_empty_filters(self):
        payload = {"criteria": {"filters": [], "limit": 5}}
        contract = {"name": "query", "operation": "playlist_query", "inputs": ["x"], "output": "y"}
        result = call_candidate("query/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["sql"], "SELECT id FROM playlists ORDER BY id LIMIT ?")
        self.assertEqual(result["result"]["params"], [5])

    def test_id_gt_rejected(self):
        payload = {"criteria": {"filters": [{"field": "id", "op": "gt", "value": "x"}], "limit": 5}}
        contract = {"name": "query", "operation": "playlist_query", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("query/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestPlaylistM3U(unittest.TestCase):
    def test_m3u_round_half_up(self):
        payload = {
            "playlist": {"id": "p", "name": "Mix", "track_ids": ["a", "b"], "track_count": 2, "duration": 4.0},
            "tracks": [
                {"id": "a", "title": "T", "artist": "A", "path": "p.mp3", "duration": 2.5},
                {"id": "b", "title": "U", "artist": "B", "path": "q.mp3", "duration": 0.5},
            ],
        }
        contract = {"name": "export", "operation": "playlist_m3u", "inputs": ["x"], "output": "y"}
        result = call_candidate("export/transform.py", "transform", args=[[payload], contract])
        m3u = result["result"]["m3u"]
        self.assertEqual(
            m3u,
            "#EXTM3U\n#PLAYLIST:Mix\n#EXTINF:3,A - T\np.mp3\n#EXTINF:1,B - U\nq.mp3\n",
        )

    def test_empty_playlist_keeps_header(self):
        payload = {"playlist": {"id": "p", "name": "Mix", "track_ids": [], "track_count": 0, "duration": 0}, "tracks": []}
        contract = {"name": "export", "operation": "playlist_m3u", "inputs": ["x"], "output": "y"}
        result = call_candidate("export/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["m3u"], "#EXTM3U\n#PLAYLIST:Mix\n")


if __name__ == "__main__":
    unittest.main()
