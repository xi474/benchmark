import re
import xml.etree.ElementTree as ET


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _local(tag):
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag


def _parse_xml(xml_text):
    if "DOCTYPE" in xml_text or "ENTITY" in xml_text:
        raise ValueError("DOCTYPE/ENTITY forbidden")
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        raise ValueError("bad XML") from e
    return root


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    xml_text = data.get("xml")
    language_codes = data.get("language_codes")
    if not isinstance(xml_text, str):
        raise ValueError("xml must be string")
    if not isinstance(language_codes, list):
        raise ValueError("language_codes must be list")
    for code in language_codes:
        if not isinstance(code, str) or len(code) != 3 or not code.islower() or not code.isalpha():
            raise ValueError("invalid language code")

    root = _parse_xml(xml_text)
    rname = _local(root.tag)
    if rname not in ("collection", "record"):
        raise ValueError("root must be collection or record")

    records = []
    if rname == "record":
        record_elems = [root]
    else:
        record_elems = list(root)

    seen_ids = set()
    for rec in record_elems:
        if _local(rec.tag) != "record":
            raise ValueError("unknown element in collection")
        controls = {}
        fields = []
        rec_id = None
        for child in rec:
            cname = _local(child.tag)
            if cname == "controlfield":
                tag = child.get("tag")
                if tag is None or not re.fullmatch(r"\d{3}", tag):
                    raise ValueError("bad controlfield tag")
                if tag in controls:
                    raise ValueError("duplicate controlfield tag")
                text = child.text or ""
                controls[tag] = text
                if tag == "001":
                    if text.strip() == "":
                        raise ValueError("empty record id")
                    rec_id = text
            elif cname == "datafield":
                tag = child.get("tag")
                if tag is None or not re.fullmatch(r"\d{3}", tag):
                    raise ValueError("bad datafield tag")
                subfields = []
                for sf in child:
                    if _local(sf.tag) != "subfield":
                        raise ValueError("unknown element in datafield")
                    code = sf.get("code")
                    if code is None or not re.fullmatch(r"[A-Za-z0-9]", code):
                        raise ValueError("bad subfield code")
                    subfields.append({"code": code, "value": sf.text or ""})
                fields.append({"tag": tag, "subfields": subfields})
            else:
                raise ValueError("unknown XML element")
        if rec_id is None:
            raise ValueError("missing 001 controlfield")
        if rec_id in seen_ids:
            raise ValueError("duplicate record id")
        seen_ids.add(rec_id)
        records.append({"id": rec_id, "controls": controls, "fields": fields})

    records.sort(key=lambda r: r["id"])
    return {"name": contract["name"], "result": {"records": records}}
