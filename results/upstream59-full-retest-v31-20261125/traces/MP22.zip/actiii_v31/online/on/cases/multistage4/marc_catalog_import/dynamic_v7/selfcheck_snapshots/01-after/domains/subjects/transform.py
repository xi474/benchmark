def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _clean(text):
    parts = text.split()
    s = " ".join(parts)
    s = s.strip()
    while s and s[0] in " /,:;":
        s = s[1:]
    while s and s[-1] in " /,:;":
        s = s[:-1]
    return s


def _join(field, codes):
    vals = []
    for sf in field.get("subfields", []):
        if sf.get("code") in codes:
            vals.append(sf.get("value", ""))
    return "".join(vals)


CATEGORIES = {
    "600": "people",
    "610": "organizations",
    "611": "meetings",
    "630": "works",
    "650": "topics",
    "651": "places",
}


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict) or "records" not in data:
        raise ValueError("bad input")
    records = data["records"]

    out_records = []
    for rec in records:
        rid = rec["id"]
        counts = {k: {} for k in ("people", "organizations", "meetings", "works", "topics", "places")}
        for field in rec.get("fields", []):
            tag = field["tag"]
            if tag not in CATEGORIES:
                continue
            cat = CATEGORIES[tag]
            main = _clean(_join(field, ("a", "b")))
            subdivisions = []
            for sf in field.get("subfields", []):
                if sf.get("code") in ("v", "x", "y", "z"):
                    seg = _clean(sf.get("value", ""))
                    if seg:
                        subdivisions.append(seg)
            full = main
            if subdivisions:
                full = main + " -- " + " -- ".join(subdivisions)
            if full:
                counts[cat][full] = counts[cat].get(full, 0) + 1

        subjects = {}
        for cat in ("people", "organizations", "meetings", "works", "topics", "places"):
            items = [{"value": v, "count": c} for v, c in sorted(counts[cat].items())]
            subjects[cat] = items
        out_records.append({"id": rid, "subjects": subjects})

    return {"name": contract["name"], "result": {"records": out_records}}
