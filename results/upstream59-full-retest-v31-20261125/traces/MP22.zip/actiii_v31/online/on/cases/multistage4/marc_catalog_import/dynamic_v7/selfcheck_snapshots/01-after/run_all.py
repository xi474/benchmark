import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts")

    # Topological order by input dependency.
    produced = set()
    remaining = list(contracts)
    order = []
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [p for p in c["inputs"] if p.startswith("outputs/")]
            if all(d in produced for d in deps):
                order.append(cp)
                produced.add(c["output"])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise ValueError("dependency cycle or missing dependency")

    for cp in order:
        subprocess.run(
            [sys.executable, str(cp.with_name("render.py"))],
            cwd=ROOT,
            check=True,
        )

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
    )

    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
