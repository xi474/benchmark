def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    names = _unwrap(payloads[0])
    langs = _unwrap(payloads[1])
    subjects = _unwrap(payloads[2])

    def ids_of(data):
        recs = data["records"]
        ids = [r["id"] for r in recs]
        if len(set(ids)) != len(ids):
            raise ValueError("duplicate record id")
        return ids

    n_ids = ids_of(names)
    l_ids = ids_of(langs)
    s_ids = ids_of(subjects)
    if set(n_ids) != set(l_ids) or set(n_ids) != set(s_ids):
        raise ValueError("record id sets differ")

    n_map = {r["id"]: r for r in names["records"]}
    l_map = {r["id"]: r for r in langs["records"]}
    s_map = {r["id"]: r for r in subjects["records"]}

    records = []
    for rid in n_ids:
        records.append({
            "id": rid,
            "authors": n_map[rid]["authors"],
            "titles": n_map[rid]["titles"],
            "languages": l_map[rid]["languages"],
            "subjects": s_map[rid]["subjects"],
        })

    return {
        "name": contract["name"],
        "result": {"records": records, "record_count": len(records)},
    }
