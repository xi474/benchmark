import unittest

# Injected by the visible-contract-check SDK runner.
# call_candidate, check_api_boundary, CandidateCallError are injected at runtime.


README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/reader/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/names/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/languages/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/subjects/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/catalog/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestReaderTransform(unittest.TestCase):
    def test_reader_output_shape(self):
        payloads = [{"xml": "<collection xmlns=\"http://www.loc.gov/MARC21/slim\"><record><controlfield tag=\"001\">r1</controlfield></record></collection>", "language_codes": ["eng"]}]
        contract = {"name": "reader", "operation": "marc_xml_records", "inputs": ["inputs/case.json"], "output": "outputs/reader.json"}
        result = call_candidate("domains/reader/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(set(result), {"name", "result"})
        self.assertEqual(result["name"], "reader")
        self.assertEqual(list(result["result"]), ["records"])
        self.assertEqual(result["result"]["records"], [{"id": "r1", "controls": {"001": "r1"}, "fields": []}])

    def test_reader_duplicate_id_raises(self):
        xml = "<collection><record><controlfield tag=\"001\">r1</controlfield></record><record><controlfield tag=\"001\">r1</controlfield></record></collection>"
        payloads = [{"xml": xml, "language_codes": ["eng"]}]
        contract = {"name": "reader", "operation": "marc_xml_records", "inputs": ["inputs/case.json"], "output": "outputs/reader.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/reader/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestLanguagesTransform(unittest.TestCase):
    def test_languages_041_split(self):
        raw = {"language_codes": ["eng", "ger", "lat"]}
        reader = {"records": [{"id": "r1", "controls": {}, "fields": [{"tag": "041", "subfields": [{"code": "a", "value": "gerlat"}]}]}]}
        payloads = [raw, reader]
        contract = {"name": "languages", "operation": "marc_languages", "inputs": ["inputs/case.json", "outputs/reader.json"], "output": "outputs/languages.json"}
        result = call_candidate("domains/languages/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(result["result"]["records"], [{"id": "r1", "languages": ["ger", "lat"]}])

    def test_languages_041_bad_length_raises(self):
        raw = {"language_codes": ["eng"]}
        reader = {"records": [{"id": "r1", "controls": {}, "fields": [{"tag": "041", "subfields": [{"code": "a", "value": "engx"}]}]}]}
        payloads = [raw, reader]
        contract = {"name": "languages", "operation": "marc_languages", "inputs": ["inputs/case.json", "outputs/reader.json"], "output": "outputs/languages.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/languages/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestSubjectsTransform(unittest.TestCase):
    def test_subjects_count(self):
        reader = {"records": [{"id": "r1", "controls": {}, "fields": [
            {"tag": "610", "subfields": [{"code": "a", "value": "Jesuits."}, {"code": "b", "value": "Dept."}]},
            {"tag": "610", "subfields": [{"code": "a", "value": "Jesuits."}, {"code": "b", "value": "Dept."}]},
        ]}]}
        payloads = [reader]
        contract = {"name": "subjects", "operation": "marc_subjects", "inputs": ["outputs/reader.json"], "output": "outputs/subjects.json"}
        result = call_candidate("domains/subjects/transform.py", "transform", args=[payloads, contract])
        orgs = result["result"]["records"][0]["subjects"]["organizations"]
        self.assertEqual(orgs, [{"value": "Jesuits.Dept.", "count": 2}])
        for cat in ("people", "meetings", "works", "topics", "places"):
            self.assertEqual(result["result"]["records"][0]["subjects"][cat], [])


class TestCatalogTransform(unittest.TestCase):
    def test_catalog_join(self):
        names = {"records": [{"id": "r1", "authors": [], "titles": []}]}
        langs = {"records": [{"id": "r1", "languages": ["eng"]}]}
        subjects = {"records": [{"id": "r1", "subjects": {}}]}
        payloads = [names, langs, subjects]
        contract = {"name": "catalog", "operation": "marc_catalog", "inputs": ["outputs/names.json", "outputs/languages.json", "outputs/subjects.json"], "output": "outputs/catalog.json"}
        result = call_candidate("views/catalog/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(result["result"]["record_count"], 1)
        self.assertEqual(result["result"]["records"][0]["languages"], ["eng"])

    def test_catalog_id_mismatch_raises(self):
        names = {"records": [{"id": "r1", "authors": [], "titles": []}]}
        langs = {"records": [{"id": "r2", "languages": ["eng"]}]}
        subjects = {"records": [{"id": "r1", "subjects": {}}]}
        payloads = [names, langs, subjects]
        contract = {"name": "catalog", "operation": "marc_catalog", "inputs": ["outputs/names.json", "outputs/languages.json", "outputs/subjects.json"], "output": "outputs/catalog.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("views/catalog/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestAPIBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        reader_payloads = [{"xml": "<collection><record><controlfield tag=\"001\">r1</controlfield></record></collection>", "language_codes": ["eng"]}]
        reader_contract = {"name": "reader", "operation": "marc_xml_records", "inputs": ["inputs/case.json"], "output": "outputs/reader.json"}
        names_payloads = [{"records": [{"id": "r1", "controls": {}, "fields": []}]}]
        names_contract = {"name": "names", "operation": "marc_names_titles", "inputs": ["outputs/reader.json"], "output": "outputs/names.json"}
        langs_payloads = [{"language_codes": ["eng"]}, {"records": [{"id": "r1", "controls": {}, "fields": []}]}]
        langs_contract = {"name": "languages", "operation": "marc_languages", "inputs": ["inputs/case.json", "outputs/reader.json"], "output": "outputs/languages.json"}
        subjects_payloads = [{"records": [{"id": "r1", "controls": {}, "fields": []}]}]
        subjects_contract = {"name": "subjects", "operation": "marc_subjects", "inputs": ["outputs/reader.json"], "output": "outputs/subjects.json"}
        catalog_payloads = [{"records": [{"id": "r1", "authors": [], "titles": []}]}, {"records": [{"id": "r1", "languages": []}]}, {"records": [{"id": "r1", "subjects": {}}]}]
        catalog_contract = {"name": "catalog", "operation": "marc_catalog", "inputs": ["outputs/names.json", "outputs/languages.json", "outputs/subjects.json"], "output": "outputs/catalog.json"}

        probes = [
            ("domains/reader/transform.py", reader_payloads, reader_contract),
            ("domains/names/transform.py", names_payloads, names_contract),
            ("domains/languages/transform.py", langs_payloads, langs_contract),
            ("domains/subjects/transform.py", subjects_payloads, subjects_contract),
            ("views/catalog/transform.py", catalog_payloads, catalog_contract),
        ]
        for target, payloads, contract in probes:
            with self.subTest(target=target, rule="nonfinite_unknown_field"):
                check_api_boundary(target, rule="nonfinite_unknown_field", contract_path="README.md", requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。", args=[payloads, contract])
            with self.subTest(target=target, rule="invalid_payload_type"):
                check_api_boundary(target, rule="invalid_payload_type", contract_path="README.md", requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。", args=[payloads, contract])


if __name__ == "__main__":
    unittest.main()
