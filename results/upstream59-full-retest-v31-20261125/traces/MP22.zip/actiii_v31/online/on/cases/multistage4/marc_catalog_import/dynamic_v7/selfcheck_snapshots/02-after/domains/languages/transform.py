import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _reject_nonfinite(payloads)
    for p in payloads:
        if not isinstance(p, (dict, list)):
            raise ValueError("payload must be object or array")

    raw_input = _unwrap(payloads[0])
    reader_result = _unwrap(payloads[1])

    language_codes = raw_input["language_codes"]
    valid = set()
    for code in language_codes:
        if not isinstance(code, str) or len(code) != 3 or not code.isalpha() or not code.islower():
            raise ValueError("invalid language code")
        valid.add(code)

    records = reader_result["records"]
    out_records = []
    for rec in records:
        rid = rec["id"]
        codes = set()
        controls = rec.get("controls", {})
        if "008" in controls:
            c008 = controls["008"]
            if len(c008) >= 38:
                code = c008[35:38]
                if code in valid:
                    codes.add(code)
        for field in rec.get("fields", []):
            if field["tag"] == "041":
                for sub in field["subfields"]:
                    if sub["code"] in ("a", "d", "h"):
                        s = sub["value"].strip()
                        if len(s) % 3 != 0:
                            raise ValueError("041 code length not multiple of 3")
                        for i in range(0, len(s), 3):
                            code = s[i:i + 3]
                            if code in valid:
                                codes.add(code)
        out_records.append({"id": rid, "languages": sorted(codes)})

    return {"name": contract["name"], "result": {"records": out_records}}
