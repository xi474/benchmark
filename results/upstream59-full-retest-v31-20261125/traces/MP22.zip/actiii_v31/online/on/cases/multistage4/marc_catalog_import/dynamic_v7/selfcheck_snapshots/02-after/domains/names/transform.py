import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _clean(text):
    # collapse intra-word whitespace, strip leading/trailing
    # spaces, slashes, commas, colons, semicolons; keep periods.
    parts = text.split()
    s = " ".join(parts)
    s = s.strip()
    while s and s[0] in " /,:;":
        s = s[1:]
    while s and s[-1] in " /,:;":
        s = s[:-1]
    return s


def _join_subfields(field, codes):
    vals = []
    for sf in field.get("subfields", []):
        if sf.get("code") in codes:
            vals.append(sf.get("value", ""))
    return "".join(vals)


def _link_key(sf6):
    # returns (tag, nn) if $6 matches TAG-NN[/suffix]
    if not isinstance(sf6, str):
        return None
    s = sf6.strip()
    if "-" not in s:
        return None
    tag, _, rest = s.partition("-")
    nn = rest.split("/", 1)[0]
    if not tag or not nn:
        return None
    return tag, nn


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _reject_nonfinite(payloads)
    data = _unwrap(payloads[0])
    if not isinstance(data, dict) or "records" not in data:
        raise ValueError("bad input")
    records = data["records"]

    out_records = []
    for rec in records:
        rid = rec["id"]
        fields = rec.get("fields", [])

        # index fields by tag
        by_tag = {}
        for f in fields:
            by_tag.setdefault(f["tag"], []).append(f)

        # build 880 link map: 880 $6 -> (tag, nn)
        link_map = {}
        for f in by_tag.get("880", []):
            for sf in f.get("subfields", []):
                if sf.get("code") == "6":
                    key = _link_key(sf.get("value"))
                    if key is not None:
                        link_map.setdefault(key, []).append(f)

        def alternates_for(tag, field):
            alts = []
            for sf in field.get("subfields", []):
                if sf.get("code") == "6":
                    key = _link_key(sf.get("value"))
                    if key is None:
                        continue
                    # 100/245 $6 must be 880-NN
                    if key[0] != "880":
                        continue
                    nn = key[1]
                    for lf in link_map.get((tag, nn), []):
                        alt = _clean(_join_subfields(lf, ("a", "b")))
                        if alt:
                            alts.append(alt)
            return sorted(set(alts))

        authors = []
        for f in by_tag.get("100", []):
            name = _clean(_join_subfields(f, ("a", "b")))
            if not name:
                continue
            authors.append({"name": name, "alternates": alternates_for("100", f)})

        titles = []
        for f in by_tag.get("245", []):
            title = _clean(_join_subfields(f, ("a", "b")))
            if not title:
                continue
            titles.append({"title": title, "alternates": alternates_for("245", f)})

        out_records.append({"id": rid, "authors": authors, "titles": titles})

    return {"name": contract["name"], "result": {"records": out_records}}
