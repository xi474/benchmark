import json


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _unwrap(p):
    if isinstance(p, dict) and set(p) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    original = _unwrap(payloads[0])
    chunks = _unwrap(payloads[1])

    if not isinstance(original, dict):
        raise ValueError("original input must be object")
    if not isinstance(chunks, dict):
        raise ValueError("chunks input must be object")

    max_file_bytes = original.get("max_file_bytes")
    max_entries = original.get("max_entries")
    if not _is_int(max_file_bytes) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not _is_int(max_entries) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    data_chunks = chunks.get("chunks")
    manifest = chunks.get("manifest")
    if not isinstance(data_chunks, list):
        raise ValueError("chunks must be a list")
    if not isinstance(manifest, dict):
        raise ValueError("manifest must be an object")

    # Serialize manifest as compact canonical JSON.
    manifest_bytes = json.dumps(
        manifest, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")

    # Metadata blocks named m000000.bin onward.
    meta_blocks = []
    for i in range(0, len(manifest_bytes), max_file_bytes):
        piece = manifest_bytes[i:i + max_file_bytes]
        meta_blocks.append({
            "name": "m%06d.bin" % (i // max_file_bytes),
            "hex": piece.hex(),
        })

    # Combine data and metadata blocks, sort by name.
    blocks = []
    for c in data_chunks:
        if not isinstance(c, dict) or "name" not in c or "hex" not in c:
            raise ValueError("invalid chunk entry")
        blocks.append({"name": c["name"], "hex": c["hex"]})
    blocks.extend(meta_blocks)
    blocks.sort(key=lambda b: b["name"])

    n = len(blocks)
    h = 1
    while max_entries ** h < n:
        h += 1

    tree = []
    for idx, b in enumerate(blocks):
        digits = []
        for j in range(h):
            digits.append((idx // (max_entries ** (h - 1 - j))) % max_entries)
        dirs = ["n%d" % d for d in digits[:-1]]
        path = "/".join(dirs + [b["name"]]) if dirs else b["name"]
        tree.append({"path": path, "hex": b["hex"]})

    tree.sort(key=lambda t: t["path"])

    return {
        "name": contract["name"],
        "result": {
            "tree": tree,
            "max_entries": max_entries,
            "max_file_bytes": max_file_bytes,
        },
    }
