import hashlib
import json
import re


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and \
        (isinstance(v, int) or (v == v and v not in (float('inf'), float('-inf'))))


def _safe_path(p):
    if not isinstance(p, str):
        raise ValueError("path must be string")
    if p == "":
        raise ValueError("empty path")
    if p.startswith("/") or "\\" in p or ":" in p:
        raise ValueError("unsafe path")
    parts = p.split("/")
    for seg in parts:
        if seg in ("", ".", ".."):
            raise ValueError("unsafe path segment")
    return parts


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    layout = payloads[0]
    if isinstance(layout, dict) and set(layout) == {"name", "result"}:
        layout = layout["result"]
    if not isinstance(layout, dict):
        raise ValueError("layout must be object")

    tree = layout.get("tree")
    max_entries = layout.get("max_entries")
    max_file_bytes = layout.get("max_file_bytes")
    if not isinstance(tree, list):
        raise ValueError("tree must be list")
    if not _is_int(max_entries) or max_entries < 2:
        raise ValueError("max_entries invalid")
    if not _is_int(max_file_bytes) or max_file_bytes < 16:
        raise ValueError("max_file_bytes invalid")

    # Build directory structure from paths.
    # Each entry: {path, hex}
    entries = []
    seen_basename = {}
    dirs = set()
    for item in tree:
        if not isinstance(item, dict):
            raise ValueError("tree item must be object")
        p = item.get("path")
        h = item.get("hex")
        if not isinstance(p, str) or not isinstance(h, str):
            raise ValueError("tree item fields invalid")
        parts = _safe_path(p)
        basename = parts[-1]
        if basename in seen_basename:
            raise ValueError("duplicate basename")
        seen_basename[basename] = p
        # validate hex
        try:
            raw = bytes.fromhex(h)
        except ValueError:
            raise ValueError("invalid hex")
        if len(raw) > max_file_bytes:
            raise ValueError("file exceeds max_file_bytes")
        entries.append((p, parts, h, raw))
        # record all ancestor dirs
        for i in range(1, len(parts)):
            dirs.add("/".join(parts[:i]))

    # Check no file/dir name collision: a path that is a dir cannot also be a file.
    file_paths = set(p for p, _, _, _ in entries)
    for d in dirs:
        if d in file_paths:
            raise ValueError("file/dir name collision")

    # Check per-directory direct entries (files + subdirs) <= max_entries.
    # Direct children of a directory = files whose parent is that dir + subdirs.
    from collections import defaultdict
    direct = defaultdict(set)
    for p, parts, _, _ in entries:
        parent = "/".join(parts[:-1])
        direct[parent].add(parts[-1])
    for d in dirs:
        parent = "/".join(d.split("/")[:-1])
        direct[parent].add(d.split("/")[-1])
    for parent, children in direct.items():
        if len(children) > max_entries:
            raise ValueError("directory exceeds max_entries")

    # Validate basenames: m<digits>.bin or d<digits>.bin
    m_blocks = {}
    d_blocks = {}
    for p, parts, h, raw in entries:
        bn = parts[-1]
        m = re.fullmatch(r"m([0-9]+)\.bin", bn)
        d = re.fullmatch(r"d([0-9]+)\.bin", bn)
        if m:
            num = int(m.group(1))
            m_blocks[num] = raw
        elif d:
            num = int(d.group(1))
            d_blocks[num] = raw
        else:
            raise ValueError("invalid basename")

    # m blocks numbered 000000 consecutively (i.e., 0..N-1).
    if m_blocks:
        nums = sorted(m_blocks)
        if nums != list(range(len(nums))):
            raise ValueError("m blocks not consecutive")
    manifest_bytes = b"".join(m_blocks[n] for n in sorted(m_blocks))
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
    except Exception:
        raise ValueError("invalid manifest")

    if not isinstance(manifest, dict) or "files" not in manifest:
        raise ValueError("manifest missing files")
    files = manifest["files"]
    if not isinstance(files, list):
        raise ValueError("manifest files must be list")

    # Restore files in manifest.files order.
    used_d = set()
    result_files = []
    total_bytes = 0
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("manifest file entry invalid")
        path = f.get("path")
        size = f.get("size")
        sha = f.get("sha256")
        parts_list = f.get("parts")
        if not isinstance(path, str) or not _is_int(size) or size < 0 \
                or not isinstance(sha, str) or not isinstance(parts_list, list):
            raise ValueError("manifest file fields invalid")
        _safe_path(path)
        data = b""
        for pn in parts_list:
            if not isinstance(pn, str):
                raise ValueError("part name invalid")
            dm = re.fullmatch(r"d([0-9]+)\.bin", pn)
            if not dm:
                raise ValueError("part name invalid")
            num = int(dm.group(1))
            if num in used_d:
                raise ValueError("data block referenced twice")
            used_d.add(num)
            if num not in d_blocks:
                raise ValueError("missing data block")
            data += d_blocks[num]
        if len(data) != size:
            raise ValueError("size mismatch")
        if hashlib.sha256(data).hexdigest() != sha:
            raise ValueError("sha256 mismatch")
        result_files.append({"path": path, "hex": data.hex()})
        total_bytes += len(data)

    # Every d block must be referenced exactly once.
    if set(d_blocks) != used_d:
        raise ValueError("extra or unreferenced data block")

    result_files.sort(key=lambda x: x["path"])
    return {"name": contract["name"], "result": {"files": result_files, "total_bytes": total_bytes}}
