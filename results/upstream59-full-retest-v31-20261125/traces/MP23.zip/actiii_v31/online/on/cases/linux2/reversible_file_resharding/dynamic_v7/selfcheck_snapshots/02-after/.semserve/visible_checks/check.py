import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/chunks/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/layout/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/restore/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        chunks_payload = {
            "files": [{"path": "a.txt", "hex": "61"}],
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        chunks_contract = {"name": "chunks", "operation": "reshard_chunks", "inputs": ["x"], "output": "y"}
        layout_payload = {
            "files": [{"path": "f.txt", "hex": "61"}],
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        layout_chunks = {
            "chunks": [{"name": "d000000.bin", "hex": "61"}],
            "manifest": {"files": [{"path": "f.txt", "size": 1, "sha256": "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7", "parts": ["d000000.bin"]}]},
        }
        layout_contract = {"name": "layout", "operation": "reshard_layout", "inputs": ["x", "y"], "output": "z"}
        restore_layout = {
            "tree": [
                {"path": "n0/d000000.bin", "hex": "61"},
                {"path": "n0/m000000.bin", "hex": "7b2266696c6573223a5b7b227061727473223a5b22643030303030302e62696e225d2c2270617468223a22662e747874222c22736861323536223a22383734323866633532323830336433313036356537626365336366303366653437353039363633316535653037626264376130646536306334636632356337222c2273697a65223a317d5d7d"},
            ],
            "max_entries": 2,
            "max_file_bytes": 256,
        }
        # 修正 restore 的 manifest 块 hex（sha256 为 "a" 的摘要）
        restore_layout["tree"][1]["hex"] = "7b2266696c6573223a5b7b227061727473223a5b22643030303030302e62696e225d2c2270617468223a22662e747874222c22736861323536223a2263613937383131326361316262646361666163323331623339613233646334646137383665666638313437633465373262393830373738356166656534386262222c2273697a65223a317d5d7d"
        restore_contract = {"name": "restore", "operation": "reshard_restore", "inputs": ["x"], "output": "y"}

        with self.subTest(component="chunks", rule="invalid_payload_type"):
            check_api_boundary(
                "products/chunks/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                args=[[chunks_payload], chunks_contract],
            )
        with self.subTest(component="chunks", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "products/chunks/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                args=[[chunks_payload], chunks_contract],
            )
        with self.subTest(component="layout", rule="invalid_payload_type"):
            check_api_boundary(
                "products/layout/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                args=[[layout_payload, layout_chunks], layout_contract],
            )
        with self.subTest(component="layout", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "products/layout/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                args=[[layout_payload, layout_chunks], layout_contract],
            )
        with self.subTest(component="restore", rule="invalid_payload_type"):
            check_api_boundary(
                "products/restore/transform.py", rule="invalid_payload_type",
                contract_path="README.md",
                requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                args=[[restore_layout], restore_contract],
            )
        with self.subTest(component="restore", rule="nonfinite_unknown_field"):
            check_api_boundary(
                "products/restore/transform.py", rule="nonfinite_unknown_field",
                contract_path="README.md",
                requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                args=[[restore_layout], restore_contract],
            )


class TestChunksTransform(unittest.TestCase):
    def test_chunks_roundtrip_and_ordering(self):
        # 独立小输入：验证按 path 排序、分块、sha256 与恢复一致性。
        payload = {
            "files": [
                {"path": "b.txt", "hex": "616263"},
                {"path": "a.txt", "hex": "64"},
            ],
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        contract = {"name": "chunks", "operation": "reshard_chunks", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/chunks/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "chunks")
        r = result["result"]
        self.assertEqual([c["name"] for c in r["chunks"]], ["d000000.bin", "d000001.bin"])
        # a.txt 先于 b.txt，因此 d000000 是 "d"（0x64），d000001 是 "abc"。
        self.assertEqual(r["chunks"][0]["hex"], "64")
        self.assertEqual(r["chunks"][1]["hex"], "616263")
        files = r["manifest"]["files"]
        self.assertEqual([f["path"] for f in files], ["a.txt", "b.txt"])
        self.assertEqual(files[0]["size"], 1)
        self.assertEqual(files[1]["size"], 3)
        self.assertEqual(files[0]["parts"], ["d000000.bin"])
        self.assertEqual(files[1]["parts"], ["d000001.bin"])


class TestLayoutTransform(unittest.TestCase):
    def test_layout_tree_limits(self):
        # 独立小输入：验证每目录直接项数受限且树按 path 排序。
        payload = {
            "files": [{"path": "f.txt", "hex": "61"}],
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        chunks = {
            "chunks": [{"name": "d000000.bin", "hex": "61"}],
            "manifest": {"files": [{"path": "f.txt", "size": 1, "sha256": "87428fc522803d31065e7bce3cf03fe475096631e5e07bbd7a0fde60c4cf25c7", "parts": ["d000000.bin"]}]},
        }
        contract = {"name": "layout", "operation": "reshard_layout", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("products/layout/transform.py", "transform", args=[[payload, chunks], contract])
        r = result["result"]
        self.assertEqual(r["max_entries"], 2)
        self.assertEqual(r["max_file_bytes"], 16)
        paths = [t["path"] for t in r["tree"]]
        self.assertEqual(paths, sorted(paths))
        # 每个目录直接项数 <= max_entries
        from collections import defaultdict
        direct = defaultdict(set)
        for p in paths:
            parts = p.split("/")
            parent = "/".join(parts[:-1])
            direct[parent].add(parts[-1])
        for children in direct.values():
            self.assertLessEqual(len(children), 2)


class TestRestoreTransform(unittest.TestCase):
    def test_restore_roundtrip(self):
        # 独立小输入：从 layout 树恢复原文件。
        layout = {
            "tree": [
                {"path": "n0/d000000.bin", "hex": "616263"},
                {"path": "n0/m000000.bin", "hex": "7b2266696c6573223a5b7b227061727473223a5b22643030303030302e62696e225d2c2270617468223a22662e747874222c22736861323536223a2262613738313662663866303163666561343134313430646535646165323232336230303336316133393631373761396362343130666636316632303031356164222c2273697a65223a337d5d7d"},
            ],
            "max_entries": 2,
            "max_file_bytes": 256,
        }
        contract = {"name": "restore", "operation": "reshard_restore", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/restore/transform.py", "transform", args=[[layout], contract])
        r = result["result"]
        self.assertEqual(r["total_bytes"], 3)
        self.assertEqual(r["files"], [{"path": "f.txt", "hex": "616263"}])


if __name__ == "__main__":
    unittest.main()
