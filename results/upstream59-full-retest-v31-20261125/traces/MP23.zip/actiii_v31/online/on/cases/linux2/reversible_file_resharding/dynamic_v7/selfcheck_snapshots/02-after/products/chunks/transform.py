import hashlib
import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _safe_path(s):
    if not isinstance(s, str):
        raise ValueError("path must be string")
    if s.strip() == "":
        raise ValueError("empty path")
    if s.startswith("/") or "\\" in s or ":" in s:
        raise ValueError("unsafe path")
    parts = s.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("unsafe path segment")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    # If keys are exactly name/result, only result is business input.
    if set(payload.keys()) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("business input must be object")
    _reject_nonfinite(payload)

    files = payload.get("files")
    max_file_bytes = payload.get("max_file_bytes")
    max_entries = payload.get("max_entries")

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not _is_int(max_file_bytes) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not _is_int(max_entries) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    seen_paths = set()
    parsed_files = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        path = _safe_path(f["path"])
        if path in seen_paths:
            raise ValueError("duplicate path")
        seen_paths.add(path)
        hexv = f["hex"]
        if not isinstance(hexv, str):
            raise ValueError("hex must be string")
        try:
            data = bytes.fromhex(hexv)
        except ValueError as e:
            raise ValueError("invalid hex") from e
        parsed_files.append((path, data))

    parsed_files.sort(key=lambda t: t[0])

    chunks = []
    manifest_files = []
    global_idx = 0
    for path, data in parsed_files:
        parts = []
        for i in range(0, len(data), max_file_bytes):
            block = data[i:i + max_file_bytes]
            name = "d%06d.bin" % global_idx
            global_idx += 1
            chunks.append({"name": name, "hex": block.hex()})
            parts.append(name)
        manifest_files.append({
            "path": path,
            "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "parts": parts,
        })

    result = {
        "chunks": chunks,
        "manifest": {"files": manifest_files},
    }
    return {"name": contract["name"], "result": result}
