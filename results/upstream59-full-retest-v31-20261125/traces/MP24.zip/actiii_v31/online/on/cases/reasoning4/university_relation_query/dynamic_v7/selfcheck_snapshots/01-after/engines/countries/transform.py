def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    departments = payload["departments"]
    professors = payload["professors"]

    dept_country = {d["id"]: d["country"] for d in departments}

    countries = {}
    for prof in professors:
        cs = sorted({dept_country[dep] for dep in prof["departments"]})
        countries[prof["id"]] = cs

    return {"name": contract["name"], "result": {"countries": countries}}
