def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    departments = data["departments"]
    professors = data["professors"]
    eu = set(data["eu"])

    country_by_dept = {d["id"]: d["country"] for d in departments}

    ids = []
    for prof in professors:
        for dept_id in prof["departments"]:
            if country_by_dept[dept_id] in eu:
                ids.append(prof["id"])
                break

    ids.sort()
    return {"name": contract["name"], "result": {"ids": ids}}
