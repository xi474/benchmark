def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    raw, eu_payload, students_payload, countries_payload = payloads

    if isinstance(raw, dict) and set(raw) == {"name", "result"}:
        raw = raw["result"]
    if isinstance(eu_payload, dict) and set(eu_payload) == {"name", "result"}:
        eu_payload = eu_payload["result"]
    if isinstance(students_payload, dict) and set(students_payload) == {"name", "result"}:
        students_payload = students_payload["result"]
    if isinstance(countries_payload, dict) and set(countries_payload) == {"name", "result"}:
        countries_payload = countries_payload["result"]

    eu_ids = set(eu_payload["ids"])
    counts = students_payload["counts"]
    countries = countries_payload["countries"]

    professors = []
    for prof in raw["professors"]:
        pid = prof["id"]
        if pid not in eu_ids:
            continue
        eligible = sorted(d for d in prof["departments"] if counts.get(d, 0) > 10)
        if not eligible:
            continue
        professors.append({
            "id": pid,
            "countries": countries.get(pid, []),
            "eligible_departments": eligible,
        })

    professors.sort(key=lambda p: p["id"])
    return {"name": contract["name"], "result": {"professors": professors}}
