def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    departments = payload["departments"]
    students = payload["students"]
    as_of = payload["as_of"]

    dept_ids = {d["id"] for d in departments}
    counts = {did: 0 for did in dept_ids}

    for student in students:
        seen = set()
        for enr in student["enrolments"]:
            dept = enr["department"]
            start = enr["start"]
            end = enr["end"]
            if end is not None and end <= start:
                continue
            if start > as_of:
                continue
            if end is not None and as_of >= end:
                continue
            if dept in seen:
                continue
            seen.add(dept)
            counts[dept] = counts.get(dept, 0) + 1

    return {"name": contract["name"], "result": {"counts": counts}}
