import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts")

    # Topological order by input dependency: a component depends on another
    # component's output file. Iteratively run components whose inputs exist.
    produced = set()
    remaining = list(contracts)
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [p for p in c["inputs"] if p.startswith("outputs/")]
            if all((ROOT / d).exists() for d in deps):
                subprocess.run(
                    [sys.executable, str(cp.with_name("render.py"))],
                    cwd=ROOT,
                    check=True,
                    timeout=60,
                )
                produced.add(c["output"])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise ValueError("missing dependency or cycle")

    # Integrate all component outputs into core manifest.
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    # Generate the final report from the core manifest.
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
