import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/eu/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/students/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/countries/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/query/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            rules = req["rules"]
            for rule_name, rule in rules.items():
                if not rule.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule_name):
                    check_api_boundary(
                        target,
                        rule=rule_name,
                        contract_path=rule["contract_path"],
                        requirement_quote=rule["requirement_quote"],
                        args=[[{"departments": [], "professors": [], "students": [], "as_of": "2025-01-01", "eu": []}], {"name": "x", "inputs": ["x"]}],
                        path=[0, 0],
                    )


class TestBusinessBehavior(unittest.TestCase):
    def test_query_requires_department_over_10(self):
        # Two departments of 6 each must not qualify; only a single >10 does.
        payloads = [
            {
                "departments": [
                    {"id": "a", "country": "DE"},
                    {"id": "b", "country": "DE"},
                ],
                "professors": [
                    {"id": "p1", "departments": ["a", "b"]},
                ],
                "students": [],
                "as_of": "2025-01-01",
                "eu": ["DE"],
            },
            {"ids": ["p1"]},
            {"counts": {"a": 6, "b": 6}},
            {"countries": {"p1": ["DE"]}},
        ]
        result = call_candidate(
            "engines/query/transform.py", "transform", args=[payloads, {"name": "query", "inputs": ["x", "y", "z", "w"]}]
        )
        self.assertEqual(result["result"]["professors"], [])

    def test_query_single_department_over_10_qualifies(self):
        payloads = [
            {
                "departments": [
                    {"id": "a", "country": "DE"},
                    {"id": "b", "country": "US"},
                ],
                "professors": [
                    {"id": "p1", "departments": ["a", "b"]},
                ],
                "students": [],
                "as_of": "2025-01-01",
                "eu": ["DE"],
            },
            {"ids": ["p1"]},
            {"counts": {"a": 11, "b": 3}},
            {"countries": {"p1": ["DE", "US"]}},
        ]
        result = call_candidate(
            "engines/query/transform.py", "transform", args=[payloads, {"name": "query", "inputs": ["x", "y", "z", "w"]}]
        )
        self.assertEqual(
            result["result"]["professors"],
            [{"id": "p1", "countries": ["DE", "US"], "eligible_departments": ["a"]}],
        )

    def test_students_distinct_per_department(self):
        # Same student enrolled twice in one department counts once.
        payloads = [
            {
                "departments": [{"id": "a", "country": "DE"}],
                "professors": [],
                "students": [
                    {
                        "id": "s1",
                        "enrolments": [
                            {"department": "a", "start": "2024-01-01", "end": None},
                            {"department": "a", "start": "2024-02-01", "end": None},
                        ],
                    }
                ],
                "as_of": "2025-01-01",
                "eu": ["DE"],
            }
        ]
        result = call_candidate(
            "engines/students/transform.py", "transform", args=[payloads, {"name": "students", "inputs": ["x"]}]
        )
        self.assertEqual(result["result"]["counts"], {"a": 1})

    def test_students_end_boundary_exclusive(self):
        # as_of == end means not enrolled (as_of < end required).
        payloads = [
            {
                "departments": [{"id": "a", "country": "DE"}],
                "professors": [],
                "students": [
                    {
                        "id": "s1",
                        "enrolments": [
                            {"department": "a", "start": "2024-01-01", "end": "2025-01-01"},
                        ],
                    }
                ],
                "as_of": "2025-01-01",
                "eu": ["DE"],
            }
        ]
        result = call_candidate(
            "engines/students/transform.py", "transform", args=[payloads, {"name": "students", "inputs": ["x"]}]
        )
        self.assertEqual(result["result"]["counts"], {"a": 0})

    def test_eu_qualifies_any_eu_department(self):
        payloads = [
            {
                "departments": [
                    {"id": "a", "country": "US"},
                    {"id": "b", "country": "FR"},
                ],
                "professors": [
                    {"id": "p1", "departments": ["a", "b"]},
                    {"id": "p2", "departments": ["a"]},
                ],
                "students": [],
                "as_of": "2025-01-01",
                "eu": ["FR"],
            }
        ]
        result = call_candidate(
            "engines/eu/transform.py", "transform", args=[payloads, {"name": "eu", "inputs": ["x"]}]
        )
        self.assertEqual(result["result"]["ids"], ["p1"])

    def test_countries_dedup_sorted(self):
        payloads = [
            {
                "departments": [
                    {"id": "a", "country": "US"},
                    {"id": "b", "country": "DE"},
                    {"id": "c", "country": "US"},
                ],
                "professors": [
                    {"id": "p1", "departments": ["c", "a", "b"]},
                ],
                "students": [],
                "as_of": "2025-01-01",
                "eu": ["DE"],
            }
        ]
        result = call_candidate(
            "engines/countries/transform.py", "transform", args=[payloads, {"name": "countries", "inputs": ["x"]}]
        )
        self.assertEqual(result["result"]["countries"], {"p1": ["DE", "US"]})


if __name__ == "__main__":
    unittest.main()
