import re


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _parse_amount(token):
    # token like "USD 1,200.50" or "1,200.50"
    s = token.strip()
    if s.upper().startswith("USD"):
        s = s[3:].strip()
    if not re.fullmatch(r"\d{1,3}(?:,\d{3})*(?:\.\d{2})", s):
        raise ValueError("invalid amount")
    digits = s.replace(",", "")
    return digits


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    documents = data["documents"]
    amounts = {}
    for doc in documents:
        doc_id = doc["id"]
        text = doc["text"]
        total = None
        vat = None
        for line in text.splitlines():
            stripped = line.strip()
            lower = stripped.lower()
            if lower.startswith("total:"):
                if total is not None:
                    raise ValueError("duplicate Total")
                total = _parse_amount(stripped[len("total:"):])
            elif lower.startswith("amount due:"):
                if total is None:
                    total = _parse_amount(stripped[len("amount due:"):])
            elif lower.startswith("vat:"):
                if vat is not None:
                    raise ValueError("duplicate VAT")
                vat = _parse_amount(stripped[len("vat:"):])
        if vat is None:
            vat = "0.00"
        amounts[doc_id] = {"total": total, "vat": vat}
    return {"name": contract["name"], "result": {"amounts": amounts}}
