import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(ROOT.rglob('contract.json'))
    contracts = [c for c in contracts if 'outputs' not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError('no contracts')

    produced = set()
    remaining = list(contracts)
    order = []
    while remaining:
        progressed = False
        for c in list(remaining):
            data = json.loads(c.read_text(encoding='utf-8'))
            deps = [p for p in data['inputs'] if p.startswith('outputs/')]
            if all(d in produced for d in deps):
                order.append(c)
                produced.add(data['output'])
                remaining.remove(c)
                progressed = True
        if not progressed:
            raise ValueError('dependency cycle or missing dependency')

    for c in order:
        render = c.with_name('render.py')
        subprocess.run([sys.executable, str(render)], cwd=ROOT, check=True)

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
