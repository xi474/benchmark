import csv
import io


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    documents = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])
    amounts = _unwrap(payloads[2])

    docs = documents["documents"]
    classes = classification["classes"]
    amts = amounts["amounts"]

    archives = []
    rows = []
    totals = {"invoice": 0, "receipt": 0}

    for d in docs:
        did = d["id"]
        filename = d["filename"]
        text = d["text"]
        kind = classes[did]
        total = amts[did]["total"]
        vat = amts[did]["vat"]

        if kind in ("invoice", "receipt") and total is None:
            raise ValueError("invoice/receipt requires total")

        path = "classified/" + kind + "/" + did + "/" + filename
        hexdata = text.encode("utf-8").hex()
        archives.append({"path": path, "hex": hexdata})

        rows.append({"id": did, "filename": filename, "kind": kind,
                     "total": total, "vat": vat})

        if kind in ("invoice", "receipt") and total is not None:
            totals[kind] += _to_cents(total)

    archives.sort(key=lambda a: a["path"])
    rows.sort(key=lambda r: r["id"])

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["id", "filename", "kind", "total", "vat"])
    for r in rows:
        w.writerow([r["id"], r["filename"], r["kind"],
                    r["total"] if r["total"] is not None else "",
                    r["vat"]])
    csv_str = buf.getvalue()

    totals_out = {
        "invoice": _fmt(totals["invoice"]),
        "receipt": _fmt(totals["receipt"]),
    }

    return {
        "name": contract["name"],
        "result": {
            "archives": archives,
            "rows": rows,
            "csv": csv_str,
            "totals": totals_out,
        },
    }


def _to_cents(s):
    sign = 1
    t = s
    if t.startswith("-"):
        sign = -1
        t = t[1:]
    if "." in t:
        whole, frac = t.split(".", 1)
    else:
        whole, frac = t, ""
    frac = (frac + "00")[:2]
    return sign * (int(whole) * 100 + int(frac))


def _fmt(cents):
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    return "%s%d.%02d" % (sign, cents // 100, cents % 100)
