import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/classification/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
                "args": [[{"documents": []}], {"name": "classification", "inputs": ["inputs/case.json"]}],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                "args": [[{"documents": []}], {"name": "classification", "inputs": ["inputs/case.json"]}],
            },
        },
    },
    {
        "target_path": "domains/amounts/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
                "args": [[{"documents": []}], {"name": "amounts", "inputs": ["inputs/case.json"]}],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                "args": [[{"documents": []}], {"name": "amounts", "inputs": ["inputs/case.json"]}],
            },
        },
    },
    {
        "target_path": "views/archive/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
                "args": [
                    [{"documents": []}, {"classes": {}}, {"amounts": {}}],
                    {"name": "archive", "inputs": ["inputs/case.json", "outputs/classification.json", "outputs/amounts.json"]},
                ],
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                "args": [
                    [{"documents": []}, {"classes": {}}, {"amounts": {}}],
                    {"name": "archive", "inputs": ["inputs/case.json", "outputs/classification.json", "outputs/amounts.json"]},
                ],
            },
        },
    },
]


class ApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            rules = req["rules"]
            for rule_name, rule in rules.items():
                if not rule.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule_name):
                    check_api_boundary(
                        target,
                        rule=rule_name,
                        contract_path=rule["contract_path"],
                        requirement_quote=rule["requirement_quote"],
                        args=rule["args"],
                    )


class ClassificationBehavior(unittest.TestCase):
    def test_classification_priority_and_other(self):
        docs = [
            {"id": "a", "filename": "x.txt", "text": "Invoice then receipt"},
            {"id": "b", "filename": "y.txt", "text": "a receipt here"},
            {"id": "c", "filename": "z.txt", "text": "nothing relevant"},
        ]
        payload = {"documents": docs}
        contract = {"name": "classification", "inputs": ["inputs/case.json"]}
        result = call_candidate(
            "domains/classification/transform.py", "transform",
            args=[[payload], contract],
        )
        self.assertEqual(result["name"], "classification")
        self.assertEqual(
            result["result"]["classes"],
            {"a": "invoice", "b": "receipt", "c": "other"},
        )


class AmountsBehavior(unittest.TestCase):
    def test_total_priority_and_vat_default(self):
        docs = [
            {
                "id": "a", "filename": "x.txt",
                "text": "Total: 10.00\nAmount Due: 20.00\nVAT: 1.50\n",
            },
            {
                "id": "b", "filename": "y.txt",
                "text": "Amount Due: USD 5.00\n",
            },
        ]
        payload = {"documents": docs}
        contract = {"name": "amounts", "inputs": ["inputs/case.json"]}
        result = call_candidate(
            "domains/amounts/transform.py", "transform",
            args=[[payload], contract],
        )
        amounts = result["result"]["amounts"]
        self.assertEqual(amounts["a"], {"total": "10.00", "vat": "1.50"})
        self.assertEqual(amounts["b"], {"total": "5.00", "vat": "0.00"})


class ArchiveBehavior(unittest.TestCase):
    def test_archive_totals_and_csv(self):
        docs = [
            {"id": "i", "filename": "f/i.txt", "text": "Invoice\nTotal: 1.00\n"},
            {"id": "r", "filename": "f/r.txt", "text": "Receipt\nTotal: 2.00\n"},
            {"id": "o", "filename": "f/o.txt", "text": "notes\n"},
        ]
        classification = {"classes": {"i": "invoice", "r": "receipt", "o": "other"}}
        amounts = {
            "amounts": {
                "i": {"total": "1.00", "vat": "0.00"},
                "r": {"total": "2.00", "vat": "0.00"},
                "o": {"total": None, "vat": "0.00"},
            }
        }
        contract = {
            "name": "archive",
            "inputs": ["inputs/case.json", "outputs/classification.json", "outputs/amounts.json"],
        }
        result = call_candidate(
            "views/archive/transform.py", "transform",
            args=[[{"documents": docs}, classification, amounts], contract],
        )
        r = result["result"]
        self.assertEqual(r["totals"], {"invoice": "1.00", "receipt": "2.00"})
        self.assertEqual(r["rows"][0]["id"], "i")
        self.assertTrue(r["csv"].startswith("id,filename,kind,total,vat\n"))
        self.assertEqual(len(r["archives"]), 3)


if __name__ == "__main__":
    unittest.main()
