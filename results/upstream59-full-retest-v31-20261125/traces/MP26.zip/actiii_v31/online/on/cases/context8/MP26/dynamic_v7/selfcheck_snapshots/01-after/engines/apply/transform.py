def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("bad arguments")
    inputs = contract.get("inputs")
    if not isinstance(inputs, list) or len(inputs) != len(payloads):
        raise ValueError("payload count mismatch")

    calendar = _unwrap(payloads[0])
    plan = _unwrap(payloads[1])
    notifications = _unwrap(payloads[2])

    if not isinstance(calendar, dict) or not isinstance(plan, dict) or not isinstance(notifications, dict):
        raise ValueError("inputs must be objects")

    events = calendar.get("events")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    cancelled = plan.get("cancelled")
    added = plan.get("added")
    if not isinstance(cancelled, list) or not isinstance(added, list):
        raise ValueError("plan fields must be lists")

    outbox = notifications.get("outbox")
    if not isinstance(outbox, list):
        raise ValueError("outbox must be a list")

    cancelled_set = set(cancelled)
    remaining = [ev for ev in events if ev.get("id") not in cancelled_set]
    final_events = remaining + list(added)
    final_events.sort(key=lambda ev: ev["id"])

    return {
        "name": contract["name"],
        "result": {
            "events": final_events,
            "outbox": outbox,
        },
    }
