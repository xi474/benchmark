import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return not (math.isnan(v) or math.isinf(v))
    return False


def _require_str(v, field):
    if not isinstance(v, str):
        raise ValueError(f"{field} must be a string")
    if not v.strip():
        raise ValueError(f"{field} must be non-empty")
    return v


def _parse_minutes(ts, field):
    _require_str(ts, field)
    if len(ts) != 16 or ts[4] != "-" or ts[7] != "-" or ts[10] != "T" or ts[13] != ":":
        raise ValueError(f"{field} must be YYYY-MM-DDTHH:MM")
    date = ts[:10]
    hm = ts[11:]
    try:
        y = int(date[0:4]); mo = int(date[5:7]); d = int(date[8:10])
        h = int(hm[0:2]); mi = int(hm[3:5])
    except ValueError as e:
        raise ValueError(f"{field} invalid") from e
    if not (1 <= mo <= 12 and 1 <= d <= 31 and 0 <= h <= 23 and 0 <= mi <= 59):
        raise ValueError(f"{field} out of range")
    return (date, h * 60 + mi)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")

    today = payload.get("today")
    _require_str(today, "today")
    if len(today) != 10 or today[4] != "-" or today[7] != "-":
        raise ValueError("today must be YYYY-MM-DD")

    contacts = payload.get("contacts")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be a list")
    contact_set = set()
    for c in contacts:
        _require_str(c, "contact")
        if c in contact_set:
            raise ValueError("duplicate contact")
        contact_set.add(c)

    events = payload.get("events")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    seen_ids = set()
    parsed = []
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be an object")
        eid = _require_str(ev.get("id"), "event id")
        if eid in seen_ids:
            raise ValueError("duplicate event id")
        seen_ids.add(eid)
        start = _parse_minutes(ev.get("start"), "start")
        end = _parse_minutes(ev.get("end"), "end")
        if end[0] < start[0] or (end[0] == start[0] and end[1] <= start[1]):
            raise ValueError("end must be after start")
        kind = _require_str(ev.get("kind"), "kind")
        attendees = ev.get("attendees")
        if not isinstance(attendees, list):
            raise ValueError("attendees must be a list")
        dedup = []
        for a in attendees:
            _require_str(a, "attendee")
            if a not in contact_set:
                raise ValueError("attendee not in contacts")
            if a not in dedup:
                dedup.append(a)
        dedup.sort()
        parsed.append((eid, start, end, kind, dedup, ev))

    # existing_dinners: start exactly 19:00 and kind == "dinner"
    existing = set()
    for eid, start, end, kind, dedup, ev in parsed:
        if kind == "dinner" and start[1] == 19 * 60:
            existing.add(start[0])
    existing_dinners = sorted(existing)

    # events output: original events by id, attendees dedup sorted
    out_events = []
    for eid, start, end, kind, dedup, ev in parsed:
        out_events.append({
            "id": eid,
            "start": ev["start"],
            "end": ev["end"],
            "kind": kind,
            "attendees": dedup,
        })
    out_events.sort(key=lambda e: e["id"])

    return {"name": contract["name"], "result": {"events": out_events, "existing_dinners": existing_dinners}}
