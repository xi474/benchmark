import datetime


def _parse_date(s):
    if not isinstance(s, str):
        raise ValueError("today must be a string")
    try:
        return datetime.date.fromisoformat(s)
    except ValueError as e:
        raise ValueError("today must be YYYY-MM-DD") from e


def transform(payloads, contract):
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("bad arguments")
    if "inputs" not in contract or "name" not in contract:
        raise ValueError("contract missing fields")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if "today" not in payload:
        raise ValueError("missing today")

    today = _parse_date(payload["today"])

    # Monday is the first day of the week (weekday()==0).
    # Find the Friday of the next natural week after the week containing today.
    days_since_monday = today.weekday()  # 0=Mon .. 6=Sun
    # Days until the Monday of the next week.
    days_to_next_monday = 7 - days_since_monday
    next_monday = today + datetime.timedelta(days=days_to_next_monday)
    # Friday is 4 days after Monday.
    next_friday = next_monday + datetime.timedelta(days=4)

    dates = []
    d = today
    while d <= next_friday:
        dates.append(d.isoformat())
        d += datetime.timedelta(days=1)

    return {"name": contract["name"], "result": {"dates": dates}}
