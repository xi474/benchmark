def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("bad arguments")
    if "inputs" not in contract or "name" not in contract:
        raise ValueError("contract missing fields")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    plan = _unwrap(payloads[0])
    if not isinstance(plan, dict):
        raise ValueError("plan must be an object")

    snapshots = plan.get("snapshots")
    if not isinstance(snapshots, list):
        raise ValueError("snapshots must be a list")

    by_contact = {}
    for ev in snapshots:
        if not isinstance(ev, dict):
            raise ValueError("snapshot must be an object")
        eid = ev.get("id")
        if not isinstance(eid, str):
            raise ValueError("snapshot id must be a string")
        attendees = ev.get("attendees")
        if not isinstance(attendees, list):
            raise ValueError("attendees must be a list")
        for a in attendees:
            if not isinstance(a, str):
                raise ValueError("attendee must be a string")
            by_contact.setdefault(a, set()).add(eid)

    outbox = []
    for contact in sorted(by_contact):
        outbox.append({
            "to": contact,
            "event_ids": sorted(by_contact[contact]),
        })

    return {"name": contract["name"], "result": {"outbox": outbox}}
