import json
from pathlib import Path


def _reject_constant(value):
    raise ValueError("non-finite number not allowed: %r" % (value,))


def _parse_float(value):
    f = float(value)
    if f != f or f in (float("inf"), float("-inf")):
        raise ValueError("non-finite number not allowed: %r" % (value,))
    return f


def load_payload(path):
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as exc:
        raise ValueError("cannot read %s: %s" % (path, exc)) from exc
    try:
        data = json.loads(
            text, parse_constant=_reject_constant, parse_float=_parse_float
        )
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("invalid JSON in %s: %s" % (path, exc)) from exc
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be an object or array")
    return data
