import copy
from datetime import datetime, timedelta


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _parse_dt(text):
    if not isinstance(text, str):
        raise ValueError("time must be a string")
    try:
        return datetime.strptime(text, "%Y-%m-%dT%H:%M")
    except ValueError as exc:
        raise ValueError("invalid time %r" % (text,)) from exc


def transform(payloads, contract):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    if not isinstance(contract, dict):
        raise ValueError("contract must be an object")
    inputs = contract.get("inputs")
    if not isinstance(inputs, list) or len(inputs) != len(payloads):
        raise ValueError("payload count must match contract.inputs")

    days_payload = _unwrap(payloads[0])
    calendar_payload = _unwrap(payloads[1])

    if not isinstance(days_payload, dict) or not isinstance(calendar_payload, dict):
        raise ValueError("inputs must be objects")

    dates = days_payload.get("dates")
    if not isinstance(dates, list):
        raise ValueError("dates must be a list")
    for d in dates:
        if not isinstance(d, str):
            raise ValueError("date must be a string")

    events = calendar_payload.get("events")
    existing_dinners = calendar_payload.get("existing_dinners")
    if not isinstance(events, list):
        raise ValueError("events must be a list")
    if not isinstance(existing_dinners, list):
        raise ValueError("existing_dinners must be a list")

    existing_set = set(existing_dinners)

    # Build new dinner reminders for non-skipped dates.
    added = []
    for d in dates:
        if d in existing_set:
            continue
        start = d + "T19:00"
        end = d + "T20:00"
        added.append(
            {
                "id": "dinner-" + d,
                "start": start,
                "end": end,
                "kind": "dinner",
                "attendees": [],
            }
        )

    # New IDs must not collide with any old event ID.
    old_ids = set()
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be an object")
        eid = ev.get("id")
        if not isinstance(eid, str):
            raise ValueError("event id must be a string")
        old_ids.add(eid)
    for ev in added:
        if ev["id"] in old_ids:
            raise ValueError("new id conflicts with existing event: %r" % (ev["id"],))

    # Cancel old events whose half-open interval intersects a new reminder.
    new_intervals = []
    for ev in added:
        new_intervals.append((_parse_dt(ev["start"]), _parse_dt(ev["end"])))

    cancelled = []
    snapshots = []
    for ev in events:
        s = _parse_dt(ev["start"])
        e = _parse_dt(ev["end"])
        if e <= s:
            raise ValueError("event end must be after start")
        conflict = False
        for ns, ne in new_intervals:
            # half-open [ns, ne): overlap iff s < ne and e > ns
            if s < ne and e > ns:
                conflict = True
                break
        if conflict:
            cancelled.append(ev["id"])
            snapshots.append(ev)

    cancelled.sort()
    snapshots.sort(key=lambda ev: ev["id"])
    added.sort(key=lambda ev: ev["start"])

    return {
        "name": contract["name"],
        "result": {
            "added": added,
            "cancelled": cancelled,
            "snapshots": snapshots,
        },
    }

