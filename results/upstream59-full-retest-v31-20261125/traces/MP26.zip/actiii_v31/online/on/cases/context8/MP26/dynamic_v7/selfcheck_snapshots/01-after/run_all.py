import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts[c['name']] = (cp, c)
    return contracts


def _topo_order(contracts):
    name_to_output = {name: c['output'] for name, (_, c) in contracts.items()}
    output_to_name = {out: name for name, out in name_to_output.items()}

    deps = {}
    for name, (_, c) in contracts.items():
        d = set()
        for inp in c['inputs']:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[name] = d

    order = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            raise ValueError('cycle detected in component dependencies')
        if name in visited:
            return
        visiting.add(name)
        for dep in sorted(deps[name]):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(contracts):
        visit(name)
    return order


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError('no contracts found')

    order = _topo_order(contracts)

    for name in order:
        cp, c = contracts[name]
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError('missing render.py for %s' % name)
        subprocess.run(
            [sys.executable, str(render_py), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    integrate_py = ROOT / 'integrate.py'
    subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    final_report_py = ROOT / 'final_report.py'
    subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == '__main__':
    main()
