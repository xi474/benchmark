import unittest

# Injected by the visible-contract-check SDK runner.
call_candidate = None
check_api_boundary = None
CandidateCallError = Exception

if call_candidate is None:
    import importlib.util
    import json
    import sys
    from pathlib import Path

    _ROOT = Path("/workspace")

    class CandidateCallError(Exception):
        def __init__(self, details):
            super().__init__(str(details))
            self.details = details

    def call_candidate(target_path, function, args=None, kwargs=None):
        args = args or []
        kwargs = kwargs or {}
        spec = importlib.util.spec_from_file_location(
            "candidate_mod", _ROOT / target_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        fn = getattr(mod, function)
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            raise CandidateCallError({
                "failure_phase": "candidate_exception",
                "error_type": type(e).__name__,
            }) from e

    def check_api_boundary(target_path, rule, contract_path,
                           requirement_quote, args):
        # Local fallback: exercise the candidate directly with a negative
        # variant and assert it raises ValueError.
        import math
        payloads, contract = args
        if rule == "invalid_payload_type":
            for bad in [None, 1, "x", True, 1.5]:
                try:
                    call_candidate(target_path, "transform",
                                   args=[[bad], contract])
                except CandidateCallError as e:
                    if e.details["error_type"] == "ValueError":
                        continue
                    raise
                raise AssertionError(
                    "invalid_payload_type accepted %r" % (bad,))
        elif rule == "nonfinite_unknown_field":
            for bad in [float("nan"), float("inf"), float("-inf")]:
                p = dict(payloads[0])
                p["extra"] = bad
                try:
                    call_candidate(target_path, "transform",
                                   args=[[p], contract])
                except CandidateCallError as e:
                    if e.details["error_type"] == "ValueError":
                        continue
                    raise
                raise AssertionError(
                    "nonfinite_unknown_field accepted %r" % (bad,))

README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {"target_path": "engines/dates/transform.py", "function": "transform",
     "rules": {
         "nonfinite_unknown_field": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。"},
         "invalid_payload_type": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。"},
     }},
    {"target_path": "engines/calendar/transform.py", "function": "transform",
     "rules": {
         "nonfinite_unknown_field": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。"},
         "invalid_payload_type": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。"},
     }},
    {"target_path": "engines/plan/transform.py", "function": "transform",
     "rules": {
         "nonfinite_unknown_field": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。"},
         "invalid_payload_type": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。"},
     }},
    {"target_path": "engines/notifications/transform.py", "function": "transform",
     "rules": {
         "nonfinite_unknown_field": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。"},
         "invalid_payload_type": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。"},
     }},
    {"target_path": "engines/apply/transform.py", "function": "transform",
     "rules": {
         "nonfinite_unknown_field": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。"},
         "invalid_payload_type": {"applicable": True,
             "contract_path": README,
             "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。"},
     }},
]


def _dates_payload():
    return {
        "today": "2026-11-04",
        "events": [],
        "contacts": [],
    }


def _calendar_payload():
    return {
        "today": "2026-11-04",
        "events": [
            {
                "id": "e1",
                "start": "2026-11-04T18:00",
                "end": "2026-11-04T19:00",
                "kind": "other",
                "attendees": [],
            }
        ],
        "contacts": [],
    }


class TestApiBoundary(unittest.TestCase):
    def test_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target, rule="invalid_payload_type",
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[None], {"name": "x", "inputs": ["i"],
                                           "output": "o"}])
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target, rule="nonfinite_unknown_field",
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"today": "2026-11-04"}],
                                  {"name": "x", "inputs": ["i"],
                                   "output": "o"}])


class TestDates(unittest.TestCase):
    def test_dates_range_and_order(self):
        payload = _dates_payload()
        contract = {"name": "dates", "operation": "dinner_days",
                    "inputs": ["inputs/case.json"], "output": "outputs/dates.json"}
        res = call_candidate("engines/dates/transform.py", "transform",
                             args=[[payload], contract])
        self.assertEqual(res["name"], "dates")
        dates = res["result"]["dates"]
        self.assertEqual(dates[0], "2026-11-04")
        self.assertEqual(dates[-1], "2026-11-13")
        self.assertEqual(dates, sorted(dates))
        self.assertEqual(len(dates), 10)

    def test_dates_missing_today_raises(self):
        payload = _dates_payload()
        del payload["today"]
        contract = {"name": "dates", "operation": "dinner_days",
                    "inputs": ["inputs/case.json"], "output": "outputs/dates.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("engines/dates/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"],
                         "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestCalendar(unittest.TestCase):
    def test_existing_dinner_detected(self):
        payload = _calendar_payload()
        payload["events"].append({
            "id": "d",
            "start": "2026-11-05T19:00",
            "end": "2026-11-05T19:10",
            "kind": "dinner",
            "attendees": [],
        })
        contract = {"name": "calendar", "operation": "dinner_calendar_index",
                    "inputs": ["inputs/case.json"], "output": "outputs/calendar.json"}
        res = call_candidate("engines/calendar/transform.py", "transform",
                             args=[[payload], contract])
        self.assertEqual(res["result"]["existing_dinners"], ["2026-11-05"])

    def test_attendee_not_in_contacts_raises(self):
        payload = _calendar_payload()
        payload["events"][0]["attendees"] = ["ghost"]
        contract = {"name": "calendar", "operation": "dinner_calendar_index",
                    "inputs": ["inputs/case.json"], "output": "outputs/calendar.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("engines/calendar/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"],
                         "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestPlan(unittest.TestCase):
    def test_skip_existing_and_cancel_conflict(self):
        days = {"dates": ["2026-11-04", "2026-11-05"]}
        calendar = {
            "events": [
                {"id": "old", "start": "2026-11-04T19:30",
                 "end": "2026-11-04T20:30", "kind": "other",
                 "attendees": ["a"]},
            ],
            "existing_dinners": ["2026-11-05"],
        }
        contract = {"name": "plan", "operation": "dinner_change_plan",
                    "inputs": ["outputs/dates.json", "outputs/calendar.json"],
                    "output": "outputs/plan.json"}
        res = call_candidate("engines/plan/transform.py", "transform",
                             args=[[days, calendar], contract])
        added = res["result"]["added"]
        self.assertEqual([a["id"] for a in added], ["dinner-2026-11-04"])
        self.assertEqual(res["result"]["cancelled"], ["old"])

    def test_edge_end_exactly_19_not_cancelled(self):
        days = {"dates": ["2026-11-04"]}
        calendar = {
            "events": [
                {"id": "edge", "start": "2026-11-04T18:00",
                 "end": "2026-11-04T19:00", "kind": "other",
                 "attendees": []},
            ],
            "existing_dinners": [],
        }
        contract = {"name": "plan", "operation": "dinner_change_plan",
                    "inputs": ["outputs/dates.json", "outputs/calendar.json"],
                    "output": "outputs/plan.json"}
        res = call_candidate("engines/plan/transform.py", "transform",
                             args=[[days, calendar], contract])
        self.assertEqual(res["result"]["cancelled"], [])


class TestNotifications(unittest.TestCase):
    def test_outbox_grouped_by_contact(self):
        plan = {
            "snapshots": [
                {"id": "x", "attendees": ["b", "a", "a"]},
                {"id": "y", "attendees": ["a"]},
            ]
        }
        contract = {"name": "notifications", "operation": "dinner_notifications",
                    "inputs": ["outputs/plan.json"],
                    "output": "outputs/notifications.json"}
        res = call_candidate("engines/notifications/transform.py", "transform",
                             args=[[plan], contract])
        outbox = res["result"]["outbox"]
        self.assertEqual(outbox[0], {"to": "a", "event_ids": ["x", "y"]})
        self.assertEqual(outbox[1], {"to": "b", "event_ids": ["x"]})


class TestApply(unittest.TestCase):
    def test_apply_removes_cancelled_adds_new(self):
        calendar = {"events": [
            {"id": "keep", "start": "2026-11-04T10:00",
             "end": "2026-11-04T11:00", "kind": "other", "attendees": []},
            {"id": "drop", "start": "2026-11-04T19:30",
             "end": "2026-11-04T20:30", "kind": "other", "attendees": []},
        ]}
        plan = {
            "cancelled": ["drop"],
            "added": [{"id": "dinner-2026-11-04",
                       "start": "2026-11-04T19:00",
                       "end": "2026-11-04T20:00",
                       "kind": "dinner", "attendees": []}],
        }
        notifications = {"outbox": []}
        contract = {"name": "apply", "operation": "dinner_apply",
                    "inputs": ["outputs/calendar.json", "outputs/plan.json",
                               "outputs/notifications.json"],
                    "output": "outputs/apply.json"}
        res = call_candidate("engines/apply/transform.py", "transform",
                             args=[[calendar, plan, notifications], contract])
        ids = [e["id"] for e in res["result"]["events"]]
        self.assertEqual(ids, ["dinner-2026-11-04", "keep"])


if __name__ == "__main__":
    unittest.main()
