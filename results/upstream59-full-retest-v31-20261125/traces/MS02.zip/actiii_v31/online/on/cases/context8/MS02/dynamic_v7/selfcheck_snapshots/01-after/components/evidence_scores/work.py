def compute(payload):
    """按主题输入顺序生成评分表；每行把具有效章节证据的论文 ID 映射到该主题最高质量分。"""
    topics = payload["topics"]
    papers = payload["papers"]
    rows = []
    for topic in topics:
        row = {}
        for paper in papers:
            methods = set(paper["methods"])
            best = None
            for claim_topic, section, quality in paper["claims"]:
                if claim_topic == topic and section in methods:
                    if best is None or quality > best:
                        best = quality
            if best is not None:
                row[paper["id"]] = best
        rows.append(row)
    return rows
