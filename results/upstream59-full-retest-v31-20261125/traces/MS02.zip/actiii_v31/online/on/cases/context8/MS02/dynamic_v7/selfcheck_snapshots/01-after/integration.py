def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    topics = payload["topics"]
    papers = payload["papers"]
    scores = left  # list of dicts, one per topic in order
    graph_facts = right  # deduped sorted existing graph triples

    # Build candidate (paper_id -> quality) per topic from scores.
    candidates = []
    for topic, row in zip(topics, scores):
        candidates.append([(pid, q) for pid, q in row.items()])

    # Find assignment maximizing min quality, then total quality, then
    # lexicographically smallest paper-id sequence.
    n = len(topics)
    best = None

    def search(i, used, chosen, total, minimum):
        nonlocal best
        if i == n:
            key = (minimum, total, tuple(chosen))
            if best is None or key > best[0]:
                best = (key, list(chosen))
            return
        for pid, q in candidates[i]:
            if pid in used:
                continue
            used.add(pid)
            chosen.append(pid)
            new_min = q if minimum is None else min(minimum, q)
            search(i + 1, used, chosen, total + q, new_min)
            chosen.pop()
            used.remove(pid)

    search(0, set(), [], 0, None)

    if best is None:
        return None

    chosen = best[1]
    review = []
    for topic, pid in zip(topics, chosen):
        q = dict(candidates[topics.index(topic)])[pid]
        review.append([topic, pid, q])

    # Merge existing graph facts with supports edges, dedupe and sort.
    merged = set(tuple(t) for t in graph_facts)
    for topic, pid in zip(topics, chosen):
        merged.add((pid, "supports", topic))
    graph = sorted([list(t) for t in merged], key=lambda t: tuple(t))

    return {"review": review, "graph": graph}
