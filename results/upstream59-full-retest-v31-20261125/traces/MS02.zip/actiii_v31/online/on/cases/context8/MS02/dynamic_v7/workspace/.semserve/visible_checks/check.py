import unittest

API_BOUNDARY_REQUIREMENTS = []


class TransformBehaviorTests(unittest.TestCase):
    def test_empty_topics_returns_empty_review_and_sorted_graph(self):
        # TASK.md: 空主题表对应空综述及原图边的去重排序。
        payload = {
            "topics": [],
            "papers": [],
            "graph": [["b", "r", "a"], ["a", "r", "b"], ["b", "r", "a"]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["review"], [])
        self.assertEqual(result["graph"], [["a", "r", "b"], ["b", "r", "a"]])

    def test_infeasible_assignment_returns_null(self):
        # TASK.md: 无完整分配返回 null。
        payload = {
            "topics": ["t1", "t2"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsNone(result)

    def test_tie_break_lexicographically_smallest_paper_ids(self):
        # TASK.md: 依次最大化最低质量、总质量，再取论文ID序列字典序最小解。
        payload = {
            "topics": ["t1", "t2"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "m", 5], ["t2", "m", 5]]},
                {"id": "p1", "methods": ["m"], "claims": [["t1", "m", 5], ["t2", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # Both assignments have min=5, total=10; lexicographically smallest id seq is [p0, p1].
        self.assertEqual([r[1] for r in result["review"]], ["p0", "p1"])
        self.assertEqual([r[2] for r in result["review"]], [5, 5])

    def test_max_quality_per_topic_and_supports_edges(self):
        # TASK.md: 同题同论文保留最大质量；graph 为既有边与 supports 边的去重并集。
        payload = {
            "topics": ["t1"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "m", 3], ["t1", "m", 7]]},
            ],
            "graph": [["p0", "supports", "t1"]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["review"], [["t1", "p0", 7]])
        self.assertEqual(result["graph"], [["p0", "supports", "t1"]])


if __name__ == "__main__":
    unittest.main()
