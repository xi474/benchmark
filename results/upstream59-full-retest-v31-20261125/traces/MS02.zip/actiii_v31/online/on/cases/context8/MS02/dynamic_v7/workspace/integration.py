def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    topics = payload["topics"]
    papers = payload["papers"]
    scores = left  # list of dicts, one per topic in order
    graph_facts = right  # deduped sorted existing graph triples

    # Build candidate (paper_id -> quality) per topic from scores.
    candidates = []
    for topic, row in zip(topics, scores):
        candidates.append(sorted(row.items(), key=lambda x: x[0]))

    # Find assignment maximizing min quality, then total quality, then
    # lexicographically smallest paper-id sequence.
    n = len(topics)

    # Enumerate all full assignments and pick the best by (min, total, id-seq).
    # The id sequence is compared lexicographically; smaller is better.
    all_solutions = []

    def collect(i, used, chosen, total, minimum):
        if i == n:
            all_solutions.append((minimum, total, tuple(chosen)))
            return
        for pid, q in candidates[i]:
            if pid in used:
                continue
            used.add(pid)
            chosen.append(pid)
            new_min = q if minimum is None else min(minimum, q)
            collect(i + 1, used, chosen, total + q, new_min)
            chosen.pop()
            used.remove(pid)

    collect(0, set(), [], 0, None)
    if not all_solutions:
        return None
    # Maximize min, then total, then minimize id sequence lexicographically.
    best_key = max(all_solutions, key=lambda s: (s[0], s[1], tuple(-ord(c) for c in s[2])))
    chosen = list(best_key[2])

    review = []
    for topic, pid in zip(topics, chosen):
        q = dict(candidates[topics.index(topic)])[pid]
        review.append([topic, pid, q])

    # Merge existing graph facts with supports edges, dedupe and sort.
    merged = set(tuple(t) for t in graph_facts)
    for topic, pid in zip(topics, chosen):
        merged.add((pid, "supports", topic))
    graph = sorted([list(t) for t in merged], key=lambda t: tuple(t))

    return {"review": review, "graph": graph}
