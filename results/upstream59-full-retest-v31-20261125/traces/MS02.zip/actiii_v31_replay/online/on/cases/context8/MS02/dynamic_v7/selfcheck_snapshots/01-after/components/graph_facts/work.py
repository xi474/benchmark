def compute(payload):
    """返回去重并按三元组字典序排列的已有图事实。"""
    graph = payload.get("graph", [])
    seen = set()
    facts = []
    for triple in graph:
        key = tuple(triple)
        if key not in seen:
            seen.add(key)
            facts.append(list(triple))
    facts.sort(key=lambda t: tuple(t))
    return facts
