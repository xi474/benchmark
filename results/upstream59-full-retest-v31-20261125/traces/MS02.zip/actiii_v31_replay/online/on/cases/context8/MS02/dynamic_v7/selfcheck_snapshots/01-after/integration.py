def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    topics = payload["topics"]
    papers = payload["papers"]
    scores = left          # list of dicts, one per topic in order
    graph_facts = right    # deduped sorted existing graph triples

    # Build candidate (paper_id -> quality) per topic index.
    paper_ids = [p["id"] for p in papers]
    cand = []
    for i, topic in enumerate(topics):
        row = scores[i]
        cand.append({pid: q for pid, q in row.items()})

    # Find assignment maximizing min quality, then total quality, then
    # lexicographically smallest paper-id sequence. Each topic picks one
    # distinct paper.
    n = len(topics)
    best = None
    best_min = -1
    best_total = -1

    def search(i, used, chosen, cur_min, cur_total):
        nonlocal best, best_min, best_total
        if i == n:
            if best is None or (cur_min, cur_total, chosen) > (best_min, best_total, best):
                best = chosen[:]
                best_min = cur_min
                best_total = cur_total
            return
        for pid in paper_ids:
            if pid in used:
                continue
            if pid not in cand[i]:
                continue
            q = cand[i][pid]
            search(i + 1, used | {pid}, chosen + [pid],
                   min(cur_min, q) if cur_min >= 0 else q,
                   cur_total + q)

    search(0, set(), [], -1, 0)

    if best is None:
        return None

    review = [[topics[i], best[i], cand[i][best[i]]] for i in range(n)]

    # Merge existing graph facts with supports edges, dedupe, sort.
    edges = [list(t) for t in graph_facts]
    for i in range(n):
        edges.append([best[i], "supports", topics[i]])
    seen = set()
    merged = []
    for e in edges:
        key = tuple(e)
        if key not in seen:
            seen.add(key)
            merged.append(e)
    merged.sort(key=lambda t: tuple(t))

    return {"review": review, "graph": merged}
