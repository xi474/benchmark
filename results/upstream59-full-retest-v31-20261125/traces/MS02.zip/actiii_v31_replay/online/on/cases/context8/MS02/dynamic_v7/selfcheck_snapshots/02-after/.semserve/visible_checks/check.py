import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent

visible_document = str(ROOT / "TASK.md")


def load(path):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": visible_document,
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "公开规格未声明 transform 对非有限数值或未知字段抛出 ValueError。",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": visible_document,
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "公开规格未声明 transform 对非对象 payload 抛出 ValueError。",
            },
        },
    },
]


class TestReviewAssignment(unittest.TestCase):
    def test_public_fixture_review(self):
        # 公开样例：验证完整分配与图合并的确定性结果。
        payload = load("public_input.json")
        expected = load("public_expected.json")
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["review"], expected["review"])
        self.assertEqual(result["graph"], expected["graph"])

    def test_empty_topics_returns_empty_review(self):
        # 空主题表对应空综述及原图边的去重排序。
        payload = {
            "topics": [],
            "papers": [],
            "graph": [["a", "r", "b"], ["a", "r", "b"], ["x", "y", "z"]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["review"], [])
        self.assertEqual(result["graph"], [["a", "r", "b"], ["x", "y", "z"]])

    def test_infeasible_returns_none(self):
        # 无完整分配返回 null：主题多于可用论文。
        payload = {
            "topics": ["t1", "t2"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsNone(result)

    def test_tie_break_lexicographic(self):
        # 依次最大化最低质量、总质量，再取论文ID序列字典序最小。
        payload = {
            "topics": ["t1", "t2"],
            "papers": [
                {"id": "pA", "methods": ["m"], "claims": [["t1", "m", 5], ["t2", "m", 5]]},
                {"id": "pB", "methods": ["m"], "claims": [["t1", "m", 5], ["t2", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual([r[1] for r in result["review"]], ["pB", "pA"])

    def test_maximize_min_quality(self):
        # 最低质量优先于总质量：牺牲总质量换取更高最低质量。
        payload = {
            "topics": ["t1", "t2"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "m", 10], ["t2", "m", 1]]},
                {"id": "p1", "methods": ["m"], "claims": [["t1", "m", 5], ["t2", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual([r[1] for r in result["review"]], ["p0", "p1"])

    def test_only_methods_sections_valid(self):
        # 仅支撑章节列于 methods 的候选可用。
        payload = {
            "topics": ["t1"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "discussion", 99], ["t1", "m", 3]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["review"], [["t1", "p0", 3]])


if __name__ == "__main__":
    unittest.main()
