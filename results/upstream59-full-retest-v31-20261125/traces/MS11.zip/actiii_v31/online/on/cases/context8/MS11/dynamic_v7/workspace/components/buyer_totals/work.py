def compute(payload):
    """按买家 ID 汇总属于 Cameras 或 Electronics 的行金额，每行只计一次；无购买为零。"""
    totals = {buyer: 0 for buyer in payload["buyers"]}
    for order in payload["orders"]:
        buyer = order["buyer"]
        for line in order["lines"]:
            categories, qty, unit_price = line
            if "Cameras" in categories or "Electronics" in categories:
                totals[buyer] = totals.get(buyer, 0) + qty * unit_price
    return totals
