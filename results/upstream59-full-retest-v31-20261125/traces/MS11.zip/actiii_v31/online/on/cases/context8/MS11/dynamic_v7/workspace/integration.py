def _build_confidence(evidence):
    """Return dict[(student, buyer)] = confidence, and set of sources."""
    conf = {}
    for source, student, buyer, strength in evidence:
        key = (student, buyer)
        prev = conf.get(key)
        if prev is None:
            conf[key] = (source, strength)
        else:
            src, val = prev
            if src == source:
                if strength > val:
                    conf[key] = (source, strength)
            else:
                conf[key] = (None, val + strength)
    return conf


def _solve_component(students, buyers, conf):
    """Enumerate all perfect matchings in each connected component."""
    adj = {s: [] for s in students}
    for (s, b), (_, w) in conf.items():
        if s in adj and b in buyers:
            adj[s].append((b, w))

    seen_s = set()
    components = []
    for s in students:
        if s in seen_s:
            continue
        stack = [s]
        comp_s = set()
        comp_b = set()
        while stack:
            cur = stack.pop()
            if cur in comp_s:
                continue
            comp_s.add(cur)
            for b, _ in adj[cur]:
                comp_b.add(b)
                for (s2, b2), (_, _w) in conf.items():
                    if b2 == b and s2 not in comp_s:
                        stack.append(s2)
        components.append((sorted(comp_s), sorted(comp_b)))

    results = []
    for comp_s, comp_b in components:
        matchings = []
        s_list = comp_s

        def backtrack(i, used, cur_map):
            if i == len(s_list):
                matchings.append(dict(cur_map))
                return
            s = s_list[i]
            for b, w in adj[s]:
                if b in used:
                    continue
                used.add(b)
                cur_map[s] = b
                backtrack(i + 1, used, cur_map)
                used.discard(b)
                del cur_map[s]

        backtrack(0, set(), {})
        results.append((comp_s, comp_b, matchings))

    return results


def _combine_components(comp_results):
    """Combine per-component matchings into full matchings with floor/total."""
    full = []

    def rec(idx, cur_map, cur_floor, cur_total):
        if idx == len(comp_results):
            full.append((dict(cur_map), cur_floor, cur_total))
            return
        comp_s, comp_b, matchings = comp_results[idx]
        for m in matchings:
            floor = min(m.values()) if m else None
            total = sum(m.values())
            if cur_floor is None:
                new_floor = floor
            elif floor is None:
                new_floor = cur_floor
            else:
                new_floor = min(cur_floor, floor)
            rec(idx + 1, {**cur_map, **m}, new_floor, cur_total + total)

    rec(0, {}, None, 0)
    return full


def _compute_result(students, buyers, X, Y, conf):
    """Compute the result dict for a given confidence mapping."""
    n = len(students)
    comp_results = _solve_component(students, buyers, conf)

    all_s = set()
    all_b = set()
    for comp_s, comp_b, matchings in comp_results:
        all_s.update(comp_s)
        all_b.update(comp_b)
    if all_s != set(students) or all_b != set(buyers) or not comp_results:
        return None

    full = _combine_components(comp_results)
    if not full:
        return None

    best_floor = max(f[1] for f in full)
    cand = [f for f in full if f[1] == best_floor]
    best_total = max(f[2] for f in cand)
    optimal = [f for f in cand if f[2] == best_total]

    count = len(optimal)

    sorted_students = sorted(students)
    min_buyers = None
    max_buyers = None
    min_num = None
    max_num = None
    for mapping, _, _ in optimal:
        sxy = sum(X[s] * Y[mapping[s]] for s in students)
        sx = sum(X[s] for s in students)
        sy = sum(Y[mapping[s]] for s in students)
        num = n * sxy - sx * sy
        if min_num is None or num < min_num:
            min_num = num
        if max_num is None or num > max_num:
            max_num = num
        vec = [mapping[s] for s in sorted_students]
        if num == min_num and (min_buyers is None or vec < min_buyers):
            min_buyers = vec
        if num == max_num and (max_buyers is None or vec < max_buyers):
            max_buyers = vec

    forced = []
    for s in sorted_students:
        bs = set(m[s] for m, _, _ in optimal)
        if len(bs) == 1:
            forced.append([s, bs.pop()])

    return {
        "floor": best_floor,
        "total": best_total,
        "count": count,
        "min_num": min_num,
        "max_num": max_num,
        "min_buyers": min_buyers,
        "max_buyers": max_buyers,
        "forced": forced,
    }


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    students = payload["students"]
    buyers = payload["buyers"]
    X = left
    Y = right

    evidence = payload["evidence"]
    drop = payload["drop"]

    full_conf = _build_confidence(evidence)

    results = []
    for d in drop:
        if d is None:
            conf = full_conf
        else:
            conf = _build_confidence([e for e in evidence if e[0] != d])

        result = _compute_result(students, buyers, X, Y, conf)
        results.append({"drop": d, "result": result})

    return results
