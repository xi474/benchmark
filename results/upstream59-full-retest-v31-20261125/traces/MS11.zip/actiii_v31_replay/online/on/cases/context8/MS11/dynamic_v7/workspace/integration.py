from itertools import permutations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    students = payload["students"]
    buyers = payload["buyers"]
    n = len(students)

    # X: integer grade mean (already computed by student_scores component).
    X = {s: left[s] for s in students}
    # Y: buyer total spend (already computed by buyer_totals component).
    Y = {b: right[b] for b in buyers}

    # Build evidence confidence: per (source, student, buyer) keep max strength,
    # then sum across sources.
    def build_confidence(evidence):
        per_source = {}
        for source, student, buyer, strength in evidence:
            key = (source, student, buyer)
            if key not in per_source or strength > per_source[key]:
                per_source[key] = strength
        conf = {}
        for (source, student, buyer), strength in per_source.items():
            conf[(student, buyer)] = conf.get((student, buyer), 0) + strength
        return conf

    def solve(evidence):
        conf = build_confidence(evidence)
        # Only pairs with evidence are usable.
        # Decompose into connected components of the bipartite graph.
        # Build adjacency.
        adj_s = {s: set() for s in students}
        adj_b = {b: set() for b in buyers}
        for (s, b) in conf:
            adj_s[s].add(b)
            adj_b[b].add(s)

        # Find connected components.
        seen_s = set()
        seen_b = set()
        components = []
        for s in students:
            if s in seen_s:
                continue
            # BFS over bipartite graph.
            stack = [("s", s)]
            comp_s = set()
            comp_b = set()
            while stack:
                kind, node = stack.pop()
                if kind == "s":
                    if node in comp_s:
                        continue
                    comp_s.add(node)
                    for b in adj_s[node]:
                        if b not in comp_b:
                            stack.append(("b", b))
                else:
                    if node in comp_b:
                        continue
                    comp_b.add(node)
                    for s2 in adj_b[node]:
                        if s2 not in comp_s:
                            stack.append(("s", s2))
            components.append((sorted(comp_s), sorted(comp_b)))
            seen_s |= comp_s
            seen_b |= comp_b

        # For each component, enumerate all perfect matchings (bijections)
        # using only evidence-backed pairs. Component sizes <= 14 per side.
        # A perfect matching must cover all students and all buyers in the
        # component (equal sizes since global lists are equal length and
        # every student/buyer must be matched).
        all_matchings = []
        for comp_s, comp_b in components:
            if len(comp_s) != len(comp_b):
                return None  # no complete mapping possible
            # Enumerate permutations of buyers for this component's students.
            matchings = []
            for perm in permutations(comp_b):
                ok = True
                for s, b in zip(comp_s, perm):
                    if (s, b) not in conf:
                        ok = False
                        break
                if ok:
                    matchings.append(list(zip(comp_s, perm)))
            if not matchings:
                return None
            all_matchings.append(matchings)

        # Combine component matchings into full mappings.
        full_mappings = [[]]
        for comp_matchings in all_matchings:
            new_full = []
            for partial in full_mappings:
                for m in comp_matchings:
                    new_full.append(partial + m)
            full_mappings = new_full

        if not full_mappings:
            return None

        # Score each mapping: floor = min confidence, total = sum confidence.
        best_floor = -1
        best_total = -1
        best_mappings = []
        for mapping in full_mappings:
            floor = min(conf[pair] for pair in mapping)
            total = sum(conf[pair] for pair in mapping)
            if floor > best_floor or (floor == best_floor and total > best_total):
                best_floor = floor
                best_total = total
                best_mappings = [mapping]
            elif floor == best_floor and total == best_total:
                best_mappings.append(mapping)

        count = len(best_mappings)

        # Compute association numerator for each optimal mapping.
        def numerator(mapping):
            # mapping is list of (student, buyer) pairs.
            sX = sum(X[s] for s, _ in mapping)
            sY = sum(Y[b] for _, b in mapping)
            sXY = sum(X[s] * Y[b] for s, b in mapping)
            return n * sXY - sX * sY

        nums = [numerator(m) for m in best_mappings]
        min_num = min(nums)
        max_num = max(nums)

        # Lexicographically smallest buyer vector (students sorted ascending).
        def buyer_vector(mapping):
            d = dict(mapping)
            return [d[s] for s in students]

        min_vec = None
        max_vec = None
        for m, num in zip(best_mappings, nums):
            vec = buyer_vector(m)
            if num == min_num and (min_vec is None or vec < min_vec):
                min_vec = vec
            if num == max_num and (max_vec is None or vec < max_vec):
                max_vec = vec

        # Forced pairs: pairs present in all optimal mappings.
        forced = []
        for s in students:
            bs = set(dict(m)[s] for m in best_mappings)
            if len(bs) == 1:
                forced.append([s, next(iter(bs))])
        forced.sort(key=lambda p: students.index(p[0]))

        return {
            "floor": best_floor,
            "total": best_total,
            "count": count,
            "min_num": min_num,
            "max_num": max_num,
            "min_buyers": min_vec,
            "max_buyers": max_vec,
            "forced": forced,
        }

    result = []
    for drop in payload["drop"]:
        if drop is None:
            evidence = payload["evidence"]
        else:
            evidence = [e for e in payload["evidence"] if e[0] != drop]
        res = solve(evidence)
        result.append({"drop": drop, "result": res})

    return result
