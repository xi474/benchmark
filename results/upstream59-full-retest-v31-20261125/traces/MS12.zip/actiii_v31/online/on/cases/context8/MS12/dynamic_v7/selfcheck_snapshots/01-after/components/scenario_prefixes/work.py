def compute(payload):
    """输出 [信号历史,该完整叶的权重或 null]，去重生成所有非空前缀，按历史字典序排列。"""
    scenarios = payload["scenarios"]
    leaves = {}
    for sc in scenarios:
        sig = tuple(sc["signals"])
        leaves[sig] = sc["weight"]
    prefixes = set()
    for sig in leaves:
        for i in range(1, len(sig) + 1):
            prefixes.add(sig[:i])
    result = []
    for p in sorted(prefixes):
        result.append([list(p), leaves.get(p)])
    return result
