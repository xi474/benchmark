import itertools


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]
    budget = payload["budget"]
    scenarios = payload["scenarios"]

    # left: list of [history, leaf_weight_or_null] sorted lexicographically.
    # right: dict signal -> list of eligible dish ids (recipes order).
    histories = [h for h, _ in left]

    # Build recipe lookup.
    recipe_by_id = {r["id"]: r for r in recipes}

    # Group info: (name, count, banned set, liked cats set)
    group_info = []
    for g in groups:
        name, count, banned, liked = g[0], g[1], g[2], g[3]
        group_info.append((name, count, set(banned), set(liked)))

    # For each scenario, its full signal path and weight.
    scenario_paths = []
    for sc in scenarios:
        scenario_paths.append((tuple(sc["signals"]), sc["weight"]))

    # Map each history (prefix) to the set of scenarios that share it.
    prefix_to_scenarios = {}
    for idx, (sig, w) in enumerate(scenario_paths):
        for d in range(1, len(sig) + 1):
            p = sig[:d]
            prefix_to_scenarios.setdefault(p, set()).add(idx)

    # For each history, eligible dishes = right[last_signal].
    history_signal = [h[-1] for h in histories]
    history_eligible = [right[s] for s in history_signal]

    dish_cat = {r["id"]: r["cat"] for r in recipes}
    dish_cost = {r["id"]: r["cost"] for r in recipes}

    def dish_satisfaction(dish_id):
        return [1 if dish_cat[dish_id] in liked else 0
                for (_, _, _, liked) in group_info]

    n_histories = len(histories)
    n_scenarios = len(scenario_paths)

    # DFS over histories. State per scenario: (last_dish, last_cat, used_set, cost, sat)
    best = None  # (key, utility, cost, floor)

    def dfs(hi, state):
        nonlocal best
        if hi == n_histories:
            floor = None
            weighted_utility = 0
            weighted_cost = 0
            for si, (sig, w) in enumerate(scenario_paths):
                s = state[si]
                sat = s[4]
                svc = min(sat)
                if floor is None or svc < floor:
                    floor = svc
                u = sum(sat[gi] * cnt for gi, (_, cnt, _, _) in enumerate(group_info))
                weighted_utility += w * u
                weighted_cost += w * s[3]
            key = (floor, weighted_utility, -weighted_cost)
            if best is None or key > best[0]:
                best = (key, weighted_utility, weighted_cost, floor)
            return

        for dish in history_eligible[hi]:
            ok = True
            new_state = list(state)
            for si in prefix_to_scenarios.get(tuple(histories[hi]), ()):
                s = state[si]
                if s is None:
                    last_dish = None
                    last_cat = None
                    used = set()
                    cost = 0
                    sat = [0] * len(group_info)
                else:
                    last_dish, last_cat, used, cost, sat = s
                if dish in used:
                    ok = False
                    break
                if last_cat is not None and dish_cat[dish] == last_cat:
                    ok = False
                    break
                new_cost = cost + dish_cost[dish]
                if new_cost > budget:
                    ok = False
                    break
                new_used = used | {dish}
                new_sat = list(sat)
                for gi in range(len(group_info)):
                    new_sat[gi] += dish_satisfaction(dish)[gi]
                new_state[si] = (dish, dish_cat[dish], new_used, new_cost, new_sat)
            if not ok:
                continue
            dfs(hi + 1, tuple(new_state))

    initial_state = tuple(None for _ in range(n_scenarios))
    dfs(0, initial_state)

    if best is None:
        return {"histories": histories, "optimal": None}

    opt_key, opt_utility, opt_cost, opt_floor = best

    # Phase 2: enumerate all optimal policies.
    all_menus = []
    allowed_sets = [set() for _ in range(n_histories)]

    def dfs2(hi, state, menu):
        if hi == n_histories:
            floor = None
            weighted_utility = 0
            weighted_cost = 0
            for si, (sig, w) in enumerate(scenario_paths):
                s = state[si]
                sat = s[4]
                svc = min(sat)
                if floor is None or svc < floor:
                    floor = svc
                u = sum(sat[gi] * cnt for gi, (_, cnt, _, _) in enumerate(group_info))
                weighted_utility += w * u
                weighted_cost += w * s[3]
            if (floor, weighted_utility, -weighted_cost) == opt_key:
                all_menus.append(tuple(menu))
                for i, d in enumerate(menu):
                    allowed_sets[i].add(d)
            return

        for dish in history_eligible[hi]:
            ok = True
            new_state = list(state)
            for si in prefix_to_scenarios.get(tuple(histories[hi]), ()):
                s = state[si]
                if s is None:
                    last_dish = None
                    last_cat = None
                    used = set()
                    cost = 0
                    sat = [0] * len(group_info)
                else:
                    last_dish, last_cat, used, cost, sat = s
                if dish in used:
                    ok = False
                    break
                if last_cat is not None and dish_cat[dish] == last_cat:
                    ok = False
                    break
                new_cost = cost + dish_cost[dish]
                if new_cost > budget:
                    ok = False
                    break
                new_used = used | {dish}
                new_sat = list(sat)
                for gi in range(len(group_info)):
                    new_sat[gi] += dish_satisfaction(dish)[gi]
                new_state[si] = (dish, dish_cat[dish], new_used, new_cost, new_sat)
            if not ok:
                continue
            dfs2(hi + 1, tuple(new_state), menu + [dish])

    dfs2(0, initial_state, [])

    menu = list(min(all_menus))
    allowed = [sorted(allowed_sets[i]) for i in range(n_histories)]
    count = len(all_menus)

    return {
        "histories": histories,
        "optimal": {
            "floor": opt_floor,
            "utility": opt_utility,
            "cost": opt_cost,
            "count": count,
            "menu": menu,
            "allowed": allowed,
        },
    }
