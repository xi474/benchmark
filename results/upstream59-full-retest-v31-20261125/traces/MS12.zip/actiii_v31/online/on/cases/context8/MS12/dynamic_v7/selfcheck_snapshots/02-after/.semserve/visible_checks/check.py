import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type for expected candidate failures


class TransformBehaviorTests(unittest.TestCase):
    """High-risk behavior checks not established by the public fixture."""

    def test_infeasible_budget_yields_null_optimal(self):
        # A budget too small to serve any single day makes the policy infeasible.
        payload = {
            "recipes": [
                {"id": "R0", "cat": "soup", "ingredients": ["rice"], "difficulty": 1, "cost": 5},
                {"id": "R1", "cat": "veg", "ingredients": ["bean"], "difficulty": 1, "cost": 5},
            ],
            "groups": [["g", 1, [], ["soup"]]],
            "delivery": {"A": ["rice"], "B": ["bean"]},
            "budget": 3,
            "scenarios": [{"signals": ["A", "B"], "weight": 1}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertIn("histories", result)
        self.assertIsNone(result["optimal"])

    def test_floor_and_utility_hand_calculation(self):
        # Two groups, one likes soup, one likes veg. Day A only soup eligible,
        # day B only veg eligible. Each group gets 1 satisfaction on its liked day.
        payload = {
            "recipes": [
                {"id": "R0", "cat": "soup", "ingredients": ["rice"], "difficulty": 1, "cost": 1},
                {"id": "R1", "cat": "veg", "ingredients": ["bean"], "difficulty": 1, "cost": 1},
            ],
            "groups": [
                ["g1", 2, [], ["soup"]],
                ["g2", 3, [], ["veg"]],
            ],
            "delivery": {"A": ["rice"], "B": ["bean"]},
            "budget": 10,
            "scenarios": [{"signals": ["A", "B"], "weight": 1}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        opt = result["optimal"]
        self.assertIsNotNone(opt)
        # g1 satisfied on day A (soup), g2 satisfied on day B (veg).
        # service score = min(1, 1) = 1; utility = 2*1 + 3*1 = 5.
        self.assertEqual(opt["floor"], 1)
        self.assertEqual(opt["utility"], 5)
        self.assertEqual(opt["cost"], 2)
        self.assertEqual(opt["menu"], ["R0", "R1"])

    def test_adjacent_same_category_forbidden(self):
        # Only soup dishes available on both days; adjacent same category is
        # forbidden, so no feasible policy exists.
        payload = {
            "recipes": [
                {"id": "R0", "cat": "soup", "ingredients": ["rice"], "difficulty": 1, "cost": 1},
                {"id": "R1", "cat": "soup", "ingredients": ["bean"], "difficulty": 1, "cost": 1},
            ],
            "groups": [["g", 1, [], ["soup"]]],
            "delivery": {"A": ["rice"], "B": ["bean"]},
            "budget": 10,
            "scenarios": [{"signals": ["A", "B"], "weight": 1}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsNone(result["optimal"])


if __name__ == "__main__":
    unittest.main()
