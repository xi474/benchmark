def compute(payload):
    """为每个查询逐时隙列出当时可见且实际不可用（down 或 degraded）的域名数组，升序。

    只取收录时刻（seen）不大于 as_of 的记录；在每个整数时隙 t 取生效时刻（effective）
    不大于 t 的最新值，同一生效时刻取最后收录的版本。up 视为可用，其余视为不可用。
    """
    queries = payload["queries"]
    log = payload["log"]

    result = []
    for query in queries:
        as_of = query["as_of"]
        start = query["start"]
        end = query["end"]

        by_domain = {}
        for domain, effective, seen, status in log:
            if seen > as_of:
                continue
            by_domain.setdefault(domain, []).append((effective, seen, status))

        for records in by_domain.values():
            records.sort(key=lambda r: (r[0], r[1]))

        slots = []
        for t in range(start, end):
            down = []
            for domain, records in by_domain.items():
                latest = None
                for effective, seen, status in records:
                    if effective <= t:
                        latest = (effective, seen, status)
                    else:
                        break
                if latest is not None and latest[2] != "up":
                    down.append(domain)
            down.sort()
            slots.append(down)
        result.append(slots)

    return result
