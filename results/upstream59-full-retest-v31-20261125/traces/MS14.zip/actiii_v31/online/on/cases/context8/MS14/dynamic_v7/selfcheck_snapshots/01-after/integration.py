def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    domains = payload["domains"]
    services = payload["services"]
    queries = payload["queries"]

    quorums = right

    service_ids = [s["id"] for s in services]
    service_index = {s["id"]: i for i, s in enumerate(services)}

    deps = {}
    for s in services:
        deps[s["id"]] = list(s["inputs"])

    indeg = {sid: 0 for sid in service_ids}
    for sid in service_ids:
        for inp in deps[sid]:
            if inp in service_index:
                indeg[sid] += 1
    from collections import deque
    q = deque([sid for sid in service_ids if indeg[sid] == 0])
    topo = []
    while q:
        sid = q.popleft()
        topo.append(sid)
        for other in service_ids:
            if sid in deps[other]:
                indeg[other] -= 1
                if indeg[other] == 0:
                    q.append(other)

    results = []
    for qi, query in enumerate(queries):
        start = query["start"]
        end = query["end"]
        targets = query["targets"]

        slots_down = left[qi]

        target_avail = {t: {} for t in targets}

        for t in range(start, end):
            slot_index = t - start
            down_domains = set(slots_down[slot_index])

            avail = {}
            for d in domains:
                avail[d] = d not in down_domains

            for sid in topo:
                need = quorums[sid][0]
                inputs = quorums[sid][1]
                cnt = 0
                for inp in inputs:
                    if avail.get(inp, False):
                        cnt += 1
                avail[sid] = cnt >= need

            for tgt in targets:
                target_avail[tgt][t] = avail.get(tgt, False)

        incidents = []
        for tgt in targets:
            t = start
            while t < end:
                if not target_avail[tgt][t]:
                    s = t
                    while t < end and not target_avail[tgt][t]:
                        t += 1
                    incidents.append([tgt, s, t])
                else:
                    t += 1

        incidents.sort(key=lambda x: (x[0], x[1]))

        repairs = compute_minimal_repairs(
            domains, quorums, service_index, topo, targets,
            slots_down, start, end
        )

        results.append({"incidents": incidents, "repairs": repairs})

    return results


def compute_minimal_repairs(domains, quorums, service_index, topo, targets,
                            slots_down, start, end):
    candidate = set()
    for slot in slots_down:
        candidate.update(slot)
    candidate = sorted(candidate)

    if all_targets_available(domains, quorums, service_index, topo, targets,
                             slots_down, start, end, set()):
        return [[]]

    results = []
    from itertools import combinations
    max_size = len(candidate)
    for size in range(1, max_size + 1):
        for combo in combinations(candidate, size):
            S = set(combo)
            if all_targets_available(domains, quorums, service_index, topo,
                                     targets, slots_down, start, end, S):
                minimal = True
                for d in combo:
                    if all_targets_available(domains, quorums, service_index,
                                             topo, targets, slots_down, start,
                                             end, S - {d}):
                        minimal = False
                        break
                if minimal:
                    results.append(sorted(combo))
        if results:
            break

    results.sort(key=lambda x: (len(x), x))
    return results


def all_targets_available(domains, quorums, service_index, topo, targets,
                          slots_down, start, end, forced):
    for t in range(start, end):
        slot_index = t - start
        down_domains = set(slots_down[slot_index])
        avail = {}
        for d in domains:
            avail[d] = (d in forced) or (d not in down_domains)
        for sid in topo:
            need = quorums[sid][0]
            inputs = quorums[sid][1]
            cnt = 0
            for inp in inputs:
                if avail.get(inp, False):
                    cnt += 1
            avail[sid] = cnt >= need
        for tgt in targets:
            if not avail.get(tgt, False):
                return False
    return True
