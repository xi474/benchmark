import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform must reject non-finite values or unknown fields; it only requires returning the specified JSON value.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform must raise ValueError on invalid payload types.",
            },
        },
    },
]


class TestVisibleContract(unittest.TestCase):
    def test_transform_returns_expected_public_shape(self):
        # Public example: two queries, each with incidents and repairs.
        import json
        from pathlib import Path
        payload = json.loads(Path("public_input.json").read_text(encoding="utf-8"))
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)
        for item in result:
            self.assertIsInstance(item, dict)
            self.assertIn("incidents", item)
            self.assertIn("repairs", item)

    def test_repairs_are_inclusion_minimal_and_sorted(self):
        import json
        from pathlib import Path
        payload = json.loads(Path("public_input.json").read_text(encoding="utf-8"))
        result = call_candidate("solution.py", "transform", args=[payload])
        for item in result:
            repairs = item["repairs"]
            # sorted by size then lexicographic
            self.assertEqual(repairs, sorted(repairs, key=lambda x: (len(x), x)))
            for r in repairs:
                self.assertEqual(r, sorted(r))
                # no strict subset also present
                for other in repairs:
                    if other is not r and set(other) < set(r):
                        self.fail(f"non-minimal repair {r} has subset {other}")

    def test_incidents_sorted_and_merged(self):
        import json
        from pathlib import Path
        payload = json.loads(Path("public_input.json").read_text(encoding="utf-8"))
        result = call_candidate("solution.py", "transform", args=[payload])
        for item in result:
            incidents = item["incidents"]
            self.assertEqual(incidents, sorted(incidents, key=lambda x: (x[0], x[1])))
            for row in incidents:
                self.assertEqual(len(row), 3)
                self.assertLess(row[1], row[2])


if __name__ == "__main__":
    unittest.main()
