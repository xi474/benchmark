def _median_score(a, b, c, k):
    """Net score of a single customer whose three ratings are a, b, c."""
    med = sorted((a, b, c))[1]
    if med == k - 1:
        return 1
    if med == 0:
        return -1
    return 0


def _enumerate_layers(k, row_sums, col_sums, ac, forbidden_cells, b, out):
    matrix = [[0] * k for _ in range(k)]
    remaining_col = list(col_sums)

    def rec(a, c):
        if a == k:
            if all(remaining_col[cc] == 0 for cc in range(k)):
                vec = [matrix[i][j] for i in range(k) for j in range(k)]
                score = 0
                for i in range(k):
                    for j in range(k):
                        if matrix[i][j]:
                            score += matrix[i][j] * _median_score(i, b, j, k)
                out.append([vec, score])
            return
        if c == k:
            if sum(matrix[a]) == row_sums[a]:
                rec(a + 1, 0)
            return
        if (a, c) in forbidden_cells:
            matrix[a][c] = 0
            rec(a, c + 1)
            return
        used = sum(matrix[a][:c])
        max_val = min(row_sums[a] - used, remaining_col[c], ac[a][c])
        for v in range(max_val + 1):
            matrix[a][c] = v
            remaining_col[c] -= v
            rec(a, c + 1)
            remaining_col[c] += v
        matrix[a][c] = 0

    rec(0, 0)


def compute(payload):
    """为每个快照按 b 生成候选层数组。每层候选为 [按 a,c 行优先的计数向量,该层的中位数净分]，满足边际、禁止格和 ac 上限；按向量字典序。"""
    result = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)
        forbidden_set = set(tuple(t) for t in forbidden)
        per_b = []
        for b in range(k):
            row_sums = [ab[a][b] for a in range(k)]
            col_sums = [bc[b][c] for c in range(k)]
            forbidden_cells = set()
            for (a, bb, c) in forbidden_set:
                if bb == b:
                    forbidden_cells.add((a, c))
            candidates = []
            _enumerate_layers(k, row_sums, col_sums, ac, forbidden_cells, b, candidates)
            candidates.sort(key=lambda x: x[0])
            per_b.append(candidates)
        result.append(per_b)
    return result
