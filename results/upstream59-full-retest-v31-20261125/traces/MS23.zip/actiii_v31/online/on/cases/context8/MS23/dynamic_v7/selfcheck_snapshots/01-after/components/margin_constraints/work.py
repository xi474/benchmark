def compute(payload):
    """为每个快照输出 [ab 与 ac 各 a 总量是否相容,按 a,c 行优先展开的 ac 配额]。"""
    out = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        ac = snap["ac"]
        ab_totals = [sum(row) for row in ab]
        ac_totals = [sum(row) for row in ac]
        compatible = ab_totals == ac_totals
        quota = [cell for row in ac for cell in row]
        out.append([compatible, quota])
    return out
