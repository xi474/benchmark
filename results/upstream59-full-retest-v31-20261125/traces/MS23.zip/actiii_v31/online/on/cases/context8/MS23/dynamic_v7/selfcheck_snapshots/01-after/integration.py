def combine(payload, left, right):
    """left: margin_constraints value (list per snapshot of [compatible, ac_quota]).
    right: layer_candidates value (list per snapshot of per-b candidate layers).
    """
    snapshots = payload["snapshots"]
    out = []
    for idx, snap in enumerate(snapshots):
        ab = snap["ab"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)
        forbidden_set = set(tuple(t) for t in forbidden)

        compatible, ac_quota = left[idx]
        if not compatible:
            out.append(None)
            continue

        per_b_layers = right[idx]
        b_count = len(per_b_layers)

        tables = []
        scores = []

        def rec(b, current, total_score):
            if b == b_count:
                # Verify the ac projection matches the input ac table.
                for a in range(k):
                    for c in range(k):
                        if sum(current.get((a, bb, c), 0) for bb in range(k)) != ac[a][c]:
                            return
                tables.append(dict(current))
                scores.append(total_score)
                return
            for vec, score in per_b_layers[b]:
                for a in range(k):
                    for c in range(k):
                        v = vec[a * k + c]
                        if v:
                            current[(a, b, c)] = current.get((a, b, c), 0) + v
                rec(b + 1, current, total_score + score)
                for a in range(k):
                    for c in range(k):
                        v = vec[a * k + c]
                        if v:
                            current[(a, b, c)] -= v
                            if current[(a, b, c)] == 0:
                                del current[(a, b, c)]

        rec(0, {}, 0)

        if not tables:
            out.append(None)
            continue

        n_tables = len(tables)

        from collections import Counter
        score_counter = Counter(scores)
        spectrum = [[s, score_counter[s]] for s in sorted(score_counter)]

        guaranteed = []
        for a in range(k):
            for b in range(k):
                for c in range(k):
                    if (a, b, c) in forbidden_set:
                        continue
                    counts = [t.get((a, b, c), 0) for t in tables]
                    mn = min(counts)
                    if mn > 0:
                        guaranteed.append([a, b, c, mn])

        min_score = min(scores)
        min_tables = [t for t, s in zip(tables, scores) if s == min_score]

        def full_vector(t):
            return tuple(t.get((a, b, c), 0)
                         for a in range(k) for b in range(k) for c in range(k))

        witness_table = min(min_tables, key=full_vector)
        witness = []
        for a in range(k):
            for b in range(k):
                for c in range(k):
                    v = witness_table.get((a, b, c), 0)
                    if v > 0:
                        witness.append([a, b, c, v])

        out.append({
            "tables": n_tables,
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": witness,
        })

    return out
