import unittest


class TestTransform(unittest.TestCase):
    def test_public_snapshot_shapes(self):
        payload = {
            "snapshots": [
                {
                    "ab": [[1, 1], [1, 1]],
                    "bc": [[1, 1], [1, 1]],
                    "ac": [[1, 1], [1, 1]],
                    "forbidden": [],
                },
                {
                    "ab": [[1, 1], [1, 1]],
                    "bc": [[1, 1], [1, 1]],
                    "ac": [[1, 1], [1, 1]],
                    "forbidden": [[1, 0, 1]],
                },
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["tables"], 2)
        self.assertEqual(result[0]["spectrum"], [[-2, 1], [2, 1]])
        self.assertEqual(result[0]["guaranteed"], [])
        self.assertEqual(result[1]["tables"], 1)
        self.assertEqual(result[1]["spectrum"], [[-2, 1]])

    def test_infeasible_snapshot_returns_null(self):
        payload = {
            "snapshots": [
                {
                    "ab": [[2, 0], [0, 0]],
                    "bc": [[0, 0], [0, 0]],
                    "ac": [[0, 0], [0, 0]],
                    "forbidden": [],
                }
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [None])


if __name__ == "__main__":
    unittest.main()
