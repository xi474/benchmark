def compute(payload):
    """为有截止日的作业返回 [需求,合格时段 ID 升序数组]，先按原始时段和七天半开窗口筛选。"""
    assignments = payload["assignments"]
    slots = payload["slots"]

    slot_days = {}
    for slot_id, day, capacity in slots:
        slot_days[slot_id] = day

    result = {}
    for assignment in assignments:
        assignment_id, due, demand, serviceable = assignment
        if due is None:
            continue
        eligible = []
        for slot_id in serviceable:
            day = slot_days[slot_id]
            if due - 7 <= day < due:
                eligible.append(slot_id)
        eligible.sort()
        result[assignment_id] = [demand, eligible]

    return result
