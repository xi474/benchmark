from fractions import Fraction


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    assignments = payload["assignments"]
    withdrawals = payload["withdrawals"]

    results = []
    for scenario in right:
        slot_cap = {sid: cap for sid, (day, cap) in scenario.items()}

        served = {}
        unserved = []
        for aid, (demand, eligible) in left.items():
            avail = [sid for sid in eligible if sid in slot_cap]
            if not avail:
                unserved.append(aid)
            else:
                served[aid] = (demand, avail)

        if not left:
            results.append({"empty": True})
            continue

        if unserved:
            results.append({"unserved": sorted(unserved)})
            continue

        aids = sorted(served.keys())

        slot_to_assign = {}
        for aid in aids:
            for sid in served[aid][1]:
                slot_to_assign.setdefault(sid, set()).add(aid)

        visited = set()
        components = []
        for aid in aids:
            if aid in visited:
                continue
            comp = set()
            stack = [aid]
            while stack:
                cur = stack.pop()
                if cur in visited:
                    continue
                visited.add(cur)
                comp.add(cur)
                for sid in served[cur][1]:
                    for nb in slot_to_assign[sid]:
                        if nb not in visited:
                            stack.append(nb)
            components.append(comp)

        best = None
        tight_sets = []

        for comp in components:
            comp_list = sorted(comp)
            m = len(comp_list)
            demands = {aid: served[aid][0] for aid in comp_list}
            for mask in range(1, 1 << m):
                subset = [comp_list[i] for i in range(m) if mask & (1 << i)]
                demand_sum = sum(demands[a] for a in subset)
                union_slots = set()
                for a in subset:
                    union_slots.update(served[a][1])
                cap_sum = sum(slot_cap[s] for s in union_slots)
                ratio = Fraction(demand_sum, cap_sum)
                if best is None or ratio > best:
                    best = ratio
                    tight_sets = [frozenset(subset)]
                elif ratio == best:
                    tight_sets.append(frozenset(subset))

        peak = [best.numerator, best.denominator]

        count = len(tight_sets)

        minimal = []
        for s in tight_sets:
            if not any(other != s and other < s for other in tight_sets):
                minimal.append(sorted(s))
        minimal.sort(key=lambda x: (len(x), x))

        implies = []
        all_in_tight = set()
        for s in tight_sets:
            all_in_tight.update(s)
        for aid in sorted(all_in_tight):
            containing = [s for s in tight_sets if aid in s]
            common = set(containing[0])
            for s in containing[1:]:
                common &= s
            common.discard(aid)
            implies.append([aid, sorted(common)])

        results.append({
            "peak": peak,
            "count": count,
            "minimal": minimal,
            "implies": implies,
        })

    return results
