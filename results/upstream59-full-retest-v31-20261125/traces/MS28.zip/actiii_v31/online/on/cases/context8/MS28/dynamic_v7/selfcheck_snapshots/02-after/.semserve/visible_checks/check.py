import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that non-finite values in unknown fields must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that a non-object payload must raise ValueError.",
            },
        },
    },
]


class TestTransform(unittest.TestCase):
    def test_empty_no_deadline_assignments(self):
        # TASK.md: 若没有任何有截止日的作业，则返回 {"empty":true}
        payload = {"assignments": [["A", None, 5, ["s1"]]], "slots": [["s1", 3, 2]], "withdrawals": [[]]}
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [{"empty": True}])

    def test_unserved_sorted(self):
        # TASK.md: 若任何有截止日的作业没有有效时隙，返回 {"unserved":[全部这类作业ID升序]}
        payload = {"assignments": [["B", 10, 2, ["s1"]], ["A", 10, 1, ["s1"]]], "slots": [["s1", 3, 2]], "withdrawals": [["s1"]]}
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [{"unserved": ["A", "B"]}])

    def test_peak_reduced_fraction(self):
        # TASK.md: peak 为最简分数 [分子,正分母]
        payload = {"assignments": [["A", 10, 4, ["s1"]]], "slots": [["s1", 3, 6]], "withdrawals": [[]]}
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result[0]["peak"], [2, 3])


if __name__ == "__main__":
    unittest.main()
