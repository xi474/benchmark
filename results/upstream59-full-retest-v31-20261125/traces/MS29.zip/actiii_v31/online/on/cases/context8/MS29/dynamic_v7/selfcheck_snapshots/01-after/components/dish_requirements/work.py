from itertools import combinations


def compute(payload):
    """返回合格的三类菜品组合及合并需求，格式 [菜品 ID 数组,原料到数量映射]，按菜品字典序枚举。"""
    dishes = payload["dishes"]
    max_difficulty = payload["max_difficulty"]

    eligible = []
    for dish in dishes:
        dish_id, category, difficulty, ingredients = dish
        if difficulty <= max_difficulty:
            eligible.append((dish_id, category, ingredients))

    # 按菜品 ID 升序排列，保证组合按字典序枚举。
    eligible.sort(key=lambda d: d[0])

    results = []
    for triple in combinations(eligible, 3):
        ids = [d[0] for d in triple]
        categories = {d[1] for d in triple}
        if len(categories) != 3:
            continue
        merged = {}
        for _, _, ingredients in triple:
            for name, qty in ingredients.items():
                merged[name] = merged.get(name, 0) + qty
        results.append([ids, merged])

    return results
