def compute(payload):
    """输出所有限量采购篮 [总价,总件数,按排序后 offer 的购买数量向量]；按这三项升序排列。"""
    offers = payload["offers"]
    # 按报价 ID 升序排序
    offers = sorted(offers, key=lambda o: o[0])
    n = len(offers)
    prices = [o[2] for o in offers]
    limits = [o[3] for o in offers]

    baskets = []

    def rec(i, counts, total_price, total_packs):
        if i == n:
            baskets.append([total_price, total_packs, list(counts)])
            return
        for c in range(limits[i] + 1):
            counts.append(c)
            rec(i + 1, counts, total_price + prices[i] * c, total_packs + c)
            counts.pop()

    rec(0, [], 0, 0)
    baskets.sort(key=lambda b: (b[0], b[1], b[2]))
    return baskets
