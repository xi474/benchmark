from collections import deque


def _add(a, b):
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, 0) + v
    return out


def _sub(a, b):
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, 0) - v
    return out


def _ge(a, b):
    return all(a.get(k, 0) >= v for k, v in b.items())


def _pos(d):
    return {k: v for k, v in d.items() if v > 0}


def combine(payload, left, right):
    """left: dish triples [[ids, req], ...]; right: baskets [[cost, packs, buyvec], ...]."""
    stock = dict(payload.get("stock", {}))
    offers = payload["offers"]
    prep = payload["prep"]

    offer_order = sorted(range(len(offers)), key=lambda i: offers[i][0])
    offer_contents = [offers[i][1] for i in offer_order]

    prep_steps = [(p[0], p[1], p[2], p[3]) for p in prep]

    results = []
    for dish_ids, req in left:
        best = None
        for cost, packs, buyvec in right:
            inv = dict(stock)
            for idx, cnt in enumerate(buyvec):
                if cnt:
                    for k, v in offer_contents[idx].items():
                        inv[k] = inv.get(k, 0) + v * cnt

            plan = _solve(inv, req, prep_steps)
            if plan is None:
                continue
            steps, final_inv = plan
            left_over = _pos(_sub(final_inv, req))
            candidate = {
                "cost": cost,
                "buy": list(buyvec),
                "steps": steps,
                "left": left_over,
            }
            if best is None or _better(candidate, best):
                best = candidate
        results.append({"dishes": dish_ids, "plan": best})
    return results


def _better(a, b):
    if a["cost"] != b["cost"]:
        return a["cost"] < b["cost"]
    if sum(a["buy"]) != sum(b["buy"]):
        return sum(a["buy"]) < sum(b["buy"])
    if a["buy"] != b["buy"]:
        return a["buy"] < b["buy"]
    if len(a["steps"]) != len(b["steps"]):
        return len(a["steps"]) < len(b["steps"])
    return a["steps"] < b["steps"]


def _solve(inv, req, prep_steps):
    names = set(inv)
    for _, c, p, _ in prep_steps:
        names |= set(c) | set(p)
    names |= set(req)
    names = sorted(names)

    def key(d):
        return tuple(d.get(n, 0) for n in names)

    start = key(inv)
    seen = {start: ([], inv)}
    queue = deque([start])
    best = None
    while queue:
        cur = queue.popleft()
        steps, cur_inv = seen[cur]
        if _ge(cur_inv, req):
            if best is None or _seq_better(steps, best[0]):
                best = (steps, cur_inv)
            continue
        if len(steps) >= 16:
            continue
        for sid, consume, produce, limit in prep_steps:
            used = steps.count(sid)
            if used >= limit:
                continue
            if not _ge(cur_inv, consume):
                continue
            new_inv = _add(_sub(cur_inv, consume), produce)
            nk = key(new_inv)
            if nk not in seen:
                seen[nk] = (steps + [sid], new_inv)
                queue.append(nk)
    return best


def _seq_better(a, b):
    if len(a) != len(b):
        return len(a) < len(b)
    return a < b
