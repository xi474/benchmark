import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict
# check_api_boundary(...) -> raises on failure


class TestTransformBehavior(unittest.TestCase):
    def test_public_fixture_output(self):
        import json
        payload = json.load(open("public_input.json", encoding="utf-8"))
        result = call_candidate("solution.py", "transform", args=[payload])
        expected = json.load(open("public_expected.json", encoding="utf-8"))
        self.assertEqual(result, expected)

    def test_infeasible_plan_is_null(self):
        # A dish requiring an ingredient no offer/prep can ever produce.
        payload = {
            "dishes": [
                ["a", "cat1", 1, {"x": 1}],
                ["b", "cat2", 1, {"x": 1}],
                ["c", "cat3", 1, {"x": 1}],
            ],
            "stock": {},
            "offers": [],
            "prep": [],
            "max_difficulty": 1,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["dishes"], ["a", "b", "c"])
        self.assertIsNone(result[0]["plan"])

    def test_stock_satisfies_without_purchase(self):
        # Stock already covers the requirement; cheapest basket is the empty one.
        payload = {
            "dishes": [
                ["a", "cat1", 1, {"x": 1}],
                ["b", "cat2", 1, {"x": 1}],
                ["c", "cat3", 1, {"x": 1}],
            ],
            "stock": {"x": 3},
            "offers": [["o1", {"x": 1}, 5, 1]],
            "prep": [],
            "max_difficulty": 1,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        plan = result[0]["plan"]
        self.assertIsNotNone(plan)
        self.assertEqual(plan["cost"], 0)
        self.assertEqual(plan["buy"], [0])
        self.assertEqual(plan["steps"], [])
        self.assertEqual(plan["left"], {})

    def test_prep_chain_produces_required(self):
        # root -> mash via prep; need mash only. Two slices yield mash 4 >= 2.
        payload = {
            "dishes": [
                ["a", "cat1", 1, {"mash": 2}],
                ["b", "cat2", 1, {"mash": 2}],
                ["c", "cat3", 1, {"mash": 2}],
            ],
            "stock": {},
            "offers": [["o1", {"root": 2}, 1, 1]],
            "prep": [["slice", {"root": 1}, {"mash": 2}, 2]],
            "max_difficulty": 1,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        plan = result[0]["plan"]
        self.assertIsNotNone(plan)
        self.assertEqual(plan["cost"], 1)
        self.assertEqual(plan["steps"], ["slice", "slice"])
        self.assertEqual(plan["left"], {"mash": 2})

    def test_difficulty_filter_excludes_dish(self):
        # Only two categories remain eligible -> no valid triple.
        payload = {
            "dishes": [
                ["a", "cat1", 1, {"x": 1}],
                ["b", "cat2", 1, {"x": 1}],
                ["c", "cat1", 5, {"x": 1}],
            ],
            "stock": {"x": 3},
            "offers": [],
            "prep": [],
            "max_difficulty": 1,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [])


if __name__ == "__main__":
    unittest.main()
