def combine(payload, left, right):
    """left = student_tiers 值（学生->层级），right = market_ranking 值（房间代号列表）。"""
    tiers = left
    room_ids = right

    rooms = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]

    students = sorted(tiers.keys())

    def room_accepts(room_id, tier):
        room = rooms[room_id]
        for rank, group in enumerate(room["tiers"]):
            if tier in group:
                return rank
        return None

    def student_rank(student, room_id):
        for rank, group in enumerate(prefs[student]):
            if room_id in group:
                return rank
        return None

    results = []
    for cancel in cancel_list:
        closed = set(cancel)
        open_rooms = [r for r in room_ids if r not in closed]

        student_options = {}
        for s in students:
            opts = []
            for rank, group in enumerate(prefs[s]):
                for r in group:
                    if r in open_rooms and room_accepts(r, tiers[s]) is not None:
                        opts.append((rank, r))
            opts.sort()
            student_options[s] = [r for _, r in opts]

        capacities = {r: rooms[r]["capacity"] for r in open_rooms}

        stable_matches = []

        def is_stable(assign):
            for s in students:
                cur = assign.get(s)
                cur_rank = student_rank(s, cur) if cur is not None else None
                for w in student_options[s]:
                    w_rank = student_rank(s, w)
                    if cur is not None and cur_rank is not None and w_rank >= cur_rank:
                        continue
                    occupants = [t for t, r in assign.items() if r == w]
                    if len(occupants) < capacities[w]:
                        return False
                    s_tier_rank = room_accepts(w, tiers[s])
                    for t in occupants:
                        t_tier_rank = room_accepts(w, tiers[t])
                        if s_tier_rank < t_tier_rank:
                            return False
            return True

        def backtrack(idx, assign, used_capacity):
            if idx == len(students):
                if is_stable(assign):
                    stable_matches.append(dict(assign))
                return
            s = students[idx]
            assign[s] = None
            backtrack(idx + 1, assign, used_capacity)
            for w in student_options[s]:
                if used_capacity.get(w, 0) < capacities[w]:
                    assign[s] = w
                    used_capacity[w] = used_capacity.get(w, 0) + 1
                    backtrack(idx + 1, assign, used_capacity)
                    used_capacity[w] -= 1
            assign.pop(s)

        backtrack(0, {}, {})

        by_size = {}
        for m in stable_matches:
            n = sum(1 for r in m.values() if r is not None)
            by_size.setdefault(n, []).append(m)

        if not by_size:
            sizes = []
            forced = []
            example = ["" for _ in students]
        else:
            max_n = max(by_size)
            max_matches = by_size[max_n]

            sizes = sorted([[n, len(ms)] for n, ms in by_size.items()])

            forced_pairs = set()
            for s in students:
                rooms_assigned = set()
                for m in max_matches:
                    r = m.get(s)
                    if r is not None:
                        rooms_assigned.add(r)
                if len(rooms_assigned) == 1:
                    forced_pairs.add((s, next(iter(rooms_assigned))))
            # 仅当所有最大映射都包含该 [学生,场次] 对时才计入 forced。
            forced = []
            for s, r in sorted(forced_pairs):
                if all(m.get(s) == r for m in max_matches):
                    forced.append([s, r])

            def vector(m):
                return [m.get(s) or "" for s in students]

            example = min(vector(m) for m in max_matches)

        results.append({
            "sizes": sizes,
            "forced": forced,
            "example": example,
        })

    return results
