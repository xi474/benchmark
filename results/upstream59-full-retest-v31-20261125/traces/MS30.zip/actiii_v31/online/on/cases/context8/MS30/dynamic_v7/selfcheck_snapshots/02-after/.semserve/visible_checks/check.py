import unittest

from visible_contract_check_sdk import call_candidate, CandidateCallError

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "components/student_tiers/work.py",
        "function": "compute",
        "rules": {
            "nonfinite_unknown_field": {"applicable": False, "reason": "组件 compute 未声明对非有限值的 ValueError 规则"},
            "invalid_payload_type": {"applicable": False, "reason": "组件 compute 未声明对非法 payload 类型的 ValueError 规则"},
        },
    },
    {
        "target_path": "components/market_ranking/work.py",
        "function": "compute",
        "rules": {
            "nonfinite_unknown_field": {"applicable": False, "reason": "组件 compute 未声明对非有限值的 ValueError 规则"},
            "invalid_payload_type": {"applicable": False, "reason": "组件 compute 未声明对非法 payload 类型的 ValueError 规则"},
        },
    },
]


class TestStudentTiers(unittest.TestCase):
    def test_tier_thresholds(self):
        # 门槛：<0.60 N, <0.75 D, 其余 P；等权平均。
        payload = {"grades": [
            ["a", 16, 5, 10], ["a", 17, 10, 16],   # 0.5, 0.625 -> 0.5625 N
            ["b", 16, 7, 10], ["b", 17, 8, 16],    # 0.7, 0.5 -> 0.6 D
            ["c", 16, 8, 10], ["c", 17, 12, 16],   # 0.8, 0.75 -> 0.775 P
            ["d", 16, None, 10], ["d", 17, 8, 16], # 仅 0.5 -> N
        ]}
        got = call_candidate("components/student_tiers/work.py", "compute", args=[payload])
        self.assertEqual(got, {"a": "N", "b": "D", "c": "P", "d": "N"})


class TestMarketRanking(unittest.TestCase):
    def test_window_and_tiebreak(self):
        # 30 天窗口 L-29..L；按 abs(close-open)/open 降序，事件 ID 升序打破平局。
        payload = {"market": [
            ["e1", 100, 100, 120],  # 0.2
            ["e2", 71, 100, 120],   # 0.2 (窗口内)
            ["e3", 100, 100, 80],   # 0.2
            ["e4", 90, 100, 110],   # 0.1
        ], "top": 3}
        # L=100, 窗口 71..100 全部保留。0.2 的有 e1,e2,e3，按 ID 升序 e1,e2,e3。
        got = call_candidate("components/market_ranking/work.py", "compute", args=[payload])
        self.assertEqual(got, ["e1", "e2", "e3"])


class TestIntegration(unittest.TestCase):
    def test_combine_public(self):
        import json
        payload = json.load(open("public_input.json"))
        left = {"A": "N", "B": "N", "C": "D", "D": "D"}
        right = ["J", "K", "L"]
        got = call_candidate("integration.py", "combine", args=[payload, left, right])
        self.assertEqual(got[0]["sizes"], [[4, 12]])
        self.assertEqual(got[0]["example"], ["J", "K", "K", "L"])
        self.assertEqual(got[2]["forced"], [])
        self.assertEqual(got[2]["example"], ["", "", "", "J"])


if __name__ == "__main__":
    unittest.main()
