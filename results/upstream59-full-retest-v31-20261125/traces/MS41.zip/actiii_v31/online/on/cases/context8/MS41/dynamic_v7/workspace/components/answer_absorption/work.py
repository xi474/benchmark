from collections import deque
from fractions import Fraction


def _frac_pair(f):
    return [f.numerator, f.denominator]


def _solve(A, b):
    """Solve A x = b for a square invertible matrix A over Fractions."""
    n = len(A)
    M = [list(row) + [b[i]] for i, row in enumerate(A)]
    for col in range(n):
        piv = None
        for r in range(col, n):
            if M[r][col] != 0:
                piv = r
                break
        if piv is None:
            raise ValueError("singular system")
        if piv != col:
            M[col], M[piv] = M[piv], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                factor = M[r][col]
                M[r] = [M[r][j] - factor * M[col][j] for j in range(n + 1)]
    return [M[i][n] for i in range(n)]


def compute(payload):
    """按 method ID、profile 名输出 [各答案吸收概率,各答案加权成本质量]。

    吸收概率：从 start 出发，单次投票最终落入某答案的概率。
    加权成本质量：落入该答案的路径概率与路径花费乘积之和（即
    P(落入该答案) * E[花费 | 落入该答案]）。
    """
    methods = payload["methods"]
    answers = payload["answers"]
    answer_index = {a: i for i, a in enumerate(answers)}
    n = len(answers)

    result = {}
    for method in methods:
        mid = method["id"]
        start = method["start"]
        graphs = method["graphs"]
        mres = {}
        for version, graph in graphs.items():
            states = list(graph.keys())
            idx = {s: k for k, s in enumerate(states)}

            # Reverse reachability: which non-terminal states can reach an answer.
            rev = {s: [] for s in states}
            can_reach = set()
            for s in states:
                for (t, w, cost) in graph[s]:
                    if t in idx:
                        rev[t].append(s)
                    elif t in answer_index:
                        can_reach.add(s)
            q = deque(can_reach)
            while q:
                s = q.popleft()
                for p in rev[s]:
                    if p not in can_reach:
                        can_reach.add(p)
                        q.append(p)

            R = sorted(can_reach, key=lambda s: idx[s])
            ridx = {s: k for k, s in enumerate(R)}
            r = len(R)

            # Precompute per-state total weight and edges.
            state_edges = {}
            for s in states:
                edges = graph[s]
                W = sum(e[1] for e in edges)
                state_edges[s] = (W, edges)

            # Coefficient matrix A = I - P_RR over reachable states.
            A = [[Fraction(0) for _ in range(r)] for _ in range(r)]
            for s in R:
                si = ridx[s]
                W, edges = state_edges[s]
                A[si][si] = Fraction(1)
                for (t, w, cost) in edges:
                    if t in ridx:
                        A[si][ridx[t]] -= Fraction(w, W)

            abs_probs = []
            cost_quality = []
            for i in range(n):
                # RHS for absorption into answer i.
                b = [Fraction(0) for _ in range(r)]
                for s in R:
                    si = ridx[s]
                    W, edges = state_edges[s]
                    for (t, w, cost) in edges:
                        if t == answers[i]:
                            b[si] += Fraction(w, W)
                a = _solve(A, b) if r else []

                # RHS for cost quality into answer i.
                c = [Fraction(0) for _ in range(r)]
                for s in R:
                    si = ridx[s]
                    W, edges = state_edges[s]
                    for (t, w, cost) in edges:
                        if t == answers[i]:
                            at = Fraction(1)
                        elif t in ridx:
                            at = a[ridx[t]]
                        else:
                            at = Fraction(0)
                        c[si] += Fraction(w, W) * cost * at
                cq = _solve(A, c) if r else []

                if start in ridx:
                    abs_probs.append(_frac_pair(a[ridx[start]]))
                    cost_quality.append(_frac_pair(cq[ridx[start]]))
                else:
                    abs_probs.append([0, 1])
                    cost_quality.append([0, 1])

            mres[version] = [abs_probs, cost_quality]
        result[mid] = mres
    return result
