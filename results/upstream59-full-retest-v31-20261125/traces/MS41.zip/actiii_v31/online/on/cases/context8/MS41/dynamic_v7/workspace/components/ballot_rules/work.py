from collections import deque
from math import gcd


def _simplify(num, den):
    g = gcd(num, den)
    return [num // g, den // g]


def _winner(counts):
    """Return the index of the current leader (ties broken by earlier index)."""
    m = max(counts)
    return counts.index(m)


def _decide(counts, votes):
    """Return the winning answer index if the state is decided, else None."""
    n = len(counts)
    remaining = votes - sum(counts)
    leader = _winner(counts)
    if remaining == 0:
        return leader
    for j in range(n):
        if j == leader:
            continue
        c2 = list(counts)
        c2[j] += remaining
        if _winner(c2) != leader:
            return None
    return leader


def _method_table(method, answers):
    votes = method["votes"]
    n = len(answers)
    start = tuple([0] * n)
    table = {}
    seen = set()
    dq = deque([start])
    while dq:
        c = dq.popleft()
        if c in seen:
            continue
        seen.add(c)
        key = ",".join(map(str, c))
        winner = _decide(list(c), votes)
        table[key] = winner
        if winner is None and sum(c) < votes:
            for j in range(n):
                c2 = list(c)
                c2[j] += 1
                dq.append(tuple(c2))
    return table


def compute(payload):
    """输出 [先验映射,方法提前决胜表]。先验为最简分数。每种方法列出从零票起可达的计数状态（键为逗号分隔的答案票数）；值是已经胜出的答案下标或 null。决胜后不扩展。"""
    profiles = payload["profiles"]
    methods = payload["methods"]
    answers = payload["answers"]

    total = sum(profiles.values())
    prior = {name: _simplify(w, total) for name, w in profiles.items()}

    tables = {}
    for m in methods:
        tables[m["id"]] = _method_table(m, answers)

    return [prior, tables]
