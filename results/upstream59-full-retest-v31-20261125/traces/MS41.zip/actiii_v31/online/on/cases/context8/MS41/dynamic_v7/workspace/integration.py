from fractions import Fraction


def _simplify(num, den):
    from math import gcd
    g = gcd(num, den)
    return [num // g, den // g]


def _frac(f):
    return [f.numerator, f.denominator]


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    answers = payload["answers"]
    correct = payload["correct"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    n = len(answers)
    correct_idx = answers.index(correct)

    prior, tables = left
    absorption = right

    prior_frac = {name: Fraction(p[0], p[1]) for name, p in prior.items()}

    out = []
    for method in methods:
        mid = method["id"]
        votes = method["votes"]
        table = tables[mid]

        prof_abs = {}
        prof_cq = {}
        for pname in profiles:
            abs_probs, cost_quality = absorption[mid][pname]
            prof_abs[pname] = [Fraction(a[0], a[1]) for a in abs_probs]
            prof_cq[pname] = [Fraction(c[0], c[1]) for c in cost_quality]

        prof_total_abs = {p: sum(prof_abs[p]) for p in profiles}

        states = {}
        for key, winner in table.items():
            counts = tuple(int(x) for x in key.split(","))
            states[counts] = winner

        ordered = sorted(states.keys(), key=lambda c: (-sum(c), c))

        win_prob = {}
        unres_prob = {}
        launch_exp = {}
        cost_correct = {}

        for counts in ordered:
            winner = states[counts]
            if winner is not None:
                win_prob[counts] = [Fraction(1) if i == winner else Fraction(0) for i in range(n)]
                unres_prob[counts] = Fraction(0)
                launch_exp[counts] = Fraction(0)
                cost_correct[counts] = Fraction(1) if winner == correct_idx else Fraction(0)
                continue

            wp = [Fraction(0) for _ in range(n)]
            up = Fraction(0)
            le = Fraction(0)
            cc = Fraction(0)

            for pname in profiles:
                pr = prior_frac[pname]
                abs_p = prof_abs[pname]
                cq = prof_cq[pname]
                total_abs = prof_total_abs[pname]
                up += pr * (Fraction(1) - total_abs)
                le += pr * Fraction(1)
                for j in range(n):
                    if abs_p[j] == 0:
                        continue
                    new_counts = list(counts)
                    new_counts[j] += 1
                    nc = tuple(new_counts)
                    branch_p = pr * abs_p[j]
                    wp = [wp[i] + branch_p * win_prob[nc][i] for i in range(n)]
                    up += branch_p * unres_prob[nc]
                    le += branch_p * launch_exp[nc]
                    vote_cost = cq[j] / abs_p[j]
                    cc += branch_p * (vote_cost + cost_correct[nc])

            win_prob[counts] = wp
            unres_prob[counts] = up
            launch_exp[counts] = le
            cost_correct[counts] = cc

        start_counts = tuple([0] * n)
        wp = win_prob[start_counts]
        up = unres_prob[start_counts]
        le = launch_exp[start_counts]
        cc = cost_correct[start_counts]

        prob = [_frac(wp[i]) for i in range(n)]
        unresolved = _frac(up)
        launches = _frac(le)
        if wp[correct_idx] == 0:
            cost_if_correct = None
        else:
            cost_if_correct = _frac(cc / wp[correct_idx])

        out.append({
            "id": mid,
            "prob": prob,
            "unresolved": unresolved,
            "launches": launches,
            "cost_if_correct": cost_if_correct,
        })

    out.sort(key=lambda m: (-m["prob"][correct_idx][0] / m["prob"][correct_idx][1], m["id"]))
    return out
