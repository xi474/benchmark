from fractions import Fraction


def _solve(A, b):
    """Solve A x = b exactly (A is n x n of Fractions, b is n-vector)."""
    n = len(A)
    M = [list(row) + [b[i]] for i, row in enumerate(A)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            raise ValueError("singular matrix")
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                f = M[r][col]
                M[r] = [M[r][j] - f * M[col][j] for j in range(n + 1)]
    return [M[i][n] for i in range(n)]


def _pair(f):
    return [f.numerator, f.denominator]


def compute(payload):
    """按 method ID、profile 名输出 [各答案吸收概率,各答案加权成本质量]；向量元素均为约分的 [分子,分母]，保留 answers 顺序。"""
    methods = payload["methods"]
    profiles = payload["profiles"]
    answers = payload["answers"]
    answer_set = set(answers)
    answer_index = {a: i for i, a in enumerate(answers)}
    n_answers = len(answers)

    result = {}
    for method in methods:
        mid = method["id"]
        start = method["start"]
        graphs = method["graphs"]
        method_result = {}
        for profile_name in profiles:
            graph = graphs[profile_name]
            states = list(graph.keys())

            # Which non-terminal states can reach some answer.
            can_reach = set()
            for s in states:
                seen = set()
                stack = [s]
                while stack:
                    cur = stack.pop()
                    if cur in seen:
                        continue
                    seen.add(cur)
                    for (t, w, c) in graph[cur]:
                        if t in answer_set:
                            can_reach.add(s)
                            break
                        if t in graph:
                            stack.append(t)
                    if s in can_reach:
                        break

            reach_states = [s for s in states if s in can_reach]
            idx = {s: i for i, s in enumerate(reach_states)}
            n = len(reach_states)

            # Coefficient matrix A = I - P_NN (restricted to can-reach states).
            A = [[Fraction(0) for _ in range(n)] for _ in range(n)]
            for i in range(n):
                A[i][i] = Fraction(1)
            for s in reach_states:
                i = idx[s]
                edges = graph[s]
                W = sum(w for (t, w, c) in edges)
                for (t, w, c) in edges:
                    if t in idx:
                        A[i][idx[t]] -= Fraction(w, W)

            # Absorption probabilities p_s[a].
            absorption = []
            for a in answers:
                b = [Fraction(0) for _ in range(n)]
                for s in reach_states:
                    i = idx[s]
                    edges = graph[s]
                    W = sum(w for (t, w, c) in edges)
                    for (t, w, c) in edges:
                        if t == a:
                            b[i] += Fraction(w, W)
                x = _solve(A, b) if n > 0 else []
                absorption.append({s: x[idx[s]] for s in reach_states})

            # Weighted cost quality q_s[a] = P(reach a) * E[cost | reach a].
            quality = []
            for a in answers:
                ai = answer_index[a]
                b = [Fraction(0) for _ in range(n)]
                for s in reach_states:
                    i = idx[s]
                    edges = graph[s]
                    W = sum(w for (t, w, c) in edges)
                    for (t, w, c) in edges:
                        if t == a:
                            pt = Fraction(1)
                        elif t in answer_set:
                            pt = Fraction(0)
                        elif t in idx:
                            pt = absorption[ai][t]
                        else:
                            pt = Fraction(0)
                        b[i] += Fraction(w, W) * c * pt
                x = _solve(A, b) if n > 0 else []
                quality.append({s: x[idx[s]] for s in reach_states})

            if start in idx:
                abs_vec = [absorption[ai][start] for ai in range(n_answers)]
                qual_vec = [quality[ai][start] for ai in range(n_answers)]
            else:
                abs_vec = [Fraction(0) for _ in range(n_answers)]
                qual_vec = [Fraction(0) for _ in range(n_answers)]

            method_result[profile_name] = [
                [_pair(f) for f in abs_vec],
                [_pair(f) for f in qual_vec],
            ]
        result[mid] = method_result
    return result
