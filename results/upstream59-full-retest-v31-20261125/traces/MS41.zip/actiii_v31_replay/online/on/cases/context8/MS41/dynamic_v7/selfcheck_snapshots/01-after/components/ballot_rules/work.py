from math import gcd


def _simplify(num, den):
    if num == 0:
        return [0, 1]
    g = gcd(num, den)
    return [num // g, den // g]


def compute(payload):
    """输出 [先验映射,方法提前决胜表]。

    先验为最简分数。每种方法列出从零票起可达的计数状态
    （键为逗号分隔的答案票数）；值是已经胜出的答案下标或 null。
    决胜后不扩展。
    """
    profiles = payload["profiles"]
    methods = payload["methods"]
    answers = payload["answers"]
    n = len(answers)

    # 先验映射：各版本权重归一化为最简分数。
    total_weight = sum(profiles.values())
    prior = {name: _simplify(w, total_weight) for name, w in profiles.items()}

    # 每种方法的提前决胜表。
    table = {}
    for method in methods:
        votes = method["votes"]
        start = tuple([0] * n)
        states = {}
        visited = set()
        queue = [start]
        while queue:
            state = queue.pop(0)
            if state in visited:
                continue
            visited.add(state)
            total = sum(state)
            remaining = votes - total

            # 当前领先者：票数最多，平票取 answers 顺序在前者。
            max_count = max(state)
            leader = next(i for i in range(n) if state[i] == max_count)

            # 即使余下每一票都投给任一同一个竞争者，领先者仍能获胜？
            wins = True
            for j in range(n):
                if j == leader:
                    continue
                cj_after = state[j] + remaining
                if state[leader] > cj_after:
                    continue
                if state[leader] == cj_after and leader < j:
                    continue
                wins = False
                break

            key = ",".join(map(str, state))
            if wins:
                states[key] = leader
            else:
                states[key] = None
                for i in range(n):
                    new_state = list(state)
                    new_state[i] += 1
                    new_state = tuple(new_state)
                    if sum(new_state) <= votes and new_state not in visited:
                        queue.append(new_state)
        table[method["id"]] = states

    return [prior, table]
