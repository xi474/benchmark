from fractions import Fraction


def _frac(pair):
    return Fraction(pair[0], pair[1])


def _pair(f):
    return [f.numerator, f.denominator]


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    answers = payload["answers"]
    correct = payload["correct"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    n = len(answers)
    correct_idx = answers.index(correct)

    prior, decision_tables = left
    absorption = right

    results = []
    for method in methods:
        mid = method["id"]
        votes = method["votes"]
        table = decision_tables[mid]

        states = {}
        for key, winner in table.items():
            counts = tuple(int(x) for x in key.split(","))
            states[counts] = winner

        prob = [Fraction(0) for _ in range(n)]
        unresolved = Fraction(0)
        launches = Fraction(0)
        cost_correct = Fraction(0)

        total_weight = sum(profiles.values())
        for pname, pweight in profiles.items():
            abs_probs = [Fraction(0) for _ in range(n)]
            cost_qual = [Fraction(0) for _ in range(n)]
            for a in range(n):
                abs_probs[a] = _frac(absorption[mid][pname][0][a])
                cost_qual[a] = _frac(absorption[mid][pname][1][a])
            unres_single = Fraction(1) - sum(abs_probs)

            start = tuple([0] * n)
            memo = {}

            def solve(counts):
                if counts in memo:
                    return memo[counts]
                total = sum(counts)
                winner = states.get(counts)
                if winner is not None:
                    res = {
                        "prob": [Fraction(1) if i == winner else Fraction(0) for i in range(n)],
                        "unres": Fraction(0),
                        "launch": Fraction(0),
                        "cost": Fraction(0),
                    }
                    memo[counts] = res
                    return res
                if total >= votes:
                    res = {
                        "prob": [Fraction(0) for _ in range(n)],
                        "unres": Fraction(1),
                        "launch": Fraction(0),
                        "cost": Fraction(0),
                    }
                    memo[counts] = res
                    return res
                res = {
                    "prob": [Fraction(0) for _ in range(n)],
                    "unres": Fraction(0),
                    "launch": Fraction(1),
                    "cost": Fraction(0),
                }
                for a in range(n):
                    if abs_probs[a] == 0:
                        continue
                    nxt = list(counts)
                    nxt[a] += 1
                    nxt = tuple(nxt)
                    sub = solve(nxt)
                    pa = abs_probs[a]
                    for i in range(n):
                        res["prob"][i] += pa * sub["prob"][i]
                    res["unres"] += pa * sub["unres"]
                    res["launch"] += pa * sub["launch"]
                    res["cost"] += pa * sub["cost"] + cost_qual[a] * sub["prob"][correct_idx]
                res["unres"] += unres_single
                memo[counts] = res
                return res

            res = solve(start)
            w = Fraction(pweight, total_weight)
            for i in range(n):
                prob[i] += w * res["prob"][i]
            unresolved += w * res["unres"]
            launches += w * res["launch"]
            cost_correct += w * res["cost"]

        if prob[correct_idx] == 0:
            cost_if_correct = None
        else:
            cost_if_correct = _pair(cost_correct / prob[correct_idx])

        results.append({
            "id": mid,
            "prob": [_pair(p) for p in prob],
            "unresolved": _pair(unresolved),
            "launches": _pair(launches),
            "cost_if_correct": cost_if_correct,
        })

    results.sort(key=lambda r: (-(r["prob"][correct_idx][0] / r["prob"][correct_idx][1]), r["id"]))
    return results
