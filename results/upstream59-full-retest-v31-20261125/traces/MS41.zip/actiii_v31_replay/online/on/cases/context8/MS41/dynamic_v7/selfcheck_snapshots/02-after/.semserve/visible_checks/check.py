import unittest

# Injected names provided by the visible-contract SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None


API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform must reject non-finite values; it only requires returning the specified JSON value.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not document a ValueError contract for invalid payload types.",
            },
        },
    },
]


class TestTransformOutputContract(unittest.TestCase):
    """High-risk behavior checks derived from the public task contract."""

    def test_public_fixture_output_shape_and_order(self):
        payload = {
            "answers": ["A", "B"],
            "correct": "A",
            "profiles": {"standard": 1},
            "methods": [
                {"id": "direct", "votes": 1, "start": "entry",
                 "graphs": {"standard": {"entry": [["A", 2, 1], ["B", 1, 3]]}}},
                {"id": "vote", "votes": 3, "start": "entry",
                 "graphs": {"standard": {"entry": [["A", 2, 1], ["B", 1, 3]]}}},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)
        self.assertEqual([r["id"] for r in result], ["vote", "direct"])
        for r in result:
            self.assertEqual(set(r.keys()), {"id", "prob", "unresolved", "launches", "cost_if_correct"})
            self.assertEqual(len(r["prob"]), 2)
            for pair in r["prob"]:
                self.assertIsInstance(pair, list)
                self.assertEqual(len(pair), 2)
                self.assertGreater(pair[1], 0)
        self.assertEqual(result[0]["prob"], [[20, 27], [7, 27]])
        self.assertEqual(result[0]["unresolved"], [0, 1])
        self.assertEqual(result[0]["launches"], [22, 9])
        self.assertEqual(result[0]["cost_if_correct"], [16, 5])
        self.assertEqual(result[1]["prob"], [[2, 3], [1, 3]])
        self.assertEqual(result[1]["cost_if_correct"], [1, 1])

    def test_input_not_mutated(self):
        payload = {
            "answers": ["A", "B"],
            "correct": "A",
            "profiles": {"standard": 1},
            "methods": [
                {"id": "direct", "votes": 1, "start": "entry",
                 "graphs": {"standard": {"entry": [["A", 2, 1], ["B", 1, 3]]}}},
            ],
        }
        import copy
        snapshot = copy.deepcopy(payload)
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)


if __name__ == "__main__":
    unittest.main()
