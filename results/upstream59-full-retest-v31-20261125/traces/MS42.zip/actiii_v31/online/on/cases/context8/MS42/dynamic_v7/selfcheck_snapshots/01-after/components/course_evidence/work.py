def compute(payload):
    """为每门课生成 [项目统计,传递可达表]。

    统计行 [ID,标签,[成绩和分子,分母],非空数] 按 ID 排序，保留零成绩。
    可达表的值为有序 ID 数组（严格传递可达，不含自身）。
    """
    courses = payload["courses"]
    result = {}
    for code, course in courses.items():
        items = course["items"]
        edges = course.get("edges", [])

        # 项目统计：按 ID 排序。
        stats = []
        for item_id, label, scores in items:
            non_null = [s for s in scores if s is not None]
            total = sum(non_null)
            count = len(non_null)
            stats.append([item_id, label, [total, count], count])
        stats.sort(key=lambda row: row[0])

        # 传递可达表：严格传递闭包（不含自身），值按 ID 排序。
        ids = [item_id for item_id, _, _ in items]
        adj = {i: set() for i in ids}
        for src, dst in edges:
            if src in adj and dst in adj:
                adj[src].add(dst)

        reach = {i: set() for i in ids}
        for start in ids:
            seen = set()
            stack = list(adj[start])
            while stack:
                node = stack.pop()
                if node in seen:
                    continue
                seen.add(node)
                stack.extend(adj[node])
            reach[start] = seen

        reach_table = {i: sorted(reach[i]) for i in ids}

        result[code] = [stats, reach_table]
    return result
