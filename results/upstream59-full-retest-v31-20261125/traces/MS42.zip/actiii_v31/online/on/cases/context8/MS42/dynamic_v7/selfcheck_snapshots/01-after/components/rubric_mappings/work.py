from itertools import permutations


def compute(payload):
    """返回 [所有可行映射位掩码,旧标签到各新标签的掩码映射]；位序按新标签升序的排列枚举。"""
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    new_labels = sorted({nl for lst in rubrics.values() for nl in lst})

    feasible_mask = 0
    per_old = {ol: {nl: 0 for nl in new_labels} for ol in old_labels}

    for i, perm in enumerate(permutations(new_labels)):
        bit = 1 << i
        ok = True
        for ol, nl in zip(old_labels, perm):
            if nl not in rubrics[ol]:
                ok = False
                break
        if ok:
            feasible_mask |= bit
            for ol, nl in zip(old_labels, perm):
                per_old[ol][nl] |= bit

    return [feasible_mask, per_old]
