from fractions import Fraction
from itertools import combinations, permutations


def _gcd(a, b):
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a


def _simplify(num, den):
    if den < 0:
        num, den = -num, -den
    g = _gcd(num, den)
    if g == 0:
        return [0, 1]
    return [num // g, den // g]


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    feasible_mask = left[0]
    per_old = left[1]
    course_evidence = right

    # Identify course prefixes with both 2013J and 2014J offerings.
    prefixes = set()
    for code in course_evidence:
        if code.endswith("-2013J"):
            prefixes.add(code[:-len("-2013J")])
    prefixes = sorted(p for p in prefixes if (p + "-2013J") in course_evidence and (p + "-2014J") in course_evidence)

    # For each prefix, gather old (2013J) and new (2014J) items.
    old_items = {}
    new_items = {}
    for p in prefixes:
        old_code = p + "-2013J"
        new_code = p + "-2014J"
        old_stats, old_reach = course_evidence[old_code]
        new_stats, new_reach = course_evidence[new_code]
        old_items[p] = (old_stats, old_reach)
        new_items[p] = (new_stats, new_reach)

    # Build candidate pairs per prefix: (old_id, new_id) where both have >=1 scored.
    candidates = {}
    for p in prefixes:
        old_stats, _ = old_items[p]
        new_stats, _ = new_items[p]
        cands = []
        for oid, olab, osum, onon in old_stats:
            if onon < 1:
                continue
            for nid, nlab, nsum, nnon in new_stats:
                if nnon < 1:
                    continue
                cands.append((oid, nid, min(onon, nnon)))
        candidates[p] = cands

    # Rebuild dictionaries directly from rubrics.
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    new_labels = sorted({nl for lst in rubrics.values() for nl in lst})

    dictionaries = []
    for perm in permutations(new_labels):
        ok = True
        for ol, nl in zip(old_labels, perm):
            if nl not in rubrics[ol]:
                ok = False
                break
        if ok:
            dictionaries.append(dict(zip(old_labels, perm)))

    # Precompute per-prefix data.
    prefix_data = {}
    for p in prefixes:
        old_stats, old_reach = old_items[p]
        new_stats, new_reach = new_items[p]
        old_ids = [r[0] for r in old_stats]
        new_ids = [r[0] for r in new_stats]
        prefix_data[p] = (old_stats, new_stats, old_reach, new_reach, old_ids, new_ids)

    # Collect all alignments as pair_set -> (pairs, support).
    all_alignments = {}

    for d in dictionaries:
        per_prefix_matchings = []
        for p in prefixes:
            old_stats, new_stats, old_reach, new_reach, old_ids, new_ids = prefix_data[p]
            cands = candidates[p]
            compat = []
            for oid, nid, sup in cands:
                olab = None
                for r in old_stats:
                    if r[0] == oid:
                        olab = r[1]
                        break
                nlab = None
                for r in new_stats:
                    if r[0] == nid:
                        nlab = r[1]
                        break
                if d.get(olab) == nlab:
                    compat.append((oid, nid, sup))
            matchings = []
            n = len(compat)
            for mask in range(1 << n):
                chosen = [compat[i] for i in range(n) if mask & (1 << i)]
                oset = set()
                nset = set()
                ok = True
                for oid, nid, sup in chosen:
                    if oid in oset or nid in nset:
                        ok = False
                        break
                    oset.add(oid)
                    nset.add(nid)
                if not ok:
                    continue
                ok = True
                for i in range(len(chosen)):
                    for j in range(i + 1, len(chosen)):
                        o1, n1, _ = chosen[i]
                        o2, n2, _ = chosen[j]
                        o12 = o2 in old_reach.get(o1, [])
                        o21 = o1 in old_reach.get(o2, [])
                        n12 = n2 in new_reach.get(n1, [])
                        n21 = n1 in new_reach.get(n2, [])
                        if (o12 != n12) or (o21 != n21):
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    matchings.append(chosen)
            per_prefix_matchings.append(matchings)

        def combine_prefixes(idx, current_pairs, current_support):
            if idx == len(prefixes):
                pair_set = frozenset(current_pairs)
                pairs = len(current_pairs)
                if pair_set not in all_alignments:
                    all_alignments[pair_set] = (pairs, current_support)
                return
            for m in per_prefix_matchings[idx]:
                new_pairs = current_pairs + [(prefixes[idx], oid, nid) for oid, nid, _ in m]
                new_support = current_support + sum(sup for _, _, sup in m)
                combine_prefixes(idx + 1, new_pairs, new_support)

        combine_prefixes(0, [], 0)

    empty_set = frozenset()
    if empty_set not in all_alignments:
        all_alignments[empty_set] = (0, 0)

    max_pairs = max(p for p, _ in all_alignments.values())
    best = [(ps, pairs, support) for ps, (pairs, support) in all_alignments.items() if pairs == max_pairs]
    max_support = max(support for _, _, support in best)
    optimal = [(ps, pairs, support) for ps, pairs, support in best if support == max_support]

    ways = len(optimal)

    if optimal:
        common = set(optimal[0][0])
        for ps, _, _ in optimal[1:]:
            common &= set(ps)
        forced = sorted(common, key=lambda t: (t[0], t[1], t[2]))
    else:
        forced = []

    if max_pairs == 0:
        drift = None
    else:
        drifts = []
        for ps, _, _ in optimal:
            old_num = 0
            old_den = 0
            new_num = 0
            new_den = 0
            for p, oid, nid in ps:
                old_stats, new_stats, _, _, _, _ = prefix_data[p]
                for r in old_stats:
                    if r[0] == oid:
                        old_num += r[2][0]
                        old_den += r[2][1]
                        break
                for r in new_stats:
                    if r[0] == nid:
                        new_num += r[2][0]
                        new_den += r[2][1]
                        break
            num = new_num * old_den - old_num * new_den
            den = new_den * old_den
            drifts.append(_simplify(num, den))
        drift = [min(drifts), max(drifts)]

    return {
        "pairs": max_pairs,
        "support": max_support,
        "ways": ways,
        "forced": forced,
        "drift": drift,
    }
