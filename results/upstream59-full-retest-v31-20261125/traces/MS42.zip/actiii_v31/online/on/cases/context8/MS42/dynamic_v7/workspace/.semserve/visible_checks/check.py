import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The visible contract does not state that transform must reject non-finite values; it only requires returning the specified JSON value.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The visible contract does not state that transform must raise ValueError on invalid payload types.",
            },
        },
    },
]


class TestIntegrationBehavior(unittest.TestCase):
    def test_public_fixture_output_contract(self):
        # Output contract: raw container type, required fields, ordering.
        result = call_candidate("solution.py", "transform", args=[{
            "rubrics": {"a": ["X", "Y"], "b": ["Y", "X"]},
            "courses": {
                "ENG-2013J": {
                    "items": [["p", "a", [30]], ["q", "b", [80, None]]],
                    "edges": [],
                },
                "ENG-2014J": {
                    "items": [["r", "X", [70]], ["s", "Y", [40]]],
                    "edges": [],
                },
            },
        }, {}])
        self.assertIsInstance(result, dict)
        self.assertEqual(
            list(result.keys()),
            ["pairs", "support", "ways", "forced", "drift"],
        )
        self.assertEqual(result["pairs"], 2)
        self.assertEqual(result["support"], 2)
        self.assertEqual(result["ways"], 2)
        self.assertEqual(result["forced"], [])
        self.assertEqual(result["drift"], [[0, 1], [0, 1]])

    def test_empty_alignment_drift_null(self):
        # Valid rare path: no comparable pairs -> pairs 0, drift null.
        result = call_candidate("solution.py", "transform", args=[{
            "rubrics": {"a": ["X"]},
            "courses": {
                "ENG-2013J": {"items": [["p", "a", [None]]], "edges": []},
                "ENG-2014J": {"items": [["r", "X", [None]]], "edges": []},
            },
        }, {}])
        self.assertEqual(result["pairs"], 0)
        self.assertIsNone(result["drift"])
        self.assertEqual(result["forced"], [])

    def test_order_consistency_blocks_pair(self):
        # Reversed order: only single-pair alignments survive.
        result = call_candidate("solution.py", "transform", args=[{
            "rubrics": {"a": ["X"], "b": ["Y"]},
            "courses": {
                "ENG-2013J": {
                    "items": [["p", "a", [10]], ["q", "b", [20]]],
                    "edges": [["p", "q"]],
                },
                "ENG-2014J": {
                    "items": [["r", "X", [30]], ["s", "Y", [40]]],
                    "edges": [["s", "r"]],
                },
            },
        }, {}])
        self.assertEqual(result["pairs"], 1)
        self.assertEqual(result["support"], 1)
        self.assertEqual(result["ways"], 2)
        self.assertEqual(result["forced"], [])
        self.assertEqual(result["drift"], [[20, 1], [20, 1]])

    def test_order_consistency_allows_pair(self):
        # Same order p->q and r->s: a valid alignment with 2 pairs exists.
        result = call_candidate("solution.py", "transform", args=[{
            "rubrics": {"a": ["X"], "b": ["Y"]},
            "courses": {
                "ENG-2013J": {
                    "items": [["p", "a", [10]], ["q", "b", [20]]],
                    "edges": [["p", "q"]],
                },
                "ENG-2014J": {
                    "items": [["r", "X", [30]], ["s", "Y", [40]]],
                    "edges": [["r", "s"]],
                },
            },
        }, {}])
        self.assertEqual(result["pairs"], 2)
        self.assertEqual(result["support"], 2)
        self.assertEqual(result["ways"], 1)
        self.assertEqual(result["forced"], [["ENG", "p", "r"], ["ENG", "q", "s"]])
        # drift = (30+40)/2 - (10+20)/2 = 35 - 15 = 20
        self.assertEqual(result["drift"], [[20, 1], [20, 1]])


if __name__ == "__main__":
    unittest.main()
