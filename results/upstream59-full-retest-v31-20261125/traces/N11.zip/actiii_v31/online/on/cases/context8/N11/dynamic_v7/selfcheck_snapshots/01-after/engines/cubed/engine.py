"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build


def _block_value(block):
    """Return the dense integer matrix for a block (zero matrix when data is null)."""
    if block["data"] is None:
        return [[0] * block["cols"] for _ in range(block["rows"])]
    return block["data"]


def _matmul(a, b):
    """Multiply two dense integer matrices."""
    rows = len(a)
    cols = len(b[0]) if b else 0
    inner = len(b)
    result = [[0] * cols for _ in range(rows)]
    for i in range(rows):
        for k in range(inner):
            aik = a[i][k]
            if aik == 0:
                continue
            brow = b[k]
            for j in range(cols):
                result[i][j] += aik * brow[j]
    return result


def _is_zero(mat):
    return all(v == 0 for row in mat for v in row)


def _block_multiply(left, right):
    """Multiply two block matrices (2D lists of blocks) and return a block matrix.

    Zero blocks are preserved with their shape (data=null).
    """
    n = len(left)
    m = len(right[0]) if right else 0
    inner = len(right)
    result = []
    for i in range(n):
        row = []
        for j in range(m):
            rows = left[i][0]["rows"]
            cols = right[0][j]["cols"]
            acc = None
            for k in range(inner):
                a = _block_value(left[i][k])
                b = _block_value(right[k][j])
                prod = _matmul(a, b)
                if acc is None:
                    acc = prod
                else:
                    for r in range(rows):
                        for c in range(cols):
                            acc[r][c] += prod[r][c]
            if acc is None:
                acc = [[0] * cols for _ in range(rows)]
            if _is_zero(acc):
                row.append({"rows": rows, "cols": cols, "data": None})
            else:
                row.append({"rows": rows, "cols": cols, "data": acc})
        result.append(row)
    return result


def transform(payload, contract):
    squared = payload["squared"]
    matrix = payload["matrix"]
    layout = payload["layout"]
    blocks = _block_multiply(squared, matrix)
    return {"layout": layout, "blocks": blocks}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
