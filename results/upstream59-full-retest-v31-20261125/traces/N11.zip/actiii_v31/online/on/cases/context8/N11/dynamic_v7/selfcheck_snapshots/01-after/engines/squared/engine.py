"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def _block_value(block):
    rows = block["rows"]
    cols = block["cols"]
    data = block["data"]
    if data is None:
        return [[0] * cols for _ in range(rows)]
    return data


def _matmul(a, b):
    ra = len(a)
    ca = len(a[0])
    rb = len(b)
    cb = len(b[0])
    assert ca == rb
    out = [[0] * cb for _ in range(ra)]
    for i in range(ra):
        for k in range(ca):
            aik = a[i][k]
            if aik == 0:
                continue
            brow = b[k]
            orow = out[i]
            for j in range(cb):
                orow[j] += aik * brow[j]
    return out


def _is_zero(mat):
    return all(x == 0 for row in mat for x in row)


def transform(payload, contract):
    matrix = payload["matrix"]
    n = len(matrix)
    result = []
    for i in range(n):
        row = []
        for j in range(n):
            rows = matrix[i][0]["rows"]
            cols = matrix[0][j]["cols"]
            acc = None
            for k in range(n):
                a = _block_value(matrix[i][k])
                b = _block_value(matrix[k][j])
                prod = _matmul(a, b)
                if acc is None:
                    acc = prod
                else:
                    for r in range(len(acc)):
                        for c in range(len(acc[0])):
                            acc[r][c] += prod[r][c]
            if _is_zero(acc):
                data = None
            else:
                data = acc
            row.append({"rows": rows, "cols": cols, "data": data})
        result.append(row)
    return result

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
