"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import build, read


def main():
    root = Path(__file__).resolve().parent

    block_layout_contract = read(root / "engines/block_layout/contract.json")
    squared_contract = read(root / "engines/squared/contract.json")
    cubed_contract = read(root / "engines/cubed/contract.json")

    block_layout = build(root, block_layout_contract, _block_layout_transform)
    squared = build(root, squared_contract, _squared_transform)
    cubed = build(root, cubed_contract, _cubed_transform)

    report = {
        "task": "N11",
        "results": {
            "block_layout": block_layout,
            "squared": squared,
            "cubed": cubed,
        },
        "result": cubed,
    }

    out = root / "outputs/final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _block_layout_transform(payload, contract):
    matrix = payload["matrix"]
    row_sizes = [row[0]["rows"] for row in matrix]
    col_sizes = [matrix[0][j]["cols"] for j in range(len(matrix[0]))]
    return {"row_sizes": row_sizes, "col_sizes": col_sizes}


def _squared_transform(payload, contract):
    from engines.squared.engine import transform
    return transform(payload, contract)


def _cubed_transform(payload, contract):
    from engines.cubed.engine import transform
    return transform(payload, contract)


if __name__ == "__main__":
    main()
