import unittest



API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/block_layout/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/block_layout/SPEC.md",
                "requirement_quote": "matrix是二维块列表，每块 {rows,cols,data:整数二维列表或null}，null表示有形状的零矩阵。",
                "reason": "SPEC does not state a ValueError rule for non-finite values in unknown fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/block_layout/SPEC.md",
                "requirement_quote": "matrix是二维块列表，每块 {rows,cols,data:整数二维列表或null}，null表示有形状的零矩阵。",
                "reason": "SPEC only defines the valid matrix shape; it does not require ValueError for invalid payload types.",
            },
        },
    },
    {
        "target_path": "engines/squared/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/squared/SPEC.md",
                "requirement_quote": "全零块 data=null，其他块 data为整数二维列表。不得折叠成无形状标量0。",
                "reason": "SPEC does not state a ValueError rule for non-finite values in unknown fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/squared/SPEC.md",
                "requirement_quote": "计算 B²，返回同分块结构；每个块仍含 rows/cols。",
                "reason": "SPEC only defines the valid matrix shape; it does not require ValueError for invalid payload types.",
            },
        },
    },
    {
        "target_path": "engines/cubed/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/cubed/SPEC.md",
                "requirement_quote": "消费 B² 再乘 B，返回 {layout:输入layout,blocks:B³的有形状分块矩阵}；使用与 squared相同零块表示。",
                "reason": "SPEC does not state a ValueError rule for non-finite values in unknown fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/cubed/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC only defines the valid input shape; it does not require ValueError for invalid payload types.",
            },
        },
    },
]


class BlockLayoutTests(unittest.TestCase):
    def test_row_and_col_sizes(self):
        matrix = [
            [
                {"rows": 2, "cols": 2, "data": [[1, 0], [0, 1]]},
                {"rows": 2, "cols": 1, "data": None},
            ],
            [
                {"rows": 1, "cols": 2, "data": None},
                {"rows": 1, "cols": 1, "data": None},
            ],
        ]
        payload = {"matrix": matrix}
        contract = {}
        result = call_candidate(
            "engines/block_layout/engine.py", "transform", args=[payload, contract]
        )
        self.assertEqual(result, {"row_sizes": [2, 1], "col_sizes": [2, 1]})


class SquaredTests(unittest.TestCase):
    def test_square_preserves_zero_block_shapes(self):
        matrix = [
            [
                {"rows": 2, "cols": 2, "data": [[2, 0], [0, 3]]},
                {"rows": 2, "cols": 1, "data": None},
            ],
            [
                {"rows": 1, "cols": 2, "data": None},
                {"rows": 1, "cols": 1, "data": None},
            ],
        ]
        payload = {"matrix": matrix}
        contract = {}
        result = call_candidate(
            "engines/squared/engine.py", "transform", args=[payload, contract]
        )
        self.assertEqual(result[0][0]["data"], [[4, 0], [0, 9]])
        self.assertEqual(result[0][0]["rows"], 2)
        self.assertEqual(result[0][0]["cols"], 2)
        self.assertIsNone(result[0][1]["data"])
        self.assertEqual(result[0][1]["rows"], 2)
        self.assertEqual(result[0][1]["cols"], 1)
        self.assertIsNone(result[1][0]["data"])
        self.assertIsNone(result[1][1]["data"])


class CubedTests(unittest.TestCase):
    def test_cube_returns_layout_and_blocks(self):
        squared = [
            [
                {"rows": 2, "cols": 2, "data": [[4, 0], [0, 9]]},
                {"rows": 2, "cols": 1, "data": None},
            ],
            [
                {"rows": 1, "cols": 2, "data": None},
                {"rows": 1, "cols": 1, "data": None},
            ],
        ]
        matrix = [
            [
                {"rows": 2, "cols": 2, "data": [[2, 0], [0, 3]]},
                {"rows": 2, "cols": 1, "data": None},
            ],
            [
                {"rows": 1, "cols": 2, "data": None},
                {"rows": 1, "cols": 1, "data": None},
            ],
        ]
        layout = {"row_sizes": [2, 1], "col_sizes": [2, 1]}
        payload = {"squared": squared, "matrix": matrix, "layout": layout}
        contract = {}
        result = call_candidate(
            "engines/cubed/engine.py", "transform", args=[payload, contract]
        )
        self.assertEqual(result["layout"], layout)
        self.assertEqual(result["blocks"][0][0]["data"], [[8, 0], [0, 27]])
        self.assertIsNone(result["blocks"][0][1]["data"])
        self.assertIsNone(result["blocks"][1][0]["data"])
        self.assertIsNone(result["blocks"][1][1]["data"])


if __name__ == "__main__":
    unittest.main()
