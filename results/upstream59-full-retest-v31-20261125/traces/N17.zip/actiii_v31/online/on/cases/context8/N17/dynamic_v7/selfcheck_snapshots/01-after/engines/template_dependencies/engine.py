"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

import re

_TEMPLATE_RE = re.compile(r"\{\{(.*?)\}\}", re.DOTALL)


def _conf_chains(expr):
    """Yield conf-prefixed access chains from a Python-compatible expression.

    A chain starts at an identifier ``conf`` and continues through attribute
    accesses (``.name``) and static string subscripts (``['name']`` or
    ``["name"]``). Subscripts are converted to dots. The chain stops at any
    other token (arithmetic operators, calls, non-string subscripts, etc.).
    """
    i = 0
    n = len(expr)
    while i < n:
        # Find the next ``conf`` identifier.
        j = expr.find("conf", i)
        if j < 0:
            return
        # Must be a standalone identifier (not part of a longer name).
        before_ok = j == 0 or not (expr[j - 1].isalnum() or expr[j - 1] == "_")
        after = j + 4
        after_ok = after >= n or not (expr[after].isalnum() or expr[after] == "_")
        if before_ok and after_ok:
            parts = ["conf"]
            k = after
            while k < n:
                if expr[k] == ".":
                    m = re.match(r"[A-Za-z_][A-Za-z0-9_]*", expr[k + 1:])
                    if not m:
                        break
                    parts.append(m.group(0))
                    k += 1 + len(m.group(0))
                elif expr[k] == "[":
                    m = re.match(r"\s*['\"]([^'\"]*)['\"]\s*\]", expr[k:])
                    if not m:
                        break
                    parts.append(m.group(1))
                    k += len(m.group(0))
                else:
                    break
            if len(parts) > 1:
                yield parts
            i = k
        else:
            i = j + 4


def _longest_prefix(chain, options):
    """Return the longest option that is a prefix of the dotted chain."""
    dotted = ".".join(chain[1:])
    best = None
    for opt in options:
        if dotted == opt or dotted.startswith(opt + "."):
            if best is None or len(opt) > len(best):
                best = opt
    return best


def transform(payload, contract):
    templates = payload["templates"]
    options = payload["options"]
    result = {}
    for tid, text in templates.items():
        keys = set()
        for match in _TEMPLATE_RE.finditer(text):
            expr = match.group(1)
            for chain in _conf_chains(expr):
                key = _longest_prefix(chain, options)
                if key is not None:
                    keys.add(key)
        result[tid] = sorted(keys)
    return result

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
