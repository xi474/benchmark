"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import read, build, module


def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    contracts = {}
    for name in ("template_dependencies", "reverse_index", "stylesheet_updates"):
        contracts[name] = read(root / "engines" / name / "contract.json")

    results = {}
    td = module(root, "engines/template_dependencies/engine.py")
    results["template_dependencies"] = build(
        root, contracts["template_dependencies"], td.transform
    )

    ri = module(root, "engines/reverse_index/engine.py")
    results["reverse_index"] = build(
        root, contracts["reverse_index"], ri.transform
    )

    su = module(root, "engines/stylesheet_updates/engine.py")
    results["stylesheet_updates"] = build(
        root, contracts["stylesheet_updates"], su.transform
    )

    result_file = delivery["result_file"]
    result_value = read(root / result_file)

    report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value,
    }
    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
