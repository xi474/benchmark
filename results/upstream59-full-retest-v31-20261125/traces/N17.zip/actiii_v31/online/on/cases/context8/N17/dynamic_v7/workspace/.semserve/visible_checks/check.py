import unittest

from call_candidate import call_candidate, CandidateCallError


class TestTemplateDependencies(unittest.TestCase):
    def test_conf_chain_longest_prefix(self):
        payload = {
            "templates": {
                "a": "{{ conf.auto_save.interval + conf.hints.min_chars }}",
                "b": "{{ conf.aliases['a'].propname }} {{ notconf.hints.min_chars }}",
            },
            "options": ["auto_save.interval", "hints.min_chars", "aliases"],
        }
        contract = {}
        got = call_candidate(
            "engines/template_dependencies/engine.py", "transform",
            args=[payload, contract],
        )
        self.assertEqual(
            got,
            {
                "a": ["auto_save.interval", "hints.min_chars"],
                "b": ["aliases"],
            },
        )

    def test_subscript_to_dot_and_ignore_notconf(self):
        payload = {
            "templates": {
                "t": "{{ conf.a['b'].c }} {{ notconf.a.b }}",
            },
            "options": ["a.b", "a.b.c"],
        }
        got = call_candidate(
            "engines/template_dependencies/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(got, {"t": ["a.b.c"]})


class TestReverseIndex(unittest.TestCase):
    def test_reverse_index_sorted(self):
        payload = {"dependencies": {"b": ["y"], "a": ["x", "y"]}}
        got = call_candidate(
            "engines/reverse_index/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(got, {"x": ["a"], "y": ["a", "b"]})


class TestStylesheetUpdates(unittest.TestCase):
    def test_affected_intersection(self):
        payload = {
            "dependencies": {"a": ["x", "y"], "b": ["y"]},
            "reverse": {"x": ["a"], "y": ["a", "b"]},
            "changed": ["y"],
        }
        got = call_candidate(
            "engines/stylesheet_updates/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(
            got,
            {"dependencies": {"a": ["x", "y"], "b": ["y"]}, "affected": ["a", "b"]},
        )


if __name__ == "__main__":
    unittest.main()
