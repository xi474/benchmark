"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import hashlib
import io
import tarfile
import zlib

from runtime import build


def _decode_bundle(bundle_b64):
    raw = base64.b64decode(bundle_b64)
    tf = tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz")
    return tf


def _read_object(objdir, sha):
    """Read and decompress a loose git object by full hex sha. Returns bytes."""
    p = Path(objdir) / sha[:2] / sha[2:]
    return zlib.decompress(p.read_bytes())


def _iter_objects(objdir):
    """Yield (sha, raw_object_bytes) for every loose object."""
    objdir = Path(objdir)
    for d in objdir.iterdir():
        if not d.is_dir() or len(d.name) != 2:
            continue
        for f in d.iterdir():
            sha = d.name + f.name
            yield sha, zlib.decompress(f.read_bytes())


def _parse_object(raw):
    """Split raw object into (type, body_bytes)."""
    header, _, body = raw.partition(b"\x00")
    typ = header.split(b" ")[0].decode("ascii")
    return typ, body


def _commit_tree_and_parents(body):
    """Return (tree_sha, [parent_shas]) from a commit body."""
    tree = None
    parents = []
    for line in body.split(b"\n"):
        if line.startswith(b"tree "):
            tree = line[5:].decode("ascii")
        elif line.startswith(b"parent "):
            parents.append(line[7:].decode("ascii"))
        elif line == b"":
            break
    return tree, parents


def _commit_message(body):
    """Return the commit message (subject line) from a commit body."""
    idx = body.find(b"\n\n")
    if idx == -1:
        return ""
    msg = body[idx + 2:]
    for line in msg.split(b"\n"):
        if line.strip():
            return line.decode("utf-8", "replace")
    return ""


def _tree_entries(body):
    """Parse a tree body into list of (mode, name, sha)."""
    entries = []
    i = 0
    while i < len(body):
        sp = body.index(b" ", i)
        mode = body[i:sp].decode("ascii")
        nul = body.index(b"\x00", sp)
        name = body[sp + 1:nul].decode("utf-8", "replace")
        sha = body[nul + 1:nul + 21].hex()
        entries.append((mode, name, sha))
        i = nul + 21
    return entries


def _collect_reachable(objdir, head_sha):
    """Return set of object shas reachable from head_sha."""
    seen = set()
    stack = [head_sha]
    while stack:
        sha = stack.pop()
        if sha in seen:
            continue
        seen.add(sha)
        raw = _read_object(objdir, sha)
        typ, body = _parse_object(raw)
        if typ == "commit":
            tree, parents = _commit_tree_and_parents(body)
            if tree:
                stack.append(tree)
            stack.extend(parents)
        elif typ == "tree":
            for mode, name, child in _tree_entries(body):
                stack.append(child)
    return seen


def _find_secret_objects(objdir, secret):
    """Return set of object shas whose content contains the secret marker."""
    found = set()
    for sha, raw in _iter_objects(objdir):
        if secret.encode("utf-8") in raw:
            found.add(sha)
    return found


def _read_head_sha(repo):
    head = (Path(repo) / ".git" / "HEAD").read_text(encoding="utf-8").strip()
    if head.startswith("ref: "):
        ref = head[5:]
        return (Path(repo) / ".git" / ref).read_text(encoding="utf-8").strip()
    return head


def _list_commits_newest_first(objdir, head_sha):
    """Return list of commit messages from head back to root (newest first)."""
    messages = []
    sha = head_sha
    while sha:
        raw = _read_object(objdir, sha)
        typ, body = _parse_object(raw)
        if typ != "commit":
            break
        messages.append(_commit_message(body))
        tree, parents = _commit_tree_and_parents(body)
        sha = parents[0] if parents else None
    return messages


def _working_tree_files(repo):
    """Return {relative_path: sha256} for non-.git files in the working tree."""
    result = {}
    repo = Path(repo)
    for p in repo.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(repo)
        parts = rel.parts
        if parts and parts[0] == ".git":
            continue
        result[rel.as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result


def transform(payload, contract):
    bundle_b64 = payload["bundle"]
    scan = payload["scan"]
    secret = scan["secret"]

    tf = _decode_bundle(bundle_b64)

    import tempfile
    repo = tempfile.mkdtemp(prefix="cleaned-repo-")
    tf.extractall(repo)

    objdir = Path(repo) / ".git" / "objects"

    # 1. Confirm the recovered secret actually exists in the repository.
    secret_objs = _find_secret_objects(objdir, secret)
    if not secret_objs:
        raise ValueError("recovered secret not found in repository")

    head_sha = _read_head_sha(repo)
    reachable = _collect_reachable(objdir, head_sha)

    # 2. Remove the secret marker: delete every object containing it, plus any
    #    unreachable object that (transitively) references a removed object.
    to_remove = set(secret_objs)
    changed = True
    while changed:
        changed = False
        for sha, raw in _iter_objects(objdir):
            if sha in to_remove or sha in reachable:
                continue
            typ, body = _parse_object(raw)
            refs = []
            if typ == "commit":
                tree, parents = _commit_tree_and_parents(body)
                if tree:
                    refs.append(tree)
                refs.extend(parents)
            elif typ == "tree":
                for mode, name, child in _tree_entries(body):
                    refs.append(child)
            if any(r in to_remove for r in refs):
                to_remove.add(sha)
                changed = True

    # Delete the objects.
    for sha in to_remove:
        p = objdir / sha[:2] / sha[2:]
        if p.exists():
            p.unlink()
        parent = objdir / sha[:2]
        try:
            parent.rmdir()
        except OSError:
            pass

    # 3. Clean reflog entries that reference removed commits, and ORIG_HEAD.
    removed_hex = set(to_remove)
    for logpath in [Path(repo) / ".git" / "logs" / "HEAD",
                    Path(repo) / ".git" / "logs" / "refs" / "heads" / "master"]:
        if not logpath.exists():
            continue
        lines = logpath.read_text(encoding="utf-8").splitlines()
        kept = []
        for line in lines:
            parts = line.split(" ")
            if len(parts) >= 2:
                old, new = parts[0], parts[1]
                if old in removed_hex or new in removed_hex:
                    continue
            kept.append(line)
        logpath.write_text("\n".join(kept) + ("\n" if kept else ""),
                           encoding="utf-8")

    orig_head = Path(repo) / ".git" / "ORIG_HEAD"
    if orig_head.exists():
        val = orig_head.read_text(encoding="utf-8").strip()
        if val in removed_hex:
            orig_head.unlink()

    # 4. Compute outputs.
    files = _working_tree_files(repo)
    messages = _list_commits_newest_first(objdir, head_sha)

    # 5. Re-pack the repository into a tar.gz and base64 it.
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as out:
        out.add(repo, arcname=".")
    bundle_out = base64.b64encode(buf.getvalue()).decode("ascii")

    return {
        "bundle": bundle_out,
        "files": files,
        "messages": messages,
    }


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
