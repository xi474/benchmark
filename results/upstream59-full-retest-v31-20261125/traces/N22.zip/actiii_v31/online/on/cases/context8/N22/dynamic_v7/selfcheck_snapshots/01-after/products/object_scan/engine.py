"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import io
import re
import tarfile
import tempfile
import zlib
from runtime import build


def _iter_objects(repo_dir):
    """Yield (sha1_hex, decompressed_bytes) for every loose object in the repo."""
    objdir = Path(repo_dir) / ".git" / "objects"
    for p in objdir.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(objdir)
        if len(rel.parts) != 2:
            continue
        sha = "".join(rel.parts)
        if len(sha) != 40:
            continue
        raw = p.read_bytes()
        try:
            data = zlib.decompress(raw)
        except zlib.error:
            continue
        yield sha, data


def _extract_bundle(bundle_b64):
    """Decode base64 gzip-tar and extract to a temp dir; return the repo dir."""
    raw = base64.b64decode(bundle_b64)
    td = tempfile.mkdtemp(prefix="object_scan_")
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tf:
        tf.extractall(td)
    return td


def transform(payload, contract):
    bundle = payload["bundle"]
    repo_dir = _extract_bundle(bundle)
    secret = None
    for sha, data in _iter_objects(repo_dir):
        # Only blob objects can carry the secret marker.
        if not data.startswith(b"blob "):
            continue
        # Skip the header line "blob <size>\0"
        nul = data.find(b"\x00")
        if nul == -1:
            continue
        content = data[nul + 1:]
        m = re.search(rb"secret\[[^\]]*\]", content)
        if m:
            secret = m.group(0).decode("utf-8")
            break
    if secret is None:
        raise ValueError("secret marker not found in repository objects")
    return {"secret": secret}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
