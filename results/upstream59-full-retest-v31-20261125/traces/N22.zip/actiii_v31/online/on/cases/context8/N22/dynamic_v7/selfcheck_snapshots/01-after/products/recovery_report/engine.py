"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import hashlib
import tarfile
import tempfile
import io
import shutil
import zlib
import struct
from runtime import build


def _unpack_bundle(bundle_b64):
    """Unpack a base64 gzip-tar bundle into a temporary directory and return its path."""
    data = base64.b64decode(bundle_b64)
    tmpdir = tempfile.mkdtemp(prefix="recovery-report-")
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
        tf.extractall(tmpdir)
    return tmpdir


class _GitRepo:
    """Minimal pure-Python reader for a local git repository object database."""

    def __init__(self, root):
        self.root = Path(root)
        self.gitdir = self.root / ".git"
        if not self.gitdir.exists():
            # Possibly a bare repo or the bundle root is the .git dir itself.
            if (self.root / "HEAD").exists() and (self.root / "objects").exists():
                self.gitdir = self.root
            else:
                raise RuntimeError("not a git repository: " + str(self.root))
        self.objdir = self.gitdir / "objects"
        self._pack_index_cache = None

    # ---- object database ----
    def _loose_object_ids(self):
        ids = []
        for d in self.objdir.iterdir():
            if not d.is_dir() or len(d.name) != 2:
                continue
            for f in d.iterdir():
                if f.is_file():
                    ids.append(d.name + f.name)
        return ids

    def _pack_indexes(self):
        if self._pack_index_cache is None:
            idxs = []
            packdir = self.objdir / "pack"
            if packdir.exists():
                for f in packdir.iterdir():
                    if f.name.endswith(".idx"):
                        idxs.append(f)
            self._pack_index_cache = idxs
        return self._pack_index_cache

    def _read_pack_index(self, idx_path):
        """Return dict mapping object id (hex) -> (pack_path, offset)."""
        data = idx_path.read_bytes()
        if data[:4] != b"\xfftOc":
            raise RuntimeError("unsupported pack index: " + str(idx_path))
        version = struct.unpack(">I", data[4:8])[0]
        if version != 2:
            raise RuntimeError("unsupported pack index version: " + str(version))
        fanout = struct.unpack(">256I", data[8:8 + 256 * 4])
        n = fanout[255]
        # 256*4 fanout + 20*n sha1 + 4*n crc + 4*n offsets
        sha_start = 8 + 256 * 4
        sha_end = sha_start + 20 * n
        shas = data[sha_start:sha_end]
        crc_start = sha_end
        off_start = crc_start + 4 * n
        off_end = off_start + 4 * n
        offsets = struct.unpack(">%dI" % n, data[off_start:off_end])
        result = {}
        for i in range(n):
            sha = shas[i * 20:(i + 1) * 20].hex()
            off = offsets[i]
            if off & 0x80000000:
                # large offset table
                large_idx = off & 0x7fffffff
                large_start = off_end
                large_off = struct.unpack(">Q", data[large_start + large_idx * 8:large_start + large_idx * 8 + 8])[0]
                off = large_off
            result[sha] = (idx_path.with_suffix(".pack"), off)
        return result

    def _all_object_ids(self):
        ids = set(self._loose_object_ids())
        for idx in self._pack_indexes():
            ids.update(self._read_pack_index(idx).keys())
        return ids

    def _read_loose_object(self, oid):
        path = self.objdir / oid[:2] / oid[2:]
        if not path.exists():
            return None
        raw = zlib.decompress(path.read_bytes())
        # header: "<type> <size>\0"
        nul = raw.index(b"\x00")
        header = raw[:nul].decode("ascii")
        typ, size = header.split(" ")
        return typ, raw[nul + 1:]

    def _read_pack_object(self, pack_path, offset):
        with open(pack_path, "rb") as fh:
            fh.seek(offset)
            return self._read_pack_object_at(fh, offset)

    def _read_pack_object_at(self, fh, offset):
        fh.seek(offset)
        b = fh.read(1)[0]
        typ = (b >> 4) & 0x7
        size = b & 0x0f
        shift = 4
        while b & 0x80:
            b = fh.read(1)[0]
            size |= (b & 0x7f) << shift
            shift += 7
        type_names = {1: "commit", 2: "tree", 3: "blob", 4: "tag", 6: "ofs_delta", 7: "ref_delta"}
        typ_name = type_names.get(typ, "unknown")
        if typ in (1, 2, 3, 4):
            data = zlib.decompressobj()
            out = data.decompress(fh.read(), size)
            out += data.flush()
            return typ_name, out
        elif typ == 6:
            # ofs_delta
            b = fh.read(1)[0]
            base_off = b & 0x7f
            while b & 0x80:
                b = fh.read(1)[0]
                base_off = ((base_off + 1) << 7) | (b & 0x7f)
            base_offset = offset - base_off
            data = zlib.decompressobj()
            delta = data.decompress(fh.read(), size)
            delta += data.flush()
            base_type, base_data = self._read_pack_object_at(fh, base_offset)
            return base_type, self._apply_delta(base_data, delta)
        elif typ == 7:
            # ref_delta
            base_sha = fh.read(20).hex()
            data = zlib.decompressobj()
            delta = data.decompress(fh.read(), size)
            delta += data.flush()
            base_type, base_data = self._read_object(base_sha)
            return base_type, self._apply_delta(base_data, delta)
        raise RuntimeError("unknown pack object type")

    def _apply_delta(self, base, delta):
        pos = 0
        # source size
        src_size, pos = self._read_varint(delta, pos)
        # target size
        tgt_size, pos = self._read_varint(delta, pos)
        out = bytearray()
        while pos < len(delta):
            cmd = delta[pos]
            pos += 1
            if cmd & 0x80:
                # copy from base
                cp_off = 0
                cp_size = 0
                if cmd & 0x01:
                    cp_off |= delta[pos]; pos += 1
                if cmd & 0x02:
                    cp_off |= delta[pos] << 8; pos += 1
                if cmd & 0x04:
                    cp_off |= delta[pos] << 16; pos += 1
                if cmd & 0x08:
                    cp_off |= delta[pos] << 24; pos += 1
                if cmd & 0x10:
                    cp_size |= delta[pos]; pos += 1
                if cmd & 0x20:
                    cp_size |= delta[pos] << 8; pos += 1
                if cmd & 0x40:
                    cp_size |= delta[pos] << 16; pos += 1
                if cp_size == 0:
                    cp_size = 0x10000
                out += base[cp_off:cp_off + cp_size]
            elif cmd:
                # insert literal
                out += delta[pos:pos + cmd]
                pos += cmd
            else:
                raise RuntimeError("invalid delta opcode 0")
        return bytes(out)

    @staticmethod
    def _read_varint(data, pos):
        result = 0
        shift = 0
        while True:
            b = data[pos]
            pos += 1
            result |= (b & 0x7f) << shift
            shift += 7
            if not (b & 0x80):
                break
        return result, pos

    def _read_object(self, oid):
        """Return (type, content_bytes) for an object id, or None."""
        loose = self._read_loose_object(oid)
        if loose is not None:
            return loose
        for idx in self._pack_indexes():
            mapping = self._read_pack_index(idx)
            if oid in mapping:
                pack_path, offset = mapping[oid]
                return self._read_pack_object(pack_path, offset)
        return None

    # ---- high level ----
    def all_object_ids(self):
        return self._all_object_ids()

    def object_contains_secret(self, oid):
        obj = self._read_object(oid)
        if obj is None:
            return False
        typ, content = obj
        if typ == "blob":
            return b"secret[" in content
        # For commit/tree/tag, check raw content too (secret could be in message).
        return b"secret[" in content

    def _resolve_head(self):
        head = self.gitdir / "HEAD"
        if not head.exists():
            return None
        ref = head.read_text(encoding="utf-8", errors="replace").strip()
        if ref.startswith("ref: "):
            refpath = self.gitdir / ref[5:]
            if refpath.exists():
                return refpath.read_text(encoding="utf-8", errors="replace").strip()
            return None
        return ref

    def _parse_tree(self, tree_content):
        """Return list of (mode, name, oid) entries."""
        entries = []
        pos = 0
        while pos < len(tree_content):
            sp = tree_content.index(b" ", pos)
            mode = tree_content[pos:sp].decode("ascii")
            pos = sp + 1
            nul = tree_content.index(b"\x00", pos)
            name = tree_content[pos:nul].decode("utf-8", errors="replace")
            pos = nul + 1
            oid = tree_content[pos:pos + 20].hex()
            pos += 20
            entries.append((mode, name, oid))
        return entries

    def tracked_files(self):
        """Return list of (relative_path, blob_oid) for files in HEAD tree."""
        head_oid = self._resolve_head()
        if head_oid is None:
            return []
        commit = self._read_object(head_oid)
        if commit is None or commit[0] != "commit":
            return []
        # find tree line
        tree_oid = None
        for line in commit[1].split(b"\n"):
            if line.startswith(b"tree "):
                tree_oid = line[5:].decode("ascii").strip()
                break
        if tree_oid is None:
            return []
        result = []
        stack = [("", tree_oid)]
        while stack:
            prefix, oid = stack.pop()
            obj = self._read_object(oid)
            if obj is None:
                continue
            typ, content = obj
            if typ == "tree":
                for mode, name, child_oid in self._parse_tree(content):
                    full = (prefix + "/" + name) if prefix else name
                    if mode == "40000":
                        stack.append((full, child_oid))
                    else:
                        result.append((full, child_oid))
            elif typ == "blob":
                result.append((prefix, oid))
        return result

    def commit_messages(self):
        """Return list of commit subject lines, newest to oldest."""
        head_oid = self._resolve_head()
        if head_oid is None:
            return []
        messages = []
        seen = set()
        oid = head_oid
        while oid and oid not in seen:
            seen.add(oid)
            obj = self._read_object(oid)
            if obj is None or obj[0] != "commit":
                break
            content = obj[1]
            # subject is first line after headers (blank line separates)
            lines = content.split(b"\n")
            subject = None
            in_headers = True
            for line in lines:
                if in_headers:
                    if line == b"":
                        in_headers = False
                    continue
                if line.strip():
                    subject = line.decode("utf-8", errors="replace")
                    break
            if subject is not None:
                messages.append(subject)
            # find parent
            parent = None
            for line in content.split(b"\n"):
                if line.startswith(b"parent "):
                    parent = line[7:].decode("ascii").strip()
                    break
            oid = parent
        return messages


def transform(payload, contract):
    scan = payload["scan"]
    cleaned = payload["cleaned"]

    secret = scan["secret"]

    repo = _unpack_bundle(cleaned["bundle"])
    try:
        gr = _GitRepo(repo)

        # Enumerate all objects and verify none contains secret[...].
        remaining = 0
        for oid in gr.all_object_ids():
            if gr.object_contains_secret(oid):
                remaining += 1

        # Compute files: SHA256 of ordinary working-tree files (tracked files).
        files = {}
        for rel, blob_oid in gr.tracked_files():
            obj = gr._read_object(blob_oid)
            if obj is not None and obj[0] == "blob":
                files[rel] = hashlib.sha256(obj[1]).hexdigest()

        messages = gr.commit_messages()

        return {
            "secret": secret,
            "files": files,
            "messages": messages,
            "remaining_secret_objects": remaining,
        }
    finally:
        shutil.rmtree(repo, ignore_errors=True)


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
