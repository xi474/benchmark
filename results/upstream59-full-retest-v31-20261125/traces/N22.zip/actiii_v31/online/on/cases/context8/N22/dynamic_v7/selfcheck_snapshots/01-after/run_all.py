"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import read, module


def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    # Load each component's contract and engine.
    components = {}
    for name, out_path in delivery["component_outputs"].items():
        comp_dir = root / "products" / name
        contract = read(comp_dir / "contract.json")
        engine = module(str(comp_dir), "engine.py")
        components[name] = (contract, engine, out_path)

    # Dependency order: object_scan -> cleaned_repo -> recovery_report.
    order = ["object_scan", "cleaned_repo", "recovery_report"]

    results = {}
    for name in order:
        contract, engine, out_path = components[name]
        value = engine.build_component(str(root), contract)
        results[name] = value

    result_file = delivery["result_file"]
    result_value = read(root / result_file)

    final = {
        "task": delivery["task"],
        "results": results,
        "result": result_value,
    }
    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(final, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
