import unittest

# Injected by the visible-contract-check SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict
# check_api_boundary(...) -> raises on failure


API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/object_scan/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/object_scan/SPEC.md",
                "requirement_quote": "transform(payload, contract) 接收 contract.bindings 对应的字段字典，返回本规格定义的 JSON 值",
                "reason": "SPEC does not state a ValueError rule for unknown or non-finite fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/object_scan/SPEC.md",
                "requirement_quote": "transform(payload, contract) 接收 contract.bindings 对应的字段字典，返回本规格定义的 JSON 值",
                "reason": "SPEC does not state a ValueError rule for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/cleaned_repo/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/cleaned_repo/SPEC.md",
                "requirement_quote": "transform(payload, contract) 接收 contract.bindings 对应的字段字典，返回本规格定义的 JSON 值",
                "reason": "SPEC does not state a ValueError rule for unknown or non-finite fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/cleaned_repo/SPEC.md",
                "requirement_quote": "transform(payload, contract) 接收 contract.bindings 对应的字段字典，返回本规格定义的 JSON 值",
                "reason": "SPEC does not state a ValueError rule for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/recovery_report/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/recovery_report/SPEC.md",
                "requirement_quote": "transform(payload, contract) 接收 contract.bindings 对应的字段字典，返回本规格定义的 JSON 值",
                "reason": "SPEC does not state a ValueError rule for unknown or non-finite fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/recovery_report/SPEC.md",
                "requirement_quote": "transform(payload, contract) 接收 contract.bindings 对应的字段字典，返回本规格定义的 JSON 值",
                "reason": "SPEC does not state a ValueError rule for invalid payload types.",
            },
        },
    },
]


class ObjectScanBehavior(unittest.TestCase):
    """object_scan: recover secret[...] from unreachable git object."""

    def test_secret_recovered_from_bundle(self):
        # Build a minimal git repo with a rewritten history whose unreachable
        # blob carries a secret[...] marker, then verify transform recovers it.
        import base64
        import io
        import os
        import subprocess
        import tarfile
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo = os.path.join(td, "repo")
            subprocess.run(["git", "init", "-q", repo], check=True)
            env = dict(os.environ)
            env["GIT_AUTHOR_NAME"] = "T"
            env["GIT_AUTHOR_EMAIL"] = "t@example.invalid"
            env["GIT_COMMITTER_NAME"] = "T"
            env["GIT_COMMITTER_EMAIL"] = "t@example.invalid"

            def git(*args):
                subprocess.run(["git", *args], cwd=repo, check=True, env=env)

            # First commit with a secret file.
            with open(os.path.join(repo, "secret.txt"), "w") as f:
                f.write("secret[THE-MARKER]\n")
            git("add", "secret.txt")
            git("commit", "-q", "-m", "init")

            # Rewrite history to drop the secret file (unreachable object).
            git("rm", "-q", "secret.txt")
            git("commit", "-q", "-m", "keep notes")

            # Pack into tar.gz and base64.
            buf = io.BytesIO()
            with tarfile.open(fileobj=buf, mode="w:gz") as tf:
                tf.add(repo, arcname="repo")
            bundle = base64.b64encode(buf.getvalue()).decode("ascii")

            payload = {"bundle": bundle}
            contract = {"bindings": {"bundle": "inputs/request.json#/bundle"}}
            result = call_candidate(
                "products/object_scan/engine.py", "transform", args=[payload, contract]
            )
            self.assertEqual(result["secret"], "secret[THE-MARKER]")


class CleanedRepoBehavior(unittest.TestCase):
    """cleaned_repo: remove secret objects, preserve files and messages."""

    def test_cleaned_repo_preserves_files_and_messages(self):
        import base64
        import hashlib
        import io
        import os
        import subprocess
        import tarfile
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo = os.path.join(td, "repo")
            subprocess.run(["git", "init", "-q", repo], check=True)
            env = dict(os.environ)
            env["GIT_AUTHOR_NAME"] = "T"
            env["GIT_AUTHOR_EMAIL"] = "t@example.invalid"
            env["GIT_COMMITTER_NAME"] = "T"
            env["GIT_COMMITTER_EMAIL"] = "t@example.invalid"

            def git(*args):
                subprocess.run(["git", *args], cwd=repo, check=True, env=env)

            with open(os.path.join(repo, "notes.txt"), "w") as f:
                f.write("hello notes\n")
            git("add", "notes.txt")
            git("commit", "-q", "-m", "init")

            with open(os.path.join(repo, "secret.txt"), "w") as f:
                f.write("secret[THE-MARKER]\n")
            git("add", "secret.txt")
            git("commit", "-q", "-m", "add secret")

            git("rm", "-q", "secret.txt")
            git("commit", "-q", "-m", "keep notes")

            buf = io.BytesIO()
            with tarfile.open(fileobj=buf, mode="w:gz") as tf:
                tf.add(repo, arcname="repo")
            bundle = base64.b64encode(buf.getvalue()).decode("ascii")

            payload = {"bundle": bundle, "scan": {"secret": "secret[THE-MARKER]"}}
            contract = {
                "bindings": {
                    "bundle": "inputs/request.json#/bundle",
                    "scan": "outputs/object_scan.json#",
                }
            }
            result = call_candidate(
                "products/cleaned_repo/engine.py", "transform", args=[payload, contract]
            )

            # messages newest-first: "keep notes", "init"
            self.assertEqual(result["messages"], ["keep notes", "init"])
            # notes.txt preserved with correct sha256
            expected_sha = hashlib.sha256(b"hello notes\n").hexdigest()
            self.assertEqual(result["files"]["notes.txt"], expected_sha)
            # secret.txt must not appear in files
            self.assertNotIn("secret.txt", result["files"])


class RecoveryReportBehavior(unittest.TestCase):
    """recovery_report: verify no secret objects remain."""

    def test_report_verifies_no_secret_objects(self):
        import base64
        import hashlib
        import io
        import os
        import subprocess
        import tarfile
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo = os.path.join(td, "repo")
            subprocess.run(["git", "init", "-q", repo], check=True)
            env = dict(os.environ)
            env["GIT_AUTHOR_NAME"] = "T"
            env["GIT_AUTHOR_EMAIL"] = "t@example.invalid"
            env["GIT_COMMITTER_NAME"] = "T"
            env["GIT_COMMITTER_EMAIL"] = "t@example.invalid"

            def git(*args):
                subprocess.run(["git", *args], cwd=repo, check=True, env=env)

            with open(os.path.join(repo, "notes.txt"), "w") as f:
                f.write("hello notes\n")
            git("add", "notes.txt")
            git("commit", "-q", "-m", "init")

            # A clean repo with no secret objects.
            buf = io.BytesIO()
            with tarfile.open(fileobj=buf, mode="w:gz") as tf:
                tf.add(repo, arcname="repo")
            bundle = base64.b64encode(buf.getvalue()).decode("ascii")

            payload = {
                "scan": {"secret": "secret[THE-MARKER]"},
                "cleaned": {"bundle": bundle},
            }
            contract = {
                "bindings": {
                    "scan": "outputs/object_scan.json#",
                    "cleaned": "outputs/cleaned_repo.json#",
                }
            }
            result = call_candidate(
                "products/recovery_report/engine.py", "transform", args=[payload, contract]
            )

            self.assertEqual(result["secret"], "secret[THE-MARKER]")
            self.assertEqual(result["remaining_secret_objects"], 0)
            self.assertEqual(result["messages"], ["init"])
            expected_sha = hashlib.sha256(b"hello notes\n").hexdigest()
            self.assertEqual(result["files"]["notes.txt"], expected_sha)


if __name__ == "__main__":
    unittest.main()
