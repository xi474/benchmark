import unittest

# Injected by the visible-contract-check SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict
# check_api_boundary(...) -> raises on failure


API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/object_scan/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/object_scan/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC does not state a ValueError rule for unknown or non-finite fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/object_scan/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC does not state a ValueError rule for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/cleaned_repo/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/cleaned_repo/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC does not state a ValueError rule for unknown or non-finite fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/cleaned_repo/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC does not state a ValueError rule for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/recovery_report/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/recovery_report/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC does not state a ValueError rule for unknown or non-finite fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/recovery_report/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC does not state a ValueError rule for invalid payload types.",
            },
        },
    },
]


def _make_bundle(repo_dir):
    """Pack a directory into a base64 gzip-tar bundle string."""
    import base64
    import io
    import tarfile

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        tf.add(repo_dir, arcname=".")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _write_loose_object(objdir, oid, raw):
    """Write a loose git object (raw = header + b'\\x00' + body)."""
    import os
    import zlib

    d = os.path.join(objdir, oid[:2])
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, oid[2:]), "wb") as f:
        f.write(zlib.compress(raw))


def _sha1(data):
    import hashlib

    return hashlib.sha1(data).hexdigest()


def _blob(content):
    return b"blob %d\x00" % len(content) + content


def _tree(entries):
    """entries: list of (mode, name, oid_hex)."""
    body = b""
    for mode, name, oid in entries:
        body += mode.encode() + b" " + name.encode() + b"\x00" + bytes.fromhex(oid)
    return b"tree %d\x00" % len(body) + body


def _commit(tree_oid, parents, message):
    body = b"tree " + tree_oid.encode() + b"\n"
    for p in parents:
        body += b"parent " + p.encode() + b"\n"
    body += b"author T <t@example.invalid> 0 +0000\n"
    body += b"committer T <t@example.invalid> 0 +0000\n\n"
    body += message.encode() + b"\n"
    return b"commit %d\x00" % len(body) + body


def _build_repo_with_secret(tmpdir):
    """Build a git repo with a rewritten history whose unreachable blob
    carries a secret[...] marker. Returns (repo_dir, secret)."""
    import os

    repo = os.path.join(tmpdir, "repo")
    gitdir = os.path.join(repo, ".git")
    objdir = os.path.join(gitdir, "objects")
    os.makedirs(objdir)
    os.makedirs(os.path.join(gitdir, "refs", "heads"))
    os.makedirs(os.path.join(gitdir, "logs", "refs", "heads"))

    secret = "secret[THE-MARKER]"

    # Blobs
    notes_blob = b"hello notes\n"
    secret_blob = secret.encode() + b"\n"
    notes_oid = _sha1(_blob(notes_blob))
    secret_oid = _sha1(_blob(secret_blob))

    # Tree for the secret commit (contains secret.txt)
    tree_secret = _tree([("100644", "secret.txt", secret_oid)])
    tree_secret_oid = _sha1(tree_secret)

    # Tree for the final commit (contains notes.txt)
    tree_final = _tree([("100644", "notes.txt", notes_oid)])
    tree_final_oid = _sha1(tree_final)

    # Commits
    commit_init = _commit(tree_secret_oid, [], "init")
    commit_init_oid = _sha1(commit_init)
    commit_keep = _commit(tree_final_oid, [commit_init_oid], "keep notes")
    commit_keep_oid = _sha1(commit_keep)

    # Write all objects
    _write_loose_object(objdir, notes_oid, _blob(notes_blob))
    _write_loose_object(objdir, secret_oid, _blob(secret_blob))
    _write_loose_object(objdir, tree_secret_oid, tree_secret)
    _write_loose_object(objdir, tree_final_oid, tree_final)
    _write_loose_object(objdir, commit_init_oid, commit_init)
    _write_loose_object(objdir, commit_keep_oid, commit_keep)

    # HEAD -> refs/heads/master -> commit_keep
    with open(os.path.join(gitdir, "HEAD"), "w") as f:
        f.write("ref: refs/heads/master\n")
    with open(os.path.join(gitdir, "refs", "heads", "master"), "w") as f:
        f.write(commit_keep_oid + "\n")

    # Working tree files
    with open(os.path.join(repo, "notes.txt"), "w") as f:
        f.write("hello notes\n")

    return repo, secret


class ObjectScanBehavior(unittest.TestCase):
    """object_scan: recover secret[...] from unreachable git object."""

    def test_secret_recovered_from_bundle(self):
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo, secret = _build_repo_with_secret(td)
            bundle = _make_bundle(repo)
            payload = {"bundle": bundle}
            contract = {"bindings": {"bundle": "inputs/request.json#/bundle"}}
            result = call_candidate(
                "products/object_scan/engine.py", "transform", args=[payload, contract]
            )
            self.assertEqual(result["secret"], secret)


class CleanedRepoBehavior(unittest.TestCase):
    """cleaned_repo: remove secret objects, preserve files and messages."""

    def test_cleaned_repo_preserves_files_and_messages(self):
        import hashlib
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo, secret = _build_repo_with_secret(td)
            bundle = _make_bundle(repo)
            payload = {"bundle": bundle, "scan": {"secret": secret}}
            contract = {
                "bindings": {
                    "bundle": "inputs/request.json#/bundle",
                    "scan": "outputs/object_scan.json#",
                }
            }
            result = call_candidate(
                "products/cleaned_repo/engine.py", "transform", args=[payload, contract]
            )

            self.assertEqual(result["messages"], ["keep notes", "init"])
            expected_sha = hashlib.sha256(b"hello notes\n").hexdigest()
            self.assertEqual(result["files"]["notes.txt"], expected_sha)
            self.assertNotIn("secret.txt", result["files"])


class RecoveryReportBehavior(unittest.TestCase):
    """recovery_report: verify no secret objects remain."""

    def test_report_verifies_no_secret_objects(self):
        import base64
        import hashlib
        import io
        import os
        import tarfile
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo, secret = _build_repo_with_secret(td)

            # Build a clean repo: remove the secret blob object entirely.
            objdir = os.path.join(repo, ".git", "objects")
            secret_blob = secret.encode() + b"\n"
            secret_oid = _sha1(_blob(secret_blob))
            p = os.path.join(objdir, secret_oid[:2], secret_oid[2:])
            os.remove(p)

            bundle = _make_bundle(repo)
            payload = {
                "scan": {"secret": secret},
                "cleaned": {"bundle": bundle},
            }
            contract = {
                "bindings": {
                    "scan": "outputs/object_scan.json#",
                    "cleaned": "outputs/cleaned_repo.json#",
                }
            }
            result = call_candidate(
                "products/recovery_report/engine.py", "transform", args=[payload, contract]
            )

            self.assertEqual(result["secret"], secret)
            self.assertEqual(result["remaining_secret_objects"], 0)
            self.assertEqual(result["messages"], ["keep notes", "init"])
            expected_sha = hashlib.sha256(b"hello notes\n").hexdigest()
            self.assertEqual(result["files"]["notes.txt"], expected_sha)


if __name__ == "__main__":
    unittest.main()
