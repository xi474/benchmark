"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    accounts = payload["accounts"]
    books = payload["books"]
    orders = payload["orders"]
    journal = payload["journal"]

    # Inputs are already-parsed JSON lists from the upstream components.
    accs = [dict(a) for a in accounts]
    bks = [dict(b) for b in books]

    acc_by_id = {a["id"]: a for a in accs}
    book_by_id = {b["id"]: b for b in bks}

    statuses = []
    for order in orders:
        buyer = order["buyer"]
        seller = order["seller"]
        book_id = order["book"]
        amount = order["amount"]
        book = book_by_id[book_id]
        if book["owner"] == seller:
            acc_by_id[buyer]["balance"] -= amount
            acc_by_id[seller]["balance"] += amount
            book["owner"] = buyer
            journal += book_id + f"{amount:010d}" + seller + buyer
            statuses.append("accepted")
        else:
            statuses.append("rejected")

    accounts_out = "".join(
        a["id"] + a["name"].ljust(20) + f"{a['balance']:010d}" for a in accs
    )
    books_out = "".join(
        b["id"] + b["title"].ljust(20) + b["owner"] for b in bks
    )
    return {
        "accounts": accounts_out,
        "books": books_out,
        "journal": journal,
        "statuses": statuses,
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
