"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import build, read, module


def main():
    root = Path(__file__).resolve().parent

    contracts = {
        "accounts": read(root / "products/accounts/contract.json"),
        "books": read(root / "products/books/contract.json"),
        "orders": read(root / "products/orders/contract.json"),
        "settlement": read(root / "products/settlement/contract.json"),
    }

    engines = {
        name: module(root, f"products/{name}/engine.py")
        for name in ("accounts", "books", "orders", "settlement")
    }

    results = {}
    for name in ("accounts", "books", "orders", "settlement"):
        results[name] = build(root, contracts[name], engines[name].transform)

    delivery = read(root / "delivery.json")
    result_file = delivery["result_file"]
    result_value = read(root / result_file)

    report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value,
    }
    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
