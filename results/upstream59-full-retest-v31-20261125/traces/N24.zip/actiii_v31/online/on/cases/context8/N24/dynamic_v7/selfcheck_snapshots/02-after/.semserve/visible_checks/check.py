import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/accounts/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/accounts/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC explicitly limits scope to legal input domain; no ValueError rule for non-finite values is stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/accounts/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "No documented ValueError requirement for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/books/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/books/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC explicitly limits scope to legal input domain.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/books/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "No documented ValueError requirement for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/orders/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/orders/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC explicitly limits scope to legal input domain.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/orders/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "No documented ValueError requirement for invalid payload types.",
            },
        },
    },
    {
        "target_path": "products/settlement/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/settlement/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "SPEC explicitly limits scope to legal input domain.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/settlement/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入",
                "reason": "No documented ValueError requirement for invalid payload types.",
            },
        },
    },
]


class TestAccountsParse(unittest.TestCase):
    def test_parse_accounts_fixed_width(self):
        # 34-char records: ID4/name20/balance10, trailing spaces stripped.
        text = "U001John Doe            0000001000U002Jane Smith          0000002000"
        expected = [
            {"id": "U001", "name": "John Doe", "balance": 1000},
            {"id": "U002", "name": "Jane Smith", "balance": 2000},
        ]
        result = call_candidate("products/accounts/engine.py", "transform",
                                args=[{"text": text}, {}])
        self.assertEqual(result, expected)


class TestBooksParse(unittest.TestCase):
    def test_parse_books_fixed_width(self):
        # 28-char records: ID4/title20/owner4.
        text = "B001Python Basics       U001B003Java Tutorial       U003"
        expected = [
            {"id": "B001", "title": "Python Basics", "owner": "U001"},
            {"id": "B003", "title": "Java Tutorial", "owner": "U003"},
        ]
        result = call_candidate("products/books/engine.py", "transform",
                                args=[{"text": text}, {}])
        self.assertEqual(result, expected)


class TestOrdersParse(unittest.TestCase):
    def test_parse_orders_fixed_width(self):
        # 22-char records: buyer4/seller4/book4/amount10.
        orders = ["U001U003B0030000000020"]
        expected = [{"buyer": "U001", "seller": "U003", "book": "B003", "amount": 20}]
        result = call_candidate("products/orders/engine.py", "transform",
                                args=[{"orders": orders}, {}])
        self.assertEqual(result, expected)


class TestSettlement(unittest.TestCase):
    def _payload(self):
        accounts = [
            {"id": "U001", "name": "John Doe", "balance": 1000},
            {"id": "U002", "name": "Jane Smith", "balance": 2000},
            {"id": "U003", "name": "Bob Wilson", "balance": 1500},
        ]
        books = [
            {"id": "B001", "title": "Python Basics", "owner": "U001"},
            {"id": "B003", "title": "Java Tutorial", "owner": "U003"},
        ]
        return accounts, books

    def test_rejected_when_owner_mismatch(self):
        # Order where seller is not the current owner must be rejected and
        # leave all three files unchanged.
        accounts, books = self._payload()
        orders = [{"buyer": "U002", "seller": "U001", "book": "B003", "amount": 50}]
        payload = {"accounts": accounts, "books": books, "orders": orders, "journal": ""}
        result = call_candidate("products/settlement/engine.py", "transform",
                                args=[payload, {}])
        self.assertEqual(result["statuses"], ["rejected"])
        self.assertEqual(result["journal"], "")
        # Re-encoded accounts unchanged (balances 1000/2000/1500).
        self.assertEqual(
            result["accounts"],
            "U001John Doe            0000001000"
            "U002Jane Smith          0000002000"
            "U003Bob Wilson          0000001500",
        )
        self.assertEqual(
            result["books"],
            "B001Python Basics       U001B003Java Tutorial       U003",
        )

    def test_accepted_transfer_updates_state(self):
        # Valid transfer: buyer balance decreases, seller increases, owner changes.
        accounts, books = self._payload()
        orders = [{"buyer": "U001", "seller": "U003", "book": "B003", "amount": 20}]
        payload = {"accounts": accounts, "books": books, "orders": orders, "journal": ""}
        result = call_candidate("products/settlement/engine.py", "transform",
                                args=[payload, {}])
        self.assertEqual(result["statuses"], ["accepted"])
        self.assertEqual(result["journal"], "B0030000000020U003U001")
        self.assertEqual(
            result["accounts"],
            "U001John Doe            0000000980"
            "U002Jane Smith          0000002000"
            "U003Bob Wilson          0000001520",
        )
        self.assertEqual(
            result["books"],
            "B001Python Basics       U001B003Java Tutorial       U001",
        )


if __name__ == "__main__":
    unittest.main()
