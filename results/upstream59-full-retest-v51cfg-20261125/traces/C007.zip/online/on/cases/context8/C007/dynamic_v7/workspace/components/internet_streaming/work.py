import re
from datetime import datetime


def _alpha_lower(text):
    if text is None:
        return ""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _digits(text):
    if text is None:
        return ""
    return re.sub(r"[^0-9]", "", str(text))


def _iso_date(text):
    if not text:
        return ""
    s = str(text).strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%Y%m%d", "%d %b %Y"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return ""


def compute(payload):
    """标准化 ('internet', 'streaming') 渠道记录，返回 [原位置,字段对象] 数组。对象字段 id,first,last,dob,ssn,mail,phone,address，日期 ISO，文字小写去非字母数字，电话及证件仅留数字。"""
    out = []
    for pos, rec in enumerate(payload["records"]):
        if rec.get("source") not in ("internet", "streaming"):
            continue
        f = rec["fields"]
        if rec["source"] == "internet":
            full = f.get("full_name", "").strip()
            parts = full.split(" ", 1)
            first = parts[0] if parts else ""
            last = parts[1] if len(parts) > 1 else ""
            dob = _iso_date(f.get("birth_date", ""))
            mail = f.get("mail", "")
            phone = f.get("tel", "")
            address = f.get("street", "")
        else:  # streaming
            full = f.get("customer", "").strip()
            parts = full.split(" ", 1)
            first = parts[0] if parts else ""
            last = parts[1] if len(parts) > 1 else ""
            dob = _iso_date(f.get("date_of_birth", ""))
            mail = f.get("email", "")
            phone = f.get("telephone", "")
            address = f.get("address", "")
        out.append([
            pos,
            {
                "id": rec["id"],
                "first": _alpha_lower(first),
                "last": _alpha_lower(last),
                "dob": dob,
                "ssn": "",
                "mail": _alpha_lower(mail),
                "phone": _digits(phone),
                "address": _alpha_lower(address),
            },
        ])
    return out
