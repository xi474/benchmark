import re


def _alpha_lower(text):
    if text is None:
        return ""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _digits(text):
    if text is None:
        return ""
    return re.sub(r"[^0-9]", "", str(text))


def _iso_date(text):
    if not text:
        return ""
    text = str(text).strip()
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})", text)
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    return ""


def _normalize_mobile(fields, record_id):
    return {
        "id": record_id,
        "first": _alpha_lower(fields.get("first")),
        "last": _alpha_lower(fields.get("last")),
        "dob": _iso_date(fields.get("dob")),
        "ssn": _digits(fields.get("ssn")),
        "mail": _alpha_lower(fields.get("email")),
        "phone": _digits(fields.get("phone")),
        "address": _alpha_lower(fields.get("address")),
    }


def _normalize_cable(fields, record_id):
    last_first = fields.get("last_first", "")
    last, first = "", ""
    if "," in last_first:
        last, first = last_first.split(",", 1)
    else:
        parts = last_first.split()
        if parts:
            last = parts[0]
            first = " ".join(parts[1:])
    return {
        "id": record_id,
        "first": _alpha_lower(first),
        "last": _alpha_lower(last),
        "dob": _iso_date(fields.get("birth")),
        "ssn": _digits(fields.get("government_id")),
        "mail": _alpha_lower(fields.get("contact")),
        "phone": _digits(fields.get("phone")),
        "address": _alpha_lower(fields.get("location")),
    }


def compute(payload):
    """标准化 ('mobile', 'cable') 渠道记录，返回 [原位置,字段对象] 数组。对象字段 id,first,last,dob,ssn,mail,phone,address，日期 ISO，文字小写去非字母数字，电话及证件仅留数字。"""
    out = []
    for pos, record in enumerate(payload["records"]):
        source = record["source"]
        fields = record["fields"]
        if source == "mobile":
            obj = _normalize_mobile(fields, record["id"])
        elif source == "cable":
            obj = _normalize_cable(fields, record["id"])
        else:
            continue
        out.append([pos, obj])
    return out
