import re
from collections import defaultdict


def _norm_name(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _edit1(a, b):
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) < len(b):
        a, b = b, a
    if len(a) == len(b):
        return sum(1 for x, y in zip(a, b) if x != y) <= 1
    i = j = 0
    skipped = False
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1
            j += 1
        else:
            if skipped:
                return False
            skipped = True
            i += 1
    return True


def _same_person(a, b, ambiguous):
    sa, sb = a.get("ssn", ""), b.get("ssn", "")
    if len(sa) == 9 and len(sb) == 9:
        return sa == sb

    ssn4_match = False
    if len(sa) == 4 and len(sb) == 4 and sa == sb:
        ssn4_match = True
    elif len(sa) == 9 and len(sb) == 4 and sa[-4:] == sb:
        ssn4_match = True
    elif len(sb) == 9 and len(sa) == 4 and sb[-4:] == sa:
        ssn4_match = True

    fa, fb = a.get("first", ""), b.get("first", "")
    la, lb = a.get("last", ""), b.get("last", "")

    name_match = None
    name_conflict = False
    if fa and fb:
        if fa == fb:
            name_match = True
        elif fa in ambiguous or fb in ambiguous:
            name_match = None
        else:
            name_conflict = True
    if la and lb and la != lb:
        name_conflict = True

    da, db = a.get("dob", ""), b.get("dob", "")
    dob_match = bool(da and db and da == db)
    dob_conflict = bool(da and db and da != db)

    ma, mb = a.get("mail", ""), b.get("mail", "")
    mail_match = False
    if ma and mb and (ma == mb or _edit1(ma, mb)):
        mail_match = True

    phone_match = bool(a.get("phone") and a.get("phone") == b.get("phone"))
    addr_match = bool(a.get("address") and a.get("address") == b.get("address"))

    if name_conflict or dob_conflict:
        return False

    if name_match is True and dob_match:
        return True
    if name_match is True and mail_match:
        return True
    if dob_match and mail_match and name_match is not False:
        return True
    if ssn4_match and dob_match and (name_match is True or mail_match):
        return True
    if ssn4_match and name_match is True and mail_match:
        return True
    return False


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    records = []
    for pos, obj in left:
        records.append(obj)
    for pos, obj in right:
        records.append(obj)

    ambiguous = set(_norm_name(n) for n in payload.get("ambiguous_names", []))

    n = len(records)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    blocks = defaultdict(list)
    for i, r in enumerate(records):
        ssn = r.get("ssn", "")
        if len(ssn) == 9:
            blocks[("ssn9", ssn)].append(i)
        elif len(ssn) == 4:
            blocks[("ssn4", ssn)].append(i)
        if r.get("phone"):
            blocks[("phone", r["phone"])].append(i)
        if r.get("address"):
            blocks[("addr", r["address"])].append(i)
        if r.get("mail"):
            blocks[("mail", r["mail"])].append(i)
        if r.get("last"):
            blocks[("last", r["last"])].append(i)

    for key, idxs in blocks.items():
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                i, j = idxs[a], idxs[b]
                if find(i) == find(j):
                    continue
                if _same_person(records[i], records[j], ambiguous):
                    union(i, j)

    groups = defaultdict(list)
    for i, r in enumerate(records):
        groups[find(i)].append(r["id"])

    clusters = [sorted(ids) for ids in groups.values()]
    return {"clusters": clusters}
