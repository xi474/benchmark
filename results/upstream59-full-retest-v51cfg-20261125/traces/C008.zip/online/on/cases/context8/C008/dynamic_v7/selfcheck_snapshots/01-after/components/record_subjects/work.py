def compute(payload):
    """按记录顺序产生 [表名,行号,时间,[租户,主体]]，为跨表归一化保留租户作用域。"""
    result = []
    for record in payload.get("records", []):
        result.append([
            record["table"],
            record["id"],
            record["time"],
            [record["tenant"], record["subject"]],
        ])
    return result
