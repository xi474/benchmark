def compute(payload):
    """将链接和合并登记为 [起点,终点,生效时刻,失效时刻]。保留原顺序并补齐缺省区间。"""
    result = []
    for key in ("links", "merges"):
        for item in payload.get(key, []):
            start = item["a"]
            end = item["b"]
            from_ = item.get("from", 0)
            to_ = item.get("to", 10**18)
            result.append([start, end, from_, to_])
    return result
