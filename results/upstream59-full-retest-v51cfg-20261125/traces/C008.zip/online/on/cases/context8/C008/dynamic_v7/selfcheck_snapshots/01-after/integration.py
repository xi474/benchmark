import json
from hashlib import sha256


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    seed = payload["seed"]
    windows = left  # list of [start, end, from, to]
    subjects = right  # list of [table, id, time, [tenant, subject]]

    # Build union-find over all (tenant, subject) pairs that appear anywhere.
    nodes = set()
    for start, end, _from, _to in windows:
        nodes.add(tuple(start))
        nodes.add(tuple(end))
    for _table, _id, _time, subj in subjects:
        nodes.add(tuple(subj))

    parent = {n: n for n in nodes}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    # For each record time, apply windows active at that time.
    # Group records by time to avoid recomputation.
    from collections import defaultdict
    time_to_records = defaultdict(list)
    for idx, (_table, _id, time, subj) in enumerate(subjects):
        time_to_records[time].append(idx)

    # Canonical token cache keyed by (seed, canonical_tenant, canonical_subject)
    token_cache = {}

    def token_for(canonical):
        raw = json.dumps(
            [str(seed), canonical[0], canonical[1]],
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return "ref_" + sha256(raw).hexdigest()[:12]

    records_out = []
    for idx, (_table, _id, time, subj) in enumerate(subjects):
        # Build a fresh union-find for this time using active windows.
        local_parent = {n: n for n in nodes}

        def lfind(x):
            while local_parent[x] != x:
                local_parent[x] = local_parent[local_parent[x]]
                x = local_parent[x]
            return x

        def lunion(a, b):
            ra, rb = lfind(a), lfind(b)
            if ra != rb:
                local_parent[rb] = ra

        for start, end, _from, _to in windows:
            if _from <= time < _to:
                lunion(tuple(start), tuple(end))

        # Find canonical (lexicographically smallest) in this record's component.
        root = lfind(tuple(subj))
        component = [n for n in nodes if lfind(n) == root]
        canonical = min(component)

        token = token_for(canonical)
        records_out.append({
            "table": _table,
            "id": _id,
            "time": time,
            "token": token,
        })

    return {"records": records_out}
