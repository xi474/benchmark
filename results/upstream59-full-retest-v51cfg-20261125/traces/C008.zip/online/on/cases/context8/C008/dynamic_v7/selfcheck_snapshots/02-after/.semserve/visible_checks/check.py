import json
import unittest

# Injected names (available at runtime): call_candidate, CandidateCallError,
# check_api_boundary, visible_document.

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "只验公开输入域与核心业务约束，不验任意异常文本或编码风格。",
                "reason": "Public spec explicitly declines validation of arbitrary malformed input; non-finite values are outside the declared normal input domain.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "只验公开输入域与核心业务约束，不验任意异常文本或编码风格。",
                "reason": "Public spec does not require ValueError on invalid payload types; only the normal input domain is validated.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_output_shape_and_fields(self):
        # Output contract: records list with table/id/time/token, no subject/tenant.
        payload = {
            "seed": 1,
            "records": [
                {"table": "orders", "id": "o1", "tenant": "a", "subject": "t", "time": 1},
            ],
            "links": [],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertEqual(list(result.keys()), ["records"])
        rec = result["records"][0]
        self.assertEqual(list(rec.keys()), ["table", "id", "time", "token"])
        self.assertEqual(rec["table"], "orders")
        self.assertEqual(rec["id"], "o1")
        self.assertEqual(rec["time"], 1)
        self.assertTrue(rec["token"].startswith("ref_"))
        self.assertEqual(len(rec["token"]), 4 + 12)

    def test_token_deterministic_and_seed_sensitive(self):
        # Same canonical subject -> same token; different seed -> different token.
        base = {
            "records": [
                {"table": "t", "id": "x", "tenant": "a", "subject": "s", "time": 0},
            ],
            "links": [],
            "merges": [],
        }
        p1 = dict(base, seed=1)
        p2 = dict(base, seed=2)
        r1 = call_candidate("solution.py", "transform", args=[p1])
        r2 = call_candidate("solution.py", "transform", args=[p2])
        self.assertEqual(r1["records"][0]["token"], r1["records"][0]["token"])
        self.assertNotEqual(r1["records"][0]["token"], r2["records"][0]["token"])

    def test_cross_table_same_token(self):
        # Two records in same component (via link) share a token across tables.
        payload = {
            "seed": 1,
            "records": [
                {"table": "orders", "id": "o1", "tenant": "a", "subject": "t", "time": 5},
                {"table": "history", "id": "h1", "tenant": "a", "subject": "s", "time": 5},
            ],
            "links": [{"a": ["a", "t"], "b": ["a", "s"]}],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        tokens = [r["token"] for r in result["records"]]
        self.assertEqual(tokens[0], tokens[1])

    def test_tenant_scope_not_mixed(self):
        # Same subject id in different tenants must NOT be merged.
        payload = {
            "seed": 1,
            "records": [
                {"table": "t", "id": "x", "tenant": "a", "subject": "s", "time": 0},
                {"table": "t", "id": "y", "tenant": "b", "subject": "s", "time": 0},
            ],
            "links": [],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        tokens = [r["token"] for r in result["records"]]
        self.assertNotEqual(tokens[0], tokens[1])

    def test_window_boundaries(self):
        # from/to are left-closed right-open: active at from, inactive at to.
        payload = {
            "seed": 1,
            "records": [
                {"table": "t", "id": "a", "tenant": "a", "subject": "s", "time": 5},
                {"table": "t", "id": "b", "tenant": "a", "subject": "t", "time": 5},
                {"table": "t", "id": "c", "tenant": "a", "subject": "s", "time": 10},
                {"table": "t", "id": "d", "tenant": "a", "subject": "t", "time": 10},
            ],
            "links": [],
            "merges": [{"a": ["a", "s"], "b": ["a", "t"], "from": 5, "to": 10}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        recs = result["records"]
        self.assertEqual(recs[0]["token"], recs[1]["token"])  # active at 5
        self.assertNotEqual(recs[2]["token"], recs[3]["token"])  # inactive at 10

    def test_canonical_lexicographic(self):
        # Canonical is lexicographically smallest (tenant, subject) in component.
        payload = {
            "seed": 1,
            "records": [
                {"table": "t", "id": "x", "tenant": "b", "subject": "z", "time": 0},
                {"table": "t", "id": "y", "tenant": "a", "subject": "a", "time": 0},
            ],
            "links": [{"a": ["b", "z"], "b": ["a", "a"]}],
            "merges": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # Both records share the canonical ("a","a") token.
        self.assertEqual(result["records"][0]["token"], result["records"][1]["token"])


if __name__ == "__main__":
    unittest.main()
