def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    return solve(payload, left, right)


def solve(payload, events, compatibility):
    """非预知逐轮调度求解器。

    events: 按 (visible, id) 排序的业务事件列表。
    compatibility: {vehicle_id: [driver_id, ...]}。
    """
    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    rounds = payload["rounds"]

    # 已提交任务（不可逆）。每项含 job/vehicle/driver/supplier/start/end/quantity/profit。
    committed = []
    # 已提交任务占用的资源（用于后续轮次约束）。
    committed_by_job = {}  # job_id -> assignment dict
    # 已取消的 job id（升序去重）。
    cancelled = []
    # 被忽略的取消（已提交且 start < cutoff）。
    ignored_cancellations = []

    # 库存消耗：供应商累计分配 quantity（含已完成与已提交）。
    stock_used = {sid: 0 for sid in suppliers}

    # 车辆/司机已占用区间（含已提交任务）。
    vehicle_intervals = {vid: [] for vid in vehicles}
    driver_intervals = {did: [] for did in drivers}

    # 司机历史工时（含已提交任务），用于 max_work 累计。
    driver_work = {did: [] for did in drivers}  # list of (start, end)

    # 已出现的 job（request 引入）。
    known_jobs = {}  # job_id -> job dict
    # 待派 job（尚未提交且未取消）。
    pending_jobs = {}  # job_id -> job dict

    def job_profit(job, supplier_id, vehicle_id):
        v = vehicles[vehicle_id]
        s = suppliers[supplier_id]
        return job["revenue"] - job["quantity"] * s["unit_cost"] - v["cost"] * job["duration"]

    def can_place(job, vehicle_id, driver_id, supplier_id, start):
        v = vehicles[vehicle_id]
        d = drivers[driver_id]
        s = suppliers[supplier_id]
        end = start + job["duration"]
        if v["type"] != job["type"]:
            return False
        if v["capacity"] < job["quantity"]:
            return False
        if job["type"] not in d["types"]:
            return False
        if supplier_id not in job["suppliers"]:
            return False
        if start > s["close"]:
            return False
        if end > job["deadline"]:
            return False
        # 车辆/司机时间不重叠。
        for (a, b) in vehicle_intervals[vehicle_id]:
            if start < b and a < end:
                return False
        for (a, b) in driver_intervals[driver_id]:
            if start < b and a < end:
                return False
        # 供应商库存。
        if stock_used[supplier_id] + job["quantity"] > s["stock"]:
            return False
        # 司机工时约束。
        new_work = sorted(driver_work[driver_id] + [(start, end)])
        total = sum(b - a for a, b in new_work)
        if total > d["max_work"]:
            return False
        # 连续工时约束。
        continuous = 0
        prev_end = None
        for (a, b) in new_work:
            if prev_end is not None and a - prev_end >= d["break"]:
                continuous = 0
            continuous += b - a
            if continuous > d["max_continuous"]:
                return False
            prev_end = b
        return True

    def commit_assignment(job, vehicle_id, driver_id, supplier_id, start):
        end = start + job["duration"]
        profit = job_profit(job, supplier_id, vehicle_id)
        a = {
            "job": job["id"],
            "vehicle": vehicle_id,
            "driver": driver_id,
            "supplier": supplier_id,
            "start": start,
            "end": end,
            "quantity": job["quantity"],
            "profit": profit,
        }
        committed.append(a)
        committed_by_job[job["id"]] = a
        stock_used[supplier_id] += job["quantity"]
        vehicle_intervals[vehicle_id].append((start, end))
        driver_intervals[driver_id].append((start, end))
        driver_work[driver_id].append((start, end))
        return a

    def feasible_placements(job):
        """返回该 job 所有可行 (start, vehicle, driver, supplier) 组合。"""
        result = []
        for vehicle_id, v in vehicles.items():
            if v["type"] != job["type"] or v["capacity"] < job["quantity"]:
                continue
            for driver_id in compatibility.get(vehicle_id, []):
                d = drivers[driver_id]
                if job["type"] not in d["types"]:
                    continue
                for supplier_id in job["suppliers"]:
                    s = suppliers[supplier_id]
                    if stock_used[supplier_id] + job["quantity"] > s["stock"]:
                        continue
                    for start in range(job["release"], job["deadline"] - job["duration"] + 1):
                        if start > s["close"]:
                            break
                        if can_place(job, vehicle_id, driver_id, supplier_id, start):
                            result.append((start, vehicle_id, driver_id, supplier_id))
        return result

    # 逐轮处理。
    for rnd in rounds:
        cutoff = rnd["cutoff"]
        commit = rnd.get("commit", False)

        # 处理 visible <= cutoff 的事件（按 (visible, id) 已排序）。
        for ev in events:
            if ev["visible"] > cutoff:
                break
            if ev["kind"] == "request":
                job = ev["job"]
                known_jobs[job["id"]] = job
                if job["id"] not in committed_by_job and job["id"] not in cancelled:
                    pending_jobs[job["id"]] = job
            elif ev["kind"] == "cancel":
                jid = ev["job"]
                if jid in committed_by_job:
                    a = committed_by_job[jid]
                    if a["start"] < cutoff:
                        if jid not in ignored_cancellations:
                            ignored_cancellations.append(jid)
                    else:
                        # 已提交但 start >= cutoff：可取消。
                        committed.remove(a)
                        del committed_by_job[jid]
                        stock_used[a["supplier"]] -= a["quantity"]
                        vehicle_intervals[a["vehicle"]].remove((a["start"], a["end"]))
                        driver_intervals[a["driver"]].remove((a["start"], a["end"]))
                        driver_work[a["driver"]].remove((a["start"], a["end"]))
                        if jid not in cancelled:
                            cancelled.append(jid)
                else:
                    # 未提交：从待派中移除并列入 cancelled。
                    pending_jobs.pop(jid, None)
                    if jid not in cancelled:
                        cancelled.append(jid)

        # 本轮新分配：在固定已提交任务之外，最大化新任务总 profit。
        # 枚举所有待派 job 的可行放置，做最优子集选择。
        pending_list = list(pending_jobs.values())
        # 每个 job 的可行放置列表。
        placements = {}
        for job in pending_list:
            placements[job["id"]] = feasible_placements(job)

        # 由于 job 数 <= 5，可枚举子集 + 组合。
        best = None  # (total_profit, count, sorted_tuple_list)

        # 对每个 job 选择至多一个放置（或不选）。
        job_ids = [j["id"] for j in pending_list]
        n = len(job_ids)

        # 递归枚举。
        def rec(idx, chosen):
            nonlocal best
            if idx == n:
                # 校验 chosen 之间无资源冲突。
                if not chosen:
                    key = (0, 0, [])
                else:
                    # 检查冲突。
                    ok = True
                    used_v = {}
                    used_d = {}
                    used_s = {}
                    for (jid, (start, vid, did, sid)) in chosen:
                        job = known_jobs[jid]
                        end = start + job["duration"]
                        if vid in used_v:
                            for (a, b) in used_v[vid]:
                                if start < b and a < end:
                                    ok = False
                                    break
                        if not ok:
                            break
                        if did in used_d:
                            for (a, b) in used_d[did]:
                                if start < b and a < end:
                                    ok = False
                                    break
                        if not ok:
                            break
                        if sid in used_s:
                            if used_s[sid] + job["quantity"] > suppliers[sid]["stock"]:
                                ok = False
                                break
                        used_v.setdefault(vid, []).append((start, end))
                        used_d.setdefault(did, []).append((start, end))
                        used_s[sid] = used_s.get(sid, 0) + job["quantity"]
                    if not ok:
                        return
                    total_profit = sum(job_profit(known_jobs[jid], sid, vid) for (jid, (start, vid, did, sid)) in chosen)
                    count = len(chosen)
                    # 排序元组列表。
                    items = []
                    for (jid, (start, vid, did, sid)) in chosen:
                        job = known_jobs[jid]
                        end = start + job["duration"]
                        items.append((jid, start, vid, did, sid))
                    items.sort()
                    key = (total_profit, count, items)
                if best is None or key > best:
                    best = key
                return
            # 不选该 job。
            rec(idx + 1, chosen)
            # 选该 job 的某个放置。
            for pl in placements[job_ids[idx]]:
                rec(idx + 1, chosen + [(job_ids[idx], pl)])

        rec(0, [])

        # 提交本轮新分配。
        if best is not None and best[2]:
            for (jid, start, vid, did, sid) in best[2]:
                job = known_jobs[jid]
                commit_assignment(job, vid, did, sid, start)
                pending_jobs.pop(jid, None)

        # 若 commit=false，本轮拟分配不永久提交？题面：commit=true 才永久提交。
        # 但输出 assignments 包含"已有提交和本轮新分配"。
        # 非 commit 轮的新分配不保留到后续轮（不提交）。
        # 这里先按 commit 语义处理：commit=false 时本轮新分配不进入 committed。
        # 但为简单，我们记录本轮新分配，若 commit=false 则回滚。
        # 由于上面已直接 commit，需要区分。改为：先计算本轮新分配，再决定是否提交。

    # 上面的实现把 commit 语义混在一起，需要重构。见下方完整实现。
    return _solve(payload, events, compatibility)


def _solve(payload, events, compatibility):
    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    rounds = payload["rounds"]

    committed = []
    committed_by_job = {}
    cancelled = []
    ignored_cancellations = []
    stock_used = {sid: 0 for sid in suppliers}
    vehicle_intervals = {vid: [] for vid in vehicles}
    driver_intervals = {did: [] for did in drivers}
    driver_work = {did: [] for did in drivers}
    known_jobs = {}
    pending_jobs = {}

    def job_profit(job, supplier_id, vehicle_id):
        v = vehicles[vehicle_id]
        s = suppliers[supplier_id]
        return job["revenue"] - job["quantity"] * s["unit_cost"] - v["cost"] * job["duration"]

    def can_place(job, vehicle_id, driver_id, supplier_id, start):
        v = vehicles[vehicle_id]
        d = drivers[driver_id]
        s = suppliers[supplier_id]
        end = start + job["duration"]
        if v["type"] != job["type"] or v["capacity"] < job["quantity"]:
            return False
        if job["type"] not in d["types"]:
            return False
        if supplier_id not in job["suppliers"]:
            return False
        if start > s["close"] or end > job["deadline"]:
            return False
        for (a, b) in vehicle_intervals[vehicle_id]:
            if start < b and a < end:
                return False
        for (a, b) in driver_intervals[driver_id]:
            if start < b and a < end:
                return False
        if stock_used[supplier_id] + job["quantity"] > s["stock"]:
            return False
        new_work = sorted(driver_work[driver_id] + [(start, end)])
        total = sum(b - a for a, b in new_work)
        if total > d["max_work"]:
            return False
        continuous = 0
        prev_end = None
        for (a, b) in new_work:
            if prev_end is not None and a - prev_end >= d["break"]:
                continuous = 0
            continuous += b - a
            if continuous > d["max_continuous"]:
                return False
            prev_end = b
        return True

    def feasible_placements(job):
        result = []
        for vehicle_id, v in vehicles.items():
            if v["type"] != job["type"] or v["capacity"] < job["quantity"]:
                continue
            for driver_id in compatibility.get(vehicle_id, []):
                d = drivers[driver_id]
                if job["type"] not in d["types"]:
                    continue
                for supplier_id in job["suppliers"]:
                    s = suppliers[supplier_id]
                    if stock_used[supplier_id] + job["quantity"] > s["stock"]:
                        continue
                    for start in range(job["release"], job["deadline"] - job["duration"] + 1):
                        if start > s["close"]:
                            break
                        if can_place(job, vehicle_id, driver_id, supplier_id, start):
                            result.append((start, vehicle_id, driver_id, supplier_id))
        return result

    def apply_assignment(job, vehicle_id, driver_id, supplier_id, start):
        end = start + job["duration"]
        profit = job_profit(job, supplier_id, vehicle_id)
        a = {
            "job": job["id"], "vehicle": vehicle_id, "driver": driver_id,
            "supplier": supplier_id, "start": start, "end": end,
            "quantity": job["quantity"], "profit": profit,
        }
        committed.append(a)
        committed_by_job[job["id"]] = a
        stock_used[supplier_id] += job["quantity"]
        vehicle_intervals[vehicle_id].append((start, end))
        driver_intervals[driver_id].append((start, end))
        driver_work[driver_id].append((start, end))
        return a

    def undo_assignment(a):
        committed.remove(a)
        del committed_by_job[a["job"]]
        stock_used[a["supplier"]] -= a["quantity"]
        vehicle_intervals[a["vehicle"]].remove((a["start"], a["end"]))
        driver_intervals[a["driver"]].remove((a["start"], a["end"]))
        driver_work[a["driver"]].remove((a["start"], a["end"]))

    output_rounds = []

    for rnd in rounds:
        cutoff = rnd["cutoff"]
        commit = rnd.get("commit", False)

        for ev in events:
            if ev["visible"] > cutoff:
                break
            if ev["kind"] == "request":
                job = ev["job"]
                known_jobs[job["id"]] = job
                if job["id"] not in committed_by_job and job["id"] not in cancelled:
                    pending_jobs[job["id"]] = job
            elif ev["kind"] == "cancel":
                jid = ev["job"]
                if jid in committed_by_job:
                    a = committed_by_job[jid]
                    if a["start"] < cutoff:
                        if jid not in ignored_cancellations:
                            ignored_cancellations.append(jid)
                    else:
                        undo_assignment(a)
                        if jid not in cancelled:
                            cancelled.append(jid)
                else:
                    pending_jobs.pop(jid, None)
                    if jid not in cancelled:
                        cancelled.append(jid)

        # 计算本轮新分配（在已提交任务之外）。
        pending_list = list(pending_jobs.values())
        placements = {}
        for job in pending_list:
            placements[job["id"]] = feasible_placements(job)

        job_ids = [j["id"] for j in pending_list]
        n = len(job_ids)
        best = None

        def rec(idx, chosen):
            nonlocal best
            if idx == n:
                if not chosen:
                    key = (0, 0, [])
                else:
                    ok = True
                    used_v = {}
                    used_d = {}
                    used_s = {}
                    for (jid, pl) in chosen:
                        (start, vid, did, sid) = pl
                        job = known_jobs[jid]
                        end = start + job["duration"]
                        for (a, b) in used_v.get(vid, []):
                            if start < b and a < end:
                                ok = False
                                break
                        if not ok:
                            break
                        for (a, b) in used_d.get(did, []):
                            if start < b and a < end:
                                ok = False
                                break
                        if not ok:
                            break
                        if used_s.get(sid, 0) + job["quantity"] > suppliers[sid]["stock"]:
                            ok = False
                            break
                        used_v.setdefault(vid, []).append((start, end))
                        used_d.setdefault(did, []).append((start, end))
                        used_s[sid] = used_s.get(sid, 0) + job["quantity"]
                    if not ok:
                        return
                    total_profit = sum(job_profit(known_jobs[jid], sid, vid) for (jid, pl) in chosen for (start, vid, did, sid) in [pl])
                    count = len(chosen)
                    items = sorted((jid, start, vid, did, sid) for (jid, pl) in chosen for (start, vid, did, sid) in [pl])
                    key = (total_profit, count, items)
                if best is None or key > best:
                    best = key
                return
            rec(idx + 1, chosen)
            for pl in placements[job_ids[idx]]:
                rec(idx + 1, chosen + [(job_ids[idx], pl)])

        rec(0, [])

        new_assignments = []
        if best is not None and best[2]:
            for (jid, start, vid, did, sid) in best[2]:
                job = known_jobs[jid]
                a = apply_assignment(job, vid, did, sid, start)
                new_assignments.append(a)
                pending_jobs.pop(jid, None)

        # 若 commit=false，本轮新分配不永久提交，回滚。
        if not commit:
            for a in new_assignments:
                undo_assignment(a)
                pending_jobs[a["job"]] = known_jobs[a["job"]]
            new_assignments = []

        # 输出本轮 assignments = 已提交 + 本轮新分配（按元组排序）。
        all_assignments = list(committed) + new_assignments
        all_assignments.sort(key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))
        profit = sum(a["profit"] for a in all_assignments)
        output_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments,
            "profit": profit,
            "cancelled": sorted(cancelled),
            "ignored_cancellations": sorted(ignored_cancellations),
        })

    return {"rounds": output_rounds}
