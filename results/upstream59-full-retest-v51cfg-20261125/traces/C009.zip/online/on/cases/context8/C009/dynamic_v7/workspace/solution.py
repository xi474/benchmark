from component_runtime import read as _read, transform as _transform, build_component as _build_component


def load_payload(path):
    """从任意给定 UTF-8 JSON 路径读取并返回输入对象。"""
    return _read(path)


def transform(payload):
    """接收 JSON 对象并返回规定的 JSON 值，不修改输入。"""
    return _transform(payload)


def build_component(input_path, output_path):
    """读取输入、调用实现，将完整结果写入给定 JSON 路径并返回该结果。"""
    return _build_component(input_path, output_path)
