def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload.get("orders", [])
    released = set(payload.get("released", []))
    routing = payload.get("routing", {})
    lines = payload.get("lines", [])
    wip = payload.get("wip", [])
    freeze = payload.get("freeze", 0)
    changeover = payload.get("changeover", 0)

    # 每条产线上 wip 的最大结束时间（wip 占据第一顺位）。
    wip_end = {}
    for w in wip:
        line = w["line"]
        end = w["end"]
        if line not in wip_end or end > wip_end[line]:
            wip_end[line] = end

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]
        r = routing.get(sku)
        if r is None:
            result[oid] = []
            continue
        duration = r["setup"] + r["per_unit"] * qty
        triples = []
        for line in lines:
            lid = line["id"]
            qualified = line.get("qualified", [])
            if sku not in qualified or sku not in released:
                continue
            min_start = freeze
            if lid in wip_end:
                wip_min = wip_end[lid] + changeover
                if wip_min > min_start:
                    min_start = wip_min
            for (ws, we) in line.get("windows", []):
                # 区间 [start, start+duration) 须完整落入窗口且结束 <= due。
                for start in range(ws, we):
                    end = start + duration
                    if start < min_start:
                        continue
                    if end > we:
                        break
                    if end > due:
                        break
                    triples.append([lid, start, end])
        result[oid] = triples
    return result
