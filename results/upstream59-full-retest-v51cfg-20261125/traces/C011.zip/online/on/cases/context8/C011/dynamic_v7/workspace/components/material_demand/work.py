def compute(payload):
    """按工单 ID 输出递归展开后的基础物料需求映射。"""
    orders = payload.get("orders", [])
    bom = payload.get("bom", {})

    def expand(sku, mult):
        if sku not in bom:
            return {sku: mult}
        result = {}
        for child, qty in bom[sku].items():
            for leaf, leaf_qty in expand(child, mult * qty).items():
                result[leaf] = result.get(leaf, 0) + leaf_qty
        return result

    out = {}
    for order in orders:
        out[order["id"]] = expand(order["sku"], order["qty"])
    return out
