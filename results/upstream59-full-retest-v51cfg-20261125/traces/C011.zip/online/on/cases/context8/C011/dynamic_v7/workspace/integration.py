"""C011 integration: combine material demand and line windows into a full plan."""


def combine(payload, left, right):
    """left = material demand per order; right = line windows per order."""
    run_id = payload.get("run_id", "run-0")
    freeze = payload.get("freeze", 0)
    changeover = payload.get("changeover", 0)
    orders = payload.get("orders", [])
    lines = payload.get("lines", [])
    wip = payload.get("wip", [])
    substitutes = payload.get("substitutes", {})
    lots = payload.get("lots", [])

    order_by_id = {o["id"]: o for o in orders}
    demand = left  # {order_id: {component: qty}}
    windows = right  # {order_id: [[line, start, end], ...]}

    candidates = {}
    for oid, triples in windows.items():
        candidates[oid] = [(t[0], t[1], t[2]) for t in triples]

    wip_by_line = {}
    for w in wip:
        wip_by_line.setdefault(w["line"], []).append(w)

    line_min_start = {}
    for line in lines:
        lid = line["id"]
        ends = [w["end"] for w in wip_by_line.get(lid, [])]
        line_min_start[lid] = (max(ends) + changeover) if ends else freeze

    feasible = {}
    for oid, triples in candidates.items():
        ok = []
        for (lid, s, e) in triples:
            if s >= line_min_start.get(lid, freeze):
                ok.append((lid, s, e))
        feasible[oid] = ok

    priorities = sorted({o["priority"] for o in orders})

    lot_info = []
    for lot in lots:
        lot_info.append({
            "id": lot["id"],
            "material": lot["material"],
            "qty": lot["qty"],
            "status": lot["status"],
            "expiry": lot["expiry"],
        })

    def component_lots(component):
        subs = substitutes.get(component, [component])
        result = []
        for lot in lot_info:
            if lot["material"] in subs and lot["status"] == "PASS":
                result.append(lot)
        return result

    def material_feasible(selected_placements):
        remaining = {lot["id"]: lot["qty"] for lot in lot_info}
        reqs = []
        for oid, (lid, s, e) in selected_placements.items():
            for comp, qty in demand.get(oid, {}).items():
                reqs.append((oid, comp, qty, e))
        reqs.sort(key=lambda r: (r[3], r[0], r[1]))
        alloc = {}

        def allocate(idx):
            if idx == len(reqs):
                return True
            oid, comp, qty, e = reqs[idx]
            lots_avail = []
            for lot in component_lots(comp):
                if lot["expiry"] >= e and remaining[lot["id"]] > 0:
                    lots_avail.append(lot)
            lots_avail.sort(key=lambda l: (l["expiry"], l["id"]))
            return try_alloc(idx, oid, comp, qty, e, lots_avail, 0)

        def try_alloc(idx, oid, comp, qty, e, lots_avail, li):
            if qty == 0:
                return allocate(idx + 1)
            if li >= len(lots_avail):
                return False
            lot = lots_avail[li]
            take = min(qty, remaining[lot["id"]])
            if take > 0:
                remaining[lot["id"]] -= take
                alloc.setdefault((oid, comp), []).append((lot["id"], take))
                if try_alloc(idx, oid, comp, qty - take, e, lots_avail, li):
                    return True
                remaining[lot["id"]] += take
                alloc[(oid, comp)].pop()
                if not alloc[(oid, comp)]:
                    del alloc[(oid, comp)]
            return try_alloc(idx, oid, comp, qty, e, lots_avail, li + 1)

        if allocate(0):
            return alloc
        return None

    order_ids = [o["id"] for o in orders]
    n = len(order_ids)

    best = None
    best_key = None

    from itertools import product

    def completion_vector(selected_set):
        ordered = sorted(orders, key=lambda o: (o["priority"], o["due"], o["id"]))
        return tuple(1 if o["id"] in selected_set else 0 for o in ordered)

    def priority_qty(selected_set):
        q = {p: 0 for p in priorities}
        for oid in selected_set:
            o = order_by_id[oid]
            q[o["priority"]] += o["qty"]
        return q

    def alloc_key(alloc):
        items = []
        for (oid, comp), lst in alloc.items():
            for (lot, qty) in lst:
                items.append((oid, comp, lot, qty))
        items.sort()
        return items

    def placement_key(selected_placements):
        entries = []
        for oid in sorted(selected_placements):
            lid, s, e = selected_placements[oid]
            entries.append((oid, lid, s, e))
        return entries

    for mask in range(1 << n):
        selected_set = set()
        for i in range(n):
            if mask & (1 << i):
                selected_set.add(order_ids[i])
        if not selected_set:
            continue
        placement_lists = []
        for oid in sorted(selected_set):
            placement_lists.append(feasible.get(oid, []))
        if any(not pl for pl in placement_lists):
            continue
        for combo in product(*placement_lists):
            sel_place = dict(zip(sorted(selected_set), combo))
            by_line = {}
            for oid, (lid, s, e) in sel_place.items():
                by_line.setdefault(lid, []).append((s, e, oid))
            ok = True
            for lid, tasks in by_line.items():
                tasks.sort(key=lambda t: (t[0], t[1]))
                prev_end = None
                for (s, e, oid) in tasks:
                    if prev_end is not None and s < prev_end + changeover:
                        ok = False
                        break
                    prev_end = e
                if not ok:
                    break
            if not ok:
                continue
            alloc = material_feasible(sel_place)
            if alloc is None:
                continue
            pq = priority_qty(selected_set)
            cv = completion_vector(selected_set)
            pk = placement_key(sel_place)
            ak = alloc_key(alloc)
            key = (tuple(pq[p] for p in sorted(priorities)), cv, pk, ak)
            if best_key is None or key > best_key:
                best_key = key
                best = (selected_set, sel_place, alloc)

    if best is None:
        selected_set, sel_place, alloc = set(), {}, {}
    else:
        selected_set, sel_place, alloc = best

    selected = sorted(selected_set)

    erp_orders = []
    for oid in selected:
        o = order_by_id[oid]
        lid, s, e = sel_place[oid]
        erp_orders.append({
            "wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
            "due": o["due"], "start": s, "end": e, "line": lid,
            "status": "PLANNED", "parent": oid,
        })
    for w in wip:
        erp_orders.append({
            "wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
            "due": w["due"], "start": w["start"], "end": w["end"],
            "line": w["line"], "status": "WIP_CONT", "parent": None,
        })
    erp_orders.sort(key=lambda x: x["wo"])

    mes = []
    by_line = {}
    for oid in selected:
        lid, s, e = sel_place[oid]
        o = order_by_id[oid]
        by_line.setdefault(lid, []).append({
            "wo": oid, "qty": o["qty"], "start": s, "end": e, "status": "PLANNED",
        })
    for w in wip:
        by_line.setdefault(w["line"], []).append({
            "wo": w["id"], "qty": w["qty"], "start": w["start"], "end": w["end"],
            "status": "WIP_CONT",
        })
    for lid in sorted(by_line):
        tasks = sorted(by_line[lid], key=lambda t: (t["start"], t["wo"]))
        for seq, t in enumerate(tasks, 1):
            mes.append({
                "run": run_id, "line": lid, "seq": seq, "wo": t["wo"],
                "qty": t["qty"], "start": t["start"], "end": t["end"],
                "status": t["status"],
            })

    wms = []
    items = []
    for (oid, comp), lst in alloc.items():
        for (lot, qty) in lst:
            items.append((oid, comp, lot, qty))
    items.sort()
    for i, (oid, comp, lot, qty) in enumerate(items, 1):
        wms.append({
            "reservation": "r%04d" % i, "run": run_id, "wo": oid,
            "component": comp, "lot": lot, "qty": qty, "status": "RESERVED",
        })

    return {
        "selected": selected,
        "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": erp_orders},
        "mes": mes,
        "wms": wms,
    }
