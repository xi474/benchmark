def compute(payload):
    """保留批次和行序，返回 name,city,source,time 对象；姓名与城市的空白折叠为单个空格。"""
    def fold(value):
        return " ".join(value.split())

    result = []
    for batch in payload["batches"]:
        rows = []
        for record in batch:
            rows.append({
                "name": fold(record["name"]),
                "city": fold(record["city"]),
                "source": record["source"],
                "time": record["time"],
            })
        result.append(rows)
    return result
