import unittest

# Injected by the SDK runner; available as globals in the test process.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type for expected candidate failures


class TestC017VisibleContract(unittest.TestCase):
    def test_promotion_preserves_first_contact_and_merges_sources(self):
        # Public rule: promotion keeps earliest first_contact; sources merge.
        payload = {
            "batches": [
                [{"email": " x@y.z ", "name": "Bob", "city": "", "source": "a", "time": 5}],
                [{"email": "X@Y.Z", "name": "Bob", "city": "Rome", "source": "b", "time": 9}],
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["batches"][0]["items"], ["incomplete"])
        self.assertEqual(result["batches"][1]["items"], ["promoted"])
        self.assertEqual(len(result["accepted"]), 1)
        row = result["accepted"][0]
        self.assertEqual(row["email"], "x@y.z")
        self.assertEqual(row["name"], "Bob")
        self.assertEqual(row["city"], "Rome")
        self.assertEqual(row["first_contact"], 5)
        self.assertEqual(row["sources"], ["a", "b"])

    def test_conflict_rolls_back_whole_batch(self):
        # Public rule: any conflicting non-empty name/city rolls back the batch.
        payload = {
            "batches": [
                [{"email": "a@b.c", "name": "Ann", "city": "X", "source": "s1", "time": 1}],
                [
                    {"email": "d@e.f", "name": "Dan", "city": "Y", "source": "s2", "time": 2},
                    {"email": "a@b.c", "name": "Zoe", "city": "X", "source": "s3", "time": 3},
                ],
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["batches"][1]["status"], "rejected")
        self.assertEqual(result["batches"][1]["items"], [])
        # The new record from the rejected batch must not appear.
        emails = [r["email"] for r in result["accepted"] + result["incomplete"]]
        self.assertNotIn("d@e.f", emails)
        # The committed record is unchanged.
        self.assertEqual(result["accepted"][0]["name"], "Ann")

    def test_complete_record_is_immutable_but_sources_merge(self):
        # Public rule: complete records are immutable audit facts; sources merge.
        payload = {
            "batches": [
                [{"email": "a@b.c", "name": "Ann", "city": "X", "source": "s1", "time": 1}],
                [{"email": "a@b.c", "name": "Ann", "city": "X", "source": "s2", "time": 7}],
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["batches"][1]["items"], ["duplicate"])
        row = result["accepted"][0]
        self.assertEqual(row["name"], "Ann")
        self.assertEqual(row["city"], "X")
        self.assertEqual(row["first_contact"], 1)
        self.assertEqual(row["sources"], ["s1", "s2"])

    def test_incomplete_record_keeps_nonempty_fields(self):
        # Public rule: non-empty old fields are not cleared by empty values.
        payload = {
            "batches": [
                [{"email": "a@b.c", "name": "Ann", "city": "", "source": "s1", "time": 1}],
                [{"email": "a@b.c", "name": "", "city": "X", "source": "s2", "time": 2}],
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["batches"][1]["items"], ["promoted"])
        row = result["accepted"][0]
        self.assertEqual(row["name"], "Ann")
        self.assertEqual(row["city"], "X")
        self.assertEqual(row["first_contact"], 1)

    def test_output_sorted_by_email_and_sources(self):
        # Public rule: accepted/incomplete sorted by email; sources sorted.
        payload = {
            "batches": [
                [
                    {"email": "z@z.z", "name": "Zed", "city": "Z", "source": "s2", "time": 2},
                    {"email": "a@a.a", "name": "Amy", "city": "A", "source": "s1", "time": 1},
                ]
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        emails = [r["email"] for r in result["accepted"]]
        self.assertEqual(emails, ["a@a.a", "z@z.z"])
        self.assertEqual(result["sources"]["s1"], ["a@a.a"])
        self.assertEqual(result["sources"]["s2"], ["z@z.z"])


if __name__ == "__main__":
    unittest.main()
