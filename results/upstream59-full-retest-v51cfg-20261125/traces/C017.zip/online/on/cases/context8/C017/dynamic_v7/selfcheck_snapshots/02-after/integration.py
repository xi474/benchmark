def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    batches = payload["batches"]
    keys = left      # list of batches -> list of cleaned emails
    profiles = right # list of batches -> list of {name,city,source,time}

    # records: email -> dict(name, city, first_contact, complete, sources:set)
    records = {}
    # sources: source -> set of emails
    sources = {}

    result_batches = []

    for bi, batch in enumerate(batches):
        emails = keys[bi]
        profs = profiles[bi]

        # Work on a temporary view: snapshot current state
        snapshot_records = {e: dict(v, sources=set(v["sources"])) for e, v in records.items()}
        snapshot_sources = {s: set(v) for s, v in sources.items()}

        items = []
        conflict = False

        for email, prof in zip(emails, profs):
            name = prof["name"]
            city = prof["city"]
            source = prof["source"]
            time = prof["time"]

            rec = snapshot_records.get(email)
            if rec is None:
                # new record
                complete = (name != "" and city != "")
                snapshot_records[email] = {
                    "name": name,
                    "city": city,
                    "first_contact": time,
                    "complete": complete,
                    "sources": {source},
                }
                snapshot_sources.setdefault(source, set()).add(email)
                items.append("accepted" if complete else "incomplete")
            else:
                # existing record: check conflict on non-empty fields
                if name != "" and rec["name"] != "" and name != rec["name"]:
                    conflict = True
                    break
                if city != "" and rec["city"] != "" and city != rec["city"]:
                    conflict = True
                    break

                if rec["complete"]:
                    # immutable audit fact: don't change name/city/first_contact
                    # but merge source
                    snapshot_sources.setdefault(source, set()).add(email)
                    rec["sources"].add(source)
                    items.append("duplicate")
                    continue
                else:
                    # incomplete: fill in non-empty fields
                    if name != "" and rec["name"] == "":
                        rec["name"] = name
                    if city != "" and rec["city"] == "":
                        rec["city"] = city
                    # merge source
                    snapshot_sources.setdefault(source, set()).add(email)
                    rec["sources"].add(source)

                    if rec["name"] != "" and rec["city"] != "":
                        rec["complete"] = True
                        items.append("promoted")
                    else:
                        items.append("incomplete")

        if conflict:
            result_batches.append({"status": "rejected", "items": []})
            # rollback: do not commit snapshot
            continue
        else:
            # commit
            records = snapshot_records
            sources = snapshot_sources
            result_batches.append({"status": "committed", "items": items})

    # Build accepted and incomplete lists
    accepted = []
    incomplete = []
    for email in sorted(records):
        rec = records[email]
        row = {
            "email": email,
            "name": rec["name"],
            "city": rec["city"],
            "first_contact": rec["first_contact"],
            "sources": sorted(rec["sources"]),
        }
        if rec["complete"]:
            accepted.append(row)
        else:
            incomplete.append(row)

    sources_out = {s: sorted(v) for s, v in sorted(sources.items())}

    return {
        "batches": result_batches,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_out,
    }
