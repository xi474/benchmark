import os
import pty
import select
import signal
import tempfile
import time
from pathlib import Path


def _normalize(data):
    data = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return data


def _read_until(fd, marker, timeout):
    """Read from fd until marker appears (or EOF). Return (bytes, eof)."""
    buf = b""
    deadline = time.monotonic() + timeout
    while True:
        if marker is not None and marker.encode("utf-8") in buf:
            return buf, False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return buf, False
        r, _, _ = select.select([fd], [], [], remaining)
        if not r:
            return buf, False
        try:
            chunk = os.read(fd, 4096)
        except OSError:
            return buf, True
        if not chunk:
            return buf, True
        buf += chunk


def combine(payload, left, right):
    """Run a real interactive bash session in a PTY and return chunks/closed."""
    key_sequences = left
    session_config = right

    rc = session_config["rc"]
    timeout = session_config.get("timeout", 4)
    markers = session_config.get("markers", [])
    steps = payload.get("steps", [])

    tmpdir = tempfile.mkdtemp(prefix="c031_")
    home = Path(tmpdir)
    (home / ".hushlogin").write_text("", encoding="utf-8")

    rcfile = home / "rcfile"
    rcfile.write_text(rc, encoding="utf-8")

    env = dict(os.environ)
    env["HOME"] = str(home)
    env["TERM"] = "dumb"
    env["LC_ALL"] = "C"
    env["HISTFILE"] = "/dev/null"

    pid, fd = pty.fork()
    if pid == 0:
        try:
            os.chdir(str(home))
            os.execvpe(
                "/bin/bash",
                ["/bin/bash", "--noprofile", "--rcfile", str(rcfile), "-i"],
                env,
            )
        except Exception:
            os._exit(127)

    chunks = []
    closed = False
    try:
        # Initial read: wait for PROMPT>
        initial, eof = _read_until(fd, "PROMPT> ", timeout)
        chunks.append(_normalize(initial).decode("utf-8", "replace"))
        if eof:
            closed = True
            return {"chunks": chunks, "closed": closed}

        for i, step in enumerate(steps):
            data = bytes.fromhex(key_sequences[i])
            os.write(fd, data)
            marker = markers[i] if i < len(markers) else None
            if marker is None:
                # wait for EOF
                buf = b""
                while True:
                    r, _, _ = select.select([fd], [], [], timeout)
                    if not r:
                        break
                    try:
                        chunk = os.read(fd, 4096)
                    except OSError:
                        closed = True
                        break
                    if not chunk:
                        closed = True
                        break
                    buf += chunk
                chunks.append(_normalize(buf).decode("utf-8", "replace"))
                if closed:
                    break
            else:
                buf, eof = _read_until(fd, marker, timeout)
                chunks.append(_normalize(buf).decode("utf-8", "replace"))
                if eof:
                    closed = True
                    break
    finally:
        try:
            os.killpg(pid, signal.SIGKILL)
        except Exception:
            pass
        try:
            os.close(fd)
        except Exception:
            pass
        try:
            os.waitpid(pid, 0)
        except Exception:
            pass

    return {"chunks": chunks, "closed": closed}
