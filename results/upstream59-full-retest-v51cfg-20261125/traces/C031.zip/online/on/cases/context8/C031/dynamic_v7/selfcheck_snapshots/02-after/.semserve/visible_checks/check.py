import unittest

# Injected names (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御、错误文本、代码风格或未公开兼容范围。",
                "reason": "Public spec explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御、错误文本、代码风格或未公开兼容范围。",
                "reason": "Spec does not require ValueError on invalid payload types.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_transform_returns_chunks_and_closed(self):
        # Output contract: transform returns dict with chunks (list) and closed (bool).
        payload = {
            "steps": [
                {"keys": ["printf 'X\\n'", "Enter"], "until": "PROMPT> "}
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertIn("chunks", result)
        self.assertIn("closed", result)
        self.assertIsInstance(result["chunks"], list)
        self.assertIsInstance(result["closed"], bool)
        # First chunk is the initial prompt.
        self.assertEqual(result["chunks"][0], "PROMPT> ")

    def test_transform_does_not_mutate_input(self):
        payload = {
            "steps": [
                {"keys": ["printf 'X\\n'", "Enter"], "until": "PROMPT> "}
            ]
        }
        snapshot = {"steps": [dict(payload["steps"][0])]}
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)

    def test_load_payload_reads_utf8_json(self):
        import json
        import tempfile
        import os
        data = {"steps": [{"keys": ["echo hi", "Enter"], "until": "PROMPT> "}]}
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as f:
            json.dump(data, f)
            path = f.name
        try:
            loaded = call_candidate("solution.py", "load_payload", args=[path])
            self.assertEqual(loaded, data)
        finally:
            os.unlink(path)

    def test_build_component_writes_and_returns(self):
        import json
        import tempfile
        import os
        payload = {"steps": [{"keys": ["printf 'X\\n'", "Enter"], "until": "PROMPT> "}]}
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as f:
            json.dump(payload, f)
            inpath = f.name
        outpath = tempfile.mktemp(suffix=".json")
        try:
            result = call_candidate("solution.py", "build_component", args=[inpath, outpath])
            with open(outpath, encoding="utf-8") as f:
                written = json.load(f)
            self.assertEqual(result, written)
            self.assertIn("chunks", written)
            self.assertIn("closed", written)
        finally:
            os.unlink(inpath)
            if os.path.exists(outpath):
                os.unlink(outpath)


if __name__ == "__main__":
    unittest.main()
