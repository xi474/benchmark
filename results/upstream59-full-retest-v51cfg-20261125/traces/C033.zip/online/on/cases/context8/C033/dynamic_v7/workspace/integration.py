"""MIPS32 interpreter integration: combine the two component values into the full result."""

MASK = 0xFFFFFFFF


def _s32(v):
    v &= MASK
    return v - (1 << 32) if v & (1 << 31) else v


def _u32(v):
    return v & MASK


def combine(payload, left, right):
    entry, segments = left
    files_map, stdin_bytes = right

    # Build memory from segments.
    mem = {}
    for addr, byte in segments:
        mem[addr] = byte

    def read8(addr):
        return mem.get(addr & MASK, 0)

    def read16(addr):
        a = addr & MASK
        return read8(a) | (read8(a + 1) << 8)

    def read32(addr):
        a = addr & MASK
        return read8(a) | (read8(a + 1) << 8) | (read8(a + 2) << 16) | (read8(a + 3) << 24)

    def write8(addr, val):
        mem[addr & MASK] = val & 0xFF

    def write16(addr, val):
        a = addr & MASK
        write8(a, val & 0xFF)
        write8(a + 1, (val >> 8) & 0xFF)

    def write32(addr, val):
        a = addr & MASK
        write8(a, val & 0xFF)
        write8(a + 1, (val >> 8) & 0xFF)
        write8(a + 2, (val >> 16) & 0xFF)
        write8(a + 3, (val >> 24) & 0xFF)

    regs = [0] * 32
    hi = 0
    lo = 0
    pc = entry

    stack_pointer = payload.get("stack_pointer")
    if stack_pointer is not None:
        regs[29] = _u32(stack_pointer)
    else:
        regs[29] = 0x7FFF0000

    max_steps = payload.get("max_steps", 20000)

    # File system state.
    files = {name: list(data) for name, data in files_map.items()}
    stdin_data = list(stdin_bytes)
    stdin_pos = 0
    stdout_data = []
    stderr_data = []
    # fd -> (name, data, pos)
    open_files = {}
    next_fd = 3

    syscalls = []
    steps = 0
    exit_code = 0
    exited = False

    def syscall(number, a0, a1, a2):
        nonlocal stdin_pos, next_fd, exit_code, exited
        syscalls.append({"number": number, "args": [a0, a1, a2]})
        if number == 4001:  # exit
            exit_code = a0 & 0xFF
            exited = True
            return 0
        if number == 4003:  # read
            fd, buf, n = a0, a1, a2
            if fd == 0:
                data = stdin_data[stdin_pos:stdin_pos + n]
                stdin_pos += len(data)
            elif fd in open_files:
                name, fdata, pos = open_files[fd]
                data = fdata[pos:pos + n]
                open_files[fd] = (name, fdata, pos + len(data))
            else:
                data = []
            for i, b in enumerate(data):
                write8(buf + i, b)
            return len(data)
        if number == 4004:  # write
            fd, buf, n = a0, a1, a2
            data = bytes(read8(buf + i) for i in range(n))
            if fd == 1:
                stdout_data.extend(data)
            elif fd == 2:
                stderr_data.extend(data)
            elif fd in open_files:
                name, fdata, pos = open_files[fd]
                fdata[pos:pos] = list(data)
                open_files[fd] = (name, fdata, pos + len(data))
            return n
        if number == 4005:  # open
            filename, flags, mode = a0, a1, a2
            name = ""
            i = 0
            while True:
                c = read8(filename + i)
                if c == 0:
                    break
                name += chr(c)
                i += 1
            if flags == 0:
                if name not in files:
                    return -1
                data = list(files[name])
            elif flags == 1:
                data = []
                files[name] = data
            elif flags == 9:
                data = list(files.get(name, []))
                files[name] = data
            else:
                return -1
            fd = next_fd
            next_fd += 1
            open_files[fd] = (name, data, 0)
            return fd
        if number == 4006:  # close
            fd = a0
            if fd in open_files:
                name, data, pos = open_files.pop(fd)
                files[name] = data
            return 0
        return 0

    while not exited and steps < max_steps:
        instr = read32(pc)
        opcode = instr >> 26
        rs = (instr >> 21) & 0x1F
        rt = (instr >> 16) & 0x1F
        rd = (instr >> 11) & 0x1F
        shamt = (instr >> 6) & 0x1F
        funct = instr & 0x3F
        imm = instr & 0xFFFF
        simm = _s32(imm << 16) >> 16

        next_pc = pc + 4
        delay = None  # (kind, args) to execute after this instruction

        def set_reg(r, v):
            if r != 0:
                regs[r] = _u32(v)

        if opcode == 0:
            if funct == 0x00:  # sll
                delay = ("sll", rd, rt, shamt)
            elif funct == 0x02:  # srl
                delay = ("srl", rd, rt, shamt)
            elif funct == 0x03:  # sra
                delay = ("sra", rd, rt, shamt)
            elif funct == 0x08:  # jr
                delay = ("jr", rs)
            elif funct == 0x09:  # jalr
                delay = ("jalr", rd, rs)
            elif funct == 0x10:  # mfhi
                delay = ("mfhi", rd)
            elif funct == 0x11:  # mthi
                delay = ("mthi", rs)
            elif funct == 0x12:  # mflo
                delay = ("mflo", rd)
            elif funct == 0x13:  # mtlo
                delay = ("mtlo", rs)
            elif funct == 0x18:  # mult
                delay = ("mult", rs, rt)
            elif funct == 0x19:  # multu
                delay = ("multu", rs, rt)
            elif funct == 0x1A:  # div
                delay = ("div", rs, rt)
            elif funct == 0x1B:  # divu
                delay = ("divu", rs, rt)
            elif funct == 0x20:  # add
                delay = ("add", rd, rs, rt)
            elif funct == 0x21:  # addu
                delay = ("addu", rd, rs, rt)
            elif funct == 0x22:  # sub
                delay = ("sub", rd, rs, rt)
            elif funct == 0x23:  # subu
                delay = ("subu", rd, rs, rt)
            elif funct == 0x24:  # and
                delay = ("and", rd, rs, rt)
            elif funct == 0x25:  # or
                delay = ("or", rd, rs, rt)
            elif funct == 0x26:  # xor
                delay = ("xor", rd, rs, rt)
            elif funct == 0x27:  # nor
                delay = ("nor", rd, rs, rt)
            elif funct == 0x2A:  # slt
                delay = ("slt", rd, rs, rt)
            elif funct == 0x2B:  # sltu
                delay = ("sltu", rd, rs, rt)
            elif funct == 0x0C:  # syscall
                delay = ("syscall",)
        elif opcode == 0x02:  # j
            target = (next_pc & 0xF0000000) | ((instr & 0x03FFFFFF) << 2)
            delay = ("j", target)
        elif opcode == 0x03:  # jal
            target = (next_pc & 0xF0000000) | ((instr & 0x03FFFFFF) << 2)
            delay = ("jal", target)
        elif opcode == 0x04:  # beq
            delay = ("beq", rs, rt, simm)
        elif opcode == 0x05:  # bne
            delay = ("bne", rs, rt, simm)
        elif opcode == 0x06:  # blez
            delay = ("blez", rs, simm)
        elif opcode == 0x07:  # bgtz
            delay = ("bgtz", rs, simm)
        elif opcode == 0x08:  # addi
            delay = ("addi", rt, rs, simm)
        elif opcode == 0x09:  # addiu
            delay = ("addiu", rt, rs, simm)
        elif opcode == 0x0A:  # slti
            delay = ("slti", rt, rs, simm)
        elif opcode == 0x0B:  # sltiu
            delay = ("sltiu", rt, rs, simm)
        elif opcode == 0x0C:  # andi
            delay = ("andi", rt, rs, imm)
        elif opcode == 0x0D:  # ori
            delay = ("ori", rt, rs, imm)
        elif opcode == 0x0E:  # xori
            delay = ("xori", rt, rs, imm)
        elif opcode == 0x0F:  # lui
            delay = ("lui", rt, imm)
        elif opcode == 0x20:  # lb
            delay = ("lb", rt, rs, simm)
        elif opcode == 0x21:  # lh
            delay = ("lh", rt, rs, simm)
        elif opcode == 0x23:  # lw
            delay = ("lw", rt, rs, simm)
        elif opcode == 0x24:  # lbu
            delay = ("lbu", rt, rs, simm)
        elif opcode == 0x25:  # lhu
            delay = ("lhu", rt, rs, simm)
        elif opcode == 0x28:  # sb
            delay = ("sb", rt, rs, simm)
        elif opcode == 0x29:  # sh
            delay = ("sh", rt, rs, simm)
        elif opcode == 0x2B:  # sw
            delay = ("sw", rt, rs, simm)

        # Execute the delay slot instruction (the instruction at next_pc).
        delay_instr = read32(next_pc)
        delay_next = next_pc + 4

        def exec_delay(instr_word):
            op = instr_word >> 26
            rrs = (instr_word >> 21) & 0x1F
            rrt = (instr_word >> 16) & 0x1F
            rrd = (instr_word >> 11) & 0x1F
            rshamt = (instr_word >> 6) & 0x1F
            rfunct = instr_word & 0x3F
            rimm = instr_word & 0xFFFF
            rsimm = _s32(rimm << 16) >> 16
            if op == 0:
                if rfunct == 0x00:
                    set_reg(rrd, regs[rrt] << rshamt)
                elif rfunct == 0x02:
                    set_reg(rrd, regs[rrt] >> rshamt)
                elif rfunct == 0x03:
                    set_reg(rrd, _s32(regs[rrt]) >> rshamt)
                elif rfunct == 0x20:
                    set_reg(rrd, _s32(regs[rrs]) + _s32(regs[rrt]))
                elif rfunct == 0x21:
                    set_reg(rrd, regs[rrs] + regs[rrt])
                elif rfunct == 0x22:
                    set_reg(rrd, _s32(regs[rrs]) - _s32(regs[rrt]))
                elif rfunct == 0x23:
                    set_reg(rrd, regs[rrs] - regs[rrt])
                elif rfunct == 0x24:
                    set_reg(rrd, regs[rrs] & regs[rrt])
                elif rfunct == 0x25:
                    set_reg(rrd, regs[rrs] | regs[rrt])
                elif rfunct == 0x26:
                    set_reg(rrd, regs[rrs] ^ regs[rrt])
                elif rfunct == 0x27:
                    set_reg(rrd, ~(regs[rrs] | regs[rrt]))
                elif rfunct == 0x2A:
                    set_reg(rrd, 1 if _s32(regs[rrs]) < _s32(regs[rrt]) else 0)
                elif rfunct == 0x2B:
                    set_reg(rrd, 1 if regs[rrs] < regs[rrt] else 0)
                elif rfunct == 0x10:
                    set_reg(rrd, hi)
                elif rfunct == 0x12:
                    set_reg(rrd, lo)
                elif rfunct == 0x11:
                    hi = regs[rrs]
                elif rfunct == 0x13:
                    lo = regs[rrs]
                elif rfunct == 0x18:
                    prod = _s32(regs[rrs]) * _s32(regs[rrt])
                    hi = _u32(prod >> 32)
                    lo = _u32(prod)
                elif rfunct == 0x19:
                    prod = regs[rrs] * regs[rrt]
                    hi = _u32(prod >> 32)
                    lo = _u32(prod)
                elif rfunct == 0x1A:
                    a = _s32(regs[rrs])
                    b = _s32(regs[rrt])
                    lo = _u32(int(a / b))
                    hi = _u32(a - int(a / b) * b)
                elif rfunct == 0x1B:
                    a = regs[rrs]
                    b = regs[rrt]
                    lo = _u32(a // b)
                    hi = _u32(a - (a // b) * b)
                elif rfunct == 0x0C:
                    syscall(regs[2], regs[4], regs[5], regs[6])
            elif op == 0x08:
                set_reg(rrt, _s32(regs[rrs]) + rsimm)
            elif op == 0x09:
                set_reg(rrt, regs[rrs] + rsimm)
            elif op == 0x0A:
                set_reg(rrt, 1 if _s32(regs[rrs]) < rsimm else 0)
            elif op == 0x0B:
                set_reg(rrt, 1 if regs[rrs] < _u32(rsimm) else 0)
            elif op == 0x0C:
                set_reg(rrt, regs[rrs] & rimm)
            elif op == 0x0D:
                set_reg(rrt, regs[rrs] | rimm)
            elif op == 0x0E:
                set_reg(rrt, regs[rrs] ^ rimm)
            elif op == 0x0F:
                set_reg(rrt, rimm << 16)
            elif op == 0x20:
                set_reg(rrt, _s32(read8(regs[rrs] + rsimm)))
            elif op == 0x21:
                set_reg(rrt, _s32(read16(regs[rrs] + rsimm)))
            elif op == 0x23:
                set_reg(rrt, read32(regs[rrs] + rsimm))
            elif op == 0x24:
                set_reg(rrt, read8(regs[rrs] + rsimm))
            elif op == 0x25:
                set_reg(rrt, read16(regs[rrs] + rsimm))
            elif op == 0x28:
                write8(regs[rrs] + rsimm, regs[rrt])
            elif op == 0x29:
                write16(regs[rrs] + rsimm, regs[rrt])
            elif op == 0x2B:
                write32(regs[rrs] + rsimm, regs[rrt])

        exec_delay(delay_instr)

        # Now execute the branch/jump itself.
        if delay is not None:
            kind = delay[0]
            if kind == "sll":
                set_reg(delay[1], regs[delay[2]] << delay[3])
            elif kind == "srl":
                set_reg(delay[1], regs[delay[2]] >> delay[3])
            elif kind == "sra":
                set_reg(delay[1], _s32(regs[delay[2]]) >> delay[3])
            elif kind == "jr":
                next_pc = regs[delay[1]]
            elif kind == "jalr":
                set_reg(delay[1], pc + 8)
                next_pc = regs[delay[2]]
            elif kind == "mfhi":
                set_reg(delay[1], hi)
            elif kind == "mflo":
                set_reg(delay[1], lo)
            elif kind == "mthi":
                hi = regs[delay[1]]
            elif kind == "mtlo":
                lo = regs[delay[1]]
            elif kind == "mult":
                prod = _s32(regs[delay[1]]) * _s32(regs[delay[2]])
                hi = _u32(prod >> 32)
                lo = _u32(prod)
            elif kind == "multu":
                prod = regs[delay[1]] * regs[delay[2]]
                hi = _u32(prod >> 32)
                lo = _u32(prod)
            elif kind == "div":
                a = _s32(regs[delay[1]])
                b = _s32(regs[delay[2]])
                lo = _u32(int(a / b))
                hi = _u32(a - int(a / b) * b)
            elif kind == "divu":
                a = regs[delay[1]]
                b = regs[delay[2]]
                lo = _u32(a // b)
                hi = _u32(a - (a // b) * b)
            elif kind == "add":
                set_reg(delay[1], _s32(regs[delay[2]]) + _s32(regs[delay[3]]))
            elif kind == "addu":
                set_reg(delay[1], regs[delay[2]] + regs[delay[3]])
            elif kind == "sub":
                set_reg(delay[1], _s32(regs[delay[2]]) - _s32(regs[delay[3]]))
            elif kind == "subu":
                set_reg(delay[1], regs[delay[2]] - regs[delay[3]])
            elif kind == "and":
                set_reg(delay[1], regs[delay[2]] & regs[delay[3]])
            elif kind == "or":
                set_reg(delay[1], regs[delay[2]] | regs[delay[3]])
            elif kind == "xor":
                set_reg(delay[1], regs[delay[2]] ^ regs[delay[3]])
            elif kind == "nor":
                set_reg(delay[1], ~(regs[delay[2]] | regs[delay[3]]))
            elif kind == "slt":
                set_reg(delay[1], 1 if _s32(regs[delay[2]]) < _s32(regs[delay[3]]) else 0)
            elif kind == "sltu":
                set_reg(delay[1], 1 if regs[delay[2]] < regs[delay[3]] else 0)
            elif kind == "syscall":
                syscall(regs[2], regs[4], regs[5], regs[6])
            elif kind == "j":
                next_pc = delay[1]
            elif kind == "jal":
                set_reg(31, pc + 8)
                next_pc = delay[1]
            elif kind == "beq":
                if regs[delay[1]] == regs[delay[2]]:
                    next_pc = pc + 4 + (delay[3] << 2)
            elif kind == "bne":
                if regs[delay[1]] != regs[delay[2]]:
                    next_pc = pc + 4 + (delay[3] << 2)
            elif kind == "blez":
                if _s32(regs[delay[1]]) <= 0:
                    next_pc = pc + 4 + (delay[2] << 2)
            elif kind == "bgtz":
                if _s32(regs[delay[1]]) > 0:
                    next_pc = pc + 4 + (delay[2] << 2)
            elif kind == "addi":
                set_reg(delay[1], _s32(regs[delay[2]]) + delay[3])
            elif kind == "addiu":
                set_reg(delay[1], regs[delay[2]] + delay[3])
            elif kind == "slti":
                set_reg(delay[1], 1 if _s32(regs[delay[2]]) < delay[3] else 0)
            elif kind == "sltiu":
                set_reg(delay[1], 1 if regs[delay[2]] < _u32(delay[3]) else 0)
            elif kind == "andi":
                set_reg(delay[1], regs[delay[2]] & delay[3])
            elif kind == "ori":
                set_reg(delay[1], regs[delay[2]] | delay[3])
            elif kind == "xori":
                set_reg(delay[1], regs[delay[2]] ^ delay[3])
            elif kind == "lui":
                set_reg(delay[1], delay[2] << 16)
            elif kind == "lb":
                set_reg(delay[1], _s32(read8(regs[delay[2]] + delay[3])))
            elif kind == "lh":
                set_reg(delay[1], _s32(read16(regs[delay[2]] + delay[3])))
            elif kind == "lw":
                set_reg(delay[1], read32(regs[delay[2]] + delay[3]))
            elif kind == "lbu":
                set_reg(delay[1], read8(regs[delay[2]] + delay[3]))
            elif kind == "lhu":
                set_reg(delay[1], read16(regs[delay[2]] + delay[3]))
            elif kind == "sb":
                write8(regs[delay[2]] + delay[3], regs[delay[1]])
            elif kind == "sh":
                write16(regs[delay[2]] + delay[3], regs[delay[1]])
            elif kind == "sw":
                write32(regs[delay[2]] + delay[3], regs[delay[1]])

        pc = next_pc
        steps += 1

    inspect = payload.get("inspect", [])
    inspect_out = []
    for item in inspect:
        address = item["address"]
        length = item["length"]
        data = bytes(read8(address + i) for i in range(length))
        inspect_out.append({"address": address, "hex": data.hex()})

    return {
        "exit_code": exit_code,
        "registers": [_u32(r) for r in regs],
        "hi": _u32(hi),
        "lo": _u32(lo),
        "steps": steps,
        "stdout_hex": bytes(stdout_data).hex(),
        "stderr_hex": bytes(stderr_data).hex(),
        "files": {name: bytes(data).hex() for name, data in files.items()},
        "inspect": inspect_out,
        "syscalls": syscalls,
    }
