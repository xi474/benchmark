from itertools import combinations


def _solve(cpp, cpy):
    """Solve CPP * beta = CPy for a small symmetric positive-definite CPP."""
    n = len(cpp)
    a = [row[:] + [cpy[i]] for i, row in enumerate(cpp)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-15:
            raise ValueError("singular parent covariance")
        a[col], a[pivot] = a[pivot], a[col]
        pv = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= pv
        for r in range(n):
            if r != col and abs(a[r][col]) > 1e-15:
                factor = a[r][col]
                for j in range(col, n + 1):
                    a[r][j] -= factor * a[col][j]
    return [a[i][n] for i in range(n)]


def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    covariance = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload.get("max_parents", len(nodes))

    n = len(nodes)
    index = {name: i for i, name in enumerate(nodes)}
    root_idx = index[root]

    parents_of = [set() for _ in range(n)]
    for p, c in allowed:
        pi, ci = index[p], index[c]
        if ci != root_idx:
            parents_of[ci].add(pi)

    result = []
    for child in range(n):
        table = {}
        parents = sorted(parents_of[child])
        table[""] = []
        for size in range(1, min(max_parents, len(parents)) + 1):
            for combo in combinations(parents, size):
                key = ",".join(str(p) for p in combo)
                cpp = [[covariance[a][b] for b in combo] for a in combo]
                cpy = [covariance[a][child] for a in combo]
                table[key] = _solve(cpp, cpy)
        result.append(table)

    return result
