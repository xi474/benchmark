import json
import math
from itertools import combinations
from collections import deque


def _round9(x):
    return round(x, 9)


def _round6(x):
    return round(x, 6)


def _solve(cpp, cpy):
    """Solve CPP * beta = CPy for a small symmetric positive-definite CPP."""
    n = len(cpp)
    a = [row[:] + [cpy[i]] for i, row in enumerate(cpp)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-15:
            raise ValueError("singular parent covariance")
        a[col], a[pivot] = a[pivot], a[col]
        pv = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= pv
        for r in range(n):
            if r != col and abs(a[r][col]) > 1e-15:
                factor = a[r][col]
                for j in range(col, n + 1):
                    a[r][j] -= factor * a[col][j]
    return [a[i][n] for i in range(n)]


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    nodes = payload["nodes"]
    covariance = payload["covariance"]
    mean = payload["mean"]
    sample_size = payload["sample_size"]
    allowed = payload["allowed"]
    root = payload["root"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload.get("intervention")

    n = len(nodes)
    index = {name: i for i, name in enumerate(nodes)}
    root_idx = index[root]

    admissible = [tuple(e) for e in left]
    reg_tables = right

    allowed_parents = [set() for _ in range(n)]
    for p, c in admissible:
        allowed_parents[c].add(p)

    def residual_var(child, parents):
        if not parents:
            return covariance[child][child]
        cpp = [[covariance[a][b] for b in parents] for a in parents]
        cpy = [covariance[a][child] for a in parents]
        beta = _solve(cpp, cpy)
        return covariance[child][child] - sum(cpy[i] * beta[i] for i in range(len(parents)))

    cand_edges = sorted(admissible)

    def is_acyclic(edges):
        indeg = [0] * n
        adj = [[] for _ in range(n)]
        for p, c in edges:
            adj[p].append(c)
            indeg[c] += 1
        q = deque([i for i in range(n) if indeg[i] == 0])
        seen = 0
        while q:
            u = q.popleft()
            seen += 1
            for v in adj[u]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)
        return seen == n

    def score_edges(edges):
        total = 0.0
        parents_of = [set() for _ in range(n)]
        for p, c in edges:
            parents_of[c].add(p)
        for c in range(n):
            parents = sorted(parents_of[c])
            rv = residual_var(c, parents)
            total += sample_size * math.log(rv) + len(parents) * math.log(sample_size)
        return total

    best = None
    best_score = None
    best_edges = None

    for combo in combinations(cand_edges, edge_count):
        indeg = [0] * n
        ok = True
        for p, c in combo:
            indeg[c] += 1
            if indeg[c] > max_parents:
                ok = False
                break
        if not ok:
            continue
        if not is_acyclic(combo):
            continue
        s = score_edges(combo)
        rs = _round9(s)
        if best_score is None or rs < best_score or (rs == best_score and sorted(combo) < sorted(best_edges)):
            best_score = rs
            best_edges = sorted(combo)
            best = combo

    if best is None:
        return {"feasible": False}

    edges = [[nodes[p], nodes[c]] for p, c in best_edges]

    parents_of = [set() for _ in range(n)]
    for p, c in best_edges:
        parents_of[c].add(p)

    coefficients = []
    for p, c in best_edges:
        parents = sorted(parents_of[c])
        key = ",".join(str(x) for x in parents)
        beta = reg_tables[c][key]
        pos = parents.index(p)
        coefficients.append([nodes[p], nodes[c], _round6(beta[pos])])

    score = _round6(best_score)

    intervened_edges = []
    if intervention is not None:
        iv_node = intervention["node"]
        iv_value = intervention["value"]
        iv_idx = index[iv_node]
        intervened_edges = [[nodes[p], nodes[c]] for p, c in best_edges if c == iv_idx]

        adj = [[] for _ in range(n)]
        indeg = [0] * n
        for p, c in best_edges:
            adj[p].append(c)
            indeg[c] += 1
        q = deque([i for i in range(n) if indeg[i] == 0])
        topo = []
        while q:
            u = q.popleft()
            topo.append(u)
            for v in adj[u]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)

        obs_mean = list(mean)

        intercept = [0.0] * n
        for c in range(n):
            parents = sorted(parents_of[c])
            if parents:
                key = ",".join(str(x) for x in parents)
                beta = reg_tables[c][key]
                s = sum(beta[i] * obs_mean[parents[i]] for i in range(len(parents)))
                intercept[c] = obs_mean[c] - s
            else:
                intercept[c] = obs_mean[c]

        new_mean = [0.0] * n
        for c in topo:
            if c == iv_idx:
                new_mean[c] = iv_value
            else:
                parents = sorted(parents_of[c])
                if parents:
                    key = ",".join(str(x) for x in parents)
                    beta = reg_tables[c][key]
                    s = sum(beta[i] * new_mean[parents[i]] for i in range(len(parents)))
                    new_mean[c] = intercept[c] + s
                else:
                    new_mean[c] = intercept[c]

        mean_out = [_round6(x) for x in new_mean]
    else:
        mean_out = [_round6(x) for x in mean]

    return {
        "feasible": True,
        "edges": edges,
        "score": score,
        "coefficients": coefficients,
        "intervened_edges": intervened_edges,
        "mean": mean_out,
    }
