import math


def _matvec(W, x):
    """W is [out, in], x is [in]. Returns [out]."""
    return [sum(wij * xj for wij, xj in zip(row, x)) for row in W]


def _matvec_T(W, y):
    """W is [out, in], y is [out]. Returns [in] = W^T @ y."""
    n_in = len(W[0])
    return [sum(W[i][j] * y[i] for i in range(len(W))) for j in range(n_in)]


def _outer(dz, a_in):
    """dz is [out], a_in is [in]. Returns [out][in] = dz outer a_in."""
    return [[dz_i * a_j for a_j in a_in] for dz_i in dz]


def compute(payload):
    """按实际 stage 保留每个微批激活并反传；返回整题格式的 loss 和各层 gradients，采用微批等权和 float64。"""
    layers = payload["layers"]
    microbatches = payload["microbatches"]

    L = len(layers)
    weights = [layer["weight"] for layer in layers]
    biases = [layer["bias"] for layer in layers]

    grad_w = [[[0.0] * len(w[0]) for _ in range(len(w))] for w in weights]
    grad_b = [[0.0] * len(b) for b in biases]

    total_loss = 0.0
    num_microbatches = len(microbatches)

    for mb in microbatches:
        inputs = mb["inputs"]
        targets = mb["targets"]
        batch_size = len(inputs)

        # Forward pass, storing pre-activations and activations per layer.
        activations = [inputs]
        pre_acts = []
        for l in range(L):
            z = [_matvec(weights[l], x) for x in activations[-1]]
            z = [[z[i][j] + biases[l][j] for j in range(len(biases[l]))] for i in range(batch_size)]
            pre_acts.append(z)
            if l == L - 1:
                a = z  # logits
            else:
                a = [[math.tanh(v) for v in row] for row in z]
            activations.append(a)

        logits = activations[-1]
        # Stable softmax cross-entropy per sample.
        mb_loss = 0.0
        probs = []
        for i in range(batch_size):
            row = logits[i]
            m = max(row)
            exps = [math.exp(v - m) for v in row]
            s = sum(exps)
            p = [e / s for e in exps]
            probs.append(p)
            mb_loss += -(row[targets[i]] - m - math.log(s))
        mb_loss /= batch_size
        total_loss += mb_loss

        # Backward pass.
        dlogits = [[p[j] - (1.0 if j == targets[i] else 0.0) for j in range(len(p))]
                   for i, p in enumerate(probs)]
        dlogits = [[v / batch_size for v in row] for row in dlogits]

        d_act = dlogits
        for l in range(L - 1, -1, -1):
            z = pre_acts[l]
            if l == L - 1:
                dz = d_act
            else:
                dz = [[d_act[i][j] * (1.0 - math.tanh(z[i][j]) ** 2)
                       for j in range(len(z[i]))] for i in range(batch_size)]
            a_in = activations[l]
            for i in range(batch_size):
                outer = _outer(dz[i], a_in[i])
                for o in range(len(weights[l])):
                    for j in range(len(weights[l][o])):
                        grad_w[l][o][j] += outer[o][j]
                    grad_b[l][o] += dz[i][o]
            if l > 0:
                d_act = [_matvec_T(weights[l], dz[i]) for i in range(batch_size)]

    loss = total_loss / num_microbatches

    gradients = [
        {
            "weight": [[v / num_microbatches for v in row] for row in grad_w[l]],
            "bias": [v / num_microbatches for v in grad_b[l]],
        }
        for l in range(L)
    ]

    return {"loss": loss, "gradients": gradients}
