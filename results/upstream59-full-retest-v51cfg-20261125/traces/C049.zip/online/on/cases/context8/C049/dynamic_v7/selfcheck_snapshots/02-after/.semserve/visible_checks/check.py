import json
import unittest

# Visible contract: TASK.md. The transform API is solution.transform(payload).
# Public checks already cover the single public fixture numerically. These
# self-checks exercise independent invariants and a second valid input using
# the injected call_candidate so candidate invocation is verified.

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "The visible contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "The visible contract does not require ValueError on invalid payload types.",
            },
        },
    },
]


def _load_payload():
    return json.loads(open("public_input.json", encoding="utf-8").read())


class TestTransform(unittest.TestCase):
    def test_output_shape_and_fields(self):
        # Rule: output has loss, gradients[{weight,bias}], partitions, events.
        payload = _load_payload()
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertEqual(
            set(result.keys()),
            {"loss", "gradients", "partitions", "events"},
        )
        self.assertIsInstance(result["loss"], float)
        self.assertEqual(len(result["gradients"]), len(payload["layers"]))
        for g in result["gradients"]:
            self.assertEqual(set(g.keys()), {"weight", "bias"})
        for p in result["partitions"]:
            self.assertEqual(set(p.keys()), {"stage", "start", "stop"})

    def test_does_not_modify_input(self):
        # Rule: transform must not modify the input object.
        payload = _load_payload()
        snapshot = json.dumps(payload, sort_keys=True)
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(json.dumps(payload, sort_keys=True), snapshot)

    def test_world_size_2_partitions_and_events(self):
        # Rule: rank r owns [floor(L*r/world), floor(L*(r+1)/world)).
        payload = _load_payload()
        payload["world_size"] = 2
        result = call_candidate("solution.py", "transform", args=[payload])
        parts = result["partitions"]
        self.assertEqual(len(parts), 2)
        self.assertEqual(parts[0], {"stage": 0, "start": 0, "stop": 1})
        self.assertEqual(parts[1], {"stage": 1, "start": 1, "stop": 2})
        ev = result["events"]
        self.assertEqual(
            ev,
            [
                {"kind": "forward", "microbatch": 0, "stage": 0},
                {"kind": "send_activation", "source": 0, "target": 1},
                {"kind": "forward", "microbatch": 0, "stage": 1},
                {"kind": "backward", "microbatch": 0, "stage": 1},
                {"kind": "send_gradient", "source": 1, "target": 0},
                {"kind": "backward", "microbatch": 0, "stage": 0},
            ],
        )

    def test_two_microbatches_equal_weighting(self):
        # Rule: loss is per-microbatch mean cross-entropy, then equal-weight
        # average across microbatches regardless of batch size.
        single = call_candidate("solution.py", "transform", args=[_load_payload()])
        payload = _load_payload()
        mb = payload["microbatches"][0]
        payload["microbatches"] = [mb, mb]
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertAlmostEqual(result["loss"], single["loss"], places=12)
        for g1, g2 in zip(result["gradients"], single["gradients"]):
            for r1, r2 in zip(g1["weight"], g2["weight"]):
                for a, b in zip(r1, r2):
                    self.assertAlmostEqual(a, b, places=12)
            for a, b in zip(g1["bias"], g2["bias"]):
                self.assertAlmostEqual(a, b, places=12)


if __name__ == "__main__":
    unittest.main()
