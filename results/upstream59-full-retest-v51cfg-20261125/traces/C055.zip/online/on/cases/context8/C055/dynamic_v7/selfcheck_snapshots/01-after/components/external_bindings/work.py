def _parse_value(raw, line_no, col, source_name, anchors):
    """Parse the value text after 'key: '. Returns (val_pos, text, is_vault)."""
    if raw.startswith("&"):
        rest = raw[1:]
        sp = rest.find(" ")
        if sp == -1:
            anchor_name = rest
            value_raw = ""
        else:
            anchor_name = rest[:sp]
            value_raw = rest[sp + 1:]
        val_pos = [source_name, line_no, col]
        if value_raw.startswith("!vault"):
            text = value_raw[len("!vault"):].strip()
            is_vault = True
        else:
            text = value_raw
            is_vault = False
        anchors[anchor_name] = (val_pos, text, is_vault)
        return val_pos, text, is_vault
    if raw.startswith("*"):
        return anchors[raw[1:]]
    if raw.startswith("!vault"):
        return [source_name, line_no, col], raw[len("!vault"):].strip(), True
    return [source_name, line_no, col], raw, False


def compute(payload):
    """解析不受信任文档的覆盖和文档内锚点。每个有效键输出 [原源序号,声明位置,[值位置,文本,是否密文,来源是否可信]]；位置为 [源名,行,列]。"""
    sources = payload["sources"]
    result = {}
    for src_idx, src in enumerate(sources):
        if src.get("trusted", False):
            continue
        name = src["name"]
        trusted = src.get("trusted", False)
        anchors = {}
        for line_no, line in enumerate(src["yaml"].split("\n"), start=1):
            stripped = line.strip()
            if stripped == "":
                continue
            if stripped == "---":
                anchors = {}
                continue
            i = 0
            while i < len(line) and line[i].islower():
                i += 1
            key = line[:i]
            if line[i:i + 2] != ": ":
                continue
            value_raw = line[i + 2:]
            col = i + 3
            val_pos, text, is_vault = _parse_value(
                value_raw, line_no, col, name, anchors
            )
            result[key] = [
                src_idx,
                [name, line_no, 1],
                [val_pos, text, is_vault, trusted],
            ]
    return result
