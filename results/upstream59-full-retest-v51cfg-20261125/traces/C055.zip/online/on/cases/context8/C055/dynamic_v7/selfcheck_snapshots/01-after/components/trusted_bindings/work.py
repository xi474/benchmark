def _parse_source(src_idx, source):
    """Parse one source document into a list of (key, decl_pos, value_record)."""
    name = source["name"]
    trusted = bool(source["trusted"])
    yaml = source["yaml"]

    anchors = {}
    entries = {}

    lines = yaml.split("\n")
    for line_no, raw_line in enumerate(lines, start=1):
        line = raw_line
        if line.strip() in ("", "---"):
            continue
        colon = line.find(":")
        if colon < 0:
            continue
        key = line[:colon]
        if not key or not key.islower() or not key.isalpha():
            continue
        rest = line[colon + 1:]
        if not rest.startswith(" "):
            continue
        value_text = rest[1:]
        value_col = colon + 3

        decl_pos = [name, line_no, 1]

        if value_text.startswith("&"):
            sp = value_text.find(" ")
            if sp < 0:
                continue
            anchor_name = value_text[1:sp]
            actual_value = value_text[sp + 1:]
            val_pos = [name, line_no, value_col]
            is_vault = actual_value.startswith("!vault")
            text = actual_value[len("!vault"):].strip() if is_vault else actual_value
            record = [val_pos, text, is_vault, trusted]
            anchors[anchor_name] = record
            entries[key] = [decl_pos, record]
            continue

        if value_text.startswith("*"):
            anchor_name = value_text[1:].strip()
            if anchor_name in anchors:
                entries[key] = [decl_pos, anchors[anchor_name]]
            continue

        is_vault = value_text.startswith("!vault")
        text = value_text[len("!vault"):].strip() if is_vault else value_text
        val_pos = [name, line_no, value_col]
        record = [val_pos, text, is_vault, trusted]
        entries[key] = [decl_pos, record]

    return entries


def compute(payload):
    """解析受信任文档的覆盖和文档内锚点。每个有效键输出 [原源序号,声明位置,[值位置,文本,是否密文,来源是否可信]]；位置为 [源名,行,列]。"""
    sources = payload["sources"]
    result = {}
    for src_idx, source in enumerate(sources):
        if not source.get("trusted"):
            continue
        for key, (decl_pos, record) in _parse_source(src_idx, source).items():
            result[key] = [src_idx, decl_pos, record]
    return result
