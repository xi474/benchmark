import json


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    sources = payload["sources"]
    tags = payload.get("tags", True)
    keys = payload.get("keys", {})

    # Merge: later sources override earlier ones. left = trusted bindings,
    # right = external (untrusted) bindings. Each maps key -> [src_idx, decl_pos, record].
    # record = [val_pos, text, is_vault, trusted].
    merged = {}
    for key, entry in left.items():
        merged[key] = entry
    for key, entry in right.items():
        merged[key] = entry

    # Determine final view: for each key, the winning entry is the one with the
    # highest source index.
    final = {}
    for key, entry in merged.items():
        src_idx = entry[0]
        if key not in final or src_idx > final[key][0]:
            final[key] = entry

    view = {}
    for key, entry in final.items():
        src_idx, decl_pos, record = entry
        val_pos, text, is_vault, trusted = record
        view[key] = {
            "src_idx": src_idx,
            "decl_pos": decl_pos,
            "val_pos": val_pos,
            "text": text,
            "is_vault": is_vault,
            "trusted": trusted,
        }

    # Resolve vaults.
    if not tags:
        for key, v in view.items():
            if v["is_vault"]:
                if v["text"] not in keys:
                    return {"status": "sealed"}
                v["text"] = keys[v["text"]]
                v["is_vault"] = False
                v["trusted"] = True

    render_cache = {}

    def render_key(key, stack):
        if key in render_cache:
            return render_cache[key]
        if key in stack:
            return ""
        v = view[key]
        if v["is_vault"]:
            if tags:
                render_cache[key] = "[sealed]"
                return "[sealed]"
            result = render_text(v["text"], stack + [key])
            render_cache[key] = result
            return result
        if v["trusted"]:
            result = render_text(v["text"], stack + [key])
            render_cache[key] = result
            return result
        render_cache[key] = v["text"]
        return v["text"]

    def render_text(text, stack):
        out = []
        i = 0
        n = len(text)
        while i < n:
            if text[i] == "$" and i + 1 < n and text[i + 1] == "{":
                j = text.find("}", i + 2)
                if j != -1:
                    ref = text[i + 2:j]
                    out.append(render_key(ref, stack))
                    i = j + 1
                    continue
            out.append(text[i])
            i += 1
        return "".join(out)

    entries = []
    for key in sorted(view.keys()):
        v = view[key]
        if v["is_vault"] and tags:
            trusted = False
            render = "[sealed]"
        elif v["is_vault"] and not tags:
            trusted = True
            render = render_key(key, [])
        else:
            trusted = v["trusted"]
            render = render_key(key, [])
        entries.append([key, v["decl_pos"], v["val_pos"], trusted, render])

    dump_lines = []
    for key in sorted(view.keys()):
        v = view[key]
        prefix = "!vault " if (v["is_vault"] and tags) else ""
        dump_lines.append(key + ": " + prefix + json.dumps(v["text"], ensure_ascii=False))

    dump = "\n".join(dump_lines) + "\n"

    return {"status": "ok", "entries": entries, "dump": dump}
