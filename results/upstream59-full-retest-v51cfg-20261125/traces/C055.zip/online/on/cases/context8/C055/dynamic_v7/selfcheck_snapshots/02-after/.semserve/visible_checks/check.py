import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "输入 sources 是按覆盖顺序的文档源序列，每份有 name、trusted、yaml。",
                "reason": "The public spec does not state that unknown fields or non-finite numbers must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The spec does not document a ValueError contract for invalid payload types.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_sealed_when_missing_key(self):
        # tags=false with a vault lacking a key must return {"status":"sealed"}.
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: !vault v1\n"},
            ],
            "tags": False,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, {"status": "sealed"})

    def test_vault_unsealed_trusted(self):
        # tags=false with a key present: vault becomes trusted plaintext.
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: !vault v1\n"},
            ],
            "tags": False,
            "keys": {"v1": "secret"},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        entries = result["entries"]
        self.assertEqual(len(entries), 1)
        key, decl, val, trusted, render = entries[0]
        self.assertEqual(key, "a")
        self.assertTrue(trusted)
        self.assertEqual(render, "secret")
        self.assertEqual(result["dump"], 'a: "secret"\n')

    def test_vault_sealed_tags_true(self):
        # tags=true: vault exported as ciphertext, trusted=False, render="[sealed]".
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: !vault v1\n"},
            ],
            "tags": True,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        entries = result["entries"]
        key, decl, val, trusted, render = entries[0]
        self.assertFalse(trusted)
        self.assertEqual(render, "[sealed]")
        self.assertEqual(result["dump"], 'a: !vault "v1"\n')

    def test_untrusted_plain_not_rendered(self):
        # Untrusted plain value keeps original text (no ${} substitution).
        payload = {
            "sources": [
                {"name": "s", "trusted": False, "yaml": "a: x-${b}\nb: hello\n"},
            ],
            "tags": True,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        entries = {e[0]: e for e in result["entries"]}
        self.assertEqual(entries["a"][4], "x-${b}")

    def test_trusted_plain_rendered_recursively(self):
        # Trusted plain value renders ${} references recursively.
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "a: ${b}\nb: ${c}\nc: done\n"},
            ],
            "tags": True,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        entries = {e[0]: e for e in result["entries"]}
        self.assertEqual(entries["a"][4], "done")
        self.assertEqual(entries["b"][4], "done")
        self.assertEqual(entries["c"][4], "done")

    def test_entries_sorted_by_key(self):
        payload = {
            "sources": [
                {"name": "s", "trusted": True, "yaml": "z: 1\na: 2\nm: 3\n"},
            ],
            "tags": True,
            "keys": {},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        keys = [e[0] for e in result["entries"]]
        self.assertEqual(keys, ["a", "m", "z"])


if __name__ == "__main__":
    unittest.main()
