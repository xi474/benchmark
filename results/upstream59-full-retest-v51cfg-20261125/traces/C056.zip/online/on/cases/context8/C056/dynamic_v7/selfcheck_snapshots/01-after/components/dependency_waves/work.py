def compute(payload):
    """返回各依赖批次，每批含按 ID 升序排列的任务 ID。同批共享同一事实快照。"""
    tasks = payload["tasks"]
    needs = {t["id"]: t.get("needs", []) for t in tasks}
    remaining = set(needs)
    batches = []
    while remaining:
        ready = sorted(
            tid for tid in remaining
            if all(dep not in remaining for dep in needs[tid])
        )
        if not ready:
            raise ValueError("cycle detected in task dependencies")
        batches.append(ready)
        remaining.difference_update(ready)
    return batches
