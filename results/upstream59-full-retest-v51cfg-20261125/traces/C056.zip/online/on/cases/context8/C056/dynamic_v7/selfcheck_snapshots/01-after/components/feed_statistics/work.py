def compute(payload):
    """每个 host/stream 返回各次循环读取的 [items,数量,总和] 列表，保持原顺序。"""
    feeds = payload["feeds"]
    result = {}
    for host, streams in feeds.items():
        host_result = {}
        for stream, batches in streams.items():
            host_result[stream] = [
                [list(items), len(items), sum(items)] for items in batches
            ]
        result[host] = host_result
    return result
