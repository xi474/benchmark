def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tasks = payload["tasks"]
    pools = payload["pools"]
    feeds = payload["feeds"]
    initial = payload["initial"]

    waves = left
    task_by_id = {t["id"]: t for t in tasks}

    pool_cursor = {p: 0 for p in pools}
    feed_cursor = {}
    for host, streams in feeds.items():
        for stream in streams:
            feed_cursor[(host, stream)] = 0

    pool_reads = {p: 0 for p in pools}
    feed_reads = {host: {stream: 0 for stream in streams} for host, streams in feeds.items()}

    facts = dict(initial)
    committed_delta = {tid: 0 for tid in task_by_id}

    result_tasks = {}

    for wave in waves:
        assignments = {}
        for tid in wave:
            t = task_by_id[tid]
            pool = t["pool"]
            stream = t["stream"]
            host = pools[pool][pool_cursor[pool]]
            pool_cursor[pool] = (pool_cursor[pool] + 1) % len(pools[pool])
            pool_reads[pool] += 1

            items = feeds[host][stream][feed_cursor[(host, stream)]]
            feed_cursor[(host, stream)] = (feed_cursor[(host, stream)] + 1) % len(feeds[host][stream])
            feed_reads[host][stream] += 1

            assignments[tid] = (host, items)

        for tid in wave:
            t = task_by_id[tid]
            host, items = assignments[tid]
            base = facts[host]
            parent = sum(committed_delta[dep] for dep in t.get("needs", []))
            delta = sum((base + item) * (1 + parent) for item in items)
            result_tasks[tid] = {
                "host": host,
                "items": list(items),
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": t["attempts"],
            }

        for tid in wave:
            host, _ = assignments[tid]
            facts[host] += result_tasks[tid]["delta"]
            committed_delta[tid] = result_tasks[tid]["delta"]

    return {
        "tasks": result_tasks,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads,
    }
