import unittest

# Injected names available at runtime (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform must reject non-finite values in unknown fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform must raise ValueError on invalid payload types.",
            },
        },
    },
]


class TransformBehaviorTests(unittest.TestCase):
    def test_transform_matches_public_expected(self):
        # Independent oracle: recompute the public example by hand.
        payload = {
            "initial": {"h": 2, "k": -1},
            "pools": {"p": ["k", "h"], "q": ["h"]},
            "feeds": {
                "h": {"s": [[2, 3], [-1]], "t": [[1], []]},
                "k": {"s": [[4], [3]], "t": [[1, 2], [0]]},
            },
            "tasks": [
                {"id": "c", "needs": ["a", "b"], "pool": "p", "stream": "s", "attempts": 3},
                {"id": "b", "needs": [], "pool": "p", "stream": "t", "attempts": 2},
                {"id": "a", "needs": [], "pool": "q", "stream": "s", "attempts": 1},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["facts"], {"h": 121, "k": 0})
        self.assertEqual(result["pool_reads"], {"p": 2, "q": 1})
        self.assertEqual(result["feed_reads"], {"h": {"s": 2, "t": 0}, "k": {"s": 0, "t": 1}})
        self.assertEqual(result["tasks"]["a"]["delta"], 9)
        self.assertEqual(result["tasks"]["b"]["delta"], 1)
        self.assertEqual(result["tasks"]["c"]["delta"], 110)

    def test_transform_preserves_input(self):
        payload = {
            "initial": {"h": 2, "k": -1},
            "pools": {"p": ["k", "h"], "q": ["h"]},
            "feeds": {
                "h": {"s": [[2, 3], [-1]], "t": [[1], []]},
                "k": {"s": [[4], [3]], "t": [[1, 2], [0]]},
            },
            "tasks": [
                {"id": "c", "needs": ["a", "b"], "pool": "p", "stream": "s", "attempts": 3},
                {"id": "b", "needs": [], "pool": "p", "stream": "t", "attempts": 2},
                {"id": "a", "needs": [], "pool": "q", "stream": "s", "attempts": 1},
            ],
        }
        snapshot = {
            "initial": dict(payload["initial"]),
            "pools": {k: list(v) for k, v in payload["pools"].items()},
            "feeds": {h: {s: [list(b) for b in bs] for s, bs in ss.items()} for h, ss in payload["feeds"].items()},
            "tasks": [dict(t) for t in payload["tasks"]],
        }
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)

    def test_single_task_no_deps(self):
        # Minimal valid seed: one task, one host, one stream, one batch.
        payload = {
            "initial": {"h": 5},
            "pools": {"p": ["h"]},
            "feeds": {"h": {"s": [[1, 2]]}},
            "tasks": [{"id": "a", "needs": [], "pool": "p", "stream": "s", "attempts": 1}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # base=5, parent=0, items=[1,2] -> (5+1)+(5+2)=13
        self.assertEqual(result["tasks"]["a"]["delta"], 13)
        self.assertEqual(result["tasks"]["a"]["base"], 5)
        self.assertEqual(result["tasks"]["a"]["parent"], 0)
        self.assertEqual(result["facts"], {"h": 18})
        self.assertEqual(result["pool_reads"], {"p": 1})
        self.assertEqual(result["feed_reads"], {"h": {"s": 1}})

    def test_retry_uses_same_host_and_batch(self):
        # attempts > 1 must not advance selectors more than once per task.
        payload = {
            "initial": {"h": 0},
            "pools": {"p": ["h"]},
            "feeds": {"h": {"s": [[3], [100]]}},
            "tasks": [{"id": "a", "needs": [], "pool": "p", "stream": "s", "attempts": 5}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # Only the first batch [3] is consumed; delta = (0+3)*(1+0) = 3.
        self.assertEqual(result["tasks"]["a"]["items"], [3])
        self.assertEqual(result["tasks"]["a"]["delta"], 3)
        self.assertEqual(result["feed_reads"], {"h": {"s": 1}})
        self.assertEqual(result["pool_reads"], {"p": 1})

    def test_lexicographic_selector_order(self):
        # Two tasks in the same wave share one pool; id order decides host assignment.
        payload = {
            "initial": {"h": 0, "k": 0},
            "pools": {"p": ["h", "k"]},
            "feeds": {"h": {"s": [[1]]}, "k": {"s": [[2]]}},
            "tasks": [
                {"id": "z", "needs": [], "pool": "p", "stream": "s", "attempts": 1},
                {"id": "a", "needs": [], "pool": "p", "stream": "s", "attempts": 1},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # "a" sorts first -> host h (batch [1]); "z" -> host k (batch [2]).
        self.assertEqual(result["tasks"]["a"]["host"], "h")
        self.assertEqual(result["tasks"]["z"]["host"], "k")
        self.assertEqual(result["tasks"]["a"]["delta"], 1)
        self.assertEqual(result["tasks"]["z"]["delta"], 2)


if __name__ == "__main__":
    unittest.main()
