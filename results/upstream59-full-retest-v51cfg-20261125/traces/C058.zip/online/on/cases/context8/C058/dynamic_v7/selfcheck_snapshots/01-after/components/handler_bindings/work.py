STAGES = ["pre", "roles", "includes", "tasks", "post"]


def compute(payload):
    """输出 [处理器声明顺序映射,叶节点到通知清单的映射]。

    叶节点按树位置编码（各级整数以 / 分隔）；通知名去重并按声明顺序排列，
    含 rescue、always 分支。
    """
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})
    handler_order = {name: idx for idx, name in enumerate(handlers)}

    leaf_to_notify = {}

    def add_leaf(path, task):
        notify = task.get("notify", []) if isinstance(task, dict) else []
        if not isinstance(notify, list):
            notify = []
        seen = set()
        deduped = []
        for name in notify:
            if name not in seen:
                seen.add(name)
                deduped.append(name)
        deduped.sort(key=lambda n: handler_order.get(n, len(handler_order)))
        leaf_to_notify[path] = deduped

    for s, stage in enumerate(STAGES):
        items = program.get(stage, [])
        if not isinstance(items, list):
            items = []
        for i, item in enumerate(items):
            if isinstance(item, dict) and "block" in item:
                block = item.get("block", {})
                if not isinstance(block, dict):
                    block = {}
                for branch_idx, branch_name in ((0, "tasks"), (1, "rescue"), (2, "always")):
                    branch_items = block.get(branch_name, [])
                    if not isinstance(branch_items, list):
                        branch_items = []
                    for j, task in enumerate(branch_items):
                        add_leaf(f"{s}/{i}/{branch_idx}/{j}", task)
            else:
                add_leaf(f"{s}/{i}", item)

    return [handler_order, leaf_to_notify]
