STAGES = ["pre", "roles", "includes", "tasks", "post"]


def _is_block(item):
    return isinstance(item, dict) and "block" in item


def _is_task(item):
    return isinstance(item, dict) and "id" in item


def _only_satisfied(item, host):
    only = item.get("only")
    if only is None:
        return True
    return host in only


def _will_fail(item, host):
    fail_hosts = item.get("fail_hosts")
    if fail_hosts is None:
        return False
    return host in fail_hosts


def _walk(items, prefix, host, ancestor_exec, table):
    for i, item in enumerate(items):
        path = prefix + "/" + str(i)
        if _is_block(item):
            own_exec = _only_satisfied(item, host)
            exec_ = ancestor_exec and own_exec
            table[path] = [exec_, False]
            block = item["block"]
            _walk(block.get("tasks", []), path + "/0", host, exec_, table)
            _walk(block.get("rescue", []), path + "/1", host, exec_, table)
            _walk(block.get("always", []), path + "/2", host, exec_, table)
        elif _is_task(item):
            own_exec = _only_satisfied(item, host)
            exec_ = ancestor_exec and own_exec
            table[path] = [exec_, _will_fail(item, host)]


def compute(payload):
    """每个 host 对应一张节点表，按树位置（各级整数以 / 分隔）记录 [可执行,会失败]；包含块节点。"""
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})
    result = {}
    for host in hosts:
        table = {}
        for si, stage in enumerate(STAGES):
            _walk(program.get(stage, []), str(si), host, True, table)
        result[host] = table
    return result
