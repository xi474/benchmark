STAGES = ["pre", "roles", "includes", "tasks", "post"]


def _is_block(item):
    return isinstance(item, dict) and "block" in item


def _is_task(item):
    return isinstance(item, dict) and "id" in item


def _only_satisfied(item, host):
    only = item.get("only")
    if only is None:
        return True
    return host in only


def _will_fail(item, host):
    fail_hosts = item.get("fail_hosts")
    if fail_hosts is None:
        return False
    return host in fail_hosts


def _notify(item):
    notify = item.get("notify", []) if isinstance(item, dict) else []
    if not isinstance(notify, list):
        return []
    return notify


def _build_nodes(program):
    """Return an ordered list of node descriptors in canonical order."""
    nodes = []

    def walk(items, prefix, stage, branch, block_path):
        for i, item in enumerate(items):
            path = prefix + [i]
            if _is_block(item):
                block = item.get("block", {})
                if not isinstance(block, dict):
                    block = {}
                walk(block.get("tasks", []), path + [0], stage, "tasks", path)
                walk(block.get("rescue", []), path + [1], stage, "rescue", path)
                walk(block.get("always", []), path + [2], stage, "always", path)
            elif _is_task(item):
                nodes.append({
                    "path": "/".join(str(x) for x in path),
                    "key": tuple(path),
                    "kind": "task",
                    "stage": stage,
                    "item": item,
                    "branch": branch,
                    "block_path": block_path,
                })

    for si, stage in enumerate(STAGES):
        items = program.get(stage, [])
        if not isinstance(items, list):
            items = []
        walk(items, [si], si, None, None)

    result = []
    for stage in range(len(STAGES)):
        stage_nodes = [n for n in nodes if n["stage"] == stage]
        result.extend(stage_nodes)
        # Flush only exists if the stage has any program nodes.
        if stage_nodes:
            result.append({
                "path": None,
                "key": None,
                "kind": "flush",
                "stage": stage,
                "item": None,
                "branch": None,
                "block_path": None,
            })
    return result


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = host_conditions value: {host: {path: [executable, will_fail]}}
    right = handler_bindings value: [handler_order, leaf_to_notify]
    """
    hosts = payload.get("hosts", [])
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    handler_order, leaf_to_notify = right

    nodes = _build_nodes(program)

    host_state = {}
    for host in hosts:
        host_state[host] = {
            "node_index": 0,
            "failed": False,
            "pending_notify": set(),
            "stage": 0,
        }

    batches = []
    final = {}

    while True:
        ready = []
        for host in hosts:
            st = host_state[host]
            if st["failed"]:
                continue
            idx = st["node_index"]
            if idx >= len(nodes):
                continue
            ready.append((host, idx, nodes[idx]))

        if not ready:
            break

        min_idx = min(idx for _, idx, _ in ready)
        selected = [(h, i, n) for h, i, n in ready if i == min_idx]

        for host, idx, node in selected:
            st = host_state[host]
            st["node_index"] = idx + 1

            if node["kind"] == "flush":
                pending = st["pending_notify"]
                ordered = [h for h in handlers if h in pending]
                batches.append({
                    "host": host,
                    "task": None,
                    "kind": "flush",
                    "status": "ok",
                    "handlers": ordered,
                })
                for h in ordered:
                    batches.append({
                        "host": host,
                        "task": None,
                        "kind": "handler",
                        "status": "ok",
                        "handler": h,
                    })
                st["pending_notify"] = set()
                st["stage"] += 1
                continue

            item = node["item"]
            path = node["path"]
            table = left.get(host, {})
            entry = table.get(path)
            if entry is None:
                executable = _only_satisfied(item, host)
                will_fail = _will_fail(item, host)
            else:
                executable = entry[0]
                will_fail = entry[1]

            if not executable:
                batches.append({
                    "host": host,
                    "task": item.get("id"),
                    "kind": "task",
                    "status": "skipped",
                })
                continue

            if will_fail:
                status = "failed"
            else:
                status = "ok"

            batches.append({
                "host": host,
                "task": item.get("id"),
                "kind": "task",
                "status": status,
            })

            if status == "ok":
                for name in _notify(item):
                    st["pending_notify"].add(name)
            else:
                st["failed"] = True
                final[host] = "failed"

    for host in hosts:
        if host not in final:
            final[host] = "ok"

    return {
        "batches": batches,
        "final": final,
    }
