import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "Public contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "Public contract does not require ValueError on invalid payload types.",
            },
        },
    },
]


class TestTransform(unittest.TestCase):
    def test_empty_program_returns_empty_batches(self):
        # Public rule: "空输入程序返回空batches。"
        payload = {"hosts": ["h0", "h1"], "handlers": [], "program": {}}
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["batches"], [])
        self.assertEqual(result["final"], {"h0": "ok", "h1": "ok"})

    def test_single_task_ok_produces_task_batch(self):
        # A single successful task yields one task batch and final ok.
        payload = {
            "hosts": ["h0"],
            "handlers": [],
            "program": {"tasks": [{"id": "t1"}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(len(result["batches"]), 2)
        self.assertEqual(result["batches"][0]["host"], "h0")
        self.assertEqual(result["batches"][0]["task"], "t1")
        self.assertEqual(result["batches"][0]["kind"], "task")
        self.assertEqual(result["batches"][0]["status"], "ok")
        self.assertEqual(result["batches"][1]["kind"], "flush")
        self.assertEqual(result["final"], {"h0": "ok"})

    def test_failed_task_marks_host_failed(self):
        # A task failing on a host marks that host failed.
        payload = {
            "hosts": ["h0"],
            "handlers": [],
            "program": {"tasks": [{"id": "t1", "fail_hosts": ["h0"]}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["final"], {"h0": "failed"})
        self.assertEqual(result["batches"][0]["status"], "failed")

    def test_notify_produces_flush_and_handler(self):
        # Successful task with notify produces flush + handler entries.
        payload = {
            "hosts": ["h0"],
            "handlers": ["h1"],
            "program": {"tasks": [{"id": "t1", "notify": ["h1"]}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        kinds = [b["kind"] for b in result["batches"]]
        self.assertEqual(kinds, ["task", "flush", "handler"])
        self.assertEqual(result["batches"][1]["handlers"], ["h1"])

    def test_only_skips_non_matching_host(self):
        # Task with only runs only on matching host.
        payload = {
            "hosts": ["h0", "h1"],
            "handlers": [],
            "program": {"tasks": [{"id": "t1", "only": ["h0"]}]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        task_batches = [b for b in result["batches"] if b["kind"] == "task"]
        self.assertEqual([b["host"] for b in task_batches], ["h0", "h1"])
        self.assertEqual([b["status"] for b in task_batches], ["ok", "skipped"])


if __name__ == "__main__":
    unittest.main()
