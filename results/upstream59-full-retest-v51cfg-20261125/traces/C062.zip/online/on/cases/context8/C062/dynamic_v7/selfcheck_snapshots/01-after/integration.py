def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    events = payload["events"]
    # left: {position(str): initial store state}
    # right: {position(str): [normal_complete_event_name, new_revision_or_null]}
    stores = {}
    for i, ev in enumerate(events):
        if ev.get("op") == "open":
            init = left[str(i)]
            stores[ev["store"]] = dict(init)

    audit = []
    state = {}
    for s in stores:
        state[s] = {
            "state": "open",
            "job": None,
            "revision": stores[s]["revision"],
            "closed_at": None,
            "updates": 0,
            "cancel_sent": False,
        }

    def emit(time, store, event, **extra):
        rec = {"time": time, "store": store, "event": event}
        rec.update(extra)
        audit.append(rec)

    for i, ev in enumerate(events):
        op = ev.get("op")
        store = ev.get("store")
        t = ev.get("time")
        if op == "open":
            emit(t, store, "opened")
            continue
        st = state[store]
        if op == "poll":
            if st["state"] in ("closing", "closed"):
                emit(t, store, "poll_rejected")
            elif st["job"] is None:
                job = ev["job"]
                st["job"] = job
                emit(t, store, "poll_started", job=job)
            else:
                emit(t, store, "poll_coalesced")
        elif op == "complete":
            job = ev["job"]
            changed = ev.get("changed", False)
            revision = ev.get("revision")
            if st["state"] == "closing" and st["cancel_sent"]:
                emit(t, store, "callback_cancelled", job=job)
                st["job"] = None
                st["state"] = "closed"
                st["closed_at"] = t
                emit(t, store, "close_returned")
            else:
                if changed:
                    st["revision"] = revision
                    st["updates"] += 1
                    emit(t, store, "snapshot_updated", job=job)
                else:
                    emit(t, store, "poll_unchanged", job=job)
                st["job"] = None
        elif op == "close":
            if st["state"] == "closed":
                emit(t, store, "close_returned")
            elif st["job"] is None:
                st["state"] = "closed"
                st["closed_at"] = t
                emit(t, store, "close_returned")
            else:
                if not st["cancel_sent"]:
                    st["cancel_sent"] = True
                    st["state"] = "closing"
                    emit(t, store, "cancel_sent", job=st["job"])
                    emit(t, store, "close_waiting")
                else:
                    emit(t, store, "close_waiting")

    result_stores = {}
    for s, st in state.items():
        result_stores[s] = {
            "backend": stores[s]["backend"],
            "state": st["state"],
            "job": st["job"],
            "revision": st["revision"],
            "closed_at": st["closed_at"],
            "updates": st["updates"],
        }

    return {"events": audit, "stores": result_stores}
