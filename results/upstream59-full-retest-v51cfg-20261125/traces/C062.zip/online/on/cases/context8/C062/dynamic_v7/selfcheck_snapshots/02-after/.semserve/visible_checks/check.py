import unittest

# Injected by the visible-contract SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None

TASK = "/workspace/TASK.md"


class TestTransformBehavior(unittest.TestCase):
    def test_open_close_minimal(self):
        payload = {"events": [
            {"time": 0, "store": "s", "op": "open", "backend": "git"},
            {"time": 1, "store": "s", "op": "close"},
        ]}
        expected = {
            "events": [
                {"time": 0, "store": "s", "event": "opened"},
                {"time": 1, "store": "s", "event": "close_returned"},
            ],
            "stores": {
                "s": {"backend": "git", "state": "closed", "job": None,
                      "revision": 0, "closed_at": 1, "updates": 0},
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, expected)

    def test_poll_complete_changed_updates(self):
        payload = {"events": [
            {"time": 0, "store": "s", "op": "open", "backend": "local"},
            {"time": 1, "store": "s", "op": "poll", "job": "j1"},
            {"time": 2, "store": "s", "op": "complete", "job": "j1", "changed": True, "revision": 7},
            {"time": 3, "store": "s", "op": "close"},
        ]}
        result = call_candidate("solution.py", "transform", args=[payload])
        events = result["events"]
        self.assertEqual([e["event"] for e in events],
                         ["opened", "poll_started", "snapshot_updated", "close_returned"])
        self.assertEqual(events[1]["job"], "j1")
        self.assertEqual(events[2]["job"], "j1")
        store = result["stores"]["s"]
        self.assertEqual(store["revision"], 7)
        self.assertEqual(store["updates"], 1)
        self.assertEqual(store["state"], "closed")

    def test_poll_unchanged_keeps_snapshot(self):
        payload = {"events": [
            {"time": 0, "store": "s", "op": "open", "backend": "s3", "revision": 3},
            {"time": 1, "store": "s", "op": "poll", "job": "j1"},
            {"time": 2, "store": "s", "op": "complete", "job": "j1", "changed": False},
            {"time": 3, "store": "s", "op": "close"},
        ]}
        result = call_candidate("solution.py", "transform", args=[payload])
        events = result["events"]
        self.assertEqual([e["event"] for e in events],
                         ["opened", "poll_started", "poll_unchanged", "close_returned"])
        store = result["stores"]["s"]
        self.assertEqual(store["revision"], 3)
        self.assertEqual(store["updates"], 0)

    def test_close_with_inflight_cancel_barrier(self):
        payload = {"events": [
            {"time": 0, "store": "s", "op": "open", "backend": "azure"},
            {"time": 1, "store": "s", "op": "poll", "job": "j1"},
            {"time": 2, "store": "s", "op": "close"},
            {"time": 3, "store": "s", "op": "complete", "job": "j1", "changed": True, "revision": 9},
        ]}
        result = call_candidate("solution.py", "transform", args=[payload])
        events = result["events"]
        self.assertEqual([e["event"] for e in events],
                         ["opened", "poll_started", "cancel_sent", "close_waiting",
                          "callback_cancelled", "close_returned"])
        # cancelled completion must not publish snapshot
        store = result["stores"]["s"]
        self.assertEqual(store["revision"], 0)
        self.assertEqual(store["updates"], 0)
        self.assertEqual(store["state"], "closed")
        self.assertEqual(store["closed_at"], 3)

    def test_poll_coalesced_and_rejected(self):
        payload = {"events": [
            {"time": 0, "store": "s", "op": "open", "backend": "oci"},
            {"time": 1, "store": "s", "op": "poll", "job": "j1"},
            {"time": 2, "store": "s", "op": "poll", "job": "j2"},
            {"time": 3, "store": "s", "op": "complete", "job": "j1", "changed": False},
            {"time": 4, "store": "s", "op": "close"},
            {"time": 5, "store": "s", "op": "poll", "job": "j3"},
        ]}
        result = call_candidate("solution.py", "transform", args=[payload])
        events = result["events"]
        self.assertEqual([e["event"] for e in events],
                         ["opened", "poll_started", "poll_coalesced", "poll_unchanged",
                          "close_returned", "poll_rejected"])

    def test_input_not_mutated(self):
        payload = {"events": [
            {"time": 0, "store": "s", "op": "open", "backend": "git"},
            {"time": 1, "store": "s", "op": "close"},
        ]}
        snapshot = {"events": [dict(e) for e in payload["events"]]}
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)


if __name__ == "__main__":
    unittest.main()
