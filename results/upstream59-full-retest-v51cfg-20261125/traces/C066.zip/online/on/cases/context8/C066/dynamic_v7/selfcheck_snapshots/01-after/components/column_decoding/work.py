def _decode(name, type_, value):
    """Decode a single column value according to its declared type.

    key/body are text, rank is int. A type mismatch yields None (null) so the
    integration layer can roll back the whole transaction.
    """
    if type_ == "text":
        if value is None or isinstance(value, str):
            return value
        return None
    if type_ == "int":
        if value is None:
            return None
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            s = value.strip()
            if not s:
                return None
            try:
                return int(s, 10)
            except ValueError:
                return None
        return None
    return None


def compute(payload):
    """按事务、语句、行变更生成已解码的列映射。D 用空对象；类型错误用 null。"""
    result = []
    for tx in payload["txs"]:
        tx_rows = []
        for statement in tx["statements"]:
            stmt_rows = []
            for op in statement:
                if op["op"] == "D":
                    stmt_rows.append({})
                    continue
                cols = {}
                for col in op.get("cols", []):
                    cols[col["name"]] = _decode(col["name"], col["type"], col["value"])
                stmt_rows.append(cols)
            tx_rows.append(stmt_rows)
        result.append(tx_rows)
    return result
