import unittest




class TestReplay(unittest.TestCase):
    def test_commit_primary_key_swap(self):
        payload = {
            "initial": {"a": {"body": "one", "rank": 1}, "b": {"body": "", "rank": 2}},
            "txs": [{"lsn": 1, "statements": [[
                {"op": "U", "old": "a", "cols": [{"name": "key", "type": "text", "value": "b"}]},
                {"op": "U", "old": "b", "cols": [
                    {"name": "key", "type": "text", "value": "a"},
                    {"name": "body", "type": "text", "value": None},
                ]},
            ]]}],
        }
        expected = {
            "log": [[1, "COMMIT"]],
            "rows": {
                "b": {"body": "one", "rank": 1},
                "a": {"body": None, "rank": 2},
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, expected)

    def test_abort_missing_old_rolls_back(self):
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}},
            "txs": [{"lsn": 1, "statements": [
                [{"op": "U", "old": "a", "cols": [{"name": "body", "type": "text", "value": "y"}]}],
                [{"op": "D", "old": "missing"}],
            ]}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[1, "ABORT"]])
        self.assertEqual(result["rows"], {"a": {"body": "x", "rank": 1}})

    def test_replay_committed_lsn(self):
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}},
            "txs": [
                {"lsn": 1, "statements": [[{"op": "U", "old": "a", "cols": [{"name": "body", "type": "text", "value": "y"}]}]]},
                {"lsn": 1, "statements": [[{"op": "D", "old": "a"}]]},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[1, "COMMIT"], [1, "REPLAY"]])
        self.assertEqual(result["rows"], {"a": {"body": "y", "rank": 1}})

    def test_abort_type_mismatch(self):
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}},
            "txs": [{"lsn": 1, "statements": [[
                {"op": "U", "old": "a", "cols": [{"name": "rank", "type": "int", "value": "notanint"}]},
            ]]}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[1, "ABORT"]])
        self.assertEqual(result["rows"], {"a": {"body": "x", "rank": 1}})

    def test_abort_new_key_collision(self):
        payload = {
            "initial": {"a": {"body": "x", "rank": 1}, "b": {"body": "y", "rank": 2}},
            "txs": [{"lsn": 1, "statements": [[
                {"op": "U", "old": "a", "cols": [{"name": "key", "type": "text", "value": "b"}]},
            ]]}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[1, "ABORT"]])
        self.assertEqual(result["rows"], {"a": {"body": "x", "rank": 1}, "b": {"body": "y", "rank": 2}})

    def test_insert_requires_all_columns(self):
        payload = {
            "initial": {},
            "txs": [{"lsn": 1, "statements": [[
                {"op": "I", "cols": [
                    {"name": "key", "type": "text", "value": "k"},
                    {"name": "body", "type": "text", "value": "b"},
                    {"name": "rank", "type": "int", "value": "5"},
                ]},
            ]]}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["log"], [[1, "COMMIT"]])
        self.assertEqual(result["rows"], {"k": {"body": "b", "rank": 5}})


if __name__ == "__main__":
    unittest.main()
