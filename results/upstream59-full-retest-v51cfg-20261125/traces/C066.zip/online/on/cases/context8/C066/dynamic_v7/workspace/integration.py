def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = row_identities: per-txn, per-statement deduped sorted consumed old keys.
    right = column_decoding: per-txn, per-statement, per-row decoded column maps.
    """
    initial = payload["initial"]
    txs = payload["txs"]

    rows = {k: dict(v) for k, v in initial.items()}
    committed = set()
    log = []

    for ti, tx in enumerate(txs):
        lsn = tx["lsn"]
        if lsn in committed:
            log.append([lsn, "REPLAY"])
            continue

        statements = tx["statements"]
        old_keys = left[ti]
        decoded = right[ti]

        snapshot = {k: dict(v) for k, v in rows.items()}
        aborted = False

        for si, statement in enumerate(statements):
            consumed = old_keys[si]
            for key in consumed:
                if key not in snapshot:
                    aborted = True
                    break
            if aborted:
                break

            for key in consumed:
                del snapshot[key]

            for ri, op in enumerate(statement):
                if op["op"] == "D":
                    continue
                cols = decoded[si][ri]
                if cols is None:
                    aborted = True
                    break
                # A type error in any column decodes to null; treat it as an abort.
                # Explicit null body/rank are legal, so only flag nulls for columns
                # whose declared type could not be decoded (key must be non-null text).
                if cols.get("key") is None:
                    aborted = True
                    break
                if "key" in cols:
                    new_key = cols["key"]
                else:
                    new_key = op["old"]
                if new_key is None or not isinstance(new_key, str) or new_key == "":
                    aborted = True
                    break
                if new_key in snapshot:
                    aborted = True
                    break

                if op["op"] == "I":
                    body = cols.get("body")
                    rank = cols.get("rank")
                else:
                    old_row = rows.get(op["old"])
                    body = cols.get("body", old_row["body"] if old_row is not None else None)
                    rank = cols.get("rank", old_row["rank"] if old_row is not None else None)

                if body is not None and not isinstance(body, str):
                    aborted = True
                    break
                if rank is not None and not isinstance(rank, int):
                    aborted = True
                    break

                snapshot[new_key] = {"body": body, "rank": rank}

            if aborted:
                break

        if aborted:
            log.append([lsn, "ABORT"])
        else:
            rows = snapshot
            committed.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": rows}
