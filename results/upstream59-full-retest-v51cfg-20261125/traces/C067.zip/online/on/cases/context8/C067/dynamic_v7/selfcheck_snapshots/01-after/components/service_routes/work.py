def compute(payload):
    """按事件位置返回请求当时的 [集群模式,服务是否可用]；合并端负责授权优先和实际计数。"""
    clusters = payload["clusters"]
    events = payload["events"]
    # Replay service events to track current availability per (cluster, service).
    availability = {}
    for cluster, info in clusters.items():
        for service, avail in info.get("services", {}).items():
            availability[(cluster, service)] = bool(avail)
    result = {}
    for i, event in enumerate(events):
        op = event.get("op")
        if op == "service":
            availability[(event["cluster"], event["service"])] = bool(event["available"])
            continue
        if op != "request":
            continue
        cluster = event["cluster"]
        service = event["service"]
        mode = clusters[cluster]["mode"]
        available = availability.get((cluster, service), False)
        result[str(i)] = [mode, available]
    return result
