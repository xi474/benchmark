def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # left: {str(index): bool} authorization per request position
    # right: {str(index): [mode, available]} per request position
    auth = left
    routes = right

    replies = []
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0

    # cache keyed by (user, cluster, service) -> {"credential": ..., "expires": ...}
    cache = {}

    for idx, event in enumerate(events):
        if event.get("op") != "request":
            continue
        key = str(idx)
        rid = event["id"]
        user = event["user"]
        cluster = event["cluster"]
        service = event["service"]

        authorizer_calls += 1
        if not auth.get(key, False):
            replies.append({"id": rid, "status": "denied"})
            continue

        service_lookups += 1
        mode, available = routes.get(key, ["local", False])
        if not available:
            replies.append({"id": rid, "status": "not_found"})
            continue

        if mode == "local":
            replies.append({"id": rid, "status": "ok", "credential": "local", "route": "local"})
            continue

        # remote
        remote_routes += 1
        now = event["time"]
        ckey = (user, cluster, service)
        # cleanup: expires <= now
        if ckey in cache and cache[ckey]["expires"] <= now:
            del cache[ckey]
        if ckey in cache:
            credential = cache[ckey]["credential"]
        else:
            certificates_issued += 1
            credential = "cert-%d" % certificates_issued
            cache[ckey] = {"credential": credential, "expires": now + ttl}
        replies.append({"id": rid, "status": "ok", "credential": credential, "route": "reverse_tunnel"})

    cache_list = [
        {
            "user": k[0],
            "cluster": k[1],
            "service": k[2],
            "credential": v["credential"],
            "expires": v["expires"],
        }
        for k, v in sorted(cache.items())
    ]

    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": cache_list,
    }
