import unittest

# Injected names provided by the SDK harness.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = None
    check_api_boundary = None

VISIBLE_DOC = "TASK.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": VISIBLE_DOC,
                "requirement_quote": "验收覆盖本文正常输入域与完整交付，不要求额外NaN/Infinity防御",
                "reason": "The public contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": VISIBLE_DOC,
                "requirement_quote": "核心接口transform(payload)返回下述JSON结果",
                "reason": "The contract does not specify ValueError for non-object payloads.",
            },
        },
    },
]


class TestVisibleContract(unittest.TestCase):
    def test_transform_returns_expected_shape(self):
        payload = {
            "ttl": 5,
            "clusters": {"here": {"mode": "local", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "here", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "a", "time": 0, "user": "alice",
                 "cluster": "here", "service": "k", "verb": "read"}
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertEqual(
            set(result.keys()),
            {"replies", "authorizer_calls", "service_lookups",
             "remote_routes", "certificates_issued", "cache"},
        )
        self.assertEqual(result["replies"], [
            {"id": "a", "status": "ok", "credential": "local", "route": "local"}
        ])
        self.assertEqual(result["authorizer_calls"], 1)
        self.assertEqual(result["service_lookups"], 1)
        self.assertEqual(result["remote_routes"], 0)
        self.assertEqual(result["certificates_issued"], 0)
        self.assertEqual(result["cache"], [])

    def test_denied_request_skips_service_and_cache(self):
        payload = {
            "ttl": 5,
            "clusters": {"away": {"mode": "remote", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "away", "verb": "write"}]},
            "events": [
                {"op": "request", "id": "a", "time": 0, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"}
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"], [{"id": "a", "status": "denied"}])
        self.assertEqual(result["authorizer_calls"], 1)
        self.assertEqual(result["service_lookups"], 0)
        self.assertEqual(result["remote_routes"], 0)
        self.assertEqual(result["certificates_issued"], 0)
        self.assertEqual(result["cache"], [])

    def test_not_found_after_authorized(self):
        payload = {
            "ttl": 5,
            "clusters": {"away": {"mode": "remote", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "away", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "a", "time": 0, "user": "alice",
                 "cluster": "away", "service": "missing", "verb": "read"}
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"], [{"id": "a", "status": "not_found"}])
        self.assertEqual(result["service_lookups"], 1)
        self.assertEqual(result["remote_routes"], 0)
        self.assertEqual(result["certificates_issued"], 0)
        self.assertEqual(result["cache"], [])

    def test_cache_expiry_issues_new_cert(self):
        payload = {
            "ttl": 5,
            "clusters": {"away": {"mode": "remote", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "away", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "a", "time": 0, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
                {"op": "request", "id": "b", "time": 5, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["credential"], "cert-1")
        self.assertEqual(result["replies"][1]["credential"], "cert-2")
        self.assertEqual(result["certificates_issued"], 2)
        self.assertEqual(len(result["cache"]), 1)
        self.assertEqual(result["cache"][0]["credential"], "cert-2")
        self.assertEqual(result["cache"][0]["expires"], 10)

    def test_cache_hit_does_not_reissue(self):
        payload = {
            "ttl": 5,
            "clusters": {"away": {"mode": "remote", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "away", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "a", "time": 0, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
                {"op": "request", "id": "b", "time": 4, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["credential"], "cert-1")
        self.assertEqual(result["replies"][1]["credential"], "cert-1")
        self.assertEqual(result["certificates_issued"], 1)
        self.assertEqual(result["cache"][0]["expires"], 5)

    def test_policy_event_replaces_allow_list(self):
        payload = {
            "ttl": 5,
            "clusters": {"away": {"mode": "remote", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "away", "verb": "read"}]},
            "events": [
                {"op": "request", "id": "a", "time": 0, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
                {"op": "policy", "time": 1, "user": "alice", "allow": []},
                {"op": "request", "id": "b", "time": 2, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "ok")
        self.assertEqual(result["replies"][1], {"id": "b", "status": "denied"})

    def test_service_event_updates_availability(self):
        payload = {
            "ttl": 5,
            "clusters": {"away": {"mode": "remote", "services": {"k": True}}},
            "policies": {"alice": [{"cluster": "away", "verb": "read"}]},
            "events": [
                {"op": "service", "time": 0, "cluster": "away",
                 "service": "k", "available": False},
                {"op": "request", "id": "a", "time": 1, "user": "alice",
                 "cluster": "away", "service": "k", "verb": "read"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"], [{"id": "a", "status": "not_found"}])
        self.assertEqual(result["service_lookups"], 1)


if __name__ == "__main__":
    unittest.main()
