def compute(payload):
    """为每个 get 的原始位置生成 [若启动时的完成时刻,value,error]；只有命中未复用时才实际启动。"""
    events = payload["events"]
    in_flight = {}  # key -> finish_time
    result = {}
    for i, ev in enumerate(events):
        t = ev["time"]
        # 在每个外部事件前，先完成到期的 load（finish_time <= t）。
        for k in [k for k, ft in in_flight.items() if ft <= t]:
            del in_flight[k]
        if ev["op"] == "get":
            key = ev["key"]
            if key not in in_flight:
                finish = t + ev["delay"]
                in_flight[key] = finish
                result[str(i)] = [finish, ev["value"], ev.get("error")]
    return result
