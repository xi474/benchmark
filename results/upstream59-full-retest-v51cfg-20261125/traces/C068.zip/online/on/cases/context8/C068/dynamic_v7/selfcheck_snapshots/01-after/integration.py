def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # left: cleanup_clock -> {position_str: next_cleanup_time}
    # right: load_proposals -> {position_str: [finish_time, value, error]}
    cleanup_positions = left
    proposals = right

    results = []
    loads = []
    cache = {}  # key -> {"value":..., "error":..., "expires":...}
    in_flight = {}  # key -> {"started_at":..., "finished_at":..., "value":..., "error":...}
    waiters = {}  # id -> {"key":..., "finished_at":..., "cancelled": bool}
    next_cleanup = 16 * ttl

    def finish_load(key):
        ld = in_flight.pop(key)
        expires = ld["finished_at"] + ttl
        cache[key] = {"value": ld["value"], "error": ld["error"], "expires": expires}
        loads.append({"key": key, "started_at": ld["started_at"], "finished_at": ld["finished_at"]})

    def complete_due_loads(now):
        due = sorted(
            (k for k, ld in in_flight.items() if ld["finished_at"] <= now),
            key=lambda k: in_flight[k]["started_at"],
        )
        for k in due:
            finish_load(k)

    for i, ev in enumerate(events):
        now = ev["time"]
        op = ev["op"]

        complete_due_loads(now)

        if op == "get":
            key = ev["key"]
            gid = ev["id"]

            if now >= next_cleanup:
                for k in [k for k, c in cache.items() if c["expires"] <= now]:
                    del cache[k]
                next_cleanup = now + 16 * ttl

            if key in cache and cache[key]["expires"] <= now:
                del cache[key]

            if key in cache:
                c = cache[key]
                status = "error" if c["error"] is not None else "ok"
                value = None if c["error"] is not None else c["value"]
                results.append({
                    "id": gid,
                    "status": status,
                    "value": value,
                    "error": c["error"],
                    "finished_at": now,
                })
            elif key in in_flight:
                ld = in_flight[key]
                waiters[gid] = {"key": key, "finished_at": ld["finished_at"]}
            else:
                delay = ev.get("delay", 0)
                finish = now + delay
                in_flight[key] = {
                    "started_at": now,
                    "finished_at": finish,
                    "value": ev.get("value"),
                    "error": ev.get("error"),
                }
                waiters[gid] = {"key": key, "finished_at": finish}

        elif op == "cancel":
            gid = ev["id"]
            if gid in waiters:
                waiters[gid]["cancelled"] = True

        elif op == "advance":
            pass

    remaining = sorted(in_flight.keys(), key=lambda k: in_flight[k]["started_at"])
    for k in remaining:
        finish_load(k)

    for gid, w in waiters.items():
        if w.get("cancelled"):
            results.append({
                "id": gid,
                "status": "cancelled",
                "value": None,
                "error": "cancelled",
                "finished_at": w["finished_at"],
            })
        else:
            key = w["key"]
            c = cache[key]
            status = "error" if c["error"] is not None else "ok"
            value = None if c["error"] is not None else c["value"]
            results.append({
                "id": gid,
                "status": status,
                "value": value,
                "error": c["error"],
                "finished_at": w["finished_at"],
            })

    get_order = {}
    idx = 0
    for ev in events:
        if ev["op"] == "get":
            get_order[ev["id"]] = idx
            idx += 1
    results.sort(key=lambda r: get_order[r["id"]])

    cache_out = [
        {"key": k, "value": cache[k]["value"], "error": cache[k]["error"], "expires": cache[k]["expires"]}
        for k in sorted(cache.keys())
    ]

    return {
        "results": results,
        "loads": loads,
        "cache": cache_out,
        "next_cleanup": next_cleanup,
    }
