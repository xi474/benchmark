import unittest

# Injected by the visible-contract SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None

VISIBLE_DOC = "/workspace/TASK.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": VISIBLE_DOC,
                "requirement_quote": "不要求额外NaN/Infinity防御",
                "reason": "The public contract explicitly does not require NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": VISIBLE_DOC,
                "requirement_quote": "输入ttl为正整数",
                "reason": "The public contract does not specify ValueError for a non-object payload.",
            },
        },
    },
]


class TestC068VisibleContract(unittest.TestCase):
    def test_transform_public_fixture(self):
        # Independent expectation derived from the public contract.
        payload = {
            "ttl": 5,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 3, "value": 1, "error": None},
                {"op": "advance", "time": 3},
                {"op": "get", "time": 4, "id": "b", "key": "k", "delay": 3, "value": 9, "error": None},
            ],
        }
        expected = {
            "results": [
                {"id": "a", "status": "ok", "value": 1, "error": None, "finished_at": 3},
                {"id": "b", "status": "ok", "value": 1, "error": None, "finished_at": 4},
            ],
            "loads": [{"key": "k", "started_at": 0, "finished_at": 3}],
            "cache": [{"key": "k", "value": 1, "error": None, "expires": 8}],
            "next_cleanup": 80,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, expected)

    def test_cancel_waiter_does_not_cancel_shared_load(self):
        # Two waiters on the same key; cancel one; the load still completes and
        # the other waiter gets the value.
        payload = {
            "ttl": 10,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 5, "value": 42, "error": None},
                {"op": "get", "time": 1, "id": "b", "key": "k", "delay": 99, "value": 7, "error": None},
                {"op": "cancel", "time": 2, "id": "b"},
                {"op": "advance", "time": 5},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        by_id = {r["id"]: r for r in result["results"]}
        self.assertEqual(by_id["a"]["status"], "ok")
        self.assertEqual(by_id["a"]["value"], 42)
        self.assertEqual(by_id["b"]["status"], "cancelled")
        self.assertEqual(by_id["b"]["error"], "cancelled")
        # The shared load still completed and entered the cache.
        self.assertEqual(len(result["loads"]), 1)
        self.assertEqual(result["loads"][0]["key"], "k")
        self.assertEqual(result["cache"][0]["value"], 42)

    def test_error_value_cached_with_null_value(self):
        payload = {
            "ttl": 10,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 2, "value": 5, "error": "boom"},
                {"op": "advance", "time": 2},
                {"op": "get", "time": 3, "id": "b", "key": "k", "delay": 0, "value": 9, "error": None},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        by_id = {r["id"]: r for r in result["results"]}
        self.assertEqual(by_id["a"]["status"], "error")
        self.assertEqual(by_id["a"]["value"], None)
        self.assertEqual(by_id["a"]["error"], "boom")
        # Second get hits the cached error.
        self.assertEqual(by_id["b"]["status"], "error")
        self.assertEqual(by_id["b"]["value"], None)
        self.assertEqual(by_id["b"]["error"], "boom")

    def test_expiry_evicts_entry(self):
        # ttl=5, load completes at 3 -> expires at 8. A get at time 9 must miss.
        payload = {
            "ttl": 5,
            "events": [
                {"op": "get", "time": 0, "id": "a", "key": "k", "delay": 3, "value": 1, "error": None},
                {"op": "advance", "time": 9},
                {"op": "get", "time": 9, "id": "b", "key": "k", "delay": 0, "value": 2, "error": None},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        by_id = {r["id"]: r for r in result["results"]}
        self.assertEqual(by_id["a"]["status"], "ok")
        self.assertEqual(by_id["a"]["value"], 1)
        # b misses (expired) and starts a new load with its own value.
        self.assertEqual(by_id["b"]["status"], "ok")
        self.assertEqual(by_id["b"]["value"], 2)
        self.assertEqual(len(result["loads"]), 2)


if __name__ == "__main__":
    unittest.main()
