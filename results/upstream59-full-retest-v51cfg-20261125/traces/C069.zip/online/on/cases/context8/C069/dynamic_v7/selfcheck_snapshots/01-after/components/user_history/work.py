def compute(payload):
    """记录各续期事件发生时的用户快照，重放 update_user 的 roles、traits；以原位置字符串为键。"""
    user = payload.get("user", {})
    current = {
        "name": user.get("name"),
        "roles": list(user.get("roles", [])),
        "traits": dict(user.get("traits", {})),
    }
    result = {}
    for index, event in enumerate(payload.get("events", [])):
        op = event.get("op")
        if op == "update_user":
            if "roles" in event:
                current["roles"] = list(event["roles"])
            if "traits" in event:
                current["traits"] = dict(event["traits"])
        elif op == "renew":
            result[str(index)] = {
                "name": current["name"],
                "roles": list(current["roles"]),
                "traits": dict(current["traits"]),
            }
    return result
