import base64
import json


def _encode(obj):
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return base64.urlsafe_b64encode(text.encode("utf-8")).decode("ascii").rstrip("=")


def combine(payload, left, right):
    user = payload.get("user", {})
    start_time = payload.get("start_time", 0)
    session_ttl = payload.get("session_ttl", 0)
    access_requests = payload.get("access_requests", {})
    events = payload.get("events", [])
    initial_id = payload.get("initial_id", "s0")

    backend_user = {
        "name": user.get("name"),
        "roles": list(user.get("roles", [])),
        "traits": dict(user.get("traits", {})),
    }

    sessions = {}
    sessions[initial_id] = {
        "login_time": start_time,
        "expiry": start_time + session_ttl,
        "cached_user": {
            "name": backend_user["name"],
            "roles": list(backend_user["roles"]),
            "traits": dict(backend_user["traits"]),
        },
        "active_requests": [],
    }

    session_ids = [initial_id]
    replies = []

    for event in events:
        op = event.get("op")
        if op == "update_user":
            if "roles" in event:
                backend_user["roles"] = list(event["roles"])
            if "traits" in event:
                backend_user["traits"] = dict(event["traits"])
            continue

        if op != "renew":
            continue

        rid = event.get("id")
        prev_id = event.get("prev")
        now = event.get("time")
        reload_user = event.get("reload_user", False)
        switchback = event.get("switchback", False)
        access_request = event.get("access_request")

        prev = sessions.get(prev_id)
        if prev is None:
            replies.append({"id": rid, "status": "expired"})
            continue

        if prev["expiry"] <= now:
            replies.append({"id": rid, "status": "expired"})
            continue

        if reload_user:
            cached_user = {
                "name": backend_user["name"],
                "roles": list(backend_user["roles"]),
                "traits": dict(backend_user["traits"]),
            }
        else:
            cached_user = {
                "name": prev["cached_user"]["name"],
                "roles": list(prev["cached_user"]["roles"]),
                "traits": dict(prev["cached_user"]["traits"]),
            }

        active_requests = list(prev["active_requests"])

        if switchback:
            active_requests = []
        elif access_request is not None:
            req = access_requests.get(access_request)
            if req is None or not req.get("approved") or req.get("expiry", 0) <= now:
                replies.append({"id": rid, "status": "request_unavailable"})
                continue
            has_resources = bool(req.get("resources"))
            if has_resources:
                conflict = False
                for ar in active_requests:
                    ar_req = access_requests.get(ar)
                    if ar_req and ar_req.get("resources"):
                        conflict = True
                        break
                if conflict:
                    replies.append({"id": rid, "status": "resource_already_active"})
                    continue
                active_requests.append(access_request)
            else:
                if access_request not in active_requests:
                    active_requests.append(access_request)

        roles = set(cached_user["roles"])
        resources = set()
        for ar in active_requests:
            ar_req = access_requests.get(ar)
            if ar_req:
                roles.update(ar_req.get("roles", []))
                resources.update(ar_req.get("resources", []))

        roles = sorted(roles)
        resources = sorted(resources)

        if active_requests:
            expiry = min(now + session_ttl, min(access_requests[ar]["expiry"] for ar in active_requests))
        else:
            expiry = now + session_ttl

        login_time = prev["login_time"]

        sessions[rid] = {
            "login_time": login_time,
            "expiry": expiry,
            "cached_user": cached_user,
            "active_requests": active_requests,
        }
        session_ids.append(rid)

        ssh_obj = {
            "roles": roles,
            "allowed_resources": resources,
            "extensions": cached_user["traits"],
            "login_time": login_time,
            "expires": expiry,
        }
        tls_obj = {
            "user": cached_user["name"],
            "active_requests": sorted(active_requests),
            "login_time": login_time,
            "expires": expiry,
        }

        replies.append({
            "id": rid,
            "status": "ok",
            "ssh_certificate": "SSH-MODEL1." + _encode(ssh_obj),
            "tls_certificate": "TLS-MODEL1." + _encode(tls_obj),
        })

    return {
        "replies": replies,
        "session_ids": session_ids,
    }
