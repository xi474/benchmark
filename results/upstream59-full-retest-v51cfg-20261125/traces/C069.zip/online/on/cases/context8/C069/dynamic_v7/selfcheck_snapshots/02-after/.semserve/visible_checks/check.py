import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "不要求额外NaN/Infinity防御",
                "reason": "Public contract explicitly excludes NaN/Infinity defense.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "不要求处理未承诺的坏编码",
                "reason": "Public contract does not require ValueError on invalid payload types.",
            },
        },
    },
]


class TestSessionRenewal(unittest.TestCase):
    def test_renew_accumulates_roles_and_resources(self):
        payload = {
            "user": {"name": "alice", "roles": ["base"], "traits": {"logins": ["alice"], "db_users": ["db1"]}},
            "start_time": 0,
            "session_ttl": 100,
            "access_requests": {
                "r1": {"approved": True, "expiry": 70, "roles": ["reader"]},
                "r2": {"approved": True, "expiry": 60, "roles": ["writer"]},
                "q1": {"approved": True, "expiry": 50, "resources": ["db:one"]},
            },
            "events": [
                {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "r1"},
                {"op": "renew", "id": "s2", "time": 20, "prev": "s1", "access_request": "r2"},
                {"op": "renew", "id": "s3", "time": 30, "prev": "s2", "access_request": "q1"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["session_ids"], ["s0", "s1", "s2", "s3"])
        self.assertEqual([r["status"] for r in result["replies"]], ["ok", "ok", "ok"])
        # s3 has roles base+reader+writer and resource db:one
        import base64, json
        cert = result["replies"][2]["ssh_certificate"]
        self.assertTrue(cert.startswith("SSH-MODEL1."))
        body = cert[len("SSH-MODEL1."):]
        obj = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)).decode("utf-8"))
        self.assertEqual(obj["roles"], ["base", "reader", "writer"])
        self.assertEqual(obj["allowed_resources"], ["db:one"])

    def test_resource_already_active(self):
        payload = {
            "user": {"name": "alice", "roles": [], "traits": {"logins": [], "db_users": []}},
            "start_time": 0,
            "session_ttl": 100,
            "access_requests": {
                "q1": {"approved": True, "expiry": 50, "resources": ["db:one"]},
                "q2": {"approved": True, "expiry": 40, "resources": ["db:two"]},
            },
            "events": [
                {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "q1"},
                {"op": "renew", "id": "s2", "time": 20, "prev": "s1", "access_request": "q2"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][1]["status"], "resource_already_active")
        self.assertEqual(result["session_ids"], ["s0", "s1"])

    def test_expired_prev(self):
        payload = {
            "user": {"name": "alice", "roles": [], "traits": {"logins": [], "db_users": []}},
            "start_time": 0,
            "session_ttl": 10,
            "access_requests": {},
            "events": [
                {"op": "renew", "id": "s1", "time": 20, "prev": "s0"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "expired")
        self.assertEqual(result["session_ids"], ["s0"])

    def test_request_unavailable_not_approved(self):
        payload = {
            "user": {"name": "alice", "roles": [], "traits": {"logins": [], "db_users": []}},
            "start_time": 0,
            "session_ttl": 100,
            "access_requests": {
                "no": {"approved": False, "expiry": 90, "roles": ["admin"]},
            },
            "events": [
                {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "no"},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["replies"][0]["status"], "request_unavailable")
        self.assertEqual(result["session_ids"], ["s0"])

    def test_switchback_clears_requests(self):
        payload = {
            "user": {"name": "alice", "roles": ["base"], "traits": {"logins": [], "db_users": []}},
            "start_time": 0,
            "session_ttl": 100,
            "access_requests": {
                "r1": {"approved": True, "expiry": 70, "roles": ["reader"]},
            },
            "events": [
                {"op": "renew", "id": "s1", "time": 10, "prev": "s0", "access_request": "r1"},
                {"op": "renew", "id": "s2", "time": 20, "prev": "s1", "switchback": True},
            ],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        import base64, json
        cert = result["replies"][1]["ssh_certificate"]
        body = cert[len("SSH-MODEL1."):]
        obj = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)).decode("utf-8"))
        self.assertEqual(obj["roles"], ["base"])
        self.assertEqual(obj["allowed_resources"], [])


if __name__ == "__main__":
    unittest.main()
