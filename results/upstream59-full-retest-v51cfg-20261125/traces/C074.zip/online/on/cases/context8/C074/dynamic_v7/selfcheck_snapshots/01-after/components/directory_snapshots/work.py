def _resolve(path, mounts, nodes):
    parts = path.split("/")
    node_id = mounts[parts[0]]
    for part in parts[1:]:
        node_id = nodes[node_id]["dirs"][part]
    return nodes[node_id]


def compute(payload):
    """按扫描轮次生成映射，从每个完成目录的逻辑路径映射至 [保留文件映射,可见子目录名升序数组]。按轮累计替换节点。"""
    nodes = {k: dict(v) for k, v in payload["nodes"].items()}
    mounts = payload["mounts"]
    result = []
    for scan in payload["scans"]:
        for node_id, repl in scan.get("replace", {}).items():
            nodes[node_id] = dict(repl)
        round_map = {}
        for path in scan.get("finish", []):
            node = _resolve(path, mounts, nodes)
            ignore = set(node.get("ignore", []))
            files = {k: v for k, v in node.get("files", {}).items() if k not in ignore}
            dirs = sorted(k for k in node.get("dirs", {}) if k not in ignore)
            round_map[path] = [files, dirs]
        result.append(round_map)
    return result
