def compute(payload):
    """每轮返回完成的逻辑路径，按深度先父后子，同深度维持输入顺序。"""
    result = []
    for scan in payload["scans"]:
        paths = list(scan.get("finish", []))
        # Stable sort by depth (number of '/' separators); equal depth keeps input order.
        paths.sort(key=lambda p: p.count("/"))
        result.append(paths)
    return result
