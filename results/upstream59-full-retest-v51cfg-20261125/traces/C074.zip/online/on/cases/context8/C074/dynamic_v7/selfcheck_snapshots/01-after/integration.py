def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = directory_snapshots: per-round {logical_path: [files_map, visible_subdirs]}
    right = scan_precedence: per-round ordered finished logical paths
    """
    return _simulate(payload, left, right)


def _simulate(payload, left, right):
    nodes = payload["nodes"]
    scans = payload["scans"]
    cur_nodes = {k: dict(v) for k, v in nodes.items()}
    index = dict(payload["initial"])
    results = []

    for round_idx, scan in enumerate(scans):
        for node_id, repl in scan.get("replace", {}).items():
            cur_nodes[node_id] = dict(repl)

        before = dict(index)
        snapshots = left[round_idx]
        finished = right[round_idx]

        for path in finished:
            files, dirs = snapshots[path]
            prefix = path + "/"
            for old_path in list(index.keys()):
                if not old_path.startswith(prefix):
                    continue
                rest = old_path[len(prefix):]
                if "/" in rest:
                    first = rest.split("/", 1)[0]
                    if first not in dirs:
                        del index[old_path]
                else:
                    if rest not in files:
                        del index[old_path]
            for name, track_id in files.items():
                index[path + "/" + name] = track_id

        after = dict(index)

        changed = {}
        all_ids = set()
        for p, t in before.items():
            all_ids.add(t)
        for p, t in after.items():
            all_ids.add(t)
        for t in all_ids:
            old_paths = sorted(p for p, tt in before.items() if tt == t)
            new_paths = sorted(p for p, tt in after.items() if tt == t)
            if old_paths != new_paths:
                changed[t] = [old_paths, new_paths]

        results.append({"index": after, "changed": changed})

    return results
