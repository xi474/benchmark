import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict


class TestTransform(unittest.TestCase):
    def test_public_fixture_roundtrip(self):
        payload = {
            "nodes": {
                "root": {"files": {"old": "1"}, "dirs": {"d": "disk", "mirror": "disk"}, "ignore": []},
                "disk": {"files": {"intro": "2", "end": "3"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root", "B": "disk"},
            "initial": {
                "A/old": "1",
                "A/d/intro": "2",
                "A/d/gone": "4",
                "A/mirror/intro": "2",
                "B/intro": "2",
            },
            "scans": [{"finish": ["A/d", "B"], "replace": {}}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
        self.assertEqual(
            result[0]["index"],
            {
                "A/old": "1",
                "A/d/intro": "2",
                "A/mirror/intro": "2",
                "B/intro": "2",
                "A/d/end": "3",
                "B/end": "3",
            },
        )
        self.assertEqual(result[0]["changed"]["3"], [[], ["A/d/end", "B/end"]])
        self.assertEqual(result[0]["changed"]["4"], [["A/d/gone"], []])

    def test_input_not_mutated(self):
        payload = {
            "nodes": {
                "root": {"files": {"old": "1"}, "dirs": {"d": "disk"}, "ignore": []},
                "disk": {"files": {"intro": "2"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root"},
            "initial": {"A/old": "1", "A/d/intro": "2"},
            "scans": [{"finish": ["A/d"], "replace": {}}],
        }
        snapshot = {
            "nodes": dict(payload["nodes"]),
            "mounts": dict(payload["mounts"]),
            "initial": dict(payload["initial"]),
            "scans": list(payload["scans"]),
        }
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload["nodes"], snapshot["nodes"])
        self.assertEqual(payload["mounts"], snapshot["mounts"])
        self.assertEqual(payload["initial"], snapshot["initial"])
        self.assertEqual(payload["scans"], snapshot["scans"])

    def test_ignore_prunes_branch(self):
        # A directory whose direct child is ignored must drop old index under it.
        payload = {
            "nodes": {
                "root": {"files": {}, "dirs": {"d": "disk"}, "ignore": []},
                "disk": {"files": {"keep": "2"}, "dirs": {"sub": "sub"}, "ignore": ["sub"]},
                "sub": {"files": {"x": "9"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root"},
            "initial": {"A/d/keep": "2", "A/d/sub/x": "9"},
            "scans": [{"finish": ["A/d"], "replace": {}}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertNotIn("A/d/sub/x", result[0]["index"])
        self.assertIn("A/d/keep", result[0]["index"])
        self.assertEqual(result[0]["changed"]["9"], [["A/d/sub/x"], []])

    def test_replace_changes_files(self):
        payload = {
            "nodes": {
                "root": {"files": {}, "dirs": {"d": "disk"}, "ignore": []},
                "disk": {"files": {"a": "1"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root"},
            "initial": {"A/d/a": "1"},
            "scans": [{"finish": ["A/d"], "replace": {"disk": {"files": {"b": "2"}, "dirs": {}, "ignore": []}}}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertNotIn("A/d/a", result[0]["index"])
        self.assertIn("A/d/b", result[0]["index"])
        self.assertEqual(result[0]["changed"]["1"], [["A/d/a"], []])
        self.assertEqual(result[0]["changed"]["2"], [[], ["A/d/b"]])

    def test_unfinished_subdir_preserved(self):
        # A visible subdir not finished keeps its old index contents.
        payload = {
            "nodes": {
                "root": {"files": {}, "dirs": {"d": "disk"}, "ignore": []},
                "disk": {"files": {}, "dirs": {"sub": "sub"}, "ignore": []},
                "sub": {"files": {"x": "5"}, "dirs": {}, "ignore": []},
            },
            "mounts": {"A": "root"},
            "initial": {"A/d/sub/x": "5"},
            "scans": [{"finish": ["A/d"], "replace": {}}],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIn("A/d/sub/x", result[0]["index"])
        self.assertEqual(result[0]["changed"], {})


if __name__ == "__main__":
    unittest.main()
