def compute(payload):
    """对 start/finish 事件按输入位置给出处理后仍活动的修改 ID 有序列表。"""
    active = []
    result = []
    for ev in payload.get("events", []):
        op = ev.get("op")
        if op == "start":
            active.append(ev["id"])
        elif op == "finish":
            active.remove(ev["id"])
        result.append(list(active))
    return result
