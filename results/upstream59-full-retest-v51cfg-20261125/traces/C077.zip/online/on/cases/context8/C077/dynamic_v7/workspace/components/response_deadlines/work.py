def compute(payload):
    """按 response 位置记录 [原因,到期时间]；失败优先于陈旧，延迟分别为 2000/1000，正常相应用 null。"""
    result = {}
    for i, ev in enumerate(payload.get("events", [])):
        if ev.get("op") != "response":
            continue
        if ev.get("failed"):
            result[str(i)] = ["failure", ev["time"] + 2000]
        elif ev.get("stale") == 1:
            result[str(i)] = ["stale", ev["time"] + 1000]
        else:
            result[str(i)] = None
    return result
