import hashlib

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def _nonce_hex(base_nonce_int, attempt):
    return (base_nonce_int + attempt).to_bytes(12, "big").hex()


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce = int.from_bytes(bytes.fromhex(payload["base_nonce_hex"]), "big")
    max_retries = payload.get("max_retries", 0)
    corrupt_attempts = right  # {label: [attempt numbers]}

    aesgcm = AESGCM(session_key)

    blocks = []
    attempts = []
    notifications = []
    failed_block = None
    file_sha256 = hashlib.sha256()

    global_attempt = 0

    for kind, index, data_hex in left:
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(data_hex)
        aad = label.encode("utf-8")
        corrupt_set = set(corrupt_attempts.get(label, []))

        published = False
        for attempt in range(max_retries + 1):
            nonce = _nonce_hex(base_nonce, global_attempt)
            global_attempt += 1
            ciphertext = aesgcm.encrypt(bytes.fromhex(nonce), plaintext, aad)

            # Simulate transmission bit error: flip last byte's lowest bit.
            if attempt in corrupt_set:
                ct = bytearray(ciphertext)
                ct[-1] ^= 0x01
                ciphertext = bytes(ct)

            verified = False
            try:
                decrypted = aesgcm.decrypt(bytes.fromhex(nonce), ciphertext, aad)
                verified = decrypted == plaintext
            except Exception:
                verified = False

            attempts.append({"block": label, "attempt": attempt, "verified": verified})

            if verified:
                blocks.append({
                    "kind": kind,
                    "index": index,
                    "nonce_hex": nonce,
                    "ciphertext_hex": ciphertext.hex(),
                    "plaintext_sha256": hashlib.sha256(plaintext).hexdigest(),
                })
                if kind == "file":
                    file_sha256.update(plaintext)
                published = True
                break
            else:
                if attempt == 0:
                    notifications.append({"block": label, "error": "verification_failed"})

        if not published:
            failed_block = label
            break

    status = "ok" if failed_block is None else "verification_failed"

    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks,
        "attempts": attempts,
        "notifications": notifications,
        "file_sha256": file_sha256.hexdigest(),
    }
