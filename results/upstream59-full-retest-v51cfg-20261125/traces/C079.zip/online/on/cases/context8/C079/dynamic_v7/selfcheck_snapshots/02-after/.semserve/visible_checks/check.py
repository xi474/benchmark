import unittest

# Injected by the SDK runner; do not import.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception with details dict


class TransformContractTests(unittest.TestCase):
    def test_transform_ok_matches_public_expected(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "61626364656667",
            "max_retries": 1,
            "environment": "production",
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertIsNone(result["failed_block"])
        self.assertEqual(len(result["blocks"]), 3)
        self.assertEqual(result["blocks"][0]["kind"], "file")
        self.assertEqual(result["blocks"][0]["index"], 0)
        self.assertEqual(result["blocks"][0]["nonce_hex"], "000000000000000000000000")
        self.assertEqual(
            result["file_sha256"],
            "7d1a54127b222502f5b79b5fb0803061152a44f92b37e23c6527baf665d4da9a",
        )
        self.assertEqual(result["notifications"], [])

    def test_transform_does_not_mutate_input(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "61626364656667",
            "max_retries": 1,
        }
        snapshot = {k: (list(v) if isinstance(v, list) else v) for k, v in payload.items()}
        call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(payload, snapshot)

    def test_empty_file_no_thumbnail_produces_no_blocks(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "",
            "max_retries": 0,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["blocks"], [])
        self.assertEqual(result["attempts"], [])
        self.assertEqual(
            result["file_sha256"],
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        )

    def test_thumbnail_present_empty_file_still_processed(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "",
            "thumbnail_hex": "00",
            "max_retries": 0,
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(len(result["blocks"]), 1)
        self.assertEqual(result["blocks"][0]["kind"], "thumbnail")
        self.assertEqual(result["blocks"][0]["index"], 0)
        # Thumbnail bytes are not part of the file digest.
        self.assertEqual(
            result["file_sha256"],
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        )

    def test_corrupt_attempt_exhausts_and_stops(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "61626364656667",
            "max_retries": 1,
            "corrupt_attempts": {"file:0": [0, 1]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "verification_failed")
        self.assertEqual(result["failed_block"], "file:0")
        self.assertEqual(result["blocks"], [])
        self.assertEqual(len(result["notifications"]), 1)
        self.assertEqual(result["notifications"][0]["block"], "file:0")
        self.assertEqual(result["notifications"][0]["error"], "verification_failed")
        # No file block succeeded, so digest is empty.
        self.assertEqual(
            result["file_sha256"],
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        )

    def test_corrupt_then_retry_succeeds(self):
        payload = {
            "session_key_hex": "0101010101010101010101010101010101010101010101010101010101010101",
            "base_nonce_hex": "000000000000000000000000",
            "chunk_size": 3,
            "file_hex": "61626364656667",
            "max_retries": 1,
            "corrupt_attempts": {"file:0": [0]},
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["status"], "ok")
        self.assertEqual(len(result["blocks"]), 3)
        # First attempt failed, second succeeded with a new nonce.
        self.assertEqual(result["attempts"][0]["verified"], False)
        self.assertEqual(result["attempts"][1]["verified"], True)
        self.assertEqual(result["blocks"][0]["nonce_hex"], "000000000000000000000001")
        self.assertEqual(len(result["notifications"]), 1)


if __name__ == "__main__":
    unittest.main()
