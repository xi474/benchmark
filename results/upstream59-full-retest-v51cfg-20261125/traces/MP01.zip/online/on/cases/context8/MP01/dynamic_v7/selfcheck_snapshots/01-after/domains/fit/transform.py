import copy
import math


def _is_bool(v):
    return isinstance(v, bool)


def _is_finite_number(v):
    if _is_bool(v):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _require(cond, msg="invalid input"):
    if not cond:
        raise ValueError(msg)


def transform(payloads, contract):
    _require(len(payloads) == len(contract["inputs"]), "payload count mismatch")
    payload = payloads[0]
    _require(isinstance(payload, dict), "payload must be object")

    # When keys are exactly name/result, only result is business input.
    if set(payload.keys()) == {"name", "result"}:
        payload = payload["result"]
    _require(isinstance(payload, dict), "business input must be object")

    classes = payload.get("classes")
    _require(isinstance(classes, list) and len(classes) > 0, "classes required")
    seen = set()
    for c in classes:
        _require(isinstance(c, str) and c.strip() != "", "class must be non-empty string")
        _require(c not in seen, "duplicate class")
        seen.add(c)

    sample_weight = payload.get("sample_weight")
    _require(isinstance(sample_weight, list), "sample_weight required")
    for w in sample_weight:
        _require(_is_finite_number(w) and w >= 0, "sample_weight must be non-negative finite number")

    members = payload.get("members")
    _require(isinstance(members, list), "members required")

    sample_count = len(sample_weight)

    active_members = []
    ids = set()
    for m in members:
        _require(isinstance(m, dict), "member must be object")
        mid = m.get("id")
        _require(isinstance(mid, str) and mid.strip() != "", "member id required")
        _require(mid not in ids, "duplicate member id")
        ids.add(mid)
        active = m.get("active")
        _require(_is_bool(active), "active must be bool")
        if not active:
            continue
        weight = m.get("weight")
        _require(_is_finite_number(weight) and weight >= 0, "member weight must be non-negative finite number")

        predictions = m.get("predictions")
        _require(isinstance(predictions, list) and len(predictions) == sample_count,
                 "predictions length must equal sample count")
        for p in predictions:
            _require(p in classes, "prediction label not in global classes")

        mclasses = m.get("classes")
        _require(isinstance(mclasses, list), "member classes required")
        _require(sorted(mclasses) == sorted(classes), "member classes must be a permutation of global classes")

        probabilities = m.get("probabilities")
        _require(isinstance(probabilities, list) and len(probabilities) == sample_count,
                 "probabilities rows must equal sample count")
        for row in probabilities:
            _require(isinstance(row, list) and len(row) == len(mclasses),
                     "probability row length mismatch")
            for v in row:
                _require(_is_finite_number(v) and v >= 0, "probability must be non-negative finite number")
            _require(abs(sum(row) - 1.0) <= 1e-9, "probability row must sum to 1")

        active_members.append(m)

    _require(len(active_members) >= 1, "at least one active member required")
    total_weight = sum(m["weight"] for m in active_members)
    _require(total_weight > 0, "active member weight sum must be positive")

    out_members = []
    for m in active_members:
        nm = copy.deepcopy(m)
        nm["fit_weight"] = list(sample_weight)
        out_members.append(nm)

    return {
        "name": contract["name"],
        "result": {
            "classes": list(classes),
            "sample_count": sample_count,
            "members": out_members,
        },
    }
