import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts[c['name']] = (cp, c)
    return contracts


def _topo_order(contracts):
    # contracts: name -> (contract_path, contract_dict)
    # Build dependency graph based on inputs that reference other components'
    # outputs. An input path like "outputs/fit.json" depends on component "fit".
    deps = {}
    for name, (cp, c) in contracts.items():
        d = set()
        for inp in c.get('inputs', []):
            p = Path(inp)
            # outputs/<name>.json -> depends on <name>
            if len(p.parts) >= 2 and p.parts[0] == 'outputs':
                dep_name = p.stem
                if dep_name in contracts:
                    d.add(dep_name)
        deps[name] = d

    # Kahn's algorithm
    result = []
    remaining = set(contracts.keys())
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(result)]
        if not ready:
            raise ValueError('dependency cycle or missing dependency')
        ready.sort()
        for n in ready:
            result.append(n)
            remaining.discard(n)
    return result


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError('no contracts')

    order = _topo_order(contracts)

    for name in order:
        cp, c = contracts[name]
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError('missing render.py for %s' % name)
        subprocess.run(
            [sys.executable, str(render_py), str(cp.relative_to(ROOT))],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    # Run integrator
    integrate_py = ROOT / 'integrate.py'
    subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    # Run final report
    final_report_py = ROOT / 'final_report.py'
    subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == '__main__':
    main()
