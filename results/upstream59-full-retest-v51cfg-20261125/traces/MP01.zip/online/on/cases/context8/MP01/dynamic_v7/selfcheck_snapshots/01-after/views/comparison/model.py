import json
import math
from pathlib import Path


def _reject_non_finite(obj):
    if isinstance(obj, float) and not math.isfinite(obj):
        raise ValueError("non-finite number")
    if isinstance(obj, dict):
        for v in obj.values():
            _reject_non_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_non_finite(v)


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except ValueError:
        raise ValueError("invalid JSON")
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _reject_non_finite(data)
    return data
