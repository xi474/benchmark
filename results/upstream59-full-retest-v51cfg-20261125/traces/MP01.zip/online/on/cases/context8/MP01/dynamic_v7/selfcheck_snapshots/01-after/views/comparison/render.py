import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def _write_json(path, obj):
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    Path(path).write_text(text, encoding="utf-8")


def build_component(root, contract_path):
    root = Path(root)
    cp = Path(contract_path)
    contract = load_payload(cp)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
    return result


if __name__ == "__main__":
    here = Path(__file__).resolve()
    root = here.parent.parent.parent
    cp = here.parent / "contract.json"
    contract = load_payload(cp)
    result = build_component(root, cp)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
