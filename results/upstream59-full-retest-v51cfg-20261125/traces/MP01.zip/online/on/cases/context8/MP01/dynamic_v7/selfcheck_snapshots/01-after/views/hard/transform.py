import copy
import math


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _finite(v):
    return _is_number(v) and (not isinstance(v, float) or math.isfinite(v))


def transform(payloads, contract):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    if not isinstance(contract, dict):
        raise ValueError("contract must be a dict")
    inputs = contract.get("inputs")
    if not isinstance(inputs, list) or len(payloads) != len(inputs):
        raise ValueError("payload count must match contract inputs")

    if len(payloads) != 1:
        raise ValueError("hard_vote expects exactly one input")

    payload = payloads[0]
    # Unwrap name/result envelope if present.
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        data = payload["result"]
    else:
        data = payload

    if not isinstance(data, dict):
        raise ValueError("fit result must be an object")

    classes = data.get("classes")
    members = data.get("members")
    if not isinstance(classes, list) or not classes:
        raise ValueError("classes must be a non-empty list")
    if not all(isinstance(c, str) and c.strip() for c in classes):
        raise ValueError("classes must be non-empty strings")
    if len(set(classes)) != len(classes):
        raise ValueError("classes must be unique")
    if not isinstance(members, list) or not members:
        raise ValueError("members must be a non-empty list")

    sample_count = data.get("sample_count")
    if not _finite(sample_count) or int(sample_count) != sample_count:
        raise ValueError("sample_count must be an integer")
    sample_count = int(sample_count)

    n_classes = len(classes)
    class_index = {c: i for i, c in enumerate(classes)}

    # scores[sample][class_index] = accumulated weighted votes
    scores = [[0.0] * n_classes for _ in range(sample_count)]

    for member in members:
        if not isinstance(member, dict):
            raise ValueError("member must be an object")
        weight = member.get("weight")
        if not _finite(weight) or weight < 0:
            raise ValueError("member weight must be non-negative")
        predictions = member.get("predictions")
        if not isinstance(predictions, list) or len(predictions) != sample_count:
            raise ValueError("member predictions length mismatch")
        for s, label in enumerate(predictions):
            if label not in class_index:
                raise ValueError("prediction label not in global classes")
            scores[s][class_index[label]] += weight

    predictions = []
    for s in range(sample_count):
        best = max(scores[s])
        # tie-break by global classes order
        for i in range(n_classes):
            if scores[s][i] == best:
                predictions.append(classes[i])
                break

    return {"name": contract["name"], "result": {"predictions": predictions, "scores": scores}}
