import copy
import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _unwrap(payload):
    # When an input object has keys exactly name/result, only its result is
    # the business input; other objects are interpreted as-is.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    if not isinstance(contract, dict) or contract.get("name") is None:
        raise ValueError("bad contract")

    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("fit result must be an object")

    classes = data.get("classes")
    members = data.get("members")
    if not isinstance(classes, list) or not isinstance(members, list):
        raise ValueError("missing classes/members")

    # classes: unique non-empty strings
    seen = set()
    for c in classes:
        if not isinstance(c, str) or not c.strip():
            raise ValueError("invalid class")
        if c in seen:
            raise ValueError("duplicate class")
        seen.add(c)

    sample_count = data.get("sample_count")
    if not _is_finite_number(sample_count) or int(sample_count) != sample_count or sample_count < 0:
        raise ValueError("invalid sample_count")

    n = int(sample_count)
    n_classes = len(classes)
    class_index = {c: i for i, c in enumerate(classes)}

    # Accumulate weighted probabilities per sample across members.
    totals = [[0.0] * n_classes for _ in range(n)]

    for m in members:
        if not isinstance(m, dict):
            raise ValueError("member must be object")
        weight = m.get("weight")
        if not _is_finite_number(weight) or weight < 0:
            raise ValueError("invalid member weight")
        m_classes = m.get("classes")
        probs = m.get("probabilities")
        if not isinstance(m_classes, list) or not isinstance(probs, list):
            raise ValueError("member missing classes/probabilities")
        if len(m_classes) != n_classes:
            raise ValueError("member classes must be a permutation of global classes")
        if sorted(m_classes) != sorted(classes):
            raise ValueError("member classes must be a permutation of global classes")
        if len(probs) != n:
            raise ValueError("member probabilities length mismatch")
        # map member class column -> global index
        col_to_global = [class_index[c] for c in m_classes]
        for s in range(n):
            row = probs[s]
            if not isinstance(row, list) or len(row) != n_classes:
                raise ValueError("probability row size mismatch")
            row_sum = 0.0
            for v in row:
                if not _is_finite_number(v) or v < 0:
                    raise ValueError("invalid probability")
                row_sum += v
            if abs(row_sum - 1.0) > 1e-9:
                raise ValueError("probability row does not sum to 1")
            for col, g in enumerate(col_to_global):
                totals[s][g] += weight * row[col]

    predictions = []
    probabilities = []
    for s in range(n):
        row = totals[s]
        best = max(row)
        # tie-break by global classes order
        pred_idx = next(i for i, v in enumerate(row) if v == best)
        predictions.append(classes[pred_idx])
        probabilities.append(row)

    return {"name": contract["name"], "result": {"predictions": predictions, "probabilities": probabilities}}
