import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/fit/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError。",
            },
        },
    },
    {
        "target_path": "views/hard/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError。",
            },
        },
    },
    {
        "target_path": "views/soft/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError。",
            },
        },
    },
    {
        "target_path": "views/comparison/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError。",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_fit_boundary(self):
        check_api_boundary("domains/fit/transform.py", rule="nonfinite_unknown_field",
                           contract_path="README.md",
                           requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                           args=[[{"classes": ["red", "blue"], "sample_weight": [1],
                                   "members": [{"id": "a", "active": True, "weight": 1,
                                                "predictions": ["red"],
                                                "classes": ["red", "blue"],
                                                "probabilities": [[0.5, 0.5]]}]}],
                                 {"name": "fit", "operation": "fit_members",
                                  "inputs": ["x"], "output": "y"}])
        check_api_boundary("domains/fit/transform.py", rule="invalid_payload_type",
                           contract_path="README.md",
                           requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError。",
                           args=[[{"classes": ["red", "blue"], "sample_weight": [1],
                                   "members": [{"id": "a", "active": True, "weight": 1,
                                                "predictions": ["red"],
                                                "classes": ["red", "blue"],
                                                "probabilities": [[0.5, 0.5]]}]}],
                                 {"name": "fit", "operation": "fit_members",
                                  "inputs": ["x"], "output": "y"}])

    def test_hard_boundary(self):
        check_api_boundary("views/hard/transform.py", rule="nonfinite_unknown_field",
                           contract_path="README.md",
                           requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                           args=[[{"classes": ["red", "blue"], "sample_count": 1,
                                   "members": [{"weight": 1, "predictions": ["red"]}]}],
                                 {"name": "hard", "operation": "hard_vote",
                                  "inputs": ["x"], "output": "y"}])
        check_api_boundary("views/hard/transform.py", rule="invalid_payload_type",
                           contract_path="README.md",
                           requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError。",
                           args=[[{"classes": ["red", "blue"], "sample_count": 1,
                                   "members": [{"weight": 1, "predictions": ["red"]}]}],
                                 {"name": "hard", "operation": "hard_vote",
                                  "inputs": ["x"], "output": "y"}])

    def test_soft_boundary(self):
        check_api_boundary("views/soft/transform.py", rule="nonfinite_unknown_field",
                           contract_path="README.md",
                           requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                           args=[[{"classes": ["red", "blue"], "sample_count": 1,
                                   "members": [{"weight": 1, "classes": ["red", "blue"],
                                                "probabilities": [[0.5, 0.5]]}]}],
                                 {"name": "soft", "operation": "soft_vote",
                                  "inputs": ["x"], "output": "y"}])
        check_api_boundary("views/soft/transform.py", rule="invalid_payload_type",
                           contract_path="README.md",
                           requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError。",
                           args=[[{"classes": ["red", "blue"], "sample_count": 1,
                                   "members": [{"weight": 1, "classes": ["red", "blue"],
                                                "probabilities": [[0.5, 0.5]]}]}],
                                 {"name": "soft", "operation": "soft_vote",
                                  "inputs": ["x"], "output": "y"}])

    def test_comparison_boundary(self):
        check_api_boundary("views/comparison/transform.py", rule="nonfinite_unknown_field",
                           contract_path="README.md",
                           requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                           args=[[{"predictions": ["red"]}, {"predictions": ["red"]}],
                                 {"name": "comparison", "operation": "vote_comparison",
                                  "inputs": ["x", "y"], "output": "z"}])
        check_api_boundary("views/comparison/transform.py", rule="invalid_payload_type",
                           contract_path="README.md",
                           requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError。",
                           args=[[{"predictions": ["red"]}, {"predictions": ["red"]}],
                                 {"name": "comparison", "operation": "vote_comparison",
                                  "inputs": ["x", "y"], "output": "z"}])


class TestFitMembers(unittest.TestCase):
    def test_fit_weight_forwarding_and_inactive_filter(self):
        payload = {
            "classes": ["red", "blue"],
            "sample_weight": [1, 2, 0],
            "members": [
                {"id": "a", "active": True, "weight": 1,
                 "predictions": ["red", "blue", "red"],
                 "classes": ["red", "blue"],
                 "probabilities": [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]},
                {"id": "b", "active": False},
                {"id": "c", "active": True, "weight": 2,
                 "predictions": ["blue", "red", "blue"],
                 "classes": ["blue", "red"],
                 "probabilities": [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]},
            ],
        }
        contract = {"name": "fit", "operation": "fit_members", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/fit/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "fit")
        r = result["result"]
        self.assertEqual(r["classes"], ["red", "blue"])
        self.assertEqual(r["sample_count"], 3)
        self.assertEqual([m["id"] for m in r["members"]], ["a", "c"])
        for m in r["members"]:
            self.assertEqual(m["fit_weight"], [1, 2, 0])

    def test_inactive_member_ignores_bad_fields(self):
        payload = {
            "classes": ["red", "blue"],
            "sample_weight": [1],
            "members": [
                {"id": "a", "active": True, "weight": 1,
                 "predictions": ["red"], "classes": ["red", "blue"],
                 "probabilities": [[0.5, 0.5]]},
                {"id": "b", "active": False, "weight": -5,
                 "predictions": ["nope"], "classes": ["x"],
                 "probabilities": [[1.0, 2.0]]},
            ],
        }
        contract = {"name": "fit", "operation": "fit_members", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/fit/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual([m["id"] for m in result["result"]["members"]], ["a"])


class TestHardVote(unittest.TestCase):
    def test_weighted_tally_and_tie_break(self):
        fit = {
            "classes": ["red", "blue"],
            "sample_count": 2,
            "members": [
                {"weight": 1, "predictions": ["red", "blue"]},
                {"weight": 1, "predictions": ["blue", "red"]},
            ],
        }
        contract = {"name": "hard", "operation": "hard_vote", "inputs": ["x"], "output": "y"}
        result = call_candidate("views/hard/transform.py", "transform",
                                args=[[fit], contract])
        r = result["result"]
        # sample 0: red=1, blue=1 -> tie -> red (global order)
        # sample 1: red=1, blue=1 -> tie -> red
        self.assertEqual(r["predictions"], ["red", "red"])
        self.assertEqual(r["scores"], [[1.0, 1.0], [1.0, 1.0]])


class TestSoftVote(unittest.TestCase):
    def test_class_mapping_and_weighted_average(self):
        fit = {
            "classes": ["red", "blue"],
            "sample_count": 1,
            "members": [
                {"weight": 1, "classes": ["blue", "red"],
                 "probabilities": [[0.8, 0.2]]},
                {"weight": 1, "classes": ["red", "blue"],
                 "probabilities": [[0.1, 0.9]]},
            ],
        }
        contract = {"name": "soft", "operation": "soft_vote", "inputs": ["x"], "output": "y"}
        result = call_candidate("views/soft/transform.py", "transform",
                                args=[[fit], contract])
        r = result["result"]
        # member1: blue=0.8, red=0.2 ; member2: red=0.1, blue=0.9
        # red total = 0.2 + 0.1 = 0.3 ; blue total = 0.8 + 0.9 = 1.7
        self.assertAlmostEqual(r["probabilities"][0][0], 0.3)
        self.assertAlmostEqual(r["probabilities"][0][1], 1.7)
        self.assertEqual(r["predictions"], ["blue"])


class TestComparison(unittest.TestCase):
    def test_disagreement_indices(self):
        hard = {"predictions": ["red", "blue", "red"]}
        soft = {"predictions": ["red", "red", "red"]}
        contract = {"name": "comparison", "operation": "vote_comparison",
                    "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("views/comparison/transform.py", "transform",
                                args=[[hard, soft], contract])
        r = result["result"]
        self.assertEqual(r["hard"], ["red", "blue", "red"])
        self.assertEqual(r["soft"], ["red", "red", "red"])
        self.assertEqual(r["disagreements"], [1])

    def test_sample_count_mismatch_raises(self):
        hard = {"predictions": ["red", "blue"]}
        soft = {"predictions": ["red"]}
        contract = {"name": "comparison", "operation": "vote_comparison",
                    "inputs": ["x", "y"], "output": "z"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("views/comparison/transform.py", "transform",
                           args=[[hard, soft], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
