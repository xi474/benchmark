import math


def _is_finite_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _check_finite_json(v):
    if isinstance(v, float) and not math.isfinite(v):
        raise ValueError("non-finite number")
    if isinstance(v, dict):
        for k, val in v.items():
            _check_finite_json(val)
    elif isinstance(v, list):
        for val in v:
            _check_finite_json(val)


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    if not isinstance(contract, dict) or "name" not in contract:
        raise ValueError("bad contract")

    payload = payloads[0]
    # unwrap name/result envelope if present
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    pieces = payload.get("pieces")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be list")

    # merge attrs
    merged = {}
    conflicts = set()
    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be object")
        attrs = piece.get("attrs")
        if attrs is None:
            continue
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be object")
        for k, v in attrs.items():
            if k in merged:
                if merged[k] != v:
                    conflicts.add(k)
            else:
                merged[k] = v

    policy = payload.get("attribute_policy")
    if policy == "first":
        # first occurrence wins; conflicts list still reports differing keys
        merged = {}
        for piece in pieces:
            attrs = piece.get("attrs")
            if not isinstance(attrs, dict):
                continue
            for k, v in attrs.items():
                if k not in merged:
                    merged[k] = v
    elif policy == "drop_conflicts":
        merged = {k: v for k, v in merged.items() if k not in conflicts}
    else:
        raise ValueError("invalid attribute_policy")

    result = {
        "attrs": merged,
        "conflicts": sorted(conflicts),
    }
    return {"name": contract["name"], "result": result}
