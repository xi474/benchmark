import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _unwrap(payload):
    # When an input object has keys exactly name/result, only its result is
    # business input; other objects are interpreted as-is.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    if not isinstance(contract, dict):
        raise ValueError("contract must be a dict")
    if "name" not in contract:
        raise ValueError("contract missing name")
    if "inputs" not in contract or not isinstance(contract["inputs"], list):
        raise ValueError("contract missing inputs")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = _unwrap(payloads[0])
    if not isinstance(payload, dict):
        raise ValueError("input must be an object")

    columns = payload.get("columns")
    pieces = payload.get("pieces")
    attribute_policy = payload.get("attribute_policy")

    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if not isinstance(attribute_policy, str):
        raise ValueError("attribute_policy must be a string")
    if attribute_policy not in ("drop_conflicts", "first"):
        raise ValueError("invalid attribute_policy")

    # columns: unique column names
    seen_cols = set()
    for col in columns:
        if not isinstance(col, str):
            raise ValueError("column name must be a string")
        if col in seen_cols:
            raise ValueError("duplicate column name")
        seen_cols.add(col)

    # pieces validation
    piece_ids = set()
    all_coords = set()
    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be an object")
        pid = piece.get("id")
        if not isinstance(pid, str):
            raise ValueError("piece id must be a string")
        if pid in piece_ids:
            raise ValueError("duplicate piece id")
        piece_ids.add(pid)

        coords = piece.get("coordinates")
        if not isinstance(coords, list):
            raise ValueError("coordinates must be a list")
        for c in coords:
            if not _is_finite_number(c):
                raise ValueError("coordinate must be a finite number")
            if c in all_coords:
                raise ValueError("overlapping coordinate")
            all_coords.add(c)

        data = piece.get("data")
        if not isinstance(data, list):
            raise ValueError("data must be a list")
        if len(data) != len(coords):
            raise ValueError("data rows must match coordinates")
        for row in data:
            if not isinstance(row, list):
                raise ValueError("data row must be a list")
            if len(row) != len(columns):
                raise ValueError("data row width must match columns")
            for v in row:
                if not _is_finite_number(v):
                    raise ValueError("data value must be a finite number")

        attrs = piece.get("attrs")
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be an object")

    # Build order sorted by coordinate ascending
    entries = []
    for piece in pieces:
        for row, coord in enumerate(piece["coordinates"]):
            entries.append((coord, piece["id"], row))
    entries.sort(key=lambda e: e[0])

    order = [
        {"coordinate": coord, "piece": pid, "row": row}
        for coord, pid, row in entries
    ]

    return {"name": contract["name"], "result": {"columns": columns, "order": order}}
