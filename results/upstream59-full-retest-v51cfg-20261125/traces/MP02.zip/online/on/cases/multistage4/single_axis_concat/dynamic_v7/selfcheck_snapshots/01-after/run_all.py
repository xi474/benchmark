import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _contracts():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    return contracts


def _topo_order(contracts):
    # Build dependency order from contract inputs that reference other
    # component outputs (outputs/*.json).
    by_output = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        by_output[c['output']] = cp

    order = []
    visited = set()
    visiting = set()

    def visit(cp):
        if cp in visited:
            return
        if cp in visiting:
            raise ValueError('cycle detected in component dependencies')
        visiting.add(cp)
        c = json.loads(cp.read_text(encoding='utf-8'))
        for inp in c.get('inputs', []):
            dep = by_output.get(inp)
            if dep is not None and dep != cp:
                visit(dep)
        visiting.discard(cp)
        visited.add(cp)
        order.append(cp)

    for cp in contracts:
        visit(cp)
    return order


def main():
    contracts = _contracts()
    if not contracts:
        raise ValueError('no contracts')

    order = _topo_order(contracts)

    for cp in order:
        render = cp.with_name('render.py')
        if not render.is_file():
            raise ValueError('missing render.py for %s' % cp)
        subprocess.run([sys.executable, str(render)], cwd=ROOT, check=True)

    # Integrate all component outputs into core manifest.
    import integrate
    integrate.main()

    # Produce final report.
    import final_report
    final_report.main()


if __name__ == '__main__':
    main()
