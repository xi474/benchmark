import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _unwrap(payload):
    # When an input object has keys exactly name/result, only its result is
    # business input; other objects are interpreted as-is.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    if not isinstance(contract, dict):
        raise ValueError("contract must be a dict")
    if "name" not in contract:
        raise ValueError("contract missing name")
    if "inputs" not in contract or not isinstance(contract["inputs"], list):
        raise ValueError("contract missing inputs")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    raw = _unwrap(payloads[0])
    index = _unwrap(payloads[1])
    attributes = _unwrap(payloads[2])

    if not isinstance(raw, dict):
        raise ValueError("raw input must be an object")
    if not isinstance(index, dict):
        raise ValueError("index input must be an object")
    if not isinstance(attributes, dict):
        raise ValueError("attributes input must be an object")

    columns = raw.get("columns")
    pieces = raw.get("pieces")
    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")

    order = index.get("order")
    if not isinstance(order, list):
        raise ValueError("index order must be a list")

    # Map piece id -> piece for fast lookup.
    piece_by_id = {}
    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be an object")
        pid = piece.get("id")
        if not isinstance(pid, str):
            raise ValueError("piece id must be a string")
        piece_by_id[pid] = piece

    coordinates = []
    data = []
    for entry in order:
        if not isinstance(entry, dict):
            raise ValueError("order entry must be an object")
        coord = entry.get("coordinate")
        pid = entry.get("piece")
        row = entry.get("row")
        if not _is_finite_number(coord):
            raise ValueError("coordinate must be a finite number")
        if not isinstance(pid, str):
            raise ValueError("piece must be a string")
        if not isinstance(row, int) or isinstance(row, bool):
            raise ValueError("row must be an integer")
        piece = piece_by_id.get(pid)
        if piece is None:
            raise ValueError("unknown piece id")
        piece_data = piece.get("data")
        if not isinstance(piece_data, list) or row < 0 or row >= len(piece_data):
            raise ValueError("row out of range")
        coordinates.append(coord)
        data.append(piece_data[row])

    attrs = attributes.get("attrs")
    attribute_conflicts = attributes.get("conflicts")
    if not isinstance(attrs, dict):
        raise ValueError("attrs must be an object")
    if not isinstance(attribute_conflicts, list):
        raise ValueError("conflicts must be a list")

    result = {
        "coordinates": coordinates,
        "columns": columns,
        "data": data,
        "attrs": attrs,
        "attribute_conflicts": attribute_conflicts,
    }
    return {"name": contract["name"], "result": result}
