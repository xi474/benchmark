def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if "aix" not in payload:
        raise ValueError("missing aix")
    text = payload["aix"]
    if not isinstance(text, str):
        raise ValueError("aix must be string")

    records = []
    current = None  # dict with mount, dev, vfs, options, seen keys

    def flush():
        nonlocal current
        if current is None:
            return
        if "dev" not in current:
            raise ValueError("missing device")
        records.append({
            "device": current["dev"],
            "mount": current["mount"],
            "fstype": current.get("vfs", "jfs2"),
            "options": current.get("options", "rw"),
        })
        current = None

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if not raw.startswith((" ", "\t")):
            # section header: "mountpoint:"
            flush()
            if not line.endswith(":"):
                raise ValueError("bad section header")
            mount = line[:-1].strip()
            if not mount:
                raise ValueError("empty mount")
            current = {"mount": mount, "seen": set()}
            continue
        if current is None:
            raise ValueError("attribute without section header")
        if "=" not in line:
            raise ValueError("bad attribute line")
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if key not in ("dev", "vfs", "options"):
            raise ValueError("unknown key: %s" % key)
        if key in current["seen"]:
            raise ValueError("duplicate key: %s" % key)
        current["seen"].add(key)
        current[key] = value

    flush()

    return {"name": contract["name"], "result": {"records": records}}
