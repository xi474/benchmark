import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all component contracts (excluding outputs dir).
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts")

    # Topologically order by input dependencies on other component outputs.
    # Build name -> contract path map.
    name_to_cp = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name_to_cp[c["name"]] = cp

    # Determine dependencies: an input path that equals another component's
    # output means that component must run first.
    output_to_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        output_to_name[c["output"]] = c["name"]

    deps = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        d = set()
        for inp in c["inputs"]:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[c["name"]] = d

    # Topological sort (Kahn's algorithm).
    order = []
    remaining = set(deps)
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError("dependency cycle detected")
        ready.sort()
        for n in ready:
            order.append(n)
            remaining.discard(n)

    # Execute each component's render.py CLI.
    for name in order:
        cp = name_to_cp[name]
        render = cp.with_name("render.py")
        if not render.is_file():
            raise ValueError("missing render.py for %s" % name)
        subprocess.run(
            [sys.executable, str(render), str(ROOT), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    # Run the integrator.
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    # Run the final report.
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
