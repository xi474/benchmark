import unittest

from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/fstab/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/aix/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/mount/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/merged/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestApiBoundaries(unittest.TestCase):
    def test_transform_api_boundaries(self):
        seeds = {
            "domains/fstab/transform.py": [[{"fstab": ""}], {"name": "fstab", "inputs": ["x"], "operation": "fstab_parse"}],
            "domains/aix/transform.py": [[{"aix": ""}], {"name": "aix", "inputs": ["x"], "operation": "aix_parse"}],
            "domains/mount/transform.py": [[{"mount": ""}], {"name": "mount", "inputs": ["x"], "operation": "mount_parse"}],
            "views/merged/transform.py": [
                [
                    {"name": "fstab", "result": {"records": []}},
                    {"name": "aix", "result": {"records": []}},
                    {"name": "mount", "result": {"records": []}},
                ],
                {"name": "merged", "inputs": ["a", "b", "c"], "operation": "mount_merge"},
            ],
        }
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=req["target_path"], rule=rule):
                    check_api_boundary(
                        req["target_path"],
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=seeds[req["target_path"]],
                    )


class TestFstabBehavior(unittest.TestCase):
    def test_fstab_parse_columns_and_escape(self):
        payload = {"fstab": "# c\n/dev/a /mnt ext4 rw,nosuid 0 2\n/dev/b /with\\040space xfs ro\n"}
        contract = {"name": "fstab", "operation": "fstab_parse", "inputs": ["x"]}
        result = call_candidate("domains/fstab/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "fstab")
        records = result["result"]["records"]
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]["device"], "/dev/a")
        self.assertEqual(records[0]["options"], ["nosuid", "rw"])
        self.assertEqual(records[1]["mount"], "/with space")
        self.assertEqual(records[1]["options"], ["ro"])


class TestAixBehavior(unittest.TestCase):
    def test_aix_parse_defaults(self):
        payload = {"aix": "/data:\n  dev = /dev/a\n/backup:\n  dev = /dev/b\n  vfs = jfs\n"}
        contract = {"name": "aix", "operation": "aix_parse", "inputs": ["x"]}
        result = call_candidate("domains/aix/transform.py", "transform", args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]["fstype"], "jfs2")
        self.assertEqual(records[0]["options"], "rw")
        self.assertEqual(records[1]["fstype"], "jfs")
        self.assertEqual(records[1]["mount"], "/backup")


class TestMountBehavior(unittest.TestCase):
    def test_mount_parse_syntax(self):
        payload = {"mount": "/dev/live on /data type ext4 (rw,relatime)\n"}
        contract = {"name": "mount", "operation": "mount_parse", "inputs": ["x"]}
        result = call_candidate("domains/mount/transform.py", "transform", args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["device"], "/dev/live")
        self.assertEqual(records[0]["fstype"], "ext4")
        self.assertEqual(records[0]["options"], ["relatime", "rw"])


class TestMergedBehavior(unittest.TestCase):
    def test_merge_priority_and_conflict(self):
        fstab = {"name": "fstab", "result": {"records": [
            {"device": "/dev/f", "mount": "/m", "fstype": "ext4", "options": ["rw"]},
        ]}}
        aix = {"name": "aix", "result": {"records": [
            {"device": "/dev/a", "mount": "/m", "fstype": "jfs2", "options": "rw"},
        ]}}
        mount = {"name": "mount", "result": {"records": [
            {"device": "/dev/m", "mount": "/m", "fstype": "ext4", "options": ["rw"]},
        ]}}
        contract = {"name": "merged", "operation": "mount_merge", "inputs": ["a", "b", "c"]}
        result = call_candidate("views/merged/transform.py", "transform", args=[[fstab, aix, mount], contract])
        records = result["result"]["records"]
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["source"], "fstab")
        self.assertEqual(records[0]["device"], "/dev/f")
        conflicts = result["result"]["conflicts"]
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["mount"], "/m")
        self.assertEqual(len(conflicts[0]["evidence"]), 3)


if __name__ == "__main__":
    unittest.main()
