import re


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    _reject_nonfinite(payload)
    if "mount" not in payload:
        raise ValueError("missing mount")
    text = payload["mount"]
    if not isinstance(text, str):
        raise ValueError("mount must be str")

    records = []
    for raw in text.split("\n"):
        line = raw.strip()
        if line == "":
            continue
        records.append(_parse_line(line))

    return {"name": contract["name"], "result": {"records": records}}


_LINE_RE = re.compile(
    r"^(?P<device>\S+) on (?P<mountpoint>\S+) type (?P<fstype>\S+) "
    r"\((?P<options>[^)]*)\)$"
)


def _parse_line(line):
    m = _LINE_RE.match(line)
    if m is None:
        raise ValueError("invalid mount line")
    device = _unescape(m.group("device"))
    mountpoint = _unescape(m.group("mountpoint"))
    fstype = m.group("fstype")
    options_raw = m.group("options")
    if options_raw == "":
        raise ValueError("empty options")
    options = _split_options(options_raw)
    return {
        "device": device,
        "mount": mountpoint,
        "fstype": fstype,
        "options": options,
    }


def _unescape(s):
    return s.replace("\\040", " ").replace("\\011", "\t").replace("\\134", "\\")


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if obj != obj or obj in (float("inf"), float("-inf")):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _split_options(raw):
    parts = [p.strip() for p in raw.split(",")]
    if any(p == "" for p in parts):
        raise ValueError("empty option")
    seen = set()
    out = []
    for p in parts:
        if p in seen:
            continue
        seen.add(p)
        out.append(p)
    out.sort()
    return out
