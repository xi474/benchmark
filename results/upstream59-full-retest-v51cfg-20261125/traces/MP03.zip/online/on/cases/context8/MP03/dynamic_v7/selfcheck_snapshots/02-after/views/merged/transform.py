def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    sources = []
    for payload in payloads:
        if isinstance(payload, dict) and set(payload) == {"name", "result"}:
            payload = payload["result"]
        if not isinstance(payload, dict) or "records" not in payload:
            raise ValueError("bad parse result")
        _reject_nonfinite(payload)
        records = payload["records"]
        if not isinstance(records, list):
            raise ValueError("records must be list")
        sources.append(records)

    # source priority: fstab(0), aix(1), mount(2)
    source_names = ["fstab", "aix", "mount"]

    # group records by mount, preserving source priority then record order
    by_mount = {}
    for si, records in enumerate(sources):
        for rec in records:
            if not isinstance(rec, dict) or "mount" not in rec:
                raise ValueError("bad record")
            mount = rec["mount"]
            by_mount.setdefault(mount, []).append((si, rec))

    winners = []
    conflicts = []
    for mount in sorted(by_mount.keys()):
        entries = by_mount[mount]
        winner = entries[0][1]
        winner_rec = dict(winner)
        winner_rec["source"] = source_names[entries[0][0]]
        winners.append(winner_rec)

        # conflict if any record differs in device/fstype/options
        base = (winner.get("device"), winner.get("fstype"), winner.get("options"))
        evidence = []
        for si, rec in entries:
            evidence.append(dict(rec, source=source_names[si]))
        if any(
            (rec.get("device"), rec.get("fstype"), rec.get("options")) != base
            for _, rec in entries
        ):
            conflicts.append({"mount": mount, "evidence": evidence})

    return {
        "name": contract["name"],
        "result": {"records": winners, "conflicts": conflicts},
    }


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if obj != obj or obj in (float("inf"), float("-inf")):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)
