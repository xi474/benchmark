import csv
import io
import re


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    csv_text = payload.get('csv_text')
    if csv_text is None:
        raise ValueError('missing csv_text')
    if not isinstance(csv_text, str):
        raise ValueError('csv_text must be str')

    records = _parse_csv(csv_text)
    return {'name': contract['name'], 'result': {'records': records}}


def _parse_csv(csv_text):
    if csv_text == '':
        return []
    reader = csv.reader(io.StringIO(csv_text))
    rows = list(reader)
    if not rows:
        return []
    header = rows[0]
    if len(set(header)) != len(header):
        raise ValueError('duplicate columns')
    if 'id' not in header and 'user_id' not in header:
        raise ValueError('missing id column')

    id_col = 'id' if 'id' in header else 'user_id'
    # column names must be unique and no extra columns beyond known set
    known = {'id', 'user_id', 'name', 'full_name', 'email', 'mail', 'joined', 'joined_at'}
    for col in header:
        if col not in known:
            raise ValueError('extra column: %s' % col)

    merged = {}
    order = []
    for row in rows[1:]:
        if len(row) != len(header):
            raise ValueError('row width mismatch')
        rec = dict(zip(header, row))
        id_val = rec.get(id_col)
        if id_val is None or id_val == '':
            continue
        uid = _normalize_id(id_val)
        if uid not in merged:
            merged[uid] = {}
            order.append(uid)
        target = merged[uid]
        _apply_fields(target, rec)

    result = []
    for uid in sorted(merged):
        entry = {'id': uid}
        for k in ('name', 'email', 'joined'):
            if k in merged[uid]:
                entry[k] = merged[uid][k]
        result.append(entry)
    return result


def _normalize_id(val):
    if isinstance(val, bool):
        raise ValueError('id cannot be bool')
    if isinstance(val, int):
        return str(val)
    if isinstance(val, str):
        s = val.strip()
        if s == '':
            raise ValueError('id cannot be empty')
        return s
    raise ValueError('id must be str or int')


def _apply_fields(target, rec):
    # name/full_name
    name = _first_present(rec, 'name', 'full_name')
    if name is not None:
        target['name'] = name
    email = _first_present(rec, 'email', 'mail')
    if email is not None:
        target['email'] = email
    joined = _first_present(rec, 'joined', 'joined_at')
    if joined is not None:
        target['joined'] = _normalize_joined(joined)


def _first_present(rec, *keys):
    for k in keys:
        if k in rec and rec[k] != '':
            return rec[k]
    return None


def _normalize_joined(val):
    if val == '':
        return None
    m = re.fullmatch(r'\d{4}-\d{2}-\d{2}', val)
    if m:
        return val
    m = re.fullmatch(r'\d{2}/\d{2}/\d{4}', val)
    if m:
        d, mo, y = val.split('/')
        return '%s-%s-%s' % (y, mo, d)
    raise ValueError('invalid joined date: %s' % val)
