import json
from datetime import datetime


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    if 'json_text' not in payload:
        raise ValueError('missing json_text')
    json_text = payload['json_text']
    if not isinstance(json_text, str):
        raise ValueError('json_text must be str')
    try:
        arr = json.loads(json_text, parse_constant=_reject_constant)
    except ValueError:
        raise
    if not isinstance(arr, list):
        raise ValueError('json_text must be an array')
    users = {}
    for item in arr:
        if not isinstance(item, dict):
            raise ValueError('each element must be object')
        uid = _extract_id(item)
        rec = users.setdefault(uid, {'id': uid})
        _apply_field(rec, item, 'name', 'full_name', 'name')
        _apply_field(rec, item, 'email', 'mail', 'email')
        _apply_field(rec, item, 'joined', 'joined_at', 'joined')
    records = [users[k] for k in sorted(users, key=lambda s: s)]
    return {'name': contract['name'], 'result': {'records': records}}


def _reject_constant(value):
    raise ValueError('non-finite number not allowed')


def _extract_id(item):
    if 'id' not in item:
        raise ValueError('missing id')
    uid = item['id']
    if isinstance(uid, bool):
        raise ValueError('id cannot be bool')
    if isinstance(uid, int):
        return str(uid)
    if isinstance(uid, str):
        return uid.strip()
    raise ValueError('id must be str or int')


def _apply_field(rec, item, new_key, old_key, out_key):
    value = None
    if new_key in item and item[new_key] is not None:
        value = item[new_key]
    elif old_key in item and item[old_key] is not None:
        value = item[old_key]
    if value is None:
        return
    if out_key == 'joined':
        value = _normalize_joined(value)
    rec[out_key] = value


def _normalize_joined(value):
    if not isinstance(value, str):
        raise ValueError('joined must be str')
    if value == '':
        return value
    for fmt in ('%Y-%m-%d', '%d/%m/%Y'):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            continue
    raise ValueError('invalid joined format')
