import json
import re


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    jsonl_text = payload.get('jsonl_text')
    if jsonl_text is None:
        raise ValueError('missing jsonl_text')
    if not isinstance(jsonl_text, str):
        raise ValueError('jsonl_text must be str')

    records = {}
    for line in jsonl_text.split('\n'):
        if line.strip() == '':
            continue
        try:
            obj = json.loads(line, parse_constant=_reject_constant)
        except ValueError:
            raise ValueError('bad JSON line')
        if not isinstance(obj, dict):
            raise ValueError('each line must be an object')
        _merge(records, obj)

    out = [records[k] for k in sorted(records, key=lambda s: s)]
    return {'name': contract['name'], 'result': {'records': out}}


def _reject_constant(value):
    raise ValueError('non-finite number not allowed')


def _merge(records, obj):
    uid = obj.get('id')
    if uid is None:
        raise ValueError('missing id')
    if isinstance(uid, bool) or not isinstance(uid, (str, int)):
        raise ValueError('id must be str or int')
    key = uid.strip() if isinstance(uid, str) else str(uid)
    if key == '':
        raise ValueError('id must be non-empty')

    rec = records.get(key)
    if rec is None:
        rec = {'id': key}
        records[key] = rec

    for src, dst in (('name', 'name'), ('full_name', 'name'),
                     ('email', 'email'), ('mail', 'email'),
                     ('joined', 'joined'), ('joined_at', 'joined')):
        if src in obj:
            v = obj[src]
            if v is None:
                continue
            if dst == 'joined':
                v = _normalize_joined(v)
            rec[dst] = v


def _normalize_joined(v):
    if not isinstance(v, str):
        raise ValueError('joined must be str')
    if v == '':
        return v
    m = re.fullmatch(r'\d{4}-\d{2}-\d{2}', v)
    if m:
        return v
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', v)
    if m:
        return f'{m.group(3)}-{m.group(2)}-{m.group(1)}'
    raise ValueError('invalid joined format')
