import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Locate all component contracts (excluding outputs).
    contracts = sorted(ROOT.rglob('contract.json'))
    contracts = [c for c in contracts if 'outputs' not in c.relative_to(ROOT).parts]

    # Topological order: domains first, then views (which consume domain outputs).
    def order_key(cp):
        rel = cp.relative_to(ROOT)
        parts = rel.parts
        if parts and parts[0] == 'views':
            return (1, str(rel))
        return (0, str(rel))

    contracts.sort(key=order_key)

    for cp in contracts:
        render = cp.with_name('render.py')
        subprocess.run([sys.executable, str(render)], cwd=ROOT, check=True)

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
