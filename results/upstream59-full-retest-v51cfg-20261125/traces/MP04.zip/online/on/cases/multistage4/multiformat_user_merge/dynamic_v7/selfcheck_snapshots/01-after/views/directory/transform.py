def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')

    sources = ['json', 'csv', 'jsonl']
    records_by_source = []
    for i, payload in enumerate(payloads):
        if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
            payload = payload['result']
        if not isinstance(payload, dict) or 'records' not in payload:
            raise ValueError('payload must have records')
        records = payload['records']
        if not isinstance(records, list):
            raise ValueError('records must be a list')
        records_by_source.append((sources[i], records))

    # Merge users by id, first present value wins by source priority.
    users = {}
    for source, records in records_by_source:
        for rec in records:
            if not isinstance(rec, dict) or 'id' not in rec:
                raise ValueError('record must have id')
            uid = rec['id']
            if not isinstance(uid, str):
                raise ValueError('id must be str')
            if uid not in users:
                users[uid] = {'id': uid}
            target = users[uid]
            for field in ('name', 'email', 'joined'):
                if field in rec and field not in target:
                    target[field] = rec[field]

    # Build conflicts: same field with >=2 distinct values across sources.
    field_values = {}
    for source, records in records_by_source:
        for rec in records:
            uid = rec['id']
            for field in ('name', 'email', 'joined'):
                if field in rec:
                    key = (uid, field)
                    field_values.setdefault(key, []).append(
                        {'source': source, 'value': rec[field]})

    conflicts = []
    for (uid, field), entries in field_values.items():
        distinct = {}
        for e in entries:
            distinct.setdefault(e['value'], []).append(e['source'])
        if len(distinct) > 1:
            values = []
            for value, srcs in distinct.items():
                for s in srcs:
                    values.append({'source': s, 'value': value})
            conflicts.append({'id': uid, 'field': field, 'values': values})

    conflicts.sort(key=lambda c: (c['id'], c['field']))
    user_list = [users[k] for k in sorted(users)]
    return {'name': contract['name'],
            'result': {'users': user_list, 'conflicts': conflicts}}
