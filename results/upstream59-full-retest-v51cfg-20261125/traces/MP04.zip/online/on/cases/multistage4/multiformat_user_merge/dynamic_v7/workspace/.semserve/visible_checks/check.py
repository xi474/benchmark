import unittest

from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary

# Visible documents used for requirement citations.
README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/json_users/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/csv_users/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/jsonl_users/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/directory/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestJsonUsers(unittest.TestCase):
    def test_records_sorted_and_fields(self):
        payload = {"json_text": '[{"id": 2, "name": "b"}, {"id": 1, "name": "a"}]'}
        contract = {"name": "json_users", "inputs": ["x"], "operation": "users_json"}
        result = call_candidate("domains/json_users/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "json_users")
        records = result["result"]["records"]
        self.assertEqual([r["id"] for r in records], ["1", "2"])
        self.assertEqual(records[0]["name"], "a")

    def test_field_priority_and_date(self):
        payload = {"json_text": '[{"id": 1, "name": "n", "full_name": "fn", '
                                '"email": "e", "mail": "m", "joined": "03/01/2024"}]'}
        contract = {"name": "json_users", "inputs": ["x"], "operation": "users_json"}
        result = call_candidate("domains/json_users/transform.py", "transform",
                                args=[[payload], contract])
        rec = result["result"]["records"][0]
        self.assertEqual(rec["name"], "n")
        self.assertEqual(rec["email"], "e")
        self.assertEqual(rec["joined"], "2024-01-03")

    def test_duplicate_id_last_wins(self):
        payload = {"json_text": '[{"id": 1, "name": "a"}, {"id": 1, "name": "b"}]'}
        contract = {"name": "json_users", "inputs": ["x"], "operation": "users_json"}
        result = call_candidate("domains/json_users/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["records"][0]["name"], "b")


class TestCsvUsers(unittest.TestCase):
    def test_csv_records(self):
        payload = {"csv_text": "user_id,name\n2,b\n1,a\n"}
        contract = {"name": "csv_users", "inputs": ["x"], "operation": "users_csv"}
        result = call_candidate("domains/csv_users/transform.py", "transform",
                                args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual([r["id"] for r in records], ["1", "2"])

    def test_csv_empty_cell_missing(self):
        payload = {"csv_text": "id,name\n1,\n"}
        contract = {"name": "csv_users", "inputs": ["x"], "operation": "users_csv"}
        result = call_candidate("domains/csv_users/transform.py", "transform",
                                args=[[payload], contract])
        rec = result["result"]["records"][0]
        self.assertNotIn("name", rec)


class TestJsonlUsers(unittest.TestCase):
    def test_jsonl_records(self):
        payload = {"jsonl_text": '{"id": 2, "name": "b"}\n{"id": 1, "name": "a"}\n'}
        contract = {"name": "jsonl_users", "inputs": ["x"], "operation": "users_jsonl"}
        result = call_candidate("domains/jsonl_users/transform.py", "transform",
                                args=[[payload], contract])
        records = result["result"]["records"]
        self.assertEqual([r["id"] for r in records], ["1", "2"])

    def test_jsonl_bad_line_raises(self):
        payload = {"jsonl_text": '{"id": 1}\nnot json\n'}
        contract = {"name": "jsonl_users", "inputs": ["x"], "operation": "users_jsonl"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/jsonl_users/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestDirectory(unittest.TestCase):
    def test_merge_priority_and_conflicts(self):
        json_rec = {"records": [{"id": "1", "name": "j", "email": "e1"}]}
        csv_rec = {"records": [{"id": "1", "name": "c", "email": "e1"}]}
        jsonl_rec = {"records": [{"id": "1", "name": "l", "email": "e2"}]}
        contract = {"name": "directory", "inputs": ["a", "b", "c"],
                    "operation": "users_merge"}
        result = call_candidate("views/directory/transform.py", "transform",
                                args=[[json_rec, csv_rec, jsonl_rec], contract])
        users = result["result"]["users"]
        self.assertEqual(users[0]["name"], "j")
        self.assertEqual(users[0]["email"], "e1")
        conflicts = result["result"]["conflicts"]
        self.assertEqual(len(conflicts), 2)
        name_conflict = [c for c in conflicts if c["field"] == "name"][0]
        self.assertEqual(len(name_conflict["values"]), 3)


class TestApiBoundaries(unittest.TestCase):
    def test_nonfinite_unknown_field(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            with self.subTest(target=req["target_path"]):
                check_api_boundary(
                    req["target_path"], rule="nonfinite_unknown_field",
                    contract_path=req["rules"]["nonfinite_unknown_field"]["contract_path"],
                    requirement_quote=req["rules"]["nonfinite_unknown_field"]["requirement_quote"],
                    args=[[{"json_text": "[]"}], {"name": "x", "inputs": ["x"]}])

    def test_invalid_payload_type(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            with self.subTest(target=req["target_path"]):
                check_api_boundary(
                    req["target_path"], rule="invalid_payload_type",
                    contract_path=req["rules"]["invalid_payload_type"]["contract_path"],
                    requirement_quote=req["rules"]["invalid_payload_type"]["requirement_quote"],
                    args=[[{"json_text": "[]"}], {"name": "x", "inputs": ["x"]}])


if __name__ == "__main__":
    unittest.main()
