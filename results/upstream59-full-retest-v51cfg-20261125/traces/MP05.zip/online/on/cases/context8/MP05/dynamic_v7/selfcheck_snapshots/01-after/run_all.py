import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    out = ROOT / "outputs"
    if out.exists():
        import shutil
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    contracts = sorted(ROOT.rglob("contract.json"))
    contracts = [c for c in contracts if "outputs" not in c.relative_to(ROOT).parts]

    # Topological order by dependency: run components whose inputs are all
    # either source inputs or already-produced outputs.
    produced = set()
    remaining = list(contracts)
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            inputs = c["inputs"]
            ready = True
            for inp in inputs:
                p = ROOT / inp
                if p.exists():
                    continue
                # input may be produced by another component
                if inp in produced:
                    continue
                ready = False
                break
            if not ready:
                continue
            render = cp.with_name("render.py")
            subprocess.run(
                [sys.executable, str(render), str(ROOT), str(cp)],
                cwd=ROOT,
                check=True,
                timeout=60,
            )
            produced.add(c["output"])
            remaining.remove(cp)
            progressed = True
        if not progressed:
            raise RuntimeError("dependency cycle or missing input: " + str(remaining))

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
