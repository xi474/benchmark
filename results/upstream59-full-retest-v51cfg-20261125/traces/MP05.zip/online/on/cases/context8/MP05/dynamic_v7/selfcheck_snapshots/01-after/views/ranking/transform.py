def _unwrap(data):
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        return data["result"]
    return data


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    groups = _unwrap(payloads[1])
    mail = _unwrap(payloads[2])
    calendar = _unwrap(payloads[3])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    if not isinstance(groups, dict):
        raise ValueError("groups result must be an object")
    if not isinstance(mail, dict):
        raise ValueError("mail result must be an object")
    if not isinstance(calendar, dict):
        raise ValueError("calendar result must be an object")

    contacts = snapshot["contacts"]
    if not isinstance(contacts, list):
        raise ValueError("contacts must be a list")

    age_by_id = {}
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        cid = c["id"]
        age = c["age"]
        if not isinstance(cid, str) or not cid.strip():
            raise ValueError("contact id must be non-empty string")
        if isinstance(age, bool) or not isinstance(age, int) or age < 0:
            raise ValueError("age must be non-negative int")
        age_by_id[cid] = age

    group_ids = groups.get("ids", [])
    mail_ids = mail.get("ids", [])
    if not isinstance(group_ids, list) or not isinstance(mail_ids, list):
        raise ValueError("candidate ids must be lists")

    minutes = calendar.get("minutes", {})
    if not isinstance(minutes, dict):
        raise ValueError("minutes must be an object")

    # union of candidates
    candidate_ids = set(group_ids) | set(mail_ids)

    ranking = []
    for cid in candidate_ids:
        if cid not in age_by_id:
            raise ValueError("unknown candidate id")
        m = minutes.get(cid, 0)
        if isinstance(m, bool) or not isinstance(m, (int, float)):
            raise ValueError("minutes must be a number")
        ranking.append({"id": cid, "minutes": m, "age": age_by_id[cid]})

    ranking.sort(key=lambda r: (-r["minutes"], -r["age"], r["id"]))

    winner = ranking[0]["id"] if ranking else None

    return {"name": contract["name"], "result": {"ranking": ranking, "winner": winner}}
