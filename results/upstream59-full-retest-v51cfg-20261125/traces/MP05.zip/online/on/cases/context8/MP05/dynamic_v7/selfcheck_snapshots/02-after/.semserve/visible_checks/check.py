import unittest

# call_candidate, check_api_boundary, CandidateCallError are injected by the
# visible-contract SDK runner into the module namespace.


API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/groups/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/mail/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/ranking/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class GroupsTransformTests(unittest.TestCase):
    def _contract(self):
        return {"name": "groups", "operation": "group_candidates",
                "inputs": ["inputs/case.json"], "output": "outputs/groups.json"}

    def _payload(self):
        return {
            "contacts": [{"id": "self", "age": 20}, {"id": "a", "age": 30}],
            "self_id": "self",
            "keyword": "dinner",
            "groups": [{"id": "g", "members": ["self", "a"],
                        "messages": ["DINNER soon"]}],
        }

    def test_group_candidates_extract_all_members(self):
        payloads = [self._payload()]
        result = call_candidate("domains/groups/transform.py", "transform",
                                args=[payloads, self._contract()])
        self.assertEqual(result["name"], "groups")
        self.assertEqual(result["result"]["ids"], ["a"])

    def test_group_unknown_member_raises(self):
        payload = self._payload()
        payload["groups"][0]["members"].append("ghost")
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/groups/transform.py", "transform",
                           args=[[payload], self._contract()])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class MailTransformTests(unittest.TestCase):
    def _contract(self):
        return {"name": "mail", "operation": "mail_candidates",
                "inputs": ["inputs/case.json"], "output": "outputs/mail.json"}

    def _payload(self):
        return {
            "contacts": [{"id": "self", "age": 20}, {"id": "a", "age": 30}],
            "self_id": "self",
            "keyword": "dinner",
            "emails": [{"id": "e0", "sender": "a", "subject": "Dinner plan"}],
        }

    def test_mail_candidates_sender(self):
        payloads = [self._payload()]
        result = call_candidate("domains/mail/transform.py", "transform",
                                args=[payloads, self._contract()])
        self.assertEqual(result["result"]["ids"], ["a"])

    def test_mail_unknown_sender_raises(self):
        payload = self._payload()
        payload["emails"][0]["sender"] = "ghost"
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/mail/transform.py", "transform",
                           args=[[payload], self._contract()])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class CalendarTransformTests(unittest.TestCase):
    def _contract(self):
        return {"name": "calendar", "operation": "shared_durations",
                "inputs": ["inputs/case.json"], "output": "outputs/calendar.json"}

    def _payload(self):
        return {
            "contacts": [{"id": "self", "age": 20}, {"id": "a", "age": 30}],
            "self_id": "self",
            "window": [0, 100],
            "events": [{"id": "v0", "start": -10, "end": 80,
                        "attendees": ["self", "a", "a"]}],
        }

    def test_calendar_clip_and_dedupe(self):
        payloads = [self._payload()]
        result = call_candidate("domains/calendar/transform.py", "transform",
                                args=[payloads, self._contract()])
        # clipped to [0,80) => 80 minutes; duplicate attendee counted once
        self.assertEqual(result["result"]["minutes"]["a"], 80)

    def test_calendar_bad_window_raises(self):
        payload = self._payload()
        payload["window"] = [100, 0]
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/calendar/transform.py", "transform",
                           args=[[payload], self._contract()])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class RankingTransformTests(unittest.TestCase):
    def _contract(self):
        return {"name": "ranking", "operation": "contact_rank",
                "inputs": ["inputs/case.json", "outputs/groups.json",
                           "outputs/mail.json", "outputs/calendar.json"],
                "output": "outputs/ranking.json"}

    def test_ranking_union_and_order(self):
        snapshot = {"contacts": [{"id": "self", "age": 20},
                                 {"id": "a", "age": 30},
                                 {"id": "b", "age": 25}]}
        groups = {"ids": ["a"]}
        mail = {"ids": ["b"]}
        calendar = {"minutes": {"a": 50, "b": 50}}
        payloads = [snapshot, groups, mail, calendar]
        result = call_candidate("views/ranking/transform.py", "transform",
                                args=[payloads, self._contract()])
        ranking = result["result"]["ranking"]
        # equal minutes -> age desc -> a (30) before b (25)
        self.assertEqual([r["id"] for r in ranking], ["a", "b"])
        self.assertEqual(result["result"]["winner"], "a")

    def test_ranking_empty_winner_null(self):
        snapshot = {"contacts": [{"id": "self", "age": 20}]}
        payloads = [snapshot, {"ids": []}, {"ids": []}, {"minutes": {}}]
        result = call_candidate("views/ranking/transform.py", "transform",
                                args=[payloads, self._contract()])
        self.assertEqual(result["result"]["ranking"], [])
        self.assertIsNone(result["result"]["winner"])


class ApiBoundaryTests(unittest.TestCase):
    def test_api_boundary_requirements(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                with self.subTest(target=req["target_path"], rule=rule):
                    if not spec.get("applicable", False):
                        continue
                    check_api_boundary(
                        req["target_path"],
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=self._seed_args(req["target_path"]),
                    )

    def _seed_args(self, target_path):
        if "groups" in target_path:
            payload = {"contacts": [{"id": "self", "age": 20},
                                    {"id": "a", "age": 30}],
                       "self_id": "self", "keyword": "dinner",
                       "groups": [{"id": "g", "members": ["self", "a"],
                                   "messages": ["DINNER soon"]}]}
            contract = {"name": "groups", "operation": "group_candidates",
                        "inputs": ["inputs/case.json"],
                        "output": "outputs/groups.json"}
            return [[payload], contract]
        if "mail" in target_path:
            payload = {"contacts": [{"id": "self", "age": 20},
                                    {"id": "a", "age": 30}],
                       "self_id": "self", "keyword": "dinner",
                       "emails": [{"id": "e0", "sender": "a",
                                   "subject": "Dinner plan"}]}
            contract = {"name": "mail", "operation": "mail_candidates",
                        "inputs": ["inputs/case.json"],
                        "output": "outputs/mail.json"}
            return [[payload], contract]
        if "calendar" in target_path:
            payload = {"contacts": [{"id": "self", "age": 20},
                                    {"id": "a", "age": 30}],
                       "self_id": "self", "window": [0, 100],
                       "events": [{"id": "v0", "start": -10, "end": 80,
                                   "attendees": ["self", "a"]}]}
            contract = {"name": "calendar", "operation": "shared_durations",
                        "inputs": ["inputs/case.json"],
                        "output": "outputs/calendar.json"}
            return [[payload], contract]
        # ranking
        snapshot = {"contacts": [{"id": "self", "age": 20},
                                 {"id": "a", "age": 30}]}
        contract = {"name": "ranking", "operation": "contact_rank",
                    "inputs": ["inputs/case.json", "outputs/groups.json",
                               "outputs/mail.json", "outputs/calendar.json"],
                    "output": "outputs/ranking.json"}
        return [[snapshot, {"ids": ["a"]}, {"ids": []}, {"minutes": {"a": 10}}],
                contract]


if __name__ == "__main__":
    unittest.main()
