import math


def _check_finite(obj):
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        raise ValueError("non-finite number")
    if isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    _check_finite(data)

    contacts = data["contacts"]
    self_id = data["self_id"]
    window = data["window"]
    events = data["events"]

    start, end = window
    if end <= start:
        raise ValueError("window end must be after start")

    contact_ids = set()
    for c in contacts:
        contact_ids.add(c["id"])

    minutes = {}
    for c in contacts:
        if c["id"] != self_id:
            minutes[c["id"]] = 0

    for ev in events:
        if ev["end"] <= ev["start"]:
            raise ValueError("event end must be after start")
        attendees = ev["attendees"]
        if self_id not in attendees:
            continue
        # clip to half-open window [start, end)
        lo = max(ev["start"], start)
        hi = min(ev["end"], end)
        if hi <= lo:
            continue
        dur = hi - lo
        seen = set()
        for a in attendees:
            if a == self_id or a in seen:
                continue
            seen.add(a)
            if a not in contact_ids:
                raise ValueError("unknown attendee")
            minutes[a] = minutes.get(a, 0) + dur

    return {"name": contract["name"], "result": {"minutes": minutes}}
