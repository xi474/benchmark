import math


def _check_finite(obj):
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        raise ValueError("non-finite number")
    if isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    _check_finite(data)

    contacts = data["contacts"]
    self_id = data["self_id"]
    keyword = data["keyword"]
    groups = data["groups"]

    if not isinstance(contacts, list):
        raise ValueError("contacts must be a list")
    if not isinstance(self_id, str) or not self_id.strip():
        raise ValueError("self_id must be non-empty string")
    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    if not isinstance(groups, list):
        raise ValueError("groups must be a list")

    contact_ids = set()
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id/age")
        if not isinstance(c["id"], str) or not c["id"].strip():
            raise ValueError("contact id must be non-empty string")
        if isinstance(c["age"], bool) or not isinstance(c["age"], int) or c["age"] < 0:
            raise ValueError("age must be non-negative int")
        contact_ids.add(c["id"])

    if self_id not in contact_ids:
        raise ValueError("self_id not in contacts")

    kw = keyword.casefold()
    ids = set()
    for g in groups:
        if not isinstance(g, dict):
            raise ValueError("group must be object")
        members = g["members"]
        messages = g["messages"]
        if not isinstance(members, list) or not isinstance(messages, list):
            raise ValueError("members/messages must be lists")
        for m in members:
            if m not in contact_ids:
                raise ValueError("unknown member")
        if any(isinstance(msg, str) and kw in msg.casefold() for msg in messages):
            for m in members:
                if m != self_id:
                    ids.add(m)

    return {"name": contract["name"], "result": {"ids": sorted(ids)}}
