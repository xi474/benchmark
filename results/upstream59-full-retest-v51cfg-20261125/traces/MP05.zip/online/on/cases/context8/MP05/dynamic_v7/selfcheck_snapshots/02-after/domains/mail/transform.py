import math


def _check_finite(obj):
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        raise ValueError("non-finite number")
    if isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    _check_finite(data)

    contacts = data["contacts"]
    self_id = data["self_id"]
    keyword = data["keyword"]
    emails = data["emails"]

    contact_ids = {c["id"] for c in contacts}
    if self_id not in contact_ids:
        raise ValueError("unknown self_id")

    kw = keyword.casefold()
    ids = set()
    for e in emails:
        sender = e["sender"]
        if sender not in contact_ids:
            raise ValueError("unknown sender")
        if kw in e["subject"].casefold():
            if sender != self_id:
                ids.add(sender)

    return {"name": contract["name"], "result": {"ids": sorted(ids)}}
