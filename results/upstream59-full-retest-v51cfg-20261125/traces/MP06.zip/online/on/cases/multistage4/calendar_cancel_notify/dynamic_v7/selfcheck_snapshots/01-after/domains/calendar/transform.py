def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    events = data["events"]
    day = data["day"]
    contacts = data["contacts"]

    if isinstance(day, bool) or not isinstance(day, int) or day < 0:
        raise ValueError("day must be non-negative int")

    lo = day * 1440
    hi = day * 1440 + 720

    cancelled = []
    snapshots = {}
    remaining = {}

    for ev in events:
        eid = ev["id"]
        start = ev["start"]
        end = ev["end"]
        social = ev["social"]
        is_cancelled = ev["cancelled"]
        if end <= start:
            raise ValueError("end must be > start")
        if lo <= start < hi and social and not is_cancelled:
            cancelled.append(eid)
            snapshots[eid] = ev
        else:
            remaining[eid] = ev

    cancelled.sort()
    snapshots = {k: snapshots[k] for k in sorted(snapshots)}
    remaining = {k: remaining[k] for k in sorted(remaining)}

    return {
        "name": contract["name"],
        "result": {
            "cancelled": cancelled,
            "snapshots": snapshots,
            "remaining": remaining,
        },
    }
