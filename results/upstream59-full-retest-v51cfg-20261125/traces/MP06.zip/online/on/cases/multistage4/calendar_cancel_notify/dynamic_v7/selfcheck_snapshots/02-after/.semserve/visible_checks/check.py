import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/channels/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/notifications/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class ApiBoundaryTests(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if target.endswith("views/notifications/transform.py"):
                        base = [{"cancelled": [], "snapshots": {}, "remaining": {}},
                                {"contacts": {}}]
                        n_inputs = 2
                    else:
                        base = [{"events": [], "day": 0, "contacts": []}]
                        n_inputs = 1
                    if rule == "invalid_payload_type":
                        args = [base, {"name": "x", "inputs": ["a"] * n_inputs, "output": "c"}]
                    elif rule == "nonfinite_unknown_field":
                        seed = dict(base[0])
                        seed["extra"] = 1
                        args = [[seed] + base[1:], {"name": "x", "inputs": ["a"] * n_inputs, "output": "c"}]
                    else:
                        continue
                    check_api_boundary(
                        target,
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=args,
                    )


class CalendarBehaviorTests(unittest.TestCase):
    def test_cancel_morning_selects_morning_social(self):
        payload = {
            "events": [
                {"id": "a", "start": 0, "end": 10, "social": True, "cancelled": False, "attendees": ["c1"]},
                {"id": "b", "start": 1000, "end": 1010, "social": True, "cancelled": False, "attendees": ["c2"]},
                {"id": "c", "start": 5, "end": 15, "social": False, "cancelled": False, "attendees": ["c3"]},
                {"id": "d", "start": 6, "end": 16, "social": True, "cancelled": True, "attendees": ["c4"]},
            ],
            "day": 0,
            "contacts": [],
        }
        contract = {"name": "calendar", "operation": "cancel_morning", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/calendar/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "calendar")
        self.assertEqual(result["result"]["cancelled"], ["a"])
        self.assertEqual(list(result["result"]["snapshots"]), ["a"])
        self.assertEqual(sorted(result["result"]["remaining"]), ["b", "c", "d"])


class ChannelsBehaviorTests(unittest.TestCase):
    def test_channel_directory_primary_precedence(self):
        payload = {
            "events": [],
            "day": 0,
            "contacts": [
                {"id": "c1", "email": "e@x", "message": "m", "chat": "h"},
                {"id": "c2", "email": None, "message": None, "chat": "h2"},
                {"id": "c3", "email": "e3@x", "message": None, "chat": None},
            ],
        }
        contract = {"name": "channels", "operation": "channel_directory", "inputs": ["x"], "output": "y"}
        result = call_candidate("domains/channels/transform.py", "transform", args=[[payload], contract])
        contacts = result["result"]["contacts"]
        self.assertEqual(contacts["c1"]["primary"], "message")
        self.assertEqual(contacts["c1"]["address"], "m")
        self.assertEqual(contacts["c2"]["primary"], "chat")
        self.assertEqual(contacts["c2"]["address"], "h2")
        self.assertEqual(contacts["c3"]["primary"], None)
        self.assertEqual(contacts["c3"]["address"], None)


class NotificationsBehaviorTests(unittest.TestCase):
    def test_cancel_notifications_routes_channels(self):
        cancel = {
            "cancelled": ["e1"],
            "snapshots": {"e1": {"id": "e1", "attendees": ["c1", "c2", "c3", "c4"]}},
            "remaining": {},
        }
        channels = {
            "contacts": {
                "c1": {"email": "1@x", "primary": "message", "address": "m1"},
                "c2": {"email": None, "primary": "chat", "address": "h2"},
                "c3": {"email": "3@x", "primary": None, "address": None},
                "c4": {"email": None, "primary": None, "address": None},
            }
        }
        contract = {"name": "notifications", "operation": "cancel_notifications", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("views/notifications/transform.py", "transform", args=[[cancel, channels], contract])
        r = result["result"]
        self.assertEqual(r["unreachable"], ["c4"])
        self.assertEqual(r["group"]["members"], ["c1"])
        channels_seen = [(o["channel"], o["to"]) for o in r["outbox"]]
        self.assertIn(("email", "1@x"), channels_seen)
        self.assertIn(("email", "3@x"), channels_seen)
        self.assertIn(("chat", "h2"), channels_seen)
        self.assertIn(("message_group", "cancelled-social"), channels_seen)


if __name__ == "__main__":
    unittest.main()
