import math


def _reject_nonfinite(node):
    if isinstance(node, float):
        if not math.isfinite(node):
            raise ValueError("non-finite number")
    elif isinstance(node, dict):
        for v in node.values():
            _reject_nonfinite(v)
    elif isinstance(node, list):
        for v in node:
            _reject_nonfinite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    _reject_nonfinite(data)

    contacts = data["contacts"]
    seen = set()
    out = {}
    for c in contacts:
        cid = c["id"]
        if cid in seen:
            raise ValueError("duplicate contact id")
        seen.add(cid)
        email = c["email"]
        message = c["message"]
        chat = c["chat"]
        for v in (email, message, chat):
            if v is not None and (not isinstance(v, str) or not v.strip()):
                raise ValueError("channel must be null or non-empty str")
        if message is not None:
            primary = "message"
            address = message
        elif chat is not None:
            primary = "chat"
            address = chat
        else:
            primary = None
            address = None
        out[cid] = {
            "email": email,
            "primary": primary,
            "address": address,
        }
    return {"name": contract["name"], "result": {"contacts": out}}
