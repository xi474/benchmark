import math


def _reject_nonfinite(node):
    if isinstance(node, float):
        if not math.isfinite(node):
            raise ValueError("non-finite number")
    elif isinstance(node, dict):
        for v in node.values():
            _reject_nonfinite(v)
    elif isinstance(node, list):
        for v in node:
            _reject_nonfinite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    cancel_result = payloads[0]
    channel_result = payloads[1]

    # Unwrap name/result envelope if present.
    cancel = _unwrap(cancel_result)
    channel = _unwrap(channel_result)
    if not isinstance(cancel, dict) or not isinstance(channel, dict):
        raise ValueError("inputs must be objects")

    _reject_nonfinite(cancel)
    _reject_nonfinite(channel)

    cancelled_ids = sorted(cancel["cancelled"])
    snapshots = cancel["snapshots"]
    contacts = channel["contacts"]

    # Union of attendees across target snapshots, deduped, preserving order.
    seen = set()
    attendee_ids = []
    for eid in cancelled_ids:
        snap = snapshots[eid]
        for cid in snap["attendees"]:
            if cid not in seen:
                seen.add(cid)
                attendee_ids.append(cid)

    # Validate unknown IDs.
    for cid in attendee_ids:
        if cid not in contacts:
            raise ValueError("unknown contact id: %s" % cid)

    requires = cancelled_ids

    outbox = []
    unreachable = []
    group_members = []

    for cid in attendee_ids:
        c = contacts[cid]
        email = c["email"]
        primary = c["primary"]
        address = c["address"]

        if email is not None:
            outbox.append({
                "channel": "email",
                "to": email,
                "recipients": [cid],
                "requires": requires,
            })
        if primary == "message":
            group_members.append(cid)
        elif primary == "chat":
            outbox.append({
                "channel": "chat",
                "to": address,
                "recipients": [cid],
                "requires": requires,
            })
        elif primary is None:
            if email is None:
                unreachable.append(cid)

    group = None
    if group_members:
        group_members.sort()
        group = {
            "id": "cancelled-social",
            "members": group_members,
            "requires": requires,
        }
        outbox.append({
            "channel": "message_group",
            "to": group["id"],
            "recipients": group_members,
            "requires": requires,
        })

    outbox.sort(key=lambda o: (o["channel"], o["to"]))
    unreachable.sort()

    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox,
            "unreachable": unreachable,
            "group": group,
        },
    }


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj) == {"name", "result"}:
        return obj["result"]
    return obj
