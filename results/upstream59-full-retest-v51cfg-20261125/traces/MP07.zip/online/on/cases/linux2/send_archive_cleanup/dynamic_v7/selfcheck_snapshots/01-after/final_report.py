import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _write_json(path, data):
    text = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
    ) + "\n"
    Path(path).write_text(text, encoding="utf-8")


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core["components"]
    component_count = len(components)

    # sha256 over the full core object (including outer "components").
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: component names satisfying any condition.
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.append(name)
            continue
        for key in ("complete", "checkout", "committed", "ok"):
            if result.get(key) is False:
                attention.append(name)
                break
        else:
            for key in ("unavailable", "missing", "conflicts", "unreachable"):
                v = result.get(key)
                if isinstance(v, (list, dict, str)) and len(v) > 0:
                    attention.append(name)
                    break

    attention = sorted(set(attention))

    report = {
        "title": "附件发送后归档与独立清理",
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention,
    }

    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, report)


if __name__ == "__main__":
    main()
