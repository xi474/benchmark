def _safe_rel_path(s):
    if not isinstance(s, str):
        raise ValueError("path must be string")
    if s == "":
        raise ValueError("empty path")
    if s.startswith("/") or "\\" in s or ":" in s:
        raise ValueError("unsafe path")
    parts = s.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("unsafe path segment")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    cleanup_prefix = payload["cleanup_prefix"]
    _safe_rel_path(cleanup_prefix)
    if cleanup_prefix.endswith("/"):
        raise ValueError("cleanup_prefix must not end with slash")

    files = payload["files"]
    if not isinstance(files, list):
        raise ValueError("files must be list")

    deleted = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        path = f["path"]
        _safe_rel_path(path)
        if path.endswith(".tmp"):
            # match by path segment boundary: prefix must be a directory prefix
            if path.startswith(cleanup_prefix + "/"):
                deleted.append(path)

    deleted.sort()
    return {"name": contract["name"], "result": {"delete": deleted}}
