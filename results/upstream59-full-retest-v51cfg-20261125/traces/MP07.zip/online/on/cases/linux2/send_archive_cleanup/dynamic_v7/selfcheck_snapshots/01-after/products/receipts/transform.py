import hashlib


def _require_str(value, field):
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    if not value.strip():
        raise ValueError(f"{field} must be non-empty")
    return value


def _safe_rel_path(value, field):
    s = _require_str(value, field)
    if s.startswith("/") or "\\" in s or ":" in s:
        raise ValueError(f"{field} is not a safe relative path")
    parts = s.split("/")
    if any(p == "" or p == "." or p == ".." for p in parts):
        raise ValueError(f"{field} is not a safe relative path")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")

    files = payload.get("files")
    attachments = payload.get("attachments")
    recipients = payload.get("recipients")
    send_ok = payload.get("send_ok")

    if not isinstance(files, list):
        raise ValueError("files must be a list")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be a list")
    if not isinstance(recipients, list):
        raise ValueError("recipients must be a list")
    if not isinstance(send_ok, dict):
        raise ValueError("send_ok must be an object")

    # Build path -> hex map, validating files entries.
    file_map = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be an object")
        path = _safe_rel_path(f.get("path"), "file.path")
        hexv = f.get("hex")
        if not isinstance(hexv, str):
            raise ValueError("file.hex must be a string")
        try:
            raw = bytes.fromhex(hexv)
        except ValueError as e:
            raise ValueError("file.hex is not valid hex") from e
        if path in file_map:
            raise ValueError("duplicate file path")
        file_map[path] = raw

    # Attachments: dedupe, sort, must exist.
    att_paths = []
    for a in attachments:
        p = _safe_rel_path(a, "attachment")
        if p not in file_map:
            raise ValueError("attachment not found in files")
        att_paths.append(p)
    att_paths = sorted(set(att_paths))

    # Recipients: unique non-empty ids.
    rec_ids = []
    for r in recipients:
        rid = _require_str(r, "recipient")
        if rid in rec_ids:
            raise ValueError("duplicate recipient")
        rec_ids.append(rid)
    rec_ids = sorted(rec_ids)

    out_attachments = []
    for p in att_paths:
        out_attachments.append({
            "path": p,
            "sha256": hashlib.sha256(file_map[p]).hexdigest(),
        })

    receipts = []
    for rid in rec_ids:
        if rid not in send_ok:
            raise ValueError("recipient missing from send_ok")
        ok = send_ok[rid]
        if not isinstance(ok, bool):
            raise ValueError("send_ok value must be bool")
        receipts.append({"recipient": rid, "ok": ok})

    return {
        "name": contract["name"],
        "result": {
            "attachments": out_attachments,
            "receipts": receipts,
        },
    }
