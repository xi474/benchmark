import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Recompute every component output from inputs, in dependency order.
    # receipts and cleanup depend only on inputs/case.json; archive depends on
    # both of their outputs. Run each component's render.py CLI.
    contracts = sorted(ROOT.rglob("contract.json"))
    contracts = [c for c in contracts if "outputs" not in c.relative_to(ROOT).parts]

    # Topological order by dependency: a component whose inputs reference
    # another component's output must run after that producer.
    name_by_contract = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name_by_contract[str(cp)] = c

    produced = set()
    remaining = list(contracts)
    order = []
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = name_by_contract[str(cp)]
            deps = [
                p
                for p in c["inputs"]
                if p.startswith("outputs/") and p != c["output"]
            ]
            if all(d in produced for d in deps):
                order.append(cp)
                produced.add(c["output"])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise ValueError("dependency cycle or missing dependency")

    for cp in order:
        render = cp.with_name("render.py")
        subprocess.run(
            [sys.executable, str(render), str(cp)],
            cwd=ROOT,
            check=True,
        )

    # Integrate all component outputs into core_manifest.json.
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
    )

    # Produce the final report.
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
