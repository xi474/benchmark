import unittest

# Injected by the SDK runner; not importable in this file's own namespace.
# call_candidate, CandidateCallError, check_api_boundary are provided at runtime.

README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/receipts/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/cleanup/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/archive/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class ApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for entry in API_BOUNDARY_REQUIREMENTS:
            target = entry["target_path"]
            for rule, spec in entry["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if target == "products/archive/transform.py":
                        args = [[
                            {
                                "files": [{"path": "a.txt", "hex": "616263"}],
                                "attachments": ["a.txt"],
                                "recipients": ["ann"],
                                "send_ok": {"ann": True},
                                "cleanup_prefix": "tmp",
                                "archive_prefix": "arc",
                            },
                            {"receipts": [{"recipient": "ann", "ok": True}]},
                            {"delete": []},
                        ], {"name": "x", "inputs": ["a", "b", "c"], "output": "o"}]
                    else:
                        args = [[{
                            "files": [{"path": "a.txt", "hex": "616263"}],
                            "attachments": ["a.txt"],
                            "recipients": ["ann"],
                            "send_ok": {"ann": True},
                            "cleanup_prefix": "tmp",
                            "archive_prefix": "arc",
                        }], {"name": "x", "inputs": ["i"], "output": "o"}]
                    check_api_boundary(
                        target,
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=args,
                    )


class ReceiptsBehavior(unittest.TestCase):
    def test_receipts_output_contract(self):
        # attachment_receipts: attachments deduped+sorted, sha256 of raw bytes,
        # receipts sorted by recipient id, ok read from send_ok.
        payload = {
            "files": [
                {"path": "a.txt", "hex": "616263"},
                {"path": "b.txt", "hex": "64"},
            ],
            "attachments": ["b.txt", "a.txt", "b.txt"],
            "recipients": ["zoe", "ann"],
            "send_ok": {"ann": True, "zoe": False},
            "cleanup_prefix": "tmp",
            "archive_prefix": "arc",
        }
        contract = {"name": "receipts", "inputs": ["x"], "output": "y"}
        result = call_candidate(
            "products/receipts/transform.py", "transform",
            args=[[payload], contract],
        )
        self.assertEqual(result["name"], "receipts")
        r = result["result"]
        self.assertEqual(
            [a["path"] for a in r["attachments"]], ["a.txt", "b.txt"]
        )
        self.assertEqual(
            r["attachments"][0]["sha256"],
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        )
        self.assertEqual(
            r["receipts"],
            [{"recipient": "ann", "ok": True}, {"recipient": "zoe", "ok": False}],
        )


class CleanupBehavior(unittest.TestCase):
    def test_cleanup_segment_boundary(self):
        # Only files under cleanup_prefix/ with .tmp suffix are deleted;
        # home/tmp-old/b.tmp must NOT match home/tmp.
        payload = {
            "files": [
                {"path": "home/tmp/a.tmp", "hex": "00"},
                {"path": "home/tmp-old/b.tmp", "hex": "01"},
                {"path": "home/tmp/keep.txt", "hex": "02"},
            ],
            "attachments": [],
            "recipients": [],
            "send_ok": {},
            "cleanup_prefix": "home/tmp",
            "archive_prefix": "arc",
        }
        contract = {"name": "cleanup", "inputs": ["x"], "output": "y"}
        result = call_candidate(
            "products/cleanup/transform.py", "transform",
            args=[[payload], contract],
        )
        self.assertEqual(result["result"]["delete"], ["home/tmp/a.tmp"])


class ArchiveBehavior(unittest.TestCase):
    def test_archive_blocked_when_not_all_ok(self):
        # Not all receipts ok -> no moves, blocked True.
        snapshot = {
            "files": [{"path": "a.txt", "hex": "616263"}],
            "attachments": ["a.txt"],
            "recipients": ["ann"],
            "send_ok": {"ann": True},
            "cleanup_prefix": "tmp",
            "archive_prefix": "arc",
        }
        receipts = {"receipts": [{"recipient": "ann", "ok": False}]}
        cleanup = {"delete": []}
        contract = {"name": "archive", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate(
            "products/archive/transform.py", "transform",
            args=[[snapshot, receipts, cleanup], contract],
        )
        r = result["result"]
        self.assertEqual(r["moves"], [])
        self.assertTrue(r["blocked"])

    def test_archive_moves_when_all_ok(self):
        snapshot = {
            "files": [{"path": "a.txt", "hex": "616263"}],
            "attachments": ["a.txt"],
            "recipients": ["ann"],
            "send_ok": {"ann": True},
            "cleanup_prefix": "tmp",
            "archive_prefix": "arc",
        }
        receipts = {"receipts": [{"recipient": "ann", "ok": True}]}
        cleanup = {"delete": []}
        contract = {"name": "archive", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate(
            "products/archive/transform.py", "transform",
            args=[[snapshot, receipts, cleanup], contract],
        )
        r = result["result"]
        self.assertEqual(
            r["moves"], [{"from": "a.txt", "to": "arc/a.txt"}]
        )
        self.assertFalse(r["blocked"])


if __name__ == "__main__":
    unittest.main()
