import hashlib
import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _unwrap(payload):
    # When an input object has keys exactly name/result, only its result is
    # the business input; other objects are interpreted as-is.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _safe_rel(path):
    if not isinstance(path, str):
        raise ValueError("path must be string")
    if path == "":
        raise ValueError("empty path")
    if path.startswith("/") or "\\" in path or ":" in path:
        raise ValueError("unsafe path")
    parts = path.split("/")
    if any(seg in ("", ".", "..") for seg in parts):
        raise ValueError("unsafe path segment")
    return path


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    receipts = _unwrap(payloads[1])
    cleanup = _unwrap(payloads[2])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be object")
    if not isinstance(receipts, dict):
        raise ValueError("receipts must be object")
    if not isinstance(cleanup, dict):
        raise ValueError("cleanup must be object")

    _reject_nonfinite(snapshot)
    _reject_nonfinite(receipts)
    _reject_nonfinite(cleanup)

    archive_prefix = snapshot["archive_prefix"]
    _safe_rel(archive_prefix)

    files = snapshot["files"]
    attachments = snapshot["attachments"]

    # Build path -> hex map from files.
    file_map = {}
    for f in files:
        p = f["path"]
        _safe_rel(p)
        file_map[p] = f["hex"]

    # receipts: list of {recipient, ok}
    receipt_list = receipts["receipts"]
    can_move = len(receipt_list) > 0 and all(r["ok"] is True for r in receipt_list)

    # cleanup delete list
    deleted = list(cleanup["delete"])

    moves = []
    blocked = not can_move

    if can_move:
        # Move attachments to archive_prefix/<full path>.
        for att in attachments:
            _safe_rel(att)
            to = archive_prefix + "/" + att
            moves.append({"from": att, "to": to})

    # Validate: duplicate targets, target already exists, cleanup/move overlap.
    seen_to = set()
    for m in moves:
        if m["to"] in seen_to:
            raise ValueError("duplicate target")
        seen_to.add(m["to"])
        if m["to"] in file_map:
            raise ValueError("target already exists")

    move_sources = set(m["from"] for m in moves)
    for d in deleted:
        if d in move_sources:
            raise ValueError("cleanup overlaps move source")

    moves.sort(key=lambda m: m["from"])

    # files output: all files sorted by path, bytes unchanged.
    out_files = sorted(files, key=lambda f: f["path"])

    return {
        "name": contract["name"],
        "result": {
            "moves": moves,
            "deleted": deleted,
            "blocked": blocked,
            "files": out_files,
        },
    }
