import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file. Only object/array top-level values are legal.

    Invalid JSON, any other top-level type, and any nested NaN/Infinity
    raise ValueError.
    """
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        raise ValueError("cannot read payload: %s" % (path,)) from exc
    try:
        data = json.loads(text, parse_constant=_reject_constant)
    except ValueError:
        raise
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level payload must be an object or array")
    return data


def _reject_constant(value):
    raise ValueError("non-finite JSON number is not allowed")
