import json
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return the wrapper."""
    root = Path(root)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    text = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text + "\n", encoding="utf-8")


def main():
    root = Path.cwd()
    contract_path = Path(__file__).with_name("contract.json")
    result = build_component(root, contract_path)
    _write_json(root / load_payload(contract_path)["output"], result)


if __name__ == "__main__":
    main()
