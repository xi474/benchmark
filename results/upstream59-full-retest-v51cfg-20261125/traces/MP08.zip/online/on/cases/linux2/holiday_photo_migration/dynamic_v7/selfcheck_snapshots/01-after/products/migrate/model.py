import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file. Only object/array top-level is legal.

    Invalid JSON, any other top-level type, and any nested NaN/Infinity
    raise ValueError.
    """
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text, parse_constant=_reject_constant)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("invalid JSON: %s" % (exc,))
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be object or array")
    return data


def _reject_constant(value):
    raise ValueError("non-finite JSON number: %s" % (value,))
