import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return the envelope."""
    root = Path(root)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    text = json.dumps(
        data,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    )
    Path(path).write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    # Support any current directory: locate the component dir from this file.
    comp_dir = Path(__file__).resolve().parent
    root = comp_dir.parents[1]
    contract_path = comp_dir / "contract.json"
    contract = load_payload(contract_path)
    result = build_component(root, contract_path)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
