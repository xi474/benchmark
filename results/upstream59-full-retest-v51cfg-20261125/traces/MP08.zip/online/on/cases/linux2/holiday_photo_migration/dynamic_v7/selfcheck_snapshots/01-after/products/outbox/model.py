import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file. Only object/array top-level values are legal.

    Raises ValueError for invalid JSON, non-object/array top-level values, and
    any nested NaN/Infinity (non-standard JSON numbers).
    """
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text, parse_constant=_reject_constant)
    except ValueError:
        raise
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON value must be object or array")
    return data


def _reject_constant(value):
    raise ValueError("non-standard JSON number: " + value)
