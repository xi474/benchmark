import json
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, run transform, return the wrapped result."""
    root = Path(root)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    text = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
    ) + "\n"
    Path(path).write_text(text, encoding="utf-8")


if __name__ == "__main__":
    here = Path(__file__).resolve()
    root = here.parents[2]
    contract_path = here.parent / "contract.json"
    result = build_component(root, contract_path)
    contract = load_payload(contract_path)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
