def transform(payloads, contract):
    """photo_outbox: build the send manifest and missing report.

    payloads are ordered per contract['inputs']:
      0: original snapshot {files, photos, festivals, destination, recipient}
      1: photo_classification {selected, missing}
      2: photo_migration {moves, files}

    Returns {"name": contract["name"], "result": {...}}.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])
    migration = _unwrap(payloads[2])

    recipient = snapshot["recipient"]
    missing = classification["missing"]

    # attachments: migrated paths, sorted
    attachments = sorted(m["to"] for m in migration["moves"])

    if missing:
        message = "Missing: " + ", ".join(missing)
    else:
        message = "Photos ready"

    result = {
        "to": recipient,
        "attachments": attachments,
        "missing": missing,
        "message": message,
    }
    return {"name": contract["name"], "result": result}


def _unwrap(payload):
    """If the payload object has exactly keys name/result, use its result."""
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload
