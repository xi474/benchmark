import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Materialize inputs/contracts/checks (idempotent, preserves implementations).
    if (ROOT / "materialize.py").is_file():
        subprocess.run(
            [sys.executable, str(ROOT / "materialize.py")],
            cwd=ROOT, check=True,
        )

    # Run each component render CLI in dependency order.
    for comp in ("classify", "migrate", "outbox"):
        render = ROOT / "products" / comp / "render.py"
        subprocess.run([sys.executable, str(render)], cwd=ROOT, check=True)

    # Integrate all component outputs into core_manifest.json.
    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)

    # Generate the final report.
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
