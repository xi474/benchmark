import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/classify/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未使用的额外字段可忽略；直接API输入中此类附加字段的递归非有限数拒绝仅为可选稳健性能力",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError",
            },
        },
    },
    {
        "target_path": "products/migrate/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未使用的额外字段可忽略；直接API输入中此类附加字段的递归非有限数拒绝仅为可选稳健性能力",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError",
            },
        },
    },
    {
        "target_path": "products/outbox/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未使用的额外字段可忽略；直接API输入中此类附加字段的递归非有限数拒绝仅为可选稳健性能力",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "必需字段缺失、指定非法类型/重复/冲突均ValueError",
            },
        },
    },
]


class ClassifyBehaviorTests(unittest.TestCase):
    def test_classify_api_boundary(self):
        payload = {
            "files": [{"path": "a.jpg", "hex": "00"}],
            "photos": [{"path": "a.jpg", "festival": "spring"}],
            "festivals": ["spring"],
            "destination": "holiday",
            "recipient": "friend",
        }
        contract = {"name": "classify", "operation": "photo_classification", "inputs": ["x"], "output": "y"}
        check_api_boundary(
            "products/classify/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError",
            args=[[payload], contract],
        )
        check_api_boundary(
            "products/classify/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未使用的额外字段可忽略；直接API输入中此类附加字段的递归非有限数拒绝仅为可选稳健性能力",
            args=[[payload], contract],
        )

    def test_classify_selects_and_missing(self):
        payload = {
            "files": [
                {"path": "a.jpg", "hex": "00"},
                {"path": "b.jpg", "hex": "01"},
                {"path": "c.jpg", "hex": "02"},
            ],
            "photos": [
                {"path": "a.jpg", "festival": "spring"},
                {"path": "b.jpg", "festival": "summer"},
                {"path": "c.jpg", "festival": "autumn"},
            ],
            "festivals": ["spring", "winter"],
            "destination": "holiday",
            "recipient": "friend",
        }
        contract = {"name": "classify", "operation": "photo_classification", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/classify/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "classify")
        self.assertEqual(result["result"]["selected"], [{"path": "a.jpg", "festival": "spring"}])
        self.assertEqual(result["result"]["missing"], ["winter"])

    def test_classify_duplicate_photo_path_raises(self):
        payload = {
            "files": [{"path": "a.jpg", "hex": "00"}],
            "photos": [
                {"path": "a.jpg", "festival": "spring"},
                {"path": "a.jpg", "festival": "summer"},
            ],
            "festivals": ["spring"],
            "destination": "holiday",
            "recipient": "friend",
        }
        contract = {"name": "classify", "operation": "photo_classification", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/classify/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class MigrateBehaviorTests(unittest.TestCase):
    def test_migrate_api_boundary(self):
        snapshot = {"files": [{"path": "a.jpg", "hex": "00"}], "destination": "holiday"}
        classification = {"name": "classify", "result": {"selected": [{"path": "a.jpg", "festival": "spring"}], "missing": []}}
        contract = {"name": "migrate", "operation": "photo_migration", "inputs": ["x", "y"], "output": "z"}
        check_api_boundary(
            "products/migrate/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError",
            args=[[snapshot, classification], contract],
        )
        check_api_boundary(
            "products/migrate/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未使用的额外字段可忽略；直接API输入中此类附加字段的递归非有限数拒绝仅为可选稳健性能力",
            args=[[snapshot, classification], contract],
        )

    def test_migrate_moves_selected(self):
        snapshot = {
            "files": [{"path": "a.jpg", "hex": "00"}, {"path": "b.jpg", "hex": "01"}],
            "destination": "holiday",
        }
        classification = {"name": "classify", "result": {"selected": [{"path": "a.jpg", "festival": "spring"}], "missing": []}}
        contract = {"name": "migrate", "operation": "photo_migration", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("products/migrate/transform.py", "transform", args=[[snapshot, classification], contract])
        self.assertEqual(result["result"]["moves"], [{"from": "a.jpg", "to": "holiday/a.jpg", "festival": "spring"}])
        self.assertEqual(result["result"]["files"], [{"path": "a.jpg", "hex": "00"}, {"path": "b.jpg", "hex": "01"}])


class OutboxBehaviorTests(unittest.TestCase):
    def test_outbox_api_boundary(self):
        snapshot = {"recipient": "friend"}
        classification = {"name": "classify", "result": {"selected": [], "missing": []}}
        migration = {"name": "migrate", "result": {"moves": [], "files": []}}
        contract = {"name": "outbox", "operation": "photo_outbox", "inputs": ["x", "y", "z"], "output": "w"}
        check_api_boundary(
            "products/outbox/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="必需字段缺失、指定非法类型/重复/冲突均ValueError",
            args=[[snapshot, classification, migration], contract],
        )
        check_api_boundary(
            "products/outbox/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未使用的额外字段可忽略；直接API输入中此类附加字段的递归非有限数拒绝仅为可选稳健性能力",
            args=[[snapshot, classification, migration], contract],
        )

    def test_outbox_message_and_attachments(self):
        snapshot = {"recipient": "friend"}
        classification = {"name": "classify", "result": {"selected": [], "missing": ["winter"]}}
        migration = {"name": "migrate", "result": {"moves": [{"from": "a.jpg", "to": "holiday/a.jpg", "festival": "spring"}], "files": []}}
        contract = {"name": "outbox", "operation": "photo_outbox", "inputs": ["x", "y", "z"], "output": "w"}
        result = call_candidate("products/outbox/transform.py", "transform", args=[[snapshot, classification, migration], contract])
        self.assertEqual(result["result"]["to"], "friend")
        self.assertEqual(result["result"]["attachments"], ["holiday/a.jpg"])
        self.assertEqual(result["result"]["missing"], ["winter"])
        self.assertEqual(result["result"]["message"], "Missing: winter")

    def test_outbox_ready_message(self):
        snapshot = {"recipient": "friend"}
        classification = {"name": "classify", "result": {"selected": [], "missing": []}}
        migration = {"name": "migrate", "result": {"moves": [], "files": []}}
        contract = {"name": "outbox", "operation": "photo_outbox", "inputs": ["x", "y", "z"], "output": "w"}
        result = call_candidate("products/outbox/transform.py", "transform", args=[[snapshot, classification, migration], contract])
        self.assertEqual(result["result"]["message"], "Photos ready")
        self.assertEqual(result["result"]["attachments"], [])


if __name__ == "__main__":
    unittest.main()
