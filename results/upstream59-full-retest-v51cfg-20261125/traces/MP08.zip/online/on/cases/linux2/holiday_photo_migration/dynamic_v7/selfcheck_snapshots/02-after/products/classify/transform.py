import math


def _reject_nonfinite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("non-finite number is not allowed")
    if isinstance(value, dict):
        for v in value.values():
            _reject_nonfinite(v)
    elif isinstance(value, list):
        for v in value:
            _reject_nonfinite(v)


def transform(payloads, contract):
    """photo_classification: select photos whose festival is in festivals.

    payloads must match contract["inputs"] order and count. Returns
    {"name": contract["name"], "result": {...}}.
    """
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("invalid arguments")
    inputs = contract.get("inputs")
    if not isinstance(inputs, list) or len(payloads) != len(inputs):
        raise ValueError("payload count must match contract inputs")

    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("business input must be an object")
    _reject_nonfinite(data)

    files = data.get("files")
    photos = data.get("photos")
    festivals = data.get("festivals")
    destination = data.get("destination")
    recipient = data.get("recipient")

    if not isinstance(files, list):
        raise ValueError("files must be a list")
    if not isinstance(photos, list):
        raise ValueError("photos must be a list")
    if not isinstance(festivals, list):
        raise ValueError("festivals must be a list")
    if not isinstance(destination, str) or not destination.strip():
        raise ValueError("destination must be a non-empty string")
    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be a non-empty string")

    # festivals: unique non-empty strings
    seen_festivals = set()
    for f in festivals:
        if not isinstance(f, str) or not f.strip():
            raise ValueError("festival must be a non-empty string")
        if f in seen_festivals:
            raise ValueError("duplicate festival")
        seen_festivals.add(f)

    # files: each {path, hex}
    file_paths = set()
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be an object")
        p = f.get("path")
        h = f.get("hex")
        if not isinstance(p, str) or not p.strip():
            raise ValueError("file path must be a non-empty string")
        if not isinstance(h, str):
            raise ValueError("file hex must be a string")
        if p in file_paths:
            raise ValueError("duplicate file path")
        file_paths.add(p)

    # photos: each {path, festival}, path unique and in files
    photo_paths = set()
    for ph in photos:
        if not isinstance(ph, dict):
            raise ValueError("photo entry must be an object")
        p = ph.get("path")
        f = ph.get("festival")
        if not isinstance(p, str) or not p.strip():
            raise ValueError("photo path must be a non-empty string")
        if not isinstance(f, str) or not f.strip():
            raise ValueError("photo festival must be a non-empty string")
        if p not in file_paths:
            raise ValueError("photo path not in files")
        if p in photo_paths:
            raise ValueError("duplicate photo path")
        photo_paths.add(p)

    selected = []
    for ph in photos:
        if ph["festival"] in seen_festivals:
            selected.append({"path": ph["path"], "festival": ph["festival"]})
    selected.sort(key=lambda x: (x["festival"], x["path"]))

    selected_festivals = {s["festival"] for s in selected}
    missing = sorted(f for f in festivals if f not in selected_festivals)

    return {
        "name": contract["name"],
        "result": {"selected": selected, "missing": missing},
    }
