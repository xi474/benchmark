import json
import math
from pathlib import Path


def _reject_nonfinite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("non-finite number is not allowed")
    if isinstance(value, dict):
        for v in value.values():
            _reject_nonfinite(v)
    elif isinstance(value, list):
        for v in value:
            _reject_nonfinite(v)


def transform(payloads, contract):
    """photo_migration: move selected source paths to destination/原路径.

    payloads order per contract.inputs:
      [0] original photo snapshot {files:[{path,hex}], destination, ...}
      [1] photo_classification {name, result:{selected:[{path,festival}], missing:[...]}}

    Returns {"name": contract["name"], "result": {...}}.
    """
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("invalid arguments")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = payloads[0]
    classification = payloads[1]

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    if not isinstance(classification, dict):
        raise ValueError("classification must be an object")
    _reject_nonfinite(snapshot)
    _reject_nonfinite(classification)

    # Unwrap name/result envelope when present.
    if set(classification) == {"name", "result"}:
        classification = classification["result"]

    destination = snapshot["destination"]
    files = snapshot["files"]
    selected = classification["selected"]

    # Build path -> hex map from the snapshot.
    hex_by_path = {}
    for f in files:
        hex_by_path[f["path"]] = f["hex"]

    moves = []
    for item in selected:
        src = item["path"]
        festival = item["festival"]
        dst = destination + "/" + src
        moves.append({"from": src, "to": dst, "festival": festival})

    moves.sort(key=lambda m: (m["from"], m["to"]))

    # files: all snapshot files, sorted by path, hex unchanged.
    out_files = [{"path": f["path"], "hex": f["hex"]} for f in files]
    out_files.sort(key=lambda f: f["path"])

    return {"name": contract["name"], "result": {"moves": moves, "files": out_files}}
