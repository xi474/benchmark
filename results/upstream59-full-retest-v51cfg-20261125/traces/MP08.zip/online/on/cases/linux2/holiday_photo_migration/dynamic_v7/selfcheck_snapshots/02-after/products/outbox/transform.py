import math


def _reject_nonfinite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("non-finite number is not allowed")
    if isinstance(value, dict):
        for v in value.values():
            _reject_nonfinite(v)
    elif isinstance(value, list):
        for v in value:
            _reject_nonfinite(v)


def transform(payloads, contract):
    """photo_outbox: build the send manifest and missing report.

    payloads are ordered per contract['inputs']:
      0: original snapshot {files, photos, festivals, destination, recipient}
      1: photo_classification {selected, missing}
      2: photo_migration {moves, files}

    Returns {"name": contract["name"], "result": {...}}.
    """
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("invalid arguments")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])
    migration = _unwrap(payloads[2])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    if not isinstance(classification, dict):
        raise ValueError("classification must be an object")
    if not isinstance(migration, dict):
        raise ValueError("migration must be an object")
    _reject_nonfinite(snapshot)
    _reject_nonfinite(classification)
    _reject_nonfinite(migration)

    recipient = snapshot["recipient"]
    missing = classification["missing"]

    # attachments: migrated paths, sorted
    attachments = sorted(m["to"] for m in migration["moves"])

    if missing:
        message = "Missing: " + ", ".join(missing)
    else:
        message = "Photos ready"

    result = {
        "to": recipient,
        "attachments": attachments,
        "missing": missing,
        "message": message,
    }
    return {"name": contract["name"], "result": result}


def _unwrap(payload):
    """If the payload object has exactly keys name/result, use its result."""
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload
