import copy


def _is_int(x):
    return isinstance(x, int) and not isinstance(x, bool)


def _is_finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and x == x and x not in (float("inf"), float("-inf"))


def _require_int(x, name):
    if not _is_int(x):
        raise ValueError(f"{name} must be int")
    return x


def _require_finite(x, name):
    if not _is_finite(x):
        raise ValueError(f"{name} must be finite number")
    return x


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data.keys()) == {"name", "result"}:
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    now = _require_int(data["now"], "now")
    duration = _require_int(data["duration"], "duration")
    gap = _require_int(data["gap"], "gap")
    if duration < 1:
        raise ValueError("duration must be >= 1")
    if gap < 0:
        raise ValueError("gap must be >= 0")

    windows = data["windows"]
    busy = data["busy"]
    if not isinstance(windows, list) or not isinstance(busy, list):
        raise ValueError("windows/busy must be lists")

    # Build free intervals: union of windows minus busy, clipped at now.
    intervals = []
    for w in windows:
        if not isinstance(w, dict):
            raise ValueError("window must be object")
        s = _require_int(w["start"], "window.start")
        e = _require_int(w["end"], "window.end")
        if e <= s:
            raise ValueError("window end must be > start")
        intervals.append((s, e))

    busy_intervals = []
    for b in busy:
        if not isinstance(b, dict):
            raise ValueError("busy must be object")
        s = _require_int(b["start"], "busy.start")
        e = _require_int(b["end"], "busy.end")
        if e <= s:
            raise ValueError("busy end must be > start")
        busy_intervals.append((s, e))

    # Merge windows into union.
    intervals.sort()
    merged = []
    for s, e in intervals:
        if not merged or s > merged[-1][1]:
            merged.append([s, e])
        else:
            merged[-1][1] = max(merged[-1][1], e)

    # Subtract busy intervals.
    free = []
    for s, e in merged:
        cur = s
        for bs, be in sorted(busy_intervals):
            if be <= cur or bs >= e:
                continue
            if bs > cur:
                free.append((cur, min(bs, e)))
            cur = max(cur, be)
            if cur >= e:
                break
        if cur < e:
            free.append((cur, e))

    # Clip at now.
    free = [(max(s, now), e) for s, e in free if e > now]

    slots = []
    # Greedy: earliest first slot of duration.
    for s, e in free:
        if e - s >= duration:
            slots.append({"start": s, "end": s + duration})
            break

    if slots:
        first_end = slots[0]["end"]
        min_start = first_end + gap
        for s, e in free:
            start = max(s, min_start)
            if start < e and e - start >= duration:
                slots.append({"start": start, "end": start + duration})
                break

    complete = len(slots) == 2
    return {"name": contract["name"], "result": {"slots": slots, "complete": complete}}
