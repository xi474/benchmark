def _unwrap(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    slots = _unwrap(payloads[0])
    invitees = _unwrap(payloads[1])
    supplies = _unwrap(payloads[2])

    complete = slots.get("complete", False)
    group_id = invitees["group_id"]
    members = invitees["members"]

    events = []
    notification = None
    if complete:
        slot_list = slots["slots"]
        for i, slot in enumerate(slot_list[:2], start=1):
            events.append({
                "id": group_id + "-" + str(i),
                "start": slot["start"],
                "end": slot["end"],
                "members": members,
            })
        notification = {
            "group_id": group_id,
            "members": members,
            "event_ids": [e["id"] for e in events],
        }

    return {
        "name": contract["name"],
        "result": {
            "events": events,
            "notification": notification,
            "purchase": supplies,
        },
    }
