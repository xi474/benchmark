def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    groups = data["groups"]
    invite_groups = data["invite_groups"]
    exclude = data.get("exclude", [])
    namespace = data["namespace"]

    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be non-empty string")

    group_map = {}
    for g in groups:
        gid = g["id"]
        members = g["members"]
        if not isinstance(members, list) or len(members) == 0:
            raise ValueError("members must be non-empty list")
        group_map[gid] = members

    member_set = set()
    for gid in invite_groups:
        if gid not in group_map:
            raise ValueError("unknown group")
        member_set.update(group_map[gid])

    member_set.difference_update(exclude)

    members = sorted(member_set)
    group_id = namespace + "-panel"

    return {"name": contract["name"], "result": {"members": members, "group_id": group_id}}
