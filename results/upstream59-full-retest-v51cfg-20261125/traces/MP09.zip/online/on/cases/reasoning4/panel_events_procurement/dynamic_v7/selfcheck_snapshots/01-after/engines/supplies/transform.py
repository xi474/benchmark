def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    products = data["products"]
    requirements = data["requirements"]

    # validate requirements: one per category
    seen = set()
    for r in requirements:
        cat = r["category"]
        if cat in seen:
            raise ValueError("duplicate category requirement")
        seen.add(cat)

    items = []
    unavailable = []
    for r in requirements:
        cat = r["category"]
        qty = r["quantity"]
        candidates = [p for p in products if p["category"] == cat and p["stock"] >= qty]
        if not candidates:
            unavailable.append(cat)
            continue
        # rating max, then price_cents min, then id min
        best = min(candidates, key=lambda p: (-p["rating"], p["price_cents"], p["id"]))
        items.append({
            "category": cat,
            "id": best["id"],
            "quantity": qty,
            "total_cents": best["price_cents"] * qty,
        })

    items.sort(key=lambda x: x["category"])
    unavailable.sort()

    return {"name": contract["name"], "result": {"items": items, "unavailable": unavailable}}
