import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        (p for p in ROOT.rglob("contract.json")
         if "outputs" not in p.relative_to(ROOT).parts),
        key=lambda p: str(p),
    )
    if not contracts:
        raise ValueError("no contracts")

    # Topologically order by input dependency on outputs of other components.
    produced = {c["name"]: c for c in (json.loads(p.read_text(encoding="utf-8")) for p in contracts)}
    # Build dependency graph: component depends on another if its input path
    # equals the other's output path.
    deps = {}
    for name, c in produced.items():
        d = set()
        for inp in c["inputs"]:
            for other_name, oc in produced.items():
                if other_name != name and inp == oc["output"]:
                    d.add(other_name)
        deps[name] = d

    # Topological sort (Kahn).
    order = []
    remaining = set(produced)
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError("dependency cycle detected")
        ready.sort()
        order.append(ready[0])
        remaining.remove(ready[0])

    for name in order:
        c = produced[name]
        cp = ROOT / c["output"].replace("outputs/", "engines/")  # placeholder
        # Locate the contract file for this component.
        cp = next(p for p in contracts if json.loads(p.read_text(encoding="utf-8"))["name"] == name)
        render = cp.with_name("render.py")
        subprocess.run([sys.executable, str(render)], cwd=ROOT, check=True, timeout=60)

    # Run integrate.py to build core_manifest.
    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True, timeout=60)

    # Run final_report.py.
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True, timeout=60)


if __name__ == "__main__":
    main()
