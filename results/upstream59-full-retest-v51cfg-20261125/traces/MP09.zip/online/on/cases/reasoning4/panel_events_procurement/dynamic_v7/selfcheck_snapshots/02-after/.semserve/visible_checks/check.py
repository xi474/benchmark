import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/invitees/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/supplies/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/commit/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_boundary_probes(self):
        calendar_payload = {
            "now": 30, "duration": 180, "gap": 60,
            "windows": [{"id": "w1", "start": 0, "end": 600}],
            "busy": [],
        }
        calendar_contract = {"name": "calendar", "operation": "panel_slots",
                             "inputs": ["inputs/case.json"], "output": "outputs/calendar.json"}
        invitees_payload = {
            "namespace": "n",
            "groups": [{"id": "a", "members": ["one"]}],
            "invite_groups": ["a"], "exclude": [],
        }
        invitees_contract = {"name": "invitees", "operation": "panel_invitees",
                             "inputs": ["inputs/case.json"], "output": "outputs/invitees.json"}
        supplies_payload = {
            "products": [{"id": "p1", "category": "c", "stock": 10, "price_cents": 100, "rating": 5}],
            "requirements": [{"category": "c", "quantity": 3}],
        }
        supplies_contract = {"name": "supplies", "operation": "supply_selection",
                             "inputs": ["inputs/case.json"], "output": "outputs/supplies.json"}
        commit_payloads = [
            {"complete": True, "slots": [{"start": 0, "end": 10}]},
            {"group_id": "n-panel", "members": ["one"]},
            {"items": [], "unavailable": []},
        ]
        commit_contract = {"name": "commit", "operation": "panel_commit",
                           "inputs": ["outputs/calendar.json", "outputs/invitees.json",
                                      "outputs/supplies.json"], "output": "outputs/commit.json"}

        probes = [
            ("engines/calendar/transform.py", "invalid_payload_type",
             "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
             [calendar_payload, calendar_contract], [0]),
            ("engines/calendar/transform.py", "nonfinite_unknown_field",
             "README.md", "任意嵌套NaN/Infinity抛ValueError",
             [calendar_payload, calendar_contract], [0]),
            ("engines/invitees/transform.py", "invalid_payload_type",
             "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
             [invitees_payload, invitees_contract], [0]),
            ("engines/invitees/transform.py", "nonfinite_unknown_field",
             "README.md", "任意嵌套NaN/Infinity抛ValueError",
             [invitees_payload, invitees_contract], [0]),
            ("engines/supplies/transform.py", "invalid_payload_type",
             "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
             [supplies_payload, supplies_contract], [0]),
            ("engines/supplies/transform.py", "nonfinite_unknown_field",
             "README.md", "任意嵌套NaN/Infinity抛ValueError",
             [supplies_payload, supplies_contract], [0]),
            ("engines/commit/transform.py", "invalid_payload_type",
             "README.md", "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
             [commit_payloads, commit_contract], [0, 0]),
            ("engines/commit/transform.py", "nonfinite_unknown_field",
             "README.md", "任意嵌套NaN/Infinity抛ValueError",
             [commit_payloads, commit_contract], [0, 0]),
        ]
        for target, rule, doc, quote, args, path in probes:
            with self.subTest(target=target, rule=rule):
                check_api_boundary(target, rule=rule, contract_path=doc,
                                   requirement_quote=quote, args=args, path=path)


class TestCalendar(unittest.TestCase):
    def test_slots_greedy_and_gap(self):
        payload = {
            "now": 30,
            "duration": 180,
            "gap": 60,
            "windows": [{"id": "w1", "start": 0, "end": 600},
                        {"id": "w2", "start": 600, "end": 1200}],
            "busy": [{"id": "b", "start": 200, "end": 300}],
        }
        contract = {"name": "calendar", "operation": "panel_slots",
                    "inputs": ["inputs/case.json"], "output": "outputs/calendar.json"}
        result = call_candidate("engines/calendar/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "calendar")
        self.assertEqual(result["result"]["complete"], True)
        self.assertEqual(result["result"]["slots"],
                         [{"start": 300, "end": 480}, {"start": 540, "end": 720}])

    def test_incomplete_when_no_second_slot(self):
        payload = {
            "now": 0,
            "duration": 500,
            "gap": 0,
            "windows": [{"id": "w1", "start": 0, "end": 600}],
            "busy": [],
        }
        contract = {"name": "calendar", "operation": "panel_slots",
                    "inputs": ["inputs/case.json"], "output": "outputs/calendar.json"}
        result = call_candidate("engines/calendar/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["complete"], False)
        self.assertEqual(len(result["result"]["slots"]), 1)


class TestInvitees(unittest.TestCase):
    def test_union_exclude_sort(self):
        payload = {
            "namespace": "n",
            "groups": [
                {"id": "a", "members": ["one", "two"]},
                {"id": "b", "members": ["two", "three"]},
            ],
            "invite_groups": ["a", "b"],
            "exclude": ["one"],
        }
        contract = {"name": "invitees", "operation": "panel_invitees",
                    "inputs": ["inputs/case.json"], "output": "outputs/invitees.json"}
        result = call_candidate("engines/invitees/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["group_id"], "n-panel")
        self.assertEqual(result["result"]["members"], ["three", "two"])

    def test_unknown_group_raises(self):
        payload = {
            "namespace": "n",
            "groups": [{"id": "a", "members": ["one"]}],
            "invite_groups": ["zzz"],
            "exclude": [],
        }
        contract = {"name": "invitees", "operation": "panel_invitees",
                    "inputs": ["inputs/case.json"], "output": "outputs/invitees.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("engines/invitees/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestSupplies(unittest.TestCase):
    def test_rating_then_price_then_id(self):
        payload = {
            "products": [
                {"id": "p1", "category": "c", "stock": 10, "price_cents": 100, "rating": 5},
                {"id": "p2", "category": "c", "stock": 10, "price_cents": 50, "rating": 5},
                {"id": "p3", "category": "c", "stock": 10, "price_cents": 50, "rating": 9},
            ],
            "requirements": [{"category": "c", "quantity": 3}],
        }
        contract = {"name": "supplies", "operation": "supply_selection",
                    "inputs": ["inputs/case.json"], "output": "outputs/supplies.json"}
        result = call_candidate("engines/supplies/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["items"],
                         [{"category": "c", "id": "p3", "quantity": 3, "total_cents": 150}])
        self.assertEqual(result["result"]["unavailable"], [])

    def test_unavailable_when_insufficient_stock(self):
        payload = {
            "products": [{"id": "p1", "category": "c", "stock": 2, "price_cents": 100, "rating": 5}],
            "requirements": [{"category": "c", "quantity": 3}],
        }
        contract = {"name": "supplies", "operation": "supply_selection",
                    "inputs": ["inputs/case.json"], "output": "outputs/supplies.json"}
        result = call_candidate("engines/supplies/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["items"], [])
        self.assertEqual(result["result"]["unavailable"], ["c"])


class TestCommit(unittest.TestCase):
    def test_commit_two_events(self):
        slots = {"complete": True, "slots": [{"start": 300, "end": 480}, {"start": 540, "end": 720}]}
        invitees = {"group_id": "n-panel", "members": ["three", "two"]}
        supplies = {"items": [], "unavailable": []}
        contract = {"name": "commit", "operation": "panel_commit",
                    "inputs": ["outputs/calendar.json", "outputs/invitees.json",
                               "outputs/supplies.json"], "output": "outputs/commit.json"}
        result = call_candidate("engines/commit/transform.py", "transform",
                                args=[[slots, invitees, supplies], contract])
        self.assertEqual(result["result"]["events"],
                         [{"id": "n-panel-1", "start": 300, "end": 480, "members": ["three", "two"]},
                          {"id": "n-panel-2", "start": 540, "end": 720, "members": ["three", "two"]}])
        self.assertEqual(result["result"]["notification"]["event_ids"],
                         ["n-panel-1", "n-panel-2"])
        self.assertEqual(result["result"]["purchase"], supplies)

    def test_commit_incomplete_no_events(self):
        slots = {"complete": False, "slots": []}
        invitees = {"group_id": "n-panel", "members": ["three", "two"]}
        supplies = {"items": [], "unavailable": []}
        contract = {"name": "commit", "operation": "panel_commit",
                    "inputs": ["outputs/calendar.json", "outputs/invitees.json",
                               "outputs/supplies.json"], "output": "outputs/commit.json"}
        result = call_candidate("engines/commit/transform.py", "transform",
                                args=[[slots, invitees, supplies], contract])
        self.assertEqual(result["result"]["events"], [])
        self.assertIsNone(result["result"]["notification"])
        self.assertEqual(result["result"]["purchase"], supplies)


if __name__ == "__main__":
    unittest.main()
