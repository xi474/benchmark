def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    # If the object has exactly keys name/result, use result as business input.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    conversations = payload["conversations"]
    topic = payload["topic"]

    needle = topic.casefold()
    best = None
    for conv in conversations:
        if needle in conv["topic"].casefold():
            if best is None:
                best = conv
            else:
                if conv["ts"] > best["ts"]:
                    best = conv
                elif conv["ts"] == best["ts"] and conv["id"] < best["id"]:
                    best = conv

    if best is None:
        result = {"contact_id": None, "conversation_id": None}
    else:
        result = {"contact_id": best["contact_id"], "conversation_id": best["id"]}

    return {"name": contract["name"], "result": result}
