import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(ROOT.rglob('contract.json'))
    contracts = [c for c in contracts if 'outputs' not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError('no contracts')

    # Topological order by input dependency among component outputs.
    outputs = {c['name']: (ROOT / c['output']).resolve() for c in
               [json.loads(cp.read_text(encoding='utf-8')) for cp in contracts]}

    remaining = list(contracts)
    done = set()
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding='utf-8'))
            deps = []
            for inp in c['inputs']:
                p = (ROOT / inp).resolve()
                for name, out in outputs.items():
                    if p == out:
                        deps.append(name)
            if all(d in done for d in deps):
                subprocess.run(
                    [sys.executable, str(cp.with_name('render.py'))],
                    cwd=ROOT, check=True, timeout=60,
                )
                done.add(c['name'])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise ValueError('dependency cycle or missing dependency')

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')],
                   cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')],
                   cwd=ROOT, check=True, timeout=60)


if __name__ == '__main__':
    main()
