def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot, dinner, contact = payloads

    # Unwrap name/result envelope if present.
    def unwrap(obj):
        if isinstance(obj, dict) and set(obj) == {"name", "result"}:
            return obj["result"]
        return obj

    snapshot = unwrap(snapshot)
    dinner = unwrap(dinner)
    contact = unwrap(contact)

    guest_count = snapshot["guest_count"]
    variants = snapshot["variants"]
    wanted = snapshot["wanted"]

    # Build wanted kinds (unique).
    wanted_kinds = []
    for w in wanted:
        if w["kind"] not in wanted_kinds:
            wanted_kinds.append(w["kind"])

    # Map kind -> wanted attributes.
    wanted_attrs = {w["kind"]: w["attributes"] for w in wanted}

    # For each wanted kind, find candidate variants: attributes exactly equal
    # and stock sufficient. Choose lowest price_cents, then id.
    items = []
    unavailable = []
    for kind in sorted(wanted_kinds):
        attrs = wanted_attrs[kind]
        candidates = [
            v for v in variants
            if v["kind"] == kind
            and v["attributes"] == attrs
            and v["stock"] >= guest_count
        ]
        if not candidates:
            unavailable.append(kind)
            continue
        best = min(candidates, key=lambda v: (v["price_cents"], v["id"]))
        items.append({"id": best["id"], "kind": kind, "quantity": guest_count})

    items.sort(key=lambda it: it["kind"])
    unavailable.sort()

    total_cents = sum(it["quantity"] * _price_of(it["id"], variants) for it in items)

    recipient = contact.get("contact_id") if isinstance(contact, dict) else None
    start = dinner.get("start") if isinstance(dinner, dict) else None

    checkout = (len(unavailable) == 0 and recipient is not None)

    return {
        "name": contract["name"],
        "result": {
            "items": items,
            "total_cents": total_cents,
            "checkout": checkout,
            "recipient": recipient,
            "start": start,
            "unavailable": unavailable,
        },
    }


def _price_of(variant_id, variants):
    for v in variants:
        if v["id"] == variant_id:
            return v["price_cents"]
    return 0
