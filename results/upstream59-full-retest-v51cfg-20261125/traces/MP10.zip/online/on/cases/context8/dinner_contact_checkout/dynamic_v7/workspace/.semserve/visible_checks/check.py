import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "dinner/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "contact/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "shopping/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        seeds = {
            "dinner/transform.py": [
                {"today": "2026-11-04", "weekday": 5, "hour": 19, "guest_count": 6},
                {"name": "dinner", "inputs": ["a"], "output": "y"},
            ],
            "contact/transform.py": [
                {"conversations": [{"id": "a", "contact_id": "c1", "ts": 5, "topic": "dinner"}],
                 "topic": "dinner"},
                {"name": "contact", "inputs": ["a"], "output": "y"},
            ],
            "shopping/transform.py": [
                [
                    {"guest_count": 2,
                     "variants": [{"id": "v1", "kind": "cup", "attributes": {"c": "w"},
                                   "stock": 5, "price_cents": 50}],
                     "wanted": [{"kind": "cup", "attributes": {"c": "w"}}]},
                    {"start": "2026-11-07T19:00", "guest_count": 2},
                    {"contact_id": "c1", "conversation_id": "a"},
                ],
                {"name": "shopping", "inputs": ["a", "b", "c"], "output": "y"},
            ],
        }
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    check_api_boundary(
                        target, rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=seeds[target],
                        path=[0, 0],
                    )


class TestDinner(unittest.TestCase):
    def test_dinner_date_next_weekday(self):
        # weekday=5 (Saturday), today=2026-11-04 (Wednesday) -> next Saturday 2026-11-07
        payload = {"today": "2026-11-04", "weekday": 5, "hour": 19, "guest_count": 6}
        contract = {"name": "dinner", "inputs": ["x"], "output": "y"}
        result = call_candidate("dinner/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["start"], "2026-11-07T19:00")
        self.assertEqual(result["result"]["guest_count"], 6)

    def test_dinner_same_weekday_adds_seven(self):
        # today is already Wednesday (weekday 2), request weekday 2 -> +7 days
        payload = {"today": "2026-11-04", "weekday": 2, "hour": 8, "guest_count": 1}
        contract = {"name": "dinner", "inputs": ["x"], "output": "y"}
        result = call_candidate("dinner/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["start"], "2026-11-11T08:00")


class TestContact(unittest.TestCase):
    def test_contact_max_ts_then_min_id(self):
        payload = {
            "conversations": [
                {"id": "b", "contact_id": "c2", "ts": 5, "topic": "Dinner plans"},
                {"id": "a", "contact_id": "c1", "ts": 5, "topic": "dinner"},
                {"id": "c", "contact_id": "c3", "ts": 3, "topic": "dinner"},
            ],
            "topic": "dinner",
        }
        contract = {"name": "contact", "inputs": ["x"], "output": "y"}
        result = call_candidate("contact/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["contact_id"], "c1")
        self.assertEqual(result["result"]["conversation_id"], "a")

    def test_contact_no_match_nulls(self):
        payload = {
            "conversations": [{"id": "a", "contact_id": "c1", "ts": 5, "topic": "Lunch"}],
            "topic": "dinner",
        }
        contract = {"name": "contact", "inputs": ["x"], "output": "y"}
        result = call_candidate("contact/transform.py", "transform", args=[[payload], contract])
        self.assertIsNone(result["result"]["contact_id"])
        self.assertIsNone(result["result"]["conversation_id"])


class TestShopping(unittest.TestCase):
    def test_shopping_selects_cheapest_and_blocks(self):
        snapshot = {
            "guest_count": 2,
            "variants": [
                {"id": "v1", "kind": "cup", "attributes": {"c": "w"}, "stock": 5, "price_cents": 100},
                {"id": "v2", "kind": "cup", "attributes": {"c": "w"}, "stock": 5, "price_cents": 50},
            ],
            "wanted": [
                {"kind": "cup", "attributes": {"c": "w"}},
                {"kind": "plate", "attributes": {"c": "w"}},
            ],
        }
        dinner = {"start": "2026-11-07T19:00", "guest_count": 2}
        contact = {"contact_id": "c1", "conversation_id": "a"}
        contract = {"name": "shopping", "inputs": ["a", "b", "c"], "output": "y"}
        result = call_candidate(
            "shopping/transform.py", "transform",
            args=[[snapshot, dinner, contact], contract],
        )
        r = result["result"]
        self.assertEqual(r["checkout"], False)
        self.assertEqual(r["unavailable"], ["plate"])
        self.assertEqual(r["items"], [{"id": "v2", "kind": "cup", "quantity": 2}])
        self.assertEqual(r["total_cents"], 100)
        self.assertEqual(r["recipient"], "c1")
        self.assertEqual(r["start"], "2026-11-07T19:00")


if __name__ == "__main__":
    unittest.main()
