import json
from pathlib import Path


def _reject_constant(value):
    raise ValueError("non-finite JSON number")


def load_payload(path):
    text = Path(path).read_text(encoding="utf-8")
    try:
        data = json.loads(text, parse_constant=_reject_constant)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("invalid JSON") from exc
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be object or array")
    return data
