def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot, files_result, mail_result, reply_result = payloads

    def unwrap(p):
        if isinstance(p, dict) and set(p) == {"name", "result"}:
            return p["result"]
        return p

    snapshot = unwrap(snapshot)
    files_result = unwrap(files_result)
    mail_result = unwrap(mail_result)
    reply_result = unwrap(reply_result)

    trash_ids = mail_result["trash_ids"]
    reply_email_id = reply_result["email_id"]

    if reply_email_id in trash_ids:
        raise ValueError("reply target is in trash")

    # Replay file moves
    files = {f["path"]: f["hex"] for f in snapshot["files"]}
    for move in files_result["moves"]:
        src = move["from"]
        dst = move["to"]
        if src not in files:
            raise ValueError("move source not found")
        if dst in files:
            raise ValueError("move target already exists")
        files[dst] = files.pop(src)

    files_out = [{"path": p, "hex": h} for p, h in files.items()]
    files_out.sort(key=lambda f: f["path"])

    # Apply trash
    emails = {e["id"]: dict(e) for e in snapshot["emails"]}
    for tid in trash_ids:
        if tid not in emails:
            raise ValueError("trash id not found")
        emails[tid]["folder"] = "TRASH"

    emails_out = [emails[k] for k in sorted(emails)]

    return {
        "name": contract["name"],
        "result": {
            "files": files_out,
            "emails": emails_out,
            "reply": reply_result,
        },
    }
