def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    download_prefix = data["download_prefix"]
    archive_prefix = data["archive_prefix"]
    extensions = data["extensions"]
    files = data["files"]

    moves = []
    seen_targets = set()
    for f in files:
        path = f["path"]
        hexv = f["hex"]
        # only direct children of download_prefix
        prefix = download_prefix + "/"
        if not path.startswith(prefix):
            continue
        rest = path[len(prefix):]
        if "/" in rest:
            continue
        # find extension (case-insensitive)
        ext = None
        for e in extensions:
            if rest.lower().endswith(e.lower()):
                ext = e
                break
        if ext is None:
            continue
        subdir = extensions[ext]
        basename = rest
        target = archive_prefix + "/" + subdir + "/" + basename
        if target in seen_targets:
            raise ValueError("target already exists")
        seen_targets.add(target)
        moves.append({"from": path, "to": target})

    moves.sort(key=lambda m: m["from"])
    return {"name": contract["name"], "result": {"moves": moves}}
