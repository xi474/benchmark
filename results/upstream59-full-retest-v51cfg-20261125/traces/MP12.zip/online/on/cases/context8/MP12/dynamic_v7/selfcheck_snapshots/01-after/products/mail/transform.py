import datetime


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    emails = data["emails"]
    month = data["month"]
    trash_keyword = data["trash_keyword"]

    # validate month format
    try:
        datetime.date.fromisoformat(month + "-01")
    except ValueError:
        raise ValueError("invalid month")

    trash_ids = []
    for email in emails:
        date = email["date"]
        try:
            datetime.date.fromisoformat(date)
        except ValueError:
            raise ValueError("invalid date")
        if date.startswith(month) and trash_keyword in email["subject"].casefold() and email["folder"] != "TRASH":
            trash_ids.append(email["id"])

    trash_ids.sort()
    return {"name": contract["name"], "result": {"trash_ids": trash_ids}}
