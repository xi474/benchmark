def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    emails = data["emails"]
    reply_email_id = data["reply_email_id"]
    manager = data["manager"]
    reply_text = data["reply_text"]

    target = None
    for email in emails:
        if email["id"] == reply_email_id:
            target = email
            break
    if target is None:
        raise ValueError("reply target not found")
    if target["sender"] != manager:
        raise ValueError("reply target sender mismatch")

    return {
        "name": contract["name"],
        "result": {
            "email_id": reply_email_id,
            "thread_id": target["thread_id"],
            "to": manager,
            "text": reply_text,
        },
    }
