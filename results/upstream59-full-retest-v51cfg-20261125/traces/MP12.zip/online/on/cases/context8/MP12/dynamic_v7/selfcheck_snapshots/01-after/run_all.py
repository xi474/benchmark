import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _contracts():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    return contracts


def _topo_order(contracts):
    # Map output path -> contract that produces it.
    producer = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        producer[ROOT / c['output']] = cp

    order = []
    visited = set()
    visiting = set()

    def visit(cp):
        if cp in visited:
            return
        if cp in visiting:
            raise ValueError('cycle in component dependencies')
        visiting.add(cp)
        c = json.loads(cp.read_text(encoding='utf-8'))
        for inp in c['inputs']:
            p = ROOT / inp
            if p in producer:
                visit(producer[p])
        visiting.discard(cp)
        visited.add(cp)
        order.append(cp)

    for cp in contracts:
        visit(cp)
    return order


def main():
    contracts = _contracts()
    if not contracts:
        raise ValueError('no contracts')
    order = _topo_order(contracts)
    for cp in order:
        subprocess.run(
            [sys.executable, str(cp.with_name('render.py'))],
            cwd=ROOT, check=True, timeout=60,
        )
    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT, check=True, timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT, check=True, timeout=60,
    )


if __name__ == '__main__':
    main()
