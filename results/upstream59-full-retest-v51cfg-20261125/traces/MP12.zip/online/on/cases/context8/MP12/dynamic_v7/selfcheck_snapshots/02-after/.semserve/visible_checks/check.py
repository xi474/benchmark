import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/files/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/mail/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/reply/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "products/commit/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestVisibleContract(unittest.TestCase):
    def test_api_boundary_probes(self):
        seeds = {
            "products/files/transform.py": {
                "download_prefix": "Downloads",
                "archive_prefix": "Archive",
                "extensions": {".png": "images"},
                "files": [{"path": "Downloads/a.png", "hex": "00"}],
            },
            "products/mail/transform.py": {
                "emails": [{"id": "e1", "date": "2026-11-01", "subject": "news", "folder": "INBOX", "sender": "s", "thread_id": "t1"}],
                "month": "2026-11",
                "trash_keyword": "news",
            },
            "products/reply/transform.py": {
                "emails": [{"id": "e1", "date": "2026-11-01", "subject": "s", "folder": "INBOX", "sender": "manager", "thread_id": "t1"}],
                "reply_email_id": "e1",
                "manager": "manager",
                "reply_text": "hi",
            },
            "products/commit/transform.py": [
                {"files": [{"path": "Downloads/a.png", "hex": "00"}], "emails": [{"id": "e1", "date": "2026-11-01", "subject": "s", "folder": "INBOX", "sender": "manager", "thread_id": "t1"}]},
                {"moves": [{"from": "Downloads/a.png", "to": "Archive/images/a.png"}]},
                {"trash_ids": []},
                {"email_id": "e1", "thread_id": "t1", "to": "manager", "text": "hi"},
            ],
        }
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            seed = seeds[target]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    check_api_boundary(
                        target, rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=[[seed], {"name": "x", "inputs": ["a"], "output": "o"}],
                        path=[0, 0],
                    )

    def test_files_archive_moves(self):
        payload = {
            "download_prefix": "Downloads",
            "archive_prefix": "Archive",
            "extensions": {".png": "images", ".jpg": "photos"},
            "files": [
                {"path": "Downloads/a.png", "hex": "00"},
                {"path": "Downloads/b.jpg", "hex": "01"},
                {"path": "Downloads/nested/c.png", "hex": "02"},
                {"path": "Downloads/keep.txt", "hex": "03"},
            ],
        }
        contract = {"name": "files", "operation": "download_archive", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/files/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "files")
        moves = result["result"]["moves"]
        self.assertEqual(
            moves,
            [
                {"from": "Downloads/a.png", "to": "Archive/images/a.png"},
                {"from": "Downloads/b.jpg", "to": "Archive/photos/b.jpg"},
            ],
        )

    def test_mail_trash_selection(self):
        payload = {
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "Newsletter", "folder": "INBOX", "sender": "s", "thread_id": "t1"},
                {"id": "e2", "date": "2026-11-02", "subject": "news", "folder": "TRASH", "sender": "s", "thread_id": "t2"},
                {"id": "e3", "date": "2026-10-01", "subject": "news", "folder": "INBOX", "sender": "s", "thread_id": "t3"},
                {"id": "e4", "date": "2026-11-03", "subject": "NEWS", "folder": "INBOX", "sender": "s", "thread_id": "t4"},
            ],
            "month": "2026-11",
            "trash_keyword": "news",
        }
        contract = {"name": "mail", "operation": "mail_trash", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/mail/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["trash_ids"], ["e1", "e4"])

    def test_reply_target(self):
        payload = {
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "s", "folder": "INBOX", "sender": "manager", "thread_id": "t1"},
                {"id": "e2", "date": "2026-11-02", "subject": "s", "folder": "INBOX", "sender": "other", "thread_id": "t2"},
            ],
            "reply_email_id": "e1",
            "manager": "manager",
            "reply_text": "",
        }
        contract = {"name": "reply", "operation": "manager_reply", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/reply/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(
            result["result"],
            {"email_id": "e1", "thread_id": "t1", "to": "manager", "text": ""},
        )

    def test_reply_sender_mismatch_raises(self):
        payload = {
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "s", "folder": "INBOX", "sender": "other", "thread_id": "t1"},
            ],
            "reply_email_id": "e1",
            "manager": "manager",
            "reply_text": "hi",
        }
        contract = {"name": "reply", "operation": "manager_reply", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/reply/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")

    def test_commit_conflict_raises(self):
        snapshot = {
            "files": [{"path": "Downloads/a.png", "hex": "00"}],
            "emails": [{"id": "e1", "date": "2026-11-01", "subject": "s", "folder": "INBOX", "sender": "manager", "thread_id": "t1"}],
        }
        files_result = {"moves": [{"from": "Downloads/a.png", "to": "Archive/images/a.png"}]}
        mail_result = {"trash_ids": ["e1"]}
        reply_result = {"email_id": "e1", "thread_id": "t1", "to": "manager", "text": "hi"}
        contract = {"name": "commit", "operation": "workspace_commit", "inputs": ["a", "b", "c", "d"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate(
                "products/commit/transform.py", "transform",
                args=[[snapshot, files_result, mail_result, reply_result], contract],
            )
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")

    def test_commit_replay(self):
        snapshot = {
            "files": [
                {"path": "Downloads/a.png", "hex": "00"},
                {"path": "Downloads/keep.txt", "hex": "03"},
            ],
            "emails": [
                {"id": "e1", "date": "2026-11-01", "subject": "s", "folder": "INBOX", "sender": "manager", "thread_id": "t1"},
                {"id": "e2", "date": "2026-11-02", "subject": "s", "folder": "INBOX", "sender": "other", "thread_id": "t2"},
            ],
        }
        files_result = {"moves": [{"from": "Downloads/a.png", "to": "Archive/images/a.png"}]}
        mail_result = {"trash_ids": ["e2"]}
        reply_result = {"email_id": "e1", "thread_id": "t1", "to": "manager", "text": "hi"}
        contract = {"name": "commit", "operation": "workspace_commit", "inputs": ["a", "b", "c", "d"], "output": "y"}
        result = call_candidate(
            "products/commit/transform.py", "transform",
            args=[[snapshot, files_result, mail_result, reply_result], contract],
        )
        r = result["result"]
        self.assertEqual(
            r["files"],
            [
                {"path": "Archive/images/a.png", "hex": "00"},
                {"path": "Downloads/keep.txt", "hex": "03"},
            ],
        )
        folders = {e["id"]: e["folder"] for e in r["emails"]}
        self.assertEqual(folders["e1"], "INBOX")
        self.assertEqual(folders["e2"], "TRASH")
        self.assertEqual(r["reply"], reply_result)


if __name__ == "__main__":
    unittest.main()
