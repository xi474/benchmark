def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    records = data["records"]
    vocabulary = data["vocabulary"]

    # group non-null categories by key
    groups = {}
    for rec in records:
        key = rec["key"]
        cat = rec["category"]
        if cat is None:
            continue
        groups.setdefault(key, set()).add(cat)

    rows = []
    for key in sorted(groups):
        cats = groups[key]
        values = {word: (word in cats) for word in vocabulary}
        rows.append({"key": key, "values": values})

    return {"name": contract["name"], "result": {"rows": rows}}
