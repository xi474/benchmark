import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    records = data["records"]
    vocabulary = data["vocabulary"]

    # validate records
    ids = set()
    for r in records:
        rid = r["id"]
        if rid in ids:
            raise ValueError("duplicate record id")
        ids.add(rid)

    groups = {}
    for r in records:
        key = r["key"]
        value = r["value"]
        if value is not None and not _is_finite_number(value):
            raise ValueError("value must be finite number or null")
        g = groups.setdefault(key, {"count": 0, "sum": 0})
        if value is not None:
            g["count"] += 1
            g["sum"] += value

    rows = []
    for key in sorted(groups):
        g = groups[key]
        mean = g["sum"] / g["count"] if g["count"] else None
        rows.append({"key": key, "values": {"count": g["count"], "sum": g["sum"], "mean": mean}})

    return {"name": contract["name"], "result": {"rows": rows}}
