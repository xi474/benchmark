def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    records = payload["records"]
    vocabulary = payload["vocabulary"]

    groups = {}
    for rec in records:
        key = rec["key"]
        t = rec["time"]
        if t is None:
            continue
        groups.setdefault(key, []).append(t)

    rows = []
    for key in sorted(groups):
        times = groups[key]
        first = min(times)
        last = max(times)
        rows.append({"key": key, "values": {"first": first, "last": last, "span": last - first}})

    return {"name": contract["name"], "result": {"rows": rows}}
