def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    branches = []
    for prefix, payload in zip(("num.", "cat.", "time."), payloads):
        result = _unwrap(payload)
        rows = result["rows"]
        branch = {}
        for row in rows:
            key = row["key"]
            values = row["values"]
            branch[key] = {prefix + col: val for col, val in values.items()}
        branches.append(branch)

    all_keys = set()
    for branch in branches:
        all_keys.update(branch.keys())

    columns = set()
    for branch in branches:
        for values in branch.values():
            columns.update(values.keys())

    columns = sorted(columns)
    index = sorted(all_keys)

    data = []
    for key in index:
        row = []
        for col in columns:
            val = None
            for branch in branches:
                if key in branch and col in branch[key]:
                    val = branch[key][col]
                    break
            row.append(val)
        data.append(row)

    return {"name": contract["name"], "result": {"index": index, "columns": columns, "data": data}}
