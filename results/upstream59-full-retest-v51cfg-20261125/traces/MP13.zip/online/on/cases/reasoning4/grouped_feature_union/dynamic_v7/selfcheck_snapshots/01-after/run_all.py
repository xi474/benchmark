import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        if name in contracts:
            raise ValueError("duplicate component name: %s" % name)
        contracts[name] = {"path": cp, "contract": c}
    if not contracts:
        raise ValueError("no contracts found")
    return contracts


def _topo_order(contracts):
    # Build dependency graph: component depends on components that produce its inputs.
    # Map output path -> component name.
    output_to_name = {}
    for name, info in contracts.items():
        out = info["contract"]["output"]
        if out in output_to_name:
            raise ValueError("duplicate output path: %s" % out)
        output_to_name[out] = name

    deps = {}
    for name, info in contracts.items():
        d = set()
        for inp in info["contract"]["inputs"]:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[name] = d

    # Kahn's algorithm for topological sort.
    order = []
    remaining = set(contracts)
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError("cycle or missing dependency detected")
        ready.sort()
        for n in ready:
            order.append(n)
            remaining.discard(n)
    return order


def main():
    contracts = _load_contracts()
    order = _topo_order(contracts)

    for name in order:
        info = contracts[name]
        cp = info["path"]
        render = cp.with_name("render.py")
        if not render.is_file():
            raise ValueError("missing render.py for %s" % name)
        subprocess.run(
            [sys.executable, str(render), str(ROOT), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    # Run the integrator to produce core_manifest.json.
    integrate = ROOT / "integrate.py"
    if not integrate.is_file():
        raise ValueError("missing integrate.py")
    subprocess.run(
        [sys.executable, str(integrate)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    # Produce the final report from the core manifest.
    final_report = ROOT / "final_report.py"
    if not final_report.is_file():
        raise ValueError("missing final_report.py")
    subprocess.run(
        [sys.executable, str(final_report)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
