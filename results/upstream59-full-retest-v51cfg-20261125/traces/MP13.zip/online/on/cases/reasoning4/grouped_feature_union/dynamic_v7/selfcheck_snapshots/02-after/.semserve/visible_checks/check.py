import unittest

# Injected by the SDK runner; do not import.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception with details dict

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/numeric/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/category/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/time/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/union/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        numeric_payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 10, "category": "x", "time": 1},
            ],
            "vocabulary": ["x"],
        }
        numeric_contract = {"name": "numeric", "operation": "numeric_features",
                            "inputs": ["inputs/case.json"], "output": "outputs/numeric.json"}
        category_payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 10, "category": "red", "time": 1},
            ],
            "vocabulary": ["red"],
        }
        category_contract = {"name": "category", "operation": "category_features",
                             "inputs": ["inputs/case.json"], "output": "outputs/category.json"}
        time_payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 10, "category": "x", "time": 1},
            ],
            "vocabulary": ["x"],
        }
        time_contract = {"name": "time", "operation": "time_features",
                         "inputs": ["inputs/case.json"], "output": "outputs/time.json"}
        union_payloads = [
            {"name": "numeric", "result": {"rows": [
                {"key": "g1", "values": {"count": 1, "sum": 10, "mean": 10.0}}]}},
            {"name": "category", "result": {"rows": [
                {"key": "g1", "values": {"red": True}}]}},
            {"name": "time", "result": {"rows": [
                {"key": "g1", "values": {"first": 1, "last": 1, "span": 0}}]}},
        ]
        union_contract = {"name": "union", "operation": "feature_union",
                          "inputs": ["outputs/numeric.json", "outputs/category.json",
                                     "outputs/time.json"], "output": "outputs/union.json"}

        probes = [
            ("engines/numeric/transform.py", "nonfinite_unknown_field",
             "未知额外字段可忽略，但其中非有限JSON仍非法。",
             [numeric_payload, numeric_contract]),
            ("engines/numeric/transform.py", "invalid_payload_type",
             "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
             [numeric_payload, numeric_contract]),
            ("engines/category/transform.py", "nonfinite_unknown_field",
             "未知额外字段可忽略，但其中非有限JSON仍非法。",
             [category_payload, category_contract]),
            ("engines/category/transform.py", "invalid_payload_type",
             "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
             [category_payload, category_contract]),
            ("engines/time/transform.py", "nonfinite_unknown_field",
             "未知额外字段可忽略，但其中非有限JSON仍非法。",
             [time_payload, time_contract]),
            ("engines/time/transform.py", "invalid_payload_type",
             "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
             [time_payload, time_contract]),
            ("engines/union/transform.py", "nonfinite_unknown_field",
             "未知额外字段可忽略，但其中非有限JSON仍非法。",
             [union_payloads, union_contract]),
            ("engines/union/transform.py", "invalid_payload_type",
             "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
             [union_payloads, union_contract]),
        ]
        for target, rule, quote, args in probes:
            with self.subTest(target=target, rule=rule):
                check_api_boundary(target, rule=rule, contract_path="README.md",
                                   requirement_quote=quote, args=args)


class TestNumericTransform(unittest.TestCase):
    def test_numeric_features_hand_computed(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 10, "category": "x", "time": 1},
                {"id": "b", "key": "g1", "value": 20, "category": "y", "time": 2},
                {"id": "c", "key": "g2", "value": None, "category": None, "time": None},
            ],
            "vocabulary": ["x", "y"],
        }
        contract = {"name": "numeric", "operation": "numeric_features",
                    "inputs": ["inputs/case.json"], "output": "outputs/numeric.json"}
        result = call_candidate("engines/numeric/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "numeric")
        rows = result["result"]["rows"]
        self.assertEqual([r["key"] for r in rows], ["g1", "g2"])
        self.assertEqual(rows[0]["values"], {"count": 2, "sum": 30, "mean": 15.0})
        self.assertEqual(rows[1]["values"], {"count": 0, "sum": 0, "mean": None})

    def test_numeric_duplicate_id_raises(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 1, "category": "x", "time": 1},
                {"id": "a", "key": "g1", "value": 2, "category": "y", "time": 2},
            ],
            "vocabulary": ["x"],
        }
        contract = {"name": "numeric", "operation": "numeric_features",
                    "inputs": ["inputs/case.json"], "output": "outputs/numeric.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("engines/numeric/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestCategoryTransform(unittest.TestCase):
    def test_category_features_hand_computed(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 1, "category": "red", "time": 1},
                {"id": "b", "key": "g1", "value": 2, "category": "blue", "time": 2},
                {"id": "c", "key": "g2", "value": 3, "category": None, "time": 3},
            ],
            "vocabulary": ["red", "blue"],
        }
        contract = {"name": "category", "operation": "category_features",
                    "inputs": ["inputs/case.json"], "output": "outputs/category.json"}
        result = call_candidate("engines/category/transform.py", "transform",
                                args=[[payload], contract])
        rows = result["result"]["rows"]
        self.assertEqual([r["key"] for r in rows], ["g1"])
        self.assertEqual(rows[0]["values"], {"red": True, "blue": True})


class TestTimeTransform(unittest.TestCase):
    def test_time_features_hand_computed(self):
        payload = {
            "records": [
                {"id": "a", "key": "g1", "value": 1, "category": "x", "time": 5},
                {"id": "b", "key": "g1", "value": 2, "category": "y", "time": -3},
                {"id": "c", "key": "g2", "value": 3, "category": "z", "time": None},
            ],
            "vocabulary": ["x"],
        }
        contract = {"name": "time", "operation": "time_features",
                    "inputs": ["inputs/case.json"], "output": "outputs/time.json"}
        result = call_candidate("engines/time/transform.py", "transform",
                                args=[[payload], contract])
        rows = result["result"]["rows"]
        self.assertEqual([r["key"] for r in rows], ["g1"])
        self.assertEqual(rows[0]["values"], {"first": -3, "last": 5, "span": 8})


class TestUnionTransform(unittest.TestCase):
    def test_union_outer_join(self):
        num = {"name": "numeric", "result": {"rows": [
            {"key": "g1", "values": {"count": 1, "sum": 5, "mean": 5.0}},
            {"key": "g2", "values": {"count": 0, "sum": 0, "mean": None}},
        ]}}
        cat = {"name": "category", "result": {"rows": [
            {"key": "g1", "values": {"red": True, "blue": False}},
        ]}}
        time = {"name": "time", "result": {"rows": [
            {"key": "g2", "values": {"first": 1, "last": 2, "span": 1}},
        ]}}
        contract = {"name": "union", "operation": "feature_union",
                    "inputs": ["outputs/numeric.json", "outputs/category.json",
                               "outputs/time.json"], "output": "outputs/union.json"}
        result = call_candidate("engines/union/transform.py", "transform",
                                args=[[num, cat, time], contract])
        r = result["result"]
        self.assertEqual(r["index"], ["g1", "g2"])
        self.assertEqual(r["columns"], ["cat.blue", "cat.red", "num.count",
                                        "num.mean", "num.sum", "time.first",
                                        "time.last", "time.span"])
        # g1 row: cat present, num present, time absent -> nulls
        self.assertEqual(r["data"][0], [False, True, 1, 5.0, 5, None, None, None])
        # g2 row: cat absent, num present, time present
        self.assertEqual(r["data"][1], [None, None, 0, None, 0, 1, 2, 1])


if __name__ == "__main__":
    unittest.main()
