import json
from pathlib import Path


def _check_finite(value, path):
    if isinstance(value, float) and (value != value or value in (float('inf'), float('-inf'))):
        raise ValueError(f"non-finite number at {path}")
    if isinstance(value, list):
        for i, v in enumerate(value):
            _check_finite(v, f"{path}[{i}]")
    elif isinstance(value, dict):
        for k, v in value.items():
            _check_finite(v, f"{path}.{k}")


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text, parse_constant=lambda s: (_ for _ in ()).throw(ValueError(f"invalid constant {s}")))
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"invalid JSON: {e}")
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data, "$")
    return data
