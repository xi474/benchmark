def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    # unwrap name/result wrapper if present
    if isinstance(payload, dict) and set(payload) == {'name', 'result'}:
        payload = payload['result']
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'root' not in payload or 'nodes' not in payload:
        raise ValueError("missing root/nodes")
    root = payload['root']
    nodes = payload['nodes']
    if not isinstance(nodes, list):
        raise ValueError("nodes must be list")
    if not isinstance(root, str) or not root.strip():
        raise ValueError("root must be non-empty string")

    node_map = {}
    for n in nodes:
        if not isinstance(n, dict):
            raise ValueError("node must be object")
        for field in ('id', 'type', 'message'):
            if field not in n:
                raise ValueError(f"missing {field}")
            if not isinstance(n[field], str) or not n[field].strip():
                raise ValueError(f"{field} must be non-empty string")
        if 'cause' not in n or 'context' not in n or 'suppress_context' not in n:
            raise ValueError("missing link fields")
        if n['cause'] is not None and not isinstance(n['cause'], str):
            raise ValueError("cause must be string or null")
        if n['context'] is not None and not isinstance(n['context'], str):
            raise ValueError("context must be string or null")
        if not isinstance(n['suppress_context'], bool):
            raise ValueError("suppress_context must be bool")
        if 'frames' not in n or not isinstance(n['frames'], list):
            raise ValueError("frames must be list")
        if n['id'] in node_map:
            raise ValueError("duplicate node id")
        node_map[n['id']] = n

    if root not in node_map:
        raise ValueError("root not found")

    # follow chain from root inward
    chain = []
    seen = set()
    cur = root
    while True:
        if cur in seen:
            raise ValueError("cycle detected")
        seen.add(cur)
        if len(chain) >= 8:
            raise ValueError("chain length exceeds 8")
        node = node_map[cur]
        chain.append(node)
        cause = node['cause']
        if cause is not None:
            if cause not in node_map:
                raise ValueError("cause not found")
            cur = cause
            continue
        if not node['suppress_context'] and node['context'] is not None:
            if node['context'] not in node_map:
                raise ValueError("context not found")
            cur = node['context']
            continue
        break

    # chain is from root inward; reverse to innermost-first
    chain.reverse()
    result = []
    for i, node in enumerate(chain):
        if i == 0:
            link = None
        else:
            prev = chain[i - 1]
            if node['cause'] == prev['id']:
                link = 'cause'
            elif node['context'] == prev['id']:
                link = 'context'
            else:
                link = None
        result.append({
            'id': node['id'],
            'type': node['type'],
            'message': node['message'],
            'link': link,
        })

    return {'name': contract['name'], 'result': {'chain': result}}
