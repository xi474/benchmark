import json
import math
import os


def _serialize_locals(locals_dict):
    return json.dumps(
        locals_dict,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _normalize_file(file_value):
    if not isinstance(file_value, str):
        raise ValueError("frame file must be string")
    file_value = file_value.replace("\\", "/")
    return os.path.basename(file_value)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    nodes = payload.get("nodes")
    if not isinstance(nodes, list):
        raise ValueError("nodes must be list")

    frames = {}
    for node in nodes:
        if not isinstance(node, dict):
            raise ValueError("node must be object")
        node_id = node.get("id")
        if not isinstance(node_id, str) or not node_id.strip():
            raise ValueError("node id must be non-empty string")
        node_frames = node.get("frames")
        if not isinstance(node_frames, list):
            raise ValueError("frames must be list")

        out_frames = []
        for frame in node_frames:
            if not isinstance(frame, dict):
                raise ValueError("frame must be object")
            file_value = frame.get("file")
            line = frame.get("line")
            function = frame.get("function")
            locals_value = frame.get("locals")

            if not isinstance(line, int) or isinstance(line, bool) or line < 1:
                raise ValueError("line must be positive int")
            if not isinstance(function, str) or not function.strip():
                raise ValueError("function must be non-empty string")
            if not isinstance(locals_value, dict):
                raise ValueError("locals must be object")

            serialized_locals = {}
            for k, v in locals_value.items():
                serialized_locals[k] = _serialize_locals(v)

            out_frames.append({
                "file": _normalize_file(file_value),
                "line": line,
                "function": function,
                "locals": serialized_locals,
            })

        frames[node_id] = out_frames

    return {"name": contract["name"], "result": {"frames": frames}}
