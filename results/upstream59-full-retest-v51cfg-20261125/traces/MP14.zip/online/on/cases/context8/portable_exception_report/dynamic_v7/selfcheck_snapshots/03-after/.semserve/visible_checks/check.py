import unittest

# Injected names (no import needed).
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception with details dict

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "chain/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "frames/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "report/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundaries(unittest.TestCase):
    def test_transform_api_boundaries(self):
        for entry in API_BOUNDARY_REQUIREMENTS:
            target = entry["target_path"]
            for rule, spec in entry["rules"].items():
                with self.subTest(target=target, rule=rule):
                    if not spec["applicable"]:
                        self.skipTest(spec.get("reason", "not applicable"))
                    if target == "report/transform.py":
                        seed = [
                            {"name": "chain", "result": {"chain": [{"id": "r", "type": "T", "message": "m", "link": None}]}},
                            {"name": "frames", "result": {"frames": {"r": []}}},
                        ]
                        contract = {"name": "x", "inputs": ["a", "b"], "output": "o"}
                    else:
                        seed = [{"root": "r", "nodes": [{"id": "r", "type": "T", "message": "m", "cause": None, "context": None, "suppress_context": False, "frames": []}]}]
                        contract = {"name": "x", "inputs": ["a"], "output": "o"}
                    check_api_boundary(
                        target,
                        rule=rule,
                        contract_path=spec["contract_path"],
                        requirement_quote=spec["requirement_quote"],
                        args=[seed, contract],
                    )


class TestChainBehavior(unittest.TestCase):
    def test_chain_cycle_raises(self):
        # root -> a -> b -> a forms a cycle; must raise ValueError.
        payload = {
            "root": "a",
            "nodes": [
                {"id": "a", "type": "T", "message": "m", "cause": "b", "context": None,
                 "suppress_context": False, "frames": []},
                {"id": "b", "type": "T", "message": "m", "cause": "a", "context": None,
                 "suppress_context": False, "frames": []},
            ],
        }
        contract = {"name": "chain", "inputs": ["x"], "output": "o"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("chain/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")

    def test_chain_suppressed_context_not_followed(self):
        # cause null, context set but suppress_context True -> chain is single node.
        payload = {
            "root": "a",
            "nodes": [
                {"id": "a", "type": "T", "message": "m", "cause": None, "context": "b",
                 "suppress_context": True, "frames": []},
                {"id": "b", "type": "T", "message": "m", "cause": None, "context": None,
                 "suppress_context": False, "frames": []},
            ],
        }
        contract = {"name": "chain", "inputs": ["x"], "output": "o"}
        result = call_candidate("chain/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "chain")
        self.assertEqual([n["id"] for n in result["result"]["chain"]], ["a"])


class TestFramesBehavior(unittest.TestCase):
    def test_frames_basename_and_locals_serialization(self):
        payload = {
            "root": "a",
            "nodes": [
                {"id": "a", "type": "T", "message": "m", "cause": None, "context": None,
                 "suppress_context": False,
                 "frames": [{"file": "C:\\dir\\mod.py", "line": 5, "function": "f",
                             "locals": {"b": True, "a": 1}}]},
            ],
        }
        contract = {"name": "frames", "inputs": ["x"], "output": "o"}
        result = call_candidate("frames/transform.py", "transform", args=[[payload], contract])
        fr = result["result"]["frames"]["a"][0]
        self.assertEqual(fr["file"], "mod.py")
        self.assertEqual(fr["line"], 5)
        self.assertEqual(fr["function"], "f")
        # each local value serialized to canonical JSON string (keys sorted, compact)
        self.assertEqual(fr["locals"], {"a": "1", "b": "true"})


class TestReportBehavior(unittest.TestCase):
    def test_report_text_and_nodes(self):
        chain = {"name": "chain", "result": {"chain": [
            {"id": "inner", "type": "KeyError", "message": "k", "link": None},
            {"id": "outer", "type": "RuntimeError", "message": "f", "link": "cause"},
        ]}}
        frames = {"name": "frames", "result": {"frames": {
            "inner": [{"file": "m.py", "line": 3, "function": "lookup", "locals": {}}],
            "outer": [{"file": "a.py", "line": 8, "function": "run", "locals": {}}],
        }}}
        contract = {"name": "report", "inputs": ["c", "f"], "output": "o"}
        result = call_candidate("report/transform.py", "transform", args=[[chain, frames], contract])
        self.assertEqual(result["result"]["text"],
                         "  m.py:3 in lookup\nKeyError: k\n--- direct cause ---\n  a.py:8 in run\nRuntimeError: f\n")
        self.assertEqual([n["id"] for n in result["result"]["nodes"]], ["inner", "outer"])


if __name__ == "__main__":
    unittest.main()
