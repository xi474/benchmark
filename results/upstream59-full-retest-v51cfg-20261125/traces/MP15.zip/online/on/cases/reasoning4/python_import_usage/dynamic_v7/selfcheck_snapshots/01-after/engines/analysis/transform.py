import ast


def _business(payload):
    """Unwrap {name, result} envelopes to their business input."""
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _collect_imports(tree):
    """Return list of import dicts {scope, name, module, line}."""
    imports = []
    seen = set()

    def add(scope, name, module, line):
        key = (scope, name)
        if key in seen:
            raise ValueError("duplicate import binding %s:%s" % key)
        seen.add(key)
        imports.append({"scope": scope, "name": name, "module": module, "line": line})

    def walk(node, scope):
        if isinstance(node, ast.FunctionDef):
            for stmt in node.body:
                walk(stmt, node.name)
            return
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.asname or alias.name.split(".")[0]
                add(scope, name, alias.name, node.lineno)
            return
        if isinstance(node, ast.ImportFrom):
            if node.level != 0:
                raise ValueError("relative import not supported")
            for alias in node.names:
                if alias.name == "*":
                    raise ValueError("star import not supported")
                name = alias.asname or alias.name
                module = (node.module + "." + alias.name) if node.module else alias.name
                add(scope, name, module, node.lineno)
            return
        for child in ast.iter_child_nodes(node):
            walk(child, scope)

    for stmt in tree.body:
        walk(stmt, "module")
    return imports


def _collect_stores(tree):
    """Return dict scope -> set of names bound by parameters or Store targets."""
    stores = {}

    def walk(node, scope):
        if isinstance(node, ast.FunctionDef):
            names = set()
            for a in (
                node.args.posonlyargs
                + node.args.args
                + node.args.kwonlyargs
            ):
                names.add(a.arg)
            if node.args.vararg is not None:
                names.add(node.args.vararg.arg)
            if node.args.kwarg is not None:
                names.add(node.args.kwarg.arg)
            stores.setdefault(node.name, set()).update(names)
            for stmt in node.body:
                walk(stmt, node.name)
            return
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            stores.setdefault(scope, set()).add(node.id)
        for child in ast.iter_child_nodes(node):
            walk(child, scope)

    for stmt in tree.body:
        walk(stmt, "module")
    return stores


def transform(payloads, contract):
    if not isinstance(payloads, list) or not isinstance(contract, dict):
        raise ValueError("bad arguments")
    if "inputs" not in contract or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    source = _business(payloads[0])["source"]
    ordinary_uses = _business(payloads[1]).get("uses", [])
    annotation_uses = _business(payloads[2]).get("uses", [])
    comment_uses = _business(payloads[3]).get("uses", [])

    tree = ast.parse(source)
    imports = _collect_imports(tree)
    stores = _collect_stores(tree)

    imports_by_scope = {}
    for imp in imports:
        imports_by_scope.setdefault(imp["scope"], {})[imp["name"]] = imp

    def resolve(scope, name):
        local = imports_by_scope.get(scope, {}).get(name)
        if local is not None:
            return local
        if name in stores.get(scope, set()):
            return None
        return imports_by_scope.get("module", {}).get(name)

    used = {id(imp): set() for imp in imports}
    for category, uses in (
        ("ordinary", ordinary_uses),
        ("annotation", annotation_uses),
        ("comment", comment_uses),
    ):
        for u in uses:
            imp = resolve(u["scope"], u["name"])
            if imp is not None:
                used[id(imp)].add(category)

    order = ["ordinary", "annotation", "comment"]
    result_imports = []
    for imp in sorted(imports, key=lambda x: (x["scope"], x["line"], x["name"])):
        cats = used[id(imp)]
        result_imports.append(
            {
                "scope": imp["scope"],
                "name": imp["name"],
                "module": imp["module"],
                "line": imp["line"],
                "used_by": [c for c in order if c in cats],
            }
        )

    unused = sorted(
        "%s:%s" % (imp["scope"], imp["name"]) for imp in imports if not used[id(imp)]
    )

    return {
        "name": contract["name"],
        "result": {"imports": result_imports, "unused": unused},
    }
