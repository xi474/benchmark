import ast


def _collect_load_names(node):
    """Collect Name nodes loaded (not stored) in an expression AST."""
    names = []
    for n in ast.walk(node):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            names.append(n.id)
    return names


def _annotation_names(annotation, lineno):
    """Return list of Load names in an annotation expression.

    If the annotation is an outermost string literal, re-parse it as a
    Python expression (forward reference). Bad expression raises ValueError.
    """
    if annotation is None:
        return []
    if isinstance(annotation, ast.Constant) and isinstance(annotation.value, str):
        try:
            expr = ast.parse(annotation.value, mode="eval")
        except SyntaxError as exc:
            raise ValueError("bad forward annotation") from exc
        return _collect_load_names(expr)
    return _collect_load_names(annotation)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source")
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")

    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise ValueError("invalid source") from exc

    uses = []

    # Map from function node -> function name for scope resolution.
    # Only module-level ordinary functions are supported.
    func_names = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            func_names[id(node)] = node.name

    def scope_for(node):
        # Walk up to find enclosing function.
        for fn_id, name in func_names.items():
            fn = next((n for n in tree.body if id(n) == fn_id), None)
            if fn is not None and _contains(fn, node):
                return name
        return "module"

    # Collect annotations: AnnAssign.annotation, function args/returns.
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign):
            scope = scope_for(node)
            names = _annotation_names(node.annotation, node.lineno)
            for name in names:
                uses.append({"scope": scope, "name": name, "line": node.lineno})
        elif isinstance(node, ast.FunctionDef):
            # Function signature annotations belong to module scope.
            for arg in node.args.args + node.args.kwonlyargs:
                if arg.annotation is not None:
                    names = _annotation_names(arg.annotation, arg.lineno)
                    for name in names:
                        uses.append({"scope": "module", "name": name, "line": arg.lineno})
            if node.args.vararg is not None and node.args.vararg.annotation is not None:
                names = _annotation_names(node.args.vararg.annotation, node.args.vararg.lineno)
                for name in names:
                    uses.append({"scope": "module", "name": name, "line": node.args.vararg.lineno})
            if node.args.kwarg is not None and node.args.kwarg.annotation is not None:
                names = _annotation_names(node.args.kwarg.annotation, node.args.kwarg.lineno)
                for name in names:
                    uses.append({"scope": "module", "name": name, "line": node.args.kwarg.lineno})
            if node.returns is not None:
                names = _annotation_names(node.returns, node.returns.lineno)
                for name in names:
                    uses.append({"scope": "module", "name": name, "line": node.returns.lineno})

    # Deduplicate by (scope, line, name) and sort.
    seen = set()
    result = []
    for u in uses:
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            result.append(u)
    result.sort(key=lambda u: (u["scope"], u["line"], u["name"]))

    return {"name": contract["name"], "result": {"uses": result}}


def _contains(fn, node):
    """Return True if node is within fn's body (not just signature)."""
    for child in ast.walk(fn):
        if child is node:
            return True
    return False
