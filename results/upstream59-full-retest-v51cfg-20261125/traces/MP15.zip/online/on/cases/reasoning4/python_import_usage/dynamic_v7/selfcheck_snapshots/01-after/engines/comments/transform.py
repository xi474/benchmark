import ast


def _load_names(node):
    """Return list of Load names in an expression node."""
    names = []
    for n in ast.walk(node):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            names.append(n.id)
    return names


def _scope_of(node, funcs):
    """Determine scope for a statement node: module or enclosing function name."""
    for fname, fnode in funcs:
        if node is fnode or _contains(fnode, node):
            return fname
    return "module"


def _contains(parent, child):
    for n in ast.walk(parent):
        if n is child:
            return True
    return False


def transform(payloads, contract):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    if not isinstance(contract, dict):
        raise ValueError("contract must be a dict")
    if "inputs" not in contract or not isinstance(contract["inputs"], list):
        raise ValueError("contract missing inputs")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source")
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")

    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as exc:
        raise ValueError("bad source") from exc

    # Collect top-level function definitions (module-level, non-nested).
    funcs = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            funcs.append((node.name, node))

    uses = []
    for node in ast.walk(tree):
        tc = getattr(node, "type_comment", None)
        if not tc:
            continue
        if isinstance(node, (ast.FunctionDef, ast.For, ast.With)):
            raise ValueError("unsupported type comment")
        if isinstance(node, ast.Assign):
            # type_comment on Assign is the "# type: expr" text.
            expr_text = tc
            try:
                expr = ast.parse(expr_text, mode="eval").body
            except SyntaxError as exc:
                raise ValueError("bad type comment") from exc
            scope = _scope_of(node, funcs)
            for name in _load_names(expr):
                uses.append({"scope": scope, "name": name, "line": node.lineno})

    # Deduplicate and sort by (scope, line, name).
    seen = set()
    result = []
    for u in sorted(uses, key=lambda x: (x["scope"], x["line"], x["name"])):
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            result.append(u)

    return {"name": contract["name"], "result": {"uses": result}}
