import ast


def _load_names(node, scope, line, out):
    """Collect Load-context Name ids from an expression node."""
    for n in ast.walk(node):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            out.append((scope, n.id, line))


def _uses_from_source(source):
    """Return list of (scope, name, line) for ordinary Load names."""
    tree = ast.parse(source)
    uses = []

    # Validate: only module-level statements and plain functions allowed.
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            _validate_function(node)
        elif isinstance(node, (ast.ClassDef, ast.AsyncFunctionDef)):
            raise ValueError("unsupported construct")

    # Module scope: decorators and default values of functions, plus
    # module-level statements (excluding annotations and type comments).
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            # decorators and defaults are module scope
            for dec in node.decorator_list:
                _load_names(dec, "module", dec.lineno, uses)
            for d in node.args.defaults:
                _load_names(d, "module", d.lineno, uses)
            for d in node.args.kw_defaults:
                if d is not None:
                    _load_names(d, "module", d.lineno, uses)
        else:
            _collect_stmt(node, "module", uses)

    # Function bodies.
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            for stmt in node.body:
                _collect_stmt(stmt, node.name, uses)

    return uses


def _validate_function(node):
    for dec in node.decorator_list:
        if isinstance(dec, ast.Name) and dec.id in ("staticmethod", "classmethod"):
            raise ValueError("unsupported construct")
    for stmt in node.body:
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            raise ValueError("nested definition not supported")


def _collect_stmt(stmt, scope, uses):
    """Collect Load names from a statement, excluding annotations/type comments."""
    if isinstance(stmt, ast.AnnAssign):
        # value only (annotation excluded)
        if stmt.value is not None:
            _load_names(stmt.value, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.Assign):
        for t in stmt.targets:
            _load_names(t, scope, stmt.lineno, uses)
        _load_names(stmt.value, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.AugAssign):
        _load_names(stmt.target, scope, stmt.lineno, uses)
        _load_names(stmt.value, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.Expr):
        _load_names(stmt.value, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.Return):
        if stmt.value is not None:
            _load_names(stmt.value, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.If):
        _load_names(stmt.test, scope, stmt.lineno, uses)
        for s in stmt.body:
            _collect_stmt(s, scope, uses)
        for s in stmt.orelse:
            _collect_stmt(s, scope, uses)
    elif isinstance(stmt, ast.While):
        _load_names(stmt.test, scope, stmt.lineno, uses)
        for s in stmt.body:
            _collect_stmt(s, scope, uses)
        for s in stmt.orelse:
            _collect_stmt(s, scope, uses)
    elif isinstance(stmt, ast.For):
        _load_names(stmt.iter, scope, stmt.lineno, uses)
        for s in stmt.body:
            _collect_stmt(s, scope, uses)
        for s in stmt.orelse:
            _collect_stmt(s, scope, uses)
    elif isinstance(stmt, ast.With):
        for item in stmt.items:
            _load_names(item.context_expr, scope, stmt.lineno, uses)
        for s in stmt.body:
            _collect_stmt(s, scope, uses)
    elif isinstance(stmt, ast.Assert):
        _load_names(stmt.test, scope, stmt.lineno, uses)
        if stmt.msg is not None:
            _load_names(stmt.msg, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.Delete):
        for t in stmt.targets:
            _load_names(t, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.Raise):
        if stmt.exc is not None:
            _load_names(stmt.exc, scope, stmt.lineno, uses)
        if stmt.cause is not None:
            _load_names(stmt.cause, scope, stmt.lineno, uses)
    elif isinstance(stmt, ast.Try):
        for s in stmt.body:
            _collect_stmt(s, scope, uses)
        for h in stmt.handlers:
            if h.type is not None:
                _load_names(h.type, scope, h.lineno, uses)
            for s in h.body:
                _collect_stmt(s, scope, uses)
        for s in stmt.orelse:
            _collect_stmt(s, scope, uses)
        for s in stmt.finalbody:
            _collect_stmt(s, scope, uses)
    elif isinstance(stmt, ast.Global):
        raise ValueError("global not supported")
    elif isinstance(stmt, ast.Nonlocal):
        raise ValueError("nonlocal not supported")
    elif isinstance(stmt, ast.Import):
        # import names are not Load uses
        pass
    elif isinstance(stmt, ast.ImportFrom):
        pass
    elif isinstance(stmt, ast.Pass) or isinstance(stmt, ast.Break) or isinstance(stmt, ast.Continue):
        pass
    else:
        # generic fallback: walk for Load names
        _load_names(stmt, scope, stmt.lineno, uses)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    source = payloads[0]["source"]
    uses = _uses_from_source(source)
    # dedupe and sort by (scope, line, name)
    seen = set()
    result = []
    for scope, name, line in uses:
        key = (scope, line, name)
        if key in seen:
            continue
        seen.add(key)
        result.append({"scope": scope, "name": name, "line": line})
    result.sort(key=lambda x: (x["scope"], x["line"], x["name"]))
    return {"name": contract["name"], "result": {"uses": result}}
