import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts.append((cp, c))
    return contracts


def _topo_sort(contracts):
    # contracts: list of (contract_path, contract_dict)
    # Build dependency graph: a component depends on any component whose
    # output appears in its inputs.
    by_name = {}
    for cp, c in contracts:
        by_name[c['name']] = (cp, c)

    # Map output path -> producing component name
    output_owner = {}
    for cp, c in contracts:
        output_owner[c['output']] = c['name']

    # Build edges: component -> set of components it depends on
    deps = {}
    for cp, c in contracts:
        d = set()
        for inp in c['inputs']:
            if inp in output_owner:
                d.add(output_owner[inp])
        deps[c['name']] = d

    # Topological sort (Kahn's algorithm)
    result = []
    remaining = set(deps.keys())
    while remaining:
        ready = [n for n in remaining if not (deps[n] & remaining)]
        if not ready:
            raise ValueError('dependency cycle detected')
        ready.sort()
        for n in ready:
            result.append(n)
            remaining.discard(n)
    return [by_name[n] for n in result]


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError('no contracts')
    ordered = _topo_sort(contracts)
    for cp, c in ordered:
        render = cp.with_name('render.py')
        subprocess.run(
            [sys.executable, str(render), str(cp)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )
    # Run the integrator to produce core_manifest.json
    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        check=True,
        timeout=60,
    )
    # Produce the final report from the core manifest
    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == '__main__':
    main()
