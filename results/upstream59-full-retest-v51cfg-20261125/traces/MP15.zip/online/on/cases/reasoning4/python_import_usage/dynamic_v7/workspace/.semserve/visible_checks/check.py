import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> raised for candidate exceptions

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/ordinary/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/annotations/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/comments/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/analysis/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestOrdinaryUses(unittest.TestCase):
    def test_ordinary_uses_expected(self):
        # Public rule: ordinary Load names, excluding annotations/type comments.
        payload = {"source": "import os\nx = os.path.join('a','b')\n"}
        contract = {"name": "ordinary", "operation": "ordinary_uses",
                    "inputs": ["inputs/case.json"], "output": "outputs/ordinary.json"}
        result = call_candidate("engines/ordinary/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "ordinary")
        uses = result["result"]["uses"]
        self.assertEqual(uses, [{"scope": "module", "name": "os", "line": 2}])

    def test_ordinary_excludes_annotation(self):
        # Annotation names must not appear in ordinary uses.
        payload = {"source": "import typing\nx: typing.List[int] = []\n"}
        contract = {"name": "ordinary", "operation": "ordinary_uses",
                    "inputs": ["inputs/case.json"], "output": "outputs/ordinary.json"}
        result = call_candidate("engines/ordinary/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["uses"], [])


class TestAnnotationsUses(unittest.TestCase):
    def test_annotation_forward_ref(self):
        # Outermost string forward annotation re-parsed as expression.
        payload = {"source": "from typing import List\nx: 'List[int]' = []\n"}
        contract = {"name": "annotations", "operation": "annotation_uses",
                    "inputs": ["inputs/case.json"], "output": "outputs/annotations.json"}
        result = call_candidate("engines/annotations/transform.py", "transform",
                                args=[[payload], contract])
        uses = result["result"]["uses"]
        names = sorted((u["name"], u["scope"]) for u in uses)
        self.assertIn(("List", "module"), names)
        self.assertIn(("int", "module"), names)


class TestCommentsUses(unittest.TestCase):
    def test_type_comment_uses(self):
        # Assign # type: expression produces Load names at the assign line.
        payload = {"source": "import abc\nX = None  # type: abc.ABC\n"}
        contract = {"name": "comments", "operation": "type_comment_uses",
                    "inputs": ["inputs/case.json"], "output": "outputs/comments.json"}
        result = call_candidate("engines/comments/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["uses"],
                         [{"scope": "module", "name": "abc", "line": 2}])


class TestAnalysisJoin(unittest.TestCase):
    def test_analysis_unused_import(self):
        # import os unused -> appears in unused list.
        source = {"source": "import os\nimport json as j\nx = j.dumps({})\n"}
        ordinary = {"uses": [{"scope": "module", "name": "j", "line": 3}]}
        annotations = {"uses": []}
        comments = {"uses": []}
        contract = {"name": "analysis", "operation": "import_usage_join",
                    "inputs": ["inputs/case.json", "outputs/ordinary.json",
                               "outputs/annotations.json", "outputs/comments.json"],
                    "output": "outputs/analysis.json"}
        result = call_candidate("engines/analysis/transform.py", "transform",
                                args=[[source, ordinary, annotations, comments], contract])
        self.assertEqual(result["result"]["unused"], ["module:os"])


class TestApiBoundaries(unittest.TestCase):
    def test_api_boundaries(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=req["target_path"], rule=rule):
                    if rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            req["target_path"], rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[{"source": "x = 1\n"}, {"name": "ordinary",
                                  "operation": "ordinary_uses",
                                  "inputs": ["inputs/case.json"],
                                  "output": "outputs/ordinary.json"}])
                    elif rule == "invalid_payload_type":
                        check_api_boundary(
                            req["target_path"], rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[{"source": "x = 1\n"}, {"name": "ordinary",
                                  "operation": "ordinary_uses",
                                  "inputs": ["inputs/case.json"],
                                  "output": "outputs/ordinary.json"}])


if __name__ == "__main__":
    unittest.main()
