def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    objects = data["objects"]
    target = data["target"]
    by_id = {o["id"]: o for o in objects}
    if target not in by_id:
        raise ValueError("unknown target")
    candidates = [target] + list(by_id[target]["mro"])
    provider = None
    for cid in candidates:
        obj = by_id[cid]
        doc = obj.get("doc", "")
        if isinstance(doc, str) and doc.strip():
            provider = cid
            break
    if provider is None:
        result = {"provider": None, "namespace": None, "aliases": {}}
    else:
        obj = by_id[provider]
        result = {
            "provider": provider,
            "namespace": obj.get("namespace"),
            "aliases": obj.get("aliases", {}),
        }
    return {"name": contract["name"], "result": result}
