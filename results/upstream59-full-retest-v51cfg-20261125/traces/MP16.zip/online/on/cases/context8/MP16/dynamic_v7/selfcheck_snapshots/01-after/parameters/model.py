import json
from pathlib import Path


def _check_finite(obj):
    if isinstance(obj, float):
        import math
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for x in obj:
            _check_finite(x)
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except ValueError:
        raise ValueError("invalid JSON")
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data)
    return data
