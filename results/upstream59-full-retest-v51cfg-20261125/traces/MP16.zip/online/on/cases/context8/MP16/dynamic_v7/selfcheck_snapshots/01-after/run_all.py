import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _contracts():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    return contracts


def _topological_order(contracts):
    # Build name -> contract path map and dependency graph.
    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        by_name[c['name']] = (cp, c)

    # A component depends on another if any of its inputs is that component's
    # output file.
    output_to_name = {}
    for name, (cp, c) in by_name.items():
        output_to_name[str(ROOT / c['output'])] = name

    deps = {}
    for name, (cp, c) in by_name.items():
        d = set()
        for inp in c['inputs']:
            key = str(ROOT / inp)
            if key in output_to_name:
                d.add(output_to_name[key])
        deps[name] = d

    # Kahn's algorithm.
    order = []
    remaining = set(by_name)
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError('dependency cycle detected')
        ready.sort()
        order.extend(ready)
        remaining -= set(ready)
    return [by_name[n][0] for n in order]


def main():
    contracts = _contracts()
    if not contracts:
        raise ValueError('no contracts')
    ordered = _topological_order(contracts)
    for cp in ordered:
        render = cp.with_name('render.py')
        subprocess.run([sys.executable, str(render), str(ROOT), str(cp)],
                       cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
