import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception with details dict

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "signatures/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "parameters/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "inheritance/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "document/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_boundary_probes(self):
        # Public rule: object/array top-level and non-finite rejection.
        sig_payload = {"overloads": ["f(x: int) -> str"]}
        sig_contract = {"name": "signatures", "operation": "overload_signatures",
                        "inputs": ["inputs/case.json"], "output": "outputs/signatures.json"}
        param_payload = {"objects": [{"id": "A", "doc": ":param int x: d",
                                      "namespace": "n", "aliases": {}, "mro": []}]}
        param_contract = {"name": "parameters", "operation": "parameter_docs",
                          "inputs": ["inputs/case.json"], "output": "outputs/parameters.json"}
        inherit_payload = {"objects": [{"id": "A", "doc": "x", "namespace": "n",
                                        "aliases": {}, "mro": []}], "target": "A"}
        inherit_contract = {"name": "inheritance", "operation": "inherited_doc",
                            "inputs": ["inputs/case.json"], "output": "outputs/inheritance.json"}
        doc_payloads = [{"overloads": []}, {"docs": {}},
                        {"provider": None, "namespace": None, "aliases": {}}]
        doc_contract = {"name": "document", "operation": "api_documentation",
                        "inputs": ["a", "b", "c"], "output": "outputs/document.json"}

        with self.subTest(component="signatures", rule="nonfinite_unknown_field"):
            check_api_boundary("signatures/transform.py", rule="nonfinite_unknown_field",
                               contract_path="README.md",
                               requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                               args=[[sig_payload], sig_contract])
        with self.subTest(component="signatures", rule="invalid_payload_type"):
            check_api_boundary("signatures/transform.py", rule="invalid_payload_type",
                               contract_path="README.md",
                               requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                               args=[[sig_payload], sig_contract])
        with self.subTest(component="parameters", rule="nonfinite_unknown_field"):
            check_api_boundary("parameters/transform.py", rule="nonfinite_unknown_field",
                               contract_path="README.md",
                               requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                               args=[[param_payload], param_contract])
        with self.subTest(component="parameters", rule="invalid_payload_type"):
            check_api_boundary("parameters/transform.py", rule="invalid_payload_type",
                               contract_path="README.md",
                               requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                               args=[[param_payload], param_contract])
        with self.subTest(component="inheritance", rule="nonfinite_unknown_field"):
            check_api_boundary("inheritance/transform.py", rule="nonfinite_unknown_field",
                               contract_path="README.md",
                               requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                               args=[[inherit_payload], inherit_contract])
        with self.subTest(component="inheritance", rule="invalid_payload_type"):
            check_api_boundary("inheritance/transform.py", rule="invalid_payload_type",
                               contract_path="README.md",
                               requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                               args=[[inherit_payload], inherit_contract])
        with self.subTest(component="document", rule="nonfinite_unknown_field"):
            check_api_boundary("document/transform.py", rule="nonfinite_unknown_field",
                               contract_path="README.md",
                               requirement_quote="任意嵌套NaN/Infinity抛ValueError",
                               args=[doc_payloads, doc_contract])
        with self.subTest(component="document", rule="invalid_payload_type"):
            check_api_boundary("document/transform.py", rule="invalid_payload_type",
                               contract_path="README.md",
                               requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                               args=[doc_payloads, doc_contract])


class TestSignatures(unittest.TestCase):
    def test_overload_parse(self):
        # Public rule: overloads parsed into name/parameters/returns with kinds.
        payload = {"overloads": ["f(x: int, /, *, strict: bool = False) -> str"]}
        contract = {"name": "signatures", "operation": "overload_signatures",
                    "inputs": ["inputs/case.json"], "output": "outputs/signatures.json"}
        result = call_candidate("signatures/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "signatures")
        ov = result["result"]["overloads"]
        self.assertEqual(len(ov), 1)
        self.assertEqual(ov[0]["name"], "f")
        self.assertEqual(ov[0]["returns"], "str")
        kinds = [p["kind"] for p in ov[0]["parameters"]]
        self.assertEqual(kinds, ["posonly", "kwonly"])
        self.assertEqual(ov[0]["parameters"][1]["default"], "False")

    def test_no_default_vs_none(self):
        # Public rule: no default differs from default None.
        payload = {"overloads": ["f(x, y = None)"]}
        contract = {"name": "signatures", "operation": "overload_signatures",
                    "inputs": ["inputs/case.json"], "output": "outputs/signatures.json"}
        result = call_candidate("signatures/transform.py", "transform",
                                args=[[payload], contract])
        params = result["result"]["overloads"][0]["parameters"]
        self.assertIsNone(params[0]["default"])
        self.assertEqual(params[1]["default"], "None")


class TestParameters(unittest.TestCase):
    def test_param_and_type_directives(self):
        # Public rule: :param and :type directives, explicit :type overrides inline.
        payload = {"objects": [{"id": "A", "doc": ":param int x: desc\n:type x: str",
                                "namespace": "n", "aliases": {}, "mro": []}]}
        contract = {"name": "parameters", "operation": "parameter_docs",
                    "inputs": ["inputs/case.json"], "output": "outputs/parameters.json"}
        result = call_candidate("parameters/transform.py", "transform",
                                args=[[payload], contract])
        docs = result["result"]["docs"]["A"]
        self.assertEqual(len(docs), 1)
        self.assertEqual(docs[0]["name"], "x")
        self.assertEqual(docs[0]["type"], "str")
        self.assertEqual(docs[0]["description"], "desc")

    def test_type_only_no_param(self):
        # Public rule: only type without param kept, description="".
        payload = {"objects": [{"id": "A", "doc": ":type y: Item",
                                "namespace": "n", "aliases": {}, "mro": []}]}
        contract = {"name": "parameters", "operation": "parameter_docs",
                    "inputs": ["inputs/case.json"], "output": "outputs/parameters.json"}
        result = call_candidate("parameters/transform.py", "transform",
                                args=[[payload], contract])
        docs = result["result"]["docs"]["A"]
        self.assertEqual(docs[0]["name"], "y")
        self.assertEqual(docs[0]["type"], "Item")
        self.assertEqual(docs[0]["description"], "")


class TestInheritance(unittest.TestCase):
    def test_provider_selection(self):
        # Public rule: first non-empty doc in target then mro.
        payload = {"objects": [
            {"id": "Base", "doc": "x", "namespace": "base",
             "aliases": {"Item": "base.Item"}, "mro": []},
            {"id": "Child", "doc": "", "namespace": "child",
             "aliases": {"Item": "child.Item"}, "mro": ["Base"]},
        ], "target": "Child"}
        contract = {"name": "inheritance", "operation": "inherited_doc",
                    "inputs": ["inputs/case.json"], "output": "outputs/inheritance.json"}
        result = call_candidate("inheritance/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["provider"], "Base")
        self.assertEqual(r["namespace"], "base")
        self.assertEqual(r["aliases"], {"Item": "base.Item"})

    def test_no_doc(self):
        # Public rule: no doc -> provider null, aliases {}.
        payload = {"objects": [
            {"id": "Base", "doc": "", "namespace": "base",
             "aliases": {"Item": "base.Item"}, "mro": []},
            {"id": "Child", "doc": "", "namespace": "child",
             "aliases": {}, "mro": ["Base"]},
        ], "target": "Child"}
        contract = {"name": "inheritance", "operation": "inherited_doc",
                    "inputs": ["inputs/case.json"], "output": "outputs/inheritance.json"}
        result = call_candidate("inheritance/transform.py", "transform",
                                args=[[payload], contract])
        r = result["result"]
        self.assertIsNone(r["provider"])
        self.assertIsNone(r["namespace"])
        self.assertEqual(r["aliases"], {})


class TestDocument(unittest.TestCase):
    def test_qualify_type(self):
        # Public rule: standalone identifier in type replaced by alias.
        sig = {"overloads": [{"name": "f", "parameters": [], "returns": None}]}
        param = {"docs": {"Base": [{"name": "y", "type": "Item",
                                    "description": "d"}]}}
        inherit = {"provider": "Base", "namespace": "base",
                   "aliases": {"Item": "base.Item"}}
        payloads = [sig, param, inherit]
        contract = {"name": "document", "operation": "api_documentation",
                    "inputs": ["a", "b", "c"], "output": "outputs/document.json"}
        result = call_candidate("document/transform.py", "transform",
                                args=[payloads, contract])
        r = result["result"]
        self.assertEqual(r["provider"], "Base")
        self.assertEqual(r["parameters"][0]["type"], "base.Item")

    def test_no_provider_empty_params(self):
        # Public rule: no provider -> parameters=[].
        sig = {"overloads": []}
        param = {"docs": {}}
        inherit = {"provider": None, "namespace": None, "aliases": {}}
        payloads = [sig, param, inherit]
        contract = {"name": "document", "operation": "api_documentation",
                    "inputs": ["a", "b", "c"], "output": "outputs/document.json"}
        result = call_candidate("document/transform.py", "transform",
                                args=[payloads, contract])
        self.assertEqual(result["result"]["parameters"], [])


if __name__ == "__main__":
    unittest.main()
