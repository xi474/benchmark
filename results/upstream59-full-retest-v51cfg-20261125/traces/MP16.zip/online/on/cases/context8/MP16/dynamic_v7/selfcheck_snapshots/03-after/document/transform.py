import re
import math

_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def _unwrap(payload):
    # If the object has exactly name/result keys, only result is business input.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _qualify_type(type_str, aliases):
    """Replace standalone identifiers (not adjacent to a dot) with aliases."""
    if type_str is None:
        return None
    out = []
    i = 0
    n = len(type_str)
    while i < n:
        ch = type_str[i]
        if ch.isalpha() or ch == "_":
            j = i
            while j < n and (type_str[j].isalnum() or type_str[j] == "_"):
                j += 1
            ident = type_str[i:j]
            # standalone: not preceded by '.' and not followed by '.'
            preceded_by_dot = i > 0 and type_str[i - 1] == "."
            followed_by_dot = j < n and type_str[j] == "."
            if (not preceded_by_dot) and (not followed_by_dot) and ident in aliases:
                out.append(aliases[ident])
            else:
                out.append(ident)
            i = j
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _check_finite(payloads)
    _check_finite(contract)

    sig_payload = _unwrap(payloads[0])
    param_payload = _unwrap(payloads[1])
    inherit_payload = _unwrap(payloads[2])
    for p in (sig_payload, param_payload, inherit_payload):
        if not isinstance(p, (dict, list)):
            raise ValueError("payload must be object or array")

    overloads = sig_payload["overloads"]
    docs = param_payload["docs"]
    provider = inherit_payload["provider"]
    namespace = inherit_payload["namespace"]
    aliases = inherit_payload["aliases"]

    if provider is None:
        parameters = []
    else:
        provider_docs = docs.get(provider, [])
        parameters = []
        for entry in provider_docs:
            parameters.append({
                "name": entry["name"],
                "type": _qualify_type(entry["type"], aliases),
                "description": entry["description"],
            })

    result = {
        "overloads": overloads,
        "provider": provider,
        "namespace": namespace,
        "parameters": parameters,
    }
    return {"name": contract["name"], "result": result}
