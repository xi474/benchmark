import re
import math


_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def _is_balanced(s):
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _parse_doc(doc):
    """Parse doc lines into list of {name, type, description}."""
    params = {}  # name -> {type, description}
    order = []
    for raw in doc.splitlines():
        line = raw.strip()
        if not line.startswith(":"):
            continue
        rest = line[1:]
        if rest.startswith("param "):
            body = rest[len("param "):]
            # body: [TYPE ]name: description
            m = re.match(r"^([^:]+):(.*)$", body)
            if m is None:
                raise ValueError("bad param directive")
            head = m.group(1).strip()
            desc = m.group(2).strip()
            # split head into optional TYPE and name
            parts = head.split()
            if len(parts) == 1:
                name = parts[0]
                inline_type = None
            else:
                name = parts[-1]
                inline_type = " ".join(parts[:-1])
            if not _IDENT.match(name):
                raise ValueError("bad param name")
            if inline_type is not None and not _is_balanced(inline_type):
                raise ValueError("unbalanced type")
            if name in params:
                raise ValueError("duplicate param")
            params[name] = {"type": inline_type, "description": desc}
            order.append(name)
        elif rest.startswith("type "):
            body = rest[len("type "):]
            m = re.match(r"^([^:]+):(.*)$", body)
            if m is None:
                raise ValueError("bad type directive")
            name = m.group(1).strip()
            typ = m.group(2).strip()
            if not _IDENT.match(name):
                raise ValueError("bad type name")
            if not _is_balanced(typ):
                raise ValueError("unbalanced type")
            if name in params:
                # explicit :type overrides inline TYPE
                params[name]["type"] = typ
            else:
                params[name] = {"type": typ, "description": ""}
                order.append(name)
        else:
            # non-supported prefix line: ignore
            continue
    return params, order


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _check_finite(payloads)
    _check_finite(contract)
    payload = payloads[0]
    if not isinstance(payload, (dict, list)):
        raise ValueError("payload must be object or array")
    # business input: if object has name/result keys, use result
    if isinstance(payload, dict) and "name" in payload and "result" in payload:
        payload = payload["result"]
    objects = payload["objects"]
    docs = {}
    for obj in objects:
        oid = obj["id"]
        doc = obj["doc"]
        params, order = _parse_doc(doc)
        # sort by name
        entries = []
        for name in sorted(params):
            entries.append({
                "name": name,
                "type": params[name]["type"],
                "description": params[name]["description"],
            })
        docs[oid] = entries
    return {"name": contract["name"], "result": {"docs": docs}}
