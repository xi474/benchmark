import ast
import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def _unparse(node):
    return ast.unparse(node)


def _annotation_str(node):
    if node is None:
        return None
    return _unparse(node)


def _default_str(node):
    if node is None:
        return None
    return _unparse(node)


def _parse_signature(sig):
    # Wrap as a function definition to reuse Python's parser.
    src = "def " + sig + ":\n    pass\n"
    try:
        tree = ast.parse(src)
    except SyntaxError as exc:
        raise ValueError("invalid signature") from exc
    func = tree.body[0]
    if not isinstance(func, ast.FunctionDef):
        raise ValueError("invalid signature")

    args = func.args
    parameters = []

    # positional-only
    for a in args.posonlyargs:
        parameters.append({
            "name": a.arg,
            "kind": "posonly",
            "annotation": _annotation_str(a.annotation),
            "default": _default_str(None),
        })
    # positional-or-keyword
    n_defaults = len(args.defaults)
    n_pos = len(args.args)
    n_no_default = n_pos - n_defaults
    for i, a in enumerate(args.args):
        default = None
        if i >= n_no_default:
            default = args.defaults[i - n_no_default]
        parameters.append({
            "name": a.arg,
            "kind": "positional",
            "annotation": _annotation_str(a.annotation),
            "default": _default_str(default),
        })
    # vararg
    if args.vararg is not None:
        parameters.append({
            "name": args.vararg.arg,
            "kind": "vararg",
            "annotation": _annotation_str(args.vararg.annotation),
            "default": None,
        })
    # kwonly
    n_kw_defaults = len(args.kw_defaults)
    n_kw = len(args.kwonlyargs)
    n_kw_no_default = n_kw - n_kw_defaults
    for i, a in enumerate(args.kwonlyargs):
        default = None
        if i >= n_kw_no_default:
            default = args.kw_defaults[i - n_kw_no_default]
        parameters.append({
            "name": a.arg,
            "kind": "kwonly",
            "annotation": _annotation_str(a.annotation),
            "default": _default_str(default),
        })
    # kwarg
    if args.kwarg is not None:
        parameters.append({
            "name": args.kwarg.arg,
            "kind": "kwarg",
            "annotation": _annotation_str(args.kwarg.annotation),
            "default": None,
        })

    returns = _annotation_str(func.returns)
    return {"name": func.name, "parameters": parameters, "returns": returns}


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    _check_finite(payloads)
    _check_finite(contract)
    payload = payloads[0]
    if not isinstance(payload, (dict, list)):
        raise ValueError("payload must be object or array")
    # If the object has exactly name/result keys, use result as business input.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    overloads = payload["overloads"]
    result = []
    for sig in overloads:
        parsed = _parse_signature(sig)
        result.append({
            "name": parsed["name"],
            "parameters": parsed["parameters"],
            "returns": parsed["returns"],
        })
    return {"name": contract["name"], "result": {"overloads": result}}
