import re

_BOUNDARY_RE = re.compile(r"^[A-Za-z0-9-]+$")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    snapshot = payloads[0]
    encoding = payloads[1]

    # Unwrap name/result envelope if present.
    if isinstance(encoding, dict) and set(encoding) == {"name", "result"}:
        encoding = encoding["result"]

    boundary = snapshot.get("boundary")
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("boundary must be non-empty str")
    if not _BOUNDARY_RE.match(boundary):
        raise ValueError("boundary invalid")

    parts = encoding.get("parts")
    if not isinstance(parts, list):
        raise ValueError("parts must be list")

    boundary_bytes = boundary.encode("utf-8")

    # check boundary not present in any payload
    for part in parts:
        ph = part.get("payload_hex")
        if not isinstance(ph, str):
            raise ValueError("payload_hex missing")
        data = bytes.fromhex(ph)
        if boundary_bytes in data:
            raise ValueError("boundary appears in payload")

    out = bytearray()
    for part in parts:
        name = part["name"]
        filename = part.get("filename")
        mimetype = part.get("mimetype")
        encoding_kind = part.get("encoding")
        payload = bytes.fromhex(part["payload_hex"])

        out += b"--" + boundary_bytes + b"\r\n"
        if encoding_kind == "base64":
            out += b"Content-Transfer-Encoding: base64\r\n"
        out += b"Content-Type: " + mimetype.encode("utf-8") + b"\r\n"
        disp = b'Content-Disposition: form-data; name="' + name.encode("utf-8") + b'"'
        if filename is not None:
            disp += b'; filename="' + filename.encode("utf-8") + b'"'
        out += disp + b"\r\n"
        out += b"\r\n"
        out += payload
        out += b"\r\n"

    out += b"--" + boundary_bytes + b"--\r\n"

    content_type = "multipart/form-data; boundary=" + boundary
    return {
        "name": contract["name"],
        "result": {
            "content_type": content_type,
            "body_hex": bytes(out).hex(),
        },
    }
