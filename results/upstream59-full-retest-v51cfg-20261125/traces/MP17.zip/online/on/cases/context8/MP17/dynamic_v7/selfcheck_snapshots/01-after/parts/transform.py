import base64
import re
from pathlib import Path

_FIELD_NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
_SAFE_BASENAME_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
_MIME_RE = re.compile(r"^[A-Za-z0-9!#$%&'*+.^_`|~-]+/[A-Za-z0-9!#$%&'*+.^_`|~-]+$")

_EXT_MIME = {
    ".txt": "text/plain",
    ".json": "application/json",
    ".jpg": "image/jpeg",
}


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return v == v and v not in (float("inf"), float("-inf"))
    return False


def _check_safe_path(p):
    if not isinstance(p, str):
        raise ValueError("path must be str")
    if p == "" or p.startswith("/") or "\\" in p or ":" in p:
        raise ValueError("unsafe path")
    for seg in p.split("/"):
        if seg in ("", ".", ".."):
            raise ValueError("unsafe path")
    return p


def _basename(p):
    return p.rsplit("/", 1)[-1]


def _mime_from_filename(filename):
    for ext, mime in _EXT_MIME.items():
        if filename.endswith(ext):
            return mime
    return "application/octet-stream"


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]

    if not isinstance(data, dict):
        raise ValueError("input must be object")

    fields = data.get("fields")
    files = data.get("files")
    boundary = data.get("boundary")

    if not isinstance(fields, dict):
        raise ValueError("fields must be object")
    if not isinstance(files, dict):
        raise ValueError("files must be object")
    if not isinstance(boundary, str) or boundary == "":
        raise ValueError("boundary must be non-empty str")
    if not re.fullmatch(r"[A-Za-z0-9-]+", boundary):
        raise ValueError("boundary invalid")

    parts = []
    for name in sorted(fields.keys()):
        if not isinstance(name, str) or not _FIELD_NAME_RE.fullmatch(name):
            raise ValueError("invalid field name")
        value = fields[name]
        if isinstance(value, str):
            parts.append({
                "name": name,
                "filename": None,
                "mimetype": "text/plain",
                "encoding": "raw",
                "hex": value.encode("utf-8").hex(),
            })
        elif isinstance(value, dict):
            if not value:
                raise ValueError("empty sub-object")
            content = value.get("content")
            filename = value.get("filename")
            mimetype = value.get("mimetype")

            if content is not None:
                if not isinstance(content, str):
                    raise ValueError("content must be str")
                raw = content.encode("utf-8")
                if filename is not None:
                    if not isinstance(filename, str):
                        raise ValueError("filename must be str")
                    filename = _basename(filename)
                    if not _SAFE_BASENAME_RE.fullmatch(filename):
                        raise ValueError("invalid filename")
                if mimetype is not None:
                    if not isinstance(mimetype, str) or not _MIME_RE.fullmatch(mimetype):
                        raise ValueError("invalid mimetype")
                else:
                    mimetype = _mime_from_filename(filename) if filename else "application/octet-stream"
                parts.append({
                    "name": name,
                    "filename": filename,
                    "mimetype": mimetype,
                    "encoding": "raw",
                    "hex": raw.hex(),
                })
            elif filename is not None:
                if not isinstance(filename, str):
                    raise ValueError("filename must be str")
                _check_safe_path(filename)
                if filename not in files:
                    raise ValueError("missing file")
                raw = bytes.fromhex(files[filename])
                base = _basename(filename)
                if not _SAFE_BASENAME_RE.fullmatch(base):
                    raise ValueError("invalid filename")
                if mimetype is not None:
                    if not isinstance(mimetype, str) or not _MIME_RE.fullmatch(mimetype):
                        raise ValueError("invalid mimetype")
                else:
                    mimetype = _mime_from_filename(base)
                parts.append({
                    "name": name,
                    "filename": base,
                    "mimetype": mimetype,
                    "encoding": "base64",
                    "hex": raw.hex(),
                })
            else:
                raise ValueError("empty sub-object")
        else:
            raise ValueError("field value must be str or object")

    return {"name": contract["name"], "result": {"parts": parts}}
