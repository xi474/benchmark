import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob('contract.json')
        if 'outputs' not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise ValueError('no contracts')

    # Build name -> contract mapping and topologically order by input deps.
    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        by_name[c['name']] = (cp, c)

    # Map output path -> producing component name.
    output_to_name = {}
    for name, (cp, c) in by_name.items():
        output_to_name[ROOT / c['output']] = name

    # Determine dependencies: an input that is another component's output.
    deps = {}
    for name, (cp, c) in by_name.items():
        d = set()
        for p in c.get('inputs', []):
            ap = ROOT / p
            if ap in output_to_name:
                d.add(output_to_name[ap])
        deps[name] = d

    # Topological sort (Kahn's algorithm).
    indeg = {name: len(deps[name]) for name in by_name}
    ready = sorted(name for name in by_name if indeg[name] == 0)
    ordered = []
    while ready:
        name = ready.pop(0)
        ordered.append(name)
        for other, d in deps.items():
            if name in d:
                indeg[other] -= 1
                if indeg[other] == 0:
                    ready.append(other)
                    ready.sort()
    if len(ordered) != len(by_name):
        raise ValueError('dependency cycle or missing dependency')

    for name in ordered:
        cp, c = by_name[name]
        render = cp.with_name('render.py')
        subprocess.run(
            [sys.executable, str(render), str(ROOT), str(cp)],
            cwd=ROOT, check=True, timeout=60,
        )

    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT, check=True, timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT, check=True, timeout=60,
    )


if __name__ == '__main__':
    main()
