import hashlib


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    inventory, selection = payloads

    def _unwrap(p):
        if isinstance(p, dict) and set(p) == {"name", "result"}:
            return p["result"]
        return p

    inventory = _unwrap(inventory)
    selection = _unwrap(selection)

    # inventory result: {files:[{path,hex}], symlinks:[...]}
    files = inventory.get("files")
    if not isinstance(files, list):
        raise ValueError("inventory files must be a list")

    file_map = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("inventory file entry must be object")
        path = f.get("path")
        hexv = f.get("hex")
        if not isinstance(path, str) or not isinstance(hexv, str):
            raise ValueError("inventory file entry missing path/hex")
        file_map[path] = hexv

    selected = selection.get("selected")
    if not isinstance(selected, list):
        raise ValueError("selection selected must be a list")

    if len(set(selected)) != len(selected):
        raise ValueError("selected has duplicates")

    entries = []
    total_bytes = 0
    for path in selected:
        if path not in file_map:
            raise ValueError("selected path not in regular files")
        raw = bytes.fromhex(file_map[path])
        size = len(raw)
        sha = hashlib.sha256(raw).hexdigest()
        entries.append({"path": path, "size": size, "sha256": sha})
        total_bytes += size

    return {"name": contract["name"], "result": {"entries": entries, "total_bytes": total_bytes}}
