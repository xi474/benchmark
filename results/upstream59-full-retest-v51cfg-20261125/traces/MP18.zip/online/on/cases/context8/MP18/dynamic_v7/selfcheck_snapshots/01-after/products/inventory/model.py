import json
import math
from pathlib import Path


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def load_payload(path):
    text = Path(path).read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data)
    return data
