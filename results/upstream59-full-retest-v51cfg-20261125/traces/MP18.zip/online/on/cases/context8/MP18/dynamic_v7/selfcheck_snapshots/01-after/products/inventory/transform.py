import math


def _is_finite_number(value):
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    return False


def _check_safe_rel_path(path):
    if not isinstance(path, str):
        raise ValueError("path must be string")
    if path == "":
        raise ValueError("empty path")
    if path.startswith("/") or "\\" in path or ":" in path:
        raise ValueError("unsafe path")
    parts = path.split("/")
    for part in parts:
        if part in ("", ".", ".."):
            raise ValueError("unsafe path segment")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    # When input object has exactly keys name/result, only result is business input.
    if isinstance(data, dict) and set(data.keys()) == {"name", "result"}:
        data = data["result"]

    if not isinstance(data, dict):
        raise ValueError("input must be object")

    files = data.get("files")
    if files is None:
        raise ValueError("missing files")
    if not isinstance(files, list):
        raise ValueError("files must be list")

    manifest = data.get("manifest")
    build_ignore = data.get("build_ignore")

    seen_paths = set()
    regular = []
    symlinks = []

    for entry in files:
        if not isinstance(entry, dict):
            raise ValueError("file entry must be object")
        path = entry.get("path")
        kind = entry.get("kind")
        hexv = entry.get("hex")
        target = entry.get("target")

        _check_safe_rel_path(path)
        if path in seen_paths:
            raise ValueError("duplicate path")
        seen_paths.add(path)

        if kind == "file":
            if not isinstance(hexv, str):
                raise ValueError("file hex must be string")
            try:
                bytes.fromhex(hexv)
            except ValueError:
                raise ValueError("invalid hex")
            regular.append({"path": path, "hex": hexv})
        elif kind == "symlink":
            if target is None:
                raise ValueError("symlink target required")
            _check_safe_rel_path(target)
            symlinks.append(path)
        else:
            raise ValueError("invalid kind")

    regular.sort(key=lambda e: e["path"])
    symlinks.sort()

    return {
        "name": contract["name"],
        "result": {
            "files": regular,
            "symlinks": symlinks,
        },
    }
