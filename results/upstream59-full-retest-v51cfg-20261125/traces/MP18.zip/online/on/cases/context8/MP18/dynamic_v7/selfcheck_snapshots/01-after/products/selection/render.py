import json
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    contract = load_payload(contract_path)
    payloads = [load_payload(Path(root) / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    text = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
    ) + "\n"
    Path(path).write_text(text, encoding="utf-8")


if __name__ == "__main__":
    import sys

    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]
    contract_path = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("contract.json")
    contract = load_payload(contract_path)
    result = build_component(root, contract_path)
    out = Path(root) / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    _write_json(out, result)
