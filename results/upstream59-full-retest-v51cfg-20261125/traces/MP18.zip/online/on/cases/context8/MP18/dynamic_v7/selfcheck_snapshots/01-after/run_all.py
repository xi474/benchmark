import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Run each component's render.py CLI in dependency order.
    components = [
        "products/inventory",
        "products/selection",
        "products/archive",
    ]
    for comp in components:
        render = ROOT / comp / "render.py"
        subprocess.run(
            [sys.executable, str(render)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )
    # Integrate all component outputs into core_manifest.json.
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )
    # Generate the final report.
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
