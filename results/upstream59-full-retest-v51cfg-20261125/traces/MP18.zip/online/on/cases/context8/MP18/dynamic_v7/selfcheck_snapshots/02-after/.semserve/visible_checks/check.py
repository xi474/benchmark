import unittest

# Injected names provided by the self-check SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type for expected candidate failures

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/inventory/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/selection/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/archive/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_inventory_boundary(self):
        check_api_boundary(
            "products/inventory/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[[{"files": [], "manifest": None, "build_ignore": None}],
                  {"name": "inventory", "inputs": ["x"], "output": "y"}],
        )
        check_api_boundary(
            "products/inventory/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[{"files": [], "manifest": None, "build_ignore": None}],
                  {"name": "inventory", "inputs": ["x"], "output": "y"}],
        )

    def test_selection_boundary(self):
        check_api_boundary(
            "products/selection/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[[{"files": [], "manifest": None, "build_ignore": None},
                   {"files": [], "symlinks": []}],
                  {"name": "selection", "inputs": ["a", "b"], "output": "c"}],
        )
        check_api_boundary(
            "products/selection/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[{"files": [], "manifest": None, "build_ignore": None},
                   {"files": [], "symlinks": []}],
                  {"name": "selection", "inputs": ["a", "b"], "output": "c"}],
        )

    def test_archive_boundary(self):
        check_api_boundary(
            "products/archive/transform.py",
            rule="nonfinite_unknown_field",
            contract_path="README.md",
            requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
            args=[[{"files": [], "symlinks": []}, {"selected": []}],
                  {"name": "archive", "inputs": ["a", "b"], "output": "c"}],
        )
        check_api_boundary(
            "products/archive/transform.py",
            rule="invalid_payload_type",
            contract_path="README.md",
            requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            args=[[{"files": [], "symlinks": []}, {"selected": []}],
                  {"name": "archive", "inputs": ["a", "b"], "output": "c"}],
        )


class TestInventoryTransform(unittest.TestCase):
    def test_inventory_output_shape_and_ordering(self):
        # Public rule: files sorted by path, symlinks sorted; only regular files
        # carry {path,hex}; symlinks are path strings and never archived.
        payload = {
            "files": [
                {"path": "b.txt", "kind": "file", "hex": "6162", "target": None},
                {"path": "a.txt", "kind": "file", "hex": "63", "target": None},
                {"path": "z", "kind": "symlink", "hex": "", "target": "a.txt"},
                {"path": "y", "kind": "symlink", "hex": "", "target": "b.txt"},
            ],
            "manifest": None,
            "build_ignore": None,
        }
        contract = {"name": "inventory", "inputs": ["x"], "output": "y"}
        result = call_candidate(
            "products/inventory/transform.py", "transform", args=[[payload], contract]
        )
        self.assertEqual(result["name"], "inventory")
        r = result["result"]
        self.assertEqual([f["path"] for f in r["files"]], ["a.txt", "b.txt"])
        self.assertEqual(r["symlinks"], ["y", "z"])
        self.assertEqual(r["files"][0], {"path": "a.txt", "hex": "63"})

    def test_inventory_rejects_unsafe_path(self):
        payload = {
            "files": [
                {"path": "../evil", "kind": "file", "hex": "61", "target": None},
            ],
            "manifest": None,
            "build_ignore": None,
        }
        contract = {"name": "inventory", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate(
                "products/inventory/transform.py", "transform", args=[[payload], contract]
            )
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestSelectionTransform(unittest.TestCase):
    def test_selection_manifest_include_exclude(self):
        # Public rule: manifest non-null starts from empty set; include/exclude
        # match full path; recursive-include matches basename under DIR/.
        snapshot = {
            "files": [],
            "manifest": "include README.md\nrecursive-include plugins *.py\nexclude plugins/tests/*\n",
            "build_ignore": None,
        }
        inventory = {
            "files": [
                {"path": "README.md", "hex": "61"},
                {"path": "plugins/a.py", "hex": "62"},
                {"path": "plugins/tests/t.py", "hex": "63"},
                {"path": "plugins/a.pyc", "hex": "64"},
            ],
            "symlinks": [],
        }
        contract = {"name": "selection", "inputs": ["a", "b"], "output": "c"}
        result = call_candidate(
            "products/selection/transform.py",
            "transform",
            args=[[snapshot, inventory], contract],
        )
        self.assertEqual(result["result"]["selected"], ["README.md", "plugins/a.py"])

    def test_selection_manifest_and_build_ignore_conflict(self):
        snapshot = {
            "files": [],
            "manifest": "include x\n",
            "build_ignore": ["*.py"],
        }
        inventory = {"files": [], "symlinks": []}
        contract = {"name": "selection", "inputs": ["a", "b"], "output": "c"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate(
                "products/selection/transform.py",
                "transform",
                args=[[snapshot, inventory], contract],
            )
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestArchiveTransform(unittest.TestCase):
    def test_archive_entries_and_total_bytes(self):
        # Public rule: hash over bytes (not hex text); size is byte length.
        inventory = {
            "files": [
                {"path": "a.txt", "hex": "616263"},
                {"path": "b.txt", "hex": "64"},
            ],
            "symlinks": [],
        }
        selection = {"selected": ["b.txt", "a.txt"]}
        contract = {"name": "archive", "inputs": ["a", "b"], "output": "c"}
        result = call_candidate(
            "products/archive/transform.py",
            "transform",
            args=[[inventory, selection], contract],
        )
        r = result["result"]
        self.assertEqual(r["total_bytes"], 4)
        self.assertEqual([e["path"] for e in r["entries"]], ["b.txt", "a.txt"])
        self.assertEqual(r["entries"][0]["size"], 1)
        self.assertEqual(r["entries"][1]["size"], 3)
        # sha256 of b"abc"
        import hashlib

        self.assertEqual(
            r["entries"][1]["sha256"],
            hashlib.sha256(b"abc").hexdigest(),
        )

    def test_archive_rejects_selected_not_in_files(self):
        inventory = {"files": [{"path": "a.txt", "hex": "61"}], "symlinks": []}
        selection = {"selected": ["missing.txt"]}
        contract = {"name": "archive", "inputs": ["a", "b"], "output": "c"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate(
                "products/archive/transform.py",
                "transform",
                args=[[inventory, selection], contract],
            )
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
