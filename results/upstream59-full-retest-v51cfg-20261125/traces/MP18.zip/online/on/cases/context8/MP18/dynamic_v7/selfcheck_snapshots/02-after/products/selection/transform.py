import fnmatch
import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for item in obj:
            _check_finite(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            _check_finite(value)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    for p in payloads:
        _check_finite(p)

    snapshot = _unwrap(payloads[0])
    inventory = _unwrap(payloads[1])

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be object")
    if not isinstance(inventory, dict):
        raise ValueError("inventory must be object")

    manifest = snapshot.get("manifest")
    build_ignore = snapshot.get("build_ignore")

    if manifest is not None and build_ignore is not None:
        raise ValueError("manifest and build_ignore cannot both be set")

    # All ordinary files from inventory, keyed by path.
    files = {f["path"] for f in inventory.get("files", [])}

    if manifest is None:
        selected = set(files)
        if build_ignore is not None:
            for pattern in build_ignore:
                selected = {
                    p for p in selected
                    if not fnmatch.fnmatchcase(p, pattern)
                }
    else:
        selected = set()
        for raw_line in manifest.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            op = parts[0]
            if op == "recursive-include":
                if len(parts) != 3:
                    raise ValueError("unknown manifest syntax")
                dirname = parts[1].rstrip("/")
                pattern = parts[2]
                prefix = dirname + "/"
                for p in files:
                    if p.startswith(prefix):
                        if fnmatch.fnmatchcase(p.split("/")[-1], pattern):
                            selected.add(p)
            elif op == "include":
                if len(parts) != 2:
                    raise ValueError("unknown manifest syntax")
                arg = parts[1]
                for p in files:
                    if fnmatch.fnmatchcase(p, arg):
                        selected.add(p)
            elif op == "exclude":
                if len(parts) != 2:
                    raise ValueError("unknown manifest syntax")
                arg = parts[1]
                selected = {p for p in selected
                            if not fnmatch.fnmatchcase(p, arg)}
            elif op == "global-exclude":
                if len(parts) != 2:
                    raise ValueError("unknown manifest syntax")
                arg = parts[1]
                selected = {p for p in selected
                            if not fnmatch.fnmatchcase(p.split("/")[-1], arg)}
            else:
                raise ValueError("unknown manifest syntax")

    # Unconditional exclusions.
    def _excluded(p):
        parts = p.split("/")
        if ".git" in parts:
            return True
        if p.endswith(".pyc"):
            return True
        if p == "MANIFEST.in":
            return True
        return False

    selected = {p for p in selected if not _excluded(p)}

    return {"name": contract["name"], "result": {"selected": sorted(selected)}}
