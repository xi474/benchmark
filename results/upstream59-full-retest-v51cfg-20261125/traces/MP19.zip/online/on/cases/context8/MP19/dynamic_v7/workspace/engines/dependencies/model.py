import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON payload.

    Only a top-level object or array is legal. Invalid JSON, any other
    top-level type, and any nested NaN/Infinity raise ValueError.
    """
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        raise ValueError("cannot read payload %r: %s" % (str(path), exc))
    try:
        data = json.loads(text, parse_constant=_reject_constant)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("invalid JSON in %r: %s" % (str(path), exc))
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be an object or array")
    return data


def _reject_constant(value):
    raise ValueError("non-finite number is not allowed")
