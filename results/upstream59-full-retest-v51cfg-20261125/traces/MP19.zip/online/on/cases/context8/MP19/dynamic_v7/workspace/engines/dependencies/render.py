import json
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    cp = Path(contract_path)
    c = load_payload(cp)
    payloads = [load_payload(root / p) for p in c["inputs"]]
    return transform(payloads, c)


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    cp = here / "contract.json"
    c = load_payload(cp)
    result = build_component(root, cp)
    out = root / c["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )
