def _unwrap(payload):
    """If a payload object has exactly the keys name/result, only its result
    is the business input; other objects are interpreted as-is."""
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _parent_inits(path, modules):
    """All existing parent package __init__.py paths for a module path."""
    parts = path.split("/")
    dirs = parts[:-1]
    result = []
    for i in range(len(dirs), 0, -1):
        init = "/".join(dirs[:i]) + "/__init__.py"
        if init in modules:
            result.append(init)
    return result


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count does not match contract inputs")

    case = _unwrap(payloads[0])
    scan = _unwrap(payloads[1])

    modules = case["modules"]
    entry = case["entry"]
    externals = case["externals"]
    aliases = case["aliases"]
    imports_map = scan["imports"]
    module_paths = scan["module_paths"]

    if entry not in modules:
        raise ValueError("entry path not present in modules")

    paths = set()
    external = set()
    queue = [entry]
    seen = set()

    while queue:
        path = queue.pop(0)
        if path in seen:
            continue
        seen.add(path)
        paths.add(path)
        for name in imports_map.get(path, []):
            if name in module_paths:
                p = module_paths[name]
                if p not in seen:
                    queue.append(p)
                for init in _parent_inits(p, modules):
                    if init not in seen:
                        queue.append(init)
            else:
                n = aliases.get(name, name)
                if n in externals or n.split(".")[0] in externals:
                    external.add(n)
                else:
                    raise ValueError("unknown external module: %s" % name)

    return {
        "name": contract["name"],
        "result": {"paths": sorted(paths), "external": sorted(external)},
    }
