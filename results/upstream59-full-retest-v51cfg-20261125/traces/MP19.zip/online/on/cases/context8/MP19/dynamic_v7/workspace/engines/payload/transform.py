import hashlib
import io
import zipfile


def _business_input(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    modules_payload = _business_input(payloads[0])
    deps_payload = _business_input(payloads[1])

    if not isinstance(modules_payload, dict):
        raise ValueError("modules must be an object")
    modules = modules_payload.get("modules")
    if not isinstance(modules, dict):
        raise ValueError("modules.modules must be an object")

    if not isinstance(deps_payload, dict):
        raise ValueError("dependencies result must be an object")
    paths = deps_payload.get("paths")
    external = deps_payload.get("external")
    if not isinstance(paths, list):
        raise ValueError("dependencies.paths must be a list")
    if not isinstance(external, list):
        raise ValueError("dependencies.external must be a list")

    if len(set(paths)) != len(paths):
        raise ValueError("duplicate paths")

    # Determine whether root __init__.py is present among paths.
    has_root_init = "__init__.py" in paths

    zip_paths = []
    entries = []
    for p in paths:
        if p not in modules:
            raise ValueError("source path not found: %s" % p)
        src = modules[p]
        if not isinstance(src, str):
            raise ValueError("module source must be a string")
        zip_paths.append(p)
        entries.append((p, src.encode("utf-8")))

    if not has_root_init:
        zip_paths.append("__init__.py")
        entries.append(("__init__.py", b""))

    # Sort ZIP items by path.
    entries.sort(key=lambda e: e[0])
    zip_paths = [e[0] for e in entries]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_STORED) as zf:
        for name, data in entries:
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_STORED
            zf.writestr(info, data)

    zip_bytes = buf.getvalue()
    zip_hex = zip_bytes.hex()
    sha256 = hashlib.sha256(zip_bytes).hexdigest()

    return {
        "name": contract["name"],
        "result": {
            "paths": zip_paths,
            "zip_hex": zip_hex,
            "sha256": sha256,
            "external": external,
        },
    }
