import ast


def _module_name(path):
    # path is a relative .py path using '/'
    if path == "__init__.py":
        return ""
    p = path
    if p.endswith(".py"):
        p = p[:-3]
    if p.endswith("/__init__"):
        p = p[:-len("/__init__")]
    return p.replace("/", ".")


def _resolve_relative(current_pkg, level, target):
    # current_pkg is dotted package of the current module ('' for root)
    parts = current_pkg.split(".") if current_pkg else []
    up = level - 1
    if up > len(parts):
        raise ValueError("relative import beyond root")
    base = parts[: len(parts) - up]
    if target:
        base = base + target.split(".")
    return ".".join(base)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    modules = data["modules"]
    entry = data["entry"]
    externals = set(data["externals"])
    aliases = data["aliases"]

    if entry not in modules:
        raise ValueError("entry not found")

    # map module name -> path
    name_to_path = {}
    for path in modules:
        name_to_path[_module_name(path)] = path

    imports = {}
    module_paths = dict(name_to_path)

    def scan(path):
        if path in imports:
            return
        src = modules[path]
        name = _module_name(path)
        module_paths[name] = path
        deps = set()
        try:
            tree = ast.parse(src)
        except SyntaxError as e:
            raise ValueError("syntax error") from e
        # current package for relative resolution
        is_init = path == "__init__.py" or path.endswith("/__init__.py")
        if name == "":
            current_pkg = ""
        elif is_init:
            current_pkg = name
        else:
            current_pkg = name.rsplit(".", 1)[0] if "." in name else ""
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    deps.add(a.name)
            elif isinstance(node, ast.ImportFrom):
                if node.level > 0:
                    # relative from
                    if node.module:
                        # from .b import c  ->  current_pkg.b
                        resolved = _resolve_relative(current_pkg, node.level, node.module)
                        deps.add(resolved)
                    else:
                        # from . import b  ->  current_pkg.b for each name
                        for a in node.names:
                            resolved = _resolve_relative(current_pkg, node.level, a.name)
                            deps.add(resolved)
                else:
                    # absolute from X import y
                    mod = node.module or ""
                    # try X.y for each imported name
                    found_local = False
                    for a in node.names:
                        candidate = (mod + "." + a.name) if mod else a.name
                        if candidate in name_to_path:
                            deps.add(candidate)
                            found_local = True
                    if not found_local:
                        deps.add(mod)
        imports[path] = sorted(deps)

    def parent_packages(name):
        # for module name 'pkg.a.b', yield 'pkg.a', 'pkg'
        parts = name.split(".")
        for i in range(len(parts) - 1, 0, -1):
            yield ".".join(parts[:i])

    # BFS from entry
    queue = [entry]
    while queue:
        path = queue.pop(0)
        if path in imports:
            continue
        scan(path)
        for dep in imports[path]:
            if dep in name_to_path and dep not in imports:
                queue.append(name_to_path[dep])
            # also scan parent package __init__.py files
            for parent in parent_packages(dep):
                if parent in name_to_path and parent not in imports:
                    queue.append(name_to_path[parent])

    result = {
        "imports": imports,
        "module_paths": module_paths,
    }
    return {"name": contract["name"], "result": result}
