import copy
import json


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    flags = payload["flags"]
    attachments = {}
    for flag in flags:
        fid = flag["id"]
        attachments[fid] = {}
        for variant in flag["variants"]:
            vid = variant["id"]
            value = copy.deepcopy(variant["attachment"])
            attachments[fid][vid] = {
                "value": value,
                "canonical": _canonical(value),
            }
    return {"name": contract["name"], "result": {"attachments": attachments}}
