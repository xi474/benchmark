import copy
import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _check_nonempty_str(v, field):
    if not isinstance(v, str):
        raise ValueError(f"{field} must be a string")
    if not v.strip():
        raise ValueError(f"{field} must be non-empty")
    return v


def _check_unique(ids, what):
    seen = set()
    for i in ids:
        if i in seen:
            raise ValueError(f"duplicate {what} id: {i}")
        seen.add(i)


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("payload must be an object")

    flags = data.get("flags")
    segments = data.get("segments")
    if not isinstance(flags, list):
        raise ValueError("flags must be a list")
    if not isinstance(segments, list):
        raise ValueError("segments must be a list")

    flag_ids = []
    for flag in flags:
        if not isinstance(flag, dict):
            raise ValueError("flag must be an object")
        fid = _check_nonempty_str(flag.get("id"), "flag.id")
        flag_ids.append(fid)

        variants = flag.get("variants")
        rules = flag.get("rules")
        if not isinstance(variants, list):
            raise ValueError("flag.variants must be a list")
        if not isinstance(rules, list):
            raise ValueError("flag.rules must be a list")

        variant_ids = []
        for variant in variants:
            if not isinstance(variant, dict):
                raise ValueError("variant must be an object")
            vid = _check_nonempty_str(variant.get("id"), "variant.id")
            variant_ids.append(vid)
            if "attachment" not in variant:
                raise ValueError("variant.attachment missing")
            _check_finite_json(variant["attachment"])
        _check_unique(variant_ids, "variant")

        rule_ids = []
        for rule in rules:
            if not isinstance(rule, dict):
                raise ValueError("rule must be an object")
            rid = _check_nonempty_str(rule.get("id"), "rule.id")
            rule_ids.append(rid)
            _check_nonempty_str(rule.get("segment"), "rule.segment")
            _check_nonempty_str(rule.get("variant"), "rule.variant")
        _check_unique(rule_ids, "rule")

    _check_unique(flag_ids, "flag")

    segment_ids = []
    for segment in segments:
        if not isinstance(segment, dict):
            raise ValueError("segment must be an object")
        sid = _check_nonempty_str(segment.get("id"), "segment.id")
        segment_ids.append(sid)
    _check_unique(segment_ids, "segment")

    return {
        "name": contract["name"],
        "result": {
            "flags": copy.deepcopy(flags),
            "segments": copy.deepcopy(segments),
        },
    }


def _check_finite_json(v):
    if isinstance(v, bool):
        return
    if isinstance(v, int):
        return
    if isinstance(v, float):
        if not math.isfinite(v):
            raise ValueError("non-finite number in attachment")
        return
    if isinstance(v, str):
        return
    if v is None:
        return
    if isinstance(v, list):
        for item in v:
            _check_finite_json(item)
        return
    if isinstance(v, dict):
        for k, val in v.items():
            _check_finite_json(val)
        return
    raise ValueError("unsupported JSON value")
