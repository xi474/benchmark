import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise SystemExit("no contracts found")

    # Topological order by input dependency on outputs.
    produced = set()
    remaining = list(contracts)
    order = []
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [i for i in c["inputs"] if i.startswith("outputs/")]
            if all(d in produced for d in deps):
                order.append(cp)
                produced.add(c["output"])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise SystemExit("dependency cycle or missing dependency")

    for cp in order:
        c = json.loads(cp.read_text(encoding="utf-8"))
        render = cp.with_name("render.py")
        r = subprocess.run(
            [sys.executable, str(render)],
            cwd=ROOT,
            check=False,
        )
        if r.returncode != 0:
            raise SystemExit(f"component {c['name']} failed")

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
    )
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
