def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    flags = data["flags"]
    segments = data["segments"]

    segment_ids = {s["id"] for s in segments}
    flag_ids = {f["id"] for f in flags}

    # Check segment references first, sorted by flag id then rule id.
    ordered_flags = sorted(flags, key=lambda f: f["id"])
    for flag in ordered_flags:
        rules = sorted(flag["rules"], key=lambda r: r["id"])
        for rule in rules:
            if rule["segment"] not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": flag["id"],
                            "rule": rule["id"],
                            "target": rule["segment"],
                        },
                    },
                }

    # All segments valid; now check variant references within each flag.
    for flag in ordered_flags:
        variant_ids = {v["id"] for v in flag["variants"]}
        rules = sorted(flag["rules"], key=lambda r: r["id"])
        for rule in rules:
            if rule["variant"] not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": flag["id"],
                            "rule": rule["id"],
                            "target": rule["variant"],
                        },
                    },
                }

    return {"name": contract["name"], "result": {"ok": True, "error": None}}
