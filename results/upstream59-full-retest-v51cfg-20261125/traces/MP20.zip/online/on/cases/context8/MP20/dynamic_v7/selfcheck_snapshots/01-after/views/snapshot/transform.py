import copy
import json


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def transform(payloads, contract):
    if not isinstance(payloads, list) or len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    original = _unwrap(payloads[0])
    schema = _unwrap(payloads[1])
    attachments = _unwrap(payloads[2])
    references = _unwrap(payloads[3])

    if not isinstance(original, dict):
        raise ValueError("original payload must be an object")
    if not isinstance(schema, dict):
        raise ValueError("schema payload must be an object")
    if not isinstance(attachments, dict):
        raise ValueError("attachments payload must be an object")
    if not isinstance(references, dict):
        raise ValueError("references payload must be an object")

    old_snapshot = original.get("old_snapshot")
    if not isinstance(old_snapshot, dict):
        raise ValueError("old_snapshot must be an object")

    if references.get("ok") is not True:
        error = references.get("error")
        return {
            "name": contract["name"],
            "result": {
                "committed": False,
                "snapshot": copy.deepcopy(old_snapshot),
                "error": copy.deepcopy(error),
                "export": None,
            },
        }

    flags = schema.get("flags")
    segments = schema.get("segments")
    if not isinstance(flags, list):
        raise ValueError("schema.flags must be a list")
    if not isinstance(segments, list):
        raise ValueError("schema.segments must be a list")

    att_map = attachments.get("attachments")
    if not isinstance(att_map, dict):
        raise ValueError("attachments.attachments must be an object")

    out_flags = []
    for flag in flags:
        fid = flag["id"]
        out_variants = []
        for variant in flag["variants"]:
            vid = variant["id"]
            value = att_map[fid][vid]["value"]
            out_variants.append({
                "id": vid,
                "attachment": copy.deepcopy(value),
            })
        out_flags.append({
            "id": fid,
            "variants": out_variants,
            "rules": copy.deepcopy(flag["rules"]),
        })

    out_segments = [{"id": s["id"]} for s in segments]

    snapshot = {
        "flags": out_flags,
        "segments": out_segments,
    }

    return {
        "name": contract["name"],
        "result": {
            "committed": True,
            "snapshot": snapshot,
            "error": None,
            "export": _canonical(snapshot),
        },
    }
