import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/schema/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/attachments/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/references/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/snapshot/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestSchemaTransform(unittest.TestCase):
    def test_schema_returns_deep_copy_and_shape(self):
        payload = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "on", "attachment": {"a": 1}}],
                    "rules": [{"id": "r1", "segment": "s1", "variant": "on"}],
                }
            ],
            "segments": [{"id": "s1"}],
            "old_snapshot": {"flags": []},
        }
        contract = {"name": "schema", "inputs": ["inputs/case.json"]}
        result = call_candidate(
            "domains/schema/transform.py", "transform", args=[[payload], contract]
        )
        self.assertEqual(set(result), {"name", "result"})
        self.assertEqual(result["name"], "schema")
        self.assertEqual(result["result"]["flags"], payload["flags"])
        self.assertEqual(result["result"]["segments"], payload["segments"])
        # deep copy: mutating result must not affect input
        result["result"]["flags"][0]["id"] = "changed"
        self.assertEqual(payload["flags"][0]["id"], "f1")

    def test_schema_duplicate_flag_id_raises(self):
        payload = {
            "flags": [
                {"id": "f1", "variants": [], "rules": []},
                {"id": "f1", "variants": [], "rules": []},
            ],
            "segments": [],
        }
        contract = {"name": "schema", "inputs": ["inputs/case.json"]}
        with self.assertRaises(CandidateCallError) as ctx:
            call_candidate(
                "domains/schema/transform.py", "transform", args=[[payload], contract]
            )
        self.assertEqual(ctx.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(ctx.exception.details["error_type"], "ValueError")


class TestReferencesTransform(unittest.TestCase):
    def test_references_missing_segment(self):
        payload = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "on", "attachment": {}}],
                    "rules": [{"id": "r1", "segment": "missing", "variant": "on"}],
                }
            ],
            "segments": [{"id": "s1"}],
        }
        contract = {"name": "references", "inputs": ["outputs/schema.json"]}
        result = call_candidate(
            "views/references/transform.py", "transform", args=[[payload], contract]
        )
        self.assertEqual(result["result"]["ok"], False)
        self.assertEqual(
            result["result"]["error"],
            {"kind": "segment", "flag": "f1", "rule": "r1", "target": "missing"},
        )

    def test_references_missing_variant(self):
        payload = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "on", "attachment": {}}],
                    "rules": [{"id": "r1", "segment": "s1", "variant": "off"}],
                }
            ],
            "segments": [{"id": "s1"}],
        }
        contract = {"name": "references", "inputs": ["outputs/schema.json"]}
        result = call_candidate(
            "views/references/transform.py", "transform", args=[[payload], contract]
        )
        self.assertEqual(result["result"]["ok"], False)
        self.assertEqual(
            result["result"]["error"],
            {"kind": "variant", "flag": "f1", "rule": "r1", "target": "off"},
        )


class TestSnapshotTransform(unittest.TestCase):
    def _payloads(self, ok=True):
        original = {"old_snapshot": {"flags": [], "version": 1}}
        schema = {
            "flags": [
                {
                    "id": "f1",
                    "variants": [{"id": "on", "attachment": {"x": 1}}],
                    "rules": [{"id": "r1", "segment": "s1", "variant": "on"}],
                }
            ],
            "segments": [{"id": "s1"}],
        }
        attachments = {"attachments": {"f1": {"on": {"value": {"x": 1}, "canonical": "{}"}}}}
        references = (
            {"ok": True, "error": None}
            if ok
            else {"ok": False, "error": {"kind": "segment", "flag": "f1", "rule": "r1", "target": "s1"}}
        )
        return [original, schema, attachments, references]

    def test_snapshot_committed(self):
        contract = {
            "name": "snapshot",
            "inputs": [
                "inputs/case.json",
                "outputs/schema.json",
                "outputs/attachments.json",
                "outputs/references.json",
            ],
        }
        result = call_candidate(
            "views/snapshot/transform.py", "transform", args=[self._payloads(True), contract]
        )
        self.assertEqual(result["name"], "snapshot")
        r = result["result"]
        self.assertTrue(r["committed"])
        self.assertIsNone(r["error"])
        self.assertEqual(r["snapshot"]["flags"][0]["variants"][0]["attachment"], {"x": 1})
        self.assertIsInstance(r["export"], str)

    def test_snapshot_atomic_fallback(self):
        contract = {
            "name": "snapshot",
            "inputs": [
                "inputs/case.json",
                "outputs/schema.json",
                "outputs/attachments.json",
                "outputs/references.json",
            ],
        }
        result = call_candidate(
            "views/snapshot/transform.py", "transform", args=[self._payloads(False), contract]
        )
        r = result["result"]
        self.assertFalse(r["committed"])
        self.assertEqual(r["snapshot"], {"flags": [], "version": 1})
        self.assertEqual(
            r["error"],
            {"kind": "segment", "flag": "f1", "rule": "r1", "target": "s1"},
        )
        self.assertIsNone(r["export"])


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            for rule, spec in req["rules"].items():
                if not spec.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule):
                    if rule == "invalid_payload_type":
                        check_api_boundary(
                            target,
                            rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"flags": [], "segments": []}], {"name": "x", "inputs": ["i"]}],
                        )
                    elif rule == "nonfinite_unknown_field":
                        check_api_boundary(
                            target,
                            rule=rule,
                            contract_path=spec["contract_path"],
                            requirement_quote=spec["requirement_quote"],
                            args=[[{"flags": [], "segments": []}], {"name": "x", "inputs": ["i"]}],
                        )


if __name__ == "__main__":
    unittest.main()
