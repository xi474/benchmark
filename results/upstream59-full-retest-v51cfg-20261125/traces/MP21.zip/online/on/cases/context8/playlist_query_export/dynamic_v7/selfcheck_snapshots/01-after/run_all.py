import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise SystemExit("no contracts")

    # Topological order by dependency on outputs of other components.
    produced = set()
    remaining = list(contracts)
    while remaining:
        progressed = False
        for cp in list(remaining):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps = [i for i in c["inputs"] if i.startswith("outputs/")]
            if all(d in produced for d in deps):
                subprocess.run(
                    [sys.executable, str(cp.with_name("render.py"))],
                    cwd=ROOT,
                    check=True,
                    timeout=60,
                )
                produced.add(c["output"])
                remaining.remove(cp)
                progressed = True
        if not progressed:
            raise SystemExit("dependency cycle or missing dependency")

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
