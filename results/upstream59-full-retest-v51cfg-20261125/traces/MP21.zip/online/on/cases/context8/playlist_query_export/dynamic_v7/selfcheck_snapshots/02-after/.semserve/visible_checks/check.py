import unittest

# Injected names available at runtime: call_candidate, CandidateCallError,
# check_api_boundary, visible_document.
try:
    visible_document
except NameError:
    visible_document = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "playlist/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": visible_document,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": visible_document,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "query/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": visible_document,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": visible_document,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "export/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": visible_document,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": visible_document,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestPlaylistReplace(unittest.TestCase):
    def test_playlist_replace_output(self):
        payload = {
            "tracks": [
                {"id": "a", "title": "T", "artist": "A", "path": "p.mp3", "duration": 2.5},
                {"id": "b", "title": "U", "artist": "B", "path": "q.mp3", "duration": 1.5},
            ],
            "playlist": {"id": "p", "name": "Mix", "track_ids": ["a"], "track_count": 1, "duration": 2.5},
            "replacement": ["b", "a", "b"],
            "criteria": {},
        }
        contract = {"name": "playlist", "operation": "playlist_replace", "inputs": ["x"], "output": "y"}
        result = call_candidate("playlist/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "playlist")
        r = result["result"]
        self.assertEqual(r["playlist"]["track_ids"], ["b", "a", "b"])
        self.assertEqual(r["playlist"]["track_count"], 3)
        self.assertAlmostEqual(r["playlist"]["duration"], 1.5 + 2.5 + 1.5)
        self.assertEqual([t["id"] for t in r["tracks"]], ["b", "a", "b"])

    def test_playlist_unknown_replacement_id(self):
        payload = {
            "tracks": [{"id": "a", "title": "T", "artist": "A", "path": "p.mp3", "duration": 1.0}],
            "playlist": {"id": "p", "name": "Mix", "track_ids": ["a"], "track_count": 1, "duration": 1.0},
            "replacement": ["zzz"],
            "criteria": {},
        }
        contract = {"name": "playlist", "operation": "playlist_replace", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("playlist/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestPlaylistQuery(unittest.TestCase):
    def test_query_sql_and_params(self):
        payload = {
            "criteria": {
                "filters": [
                    {"field": "track_count", "op": "ge", "value": 2},
                    {"field": "name", "op": "ne", "value": "O'Reilly"},
                ],
                "limit": 10,
            }
        }
        contract = {"name": "query", "operation": "playlist_query", "inputs": ["x"], "output": "y"}
        result = call_candidate("query/transform.py", "transform", args=[[payload], contract])
        r = result["result"]
        self.assertEqual(
            r["sql"],
            "SELECT id FROM playlists WHERE track_count ge ? AND name ne ? ORDER BY id LIMIT ?",
        )
        self.assertEqual(r["params"], [2, "O'Reilly", 10])

    def test_query_empty_filters(self):
        payload = {"criteria": {"filters": [], "limit": 5}}
        contract = {"name": "query", "operation": "playlist_query", "inputs": ["x"], "output": "y"}
        result = call_candidate("query/transform.py", "transform", args=[[payload], contract])
        r = result["result"]
        self.assertEqual(r["sql"], "SELECT id FROM playlists ORDER BY id LIMIT ?")
        self.assertEqual(r["params"], [5])

    def test_query_invalid_op_for_name(self):
        payload = {"criteria": {"filters": [{"field": "name", "op": "gt", "value": "x"}], "limit": 5}}
        contract = {"name": "query", "operation": "playlist_query", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("query/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestPlaylistM3u(unittest.TestCase):
    def test_m3u_rounding_and_order(self):
        payload = {
            "playlist": {"id": "p", "name": "Mix", "track_ids": ["a", "b"], "track_count": 2, "duration": 4.0},
            "tracks": [
                {"id": "a", "title": "T1", "artist": "A1", "path": "p.mp3", "duration": 2.5},
                {"id": "b", "title": "T2", "artist": "A2", "path": "q.mp3", "duration": 1.5},
            ],
        }
        contract = {"name": "export", "operation": "playlist_m3u", "inputs": ["x"], "output": "y"}
        result = call_candidate("export/transform.py", "transform", args=[[payload], contract])
        m3u = result["result"]["m3u"]
        self.assertEqual(
            m3u,
            "#EXTM3U\n#PLAYLIST:Mix\n#EXTINF:3,A1 - T1\np.mp3\n#EXTINF:2,A2 - T2\nq.mp3\n",
        )

    def test_m3u_empty_playlist(self):
        payload = {
            "playlist": {"id": "p", "name": "Mix", "track_ids": [], "track_count": 0, "duration": 0},
            "tracks": [],
        }
        contract = {"name": "export", "operation": "playlist_m3u", "inputs": ["x"], "output": "y"}
        result = call_candidate("export/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["m3u"], "#EXTM3U\n#PLAYLIST:Mix\n")


class TestApiBoundaries(unittest.TestCase):
    def test_api_boundary_rules(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            for rule_name, rule in req["rules"].items():
                with self.subTest(target=req["target_path"], rule=rule_name):
                    if not rule.get("applicable", False):
                        continue
                    check_api_boundary(
                        req["target_path"],
                        rule=rule_name,
                        contract_path=rule["contract_path"],
                        requirement_quote=rule["requirement_quote"],
                        args=[[{"tracks": [], "playlist": {"id": "p", "name": "M", "track_ids": [], "track_count": 0, "duration": 0}, "replacement": [], "criteria": {"filters": [], "limit": 1}}], {"name": "x", "operation": "y", "inputs": ["i"], "output": "o"}],
                    )


if __name__ == "__main__":
    unittest.main()
