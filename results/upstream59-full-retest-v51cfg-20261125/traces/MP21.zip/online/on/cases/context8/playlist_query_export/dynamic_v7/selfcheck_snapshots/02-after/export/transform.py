from decimal import Decimal, ROUND_HALF_UP
import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for x in obj:
            _reject_nonfinite(x)
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)


def _round_seconds(duration):
    return int(Decimal(str(duration)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    _reject_nonfinite(payload)
    if not isinstance(payload, dict):
        raise ValueError("input must be object")

    playlist = payload["playlist"]
    tracks = payload["tracks"]

    name = playlist["name"]
    if "\r" in name or "\n" in name:
        raise ValueError("playlist name contains CR/LF")

    by_id = {}
    for t in tracks:
        by_id[t["id"]] = t

    lines = ["#EXTM3U", "#PLAYLIST:" + name]
    for tid in playlist["track_ids"]:
        t = by_id[tid]
        artist = t["artist"]
        title = t["title"]
        if "\r" in artist or "\n" in artist or "\r" in title or "\n" in title:
            raise ValueError("CR/LF in track fields")
        seconds = _round_seconds(t["duration"])
        lines.append("#EXTINF:%d,%s - %s" % (seconds, artist, title))
        lines.append(t["path"])

    m3u = "\n".join(lines) + "\n"
    return {"name": contract["name"], "result": {"m3u": m3u}}
