import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for x in obj:
            _reject_nonfinite(x)
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)


def _is_int(x):
    return isinstance(x, int) and not isinstance(x, bool)


def _is_number(x):
    if isinstance(x, bool):
        return False
    if isinstance(x, int):
        return True
    if isinstance(x, float):
        return math.isfinite(x)
    return False


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = _unwrap(payloads[0])
    _reject_nonfinite(data)
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    tracks = data.get("tracks")
    playlist = data.get("playlist")
    replacement = data.get("replacement")

    if not isinstance(tracks, list):
        raise ValueError("tracks must be list")
    if not isinstance(playlist, dict):
        raise ValueError("playlist must be object")
    if not isinstance(replacement, list):
        raise ValueError("replacement must be list")

    track_map = {}
    for t in tracks:
        if not isinstance(t, dict):
            raise ValueError("track must be object")
        tid = t.get("id")
        if not isinstance(tid, str):
            raise ValueError("track id must be str")
        if tid in track_map:
            raise ValueError("duplicate track id")
        title = t.get("title")
        artist = t.get("artist")
        path = t.get("path")
        duration = t.get("duration")
        if not isinstance(title, str):
            raise ValueError("title must be str")
        if not isinstance(artist, str):
            raise ValueError("artist must be str")
        if not isinstance(path, str):
            raise ValueError("path must be str")
        if "\r" in title or "\n" in title:
            raise ValueError("title CR/LF")
        if "\r" in artist or "\n" in artist:
            raise ValueError("artist CR/LF")
        if "\r" in path or "\n" in path:
            raise ValueError("path CR/LF")
        if not _is_number(duration) or duration < 0:
            raise ValueError("duration must be non-negative finite number")
        track_map[tid] = t

    for rid in replacement:
        if not isinstance(rid, str):
            raise ValueError("replacement id must be str")
        if rid not in track_map:
            raise ValueError("unknown replacement id")

    pid = playlist.get("id")
    name = playlist.get("name")
    if not isinstance(pid, str):
        raise ValueError("playlist id must be str")
    if not isinstance(name, str):
        raise ValueError("playlist name must be str")
    if "\r" in name or "\n" in name:
        raise ValueError("playlist name CR/LF")

    new_tracks = [track_map[rid] for rid in replacement]
    total_duration = sum(t["duration"] for t in new_tracks)

    result = {
        "playlist": {
            "id": pid,
            "name": name,
            "track_ids": list(replacement),
            "track_count": len(replacement),
            "duration": total_duration,
        },
        "tracks": new_tracks,
    }

    return {"name": contract["name"], "result": result}
