import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, list):
        for x in obj:
            _reject_nonfinite(x)
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = _unwrap(payloads[0])
    _reject_nonfinite(data)
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    criteria = data.get("criteria")
    if not isinstance(criteria, dict):
        raise ValueError("criteria required")

    filters = criteria.get("filters")
    if not isinstance(filters, list):
        raise ValueError("filters required")

    limit = criteria.get("limit")
    if not _is_int(limit) or not (1 <= limit <= 100):
        raise ValueError("limit must be int 1..100")

    allowed_fields = {"id", "name", "track_count", "duration"}
    allowed_ops = {"eq", "ne", "gt", "ge", "lt", "le"}
    str_ops = {"eq", "ne"}

    where_parts = []
    params = []

    for f in filters:
        if not isinstance(f, dict):
            raise ValueError("filter must be object")
        field = f.get("field")
        op = f.get("op")
        value = f.get("value")

        if field not in allowed_fields:
            raise ValueError("invalid field")
        if op not in allowed_ops:
            raise ValueError("invalid op")

        if field in ("id", "name"):
            if op not in str_ops:
                raise ValueError("id/name only eq/ne")
            if not isinstance(value, str):
                raise ValueError("id/name value must be str")
        else:
            if not _is_number(value) or value < 0:
                raise ValueError("stat field value must be non-negative finite number")

        where_parts.append(f"{field} {op} ?")
        params.append(value)

    sql = "SELECT id FROM playlists"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)

    return {"name": contract["name"], "result": {"sql": sql, "params": params}}
