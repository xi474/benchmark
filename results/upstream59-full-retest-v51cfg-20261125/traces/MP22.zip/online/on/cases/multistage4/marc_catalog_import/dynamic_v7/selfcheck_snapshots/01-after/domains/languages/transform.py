def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    raw, records_payload = payloads[0], payloads[1]

    # Unwrap name/result envelope if present.
    raw = _unwrap(raw)
    records_payload = _unwrap(records_payload)

    language_codes = raw.get('language_codes')
    if not isinstance(language_codes, list):
        raise ValueError('language_codes must be a list')
    valid = set()
    for code in language_codes:
        if not isinstance(code, str) or len(code) != 3 or not code.islower():
            raise ValueError('invalid language code')
        valid.add(code)

    records = records_payload.get('records')
    if not isinstance(records, list):
        raise ValueError('records must be a list')

    out_records = []
    for rec in records:
        rid = rec['id']
        controls = rec.get('controls', {})
        fields = rec.get('fields', [])
        langs = set()

        # 008 controlfield: length >= 38, code at index 35..37.
        c008 = controls.get('008')
        if c008 is not None:
            if len(c008) < 38:
                raise ValueError('008 too short')
            code = c008[35:38]
            if code in valid:
                langs.add(code)

        # 041 subfields a/d/h: strip, split every 3 chars.
        for f in fields:
            if f.get('tag') != '041':
                continue
            for sf in f.get('subfields', []):
                if sf.get('code') not in ('a', 'd', 'h'):
                    continue
                val = sf.get('value', '')
                val = val.strip()
                if len(val) % 3 != 0:
                    raise ValueError('041 code length not multiple of 3')
                for i in range(0, len(val), 3):
                    code = val[i:i + 3]
                    if code in valid:
                        langs.add(code)

        out_records.append({'id': rid, 'languages': sorted(langs)})

    return {'name': contract['name'], 'result': {'records': out_records}}


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj) == {'name', 'result'}:
        return obj['result']
    return obj
