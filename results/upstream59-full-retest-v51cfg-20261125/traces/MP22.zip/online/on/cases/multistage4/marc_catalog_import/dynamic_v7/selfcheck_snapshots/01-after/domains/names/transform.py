def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    records = data["records"]
    out_records = []
    for rec in records:
        rid = rec["id"]
        fields = rec["fields"]
        authors = []
        titles = []
        # build alternates map: 880 fields keyed by their $6 target
        alt_map = {}
        for f in fields:
            if f["tag"] == "880":
                sub = {s["code"]: s["value"] for s in f["subfields"]}
                if "6" in sub:
                    alt_map.setdefault(sub["6"], []).append(f)
        for f in fields:
            tag = f["tag"]
            if tag == "100":
                authors.append(_build_entry(f, alt_map, "100", "name"))
            elif tag == "245":
                titles.append(_build_entry(f, alt_map, "245", "title"))
        out_records.append({
            "id": rid,
            "authors": authors,
            "titles": titles,
        })
    return {"name": contract["name"], "result": {"records": out_records}}


def _build_entry(f, alt_map, tag, key):
    sub = {s["code"]: s["value"] for s in f["subfields"]}
    name = _clean(_join(sub.get("a", ""), sub.get("b", "")))
    alternates = []
    six = sub.get("6")
    if six is not None:
        # $6 must be 880-NN
        if _valid_link(six, "880"):
            nn = six.split("-")[1].split("/")[0]
            target = tag + "-" + nn
            for k, afs in alt_map.items():
                if _valid_link(k, tag) and k.split("-")[1].split("/")[0] == nn:
                    for af in afs:
                        asub = {s["code"]: s["value"] for s in af["subfields"]}
                        alt = _clean(_join(asub.get("a", ""), asub.get("b", "")))
                        if alt:
                            alternates.append(alt)
    alternates = sorted(set(alternates))
    return {key: name, "alternates": alternates}


def _valid_link(six, expected_tag):
    parts = six.split("/")
    base = parts[0]
    if "-" not in base:
        return False
    tag, nn = base.split("-", 1)
    if tag != expected_tag:
        return False
    if not nn.isdigit():
        return False
    return True


def _join(a, b):
    if a and b:
        return a + " " + b
    return a if a else b


def _clean(s):
    # collapse internal whitespace
    s = " ".join(s.split())
    # strip leading/trailing spaces, slash, comma, colon, semicolon
    s = s.strip(" /,:;")
    return s
