import re
import xml.etree.ElementTree as ET


def _local(tag):
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag


def _is_controlfield_tag(tag):
    return bool(re.fullmatch(r"[0-9]{3}", tag))


def _is_datafield_tag(tag):
    return bool(re.fullmatch(r"[0-9]{3}", tag))


def _is_subfield_code(code):
    return bool(re.fullmatch(r"[A-Za-z0-9]", code))


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    # When input object has exactly name/result keys, only result is business input.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("input must be object")
    xml = payload.get("xml")
    language_codes = payload.get("language_codes")
    if not isinstance(xml, str):
        raise ValueError("xml must be string")
    if not isinstance(language_codes, list):
        raise ValueError("language_codes must be list")
    for code in language_codes:
        if not isinstance(code, str) or not re.fullmatch(r"[a-z]{3}", code):
            raise ValueError("invalid language code")

    if "DOCTYPE" in xml or "ENTITY" in xml:
        raise ValueError("DOCTYPE/ENTITY forbidden")

    try:
        root = ET.fromstring(xml)
    except ET.ParseError as e:
        raise ValueError("bad XML") from e

    rtag = _local(root.tag)
    if rtag not in ("collection", "record"):
        raise ValueError("root must be collection or record")

    records = []
    seen_ids = set()

    def parse_record(elem):
        rid = None
        controls = {}
        fields = []
        for child in elem:
            ctag = _local(child.tag)
            if ctag == "controlfield":
                tag = child.get("tag")
                if not _is_controlfield_tag(tag):
                    raise ValueError("bad controlfield tag")
                if tag in controls:
                    raise ValueError("duplicate controlfield tag")
                text = child.text if child.text is not None else ""
                controls[tag] = text
                if tag == "001":
                    if rid is not None:
                        raise ValueError("duplicate 001")
                    rid = text
            elif ctag == "datafield":
                tag = child.get("tag")
                if not _is_datafield_tag(tag):
                    raise ValueError("bad datafield tag")
                subfields = []
                for sub in child:
                    stag = _local(sub.tag)
                    if stag != "subfield":
                        raise ValueError("unknown element in datafield")
                    code = sub.get("code")
                    if not _is_subfield_code(code):
                        raise ValueError("bad subfield code")
                    value = sub.text if sub.text is not None else ""
                    subfields.append({"code": code, "value": value})
                fields.append({"tag": tag, "subfields": subfields})
            else:
                raise ValueError("unknown XML element")
        if rid is None or rid == "":
            raise ValueError("missing 001")
        return rid, controls, fields

    if rtag == "record":
        rid, controls, fields = parse_record(root)
        records.append({"id": rid, "controls": controls, "fields": fields})
        seen_ids.add(rid)
    else:
        for child in root:
            ctag = _local(child.tag)
            if ctag != "record":
                raise ValueError("unknown XML element")
            rid, controls, fields = parse_record(child)
            if rid in seen_ids:
                raise ValueError("duplicate record id")
            seen_ids.add(rid)
            records.append({"id": rid, "controls": controls, "fields": fields})

    records.sort(key=lambda r: r["id"])
    return {"name": contract["name"], "result": {"records": records}}
