def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]
    records = data["records"]

    tag_to_category = {
        "600": "people",
        "610": "organizations",
        "611": "meetings",
        "630": "works",
        "650": "topics",
        "651": "places",
    }

    out_records = []
    for rec in records:
        rid = rec["id"]
        fields = rec["fields"]
        counts = {cat: {} for cat in tag_to_category.values()}
        for f in fields:
            tag = f["tag"]
            if tag not in tag_to_category:
                continue
            sub = {}
            for s in f["subfields"]:
                sub.setdefault(s["code"], []).append(s["value"])
            main = _clean(_join(sub.get("a", []), sub.get("b", [])))
            subdivisions = []
            for code in ("v", "x", "y", "z"):
                for val in sub.get(code, []):
                    subdivisions.append(_clean(val))
            full = main
            if subdivisions:
                full = main + " -- " + " -- ".join(subdivisions)
            cat = tag_to_category[tag]
            counts[cat][full] = counts[cat].get(full, 0) + 1

        subjects = {}
        for cat in tag_to_category.values():
            items = [{"value": v, "count": c} for v, c in counts[cat].items()]
            items.sort(key=lambda x: x["value"])
            subjects[cat] = items
        out_records.append({"id": rid, "subjects": subjects})

    return {"name": contract["name"], "result": {"records": out_records}}


def _join(a_vals, b_vals):
    a = " ".join(a_vals)
    b = " ".join(b_vals)
    if a and b:
        return a + " " + b
    return a if a else b


def _clean(s):
    s = " ".join(s.split())
    s = s.strip(" /,:;")
    return s
