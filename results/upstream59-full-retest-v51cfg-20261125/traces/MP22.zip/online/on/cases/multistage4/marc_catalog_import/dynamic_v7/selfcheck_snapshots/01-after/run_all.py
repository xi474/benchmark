import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts[c['name']] = (cp, c)
    return contracts


def _topo_order(contracts):
    # Build dependency graph: component depends on components that produce its inputs.
    # Map output path -> component name.
    output_to_name = {}
    for name, (cp, c) in contracts.items():
        output_to_name[c['output']] = name

    deps = {}
    for name, (cp, c) in contracts.items():
        d = set()
        for inp in c['inputs']:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[name] = d

    # Detect cycles.
    order = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError('cycle detected in component dependencies')
        visiting.add(name)
        for dep in sorted(deps[name]):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(contracts):
        visit(name)
    return order


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError('no contracts')
    order = _topo_order(contracts)
    for name in order:
        cp, c = contracts[name]
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError('missing render.py for %s' % name)
        subprocess.run([sys.executable, str(render_py)], cwd=ROOT, check=True)

    # Run integrate.py then final_report.py.
    integrate_py = ROOT / 'integrate.py'
    subprocess.run([sys.executable, str(integrate_py)], cwd=ROOT, check=True)
    final_report_py = ROOT / 'final_report.py'
    subprocess.run([sys.executable, str(final_report_py)], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
