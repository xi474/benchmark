def _unwrap(obj):
    if isinstance(obj, dict) and set(obj) == {"name", "result"}:
        return obj["result"]
    return obj


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    names = _unwrap(payloads[0])
    languages = _unwrap(payloads[1])
    subjects = _unwrap(payloads[2])

    if not isinstance(names, dict) or not isinstance(languages, dict) or not isinstance(subjects, dict):
        raise ValueError("inputs must be objects")

    n_records = names.get("records")
    l_records = languages.get("records")
    s_records = subjects.get("records")

    if not isinstance(n_records, list) or not isinstance(l_records, list) or not isinstance(s_records, list):
        raise ValueError("records must be lists")

    def ids(records):
        seen = set()
        for r in records:
            rid = r["id"]
            if rid in seen:
                raise ValueError("duplicate id")
            seen.add(rid)
        return seen

    n_ids = ids(n_records)
    l_ids = ids(l_records)
    s_ids = ids(s_records)

    if not (n_ids == l_ids == s_ids):
        raise ValueError("record id sets must be identical")

    n_map = {r["id"]: r for r in n_records}
    l_map = {r["id"]: r for r in l_records}
    s_map = {r["id"]: r for r in s_records}

    records = []
    for rid in sorted(n_ids):
        records.append({
            "id": rid,
            "authors": n_map[rid]["authors"],
            "titles": n_map[rid]["titles"],
            "languages": l_map[rid]["languages"],
            "subjects": s_map[rid]["subjects"],
        })

    return {
        "name": contract["name"],
        "result": {"records": records, "record_count": len(records)},
    }
