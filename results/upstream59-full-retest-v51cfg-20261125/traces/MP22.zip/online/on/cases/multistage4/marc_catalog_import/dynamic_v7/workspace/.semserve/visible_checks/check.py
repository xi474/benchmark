import unittest

# Injected by the visible-contract SDK runner.
try:
    from visible_contract_check_sdk import call_candidate, CandidateCallError, check_api_boundary
except Exception:
    call_candidate = None
    CandidateCallError = Exception
    check_api_boundary = None

README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/reader/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/names/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/languages/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "domains/subjects/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "views/catalog/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        reader_payload = {
            "xml": "<collection><record><controlfield tag=\"001\">a</controlfield></record></collection>",
            "language_codes": ["eng"],
        }
        reader_contract = {"name": "reader", "operation": "marc_xml_records",
                           "inputs": ["inputs/case.json"], "output": "outputs/reader.json"}
        names_payload = {"records": [{"id": "a", "fields": []}]}
        names_contract = {"name": "names", "operation": "marc_names_titles",
                          "inputs": ["outputs/reader.json"], "output": "outputs/names.json"}
        lang_raw = {"language_codes": ["eng"]}
        lang_records = {"records": [{"id": "a", "controls": {}, "fields": []}]}
        lang_contract = {"name": "languages", "operation": "marc_languages",
                         "inputs": ["inputs/case.json", "outputs/reader.json"],
                         "output": "outputs/languages.json"}
        subj_payload = {"records": [{"id": "a", "fields": []}]}
        subj_contract = {"name": "subjects", "operation": "marc_subjects",
                         "inputs": ["outputs/reader.json"], "output": "outputs/subjects.json"}
        cat_names = {"records": [{"id": "a", "authors": [], "titles": []}]}
        cat_lang = {"records": [{"id": "a", "languages": []}]}
        cat_subj = {"records": [{"id": "a", "subjects": {}}]}
        cat_contract = {"name": "catalog", "operation": "marc_catalog",
                        "inputs": ["outputs/names.json", "outputs/languages.json",
                                   "outputs/subjects.json"],
                        "output": "outputs/catalog.json"}

        probes = [
            ("domains/reader/transform.py", [reader_payload], reader_contract),
            ("domains/names/transform.py", [names_payload], names_contract),
            ("domains/languages/transform.py", [lang_raw, lang_records], lang_contract),
            ("domains/subjects/transform.py", [subj_payload], subj_contract),
            ("views/catalog/transform.py", [cat_names, cat_lang, cat_subj], cat_contract),
        ]
        for target, args, contract in probes:
            with self.subTest(target=target, rule="nonfinite_unknown_field"):
                check_api_boundary(target, rule="nonfinite_unknown_field",
                                   contract_path=README,
                                   requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法。",
                                   args=args)
            with self.subTest(target=target, rule="invalid_payload_type"):
                check_api_boundary(target, rule="invalid_payload_type",
                                   contract_path=README,
                                   requirement_quote="model.load_payload(path:Path)：读取UTF8 JSON，仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
                                   args=args)


class TestReaderTransform(unittest.TestCase):
    def test_reader_output_shape_and_ordering(self):
        # Public rule: records sorted by id, controls/fields preserved.
        payload = {
            "xml": "<collection><record><controlfield tag=\"001\">b</controlfield>"
                   "<controlfield tag=\"008\">x</controlfield>"
                   "<datafield tag=\"245\"><subfield code=\"a\">T</subfield></datafield>"
                   "</record><record><controlfield tag=\"001\">a</controlfield>"
                   "<controlfield tag=\"008\">y</controlfield></record></collection>",
            "language_codes": ["eng"],
        }
        contract = {"name": "reader", "operation": "marc_xml_records",
                    "inputs": ["inputs/case.json"], "output": "outputs/reader.json"}
        result = call_candidate("domains/reader/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "reader")
        ids = [r["id"] for r in result["result"]["records"]]
        self.assertEqual(ids, ["a", "b"])
        self.assertEqual(result["result"]["records"][0]["controls"]["008"], "y")

    def test_reader_rejects_doctype(self):
        payload = {
            "xml": "<!DOCTYPE collection><collection><record>"
                   "<controlfield tag=\"001\">a</controlfield></record></collection>",
            "language_codes": ["eng"],
        }
        contract = {"name": "reader", "operation": "marc_xml_records",
                    "inputs": ["inputs/case.json"], "output": "outputs/reader.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/reader/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestLanguagesTransform(unittest.TestCase):
    def test_languages_gerlat_split(self):
        # Public rule: 041 $a "gerlat" must split into ger + lat, not one code.
        raw = {"language_codes": ["eng", "ger", "lat", "fra"]}
        records = {"records": [{
            "id": "r1",
            "controls": {"008": " " * 35 + "eng" + " " * 3},
            "fields": [{"tag": "041", "subfields": [{"code": "a", "value": "gerlat"}]}],
        }]}
        contract = {"name": "languages", "operation": "marc_languages",
                    "inputs": ["inputs/case.json", "outputs/reader.json"],
                    "output": "outputs/languages.json"}
        result = call_candidate("domains/languages/transform.py", "transform",
                                args=[[raw, records], contract])
        self.assertEqual(result["result"]["records"][0]["languages"],
                         ["eng", "ger", "lat"])

    def test_languages_041_bad_length(self):
        raw = {"language_codes": ["eng"]}
        records = {"records": [{
            "id": "r1",
            "controls": {},
            "fields": [{"tag": "041", "subfields": [{"code": "a", "value": "engx"}]}],
        }]}
        contract = {"name": "languages", "operation": "marc_languages",
                    "inputs": ["inputs/case.json", "outputs/reader.json"],
                    "output": "outputs/languages.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/languages/transform.py", "transform",
                           args=[[raw, records], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestSubjectsTransform(unittest.TestCase):
    def test_subjects_count_by_field(self):
        # Public rule: same full title counted per field occurrence, not per subfield.
        records = {"records": [{
            "id": "r1",
            "fields": [
                {"tag": "610", "subfields": [
                    {"code": "a", "value": "Jesuits."},
                    {"code": "b", "value": "Dept."},
                ]},
                {"tag": "610", "subfields": [
                    {"code": "a", "value": "Jesuits."},
                    {"code": "b", "value": "Dept."},
                ]},
            ],
        }]}
        contract = {"name": "subjects", "operation": "marc_subjects",
                    "inputs": ["outputs/reader.json"], "output": "outputs/subjects.json"}
        result = call_candidate("domains/subjects/transform.py", "transform",
                                args=[[records], contract])
        orgs = result["result"]["records"][0]["subjects"]["organizations"]
        self.assertEqual(orgs, [{"value": "Jesuits. Dept.", "count": 2}])


class TestCatalogTransform(unittest.TestCase):
    def test_catalog_joins_by_id(self):
        # Public rule: join by id, not row order; must not drop records.
        names = {"records": [
            {"id": "b", "authors": [], "titles": []},
            {"id": "a", "authors": [], "titles": []},
        ]}
        languages = {"records": [
            {"id": "a", "languages": ["eng"]},
            {"id": "b", "languages": ["ger"]},
        ]}
        subjects = {"records": [
            {"id": "b", "subjects": {}},
            {"id": "a", "subjects": {}},
        ]}
        contract = {"name": "catalog", "operation": "marc_catalog",
                    "inputs": ["outputs/names.json", "outputs/languages.json",
                               "outputs/subjects.json"],
                    "output": "outputs/catalog.json"}
        result = call_candidate("views/catalog/transform.py", "transform",
                                args=[[names, languages, subjects], contract])
        self.assertEqual(result["result"]["record_count"], 2)
        by_id = {r["id"]: r for r in result["result"]["records"]}
        self.assertEqual(by_id["a"]["languages"], ["eng"])
        self.assertEqual(by_id["b"]["languages"], ["ger"])

    def test_catalog_id_mismatch_raises(self):
        names = {"records": [{"id": "a", "authors": [], "titles": []}]}
        languages = {"records": [{"id": "b", "languages": []}]}
        subjects = {"records": [{"id": "a", "subjects": {}}]}
        contract = {"name": "catalog", "operation": "marc_catalog",
                    "inputs": ["outputs/names.json", "outputs/languages.json",
                               "outputs/subjects.json"],
                    "output": "outputs/catalog.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("views/catalog/transform.py", "transform",
                           args=[[names, languages, subjects], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
