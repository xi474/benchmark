import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core["components"]
    component_count = len(components)

    # attention: component names satisfying any condition, deduped and sorted.
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.add(name)
        for key in ("complete", "checkout", "committed", "ok"):
            if result.get(key) is False:
                attention.add(name)
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            v = result.get(key)
            if isinstance(v, (list, dict, str, tuple)) and len(v) > 0:
                attention.add(name)

    sha = hashlib.sha256(
        json.dumps(
            core,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()

    report = {
        "title": "受目录容量限制的可逆文件重分片",
        "component_count": component_count,
        "sha256": sha,
        "attention": sorted(attention),
    }

    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
