import json
import math
from pathlib import Path


def _check_finite(value, where):
    if isinstance(value, bool):
        raise ValueError("invalid type for %s" % where)
    if isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("non-finite number for %s" % where)
        return
    raise ValueError("invalid type for %s" % where)


def _check_no_nan(obj, where="payload"):
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number in %s" % where)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            _check_no_nan(v, where)
    elif isinstance(obj, list):
        for v in obj:
            _check_no_nan(v, where)


def load_payload(path):
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as e:
        raise ValueError("cannot read payload: %s" % e)
    try:
        obj = json.loads(text)
    except ValueError as e:
        raise ValueError("invalid JSON: %s" % e)
    if not isinstance(obj, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_no_nan(obj)
    return obj
