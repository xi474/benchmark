import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Locate all component contracts (excluding outputs).
    contracts = sorted(
        p for p in ROOT.rglob("contract.json")
        if "outputs" not in p.relative_to(ROOT).parts
    )
    if not contracts:
        raise SystemExit("no component contracts found")

    # Recompute every component output by running each component's render.py.
    for cp in contracts:
        comp_dir = cp.parent
        render = comp_dir / "render.py"
        if not render.is_file():
            raise SystemExit("missing render.py for " + str(comp_dir))
        subprocess.run(
            [sys.executable, str(render)],
            cwd=ROOT,
            check=True,
        )

    # Integrate all component results into core_manifest.json.
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
    )

    # Produce the final report.
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
