import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> raised for candidate exceptions

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/chunks/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/layout/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "products/restore/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestChunksTransform(unittest.TestCase):
    def test_api_boundary_probes(self):
        # Each target needs its own valid finite control args matching its signature.
        chunks_args = [[{"files": [{"path": "a.txt", "hex": "616263"}], "max_file_bytes": 16, "max_entries": 2}], {"name": "chunks", "operation": "reshard_chunks", "inputs": ["x"], "output": "y"}]
        layout_args = [[
            {"files": [{"path": "a.txt", "hex": "616263"}], "max_file_bytes": 16, "max_entries": 2},
            {"chunks": [{"name": "d000000.bin", "hex": "616263"}], "manifest": {"files": [{"path": "a.txt", "size": 3, "sha256": "x", "parts": ["d000000.bin"]}]}},
        ], {"name": "layout", "operation": "reshard_layout", "inputs": ["x", "y"], "output": "z"}]
        restore_args = [[{"tree": [{"path": "n0/d000000.bin", "hex": "616263"}, {"path": "n0/m000000.bin", "hex": "7b2266696c6573223a5b7b227061727473223a5b22643030303030302e62696e225d2c2270617468223a22612e747874222c22736861323536223a2262613738313662663866303163666561343134313430646535646165323232336230303336316133393631373761396362343130666636316632303031356164222c2273697a65223a337d5d7d"}], "max_entries": 4, "max_file_bytes": 1024}], {"name": "restore", "operation": "reshard_restore", "inputs": ["x"], "output": "y"}]
        for target, rules, args in [
            ("products/chunks/transform.py", ["invalid_payload_type", "nonfinite_unknown_field"], chunks_args),
            ("products/layout/transform.py", ["invalid_payload_type", "nonfinite_unknown_field"], layout_args),
            ("products/restore/transform.py", ["invalid_payload_type", "nonfinite_unknown_field"], restore_args),
        ]:
            for rule in rules:
                with self.subTest(target=target, rule=rule):
                    check_api_boundary(
                        target,
                        rule=rule,
                        contract_path="README.md",
                        requirement_quote="非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                        args=args,
                    )

    def test_chunks_roundtrip_shape(self):
        payload = {
            "files": [
                {"path": "a.txt", "hex": "616263"},
                {"path": "b.txt", "hex": ""},
            ],
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        contract = {"name": "chunks", "operation": "reshard_chunks", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/chunks/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "chunks")
        r = result["result"]
        self.assertIn("chunks", r)
        self.assertIn("manifest", r)
        # a.txt = 3 bytes -> one chunk d000000.bin
        self.assertEqual(r["chunks"][0]["name"], "d000000.bin")
        self.assertEqual(r["chunks"][0]["hex"], "616263")
        # b.txt empty -> no chunks
        self.assertEqual(len(r["chunks"]), 1)
        files = r["manifest"]["files"]
        self.assertEqual(files[0]["path"], "a.txt")
        self.assertEqual(files[0]["parts"], ["d000000.bin"])
        self.assertEqual(files[1]["path"], "b.txt")
        self.assertEqual(files[1]["parts"], [])

    def test_chunks_max_file_bytes_split(self):
        payload = {
            "files": [{"path": "a.txt", "hex": "6162636465"}],  # "abcde" 5 bytes
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        contract = {"name": "chunks", "operation": "reshard_chunks", "inputs": ["x"], "output": "y"}
        result = call_candidate("products/chunks/transform.py", "transform", args=[[payload], contract])
        r = result["result"]
        names = [c["name"] for c in r["chunks"]]
        self.assertEqual(names, ["d000000.bin"])
        self.assertEqual(r["chunks"][0]["hex"], "6162636465")
        self.assertEqual(r["manifest"]["files"][0]["parts"], names)


class TestRestoreTransform(unittest.TestCase):
    def test_restore_rejects_duplicate_d_block(self):
        # A tree with a d block referenced twice in manifest parts.
        tree = {
            "tree": [
                {"path": "n0/d000000.bin", "hex": "616263"},
                {"path": "n0/m000000.bin", "hex": ""},
            ],
            "max_entries": 4,
            "max_file_bytes": 64,
        }
        # Build manifest referencing d000000 twice.
        import json
        manifest = {"files": [{"path": "a.txt", "size": 6, "sha256": "", "parts": ["d000000.bin", "d000000.bin"]}]}
        mb = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
        tree["tree"][1]["hex"] = mb.hex()
        contract = {"name": "restore", "operation": "reshard_restore", "inputs": ["x"], "output": "y"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("products/restore/transform.py", "transform", args=[[tree], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestLayoutTransform(unittest.TestCase):
    def test_layout_tree_shape(self):
        payload = {
            "files": [{"path": "a.txt", "hex": "616263"}],
            "max_file_bytes": 16,
            "max_entries": 2,
        }
        chunks = {
            "chunks": [{"name": "d000000.bin", "hex": "616263"}],
            "manifest": {"files": [{"path": "a.txt", "size": 3, "sha256": "x", "parts": ["d000000.bin"]}]},
        }
        contract = {"name": "layout", "operation": "reshard_layout", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("products/layout/transform.py", "transform", args=[[payload, chunks], contract])
        r = result["result"]
        self.assertIn("tree", r)
        self.assertEqual(r["max_entries"], 2)
        self.assertEqual(r["max_file_bytes"], 16)
        # every tree entry has path and hex
        for item in r["tree"]:
            self.assertEqual(set(item), {"path", "hex"})


if __name__ == "__main__":
    unittest.main()
