import hashlib
import json
import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _safe_path(s):
    if not isinstance(s, str):
        raise ValueError("path must be string")
    if s.strip() == "":
        raise ValueError("path must be non-empty")
    if "\\" in s or ":" in s:
        raise ValueError("path must not contain backslash or colon")
    if s.startswith("/"):
        raise ValueError("path must not be absolute")
    parts = s.split("/")
    for part in parts:
        if part in ("", ".", ".."):
            raise ValueError("path must not contain empty segment, . or ..")
    return s


def transform(payloads, contract):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be list")
    if not isinstance(contract, dict):
        raise ValueError("contract must be dict")
    if "name" not in contract:
        raise ValueError("contract missing name")
    if "inputs" not in contract:
        raise ValueError("contract missing inputs")
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise ValueError("input must be object")
    _reject_nonfinite(payload)

    if "files" not in payload:
        raise ValueError("missing files")
    if "max_file_bytes" not in payload:
        raise ValueError("missing max_file_bytes")
    if "max_entries" not in payload:
        raise ValueError("missing max_entries")

    files = payload["files"]
    max_file_bytes = payload["max_file_bytes"]
    max_entries = payload["max_entries"]

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not _is_int(max_file_bytes) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not _is_int(max_entries) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    seen_paths = set()
    parsed_files = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path/hex")
        path = _safe_path(f["path"])
        if path in seen_paths:
            raise ValueError("duplicate path")
        seen_paths.add(path)
        hexstr = f["hex"]
        if not isinstance(hexstr, str):
            raise ValueError("hex must be string")
        try:
            raw = bytes.fromhex(hexstr)
        except ValueError as exc:
            raise ValueError("invalid hex") from exc
        parsed_files.append((path, raw))

    parsed_files.sort(key=lambda x: x[0])

    chunks = []
    manifest_files = []
    counter = 0
    for path, raw in parsed_files:
        parts = []
        if len(raw) == 0:
            pass
        else:
            for i in range(0, len(raw), max_file_bytes):
                piece = raw[i:i + max_file_bytes]
                name = "d%06d.bin" % counter
                counter += 1
                chunks.append({"name": name, "hex": piece.hex()})
                parts.append(name)
        sha = hashlib.sha256(raw).hexdigest()
        manifest_files.append({
            "path": path,
            "size": len(raw),
            "sha256": sha,
            "parts": parts,
        })

    result = {
        "chunks": chunks,
        "manifest": {"files": manifest_files},
    }
    return {"name": contract["name"], "result": result}
