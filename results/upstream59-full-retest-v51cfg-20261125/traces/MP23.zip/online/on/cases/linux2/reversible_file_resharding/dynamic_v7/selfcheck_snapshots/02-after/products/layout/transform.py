import hashlib
import json
import math


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and (
        not isinstance(v, float) or math.isfinite(v)
    )


def _require(cond, msg):
    if not cond:
        raise ValueError(msg)


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _safe_path(p):
    if not isinstance(p, str):
        raise ValueError("path must be string")
    if p == "" or p != p.strip():
        raise ValueError("path must be non-empty and stripped")
    if "\\" in p or ":" in p:
        raise ValueError("path contains forbidden characters")
    if p.startswith("/"):
        raise ValueError("absolute path forbidden")
    parts = p.split("/")
    for seg in parts:
        if seg in ("", ".", ".."):
            raise ValueError("path contains empty/dot segment")
    return p


def _hex_bytes(h):
    if not isinstance(h, str):
        raise ValueError("hex must be string")
    try:
        return bytes.fromhex(h)
    except ValueError:
        raise ValueError("invalid hex")


def transform(payloads, contract):
    _require(isinstance(payloads, list), "payloads must be list")
    _require(isinstance(contract, dict), "contract must be dict")
    _require(len(payloads) == len(contract["inputs"]),
             "payload count mismatch")

    raw_input = payloads[0]
    chunks_result = payloads[1]

    # Unwrap name/result envelope if present.
    if isinstance(raw_input, dict) and set(raw_input) == {"name", "result"}:
        raw_input = raw_input["result"]
    if isinstance(chunks_result, dict) and set(chunks_result) == {"name", "result"}:
        chunks_result = chunks_result["result"]

    _require(isinstance(raw_input, dict), "input must be object")
    _require(isinstance(chunks_result, dict), "chunks result must be object")
    _reject_nonfinite(raw_input)
    _reject_nonfinite(chunks_result)

    # Validate raw input fields.
    _require("files" in raw_input, "missing files")
    _require(isinstance(raw_input["files"], list), "files must be list")
    _require("max_file_bytes" in raw_input, "missing max_file_bytes")
    _require(_is_int(raw_input["max_file_bytes"]), "max_file_bytes must be int")
    _require(raw_input["max_file_bytes"] >= 16, "max_file_bytes must be >= 16")
    _require("max_entries" in raw_input, "missing max_entries")
    _require(_is_int(raw_input["max_entries"]), "max_entries must be int")
    _require(raw_input["max_entries"] >= 2, "max_entries must be >= 2")

    max_file_bytes = raw_input["max_file_bytes"]
    max_entries = raw_input["max_entries"]

    # Validate chunks result.
    _require("chunks" in chunks_result, "missing chunks")
    _require(isinstance(chunks_result["chunks"], list), "chunks must be list")
    _require("manifest" in chunks_result, "missing manifest")
    _require(isinstance(chunks_result["manifest"], dict), "manifest must be dict")

    chunks = chunks_result["chunks"]
    manifest = chunks_result["manifest"]

    # Build data blocks (d*.bin) from chunks.
    data_blocks = []
    for ch in chunks:
        _require(isinstance(ch, dict), "chunk must be object")
        _require("name" in ch and "hex" in ch, "chunk missing name/hex")
        name = ch["name"]
        _require(isinstance(name, str), "chunk name must be string")
        data_blocks.append({"name": name, "hex": ch["hex"]})

    # Build metadata blocks (m*.bin) from compact manifest JSON.
    manifest_bytes = json.dumps(
        manifest, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")

    meta_blocks = []
    idx = 0
    for i in range(0, len(manifest_bytes), max_file_bytes):
        part = manifest_bytes[i:i + max_file_bytes]
        name = "m%06d.bin" % idx
        meta_blocks.append({"name": name, "hex": part.hex()})
        idx += 1

    # Sort all blocks by name.
    all_blocks = sorted(data_blocks + meta_blocks, key=lambda b: b["name"])
    N = len(all_blocks)

    # Determine minimal h such that max_entries**h >= N.
    h = 1
    while max_entries ** h < N:
        h += 1

    # Build tree paths.
    tree = []
    for i, blk in enumerate(all_blocks):
        # Convert i to exactly h digits in base max_entries.
        digits = []
        v = i
        for _ in range(h):
            digits.append(v % max_entries)
            v //= max_entries
        digits.reverse()
        # First h-1 digits become directory names n<digit>.
        dirs = ["n%d" % d for d in digits[:-1]]
        path = "/".join(dirs + [blk["name"]]) if dirs else blk["name"]
        tree.append({"path": path, "hex": blk["hex"]})

    tree.sort(key=lambda t: t["path"])

    result = {
        "tree": tree,
        "max_entries": max_entries,
        "max_file_bytes": max_file_bytes,
    }

    return {"name": contract["name"], "result": result}
