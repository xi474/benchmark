import hashlib
import json
import math
import re
from pathlib import PurePosixPath


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _safe_rel_path(s):
    if not isinstance(s, str):
        raise ValueError("path must be string")
    if s == "" or s != s.strip():
        raise ValueError("path must be non-empty and stripped")
    if "\\" in s or ":" in s:
        raise ValueError("path must not contain backslash or colon")
    if s.startswith("/"):
        raise ValueError("path must not be absolute")
    parts = s.split("/")
    for part in parts:
        if part in ("", ".", ".."):
            raise ValueError("path must not contain empty, . or .. segments")
    return s


def _parse_basename(name):
    m = re.fullmatch(r"([md])([0-9]{6,})\.bin", name)
    if not m:
        raise ValueError("invalid basename: " + name)
    return m.group(1), int(m.group(2))


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    tree_payload = payloads[0]
    # When input object has exactly name/result keys, only result is business input.
    if isinstance(tree_payload, dict) and set(tree_payload) == {"name", "result"}:
        tree_payload = tree_payload["result"]

    if not isinstance(tree_payload, dict):
        raise ValueError("layout must be object")
    _reject_nonfinite(tree_payload)
    if "tree" not in tree_payload or "max_entries" not in tree_payload or "max_file_bytes" not in tree_payload:
        raise ValueError("missing required fields")

    tree = tree_payload["tree"]
    max_entries = tree_payload["max_entries"]
    max_file_bytes = tree_payload["max_file_bytes"]

    if not _is_int(max_entries) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")
    if not _is_int(max_file_bytes) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")

    if not isinstance(tree, list):
        raise ValueError("tree must be list")

    # Validate each entry and collect blocks.
    entries = []
    seen_paths = set()
    seen_basenames = set()
    for item in tree:
        if not isinstance(item, dict) or set(item) != {"path", "hex"}:
            raise ValueError("tree entry must have exactly path and hex")
        path = _safe_rel_path(item["path"])
        hexv = item["hex"]
        if not isinstance(hexv, str):
            raise ValueError("hex must be string")
        try:
            data = bytes.fromhex(hexv)
        except ValueError:
            raise ValueError("invalid hex")
        if path in seen_paths:
            raise ValueError("duplicate path")
        seen_paths.add(path)
        basename = PurePosixPath(path).name
        if basename in seen_basenames:
            raise ValueError("duplicate basename")
        seen_basenames.add(basename)
        if len(data) > max_file_bytes:
            raise ValueError("file exceeds max_file_bytes")
        entries.append((path, basename, data))

    # Validate directory entry counts: each directory's direct children
    # (files and subdirectories) must not exceed max_entries.
    dir_counts = {}
    for path, basename, data in entries:
        parts = path.split("/")
        for i in range(len(parts) - 1):
            d = "/".join(parts[: i + 1])
            child = parts[i + 1]
            dir_counts.setdefault(d, set()).add(child)
    for d, children in dir_counts.items():
        if len(children) > max_entries:
            raise ValueError("directory exceeds max_entries")

    # Parse basenames into m/d blocks.
    m_blocks = {}
    d_blocks = {}
    for path, basename, data in entries:
        kind, num = _parse_basename(basename)
        if kind == "m":
            if num in m_blocks:
                raise ValueError("duplicate m block")
            m_blocks[num] = data
        else:
            if num in d_blocks:
                raise ValueError("duplicate d block")
            d_blocks[num] = data

    # m blocks must be contiguous from 0.
    if m_blocks:
        nums = sorted(m_blocks)
        if nums != list(range(len(nums))):
            raise ValueError("m blocks not contiguous from 0")

    # Concatenate m blocks and parse manifest.
    manifest_bytes = b"".join(m_blocks[n] for n in sorted(m_blocks))
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise ValueError("invalid manifest JSON")

    if not isinstance(manifest, dict) or "files" not in manifest:
        raise ValueError("manifest must have files")
    files = manifest["files"]
    if not isinstance(files, list):
        raise ValueError("manifest files must be list")

    # Reconstruct files.
    result_files = []
    used_d = set()
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("manifest file entry must be object")
        if set(f) != {"path", "size", "sha256", "parts"}:
            raise ValueError("manifest file entry fields invalid")
        path = _safe_rel_path(f["path"])
        size = f["size"]
        if not _is_int(size) or size < 0:
            raise ValueError("size must be non-negative int")
        sha = f["sha256"]
        if not isinstance(sha, str):
            raise ValueError("sha256 must be string")
        parts = f["parts"]
        if not isinstance(parts, list):
            raise ValueError("parts must be list")
        data = b""
        for pname in parts:
            if not isinstance(pname, str):
                raise ValueError("part name must be string")
            kind, num = _parse_basename(pname)
            if kind != "d":
                raise ValueError("part must be d block")
            if num in used_d:
                raise ValueError("d block referenced more than once")
            used_d.add(num)
            if num not in d_blocks:
                raise ValueError("missing d block")
            data += d_blocks[num]
        if len(data) != size:
            raise ValueError("size mismatch")
        if hashlib.sha256(data).hexdigest() != sha:
            raise ValueError("sha256 mismatch")
        result_files.append({"path": path, "hex": data.hex()})

    # Every d block must be referenced exactly once.
    if set(d_blocks) != used_d:
        raise ValueError("extra or unreferenced d block")

    result_files.sort(key=lambda x: x["path"])
    total_bytes = sum(len(bytes.fromhex(x["hex"])) for x in result_files)

    return {"name": contract["name"], "result": {"files": result_files, "total_bytes": total_bytes}}
