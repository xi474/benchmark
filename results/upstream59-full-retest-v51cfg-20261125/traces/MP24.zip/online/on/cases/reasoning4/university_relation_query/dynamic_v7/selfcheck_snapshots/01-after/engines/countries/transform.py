def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = _unwrap(payloads[0])

    departments = data["departments"]
    professors = data["professors"]

    dept_country = {}
    for d in departments:
        dept_country[d["id"]] = d["country"]

    countries = {}
    for prof in professors:
        pid = prof["id"]
        depts = prof["departments"]
        seen = set()
        for did in depts:
            seen.add(dept_country[did])
        countries[pid] = sorted(seen)

    return {"name": contract["name"], "result": {"countries": countries}}
