def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    departments = payload["departments"]
    professors = payload["professors"]
    eu = set(payload["eu"])

    country_by_dept = {}
    for d in departments:
        country_by_dept[d["id"]] = d["country"]

    ids = []
    for prof in professors:
        for dept_id in prof["departments"]:
            if country_by_dept.get(dept_id) in eu:
                ids.append(prof["id"])
                break

    ids.sort()
    return {"name": contract["name"], "result": {"ids": ids}}
