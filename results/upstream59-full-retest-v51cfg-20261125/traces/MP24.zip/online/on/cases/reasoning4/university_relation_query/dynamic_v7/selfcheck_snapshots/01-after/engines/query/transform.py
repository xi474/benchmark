def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    raw = _unwrap(payloads[0])
    eu_result = _unwrap(payloads[1])
    students_result = _unwrap(payloads[2])
    countries_result = _unwrap(payloads[3])

    eligible_ids = set(eu_result["ids"])
    counts = students_result["counts"]
    countries = countries_result["countries"]

    professors = []
    for prof in raw["professors"]:
        pid = prof["id"]
        if pid not in eligible_ids:
            continue
        eligible_departments = sorted(
            d for d in prof["departments"] if counts.get(d, 0) > 10
        )
        if not eligible_departments:
            continue
        professors.append({
            "id": pid,
            "countries": countries.get(pid, []),
            "eligible_departments": eligible_departments,
        })

    professors.sort(key=lambda p: p["id"])
    return {"name": contract["name"], "result": {"professors": professors}}
