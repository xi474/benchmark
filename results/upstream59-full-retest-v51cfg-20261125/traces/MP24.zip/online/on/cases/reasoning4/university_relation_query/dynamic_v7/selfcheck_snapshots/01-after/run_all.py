import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(ROOT.rglob("contract.json"))
    contracts = [c for c in contracts if "outputs" not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError("no contracts")

    # Topological order by input dependency on other component outputs.
    outputs = {c.parent.name: c for c in contracts}
    produced = set()

    remaining = list(contracts)
    while remaining:
        progressed = False
        for c in list(remaining):
            contract = json.loads(c.read_text(encoding="utf-8"))
            deps = []
            for inp in contract["inputs"]:
                p = Path(inp)
                if p.parts and p.parts[0] == "outputs":
                    dep_name = p.stem
                    if dep_name in outputs and dep_name not in produced:
                        deps.append(dep_name)
            if not deps:
                subprocess.run(
                    [sys.executable, str(c.parent / "render.py")],
                    cwd=ROOT, check=True, timeout=60,
                )
                produced.add(contract["name"])
                remaining.remove(c)
                progressed = True
        if not progressed:
            raise ValueError("dependency cycle or missing dependency")

    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True, timeout=60)


if __name__ == "__main__":
    main()
