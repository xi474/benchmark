import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/eu/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/students/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/countries/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "engines/query/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "任意嵌套NaN/Infinity抛ValueError",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_api_boundary_probes(self):
        for req in API_BOUNDARY_REQUIREMENTS:
            target = req["target_path"]
            rules = req["rules"]
            for rule_name, rule in rules.items():
                if not rule.get("applicable"):
                    continue
                with self.subTest(target=target, rule=rule_name):
                    if target == "engines/query/transform.py":
                        args = [[
                            {
                                "departments": [{"id": "a", "country": "DE"}],
                                "professors": [{"id": "p1", "departments": ["a"]}],
                                "students": [],
                                "as_of": "2025-01-01",
                                "eu": ["DE"],
                            },
                            {"name": "eu", "result": {"ids": ["p1"]}},
                            {"name": "students", "result": {"counts": {"a": 0}}},
                            {"name": "countries", "result": {"countries": {"p1": ["DE"]}}},
                        ], {"name": "query", "operation": "university_query", "inputs": ["i", "j", "k", "l"], "output": "o"}]
                    else:
                        args = [[
                            {
                                "departments": [{"id": "a", "country": "DE"}],
                                "professors": [{"id": "p1", "departments": ["a"]}],
                                "students": [],
                                "as_of": "2025-01-01",
                                "eu": ["DE"],
                            }
                        ], {"name": "x", "operation": "op", "inputs": ["i"], "output": "o"}]
                    check_api_boundary(
                        target,
                        rule=rule_name,
                        contract_path=rule["contract_path"],
                        requirement_quote=rule["requirement_quote"],
                        args=args,
                    )


class TestBusinessBehavior(unittest.TestCase):
    def test_query_requires_department_over_10(self):
        # Two departments of 6 each must not qualify; only a single dept >10 does.
        raw = {
            "departments": [
                {"id": "a", "country": "DE"},
                {"id": "b", "country": "US"},
            ],
            "professors": [{"id": "p1", "departments": ["a", "b"]}],
            "students": [],
            "as_of": "2025-01-01",
            "eu": ["DE"],
        }
        eu = {"name": "eu", "result": {"ids": ["p1"]}}
        students = {"name": "students", "result": {"counts": {"a": 6, "b": 6}}}
        countries = {"name": "countries", "result": {"countries": {"p1": ["DE", "US"]}}}
        payloads = [raw, eu, students, countries]
        contract = {"name": "query", "operation": "university_query", "inputs": ["x", "y", "z", "w"], "output": "o"}
        result = call_candidate("engines/query/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(result["result"]["professors"], [])

    def test_query_qualifies_single_dept_over_10(self):
        raw = {
            "departments": [
                {"id": "a", "country": "DE"},
                {"id": "b", "country": "US"},
            ],
            "professors": [{"id": "p1", "departments": ["a", "b"]}],
            "students": [],
            "as_of": "2025-01-01",
            "eu": ["DE"],
        }
        eu = {"name": "eu", "result": {"ids": ["p1"]}}
        students = {"name": "students", "result": {"counts": {"a": 11, "b": 6}}}
        countries = {"name": "countries", "result": {"countries": {"p1": ["DE", "US"]}}}
        payloads = [raw, eu, students, countries]
        contract = {"name": "query", "operation": "university_query", "inputs": ["x", "y", "z", "w"], "output": "o"}
        result = call_candidate("engines/query/transform.py", "transform", args=[payloads, contract])
        self.assertEqual(
            result["result"]["professors"],
            [{"id": "p1", "countries": ["DE", "US"], "eligible_departments": ["a"]}],
        )

    def test_students_distinct_per_department(self):
        # Same student enrolled twice in same dept counts once.
        raw = {
            "departments": [{"id": "a", "country": "DE"}],
            "professors": [],
            "students": [
                {
                    "id": "s1",
                    "enrolments": [
                        {"department": "a", "start": "2024-01-01", "end": None},
                        {"department": "a", "start": "2024-01-01", "end": None},
                    ],
                }
            ],
            "as_of": "2025-01-01",
            "eu": ["DE"],
        }
        contract = {"name": "students", "operation": "department_students", "inputs": ["x"], "output": "o"}
        result = call_candidate("engines/students/transform.py", "transform", args=[[raw], contract])
        self.assertEqual(result["result"]["counts"], {"a": 1})

    def test_students_end_exclusive(self):
        raw = {
            "departments": [{"id": "a", "country": "DE"}],
            "professors": [],
            "students": [
                {
                    "id": "s1",
                    "enrolments": [
                        {"department": "a", "start": "2024-01-01", "end": "2025-01-01"},
                    ],
                }
            ],
            "as_of": "2025-01-01",
            "eu": ["DE"],
        }
        contract = {"name": "students", "operation": "department_students", "inputs": ["x"], "output": "o"}
        result = call_candidate("engines/students/transform.py", "transform", args=[[raw], contract])
        # as_of < end required, so end == as_of is not enrolled.
        self.assertEqual(result["result"]["counts"], {"a": 0})

    def test_countries_dedup_sorted(self):
        raw = {
            "departments": [
                {"id": "a", "country": "US"},
                {"id": "b", "country": "DE"},
                {"id": "c", "country": "US"},
            ],
            "professors": [{"id": "p1", "departments": ["a", "b", "c"]}],
            "students": [],
            "as_of": "2025-01-01",
            "eu": ["DE"],
        }
        contract = {"name": "countries", "operation": "employment_countries", "inputs": ["x"], "output": "o"}
        result = call_candidate("engines/countries/transform.py", "transform", args=[[raw], contract])
        self.assertEqual(result["result"]["countries"], {"p1": ["DE", "US"]})

    def test_eu_qualifies_any_dept(self):
        raw = {
            "departments": [
                {"id": "a", "country": "US"},
                {"id": "b", "country": "DE"},
            ],
            "professors": [{"id": "p1", "departments": ["a", "b"]}],
            "students": [],
            "as_of": "2025-01-01",
            "eu": ["DE"],
        }
        contract = {"name": "eu", "operation": "eu_professors", "inputs": ["x"], "output": "o"}
        result = call_candidate("engines/eu/transform.py", "transform", args=[[raw], contract])
        self.assertEqual(result["result"]["ids"], ["p1"])


if __name__ == "__main__":
    unittest.main()
