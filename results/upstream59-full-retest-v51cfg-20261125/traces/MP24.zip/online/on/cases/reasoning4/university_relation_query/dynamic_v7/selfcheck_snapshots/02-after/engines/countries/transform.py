import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    if not isinstance(payloads[0], (dict, list)):
        raise ValueError("payload must be object or array")
    _reject_nonfinite(payloads[0])
    data = _unwrap(payloads[0])

    departments = data["departments"]
    professors = data["professors"]

    dept_country = {}
    for d in departments:
        dept_country[d["id"]] = d["country"]

    countries = {}
    for prof in professors:
        pid = prof["id"]
        depts = prof["departments"]
        seen = set()
        for did in depts:
            seen.add(dept_country[did])
        countries[pid] = sorted(seen)

    return {"name": contract["name"], "result": {"countries": countries}}
