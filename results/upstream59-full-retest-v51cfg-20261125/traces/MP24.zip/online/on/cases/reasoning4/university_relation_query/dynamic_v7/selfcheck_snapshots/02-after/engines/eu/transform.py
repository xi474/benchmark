import math


def _reject_nonfinite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _reject_nonfinite(v)
    elif isinstance(obj, list):
        for v in obj:
            _reject_nonfinite(v)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, (dict, list)):
        raise ValueError("payload must be object or array")
    _reject_nonfinite(payload)
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]

    departments = payload["departments"]
    professors = payload["professors"]
    eu = set(payload["eu"])

    country_by_dept = {}
    for d in departments:
        country_by_dept[d["id"]] = d["country"]

    ids = []
    for prof in professors:
        for dept_id in prof["departments"]:
            if country_by_dept.get(dept_id) in eu:
                ids.append(prof["id"])
                break

    ids.sort()
    return {"name": contract["name"], "result": {"ids": ids}}
