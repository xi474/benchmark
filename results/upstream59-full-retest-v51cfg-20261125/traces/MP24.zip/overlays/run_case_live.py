"""Run one historical coding case under the current v8 Runtime configuration.

The runner intentionally ignores every case's audit_only/frontier metadata.
Only the natural-language task, immutable fixture list, template workspace, and
root check.py are used.  Parallel opportunities must be discovered online by
the executor, Runtime frontier reports, and the Qwen predictor.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
from collections import Counter
from dataclasses import replace
from pathlib import Path


# Windows otherwise inherits GBK and can turn a correct task into a late
# UnicodeEncodeError when the executor prints a check mark or other UTF-8 text.
for _stream in (sys.stdout, sys.stderr):
    _reconfigure = getattr(_stream, "reconfigure", None)
    if callable(_reconfigure):
        _reconfigure(encoding="utf-8", errors="replace")


ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(Path(__file__).resolve().parent), str(ROOT), str(ROOT / "bin")]
BASE = ROOT.parent
VBA_ROOT = BASE / "VBA-Harbor-LocalQwen32B-20261025"
CURRENT_SRC = VBA_ROOT / "runtime-snapshot" / "src"
OFOX_ROOT = BASE / "Ofox-MultiBackend5-MockOffer-20261024"
LOCK = threading.RLock()
LOCAL = threading.local()
CASE: Path | None = None
WORKSPACE: Path | None = None
ARM = ""
PREDICTOR_ENDPOINT = ""
PREDICTOR_MODEL = "Qwen3-32B"
EXECUTOR_MODEL = "deepseek/deepseek-v4-pro-0813"
CURRENT_MAX_PARALLELISM = 8


GROUPS = {
    "multistage4": BASE / "DeepSeek-V4Pro-Multistage4-MockVsReal-20261021",
    "reasoning4": BASE / "DeepSeek-V4Pro-Reasoning4-MockOffer-Ablation-20261021",
    "context8": BASE / "DeepSeek-V4Pro-ComplexLong8-StructuredContext-AB-20261022",
    "linux2": BASE / "DeepParallel-Linux-LongTool-20261023",
}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def credentials():
    helper = load_module(
        "qwen_experiment_access_retest18",
        OFOX_ROOT / "qwen_experiment_access.py",
    )
    key, _ = helper.current_chat_credentials()
    if not key:
        raise RuntimeError("Ofox credential unavailable in the active chat")
    return key, helper


def rows(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(name: str, row: dict) -> None:
    if CASE is None:
        return
    with LOCK, (CASE / name).open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def interval_union_seconds(items: list[dict]) -> float:
    intervals = sorted(
        (float(item["start"]), float(item["end"]))
        for item in items
        if item.get("end", 0) > item.get("start", 0)
    )
    if not intervals:
        return 0.0
    total = 0.0
    left, right = intervals[0]
    for start, end in intervals[1:]:
        if start <= right:
            right = max(right, end)
        else:
            total += right - left
            left, right = start, end
    return total + right - left


def overlap_stats(turns: list[dict]) -> dict:
    children = [
        row for row in turns
        if row.get("parent_task_id") and row.get("end", 0) > row.get("start", 0)
    ]
    pairs = []
    for index, left in enumerate(children):
        for right in children[index + 1:]:
            if left.get("scope") == right.get("scope"):
                continue
            overlap = max(
                0.0,
                min(float(left["end"]), float(right["end"]))
                - max(float(left["start"]), float(right["start"])),
            )
            if overlap:
                pairs.append({
                    "a": left.get("scope"),
                    "b": right.get("scope"),
                    "seconds": overlap,
                })
    return {
        "child_model_turns": len(children),
        "overlap_pair_count": len(pairs),
        "max_model_request_overlap_seconds": max(
            (item["seconds"] for item in pairs), default=0.0
        ),
        "pairs": pairs[:100],
    }


def main() -> None:
    global CASE, WORKSPACE, ARM, PREDICTOR_ENDPOINT, CURRENT_SRC, EXECUTOR_MODEL
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", required=True, choices=sorted(GROUPS))
    parser.add_argument("--case", required=True)
    parser.add_argument("--arm", required=True, choices=("dynamic_v7", "no_offer"))
    parser.add_argument("--result-root", required=True)
    parser.add_argument("--task-source", type=Path, help="Portable task directory containing TASK.md and workspace/; no design manifest is consumed")
    parser.add_argument("--max-output-tokens", type=int, default=32768)
    parser.add_argument("--provider-timeout", type=int, default=600)
    parser.add_argument("--executor-base-url", default="https://api.ofox.io/v1")
    parser.add_argument("--executor-model", default=EXECUTOR_MODEL)
    parser.add_argument("--executor-key-user-thread")
    parser.add_argument("--executor-key-fingerprint", default="")
    parser.add_argument("--plan-check-fix", action="store_true")
    parser.add_argument("--contract-ownership-fix", action="store_true")
    parser.add_argument("--predictor-input-budget-fix", action="store_true")
    parser.add_argument("--two-user-turns", action="store_true",
                        help="TASK.md then TURN2.md, with round2_workspace released after turn1")
    parser.add_argument("--predictor-tokenizer", type=Path)
    parser.add_argument("--predictor-context-tokens", type=int)
    parser.add_argument("--max-parallelism", type=int, default=None)
    parser.add_argument("--max-subtasks", type=int, default=None)
    parser.add_argument("--offer-width-policy", choices=("bucket_lower_bound", "bucket_upper_bound"), default=None)
    parser.add_argument("--task-prompt-limit", type=int, choices=(150, 512), default=150)
    parser.add_argument("--handshake-input", choices=("full", "c1", "c2", "c3", "c4"), default="c1")
    parser.add_argument("--handshake-window-turns", type=int, default=3)
    parser.add_argument("--c4-summary-model", default="qwen/qwen3.5-flash")
    parser.add_argument("--c4-summary-every", type=int)
    parser.add_argument("--c4-input-max-chars", type=int, default=65536)
    parser.add_argument("--c4-native-h3", action="store_true",
                        help="Use the native H3 snapshot and append-only handshake input")
    parser.add_argument("--h3-input-max-chars", type=int,
                        help="Final serialized H3 input character cap (default: 131072)")
    parser.add_argument("--h3-restore-effective-batches", type=int,
                        help="Effective delta batches between H3 snapshots (default: 12)")
    parser.add_argument("--handshake-model")
    parser.add_argument("--speculative-generation", action="store_true")
    args = parser.parse_args()
    if args.c4_summary_every is None:
        args.c4_summary_every = 4 if args.c4_native_h3 else 3
    if args.c4_native_h3:
        if args.handshake_input != "c4" or not (args.contract_ownership_fix and args.speculative_generation):
            parser.error("--c4-native-h3 requires c4 and the active ownership/speculative runtime")
        from handshake_h3 import DEFAULT_INPUT_MAX_CHARS
        if args.h3_input_max_chars is None:
            args.h3_input_max_chars = DEFAULT_INPUT_MAX_CHARS
        if args.h3_restore_effective_batches is None:
            args.h3_restore_effective_batches = 12
        if args.h3_input_max_chars < 1 or args.h3_restore_effective_batches < 1:
            parser.error("H3 input budget and restore threshold must be positive")
    elif args.h3_input_max_chars is not None or args.h3_restore_effective_batches is not None:
        parser.error("H3 input budget and restore threshold require --c4-native-h3")
    if args.c4_summary_every < 1:
        parser.error("--c4-summary-every must be positive")
    if args.plan_check_fix or args.predictor_input_budget_fix or args.two_user_turns:
        parser.error("This A/B freezes the original14 ownership profile")
    if args.executor_base_url.rstrip("/") != "https://api.deepseek.com/v1" or args.executor_model != "deepseek-v4-pro":
        parser.error("This A/B requires the configured official DeepSeek Pro route")
    EXECUTOR_MODEL = args.executor_model
    args.handshake_model = args.handshake_model or EXECUTOR_MODEL
    if args.max_output_tokens < 1 or args.provider_timeout < 1:
        parser.error("output token budget and provider timeout must be positive")
    # The latest ownership profile defaults to width8; legacy snapshots retain
    # their former defaults unless explicitly selected otherwise.
    max_parallelism = args.max_parallelism if args.max_parallelism is not None else (CURRENT_MAX_PARALLELISM if args.contract_ownership_fix else 3)
    max_subtasks = args.max_subtasks if args.max_subtasks is not None else max(6, max_parallelism)
    width_policy = args.offer_width_policy or ("bucket_upper_bound" if args.contract_ownership_fix else "bucket_lower_bound")
    if not 1 <= max_parallelism <= CURRENT_MAX_PARALLELISM or max_subtasks < max_parallelism:
        parser.error("parallelism must be in [1,8] and max-subtasks must be >= parallelism")
    if not args.contract_ownership_fix and (max_parallelism > 3 or width_policy != "bucket_lower_bound"):
        parser.error("width8 requires the current --contract-ownership-fix runtime profile")
    ARM = args.arm
    if args.plan_check_fix:
        CURRENT_SRC = ROOT / "runtime-v8-plancheck" / "src"
    if args.contract_ownership_fix:
        if args.plan_check_fix:
            raise RuntimeError("contract-ownership ablation must not enable the separate plan-check fixes")
        CURRENT_SRC = (Path(__file__).resolve().parent / "runtime" / "src" if args.speculative_generation else ROOT / "runtime-v8-fork-only-prefix" / "src")
    if args.predictor_input_budget_fix:
        if not args.contract_ownership_fix:
            parser.error("input-budget fix extends the current ownership profile")
        CURRENT_SRC = ROOT / "runtime-v8-input-budget" / "src"
    if args.two_user_turns and (not args.predictor_input_budget_fix or args.task_source is None):
        parser.error("two user turns require --task-source and --predictor-input-budget-fix")

    if args.task_source is not None:
        source_case = args.task_source.resolve()
        template = source_case / "workspace"
        prompt_path = source_case / "TASK.md"
        first_checker = "check_evidence.py" if args.two_user_turns else "check.py"
        if not prompt_path.is_file() or not (template / first_checker).is_file():
            raise RuntimeError(f"invalid portable task: {source_case}")
        # No pack manifest, branch design or audit-only metadata enters the task.
        from parallel20_actor_adapter import fixture_paths as published_fixture_paths
        fixture_paths, editable_placeholders = published_fixture_paths(
            template, prompt_path.read_text(encoding='utf8'))
        spec = {"task": prompt_path.read_text(encoding="utf-8"),
                "fixtures": fixture_paths, "editable_placeholders": editable_placeholders,
                "outputs": []}
    else:
        source_root = GROUPS[args.group]
        source_case = source_root / "cases" / args.case
        spec_path = source_case / "case.json"
        template = source_case / "template"
        if not spec_path.is_file() or not template.is_dir():
            raise RuntimeError(f"invalid source case: {source_case}")
        spec = json.loads(spec_path.read_text(encoding="utf-8"))

    result_root = Path(args.result_root).resolve()
    CASE = result_root / args.group / args.case / args.arm
    if CASE.exists():
        raise RuntimeError(f"result exists: {CASE}")
    CASE.mkdir(parents=True)
    WORKSPACE = CASE / "workspace"
    shutil.copytree(template, WORKSPACE)
    for cache in WORKSPACE.rglob("__pycache__"):
        shutil.rmtree(cache)

    fixtures = [str(value) for value in spec.get("fixtures", [])]
    staging = None
    if args.two_user_turns:
        staging = json.loads((source_case / "staging_manifest.json").read_text(encoding="utf-8"))
        if staging["user_turns"] != 2:
            raise RuntimeError("Expected exactly two user requests")
        for relative, digest in staging["files_sha256"].items():
            if sha256(source_case / relative) != digest:
                raise RuntimeError(f"Staged task source changed: {relative}")
        editable_initial = {row["path"] for row in staging["editable_initial_paths"] if row["stage"] == 1}
        fixtures = [relative for relative in fixtures if relative not in editable_initial]
    before = {
        path: sha256(WORKSPACE / path)
        for path in fixtures
        if (WORKSPACE / path).is_file()
    }
    generated_protected = {}
    def capture_generated_fixtures():
        if args.task_source is None:
            return
        # Audit only. Observe at a completed-tool/model boundary, not while a
        # materializer is writing. Never use these paths to trigger an Offer.
        for path in WORKSPACE.rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            relative = path.relative_to(WORKSPACE).as_posix()
            if relative in before or relative in generated_protected:
                continue
            parts = Path(relative).parts
            if any(part in {"outputs", ".git", ".semserve"} for part in parts):
                continue
            immutable = (path.name.startswith(("check", "test_")) or path.name == "contract.json"
                         or (path.suffix.lower() == ".json" and any(part in {"inputs", "workloads"} for part in parts)))
            if immutable:
                generated_protected[relative] = sha256(path)

    key, access = credentials()
    os.environ["OFOX_API_KEY"] = key
    executor_key = key
    if args.executor_key_user_thread:
        if args.executor_base_url.rstrip("/") != "https://api.deepseek.com/v1":
            raise RuntimeError("The official user key is scoped to api.deepseek.com only")
        from user_api_credential import user_api_key
        executor_key = user_api_key(args.executor_key_user_thread, args.executor_key_fingerprint)
    predictor_connection = None
    predictor_tunnel = None
    if args.arm == "dynamic_v7":
        predictor_connection = access.connect()
        predictor_tunnel, predictor_base = access.start_tunnel(
            predictor_connection, remote_port=39232
        )
        PREDICTOR_ENDPOINT = predictor_base + "/chat/completions"
    sys.path.insert(0, str(CURRENT_SRC))
    sys.path.insert(1, str(OFOX_ROOT))

    import ofox_wire  # noqa: E402
    from agent_runtime_demo import cli, planning  # noqa: E402
    from agent_runtime_demo import parallel_control_v2 as pc  # noqa: E402
    from agent_runtime_demo.qwen_frontier_predictor import (  # noqa: E402
        INPUT_VERSION,
        Qwen32BFrontierPredictor,
        capture_execution_delta,
    )

    token_counter = None
    if args.predictor_tokenizer is not None:
        from predictor_token_budget import LocalChatTokenCounter
        token_counter = LocalChatTokenCounter(args.predictor_tokenizer)

    # Pin the model at the transport boundary, including a separately authorized
    # handshake model. Never relax the allowed-model set for ordinary turns.
    original_wire = ofox_wire.wire
    def scoped_wire(request, *wire_args, **wire_kwargs):
        body = json.loads(request.data)
        expected = getattr(LOCAL, "expected_model", EXECUTOR_MODEL)
        if body.get("model") != expected:
            raise RuntimeError("request model differs from the per-turn pinned model")
        if expected.startswith("qwen/"):
            body["enable_thinking"] = False
            request.data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        if request.full_url.startswith("https://api.deepseek.com/v1/"):
            from deepseek_official_wire import official_wire
            body["messages"] = ofox_wire._normalize_rejected_tool_history(body.get("messages", []))
            request.data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            return official_wire(request, ofox_wire.ORIGINAL, record, getattr(LOCAL, "scope", None),
                                 *wire_args, **wire_kwargs)
        return original_wire(request, *wire_args, **wire_kwargs)
    ofox_wire.wire = scoped_wire
    ofox_wire.install()
    original_controller = pc.ControllerV2

    class DynamicPredictor(Qwen32BFrontierPredictor):
        def predict_prepared(self, context, prepared):
            prediction = super().predict_prepared(context, prepared)
            print("PREPARED_QWEN_PREDICTION", json.dumps({"step": context.step,
                "action": prediction.action, "width": prediction.width_bucket,
                "request_chars": prepared.request_chars, "input_tokens": prepared.input_tokens}), flush=True)
            return prediction

        def predict(self, context):
            prediction = super().predict(context)
            print(
                "RETEST18_PREDICTION",
                json.dumps({
                    "group": args.group,
                    "case": args.case,
                    "step": context.step,
                    "event": context.event,
                    "action": prediction.action,
                    "width": prediction.width_bucket,
                    "workload": prediction.workload_level,
                }, ensure_ascii=False),
                flush=True,
            )
            return prediction

    class DynamicController(original_controller):
        def __init__(self, config=None, predictor=None):
            if config is not None and config.mode != "off":
                config = replace(
                    config,
                    minimum_confidence=1.0,
                    max_evaluations=64,
                    max_offers=4,
                    max_expansions=2,
                    offer_ttl_steps=4,
                    max_context_chars=256000,
                )
                if hasattr(config, "width_admission_policy"):
                    config = replace(config, width_admission_policy=width_policy)
                predictor = DynamicPredictor(
                    endpoint=PREDICTOR_ENDPOINT,
                    model=PREDICTOR_MODEL,
                    audit_path=CASE / "qwen-predictions.jsonl",
                    timeout_seconds=180,
                    api_key="",
                    portable_openai_compatible=False,
                    **({"token_counter": token_counter, "context_token_limit": args.predictor_context_tokens}
                       if args.predictor_input_budget_fix else {}),
                )
            super().__init__(config, predictor)

    pc.ControllerV2 = DynamicController

    provider_class = cli.OpenAICompatibleProvider

    c4_memory = None
    active_user_request = spec["task"]
    def control_fields(state):
        result = {name: getattr(state, name) for name in [
            "step", "scope_id", "branch_id", "v2_frontier_handshake_reason",
            "v2_frontier_handshake_generation", "v2_frontier_committed_generation",
            "plan_expansion_count", "v2_expansion_count", "plan_validation_failures",
            "v2_post_join_watch_paths", "v2_post_join_followup_available",
        ]}
        if args.two_user_turns:
            # C4's compact representation must retain the actual later user
            # request, not only its original first-user-message anchor.
            result.update(active_user_request=active_user_request, cumulative_user_task=state.task)
        return result

    if args.handshake_input == "c4":
        from urllib.request import Request
        from handshake_async_memory import AsyncHandshakeMemory, SUMMARY_TOOL, SUMMARY_SCHEMA, SUMMARY_SYSTEM, validate_memory, normalize_memory_quotes
        from agent_runtime_demo.runtime import AgentRuntime

        def summarize_memory(request_body, snapshot):
            LOCAL.expected_model = args.c4_summary_model
            ofox_wire.LOCAL.scope = f"root/c4-summary/{snapshot['generation']}"
            payload = {"model": args.c4_summary_model, "stream": False, "temperature": 0,
                       "thinking": {"type": "disabled"}, "enable_thinking": False,
                       "max_tokens": 3072,
                       "messages": [{"role": "system", "content": SUMMARY_SYSTEM},
                                    {"role": "user", "content": json.dumps(request_body, ensure_ascii=False)}],
                       "tools": [{"type": "function", "function": {"name": SUMMARY_TOOL,
                                  "description": "Commit a bounded advisory evidence memory with exact source quotations.",
                                  "parameters": SUMMARY_SCHEMA}}],
                       "tool_choice": {"type": "function", "function": {"name": SUMMARY_TOOL}}}
            started_summary = time.time()
            data = None
            parsed_memory = None
            raw_memory = None
            normalizations = []
            error = None
            try:
                request = Request("https://api.ofox.io/v1/chat/completions",
                                  data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                                  headers={"Content-Type": "application/json"}, method="POST")
                with ofox_wire.wire(request, timeout=40) as response:
                    data = json.load(response)
                if data.get("model") != args.c4_summary_model:
                    raise ValueError("summary_returned_model_mismatch")
                message = data["choices"][0]["message"]
                reasoning = ((data.get("usage") or {}).get("completion_tokens_details") or {}).get("reasoning_tokens")
                if reasoning or message.get("reasoning_content"):
                    raise ValueError("summary_returned_reasoning_on_disabled_route")
                calls = message.get("tool_calls") or []
                if len(calls) == 1 and calls[0]["function"]["name"] == SUMMARY_TOOL:
                    value = calls[0]["function"]["arguments"]
                elif not calls and message.get("content"):
                    value = message["content"]
                else:
                    raise ValueError("summary_wrong_tool_or_response_shape")
                raw_memory = json.loads(value) if isinstance(value, str) else value
                parsed_memory, normalizations = normalize_memory_quotes(raw_memory, snapshot)
                validate_memory(parsed_memory, snapshot)
                return parsed_memory
            except Exception as exc:
                error = {"type": type(exc).__name__, "detail": str(exc)[:400]}
                raise
            finally:
                record("c4_summary_calls.jsonl", {"generation": snapshot["generation"], "epoch": snapshot["epoch"],
                    "scope": ofox_wire.LOCAL.scope, "start": started_summary, "end": time.time(),
                    "model": args.c4_summary_model, "requested_reasoning": "off",
                    "snapshot_digest": snapshot["prefix_digest"], "snapshot_step": snapshot["step"],
                    "usage": (data or {}).get("usage"), "returned_model": (data or {}).get("model"),
                    "valid": error is None, "error": error, "memory": parsed_memory,
                    "raw_memory": raw_memory, "quote_normalizations": normalizations})

        c4_memory = AsyncHandshakeMemory(summarize_memory, record, every=args.c4_summary_every,
                                         max_input_chars=args.c4_input_max_chars,
                                         restore_every=args.h3_restore_effective_batches,
                                         native_h3=args.c4_native_h3)
        if args.c4_native_h3:
            c4_memory.h3_max_input_chars = args.h3_input_max_chars
        original_after_tools = AgentRuntime._v2_after_tools

        def after_tools_with_c4(runtime, state, calls, results, node_id):
            was_pending = state.v2_frontier_handshake_pending
            generation = state.v2_frontier_handshake_generation
            result = original_after_tools(runtime, state, calls, results, node_id)
            if runtime.depth == 0:
                c4_memory.root_runtime = runtime
                if was_pending and state.v2_frontier_committed_generation == generation:
                    memory = getattr(runtime, "_v2_classifier_state_memory", None)
                    verified = memory.snapshot(state.task) if memory is not None else {}
                    c4_memory.after_commit(state.messages, verified, control_fields(state), state.step)
            return result

        AgentRuntime._v2_after_tools = after_tools_with_c4

    from agent_runtime_demo.output_guard import PROMPT as OUTPUT_GUARD_PROMPT, metadata_capture_allowed
    from output_guard_live import make_public_checker
    from narration_summary_live import build_compressor
    from agent_runtime_demo.narration_compression import provider_class as narration_provider_class
    narration_compressor=build_compressor(args.c4_summary_model,ofox_wire.wire,record,LOCAL,ofox_wire.LOCAL)
    provider_class=narration_provider_class(provider_class,narration_compressor,record,lambda:getattr(LOCAL,'scope',None))

    class CaptureProvider(provider_class):
        def __init__(self, base_url, model, api_key="", timeout_seconds=120.0):
            super().__init__(base_url, model, executor_key if base_url.startswith("https://api.deepseek.com/") else ofox_wire.SECRET, timeout_seconds)

        def fork(self, *, stream=None):
            return CaptureProvider(
                self.base_url, self.model, self.api_key, self.timeout_seconds
            )

        def complete(self, state, tools, routing_context):
            capture_generated_fixtures()
            LOCAL.scope = state.scope_id
            ofox_wire.LOCAL.scope = state.scope_id
            started = time.time()
            before_messages = copy.deepcopy(state.messages)
            handshake = not state.parent_task_id and {
                s["function"]["name"] for s in tools
            } == {"report_frontier_state"}
            actual_model = args.handshake_model if handshake else self.model
            LOCAL.expected_model = actual_model
            try:
                actual_state = state
                if handshake:
                    from handshake_compression import build_handshake_input
                    control = control_fields(state)
                    if args.handshake_input == "c4":
                        runtime = c4_memory.root_runtime
                        if c4_memory.native_h3:
                            verified = runtime._v2_snapshot_for_h3_report(state)
                        else:
                            runtime_memory = getattr(runtime, "_v2_classifier_state_memory", None)
                            verified = runtime_memory.snapshot(state.task) if runtime_memory is not None else {}
                        sent, compression = c4_memory.build(before_messages, verified, control, report_tools=tools)
                    elif args.handshake_input == "c3":
                        from handshake_window import build_recent_handshake_input
                        sent, compression = build_recent_handshake_input(before_messages, args.handshake_window_turns)
                    else:
                        sent, compression = build_handshake_input(before_messages, args.handshake_input, control)
                    record("handshake_inputs.jsonl", {
                        "scope": state.scope_id, "step": state.step, "model": actual_model,
                        "compression": compression, "original_messages": before_messages,
                        "sent_messages": sent, "tools": tools,
                    })
                    actual_state = replace(state, messages=sent)
                    before_messages = copy.deepcopy(sent)
                if actual_model == self.model:
                    turn = super().complete(actual_state, tools, replace(routing_context, requested_model=actual_model))
                else:
                    provider = provider_class(self.base_url, actual_model, executor_key if self.base_url.startswith("https://api.deepseek.com/") else ofox_wire.SECRET, self.timeout_seconds)
                    turn = provider.complete(actual_state, tools, replace(routing_context, requested_model=actual_model))
                if not state.parent_task_id and metadata_capture_allowed(turn, tools):
                    delta, error = capture_execution_delta(
                        state.run_id,
                        state.scope_id,
                        turn.content or "",
                        state.step,
                    )
                    record("summary_captures.jsonl", {
                        "scope": state.scope_id,
                        "reported_at_step": state.step,
                        "captured": delta is not None,
                        "error": error,
                        "delta": delta,
                    })
                record("turns.jsonl", {
                    "scope": state.scope_id,
                    "parent_task_id": state.parent_task_id,
                    "step": state.step,
                    "start": started,
                    "end": time.time(),
                    "messages": before_messages + [turn.assistant_message],
                    "tools": tools,
                    "usage": turn.usage,
                    "route_info": turn.route_info,
                    "model": actual_model,
                    "handshake": handshake,
                    "handshake_input": args.handshake_input if handshake else None,
                })
                return turn
            except BaseException as exc:
                record("turns.jsonl", {
                    "scope": state.scope_id,
                    "parent_task_id": state.parent_task_id,
                    "step": state.step,
                    "start": started,
                    "end": time.time(),
                    "provider_error": type(exc).__name__,
                })
                raise

    cli.OpenAICompatibleProvider = CaptureProvider

    # Enable child-only envelope inheritance; root tool declarations stay legacy.
    from live_capture_adapter import generation_provider_class, capture_committed_business
    GenerationOnlyProvider = generation_provider_class(provider_class, record, LOCAL, ofox_wire.LOCAL)
    live_root_runtimes = []
    RootRuntime = cli.AgentRuntime
    class StablePrefixRootRuntime(RootRuntime):
        def __init__(self, *a, **kw):
            kw["fork_only_stable_prefix"] = True
            kw["output_guard"] = True
            kw["root_public_checker"] = make_public_checker(WORKSPACE, before, generated_protected, capture_generated_fixtures, record)
            if args.speculative_generation:
                kw["handshake_speculation"] = True
                kw["handshake_speculation_wait_seconds"] = args.provider_timeout
                kw["handshake_speculation_provider_factory"] = lambda: GenerationOnlyProvider(self.provider.base_url, self.provider.model, self.provider.api_key, self.provider.timeout_seconds)
                kw["handshake_speculation_commit_observer"] = lambda state, turn: capture_committed_business(self, state, turn, record, capture_execution_delta, capture_generated_fixtures)
            super().__init__(*a, **kw)
            if self.depth == 0:
                from parallel20_actor_adapter import audit_semantic_root
                record('semantic_mode_audit.jsonl', audit_semantic_root(
                    self, os.environ['SEMSERVE_SEMANTIC_PARALLEL']))
                live_root_runtimes.append(self)
    cli.AgentRuntime = StablePrefixRootRuntime

    reference = (
        OFOX_ROOT / "codex-supervised-results-v5-fewshot-v1"
        / "tenant_rollout_reconciler" / "deepseek__deepseek-v4-pro-0813"
    )
    first = rows(reference / "turns.jsonl")[0]
    frozen_prompt = next(
        message["content"]
        for message in first["messages"]
        if message["role"] == "system"
    )
    marker = "\n\nIn every response include exactly one compact plain-text metadata line:"
    prompt_core = frozen_prompt.split(marker, 1)[0]
    entrypoint_text = (VBA_ROOT / "harbor_runtime_entrypoint.py").read_text(
        encoding="utf-8"
    )
    match = re.search(
        r'EXECUTION_DELTA_PROMPT = """(.*?)"""\.strip\(\)',
        entrypoint_text,
        flags=re.DOTALL,
    )
    if not match:
        raise RuntimeError("Cannot locate current execution-delta prompt")
    system_prompt = prompt_core + "\n\n" + match.group(1).strip()
    if args.task_prompt_limit == 150:
        from task_prompt_policy import rewrite_system_prompt, rewrite_task_schema_in_place
        system_prompt = rewrite_system_prompt(system_prompt)
    system_prompt += "\n\n" + OUTPUT_GUARD_PROMPT
    attempt_lessons = ""
    try:
        attempt_lessons = str(__import__("pathlib").Path("/opt/attempt_lessons.txt").read_text(encoding="utf-8")).strip()
    except Exception:
        attempt_lessons = ""
    if attempt_lessons:
        system_prompt += "\n\n" + attempt_lessons
    cli.NEUTRAL_SYSTEM_PROMPT = system_prompt

    planning.MAX_SUBTASK_TASK_LENGTH = 512
    task_schema = planning.SPAWN_SUBTASKS_SCHEMA["function"]["parameters"][
        "properties"
    ]["subtasks"]["items"]["properties"]["task"]
    task_schema["maxLength"] = 512
    if args.task_prompt_limit == 150:
        rewrite_task_schema_in_place(planning.SPAWN_SUBTASKS_SCHEMA)

    shim = ROOT / "bin"
    shim.mkdir(exist_ok=True)
    (shim / "python3.cmd").write_text(
        f'@"{sys.executable}" %*\r\n', encoding="utf-8"
    )
    os.environ.update(
        AGENT_RUNTIME_OUTPUT_GUARD="1",
        AGENT_RUNTIME_ENABLE_THINKING="false",
        AGENT_RUNTIME_FORBID_REASONING="true",
        AGENT_RUNTIME_MAX_OUTPUT_TOKENS=str(args.max_output_tokens),
        AGENT_RUNTIME_PROVIDER_TIMEOUT=str(args.provider_timeout),
        AGENT_RUNTIME_OFFER_RESPONSE_POLICY="required_response_choice",
        OFOX_EXPECTED_MODEL=(EXECUTOR_MODEL if args.handshake_model == EXECUTOR_MODEL and args.handshake_input != "c4" else ""),
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONIOENCODING="utf-8",
        PYTHONUTF8="1",
        PATH=str(shim) + os.pathsep + os.environ.get("PATH", ""),
    )

    manifest = {
        "schema_version": "semserve.current-v8-generic-handshake/v1",
        "report_authorization_version": "report-request-authorization-v2-scoped-resume",
        "report_mode_transition": "request_scoped_handshake_and_shared_idempotent_business_resume",
        "write_preflight_version": "literal-write-preflight-v1",
        "progress_recovery_version": "verified-progress-recovery-v1",
        "repeated_output_guard_version": "five-identical-business-turns-v1",
        "repeated_output_guard_limit": 5,
        "validation_progress_guard_version": "public-validation-progress-v1",
        "recovery_coordinator_version": "scope-recovery-coordinator-v1",
        "validation_progress_repeat_limit": 3,
        "validation_progress_recovery_business_batches": 6,
        "validation_progress_recovery_episodes_per_check": 2,
        "report_schema_policy": "dedicated_root_handshake_only",
        "report_execution_authorization": "request_scope_generation_and_one_shot_dispatch",
        "output_guard_version": "agent-output-guard-v3-narration-compression",
        "narration_compression_version": "small-model-narration-v1",
        "narration_compression_model": args.c4_summary_model,
        "narration_compression_threshold_chars": 1024,
        "narration_summary_max_chars": 768,
        "narration_summary_target": "Chinese advisory note, target 300 chars",
        "narration_compression_failure_policy": "retain original narration and executable calls",
        "output_guard_scope": "root and child narration; original child delivery unchanged",
        "tool_loop_progress": "workspace content epoch; cross-operation repeats; shell always executes",
        "output_guard_narration_soft_chars": 256,
        "output_guard_narration_hard_chars": 1024,
        "root_completion_protocol": "finish_task_public_check_or_report_blocked",
        "output_guard_request_transport": "non-stream unchanged; no server cancellation",
        "group": args.group,
        "case": args.case,
        "arm": args.arm,
        "task_source": str(source_case),
        "editable_initial_placeholders": spec.get("editable_placeholders", []),
        "task_input_format": "TASK.md+workspace" if args.task_source is not None else "historical-case-manifest",
        "task_prompt_sha256": hashlib.sha256(spec["task"].encode("utf-8")).hexdigest(),
        "predeclared_dag": False,
        "audit_only_metadata_consumed": False,
        "predictor_model": PREDICTOR_MODEL if args.arm == "dynamic_v7" else None,
        "predictor_input": INPUT_VERSION if args.arm == "dynamic_v7" else None,
        "predictor_transport": (
            "ssh_tunnel:127.0.0.1:39232"
            if args.arm == "dynamic_v7" else None
        ),
        "executor_model": EXECUTOR_MODEL,
        "executor_base_url": args.executor_base_url,
        "executor_key_fingerprint": hashlib.sha256(executor_key.encode()).hexdigest()[:12],
        "executor_reasoning_mode": "off",
        "executor_max_output_tokens": args.max_output_tokens,
        "provider_timeout_seconds": args.provider_timeout,
        "runtime_fix_version": "generic-evidence-frontier-handshake-v8",
        "system_prompt_version": "neutral-v5-fewshot-v1+dynamic-work-unit-v7",
        "system_prompt_sha256": hashlib.sha256(system_prompt.encode()).hexdigest(),
        "max_parallelism": max_parallelism,
        "max_subtasks": max_subtasks,
        "offer_width_admission_policy": width_policy,
        "max_subtask_depth": 1,
        "max_expansions": 2,
        "subtask_task_max_chars": 512,
        "subtask_task_prompt_max_chars": args.task_prompt_limit,
        "handshake_model": args.handshake_model,
        "handshake_input": args.handshake_input,
        "handshake_compressor_sha256": sha256(ROOT / "handshake_compression.py"),
        "runner_sha256": sha256(Path(__file__)),
    }
    if args.task_prompt_limit == 150:
        manifest["system_prompt_version"] += "+task150"
    if args.handshake_input == "c3":
        manifest.update(handshake_window_turns=args.handshake_window_turns,
                        handshake_window_sha256=sha256(ROOT / "handshake_window.py"))
    if args.handshake_input == "c4":
        manifest.update(c4_summary_model=args.c4_summary_model, c4_summary_every=args.c4_summary_every,
                        c4_input_max_chars=args.c4_input_max_chars,
                        c4_summary_sha256=sha256(ROOT / "handshake_async_memory.py"))
        if args.c4_native_h3:
            manifest.update(c4_h3_native=True, c4_h3_input_max_chars=args.h3_input_max_chars,
                            c4_restore_effective_batches=args.h3_restore_effective_batches)
    if args.plan_check_fix:
        manifest.update(
            runtime_fix_version="generic-evidence-frontier-handshake-v8+plan-check-fix1",
            plan_objective_normalization="lossless_overflow_to_branch_inputs",
            focused_delivery_gate="execute_before_delivery_with_source_version_attestation",
            runtime_source=str(CURRENT_SRC),
            runtime_changed_files_sha256={
                name: sha256(CURRENT_SRC / "agent_runtime_demo" / name)
                for name in ["planning.py", "runtime.py", "tools/workspace.py", "delivery_guards.py"]
            },
        )
    if args.contract_ownership_fix:
        manifest.update(
            runtime_fix_version="generic-evidence-frontier-handshake-v8+contract-ownership-fix1",
            contract_ownership_fix="explicit_write_union_before_fork_with_conflict_revalidation",
            runtime_source=str(CURRENT_SRC),
            runtime_changed_files_sha256={
                name: sha256(CURRENT_SRC / "agent_runtime_demo" / name)
                for name in ["runtime.py", "delivery_ownership.py", "dynamic_frontier.py", "qwen_frontier_predictor.py", "parallel_control_v2.py", "tools/workspace.py"]
            },
        )
        if max_parallelism == 8:
            manifest["runtime_fix_version"] += "+width8"
    if args.predictor_input_budget_fix:
        manifest.update(predictor_budget_object="serialized_prepared_request",
                        predictor_request_max_chars=256000, predictor_raw_safety_chars=16000000,
                        predictor_context_tokens=args.predictor_context_tokens,
                        predictor_tokenizer_sha256=sha256(args.predictor_tokenizer) if args.predictor_tokenizer else None,
                        predictor_token_count="exact_local_chat_template" if args.predictor_tokenizer else "unavailable",
                        runtime_fix_version=manifest["runtime_fix_version"] + "+prepared-input-budget",
                        input_budget_source_sha256={name: sha256(CURRENT_SRC / "agent_runtime_demo" / name)
                                                   for name in ("parallel_control_v2.py", "qwen_frontier_predictor.py", "runtime.py", "classifier_state_memory.py")})
    conversation_results = []
    conversation_audits = []
    if args.two_user_turns:
        from agent_runtime_demo.runtime import AgentRuntime as ConversationRuntimeBase
        followup = (source_case / "TURN2.md").read_text(encoding="utf-8")

        def publish_second_request(user_turn, state, previous_answer):
            nonlocal active_user_request
            begin = time.time()
            checked = subprocess.run([sys.executable, str(WORKSPACE / "check_evidence.py")],
                                     cwd=WORKSPACE, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
            audit = {"user_turn": 1, "passed": checked.returncode == 0,
                     "stdout": checked.stdout, "stderr": checked.stderr,
                     "audit_seconds": time.time() - begin}
            conversation_audits.append(audit)
            record("conversation_events.jsonl", {"event": "first_turn_audited", **audit})
            (CASE / "round1_history.json").write_text(json.dumps(state.messages, ensure_ascii=False, indent=2), encoding="utf-8")
            shutil.copytree(WORKSPACE, CASE / "round1_workspace", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            if not audit["passed"]:
                raise RuntimeError("First user-turn deliverables failed the evidence-stage checker; second request not published")
            editable = {row["path"] for row in staging["editable_initial_paths"] if row["stage"] == 2}
            published = []
            for source in sorted((source_case / "round2_workspace").rglob("*")):
                if not source.is_file():
                    continue
                relative = source.relative_to(source_case / "round2_workspace").as_posix()
                target = WORKSPACE / relative
                if target.exists() and relative != "README.md":
                    raise RuntimeError(f"Second-round fixture would overwrite an existing implementation: {relative}")
                target.parent.mkdir(parents=True, exist_ok=True)
                old_digest = sha256(target) if target.exists() else None
                shutil.copy2(source, target)
                if relative not in editable:
                    before[relative] = sha256(target)
                published.append({"path": relative, "old_sha256": old_digest, "new_sha256": sha256(target)})
            active_user_request = followup
            record("conversation_events.jsonl", {"event": "second_request_released", "user_turn": user_turn,
                "published_files": published, "message": followup, "history_messages_inherited": len(state.messages),
                "same_run_id": state.run_id, "same_scope_id": state.scope_id,
                "release_and_audit_seconds": time.time() - begin, "time": time.time()})

        class TwoTurnRuntime(ConversationRuntimeBase):
            def __init__(self, *positional, **kwargs):
                # Both arms have the same two-wave capacity, including native
                # autonomous spawn in no-offer. No branch is scheduled here.
                kwargs["max_plan_expansions"] = 2
                kwargs["max_initial_plan_expansions"] = 2
                super().__init__(*positional, **kwargs)

            def run(self, task, **kwargs):
                try:
                    return super().run(task, followup_user_messages=(followup,), before_followup=publish_second_request, **kwargs)
                finally:
                    conversation_results[:] = getattr(self, "conversation_turn_results", [])

        cli.AgentRuntime = TwoTurnRuntime
        manifest.update(user_turns=2, conversational_inheritance="same_runtime_state_full_history_same_workspace",
                        second_user_request_sha256=hashlib.sha256(followup.encode("utf-8")).hexdigest(),
                        staged_fixture_manifest_sha256=sha256(source_case / "staging_manifest.json"),
                        max_expansions=2, native_spawn_max_expansions=2,
                        first_turn_checker="check_evidence.py", final_checker="check.py",
                        c4_preserves_active_user_request=True)
    if not args.contract_ownership_fix or args.arm != "dynamic_v7":
        raise RuntimeError("stable-prefix experiment requires unchanged active ownership profile")
    manifest.update(stable_context_prefix=True,
                    stable_prefix_version="fork-only-parent-envelope-v2",
                    parent_tool_exposure="unchanged_legacy_timing",
                    fork_only_stable_prefix=True,
                    context_fork="balanced_parent_history_plus_branch_overlay",
                    stable_prefix_sha256=sha256(CURRENT_SRC / "agent_runtime_demo/fork_only_prefix.py"),
                    original_runner_sha256=sha256(ROOT / "run_case_v7.py"))
    manifest.update(handshake_speculation=bool(args.speculative_generation),
                    speculation_adapter_sha256=sha256(Path(__file__).resolve().parent / "live_capture_adapter.py"),
                    physical_speculation_usage="api_events physical requests, never logical commit rows",
                    live_runtime_source=str(CURRENT_SRC))
    (CASE / "experiment_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    sys.argv = [
        "entry",
        str(spec["task"]),
        "--provider", "openai-compatible",
        "--base-url", args.executor_base_url,
        "--model", EXECUTOR_MODEL,
        "--workspace", str(WORKSPACE),
        "--max-steps", "128",
        "--max-subtasks", str(max_subtasks),
        "--max-parallelism", str(max_parallelism),
        "--max-subtask-depth", "1",
        "--parallel-v2", "active" if args.arm == "dynamic_v7" else "off",
        "--parallel-v2-max-expansions", "2",
        "--system-prompt-profile", "neutral",
        "--require-file-branch-contract",
        "--reasoning-mode", "off",
        "--trace-path", str(CASE / "trace.jsonl"),
        "--dag-path", str(CASE / "dag.json"),
        "--execution-state-log", str(CASE / "execution_state.jsonl"),
        "--quiet-trace",
        "--tool-timeout", "600",
    ]
    from parallel20_actor_adapter import semantic_cli
    sys.argv = semantic_cli(sys.argv, os.environ['SEMSERVE_SEMANTIC_PARALLEL'])
    started = time.time()
    failure = None
    try:
        cli.main()
    except BaseException as exc:
        failure = {"type": type(exc).__name__, "detail": str(exc)}
        (CASE / "exception.txt").write_text(
            traceback.format_exc(), encoding="utf-8"
        )
    finally:
        if predictor_tunnel is not None:
            predictor_tunnel.shutdown()
            predictor_tunnel.server_close()
        if predictor_connection is not None:
            predictor_connection.close()
    elapsed = time.time() - started
    speculative_drain_start = time.time()
    speculative_final_metrics = []
    if args.speculative_generation:
        for runtime in live_root_runtimes:
            speculative_final_metrics.append(runtime.wait_for_handshake_speculation(timeout=args.provider_timeout * 3 + 30))
    speculative_background_drain = time.time() - speculative_drain_start
    c4_background_drain = c4_memory.close() if c4_memory is not None else 0.0

    completed = subprocess.run(
        [sys.executable, str(WORKSPACE / "check.py")],
        cwd=WORKSPACE,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=900,
        env=dict(os.environ),
    )
    validation = {
        "passed": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }
    trace = rows(CASE / "trace.jsonl")
    turns = rows(CASE / "turns.jsonl")
    api_events = rows(CASE / "api_events.jsonl")
    predictions = rows(CASE / "qwen-predictions.jsonl")
    events = Counter(row.get("event") for row in trace)
    responses = [row for row in trace if row.get("event") == "model_response"]
    calls = [call for row in responses for call in row.get("tool_calls", [])]
    decisions = [
        call.get("arguments", {})
        for call in calls
        if call.get("name") == "choose_execution_mode_v2"
    ]
    spawns = [
        call for call in calls if call.get("name") == "spawn_subtasks"
    ]
    valid_turns = [
        row for row in turns if row.get("end", 0) > row.get("start", 0)
    ]
    usage = Counter()
    for turn in valid_turns:
        for name, value in (turn.get("usage") or {}).items():
            if isinstance(value, (int, float)):
                usage[name] += value
    reasoning_tokens = [
        int(
            ((row.get("usage") or {}).get("completion_tokens_details") or {})
            .get("reasoning_tokens")
            or 0
        )
        for row in api_events
        if row.get("usage")
    ]
    result = {
        **manifest,
        "seconds": elapsed,
        "background_summary_drain_seconds": c4_background_drain,
        "background_speculative_drain_seconds": speculative_background_drain,
        "speculative_metrics": speculative_final_metrics,
        "completion_inclusive_seconds": elapsed + speculative_background_drain + c4_background_drain,
        "runtime_error": failure,
        "workspace_progress_observation": [{"seconds": r._cross_workspace.seconds,
            "scans": r._cross_workspace.scans,"epoch": r._cross_workspace.epoch}
            for r in live_root_runtimes if hasattr(r,"_cross_workspace")],
        "conversation_turns": conversation_results,
        "conversation_stage_audits": conversation_audits,
        "final_validation": validation,
        "fixtures_unchanged": {
            path: (WORKSPACE / path).is_file()
            and sha256(WORKSPACE / path) == digest
            for path, digest in {**before, **generated_protected}.items()
        },
        "generated_protected_fixture_count": len(generated_protected),
        "output_check_scope": "root checker authoritative; no external output list provided" if args.task_source is not None else "case output list and root checker",
        "outputs_present": {
            str(path): (WORKSPACE / str(path)).is_file()
            for path in spec.get("outputs", [])
        },
        "event_counts": dict(events),
        "offer_events": {
            name: int(events.get(name, 0))
            for name in (
                "parallel_v2_evaluated",
                "parallel_v2_offer_accepted",
                "parallel_v2_offer_declined",
                "parallel_v2_plan_rejected",
                "parallel_v2_plan_completed",
                "parallel_v2_frontier_handshake_scheduled",
                "parallel_v2_frontier_report_committed",
            )
        },
        "decision_calls": decisions,
        "spawn_call_count": len(spawns),
        "spawn_subtask_count": sum(
            len((call.get("arguments") or {}).get("subtasks", []))
            for call in spawns
        ),
        "predictor": {
            "prediction_count": len(predictions),
            "latency_seconds_sum": sum(
                float(row.get("latency_seconds") or 0) for row in predictions
            ),
            "actions": dict(Counter(
                (row.get("admitted_heads") or {}).get("action")
                for row in predictions if not row.get("error")
            )),
            "frontier_safe_widths": [
                int(
                    ((row.get("input") or {}).get("current_frontier") or {})
                    .get("safe_width")
                    or 0
                )
                for row in predictions if not row.get("error")
            ],
        },
        "usage": dict(usage),
        "model_timing": {
            "turn_count": len(valid_turns),
            "request_seconds_sum": sum(
                row["end"] - row["start"] for row in valid_turns
            ),
            "request_wall_union_seconds": interval_union_seconds(valid_turns),
        },
        "overlap": overlap_stats(turns),
        "reasoning_gate": {
            "api_calls_with_usage": len(reasoning_tokens),
            "reasoning_tokens_sum": sum(reasoning_tokens),
            "passed": bool(reasoning_tokens)
            and all(value == 0 for value in reasoning_tokens),
        },
    }
    (CASE / "final_validation.json").write_text(
        json.dumps(validation, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (CASE / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print("RETEST18_COMPLETE", json.dumps({
        "group": args.group,
        "case": args.case,
        "arm": args.arm,
        "seconds": round(elapsed, 2),
        "validation": validation["passed"],
        "runtime_error": failure,
        "predictions": len(predictions),
        "accepted": result["offer_events"]["parallel_v2_offer_accepted"],
        "completed": result["offer_events"]["parallel_v2_plan_completed"],
        "overlap": result["overlap"]["max_model_request_overlap_seconds"],
        "reasoning_tokens": sum(reasoning_tokens),
        "result": str(CASE / "result.json"),
    }, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
