import re

_AMOUNT_RE = re.compile(
    r"^\s*(?:USD\s+)?(\d{1,3}(?:,\d{3})*|\d+)(?:\.(\d{2}))?\s*$",
    re.IGNORECASE,
)


def _parse_amount(text):
    m = _AMOUNT_RE.match(text)
    if m is None:
        raise ValueError("invalid amount")
    int_part = m.group(1).replace(",", "")
    frac = m.group(2)
    if frac is None:
        raise ValueError("amount must have 2 decimals")
    return int_part + "." + frac


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        payload = payload["result"]
    documents = payload["documents"]
    amounts = {}
    for doc in documents:
        doc_id = doc["id"]
        total = None
        vat = "0.00"
        seen_total = False
        seen_due = False
        seen_vat = False
        for line in doc["text"].splitlines():
            s = line.strip()
            low = s.lower()
            if low.startswith("total:"):
                if seen_total:
                    raise ValueError("duplicate Total")
                seen_total = True
                total = _parse_amount(s[len("total:"):])
            elif low.startswith("amount due:"):
                if seen_due:
                    raise ValueError("duplicate Amount Due")
                seen_due = True
                due = _parse_amount(s[len("amount due:"):])
                if total is None:
                    total = due
            elif low.startswith("vat:"):
                if seen_vat:
                    raise ValueError("duplicate VAT")
                seen_vat = True
                vat = _parse_amount(s[len("vat:"):])
        amounts[doc_id] = {"total": total, "vat": vat}
    return {"name": contract["name"], "result": {"amounts": amounts}}
