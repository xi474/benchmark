import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(ROOT.rglob('contract.json'))
    contracts = [c for c in contracts if 'outputs' not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError('no contracts')

    # Topological order by input dependency: a component whose inputs include
    # another component's output must run after that producer.
    produced = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        produced[c['name']] = cp

    remaining = set(contracts)
    order = []
    while remaining:
        progressed = False
        for cp in sorted(remaining):
            c = json.loads(cp.read_text(encoding='utf-8'))
            deps = []
            for inp in c['inputs']:
                for name, pcp in produced.items():
                    if c['output'] == inp:
                        continue
                    if inp == json.loads(pcp.read_text(encoding='utf-8'))['output']:
                        deps.append(name)
            if all(json.loads(produced[d].read_text(encoding='utf-8'))['name'] in
                   [json.loads(produced[n].read_text(encoding='utf-8'))['name']
                    for n in []] or
                   json.loads(produced[d].read_text(encoding='utf-8'))['name'] in
                   [json.loads(x.read_text(encoding='utf-8'))['name']
                    for x in order] for d in deps):
                order.append(cp)
                remaining.remove(cp)
                progressed = True
                break
        if not progressed:
            raise ValueError('cycle or missing dependency')

    for cp in order:
        render = cp.with_name('render.py')
        subprocess.run([sys.executable, str(render)],
                       cwd=ROOT, check=True, timeout=60)

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')],
                   cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')],
                   cwd=ROOT, check=True, timeout=60)


if __name__ == '__main__':
    main()
