import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "domains/classification/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "domains/amounts/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
    {
        "target_path": "views/archive/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": "README.md",
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
            },
        },
    },
]


class TestApiBoundary(unittest.TestCase):
    def test_boundary_probes(self):
        cases = [
            ("domains/classification/transform.py",
             [{"documents": [{"id": "a", "filename": "f/a.txt", "text": "Invoice\n"}]}],
             {"name": "classification", "operation": "invoice_classification",
              "inputs": ["inputs/case.json"], "output": "outputs/classification.json"}),
            ("domains/amounts/transform.py",
             [{"documents": [{"id": "a", "filename": "f/a.txt", "text": "Total: 1.00\n"}]}],
             {"name": "amounts", "operation": "invoice_amounts",
              "inputs": ["inputs/case.json"], "output": "outputs/amounts.json"}),
            ("views/archive/transform.py",
             [{"documents": [{"id": "a", "filename": "f/a.txt", "text": "Invoice\n"}]},
              {"classes": {"a": "invoice"}},
              {"amounts": {"a": {"total": "1.00", "vat": "0.00"}}}],
             {"name": "archive", "operation": "invoice_archive_summary",
              "inputs": ["inputs/case.json", "outputs/classification.json",
                         "outputs/amounts.json"], "output": "outputs/archive.json"}),
        ]
        for target, payload, contract in cases:
            with self.subTest(target=target):
                check_api_boundary(
                    target, rule="nonfinite_unknown_field",
                    contract_path="README.md",
                    requirement_quote="未知额外字段可忽略，但其中非有限JSON仍非法",
                    args=[payload, contract],
                )
                check_api_boundary(
                    target, rule="invalid_payload_type",
                    contract_path="README.md",
                    requirement_quote="仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError",
                    args=[payload, contract],
                )


class TestClassification(unittest.TestCase):
    def test_classification_priority_and_other(self):
        # invoice > receipt > other, case-insensitive independent words
        payload = {
            "documents": [
                {"id": "a", "filename": "f/a.txt", "text": "Receipt\n"},
                {"id": "b", "filename": "f/b.txt", "text": "Invoice\n"},
                {"id": "c", "filename": "f/c.txt", "text": "INVOICE receipt\n"},
                {"id": "d", "filename": "f/d.txt", "text": "notes\n"},
            ]
        }
        contract = {"name": "classification", "operation": "invoice_classification",
                    "inputs": ["inputs/case.json"], "output": "outputs/classification.json"}
        result = call_candidate("domains/classification/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["name"], "classification")
        self.assertEqual(result["result"]["classes"],
                         {"a": "receipt", "b": "invoice", "c": "invoice", "d": "other"})

    def test_duplicate_id_raises(self):
        payload = {
            "documents": [
                {"id": "a", "filename": "f/a.txt", "text": "Invoice\n"},
                {"id": "a", "filename": "f/b.txt", "text": "Receipt\n"},
            ]
        }
        contract = {"name": "classification", "operation": "invoice_classification",
                    "inputs": ["inputs/case.json"], "output": "outputs/classification.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/classification/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestAmounts(unittest.TestCase):
    def test_total_priority_and_vat_default(self):
        payload = {
            "documents": [
                {"id": "a", "filename": "f/a.txt",
                 "text": "Total: USD 1,200.50\nAmount Due: 12.00\n"},
                {"id": "b", "filename": "f/b.txt",
                 "text": "Amount Due: 12.00\nVAT: 0.00\n"},
            ]
        }
        contract = {"name": "amounts", "operation": "invoice_amounts",
                    "inputs": ["inputs/case.json"], "output": "outputs/amounts.json"}
        result = call_candidate("domains/amounts/transform.py", "transform",
                                args=[[payload], contract])
        self.assertEqual(result["result"]["amounts"],
                         {"a": {"total": "1200.50", "vat": "0.00"},
                          "b": {"total": "12.00", "vat": "0.00"}})

    def test_duplicate_total_raises(self):
        payload = {
            "documents": [
                {"id": "a", "filename": "f/a.txt",
                 "text": "Total: 1.00\nTotal: 2.00\n"},
            ]
        }
        contract = {"name": "amounts", "operation": "invoice_amounts",
                    "inputs": ["inputs/case.json"], "output": "outputs/amounts.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("domains/amounts/transform.py", "transform",
                           args=[[payload], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


class TestArchive(unittest.TestCase):
    def test_archive_summary(self):
        documents = {"documents": [
            {"id": "a", "filename": "f/a.txt", "text": "Invoice\n"},
            {"id": "b", "filename": "f/b.txt", "text": "Receipt\n"},
            {"id": "c", "filename": "f/c.txt", "text": "notes\n"},
        ]}
        classification = {"classes": {"a": "invoice", "b": "receipt", "c": "other"}}
        amounts = {"amounts": {
            "a": {"total": "10.00", "vat": "1.00"},
            "b": {"total": "20.00", "vat": "2.00"},
            "c": {"total": None, "vat": "0.00"},
        }}
        contract = {"name": "archive", "operation": "invoice_archive_summary",
                    "inputs": ["inputs/case.json", "outputs/classification.json",
                               "outputs/amounts.json"],
                    "output": "outputs/archive.json"}
        result = call_candidate("views/archive/transform.py", "transform",
                                args=[[documents, classification, amounts], contract])
        r = result["result"]
        self.assertEqual(r["totals"], {"invoice": "10.00", "receipt": "20.00"})
        self.assertEqual([row["id"] for row in r["rows"]], ["a", "b", "c"])
        self.assertEqual(r["archives"][0]["path"], "classified/invoice/a/f/a.txt")
        self.assertEqual(r["archives"][0]["hex"], "Invoice\n".encode("utf-8").hex())
        # CSV header and null total as empty cell
        lines = r["csv"].split("\n")
        self.assertEqual(lines[0], "id,filename,kind,total,vat")
        # row for id "c" (other, total None) -> total empty cell, vat "0.00"
        self.assertEqual(lines[3], "c,f/c.txt,other,,0.00")

    def test_invoice_missing_total_raises(self):
        documents = {"documents": [
            {"id": "a", "filename": "f/a.txt", "text": "Invoice\n"},
        ]}
        classification = {"classes": {"a": "invoice"}}
        amounts = {"amounts": {"a": {"total": None, "vat": "0.00"}}}
        contract = {"name": "archive", "operation": "invoice_archive_summary",
                    "inputs": ["inputs/case.json", "outputs/classification.json",
                               "outputs/amounts.json"],
                    "output": "outputs/archive.json"}
        with self.assertRaises(CandidateCallError) as cm:
            call_candidate("views/archive/transform.py", "transform",
                           args=[[documents, classification, amounts], contract])
        self.assertEqual(cm.exception.details["failure_phase"], "candidate_exception")
        self.assertEqual(cm.exception.details["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main()
