import math


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _business_input(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    for p in payloads:
        _check_finite(p)
    data = _business_input(payloads[0])
    if not isinstance(data, dict) or "documents" not in data:
        raise ValueError("missing documents")
    documents = data["documents"]
    if not isinstance(documents, list):
        raise ValueError("documents must be a list")
    classes = {}
    seen = set()
    for doc in documents:
        if not isinstance(doc, dict):
            raise ValueError("document must be object")
        if "id" not in doc or "filename" not in doc or "text" not in doc:
            raise ValueError("document missing required field")
        doc_id = doc["id"]
        if not isinstance(doc_id, str):
            raise ValueError("id must be string")
        if doc_id in seen:
            raise ValueError("duplicate id")
        seen.add(doc_id)
        text = doc["text"]
        if not isinstance(text, str):
            raise ValueError("text must be string")
        words = set(text.lower().split())
        if "invoice" in words:
            cls = "invoice"
        elif "receipt" in words:
            cls = "receipt"
        else:
            cls = "other"
        classes[doc_id] = cls
    return {"name": contract["name"], "result": {"classes": classes}}
