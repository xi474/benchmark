import csv
import io
import json
import math
from pathlib import Path


def _check_finite(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _safe_segment(s):
    if not isinstance(s, str):
        raise ValueError("id must be string")
    if s == "" or s != s.strip():
        raise ValueError("id must be non-empty stripped")
    if "/" in s or "\\" in s or ":" in s or s in (".", ".."):
        raise ValueError("unsafe id segment")
    return s


def _safe_relpath(s):
    if not isinstance(s, str):
        raise ValueError("filename must be string")
    if s == "" or s != s.strip():
        raise ValueError("filename must be non-empty stripped")
    if s.startswith("/") or "\\" in s or ":" in s:
        raise ValueError("unsafe filename")
    parts = s.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("unsafe filename")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    for p in payloads:
        _check_finite(p)

    documents = _unwrap(payloads[0])
    classification = _unwrap(payloads[1])
    amounts = _unwrap(payloads[2])

    if not isinstance(documents, dict) or not isinstance(classification, dict) or not isinstance(amounts, dict):
        raise ValueError("payload must be object")

    docs = documents["documents"]
    classes = classification["classes"]
    amts = amounts["amounts"]

    ids = [d["id"] for d in docs]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate id")

    archives = []
    rows = []
    totals = {"invoice": "0.00", "receipt": "0.00"}

    for d in docs:
        did = d["id"]
        filename = _safe_relpath(d["filename"])
        text = d["text"]
        if not isinstance(text, str):
            raise ValueError("text must be string")
        kind = classes[did]
        if kind not in ("invoice", "receipt", "other"):
            raise ValueError("bad class")
        total = amts[did]["total"]
        vat = amts[did]["vat"]

        if kind in ("invoice", "receipt") and total is None:
            raise ValueError("invoice/receipt must have total")

        seg = _safe_segment(did)
        path = "classified/" + kind + "/" + seg + "/" + filename
        hexval = text.encode("utf-8").hex()
        archives.append({"path": path, "hex": hexval})

        rows.append({
            "id": did,
            "filename": filename,
            "kind": kind,
            "total": total,
            "vat": vat,
        })

        if kind in ("invoice", "receipt") and total is not None:
            totals[kind] = _add(totals[kind], total)

    archives.sort(key=lambda a: a["path"])
    rows.sort(key=lambda r: r["id"])

    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["id", "filename", "kind", "total", "vat"])
    for r in rows:
        w.writerow([r["id"], r["filename"], r["kind"],
                    "" if r["total"] is None else r["total"], r["vat"]])
    csv_str = buf.getvalue()

    return {
        "name": contract["name"],
        "result": {
            "archives": archives,
            "rows": rows,
            "csv": csv_str,
            "totals": totals,
        },
    }


def _add(a, b):
    # both are two-decimal strings
    ai = int(a.replace(".", ""))
    bi = int(b.replace(".", ""))
    s = ai + bi
    return f"{s // 100}.{s % 100:02d}"
