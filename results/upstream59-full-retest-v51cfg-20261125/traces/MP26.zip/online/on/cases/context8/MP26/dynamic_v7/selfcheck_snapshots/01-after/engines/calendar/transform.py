import json
from pathlib import Path


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data) == {"name", "result"}:
        data = data["result"]

    contacts = data["contacts"]
    events = data["events"]

    # validate contacts
    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")
    seen_contacts = set()
    for c in contacts:
        if not isinstance(c, str) or not c.strip():
            raise ValueError("invalid contact")
        if c in seen_contacts:
            raise ValueError("duplicate contact")
        seen_contacts.add(c)

    # validate events
    if not isinstance(events, list):
        raise ValueError("events must be list")
    seen_ids = set()
    for e in events:
        if not isinstance(e, dict):
            raise ValueError("event must be object")
        eid = e["id"]
        if not isinstance(eid, str) or not eid.strip():
            raise ValueError("invalid event id")
        if eid in seen_ids:
            raise ValueError("duplicate event id")
        seen_ids.add(eid)
        start = e["start"]
        end = e["end"]
        kind = e["kind"]
        if not isinstance(kind, str) or not kind.strip():
            raise ValueError("invalid kind")
        if start >= end:
            raise ValueError("end must be after start")
        for a in e["attendees"]:
            if a not in seen_contacts:
                raise ValueError("attendee not in contacts")

    # build events output: original events with attendees deduped+sorted
    out_events = []
    for e in events:
        ne = dict(e)
        ne["attendees"] = sorted(set(e["attendees"]))
        out_events.append(ne)

    # existing dinners: start exactly 19:00 and kind == "dinner"
    existing = set()
    for e in events:
        if e["kind"] == "dinner" and e["start"].endswith("T19:00"):
            existing.add(e["start"][:10])
    existing_dinners = sorted(existing)

    return {
        "name": contract["name"],
        "result": {
            "events": out_events,
            "existing_dinners": existing_dinners,
        },
    }
