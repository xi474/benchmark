import datetime


def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    today = data["today"]
    if not isinstance(today, str):
        raise ValueError("today must be string")
    try:
        d = datetime.date.fromisoformat(today)
    except ValueError as e:
        raise ValueError("invalid today") from e

    # Monday is start of week; find next week's Friday (inclusive).
    # Week starts Monday. Next natural week = the week after the week
    # containing today. Friday of that week.
    weekday = d.weekday()  # Monday=0 .. Sunday=6
    # days until next Monday (start of next week)
    days_to_next_monday = (7 - weekday) % 7
    if days_to_next_monday == 0:
        days_to_next_monday = 7
    next_monday = d + datetime.timedelta(days=days_to_next_monday)
    # Friday of that week is next_monday + 4 days
    next_friday = next_monday + datetime.timedelta(days=4)

    dates = []
    cur = d
    while cur <= next_friday:
        dates.append(cur.isoformat())
        cur += datetime.timedelta(days=1)

    return {"name": contract["name"], "result": {"dates": dates}}
