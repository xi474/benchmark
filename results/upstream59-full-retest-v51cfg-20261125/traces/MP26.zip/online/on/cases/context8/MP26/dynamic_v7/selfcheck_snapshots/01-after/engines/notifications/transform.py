def _unwrap(payload):
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    plan = _unwrap(payloads[0])
    snapshots = plan["snapshots"]

    # Map contact -> set of cancelled event ids they attended.
    by_contact = {}
    for snap in snapshots:
        for attendee in snap.get("attendees", []):
            by_contact.setdefault(attendee, set()).add(snap["id"])

    outbox = []
    for contact in sorted(by_contact):
        outbox.append({
            "to": contact,
            "event_ids": sorted(by_contact[contact]),
        })

    return {"name": contract["name"], "result": {"outbox": outbox}}
