import copy
from datetime import datetime, timedelta


def _unwrap(payload):
    # If the object has exactly keys name/result, only result is business input.
    if isinstance(payload, dict) and set(payload) == {"name", "result"}:
        return payload["result"]
    return payload


def _parse_dt(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    days_payload = _unwrap(payloads[0])
    calendar_payload = _unwrap(payloads[1])

    dates = days_payload["dates"]
    existing_dinners = set(calendar_payload["existing_dinners"])
    events = calendar_payload["events"]

    # Build id -> event map for conflict detection.
    event_by_id = {e["id"]: e for e in events}

    added = []
    cancelled = []
    snapshots = []

    for d in dates:
        if d in existing_dinners:
            continue
        start = d + "T19:00"
        end = d + "T20:00"
        new_id = "dinner-" + d
        if new_id in event_by_id:
            raise ValueError("new id conflicts with existing event")
        added.append({
            "id": new_id,
            "start": start,
            "end": end,
            "kind": "dinner",
            "attendees": [],
        })

    # Determine cancelled events: any old event whose half-open interval
    # [start, end) intersects any new reminder's [19:00, 20:00).
    new_starts = {a["start"] for a in added}
    new_ends = {a["end"] for a in added}

    cancelled_ids = set()
    for e in events:
        es = _parse_dt(e["start"])
        ee = _parse_dt(e["end"])
        for a in added:
            ns = _parse_dt(a["start"])
            ne = _parse_dt(a["end"])
            # half-open intersection: es < ne and ns < ee
            if es < ne and ns < ee:
                cancelled_ids.add(e["id"])
                break

    cancelled = sorted(cancelled_ids)
    snapshots = [copy.deepcopy(event_by_id[cid]) for cid in cancelled]

    # added sorted by start
    added.sort(key=lambda a: a["start"])

    return {
        "name": contract["name"],
        "result": {
            "added": added,
            "cancelled": cancelled,
            "snapshots": snapshots,
        },
    }
