import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_contracts():
    contracts = {}
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding="utf-8"))
        contracts[c["name"]] = {"path": cp, "contract": c}
    return contracts


def _topological_order(contracts):
    # Build dependency graph: component depends on components that produce
    # its input files.
    name_to_output = {}
    for name, info in contracts.items():
        name_to_output[name] = info["contract"]["output"]

    output_to_name = {}
    for name, info in contracts.items():
        output_to_name[info["contract"]["output"]] = name

    deps = {}
    for name, info in contracts.items():
        d = set()
        for inp in info["contract"]["inputs"]:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[name] = d

    # Kahn's algorithm
    order = []
    remaining = set(contracts)
    while remaining:
        ready = [n for n in remaining if deps[n] <= set(order)]
        if not ready:
            raise ValueError("dependency cycle detected")
        ready.sort()
        for n in ready:
            order.append(n)
            remaining.discard(n)
    return order


def main():
    contracts = _load_contracts()
    if not contracts:
        raise ValueError("no contracts")
    order = _topological_order(contracts)

    for name in order:
        info = contracts[name]
        render = info["path"].with_name("render.py")
        subprocess.run(
            [sys.executable, str(render), str(ROOT)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    # Run integrator
    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    # Run final report
    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
