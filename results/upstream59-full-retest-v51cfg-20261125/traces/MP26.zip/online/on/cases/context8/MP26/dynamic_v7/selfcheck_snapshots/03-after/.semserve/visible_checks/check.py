import unittest

# Injected by the visible-contract SDK runner.
call_candidate = None
check_api_boundary = None
CandidateCallError = Exception


README = "README.md"

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/dates/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/calendar/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/plan/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/notifications/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
    {
        "target_path": "engines/apply/transform.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "未知额外字段可忽略，但其中非有限JSON仍非法。",
            },
            "invalid_payload_type": {
                "applicable": True,
                "contract_path": README,
                "requirement_quote": "仅对象/数组顶层合法；非法JSON、其他顶层类型和任意嵌套NaN/Infinity抛ValueError。",
            },
        },
    },
]


class TestDates(unittest.TestCase):
    def test_dates_range(self):
        payload = {"today": "2026-11-04", "events": [], "contacts": []}
        contract = {"name": "dates", "operation": "dinner_days", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/dates/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["name"], "dates")
        self.assertEqual(result["result"]["dates"][0], "2026-11-04")
        self.assertEqual(result["result"]["dates"][-1], "2026-11-13")
        self.assertEqual(len(result["result"]["dates"]), 10)


class TestCalendar(unittest.TestCase):
    def test_existing_dinner_dedup(self):
        payload = {
            "today": "2026-11-04",
            "contacts": ["a", "b"],
            "events": [
                {"id": "e1", "start": "2026-11-05T19:00", "end": "2026-11-05T19:10",
                 "kind": "dinner", "attendees": ["a"]},
                {"id": "e2", "start": "2026-11-05T19:00", "end": "2026-11-05T19:05",
                 "kind": "dinner", "attendees": ["b"]},
            ],
        }
        contract = {"name": "calendar", "operation": "dinner_calendar_index", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/calendar/transform.py", "transform", args=[[payload], contract])
        self.assertEqual(result["result"]["existing_dinners"], ["2026-11-05"])


class TestPlan(unittest.TestCase):
    def test_skip_existing_and_cancel_conflict(self):
        days = {"dates": ["2026-11-04", "2026-11-05"]}
        calendar = {
            "existing_dinners": ["2026-11-05"],
            "events": [
                {"id": "old", "start": "2026-11-04T19:30", "end": "2026-11-04T20:30",
                 "kind": "other", "attendees": ["a"]},
            ],
        }
        contract = {"name": "plan", "operation": "dinner_change_plan", "inputs": ["x", "y"], "output": "z"}
        result = call_candidate("engines/plan/transform.py", "transform", args=[[days, calendar], contract])
        added_ids = [e["id"] for e in result["result"]["added"]]
        self.assertEqual(added_ids, ["dinner-2026-11-04"])
        self.assertEqual(result["result"]["cancelled"], ["old"])


class TestNotifications(unittest.TestCase):
    def test_outbox(self):
        plan = {
            "snapshots": [
                {"id": "c1", "attendees": ["b", "a", "a"]},
                {"id": "c2", "attendees": ["a"]},
            ]
        }
        contract = {"name": "notifications", "operation": "dinner_notifications", "inputs": ["x"], "output": "y"}
        result = call_candidate("engines/notifications/transform.py", "transform", args=[[plan], contract])
        outbox = result["result"]["outbox"]
        self.assertEqual(outbox[0], {"to": "a", "event_ids": ["c1", "c2"]})
        self.assertEqual(outbox[1], {"to": "b", "event_ids": ["c1"]})


class TestApply(unittest.TestCase):
    def test_apply_removes_cancelled(self):
        calendar = {"events": [
            {"id": "keep", "start": "2026-11-04T18:00", "end": "2026-11-04T19:00",
             "kind": "other", "attendees": []},
            {"id": "drop", "start": "2026-11-04T19:30", "end": "2026-11-04T20:30",
             "kind": "other", "attendees": []},
        ]}
        plan = {"cancelled": ["drop"], "added": [
            {"id": "dinner-2026-11-04", "start": "2026-11-04T19:00", "end": "2026-11-04T20:00",
             "kind": "dinner", "attendees": []},
        ]}
        notifications = {"outbox": []}
        contract = {"name": "apply", "operation": "dinner_apply", "inputs": ["a", "b", "c"], "output": "d"}
        result = call_candidate("engines/apply/transform.py", "transform", args=[[calendar, plan, notifications], contract])
        ids = [e["id"] for e in result["result"]["events"]]
        self.assertEqual(ids, ["dinner-2026-11-04", "keep"])


if __name__ == "__main__":
    unittest.main()
