def compute(payload):
    """按主题输入顺序生成评分表；每行把具有效章节证据的论文 ID 映射到该主题最高质量分。"""
    topics = payload["topics"]
    papers = payload["papers"]

    paper_methods = {p["id"]: set(p["methods"]) for p in papers}

    rows = []
    for topic in topics:
        scores = {}
        for paper in papers:
            pid = paper["id"]
            best = None
            for claim in paper["claims"]:
                c_topic, chapter, quality = claim
                if c_topic != topic:
                    continue
                if chapter not in paper_methods[pid]:
                    continue
                if best is None or quality > best:
                    best = quality
            if best is not None:
                scores[pid] = best
        rows.append(scores)

    return rows
