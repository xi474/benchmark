def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    topics = payload["topics"]
    scores = left  # list of dicts, one per topic in order: paper_id -> max quality

    # Build candidate (paper_id, quality) per topic.
    candidates = []
    for topic_scores in scores:
        cands = [(pid, q) for pid, q in topic_scores.items()]
        candidates.append(cands)

    n = len(topics)
    best = None  # (min_quality, total_quality, paper_id_sequence)

    # Backtracking assignment: one paper per topic, no reuse.
    used = set()
    assignment = [None] * n

    def search(i, cur_min, cur_total):
        nonlocal best
        if i == n:
            seq = tuple(assignment)
            key = (-cur_min, -cur_total, seq)
            if best is None or key < best:
                best = key
            return
        for pid, q in candidates[i]:
            if pid in used:
                continue
            used.add(pid)
            assignment[i] = pid
            search(i + 1, min(cur_min, q), cur_total + q)
            used.discard(pid)
            assignment[i] = None

    search(0, float("inf"), 0)

    if best is None:
        return None

    min_q, total_q, seq = best
    review = [[topics[i], seq[i], scores[i][seq[i]]] for i in range(n)]

    # Build graph: existing edges + supports edges, dedupe, sort.
    edges = set()
    for edge in right:
        edges.add(tuple(edge))
    for i in range(n):
        edges.add((seq[i], "supports", topics[i]))
    graph = sorted(edges)

    return {"review": review, "graph": [list(e) for e in graph]}
