import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that unknown fields or non-finite values must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that a non-object payload must raise ValueError.",
            },
        },
    },
]


class TestTransform(unittest.TestCase):
    def test_empty_topics_returns_empty_review_and_deduped_graph(self):
        # TASK.md: 空主题表对应空综述及原图边的去重排序。
        payload = {
            "topics": [],
            "papers": [],
            "graph": [["b", "r", "c"], ["a", "r", "b"], ["b", "r", "c"]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["review"], [])
        self.assertEqual(result["graph"], [["a", "r", "b"], ["b", "r", "c"]])

    def test_no_complete_assignment_returns_null(self):
        # TASK.md: 无完整分配返回 null。
        payload = {
            "topics": ["t1", "t2"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t1", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsNone(result)

    def test_tie_break_lexicographic_paper_ids(self):
        # TASK.md: 依次最大化最低质量、总质量，再取论文ID序列字典序最小解。
        payload = {
            "topics": ["a", "b"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["a", "m", 5], ["b", "m", 5]]},
                {"id": "p1", "methods": ["m"], "claims": [["a", "m", 5], ["b", "m", 5]]},
            ],
            "graph": [],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        # Both assignments have min=5, total=10; lexicographically smallest id sequence is [p0, p1].
        self.assertEqual([r[1] for r in result["review"]], ["p0", "p1"])

    def test_supports_edges_merged_and_sorted(self):
        # TASK.md: 后者是既有边与每条 [论文ID,"supports",主题] 的去重并集，按三项字典序排序。
        payload = {
            "topics": ["t"],
            "papers": [
                {"id": "p0", "methods": ["m"], "claims": [["t", "m", 3]]},
            ],
            "graph": [["p0", "supports", "t"], ["x", "y", "z"]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(
            result["graph"],
            [["p0", "supports", "t"], ["x", "y", "z"]],
        )


if __name__ == "__main__":
    unittest.main()
