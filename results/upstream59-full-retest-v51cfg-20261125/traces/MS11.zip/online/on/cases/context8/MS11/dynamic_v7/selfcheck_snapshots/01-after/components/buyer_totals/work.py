def compute(payload):
    """按买家 ID 汇总属于 Cameras 或 Electronics 的行金额，每行只计一次；无购买为零。"""
    totals = {b: 0 for b in payload["buyers"]}
    for order in payload["orders"]:
        buyer = order["buyer"]
        for categories, qty, price in order["lines"]:
            if "Electronics" in categories or "Cameras" in categories:
                totals[buyer] = totals.get(buyer, 0) + qty * price
    return totals
