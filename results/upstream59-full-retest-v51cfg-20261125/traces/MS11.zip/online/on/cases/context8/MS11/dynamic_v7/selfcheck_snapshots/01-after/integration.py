from itertools import product


def _build_evidence(payload, drop):
    """Return dict[(student, buyer)] -> confidence, using max per source then sum."""
    conf = {}
    for source, student, buyer, strength in payload["evidence"]:
        if drop is not None and source == drop:
            continue
        key = (student, buyer)
        cur = conf.get(key)
        if cur is None:
            conf[key] = {source: strength}
        else:
            cur[source] = max(cur.get(source, 0), strength)
    return {k: sum(v.values()) for k, v in conf.items()}


def _solve_block(students, buyers, conf):
    """Enumerate all perfect matchings of a connected block, return list of
    (matching, floor, total) where matching maps student -> buyer."""
    # Build adjacency: only pairs with evidence are usable.
    adj = {s: [b for b in buyers if (s, b) in conf] for s in students}
    results = []
    used = set()

    def rec(i, cur, cur_floor, cur_total):
        if i == len(students):
            results.append((dict(cur), cur_floor, cur_total))
            return
        s = students[i]
        for b in adj[s]:
            if b in used:
                continue
            w = conf[(s, b)]
            used.add(b)
            rec(i + 1, cur + [(s, b)], min(cur_floor, w) if cur else w, cur_total + w)
            used.remove(b)

    rec(0, [], None, 0)
    return results


def _connected_components(students, buyers, conf):
    """Split the bipartite evidence graph into connected components."""
    adj_s = {s: set() for s in students}
    adj_b = {b: set() for b in buyers}
    for (s, b) in conf:
        adj_s[s].add(b)
        adj_b[b].add(s)
    seen_s = set()
    seen_b = set()
    comps = []
    for s in students:
        if s in seen_s:
            continue
        # BFS over the bipartite graph
        stack = [("s", s)]
        cs = []
        cb = []
        seen_s.add(s)
        while stack:
            kind, node = stack.pop()
            if kind == "s":
                cs.append(node)
                for b in adj_s[node]:
                    if b not in seen_b:
                        seen_b.add(b)
                        stack.append(("b", b))
            else:
                cb.append(node)
                for s2 in adj_b[node]:
                    if s2 not in seen_s:
                        seen_s.add(s2)
                        stack.append(("s", s2))
        comps.append((cs, cb))
    return comps


def _solve_all(students, buyers, conf):
    """Return list of full matchings (dict student->buyer) that are optimal."""
    comps = _connected_components(students, buyers, conf)
    # Each component must have equal sides for a perfect matching to exist.
    block_solutions = []
    for cs, cb in comps:
        if len(cs) != len(cb):
            return []
        sols = _solve_block(cs, cb, conf)
        if not sols:
            return []
        block_solutions.append(sols)
    # Combine across blocks, maximizing min floor then total sum.
    best = []
    best_floor = -1
    best_total = -1

    def rec(idx, cur, cur_floor, cur_total):
        nonlocal best, best_floor, best_total
        if idx == len(block_solutions):
            if cur_floor > best_floor or (cur_floor == best_floor and cur_total > best_total):
                best = [dict(cur)]
                best_floor = cur_floor
                best_total = cur_total
            elif cur_floor == best_floor and cur_total == best_total:
                best.append(dict(cur))
            return
        for m, f, t in block_solutions[idx]:
            rec(idx + 1, cur + list(m.items()), min(cur_floor, f) if cur else f, cur_total + t)

    rec(0, [], None, 0)
    return best


def _result_for(payload, left, right, drop):
    students = payload["students"]
    buyers = payload["buyers"]
    conf = _build_evidence(payload, drop)
    matchings = _solve_all(students, buyers, conf)
    if not matchings:
        return None
    n = len(students)
    # X per student (integer), Y per buyer (integer)
    X = {s: left[s] for s in students}
    Y = {b: right[b] for b in buyers}
    nums = []
    for m in matchings:
        sxy = sum(X[s] * Y[m[s]] for s in students)
        sx = sum(X[s] for s in students)
        sy = sum(Y[m[s]] for s in students)
        nums.append(n * sxy - sx * sy)
    min_num = min(nums)
    max_num = max(nums)
    # Lexicographically smallest buyer vector (by student ID ascending).
    def buyer_vector(m):
        return [m[s] for s in sorted(students)]
    # min_buyers is the lexicographically smallest buyer vector among all
    # optimal matchings; max_buyers is the lexicographically largest.
    min_vec = None
    max_vec = None
    for m in matchings:
        v = buyer_vector(m)
        if min_vec is None or v < min_vec:
            min_vec = v
        if max_vec is None or v > max_vec:
            max_vec = v
    # Forced pairs: present in all optimal matchings.
    forced = []
    for s in students:
        bs = {m[s] for m in matchings}
        if len(bs) == 1:
            forced.append([s, next(iter(bs))])
    forced.sort(key=lambda p: p[0])
    # floor/total are the optimal objective values (same for all matchings).
    floor = min(min(conf[(s, m[s])] for s in students) for m in matchings)
    total = sum(conf[(s, m[s])] for s in students for m in matchings[:1])
    return {
        "floor": floor,
        "total": total,
        "count": len(matchings),
        "min_num": min_num,
        "max_num": max_num,
        "min_buyers": min_vec,
        "max_buyers": max_vec,
        "forced": forced,
    }


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    out = []
    for drop in payload["drop"]:
        out.append({"drop": drop, "result": _result_for(payload, left, right, drop)})
    return out
