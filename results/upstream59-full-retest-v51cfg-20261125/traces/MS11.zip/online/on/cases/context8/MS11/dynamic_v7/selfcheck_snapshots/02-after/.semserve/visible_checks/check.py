import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


class TestTransform(unittest.TestCase):
    def test_output_shape_and_values(self):
        payload = load("public_input.json")
        result = call_candidate("integration.py", "combine",
                                args=[payload,
                                      {"S01-0": 4800, "S00-0": 4300},
                                      {"B00-0": 18, "B01-0": 15}])
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 3)
        self.assertEqual([r["drop"] for r in result], [None, "ledger", "witness"])
        r0 = result[0]["result"]
        self.assertEqual(r0["floor"], 6)
        self.assertEqual(r0["total"], 12)
        self.assertEqual(r0["count"], 2)
        self.assertEqual(r0["min_num"], -1500)
        self.assertEqual(r0["max_num"], 1500)
        self.assertEqual(r0["min_buyers"], ["B00-0", "B01-0"])
        self.assertEqual(r0["max_buyers"], ["B01-0", "B00-0"])
        self.assertEqual(r0["forced"], [])

    def test_drop_ledger_single_mapping(self):
        payload = load("public_input.json")
        result = call_candidate("integration.py", "combine",
                                args=[payload,
                                      {"S01-0": 4800, "S00-0": 4300},
                                      {"B00-0": 18, "B01-0": 15}])
        r1 = result[1]["result"]
        self.assertEqual(r1["count"], 1)
        self.assertEqual(r1["min_num"], 1500)
        self.assertEqual(r1["max_num"], 1500)
        self.assertEqual(r1["min_buyers"], ["B01-0", "B00-0"])
        self.assertEqual(r1["max_buyers"], ["B01-0", "B00-0"])
        self.assertEqual(r1["forced"], [["S00-0", "B01-0"], ["S01-0", "B00-0"]])

    def test_student_scores_component(self):
        payload = load("components/student_scores/input.json")
        result = call_candidate("components/student_scores/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, {"S01-0": 4800, "S00-0": 4300})

    def test_buyer_totals_component(self):
        payload = load("components/buyer_totals/input.json")
        result = call_candidate("components/buyer_totals/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, {"B00-0": 18, "B01-0": 15})

    def test_buyer_totals_zero_for_no_purchase(self):
        payload = {
            "buyers": ["B0", "B1"],
            "orders": [
                {"buyer": "B0", "status": "done",
                 "lines": [[["Books"], 2, 100]]}
            ],
        }
        result = call_candidate("components/buyer_totals/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, {"B0": 0, "B1": 0})

    def test_student_scores_ignores_other_courses_and_null(self):
        payload = {
            "grades": [
                ["S0", 1, 50],
                ["S0", 2, 60],
                ["S0", 3, 100],
                ["S0", 1, None],
            ],
        }
        result = call_candidate("components/student_scores/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, {"S0": 5500})


if __name__ == "__main__":
    unittest.main()
