def compute(payload):
    """每个到货信号映射至可供菜品 ID，保持 recipes 顺序，检查难度、原料可得性和过敏限制。"""
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]

    banned = set()
    for g in groups:
        for ing in g[2]:
            banned.add(ing)

    result = {}
    for signal, available in delivery.items():
        available_set = set(available)
        eligible = []
        for r in recipes:
            if r["difficulty"] > 4:
                continue
            ingredients = r["ingredients"]
            if not all(ing in available_set for ing in ingredients):
                continue
            if any(ing in banned for ing in ingredients):
                continue
            eligible.append(r["id"])
        result[signal] = eligible
    return result
