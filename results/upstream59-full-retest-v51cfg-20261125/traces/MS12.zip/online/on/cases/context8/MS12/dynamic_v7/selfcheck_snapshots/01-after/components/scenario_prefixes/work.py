def compute(payload):
    """输出 [信号历史,该完整叶的权重或 null]，去重生成所有非空前缀，按历史字典序排列。"""
    scenarios = payload["scenarios"]
    leaf_weight = {}
    for sc in scenarios:
        leaf_weight[tuple(sc["signals"])] = sc.get("weight")

    prefixes = set()
    for sc in scenarios:
        signals = list(sc["signals"])
        for i in range(1, len(signals) + 1):
            prefixes.add(tuple(signals[:i]))

    result = []
    for prefix in sorted(prefixes):
        result.append([list(prefix), leaf_weight.get(prefix)])
    return result
