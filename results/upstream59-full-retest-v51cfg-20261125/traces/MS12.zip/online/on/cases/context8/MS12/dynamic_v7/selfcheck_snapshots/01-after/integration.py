def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]
    budget = payload["budget"]
    scenarios = payload["scenarios"]

    # left: list of [history, weight-or-null] sorted lexicographically
    # right: dict signal -> eligible recipe ids (in recipe order)
    histories = [h for h, _ in left]

    # recipe lookup
    recipe_by_id = {r["id"]: r for r in recipes}

    # group info
    group_likes = [set(g[3]) for g in groups]
    group_count = [g[1] for g in groups]

    # For each history (prefix), the set of scenarios sharing that prefix.
    # A policy assigns one dish per history. The dish for a history must be
    # eligible on every day of that history (all ingredients available each day).
    # Actually eligibility is per-signal (per-day). A dish assigned to a history
    # of length d must be eligible on each of the d days (each signal in history).
    # We compute per-history eligible dishes = intersection over days of
    # right[signal].
    history_eligible = {}
    for h in histories:
        # A dish assigned to a history must be eligible on the last day of that
        # history (the most recently observed delivery signal).
        last_sig = h[-1]
        history_eligible[tuple(h)] = list(right[last_sig])

    # Map each scenario to its full path and weight.
    # Each scenario's day-d dish is determined by the history = signals[:d].
    # Constraints:
    #  - no repeated dish name along a path
    #  - adjacent days not same category
    #  - total cost <= budget
    # Objective (lexicographic):
    #  1. maximize min over scenarios of service score (per-person satisfaction)
    #  2. maximize sum over scenarios of weight * total-person score
    #  3. minimize sum over scenarios of weight * path cost

    # Enumerate all policies: assignment of a dish to each history.
    # Number of histories <= 12, dishes <= 12. Brute force over assignments is
    # too large in general, but we can do a DFS with pruning. Given small limits
    # (<=5 days, <=12 dishes, <=12 prefixes), we enumerate via backtracking.

    # Precompute per-history candidate dishes.
    hist_list = histories
    n_hist = len(hist_list)
    hist_index = {tuple(h): i for i, h in enumerate(hist_list)}

    # For each scenario, list of (history_index, day) in order.
    scenario_paths = []
    for sc in scenarios:
        sigs = sc["signals"]
        weight = sc["weight"]
        path = []
        for d in range(1, len(sigs) + 1):
            h = tuple(sigs[:d])
            path.append(hist_index[h])
        scenario_paths.append((path, weight))

    # satisfaction per dish per group: 1 if group likes dish cat else 0
    def dish_sat(dish_id):
        cat = recipe_by_id[dish_id]["cat"]
        return [1 if cat in likes else 0 for likes in group_likes]

    # We'll do DFS assigning dishes to histories in order.
    # Track per-scenario accumulated: used dish ids, last cat, cost, per-group sat sums.
    # To evaluate objective we need full assignment. We'll collect all valid
    # assignments and then pick best. Given small sizes this is acceptable.

    # Precompute candidate list per history.
    candidates = [history_eligible[tuple(h)] for h in hist_list]

    # For efficiency, precompute dish cost and cat.
    dish_cost = {r["id"]: r["cost"] for r in recipes}
    dish_cat = {r["id"]: r["cat"] for r in recipes}

    # scenario state: for each scenario, list of (dish_id, cat) assigned so far
    # We'll maintain per-scenario: used set, last cat, cost, sat per group.
    # Simpler: after full assignment, validate each scenario path.

    best = None  # (floor, utility, cost, assignment_tuple)

    # DFS over histories
    assignment = [None] * n_hist

    def evaluate():
        # compute per scenario
        min_service = None
        total_utility = 0
        total_cost = 0
        for path, weight in scenario_paths:
            used = set()
            last_cat = None
            cost = 0
            sat = [0] * len(groups)
            for hi in path:
                dish = assignment[hi]
                if dish in used:
                    return None
                used.add(dish)
                cat = dish_cat[dish]
                if last_cat is not None and cat == last_cat:
                    return None
                last_cat = cat
                cost += dish_cost[dish]
                ds = dish_sat(dish)
                for gi in range(len(groups)):
                    sat[gi] += ds[gi]
            if cost > budget:
                return None
            # service score = min over groups of per-person satisfaction
            service = min(sat)
            total_utility += weight * sum(sat[gi] * group_count[gi] for gi in range(len(groups)))
            total_cost += weight * cost
            if min_service is None or service < min_service:
                min_service = service
        return (min_service, total_utility, total_cost)

    def dfs(i):
        nonlocal best
        if i == n_hist:
            res = evaluate()
            if res is not None:
                floor, utility, cost = res
                key = (floor, utility, -cost)
                if best is None or key > best[0]:
                    best = (key, tuple(assignment))
            return
        for dish in candidates[i]:
            assignment[i] = dish
            dfs(i + 1)
        assignment[i] = None

    dfs(0)

    if best is None:
        return {"histories": histories, "optimal": None}

    key, best_assignment = best
    floor, utility, cost = key[0], key[1], -key[2]

    # count: number of distinct history->dish mappings among optimal policies
    # menu: lexicographically smallest dish vector among optimal policies
    # allowed: per history, sorted list of dishes chosen by at least one optimal policy

    # Re-enumerate to collect all optimal policies.
    optimal_assignments = []
    def dfs_collect(i):
        if i == n_hist:
            res = evaluate()
            if res is not None:
                f, u, c = res
                if (f, u, c) == (floor, utility, cost):
                    optimal_assignments.append(tuple(assignment))
            return
        for dish in candidates[i]:
            assignment[i] = dish
            dfs_collect(i + 1)
        assignment[i] = None

    dfs_collect(0)

    # distinct mappings
    distinct = set(optimal_assignments)
    count = len(distinct)

    # lexicographically smallest menu vector
    menu = list(min(distinct))

    # allowed per history
    allowed = []
    for i in range(n_hist):
        s = sorted(set(a[i] for a in distinct))
        allowed.append(s)

    return {
        "histories": histories,
        "optimal": {
            "floor": floor,
            "utility": utility,
            "cost": cost,
            "count": count,
            "menu": menu,
            "allowed": allowed,
        },
    }
