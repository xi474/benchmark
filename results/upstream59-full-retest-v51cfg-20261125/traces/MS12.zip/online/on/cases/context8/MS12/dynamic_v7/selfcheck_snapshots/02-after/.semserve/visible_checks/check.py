import json
import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> raised for candidate exceptions


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


class TransformBehaviorTests(unittest.TestCase):
    """High-risk behavior checks not established by the public fixture."""

    def test_infeasible_budget_yields_null_optimal(self):
        # A budget too small for any single day's cheapest dish makes the
        # policy infeasible; optimal must be null while histories remain.
        payload = load("public_input.json")
        payload = json.loads(json.dumps(payload))
        payload["budget"] = 0
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, dict)
        self.assertIn("histories", result)
        self.assertIsNone(result["optimal"])

    def test_histories_are_lexicographic_prefixes(self):
        # histories must be all distinct non-empty prefixes, short before
        # their extensions, in lexicographic order.
        payload = load("public_input.json")
        result = call_candidate("solution.py", "transform", args=[payload])
        histories = result["histories"]
        self.assertTrue(all(isinstance(h, list) and len(h) > 0 for h in histories))
        self.assertEqual(histories, sorted(histories))
        # short prefix before its extension
        for i in range(len(histories)):
            for j in range(i + 1, len(histories)):
                if histories[j][:len(histories[i])] == histories[i]:
                    self.assertLess(len(histories[i]), len(histories[j]))

    def test_optimal_menu_respects_budget_and_no_repeat(self):
        # Independent consumer: verify the returned menu is a valid policy.
        payload = load("public_input.json")
        result = call_candidate("solution.py", "transform", args=[payload])
        opt = result["optimal"]
        self.assertIsNotNone(opt)
        menu = opt["menu"]
        histories = result["histories"]
        self.assertEqual(len(menu), len(histories))
        byid = {r["id"]: r for r in payload["recipes"]}
        # each menu dish must be eligible on the last signal of its history
        for h, dish in zip(histories, menu):
            last = h[-1]
            avail = set(payload["delivery"][last])
            r = byid[dish]
            self.assertLessEqual(r["difficulty"], 4)
            self.assertTrue(all(i in avail for i in r["ingredients"]))
        # no repeat dish name along any single scenario path
        for sc in payload["scenarios"]:
            sigs = sc["signals"]
            path = []
            for d in range(1, len(sigs) + 1):
                h = sigs[:d]
                path.append(menu[histories.index(h)])
            self.assertEqual(len(set(path)), len(path))

    def test_allowed_lists_are_sorted_and_subset_of_menu_choices(self):
        payload = load("public_input.json")
        result = call_candidate("solution.py", "transform", args=[payload])
        opt = result["optimal"]
        for allowed in opt["allowed"]:
            self.assertEqual(allowed, sorted(allowed))
            self.assertTrue(all(isinstance(x, str) for x in allowed))


if __name__ == "__main__":
    unittest.main()
