def compute(payload):
    """为每个查询逐时隙列出当时可见且实际为 down 的域名数组，升序；按有效时刻再按看到时刻选择最新记录。"""
    queries = payload["queries"]
    log = payload["log"]

    by_domain = {}
    for domain, effective, seen, status in log:
        by_domain.setdefault(domain, []).append((effective, seen, status))
    for domain in by_domain:
        by_domain[domain].sort(key=lambda r: (r[0], r[1]))

    results = []
    for q in queries:
        start = q["start"]
        end = q["end"]
        as_of = q["as_of"]
        slots = []
        for t in range(start, end):
            down_domains = []
            for domain, records in by_domain.items():
                cands = [r for r in records if r[1] <= as_of and r[0] <= t]
                if not cands:
                    continue
                best = max(cands, key=lambda r: (r[0], r[1]))
                if best[2] in ("down", "degraded"):
                    down_domains.append(domain)
            down_domains.sort()
            slots.append(down_domains)
        results.append(slots)
    return results
