def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    queries = payload["queries"]
    domains = payload["domains"]
    services = payload["services"]
    log = payload["log"]

    # left: per-query per-slot list of unavailable (down/degraded) domains
    # right: service id -> [need, inputs]
    quorums = right

    # Build service dependency graph (acyclic). inputs may be domains or services.
    # A service is available if at least `need` distinct direct inputs are available.
    # A domain is available if not in the unavailable set (or forced up by repair).

    # For each query, compute per-slot availability of every target.
    results = []
    for qi, q in enumerate(queries):
        start = q["start"]
        end = q["end"]
        targets = q["targets"]
        slots_unavailable = left[qi]  # list per slot of unavailable domains

        # Determine per-slot availability of each service (topological order).
        # services list is acyclic; process in given order may not be topological,
        # so do a memoized recursive evaluation per slot.
        service_ids = [s["id"] for s in services]
        service_index = {s["id"]: s for s in services}

        def service_available(sid, unavailable_set):
            s = service_index[sid]
            need = s["need"]
            cnt = 0
            for inp in s["inputs"]:
                if inp in service_index:
                    if service_available(inp, unavailable_set):
                        cnt += 1
                else:
                    # domain
                    if inp not in unavailable_set:
                        cnt += 1
                if cnt >= need:
                    return True
            return cnt >= need

        # For each slot, compute target availability.
        target_available = []  # per slot, dict target->bool
        for slot in range(start, end):
            unavailable = set(slots_unavailable[slot - start])
            avail = {}
            for t in targets:
                if t in service_index:
                    avail[t] = service_available(t, unavailable)
                else:
                    avail[t] = t not in unavailable
            target_available.append(avail)

        # Build incidents: for each target, merge adjacent unavailable slots.
        incidents = []
        for t in targets:
            i = 0
            while i < end - start:
                if not target_available[i][t]:
                    j = i
                    while j < end - start and not target_available[j][t]:
                        j += 1
                    incidents.append([t, start + i, start + j])
                    i = j
                else:
                    i += 1
        # Sort incidents by target id then start.
        incidents.sort(key=lambda x: (x[0], x[1]))

        # Compute minimal repair sets.
        # A repair set is a set of domains forced up in every slot of the window.
        # All targets must be available in every slot.
        # Find all inclusion-minimal sets.
        all_domains = list(domains)

        def all_targets_available(forced):
            for slot in range(start, end):
                unavailable = set(slots_unavailable[slot - start]) - forced
                for t in targets:
                    if t in service_index:
                        if not service_available(t, unavailable):
                            return False
                    else:
                        if t in unavailable:
                            return False
            return True

        # Enumerate subsets of domains (up to 40 domains -> too many).
        # Use a smarter approach: only domains that are ever unavailable matter.
        # Collect candidate domains that appear unavailable in any slot.
        candidate_domains = set()
        for slot in range(start, end):
            candidate_domains |= set(slots_unavailable[slot - start])
        candidate_domains = sorted(candidate_domains)

        minimal_sets = []
        n = len(candidate_domains)
        # Enumerate subsets; n is small in practice (sparse).
        for mask in range(1 << n):
            forced = set()
            for k in range(n):
                if mask & (1 << k):
                    forced.add(candidate_domains[k])
            if all_targets_available(forced):
                # check minimality
                minimal = True
                for d in forced:
                    if all_targets_available(forced - {d}):
                        minimal = False
                        break
                if minimal:
                    minimal_sets.append(sorted(forced))

        # Sort: by size then lexicographic member sequence.
        minimal_sets.sort(key=lambda s: (len(s), s))

        if not minimal_sets:
            repairs = [[]]
        else:
            repairs = minimal_sets

        results.append({"incidents": incidents, "repairs": repairs})

    return results
