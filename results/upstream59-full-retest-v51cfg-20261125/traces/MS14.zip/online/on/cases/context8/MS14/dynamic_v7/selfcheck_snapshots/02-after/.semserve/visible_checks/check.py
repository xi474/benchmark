import unittest

# Injected by the SDK runner; do not import.
# call_candidate(path, function, args=[...]) -> JSON value
# check_api_boundary(...) -> raises on failure
# CandidateCallError -> exception type

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "transform(payload) 返回题面指定的 JSON 值并保持输入值完整",
                "reason": "TASK.md does not state that non-finite values in unknown fields must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "transform(payload) 返回题面指定的 JSON 值并保持输入值完整",
                "reason": "TASK.md does not state that a non-object payload must raise ValueError.",
            },
        },
    },
]


class TestObservedOutages(unittest.TestCase):
    def test_down_and_degraded_are_unavailable(self):
        # Public rule: down and degraded both count as unavailable.
        payload = {
            "queries": [{"start": 0, "end": 2, "as_of": 5, "targets": ["x"]}],
            "log": [
                ["a", 0, 1, "down"],
                ["b", 0, 1, "degraded"],
                ["c", 0, 1, "up"],
            ],
        }
        result = call_candidate(
            "components/observed_outages/work.py", "compute", args=[payload]
        )
        self.assertEqual(result, [[["a", "b"], ["a", "b"]]])

    def test_as_of_filters_late_records(self):
        # Public rule: only records with seen time <= as_of are visible.
        payload = {
            "queries": [{"start": 0, "end": 1, "as_of": 2, "targets": ["x"]}],
            "log": [
                ["a", 0, 1, "down"],
                ["a", 0, 3, "up"],  # seen after as_of, must be ignored
            ],
        }
        result = call_candidate(
            "components/observed_outages/work.py", "compute", args=[payload]
        )
        self.assertEqual(result, [[["a"]]])

    def test_latest_record_by_effective_then_seen(self):
        # Public rule: pick latest by effective time, then last seen.
        payload = {
            "queries": [{"start": 0, "end": 1, "as_of": 9, "targets": ["x"]}],
            "log": [
                ["a", 0, 1, "down"],
                ["a", 0, 2, "up"],  # same effective, later seen -> up wins
            ],
        }
        result = call_candidate(
            "components/observed_outages/work.py", "compute", args=[payload]
        )
        self.assertEqual(result, [[[]]])


class TestServiceQuorums(unittest.TestCase):
    def test_index_preserves_order(self):
        payload = {
            "services": [
                {"id": "s1", "need": 2, "inputs": ["a", "b", "c"]},
                {"id": "s2", "need": 1, "inputs": ["d", "a"]},
            ]
        }
        result = call_candidate(
            "components/service_quorums/work.py", "compute", args=[payload]
        )
        self.assertEqual(
            result,
            {"s1": [2, ["a", "b", "c"]], "s2": [1, ["d", "a"]]},
        )


class TestIntegration(unittest.TestCase):
    def test_no_repair_needed_when_all_up(self):
        # Public rule: when no repair is needed, repairs == [[]].
        payload = {
            "domains": ["a", "b"],
            "services": [],
            "log": [["a", 0, 1, "up"], ["b", 0, 1, "up"]],
            "queries": [{"start": 0, "end": 2, "as_of": 5, "targets": ["a", "b"]}],
        }
        left = [[[], []]]
        right = {}
        result = call_candidate(
            "integration.py", "combine", args=[payload, left, right]
        )
        self.assertEqual(result[0]["incidents"], [])
        self.assertEqual(result[0]["repairs"], [[]])

    def test_incident_merges_adjacent_slots(self):
        # Public rule: adjacent abnormal slots merge into one half-open interval.
        payload = {
            "domains": ["a"],
            "services": [],
            "log": [["a", 0, 1, "down"]],
            "queries": [{"start": 0, "end": 3, "as_of": 5, "targets": ["a"]}],
        }
        left = [[["a"], ["a"], ["a"]]]
        right = {}
        result = call_candidate(
            "integration.py", "combine", args=[payload, left, right]
        )
        self.assertEqual(result[0]["incidents"], [["a", 0, 3]])

    def test_service_quorum_need(self):
        # Public rule: service available when >= need distinct direct inputs available.
        payload = {
            "domains": ["a", "b", "c"],
            "services": [{"id": "s", "need": 2, "inputs": ["a", "b", "c"]}],
            "log": [],
            "queries": [{"start": 0, "end": 1, "as_of": 5, "targets": ["s"]}],
        }
        # a down, b down, c up -> only 1 available, need 2 -> unavailable
        left = [[["a", "b"]]]
        right = {"s": [2, ["a", "b", "c"]]}
        result = call_candidate(
            "integration.py", "combine", args=[payload, left, right]
        )
        self.assertEqual(result[0]["incidents"], [["s", 0, 1]])


if __name__ == "__main__":
    unittest.main()
