def _cell_score(a, b, c, k):
    """Median of the three ratings decides the net score."""
    vals = sorted((a, b, c))
    median = vals[1]
    if median == k - 1:
        return 1
    if median == 0:
        return -1
    return 0


def _enumerate_tables(row_sums, col_sums, k, forced_zero, upper):
    """Enumerate all non-negative integer k x k matrices with the given
    row/column sums, forced-zero cells, and per-cell upper bounds."""
    results = []
    matrix = [[0] * k for _ in range(k)]
    rem_row = list(row_sums)
    rem_col = list(col_sums)

    def rec(idx):
        if idx == k * k:
            if all(r == 0 for r in rem_row) and all(c == 0 for c in rem_col):
                results.append([row[:] for row in matrix])
            return
        a, c = divmod(idx, k)
        if (a, c) in forced_zero:
            rec(idx + 1)
            return
        hi = min(rem_row[a], rem_col[c], upper[a][c])
        for v in range(0, hi + 1):
            rem_row[a] -= v
            rem_col[c] -= v
            # Feasibility pruning: remaining row/column sums must be reachable
            # through the remaining non-forced cells.
            row_cap = sum(rem_col[j] for j in range(c + 1, k) if (a, j) not in forced_zero)
            col_cap = sum(rem_row[i] for i in range(a + 1, k) if (i, c) not in forced_zero)
            if rem_row[a] <= row_cap and rem_col[c] <= col_cap:
                matrix[a][c] = v
                rec(idx + 1)
            rem_row[a] += v
            rem_col[c] += v

    rec(0)
    return results


def compute(payload):
    """为每个快照按 b 生成候选层数组。每层候选为 [按 a,c 行优先的计数向量,该层的中位数净分]，满足边际、禁止格和 ac 上限；按向量字典序。"""
    out = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)
        forbidden_set = set(tuple(t) for t in forbidden)
        layers = []
        for b in range(k):
            row_sums = [ab[a][b] for a in range(k)]
            col_sums = [bc[b][c] for c in range(k)]
            forced_zero = set()
            for a in range(k):
                for c in range(k):
                    if (a, b, c) in forbidden_set:
                        forced_zero.add((a, c))
            candidates = []
            for matrix in _enumerate_tables(row_sums, col_sums, k, forced_zero, ac):
                vec = [matrix[a][c] for a in range(k) for c in range(k)]
                score = 0
                for a in range(k):
                    for c in range(k):
                        score += matrix[a][c] * _cell_score(a, b, c, k)
                candidates.append([vec, score])
            candidates.sort(key=lambda x: x[0])
            layers.append(candidates)
        out.append(layers)
    return out
