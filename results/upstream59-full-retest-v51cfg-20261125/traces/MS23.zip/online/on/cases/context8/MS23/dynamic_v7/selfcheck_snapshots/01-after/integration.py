def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    snapshots = payload["snapshots"]
    out = []
    for i, snap in enumerate(snapshots):
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        k = len(ab)
        compatible, quota = left[i]
        layers = right[i]  # list per b of [vec, score]

        if not compatible:
            out.append(None)
            continue

        # Reconstruct candidate matrices per b as dicts of (a,c)->count.
        cand_per_b = []
        for b in range(k):
            cands = []
            for vec, score in layers[b]:
                mat = {}
                for a in range(k):
                    for c in range(k):
                        v = vec[a * k + c]
                        if v:
                            mat[(a, c)] = v
                cands.append((mat, score))
            cand_per_b.append(cands)

        # Enumerate all full tables via DFS over b, tracking remaining ac quota.
        quota_flat = list(quota)
        rem = [[0] * k for _ in range(k)]
        for a in range(k):
            for c in range(k):
                rem[a][c] = quota_flat[a * k + c]

        tables = []

        def dfs(b, rem, cur_score, cur_cells):
            if b == k:
                if all(rem[a][c] == 0 for a in range(k) for c in range(k)):
                    tables.append((cur_score, cur_cells))
                return
            for mat, score in cand_per_b[b]:
                ok = True
                for (a, c), v in mat.items():
                    if v > rem[a][c]:
                        ok = False
                        break
                if not ok:
                    continue
                new_rem = [row[:] for row in rem]
                for (a, c), v in mat.items():
                    new_rem[a][c] -= v
                new_cells = dict(cur_cells)
                for (a, c), v in mat.items():
                    new_cells[(a, b, c)] = new_cells.get((a, b, c), 0) + v
                dfs(b + 1, new_rem, cur_score + score, new_cells)

        dfs(0, rem, 0, {})

        if not tables:
            out.append(None)
            continue

        from collections import Counter
        score_counts = Counter(s for s, _ in tables)
        spectrum = [[s, score_counts[s]] for s in sorted(score_counts)]

        guaranteed = []
        all_cells = set()
        for _, cells in tables:
            all_cells.update(cells.keys())
        for (a, b, c) in sorted(all_cells):
            mn = min(cells.get((a, b, c), 0) for _, cells in tables)
            if mn > 0:
                guaranteed.append([a, b, c, mn])

        min_score = min(s for s, _ in tables)
        min_tables = [cells for s, cells in tables if s == min_score]

        def full_vec(cells):
            v = []
            for a in range(k):
                for b in range(k):
                    for c in range(k):
                        v.append(cells.get((a, b, c), 0))
            return v

        min_tables.sort(key=full_vec)
        witness_cells = min_tables[0]
        witness = []
        for a in range(k):
            for b in range(k):
                for c in range(k):
                    v = witness_cells.get((a, b, c), 0)
                    if v:
                        witness.append([a, b, c, v])

        out.append({
            "tables": len(tables),
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": witness,
        })
    return out
