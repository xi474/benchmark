import unittest

# Injected names provided by the visible-contract SDK runner.
# call_candidate(path, function, args=[...]) -> JSON value
# CandidateCallError -> exception with details dict
# check_api_boundary(...) -> raises on failure

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "ab[a][b]、bc[b][c]、ac[a][c] 均为非负整数人数。",
                "reason": "The public spec does not state that unknown fields or non-finite values must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "对每个输入快照，ab[a][b]、bc[b][c]、ac[a][c] 均为非负整数人数。",
                "reason": "The public spec does not state that a non-object payload must raise ValueError.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    """High-risk behavior checks derived from the public task contract."""

    def test_public_fixture_shape_and_values(self):
        # Independent expectation for the public input (k=2, all-ones margins).
        payload = {
            "snapshots": [
                {
                    "ab": [[1, 1], [1, 1]],
                    "bc": [[1, 1], [1, 1]],
                    "ac": [[1, 1], [1, 1]],
                    "forbidden": [],
                },
                {
                    "ab": [[1, 1], [1, 1]],
                    "bc": [[1, 1], [1, 1]],
                    "ac": [[1, 1], [1, 1]],
                    "forbidden": [[1, 0, 1]],
                },
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)
        first = result[0]
        self.assertIsInstance(first, dict)
        self.assertEqual(set(first.keys()), {"tables", "spectrum", "guaranteed", "witness"})
        self.assertEqual(first["tables"], 2)
        self.assertEqual(first["spectrum"], [[-2, 1], [2, 1]])
        self.assertEqual(first["guaranteed"], [])
        self.assertEqual(first["witness"], [[0, 0, 1, 1], [0, 1, 0, 1], [1, 0, 0, 1], [1, 1, 1, 1]])
        second = result[1]
        self.assertEqual(second["tables"], 1)
        self.assertEqual(second["spectrum"], [[-2, 1]])
        self.assertEqual(second["guaranteed"], [[0, 0, 1, 1], [0, 1, 0, 1], [1, 0, 0, 1], [1, 1, 1, 1]])
        self.assertEqual(second["witness"], [[0, 0, 1, 1], [0, 1, 0, 1], [1, 0, 0, 1], [1, 1, 1, 1]])

    def test_infeasible_snapshot_returns_null(self):
        # A snapshot whose ab and ac a-totals disagree has no compatible table.
        payload = {
            "snapshots": [
                {
                    "ab": [[2, 0], [0, 0]],
                    "bc": [[0, 0], [0, 0]],
                    "ac": [[0, 0], [0, 0]],
                    "forbidden": [],
                }
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [None])

    def test_single_customer_deterministic(self):
        # One customer with ratings a=0,b=0,c=0 -> median 0 -> net -1.
        payload = {
            "snapshots": [
                {
                    "ab": [[1, 0], [0, 0]],
                    "bc": [[1, 0], [0, 0]],
                    "ac": [[1, 0], [0, 0]],
                    "forbidden": [],
                }
            ]
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(len(result), 1)
        snap = result[0]
        self.assertEqual(snap["tables"], 1)
        self.assertEqual(snap["spectrum"], [[-1, 1]])
        self.assertEqual(snap["guaranteed"], [[0, 0, 0, 1]])
        self.assertEqual(snap["witness"], [[0, 0, 0, 1]])


if __name__ == "__main__":
    unittest.main()
