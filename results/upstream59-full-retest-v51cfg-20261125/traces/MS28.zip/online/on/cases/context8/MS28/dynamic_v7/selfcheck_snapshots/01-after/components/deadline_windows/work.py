def compute(payload):
    """为有截止日的作业返回 [需求,合格时段 ID 升序数组]，先按原始时段和七天半开窗口筛选。"""
    slots = payload["slots"]
    slot_day = {sid: day for sid, day, _cap in slots}
    result = {}
    for aid, due, demand, eligible in payload["assignments"]:
        if due is None:
            continue
        ok = [sid for sid in eligible if sid in slot_day and due - 7 <= slot_day[sid] < due]
        ok.sort()
        result[aid] = [demand, ok]
    return result
