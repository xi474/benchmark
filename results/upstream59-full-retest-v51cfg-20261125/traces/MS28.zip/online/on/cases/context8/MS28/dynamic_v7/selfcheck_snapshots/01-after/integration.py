from fractions import Fraction


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    assignments = payload["assignments"]
    withdrawals = payload["withdrawals"]

    deadline_assignments = [a for a in assignments if a[1] is not None]

    results = []
    for idx, withdrawn in enumerate(withdrawals):
        remaining = right[idx]

        effective = {}
        for aid, due, demand, eligible in deadline_assignments:
            ok = [sid for sid in left[aid][1] if sid in remaining]
            effective[aid] = ok

        unserved = sorted(aid for aid, due, demand, eligible in deadline_assignments
                          if not effective[aid])
        if unserved:
            results.append({"unserved": unserved})
            continue

        if not deadline_assignments:
            results.append({"empty": True})
            continue

        n = len(deadline_assignments)
        demands = [a[2] for a in deadline_assignments]
        eff_slots = [effective[a[0]] for a in deadline_assignments]
        cap = {sid: remaining[sid][1] for sid in remaining}

        best = None
        tight_masks = []
        for mask in range(1, 1 << n):
            total_demand = 0
            union_slots = set()
            for i in range(n):
                if mask & (1 << i):
                    total_demand += demands[i]
                    union_slots.update(eff_slots[i])
            total_cap = sum(cap[s] for s in union_slots)
            if total_cap == 0:
                continue
            ratio = Fraction(total_demand, total_cap)
            if best is None or ratio > best:
                best = ratio
                tight_masks = [mask]
            elif ratio == best:
                tight_masks.append(mask)

        peak = [best.numerator, best.denominator]
        count = len(tight_masks)

        minimal_masks = []
        for mask in tight_masks:
            is_minimal = True
            for other in tight_masks:
                if other != mask and (other & mask) == other:
                    is_minimal = False
                    break
            if is_minimal:
                minimal_masks.append(mask)

        minimal_lists = []
        for mask in minimal_masks:
            ids = sorted(deadline_assignments[i][0] for i in range(n) if mask & (1 << i))
            minimal_lists.append(ids)
        minimal_lists.sort(key=lambda x: (len(x), x))

        implies = []
        for i in sorted(range(n), key=lambda i: deadline_assignments[i][0]):
            aid = deadline_assignments[i][0]
            containing = [mask for mask in tight_masks if mask & (1 << i)]
            if not containing:
                continue
            common = containing[0]
            for m in containing[1:]:
                common &= m
            others = sorted(deadline_assignments[j][0] for j in range(n)
                            if j != i and (common & (1 << j)))
            implies.append([aid, others])

        results.append({
            "peak": peak,
            "count": count,
            "minimal": minimal_lists,
            "implies": implies,
        })

    return results
