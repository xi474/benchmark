import unittest


API_BOUNDARY_REQUIREMENTS = []


class TestTransformBehavior(unittest.TestCase):
    def test_empty_no_deadline_assignments(self):
        payload = {
            "assignments": [["A", None, 5, ["s1"]]],
            "slots": [["s1", 3, 10]],
            "withdrawals": [[]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [{"empty": True}])

    def test_unserved_when_no_effective_slot(self):
        payload = {
            "assignments": [["A", 10, 5, ["s1"]]],
            "slots": [["s1", 2, 10]],
            "withdrawals": [[]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result, [{"unserved": ["A"]}])

    def test_single_assignment_peak(self):
        payload = {
            "assignments": [["A", 10, 5, ["s1"]]],
            "slots": [["s1", 5, 10]],
            "withdrawals": [[]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result[0]["peak"], [1, 2])
        self.assertEqual(result[0]["count"], 1)
        self.assertEqual(result[0]["minimal"], [["A"]])
        self.assertEqual(result[0]["implies"], [["A", []]])

    def test_withdrawal_removes_slot(self):
        payload = {
            "assignments": [["A", 10, 5, ["s1"]]],
            "slots": [["s1", 5, 10]],
            "withdrawals": [[], ["s1"]],
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result[0]["peak"], [1, 2])
        self.assertEqual(result[1], {"unserved": ["A"]})


if __name__ == "__main__":
    unittest.main()
