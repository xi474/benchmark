from itertools import combinations


def compute(payload):
    """返回合格的三类菜品组合及合并需求，格式 [菜品 ID 数组,原料到数量映射]，按菜品字典序枚举。"""
    dishes = payload["dishes"]
    max_difficulty = payload.get("max_difficulty")

    # 仅候选难度 <= max_difficulty 的菜
    eligible = []
    for dish in dishes:
        dish_id, category, difficulty, ingredients = dish
        if max_difficulty is None or difficulty <= max_difficulty:
            eligible.append((dish_id, category, ingredients))

    results = []
    for combo in combinations(eligible, 3):
        ids = sorted(c[0] for c in combo)
        categories = [c[1] for c in combo]
        # 三道菜必须不同品类
        if len(set(categories)) != 3:
            continue
        merged = {}
        for _, _, ingredients in combo:
            for name, qty in ingredients.items():
                merged[name] = merged.get(name, 0) + qty
        results.append([ids, merged])

    # 按菜品字典序枚举（升序菜 ID 组成的三元列表的字典序）
    results.sort(key=lambda r: r[0])
    return results
