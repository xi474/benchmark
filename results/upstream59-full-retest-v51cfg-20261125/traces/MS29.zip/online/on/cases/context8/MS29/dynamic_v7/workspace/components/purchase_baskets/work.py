def compute(payload):
    """输出所有限量采购篮 [总价,总件数,按排序后 offer 的购买数量向量]；按这三项升序排列。"""
    offers = payload["offers"]
    # 按商品 ID 升序排序报价，购买数量向量按此顺序排列。
    sorted_offers = sorted(offers, key=lambda o: o[0])
    prices = [o[2] for o in sorted_offers]
    maxes = [o[3] for o in sorted_offers]

    baskets = []

    def rec(i, counts, cost, total):
        if i == len(sorted_offers):
            baskets.append([cost, total, list(counts)])
            return
        for c in range(maxes[i] + 1):
            counts.append(c)
            rec(i + 1, counts, cost + prices[i] * c, total + c)
            counts.pop()

    rec(0, [], 0, 0)
    baskets.sort(key=lambda b: (b[0], b[1], b[2]))
    return baskets
