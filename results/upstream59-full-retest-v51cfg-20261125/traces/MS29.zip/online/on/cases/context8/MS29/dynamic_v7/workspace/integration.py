def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    dishes = payload["dishes"]
    stock = payload.get("stock", {})
    offers = payload["offers"]
    prep = payload.get("prep", [])

    combos = left
    baskets = right

    sorted_offers = sorted(offers, key=lambda o: o[0])
    offer_contents = [o[1] for o in sorted_offers]

    prep_steps = prep

    results = []
    for dish_ids, requirement in combos:
        best = None
        for cost, count, buy in baskets:
            materials = dict(stock)
            for i, c in enumerate(buy):
                if c:
                    materials = _add(materials, {k: v * c for k, v in offer_contents[i].items()})

            plan = _solve_prep(materials, requirement, prep_steps)
            if plan is None:
                continue
            steps, left_over = plan
            candidate = {
                "cost": cost,
                "buy": buy,
                "steps": steps,
                "left": left_over,
            }
            if best is None or _better(candidate, best):
                best = candidate
        if best is None:
            results.append({"dishes": dish_ids, "plan": None})
        else:
            results.append({"dishes": dish_ids, "plan": best})

    return results


def _add(a, b):
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, 0) + v
    return out


def _sub(a, b):
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, 0) - v
    return out


def _ge(a, b):
    return all(a.get(k, 0) >= v for k, v in b.items())


def _positive(d):
    return {k: v for k, v in d.items() if v > 0}


def _better(a, b):
    if a["cost"] != b["cost"]:
        return a["cost"] < b["cost"]
    if sum(a["buy"]) != sum(b["buy"]):
        return sum(a["buy"]) < sum(b["buy"])
    if a["buy"] != b["buy"]:
        return a["buy"] < b["buy"]
    if len(a["steps"]) != len(b["steps"]):
        return len(a["steps"]) < len(b["steps"])
    return a["steps"] < b["steps"]


def _solve_prep(materials, requirement, prep_steps):
    """Find a feasible prep sequence minimizing step count then step-id lexicographic order.

    Returns (steps, left_over) or None. Uses BFS over material states; the first
    solution found at each depth is the lexicographically smallest step sequence
    because prep steps are iterated in input order and BFS explores by depth.
    """
    from collections import deque

    def freeze(d):
        return tuple(sorted((k, v) for k, v in d.items() if v > 0))

    start = freeze(materials)
    if _ge(materials, requirement):
        return ([], _positive(_sub(materials, requirement)))

    queue = deque([(start, [])])
    seen = {start}
    max_steps = 16

    while queue:
        state, steps = queue.popleft()
        if len(steps) >= max_steps:
            continue
        cur = dict(state)
        for pid, consume, produce, maxn in prep_steps:
            if _ge(cur, consume):
                new = _sub(cur, consume)
                new = _add(new, produce)
                new_steps = steps + [pid]
                if _ge(new, requirement):
                    left = _positive(_sub(new, requirement))
                    return (new_steps, left)
                fs = freeze(new)
                if fs not in seen:
                    seen.add(fs)
                    queue.append((fs, new_steps))
    return None
