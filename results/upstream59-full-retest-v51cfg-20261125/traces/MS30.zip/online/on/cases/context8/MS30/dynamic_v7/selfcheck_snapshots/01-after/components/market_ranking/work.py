def compute(payload):
    """按最新市场日的 30 天窗口、相对绝对涨跌幅和代号打破平局，返回前 top 个房间代号（保持排名）。"""
    market = payload["market"]
    top = payload["top"]

    # 以全体行情的最后教学日 L 为锚点，仅保留 L-29 到 L（含）的事件。
    last_day = max(row[1] for row in market)
    window = [row for row in market if last_day - 29 <= row[1] <= last_day]

    # 按 abs(收盘-开盘)/开盘 降序、事件 ID 升序排序。
    def key(row):
        event_id, _day, open_price, close_price = row
        change = abs(close_price - open_price) / open_price
        return (-change, event_id)

    window.sort(key=key)
    return [row[0] for row in window[:top]]
