def _flat_tiers(tiers_list):
    return {t for group in tiers_list for t in group}


def combine(payload, left, right):
    """left = student->tier map, right = ranked room ids (top rooms)."""
    tiers = left
    ranked = right

    rooms = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]

    students = sorted(tiers.keys())

    results = []
    for cancel in cancel_list:
        closed = set(cancel)
        open_rooms = [r for r in ranked if r not in closed]

        student_accept = {}
        student_rank = {}
        for s in students:
            acc = []
            rank = {}
            for gi, group in enumerate(prefs.get(s, [])):
                for r in group:
                    if r in closed or r not in rooms:
                        continue
                    if r not in open_rooms:
                        continue
                    if tiers[s] not in _flat_tiers(rooms[r]["tiers"]):
                        continue
                    acc.append(r)
                    rank[r] = gi
            student_accept[s] = acc
            student_rank[s] = rank

        room_accept = {}
        room_rank = {}
        for r in open_rooms:
            if r not in rooms:
                continue
            tiers_list = rooms[r]["tiers"]
            acc = []
            rank = {}
            for gi, group in enumerate(tiers_list):
                for t in group:
                    for s in students:
                        if tiers[s] == t and s not in rank:
                            rank[s] = gi
                            acc.append(s)
            room_accept[r] = acc
            room_rank[r] = rank

        matchings = enumerate_stable(students, open_rooms, student_accept,
                                     student_rank, room_accept, room_rank,
                                     rooms)

        size_counts = {}
        for m in matchings:
            cnt = sum(1 for v in m.values() if v != "")
            size_counts[cnt] = size_counts.get(cnt, 0) + 1
        sizes = [[c, size_counts[c]] for c in sorted(size_counts)]

        max_cnt = max(size_counts) if size_counts else 0
        max_matchings = [m for m in matchings
                         if sum(1 for v in m.values() if v != "") == max_cnt]

        forced = []
        for s in students:
            rooms_assigned = set(m[s] for m in max_matchings if m[s] != "")
            if len(rooms_assigned) == 1:
                forced.append([s, next(iter(rooms_assigned))])
        forced.sort()
        # A pair is forced only if the student is assigned in EVERY max matching.
        forced = [[s, r] for s, r in forced
                  if all(m[s] == r for m in max_matchings)]

        # example: lexicographically smallest vector over max matchings.
        vectors = sorted([m[s] for s in students] for m in max_matchings)
        example = vectors[0] if vectors else ["" for _ in students]

        results.append({
            "sizes": sizes,
            "forced": forced,
            "example": example,
        })

    return results


def enumerate_stable(students, open_rooms, student_accept, student_rank,
                     room_accept, room_rank, rooms):
    matchings = []
    n = len(students)
    assignment = {s: "" for s in students}
    room_load = {r: 0 for r in rooms}

    def is_stable():
        for s in students:
            cur = assignment[s]
            cur_rank = student_rank[s].get(cur, 10**9) if cur else 10**9
            for w in student_accept[s]:
                wr = student_rank[s][w]
                if wr >= cur_rank:
                    continue
                cap = rooms[w]["capacity"]
                if cap <= 0:
                    continue
                if room_load[w] < cap:
                    return False
                s_rank = room_rank.get(w, {}).get(s, 10**9)
                for t in room_accept.get(w, []):
                    if assignment[t] == w and room_rank[w][t] > s_rank:
                        return False
        return True

    def backtrack(i):
        if i == n:
            if is_stable():
                matchings.append(dict(assignment))
            return
        s = students[i]
        backtrack(i + 1)
        for w in student_accept[s]:
            if room_load[w] < rooms[w]["capacity"]:
                assignment[s] = w
                room_load[w] += 1
                backtrack(i + 1)
                room_load[w] -= 1
                assignment[s] = ""

    backtrack(0)
    return matchings
