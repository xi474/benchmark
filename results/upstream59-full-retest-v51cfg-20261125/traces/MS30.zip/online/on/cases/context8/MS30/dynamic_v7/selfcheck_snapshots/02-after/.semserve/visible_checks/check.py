import unittest

# call_candidate, CandidateCallError, check_api_boundary are injected by Runtime.


class StudentTiersTests(unittest.TestCase):
    def test_tier_thresholds(self):
        # Public rule: ratio <0.60 -> N, <0.75 -> D, else P; equal-weight average.
        payload = {"grades": [
            ["A", 16, 5, 10], ["A", 17, 10, 16],   # 0.5, 0.625 -> avg 0.5625 -> N
            ["B", 16, 7, 10], ["B", 17, 8, 16],    # 0.7, 0.5 -> avg 0.6 -> D
            ["C", 16, 8, 10], ["C", 17, 12, 16],   # 0.8, 0.75 -> avg 0.775 -> P
        ]}
        expected = {"A": "N", "B": "D", "C": "P"}
        result = call_candidate("components/student_tiers/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, expected)

    def test_null_grade_ignored(self):
        # Null score must be excluded; only non-null grades count.
        payload = {"grades": [
            ["A", 16, None, 10],
            ["A", 17, 10, 16],   # only 0.625 -> D
        ]}
        result = call_candidate("components/student_tiers/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, {"A": "D"})

    def test_other_courses_ignored(self):
        # Only courses 16 and 17 are considered.
        payload = {"grades": [
            ["A", 15, 10, 10],
            ["A", 16, 10, 10],   # 1.0 -> P
        ]}
        result = call_candidate("components/student_tiers/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, {"A": "P"})


class MarketRankingTests(unittest.TestCase):
    def test_window_and_ranking(self):
        # 30-day window anchored at last day; sort by abs change desc, id asc.
        payload = {
            "market": [
                ["A", 100, 100, 120],  # 0.2
                ["B", 71, 100, 80],    # 0.2 (day 71 outside window if L=100)
                ["C", 90, 100, 120],   # 0.2
                ["D", 100, 100, 80],   # 0.2
            ],
            "top": 3,
        }
        # L=100, window days 71..100. B at day 71 is included (L-29=71).
        # All changes 0.2; tie broken by id ascending: A, B, C.
        result = call_candidate("components/market_ranking/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, ["A", "B", "C"])

    def test_window_excludes_old(self):
        payload = {
            "market": [
                ["A", 100, 100, 120],  # 0.2
                ["B", 70, 100, 80],    # 0.2, day 70 < L-29=71 -> excluded
                ["C", 90, 100, 120],   # 0.2
            ],
            "top": 3,
        }
        result = call_candidate("components/market_ranking/work.py", "compute",
                                args=[payload])
        self.assertEqual(result, ["A", "C"])


class IntegrationTests(unittest.TestCase):
    def test_combine_empty_cancel(self):
        # Full public scenario 0: no cancel -> 4 assigned, 12 matchings.
        payload = {
            "rooms": {
                "J": {"capacity": 1, "tiers": [["P"], ["D", "N"]]},
                "K": {"capacity": 2, "tiers": [["N", "D"], ["P"]]},
                "L": {"capacity": 1, "tiers": [["P"], ["D", "N"]]},
            },
            "prefs": {
                "A": [["J"], ["L", "K"]],
                "B": [["J", "L"], ["K"]],
                "C": [["J", "K"], ["L"]],
                "D": [["L"], ["K", "J"]],
            },
            "cancel": [[]],
        }
        left = {"A": "N", "B": "N", "C": "D", "D": "D"}
        right = ["J", "K", "L"]
        result = call_candidate("integration.py", "combine",
                                args=[payload, left, right])
        self.assertEqual(result[0]["sizes"], [[4, 12]])
        self.assertEqual(result[0]["forced"], [])
        self.assertEqual(result[0]["example"], ["J", "K", "K", "L"])


if __name__ == "__main__":
    unittest.main()
