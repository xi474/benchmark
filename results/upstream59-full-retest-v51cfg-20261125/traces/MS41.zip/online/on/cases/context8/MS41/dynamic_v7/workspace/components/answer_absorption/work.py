from collections import deque
from fractions import Fraction


def _invert(matrix):
    """Invert a square matrix of Fractions via Gauss-Jordan elimination."""
    n = len(matrix)
    if n == 0:
        return []
    aug = [
        [matrix[i][j] for j in range(n)]
        + [Fraction(1) if i == j else Fraction(0) for j in range(n)]
        for i in range(n)
    ]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if aug[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            raise ValueError("singular matrix")
        if pivot != col:
            aug[col], aug[pivot] = aug[pivot], aug[col]
        pv = aug[col][col]
        for j in range(col, 2 * n):
            aug[col][j] /= pv
        for r in range(n):
            if r != col and aug[r][col] != 0:
                factor = aug[r][col]
                for j in range(col, 2 * n):
                    aug[r][j] -= factor * aug[col][j]
    return [row[n:] for row in aug]


def _frac_pair(value):
    if value == 0:
        return [0, 1]
    return [value.numerator, value.denominator]


def _solve_graph(graph, answers, start):
    answer_set = set(answers)
    a_index = {a: i for i, a in enumerate(answers)}
    m = len(answers)

    states = list(graph.keys())
    n = len(states)
    index = {s: i for i, s in enumerate(states)}

    # Determine which non-terminal states can reach a terminal (answer).
    can_reach = [False] * n
    rev = [[] for _ in range(n)]
    for s in states:
        si = index[s]
        for target, _w, _c in graph[s]:
            if target in answer_set:
                can_reach[si] = True
            elif target in index:
                rev[index[target]].append(si)

    dq = deque(i for i in range(n) if can_reach[i])
    while dq:
        u = dq.popleft()
        for v in rev[u]:
            if not can_reach[v]:
                can_reach[v] = True
                dq.append(v)

    transient = [i for i in range(n) if can_reach[i]]
    t_index = {orig: new for new, orig in enumerate(transient)}
    nt = len(transient)

    start_i = index.get(start)
    if start_i is None or not can_reach[start_i]:
        return (
            [[0, 1] for _ in range(m)],
            [[0, 1] for _ in range(m)],
        )

    # Build Q (transient -> transient) and R (transient -> answers).
    Q = [[Fraction(0) for _ in range(nt)] for _ in range(nt)]
    R = [[Fraction(0) for _ in range(m)] for _ in range(nt)]
    for si in transient:
        s = states[si]
        total_w = sum(w for _t, w, _c in graph[s])
        for target, w, _c in graph[s]:
            prob = Fraction(w, total_w)
            if target in answer_set:
                R[t_index[si]][a_index[target]] += prob
            elif target in index and can_reach[index[target]]:
                Q[t_index[si]][t_index[index[target]]] += prob
            # target in a closed (recurrent) class: contributes nothing.

    # Fundamental matrix N = (I - Q)^-1.
    I_minus_Q = [
        [(Fraction(1) if i == j else Fraction(0)) - Q[i][j] for j in range(nt)]
        for i in range(nt)
    ]
    N = _invert(I_minus_Q)

    # Absorption probabilities p = N * R.
    p = [[Fraction(0) for _ in range(m)] for _ in range(nt)]
    for i in range(nt):
        for a in range(m):
            acc = Fraction(0)
            for k in range(nt):
                acc += N[i][k] * R[k][a]
            p[i][a] = acc

    # One-step cost mass attributed to each answer.
    d = [[Fraction(0) for _ in range(m)] for _ in range(nt)]
    for si in transient:
        s = states[si]
        total_w = sum(w for _t, w, _c in graph[s])
        for target, w, c in graph[s]:
            prob = Fraction(w, total_w)
            cost = Fraction(c)
            if target in answer_set:
                d[t_index[si]][a_index[target]] += prob * cost
            elif target in index and can_reach[index[target]]:
                ti = t_index[index[target]]
                for a in range(m):
                    d[t_index[si]][a] += prob * cost * p[ti][a]

    # Cost mass q = N * d.
    q = [[Fraction(0) for _ in range(m)] for _ in range(nt)]
    for i in range(nt):
        for a in range(m):
            acc = Fraction(0)
            for k in range(nt):
                acc += N[i][k] * d[k][a]
            q[i][a] = acc

    ti = t_index[start_i]
    abs_probs = [_frac_pair(p[ti][a]) for a in range(m)]
    cost_quality = [_frac_pair(q[ti][a]) for a in range(m)]
    return abs_probs, cost_quality


def compute(payload):
    """按 method ID、profile 名输出 [各答案吸收概率,各答案加权成本质量]；向量元素均为约分的 [分子,分母]，保留 answers 顺序。"""
    methods = payload["methods"]
    answers = payload["answers"]

    result = {}
    for method in methods:
        mid = method["id"]
        start = method["start"]
        graphs = method["graphs"]
        method_result = {}
        for version, graph in graphs.items():
            abs_probs, cost_quality = _solve_graph(graph, answers, start)
            method_result[version] = [abs_probs, cost_quality]
        result[mid] = method_result
    return result
