import math


def _reduce(num, den):
    if num == 0:
        return [0, 1]
    g = math.gcd(num, den)
    return [num // g, den // g]


def compute(payload):
    """输出 [先验映射,方法提前决胜表]。先验为最简分数。每种方法列出从零票起可达的计数状态（键为逗号分隔的答案票数）；值是已经胜出的答案下标或 null。决胜后不扩展。"""
    answers = payload["answers"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    n = len(answers)

    total_weight = sum(profiles.values())
    prior = {name: _reduce(w, total_weight) for name, w in profiles.items()}

    table = {}
    for m in methods:
        votes = m["votes"]
        states = {}
        start = tuple([0] * n)
        stack = [start]
        visited = set()
        while stack:
            state = stack.pop()
            if state in visited:
                continue
            visited.add(state)
            total = sum(state)

            leader = 0
            for i in range(1, n):
                if state[i] > state[leader]:
                    leader = i

            remaining = votes - total
            decided = True
            for j in range(n):
                if j == leader:
                    continue
                cj = state[j] + remaining
                if state[leader] > cj:
                    continue
                if state[leader] == cj and leader < j:
                    continue
                decided = False
                break

            key = ",".join(str(x) for x in state)
            if decided:
                states[key] = leader
            else:
                states[key] = None
                if total < votes:
                    for i in range(n):
                        child = list(state)
                        child[i] += 1
                        stack.append(tuple(child))
        table[m["id"]] = states

    return [prior, table]
