from fractions import Fraction


def _reduce(num, den):
    if num == 0:
        return [0, 1]
    g = _gcd(num, den)
    return [num // g, den // g]


def _gcd(a, b):
    while b:
        a, b = b, a % b
    return abs(a)


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    answers = payload["answers"]
    correct = payload["correct"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    n = len(answers)

    prior, decision_table = left
    absorption = right

    total_weight = sum(profiles.values())
    profile_frac = {name: Fraction(w, total_weight) for name, w in profiles.items()}

    results = []
    for m in methods:
        mid = m["id"]
        votes = m["votes"]
        table = decision_table[mid]
        abs_map = absorption[mid]

        states = {}
        for key, val in table.items():
            counts = tuple(int(x) for x in key.split(","))
            states[counts] = val

        ordered = sorted(states.keys(), key=lambda s: -sum(s))

        win_prob = {}
        unresolved = {}
        launches = {}
        cost_mass = {}

        for state in ordered:
            total = sum(state)
            decision = states[state]
            if decision is not None:
                wp = [Fraction(0)] * n
                wp[decision] = Fraction(1)
                win_prob[state] = wp
                unresolved[state] = Fraction(0)
                launches[state] = Fraction(0)
                cost_mass[state] = [Fraction(0)] * n
                continue

            if total == votes:
                leader = 0
                for i in range(1, n):
                    if state[i] > state[leader]:
                        leader = i
                wp = [Fraction(0)] * n
                wp[leader] = Fraction(1)
                win_prob[state] = wp
                unresolved[state] = Fraction(0)
                launches[state] = Fraction(0)
                cost_mass[state] = [Fraction(0)] * n
                continue

            wp = [Fraction(0)] * n
            unres = Fraction(0)
            launch = Fraction(1)
            cm = [Fraction(0)] * n

            for pname, wfrac in profile_frac.items():
                abs_probs, cost_quality = abs_map[pname]
                p_abs = [Fraction(a[0], a[1]) for a in abs_probs]
                cq = [Fraction(c[0], c[1]) for c in cost_quality]
                p_unres = Fraction(1) - sum(p_abs)

                for a in range(n):
                    if p_abs[a] == 0:
                        continue
                    child = list(state)
                    child[a] += 1
                    child = tuple(child)
                    wp_a = win_prob[child]
                    unres_a = unresolved[child]
                    launch_a = launches[child]
                    cm_a = cost_mass[child]

                    for b in range(n):
                        wp[b] += wfrac * p_abs[a] * wp_a[b]
                    unres += wfrac * p_abs[a] * unres_a
                    launch += wfrac * p_abs[a] * launch_a
                    for b in range(n):
                        cm[b] += wfrac * (p_abs[a] * cm_a[b] + cq[a] * wp_a[b])

                unres += wfrac * p_unres

            win_prob[state] = wp
            unresolved[state] = unres
            launches[state] = launch
            cost_mass[state] = cm

        start = tuple([0] * n)
        wp = win_prob[start]
        unres = unresolved[start]
        launch = launches[start]
        cm = cost_mass[start]

        prob = [_reduce(wp[a].numerator, wp[a].denominator) for a in range(n)]
        unresolved_out = _reduce(unres.numerator, unres.denominator)
        launches_out = _reduce(launch.numerator, launch.denominator)

        correct_idx = answers.index(correct)
        p_correct = wp[correct_idx]
        if p_correct == 0:
            cost_if_correct = None
        else:
            num = cm[correct_idx]
            cost_if_correct = _reduce(num.numerator, num.denominator)

        results.append({
            "id": mid,
            "prob": prob,
            "unresolved": unresolved_out,
            "launches": launches_out,
            "cost_if_correct": cost_if_correct,
        })

    def correct_prob_key(r):
        idx = answers.index(correct)
        p = r["prob"][idx]
        return Fraction(p[0], p[1])

    results.sort(key=lambda r: (-correct_prob_key(r), r["id"]))

    return results
