def compute(payload):
    """为每门课生成 [项目统计,传递可达表]；统计行 [ID,标签,[成绩和分子,分母],非空数] 按 ID 排序，保留零成绩。可达表的值为有序 ID 数组。"""
    courses = payload["courses"]
    result = {}
    for code, course in courses.items():
        items = course["items"]
        edges = course.get("edges", [])

        # Item stats: [ID, label, [sum_numerator, denominator], non_null_count]
        stats = []
        for item in items:
            item_id, label, scores = item[0], item[1], item[2]
            numerator = 0
            denominator = 0
            non_null = 0
            for s in scores:
                if s is not None:
                    numerator += s
                    denominator += 1
                    non_null += 1
            stats.append([item_id, label, [numerator, denominator], non_null])
        stats.sort(key=lambda row: row[0])

        # Transitive reachability over the full graph.
        ids = [item[0] for item in items]
        id_set = set(ids)
        adj = {i: set() for i in ids}
        for a, b in edges:
            if a in id_set and b in id_set:
                adj[a].add(b)

        reach = {i: set() for i in ids}
        for start in ids:
            stack = list(adj[start])
            seen = set()
            while stack:
                node = stack.pop()
                if node in seen:
                    continue
                seen.add(node)
                reach[start].add(node)
                for nxt in adj[node]:
                    if nxt not in seen:
                        stack.append(nxt)

        reach_table = {i: sorted(reach[i]) for i in ids}
        result[code] = [stats, reach_table]
    return result
