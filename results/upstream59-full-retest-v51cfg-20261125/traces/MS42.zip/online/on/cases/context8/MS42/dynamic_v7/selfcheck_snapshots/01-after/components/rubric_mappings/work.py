from itertools import permutations


def compute(payload):
    """返回 [所有可行映射位掩码,旧标签到各新标签的掩码映射]；位序按新标签升序的排列枚举。"""
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    new_labels = sorted({nl for lst in rubrics.values() for nl in lst})
    allowed = {ol: set(rubrics[ol]) for ol in old_labels}

    total_mask = 0
    per_old = {ol: {nl: 0 for nl in new_labels} for ol in old_labels}

    # 枚举新标签的全部排列（升序），每个排列把 old_labels[i] 映到 perm[i]。
    for rank, perm in enumerate(permutations(new_labels), start=1):
        if not all(perm[i] in allowed[old_labels[i]] for i in range(len(old_labels))):
            continue
        bit = 1 << (rank - 1)
        total_mask |= bit
        for i, ol in enumerate(old_labels):
            per_old[ol][perm[i]] |= bit

    return [total_mask, per_old]
