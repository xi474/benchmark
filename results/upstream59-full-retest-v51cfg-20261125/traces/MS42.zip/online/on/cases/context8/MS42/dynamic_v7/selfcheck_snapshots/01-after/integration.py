from fractions import Fraction


def _gcd(a, b):
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a


def _simplify(num, den):
    if den < 0:
        num, den = -num, -den
    g = _gcd(num, den)
    return [num // g, den // g]


def combine(payload, left, right):
    # left: [total_mask, per_old]  from rubric_mappings
    # right: {course_code: [stats, reach_table]}  from course_evidence
    total_mask, per_old = left
    courses = right

    # Group courses by prefix (code before -2013J / -2014J).
    prefixes = {}
    for code in courses:
        if code.endswith("-2013J"):
            prefixes.setdefault(code[:-len("-2013J")], {})["old"] = code
        elif code.endswith("-2014J"):
            prefixes.setdefault(code[:-len("-2014J")], {})["new"] = code

    # For each prefix with both terms, build candidate pairs.
    all_pairs = []  # (prefix, oid, nid, olab, nlab, support)
    for prefix, terms in prefixes.items():
        if "old" not in terms or "new" not in terms:
            continue
        old_code = terms["old"]
        new_code = terms["new"]
        old_stats, _ = courses[old_code]
        new_stats, _ = courses[new_code]

        old_items = {row[0]: row for row in old_stats}
        new_items = {row[0]: row for row in new_stats}

        old_eligible = {iid: row for iid, row in old_items.items() if row[3] > 0}
        new_eligible = {iid: row for iid, row in new_items.items() if row[3] > 0}

        for oid, orow in old_eligible.items():
            for nid, nrow in new_eligible.items():
                support = min(orow[3], nrow[3])
                all_pairs.append((prefix, oid, nid, orow[1], nrow[1], support))

    prefix_info = {}
    for prefix, terms in prefixes.items():
        if "old" not in terms or "new" not in terms:
            continue
        old_code = terms["old"]
        new_code = terms["new"]
        _, old_reach = courses[old_code]
        _, new_reach = courses[new_code]
        prefix_info[prefix] = (old_reach, new_reach)

    # Reconstruct feasible dictionaries from bitmasks.
    old_labels = sorted(per_old.keys())
    new_labels = sorted({nl for m in per_old.values() for nl in m})

    dicts = []
    bit = 1
    while bit <= total_mask:
        if total_mask & bit:
            mapping = {}
            for ol in old_labels:
                for nl in new_labels:
                    if per_old[ol][nl] & bit:
                        mapping[ol] = nl
                        break
            dicts.append(mapping)
        bit <<= 1

    best_pair_sets = set()
    best_pairs = -1
    best_support = -1

    for mapping in dicts:
        prefix_pairs = {}
        for (prefix, oid, nid, olab, nlab, support) in all_pairs:
            if mapping.get(olab) == nlab:
                prefix_pairs.setdefault(prefix, []).append((oid, nid, support))

        chosen = []
        for prefix, pairs in prefix_pairs.items():
            old_reach, new_reach = prefix_info[prefix]
            best_sub = None
            best_sub_pairs = -1
            best_sub_support = -1
            n = len(pairs)
            for mask in range(1 << n):
                used_old = set()
                used_new = set()
                sub = []
                ok = True
                for i in range(n):
                    if mask & (1 << i):
                        oid, nid, sup = pairs[i]
                        if oid in used_old or nid in used_new:
                            ok = False
                            break
                        used_old.add(oid)
                        used_new.add(nid)
                        sub.append((oid, nid, sup))
                if not ok:
                    continue
                if not _order_consistent(sub, old_reach, new_reach):
                    continue
                npairs = len(sub)
                nsup = sum(s for _, _, s in sub)
                if npairs > best_sub_pairs or (npairs == best_sub_pairs and nsup > best_sub_support):
                    best_sub_pairs = npairs
                    best_sub_support = nsup
                    best_sub = sub
            if best_sub is not None:
                chosen.append((prefix, best_sub, best_sub_pairs, best_sub_support))

        total_pairs = sum(c[2] for c in chosen)
        total_support = sum(c[3] for c in chosen)

        if total_pairs > best_pairs or (total_pairs == best_pairs and total_support > best_support):
            best_pairs = total_pairs
            best_support = total_support
            best_pair_sets = set()

        if total_pairs == best_pairs and total_support == best_support:
            pair_set = frozenset(
                (prefix, oid, nid)
                for prefix, sub, _, _ in chosen
                for oid, nid, _ in sub
            )
            best_pair_sets.add(pair_set)

    pairs = best_pairs
    support = best_support
    ways = len(best_pair_sets)

    if best_pair_sets:
        common = set.intersection(*[set(s) for s in best_pair_sets])
    else:
        common = set()
    forced = sorted(common)

    if pairs == 0:
        drift = None
    else:
        drifts = []
        for pair_set in best_pair_sets:
            old_num = 0
            old_den = 0
            new_num = 0
            new_den = 0
            for (prefix, oid, nid) in pair_set:
                old_code = prefixes[prefix]["old"]
                new_code = prefixes[prefix]["new"]
                old_stats, _ = courses[old_code]
                new_stats, _ = courses[new_code]
                old_row = next(r for r in old_stats if r[0] == oid)
                new_row = next(r for r in new_stats if r[0] == nid)
                old_num += old_row[2][0]
                old_den += old_row[2][1]
                new_num += new_row[2][0]
                new_den += new_row[2][1]
            d = Fraction(new_num, new_den) - Fraction(old_num, old_den)
            drifts.append(d)
        dmin = min(drifts)
        dmax = max(drifts)
        drift = [_simplify(dmin.numerator, dmin.denominator),
                 _simplify(dmax.numerator, dmax.denominator)]

    return {
        "pairs": pairs,
        "support": support,
        "ways": ways,
        "forced": forced,
        "drift": drift,
    }


def _order_consistent(sub, old_reach, new_reach):
    for i in range(len(sub)):
        for j in range(i + 1, len(sub)):
            o1, n1, _ = sub[i]
            o2, n2, _ = sub[j]
            if _rel(o1, o2, old_reach) != _rel(n1, n2, new_reach):
                return False
    return True


def _rel(a, b, reach):
    if b in reach.get(a, []):
        return -1
    if a in reach.get(b, []):
        return 1
    return 0
