import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "solution.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform rejects non-finite or unknown fields.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "TASK.md",
                "requirement_quote": "实现 solution.py 中的 transform(payload)，返回题面指定的 JSON 值并保持输入值完整。",
                "reason": "The public spec does not state that transform raises ValueError on a non-object payload.",
            },
        },
    },
]


class TestTransformBehavior(unittest.TestCase):
    def test_public_fixture_output(self):
        payload = {
            "rubrics": {"a": ["X", "Y"], "b": ["Y", "X"]},
            "courses": {
                "ENG-2013J": {"items": [["p", "a", [30]], ["q", "b", [80, None]]], "edges": []},
                "ENG-2014J": {"items": [["r", "X", [70]], ["s", "Y", [40]]], "edges": []},
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["pairs"], 2)
        self.assertEqual(result["support"], 2)
        self.assertEqual(result["ways"], 2)
        self.assertEqual(result["forced"], [])
        self.assertEqual(result["drift"], [[0, 1], [0, 1]])

    def test_empty_alignment_drift_null(self):
        payload = {
            "rubrics": {"a": ["X"]},
            "courses": {
                "M-2013J": {"items": [["p", "a", [None]]], "edges": []},
                "M-2014J": {"items": [["q", "X", [None]]], "edges": []},
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["pairs"], 0)
        self.assertIsNone(result["drift"])

    def test_drift_hand_calculation(self):
        payload = {
            "rubrics": {"a": ["X"]},
            "courses": {
                "M-2013J": {"items": [["p", "a", [30]]], "edges": []},
                "M-2014J": {"items": [["q", "X", [70]]], "edges": []},
            },
        }
        result = call_candidate("solution.py", "transform", args=[payload])
        self.assertEqual(result["pairs"], 1)
        self.assertEqual(result["support"], 1)
        self.assertEqual(result["drift"], [[40, 1], [40, 1]])


if __name__ == "__main__":
    unittest.main()
