"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def _dense(block):
    """Return a dense integer matrix for a block (zero blocks become zeros)."""
    rows = block["rows"]
    cols = block["cols"]
    data = block["data"]
    if data is None:
        return [[0] * cols for _ in range(rows)]
    return [list(row) for row in data]


def _matmul(a, b):
    """Multiply two dense integer matrices."""
    ra = len(a)
    ca = len(a[0]) if ra else 0
    cb = len(b[0]) if ra else 0
    result = [[0] * cb for _ in range(ra)]
    for i in range(ra):
        for k in range(ca):
            aik = a[i][k]
            if aik == 0:
                continue
            brow = b[k]
            for j in range(cb):
                result[i][j] += aik * brow[j]
    return result


def _is_zero(mat):
    return all(all(v == 0 for v in row) for row in mat)


def _block_from_dense(mat, rows, cols):
    if _is_zero(mat):
        return {"rows": rows, "cols": cols, "data": None}
    return {"rows": rows, "cols": cols, "data": mat}


def transform(payload, contract):
    squared = payload["squared"]
    matrix = payload["matrix"]
    layout = payload["layout"]

    row_sizes = layout["row_sizes"]
    col_sizes = layout["col_sizes"]

    sq_blocks = squared["blocks"] if isinstance(squared, dict) else squared

    n = len(matrix)
    m = len(matrix[0]) if n else 0

    total_rows = sum(row_sizes)
    total_cols = sum(col_sizes)

    # Assemble dense B^2
    b2 = [[0] * total_cols for _ in range(total_rows)]
    row_off = 0
    for i in range(n):
        col_off = 0
        for j in range(m):
            dense = _dense(sq_blocks[i][j])
            for r in range(len(dense)):
                for c in range(len(dense[0])):
                    b2[row_off + r][col_off + c] = dense[r][c]
            col_off += col_sizes[j]
        row_off += row_sizes[i]

    # Assemble dense B
    b = [[0] * total_cols for _ in range(total_rows)]
    row_off = 0
    for i in range(n):
        col_off = 0
        for j in range(m):
            dense = _dense(matrix[i][j])
            for r in range(len(dense)):
                for c in range(len(dense[0])):
                    b[row_off + r][col_off + c] = dense[r][c]
            col_off += col_sizes[j]
        row_off += row_sizes[i]

    # B^3 = B^2 * B
    b3 = _matmul(b2, b)

    # Re-block B^3 into the same block structure.
    blocks = []
    row_off = 0
    for i in range(n):
        row = []
        col_off = 0
        for j in range(m):
            rows = row_sizes[i]
            cols = col_sizes[j]
            sub = [b3[row_off + r][col_off:col_off + cols] for r in range(rows)]
            row.append(_block_from_dense(sub, rows, cols))
            col_off += cols
        blocks.append(row)
        row_off += row_sizes[i]

    return {"layout": layout, "blocks": blocks}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
