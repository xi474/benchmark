"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def _block_data(block):
    data = block["data"]
    if data is None:
        return [[0] * block["cols"] for _ in range(block["rows"])]
    return data


def _matmul(a, b):
    rows = len(a)
    cols = len(b[0]) if b else 0
    inner = len(b)
    out = [[0] * cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            s = 0
            for k in range(inner):
                s += a[i][k] * b[k][j]
            out[i][j] = s
    return out


def _is_zero(data):
    return all(v == 0 for row in data for v in row)


def transform(payload, contract):
    matrix = payload["matrix"]
    n = len(matrix)
    blocks = []
    for i in range(n):
        row = []
        for j in range(n):
            rows = matrix[i][0]["rows"]
            cols = matrix[0][j]["cols"]
            acc = None
            for k in range(n):
                a = _block_data(matrix[i][k])
                b = _block_data(matrix[k][j])
                prod = _matmul(a, b)
                if acc is None:
                    acc = prod
                else:
                    for r in range(rows):
                        for c in range(cols):
                            acc[r][c] += prod[r][c]
            if _is_zero(acc):
                row.append({"rows": rows, "cols": cols, "data": None})
            else:
                row.append({"rows": rows, "cols": cols, "data": acc})
        blocks.append(row)
    return blocks

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
