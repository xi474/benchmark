"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import read, build, module


def main():
    root = Path(__file__).resolve().parent

    contracts = {}
    for name in ("block_layout", "squared", "cubed"):
        contracts[name] = read(root / "engines" / name / "contract.json")

    results = {}
    for name in ("block_layout", "squared", "cubed"):
        eng = module(root, f"engines/{name}/engine.py")
        results[name] = eng.build_component(root, contracts[name])

    result_file = read(root / "delivery.json")["result_file"]
    report = {
        "task": "N11",
        "results": results,
        "result": read(root / result_file),
    }
    out = root / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == '__main__':
    main()
