import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/block_layout/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/block_layout/SPEC.md",
                "requirement_quote": "matrix是二维块列表，每块 {rows,cols,data:整数二维列表或null}，null表示有形状的零矩阵。",
                "reason": "SPEC only describes the valid input domain; it does not state that unknown fields or non-finite values must raise ValueError.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/block_layout/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly disclaims arbitrary malformed input handling; no ValueError rule is stated.",
            },
        },
    },
    {
        "target_path": "engines/squared/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/squared/SPEC.md",
                "requirement_quote": "计算 B²，返回同分块结构；每个块仍含 rows/cols。全零块 data=null，其他块 data为整数二维列表。",
                "reason": "SPEC describes valid input/output only; no ValueError rule for non-finite or unknown fields is stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/squared/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly disclaims arbitrary malformed input handling.",
            },
        },
    },
    {
        "target_path": "engines/cubed/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/cubed/SPEC.md",
                "requirement_quote": "消费 B² 再乘 B，返回 {layout:输入layout,blocks:B³的有形状分块矩阵}；使用与 squared相同零块表示。",
                "reason": "SPEC describes valid input/output only; no ValueError rule for non-finite or unknown fields is stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/cubed/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly disclaims arbitrary malformed input handling.",
            },
        },
    },
]


class BlockLayoutTests(unittest.TestCase):
    def test_row_col_sizes(self):
        # block_layout returns {row_sizes, col_sizes} from block rows/cols.
        matrix = [
            [{"rows": 2, "cols": 2, "data": [[1, 0], [0, 1]]},
             {"rows": 2, "cols": 1, "data": None}],
            [{"rows": 1, "cols": 2, "data": None},
             {"rows": 1, "cols": 1, "data": None}],
        ]
        expected = {"row_sizes": [2, 1], "col_sizes": [2, 1]}
        result = call_candidate("engines/block_layout/engine.py", "transform",
                                args=[{"matrix": matrix}, {}])
        self.assertEqual(result, expected)


class SquaredTests(unittest.TestCase):
    def test_square_preserves_zero_block_shape(self):
        # B² keeps shaped zero blocks (data=null) and integer dense blocks.
        matrix = [
            [{"rows": 2, "cols": 2, "data": [[2, 0], [0, 3]]},
             {"rows": 2, "cols": 1, "data": None}],
            [{"rows": 1, "cols": 2, "data": None},
             {"rows": 1, "cols": 1, "data": None}],
        ]
        result = call_candidate("engines/squared/engine.py", "transform",
                                args=[{"matrix": matrix}, {}])
        self.assertEqual(result[0][0]["data"], [[4, 0], [0, 9]])
        self.assertIsNone(result[0][1]["data"])
        self.assertEqual(result[0][1]["rows"], 2)
        self.assertEqual(result[0][1]["cols"], 1)
        self.assertIsNone(result[1][0]["data"])
        self.assertIsNone(result[1][1]["data"])


class CubedTests(unittest.TestCase):
    def test_cube_result(self):
        # B³ = B² * B; zero blocks stay shaped null.
        matrix = [
            [{"rows": 2, "cols": 2, "data": [[2, 0], [0, 3]]},
             {"rows": 2, "cols": 1, "data": None}],
            [{"rows": 1, "cols": 2, "data": None},
             {"rows": 1, "cols": 1, "data": None}],
        ]
        squared = [
            [{"rows": 2, "cols": 2, "data": [[4, 0], [0, 9]]},
             {"rows": 2, "cols": 1, "data": None}],
            [{"rows": 1, "cols": 2, "data": None},
             {"rows": 1, "cols": 1, "data": None}],
        ]
        layout = {"row_sizes": [2, 1], "col_sizes": [2, 1]}
        result = call_candidate("engines/cubed/engine.py", "transform",
                                args=[{"squared": squared, "matrix": matrix,
                                       "layout": layout}, {}])
        self.assertEqual(result["layout"], layout)
        self.assertEqual(result["blocks"][0][0]["data"], [[8, 0], [0, 27]])
        self.assertIsNone(result["blocks"][0][1]["data"])
        self.assertIsNone(result["blocks"][1][0]["data"])
        self.assertIsNone(result["blocks"][1][1]["data"])


if __name__ == "__main__":
    unittest.main()
