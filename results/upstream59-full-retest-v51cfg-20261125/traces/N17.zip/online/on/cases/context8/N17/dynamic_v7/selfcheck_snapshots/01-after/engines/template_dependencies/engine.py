"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

import re

_TOKEN_RE = re.compile(
    r"[A-Za-z_][A-Za-z0-9_]*"
    r"|'(?:[^'\\]|\\.)*'"
    r"|\"(?:[^\"\\]|\\.)*\""
    r"|\d+"
    r"|\.|\[|\]"
    r"|[^\s.\[\]]+"
)


def _tokenize(expr):
    return _TOKEN_RE.findall(expr)


def _extract_conf_chains(expr):
    """Yield conf access chains as lists of attribute/string-subscript parts."""
    tokens = _tokenize(expr)
    i = 0
    n = len(tokens)
    while i < n:
        if tokens[i] == "conf":
            chain = []
            j = i + 1
            while j < n:
                tok = tokens[j]
                if tok == ".":
                    j += 1
                    if j < n:
                        chain.append(tokens[j])
                        j += 1
                    else:
                        break
                elif tok == "[":
                    j += 1
                    if j < n and (tokens[j].startswith("'") or tokens[j].startswith('"')):
                        chain.append(tokens[j][1:-1])
                        j += 1
                        if j < n and tokens[j] == "]":
                            j += 1
                    else:
                        break
                else:
                    break
            if chain:
                yield chain
            i = j
        else:
            i += 1


def transform(payload, contract):
    templates = payload["templates"]
    options = payload["options"]
    result = {}
    for tid, text in templates.items():
        keys = set()
        for m in re.finditer(r"\{\{(.*?)\}\}", text):
            expr = m.group(1)
            for chain in _extract_conf_chains(expr):
                # Build dotted path from chain parts.
                path = ".".join(chain)
                # Longest legal prefix among options.
                best = None
                for opt in options:
                    if path == opt or path.startswith(opt + "."):
                        if best is None or len(opt) > len(best):
                            best = opt
                if best is not None:
                    keys.add(best)
        result[tid] = sorted(keys)
    return result

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
