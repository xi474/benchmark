"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import build, module, read

ROOT = Path(__file__).resolve().parent


def main():
    delivery = read(ROOT / "delivery.json")
    components = {}
    order = ["template_dependencies", "reverse_index", "stylesheet_updates"]
    for name in order:
        contract = read(ROOT / "engines" / name / "contract.json")
        engine = module(ROOT / "engines" / name, "engine.py")
        value = build(ROOT, contract, engine.transform)
        components[name] = value

    result = read(ROOT / delivery["result_file"])
    report = {
        "task": delivery["task"],
        "results": components,
        "result": result,
    }
    target = ROOT / delivery["report"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
