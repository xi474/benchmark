import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "engines/template_dependencies/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/template_dependencies/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly excludes arbitrary malformed input and extra-field recursion; no ValueError rule is documented for this transform.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/template_dependencies/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC does not document a ValueError for invalid payload types.",
            },
        },
    },
    {
        "target_path": "engines/reverse_index/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/reverse_index/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input; no ValueError rule documented.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/reverse_index/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC does not document a ValueError for invalid payload types.",
            },
        },
    },
    {
        "target_path": "engines/stylesheet_updates/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "engines/stylesheet_updates/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input; no ValueError rule documented.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "engines/stylesheet_updates/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC does not document a ValueError for invalid payload types.",
            },
        },
    },
]


class TestTemplateDependencies(unittest.TestCase):
    def test_longest_prefix_and_subscript(self):
        payload = {
            "templates": {
                "a": "{{ conf.auto_save.interval + conf.hints.min_chars }}",
                "b": "{{ conf.aliases['a'].propname }} {{ notconf.hints.min_chars }}",
            },
            "options": ["auto_save.interval", "hints.min_chars", "aliases"],
        }
        expected = {
            "a": ["auto_save.interval", "hints.min_chars"],
            "b": ["aliases"],
        }
        result = call_candidate(
            "engines/template_dependencies/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(result, expected)

    def test_longest_prefix_prefers_longer_option(self):
        payload = {
            "templates": {"t": "{{ conf.a.b.c }}"},
            "options": ["a", "a.b", "a.b.c"],
        }
        result = call_candidate(
            "engines/template_dependencies/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(result, {"t": ["a.b.c"]})


class TestReverseIndex(unittest.TestCase):
    def test_invert_and_sort(self):
        payload = {
            "dependencies": {
                "b": ["aliases"],
                "a": ["auto_save.interval", "hints.min_chars"],
            }
        }
        expected = {
            "aliases": ["b"],
            "auto_save.interval": ["a"],
            "hints.min_chars": ["a"],
        }
        result = call_candidate(
            "engines/reverse_index/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(result, expected)


class TestStylesheetUpdates(unittest.TestCase):
    def test_affected_intersection(self):
        payload = {
            "dependencies": {
                "a": ["auto_save.interval", "hints.min_chars"],
                "b": ["aliases"],
            },
            "reverse": {},
            "changed": ["hints.min_chars"],
        }
        result = call_candidate(
            "engines/stylesheet_updates/engine.py", "transform",
            args=[payload, {}],
        )
        self.assertEqual(result["dependencies"], payload["dependencies"])
        self.assertEqual(result["affected"], ["a"])


if __name__ == "__main__":
    unittest.main()
