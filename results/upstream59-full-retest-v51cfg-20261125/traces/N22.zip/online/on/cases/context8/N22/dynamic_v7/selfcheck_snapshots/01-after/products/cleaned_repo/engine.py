"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    import base64
    import gzip
    import hashlib
    import io
    import os
    import re
    import tarfile
    import tempfile
    import zlib

    secret = payload["scan"]["secret"]
    raw = base64.b64decode(payload["bundle"])
    data = gzip.decompress(raw)
    tf = tarfile.open(fileobj=io.BytesIO(data))

    with tempfile.TemporaryDirectory(prefix="n22-clean-") as td:
        tf.extractall(td)
        root = os.path.join(td)
        # Remove the secret marker from every loose object and drop unreachable
        # objects plus reflog entries that reference them.
        objects_dir = os.path.join(root, ".git", "objects")
        reachable = set()
        # Walk reachable objects from HEAD via git if available; otherwise
        # fall back to a pure-Python reachability walk.
        head_ref = os.path.join(root, ".git", "refs", "heads", "master")
        head = None
        if os.path.exists(head_ref):
            head = open(head_ref).read().strip()
        if head:
            reachable = _collect_reachable(objects_dir, head)
        # Remove any object whose decompressed content contains the secret.
        for dirpath, dirnames, filenames in os.walk(objects_dir):
            for fn in filenames:
                p = os.path.join(dirpath, fn)
                try:
                    obj = zlib.decompress(open(p, "rb").read())
                except zlib.error:
                    continue
                if secret.encode("utf-8") in obj:
                    os.remove(p)
        # Drop unreachable objects (history rewrite leftovers).
        if head:
            for dirpath, dirnames, filenames in os.walk(objects_dir):
                for fn in filenames:
                    oid = os.path.basename(dirpath) + fn
                    if oid not in reachable:
                        os.remove(os.path.join(dirpath, fn))
        # Clear reflogs and ORIG_HEAD.
        for rel in (".git/logs/HEAD", ".git/logs/refs/heads/master", ".git/ORIG_HEAD"):
            p = os.path.join(root, rel)
            if os.path.exists(p):
                os.remove(p)
        # Collect normal files (non-.git) and their SHA256.
        files = {}
        for dirpath, dirnames, filenames in os.walk(root):
            if ".git" in dirpath.split(os.sep):
                continue
            for fn in filenames:
                fp = os.path.join(dirpath, fn)
                rel = os.path.relpath(fp, root).replace(os.sep, "/")
                files[rel] = hashlib.sha256(open(fp, "rb").read()).hexdigest()
        # Messages from git log (newest first).
        messages = _git_log_messages(root)
        # Repack into tar.gz.
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as out:
            for dirpath, dirnames, filenames in os.walk(root):
                for name in dirnames + filenames:
                    fp = os.path.join(dirpath, name)
                    rel = os.path.relpath(fp, root)
                    out.add(fp, arcname=rel)
        bundle = base64.b64encode(buf.getvalue()).decode("ascii")
        return {"bundle": bundle, "files": files, "messages": messages}


def _collect_reachable(objects_dir, head):
    import os
    import zlib
    reachable = set()
    stack = [head]
    while stack:
        oid = stack.pop()
        if oid in reachable:
            continue
        reachable.add(oid)
        p = os.path.join(objects_dir, oid[:2], oid[2:])
        if not os.path.exists(p):
            continue
        try:
            obj = zlib.decompress(open(p, "rb").read())
        except zlib.error:
            continue
        header, _, body = obj.partition(b"\x00")
        typ = header.split(b" ")[0]
        if typ == b"commit":
            for line in body.split(b"\n"):
                if line.startswith(b"tree ") or line.startswith(b"parent "):
                    stack.append(line.split(b" ")[1].decode("ascii"))
        elif typ == b"tree":
            i = 0
            while i < len(body):
                sp = body.index(b" ", i)
                mode = body[i:sp]
                nul = body.index(b"\x00", sp)
                name = body[sp + 1:nul]
                oid = body[nul + 1:nul + 21].hex()
                stack.append(oid)
                i = nul + 21
    return reachable


def _git_log_messages(root):
    import os
    import zlib
    head_ref = os.path.join(root, ".git", "refs", "heads", "master")
    if not os.path.exists(head_ref):
        return []
    head = open(head_ref).read().strip()
    objects_dir = os.path.join(root, ".git", "objects")
    messages = []
    seen = set()
    stack = [head]
    while stack:
        oid = stack.pop()
        if oid in seen:
            continue
        seen.add(oid)
        p = os.path.join(objects_dir, oid[:2], oid[2:])
        if not os.path.exists(p):
            continue
        try:
            obj = zlib.decompress(open(p, "rb").read())
        except zlib.error:
            continue
        header, _, body = obj.partition(b"\x00")
        typ = header.split(b" ")[0]
        if typ == b"commit":
            parents = []
            msg = None
            for line in body.split(b"\n"):
                if line.startswith(b"parent "):
                    parents.append(line.split(b" ")[1].decode("ascii"))
            # message is everything after the blank line following headers
            parts = body.split(b"\n\n", 1)
            if len(parts) == 2:
                msg = parts[1].strip().decode("utf-8", "replace")
            if msg:
                messages.append(msg)
            for par in parents:
                stack.append(par)
    return messages

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
