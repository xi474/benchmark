"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    import base64
    import gzip
    import io
    import re
    import tarfile
    import zlib
    raw = base64.b64decode(payload["bundle"])
    data = gzip.decompress(raw)
    tf = tarfile.open(fileobj=io.BytesIO(data))
    for member in tf.getmembers():
        if not member.name.startswith(".git/objects/") or not member.isfile():
            continue
        blob = tf.extractfile(member).read()
        try:
            obj = zlib.decompress(blob)
        except zlib.error:
            continue
        m = re.search(rb"secret\[[^\]]*\]", obj)
        if m:
            return {"secret": m.group(0).decode("utf-8")}
    raise ValueError("secret marker not found")

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
