"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    import base64
    import gzip
    import hashlib
    import io
    import os
    import tarfile
    import tempfile
    import zlib

    secret = payload["scan"]["secret"]
    cleaned = payload["cleaned"]
    bundle = cleaned["bundle"]
    raw = base64.b64decode(bundle)
    data = gzip.decompress(raw)
    tf = tarfile.open(fileobj=io.BytesIO(data))

    with tempfile.TemporaryDirectory(prefix="n22-report-") as td:
        tf.extractall(td)
        root = td
        remaining = 0
        objects_dir = os.path.join(root, ".git", "objects")
        for dirpath, dirnames, filenames in os.walk(objects_dir):
            for fn in filenames:
                p = os.path.join(dirpath, fn)
                try:
                    obj = zlib.decompress(open(p, "rb").read())
                except zlib.error:
                    continue
                if secret.encode("utf-8") in obj:
                    remaining += 1
        files = {}
        for dirpath, dirnames, filenames in os.walk(root):
            if ".git" in dirpath.split(os.sep):
                continue
            for fn in filenames:
                fp = os.path.join(dirpath, fn)
                rel = os.path.relpath(fp, root).replace(os.sep, "/")
                files[rel] = hashlib.sha256(open(fp, "rb").read()).hexdigest()
        messages = _git_log_messages(root)
        return {
            "secret": secret,
            "files": files,
            "messages": messages,
            "remaining_secret_objects": remaining,
        }


def _git_log_messages(root):
    import os
    import zlib
    head_ref = os.path.join(root, ".git", "refs", "heads", "master")
    if not os.path.exists(head_ref):
        return []
    head = open(head_ref).read().strip()
    objects_dir = os.path.join(root, ".git", "objects")
    messages = []
    seen = set()
    stack = [head]
    while stack:
        oid = stack.pop()
        if oid in seen:
            continue
        seen.add(oid)
        p = os.path.join(objects_dir, oid[:2], oid[2:])
        if not os.path.exists(p):
            continue
        try:
            obj = zlib.decompress(open(p, "rb").read())
        except zlib.error:
            continue
        header, _, body = obj.partition(b"\x00")
        typ = header.split(b" ")[0]
        if typ == b"commit":
            parents = []
            msg = None
            for line in body.split(b"\n"):
                if line.startswith(b"parent "):
                    parents.append(line.split(b" ")[1].decode("ascii"))
            parts = body.split(b"\n\n", 1)
            if len(parts) == 2:
                msg = parts[1].strip().decode("utf-8", "replace")
            if msg:
                messages.append(msg)
            for par in parents:
                stack.append(par)
    return messages

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
