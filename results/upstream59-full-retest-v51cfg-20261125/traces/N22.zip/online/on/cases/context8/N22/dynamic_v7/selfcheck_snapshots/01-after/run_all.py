"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path

from runtime import build, read, module


def main():
    root = Path(__file__).resolve().parent
    (root / "outputs").mkdir(exist_ok=True)

    scan_contract = read(root / "products/object_scan/contract.json")
    clean_contract = read(root / "products/cleaned_repo/contract.json")
    report_contract = read(root / "products/recovery_report/contract.json")

    scan_mod = module(root, "products/object_scan/engine.py")
    clean_mod = module(root, "products/cleaned_repo/engine.py")
    report_mod = module(root, "products/recovery_report/engine.py")

    scan = build(root, scan_contract, scan_mod.transform)
    clean = build(root, clean_contract, clean_mod.transform)
    report = build(root, report_contract, report_mod.transform)

    delivery = read(root / "delivery.json")
    result_file = delivery["result_file"]
    result = read(root / result_file)

    final = {
        "task": "N22",
        "results": {
            "cleaned_repo": clean,
            "object_scan": scan,
            "recovery_report": report,
        },
        "result": result,
    }
    (root / "outputs/final_report.json").write_text(
        json.dumps(final, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
