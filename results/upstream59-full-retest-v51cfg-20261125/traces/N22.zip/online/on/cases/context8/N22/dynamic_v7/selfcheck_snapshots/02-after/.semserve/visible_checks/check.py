import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

with open(ROOT / "inputs/request.json", encoding="utf-8") as f:
    REQUEST = json.load(f)

with open(ROOT / "products/object_scan/contract.json", encoding="utf-8") as f:
    SCAN_CONTRACT = json.load(f)
with open(ROOT / "products/cleaned_repo/contract.json", encoding="utf-8") as f:
    CLEAN_CONTRACT = json.load(f)
with open(ROOT / "products/recovery_report/contract.json", encoding="utf-8") as f:
    REPORT_CONTRACT = json.load(f)

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/object_scan/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/object_scan/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly excludes arbitrary malformed input and extra-field recursion checks.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/object_scan/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input; no explicit ValueError rule for wrong payload type.",
            },
        },
    },
    {
        "target_path": "products/cleaned_repo/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/cleaned_repo/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input and extra-field recursion checks.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/cleaned_repo/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input; no explicit ValueError rule for wrong payload type.",
            },
        },
    },
    {
        "target_path": "products/recovery_report/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/recovery_report/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input and extra-field recursion checks.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/recovery_report/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC excludes arbitrary malformed input; no explicit ValueError rule for wrong payload type.",
            },
        },
    },
]


class ObjectScanTests(unittest.TestCase):
    def test_secret_recovered(self):
        result = call_candidate(
            "products/object_scan/engine.py",
            "transform",
            args=[{"bundle": REQUEST["bundle"]}, SCAN_CONTRACT],
        )
        self.assertIn("secret", result)
        self.assertTrue(result["secret"].startswith("secret["))
        self.assertTrue(result["secret"].endswith("]"))


class CleanedRepoTests(unittest.TestCase):
    def test_clean_removes_secret_and_keeps_files(self):
        scan = call_candidate(
            "products/object_scan/engine.py",
            "transform",
            args=[{"bundle": REQUEST["bundle"]}, SCAN_CONTRACT],
        )
        result = call_candidate(
            "products/cleaned_repo/engine.py",
            "transform",
            args=[{"bundle": REQUEST["bundle"], "scan": scan}, CLEAN_CONTRACT],
        )
        self.assertIn("bundle", result)
        self.assertIn("files", result)
        self.assertIn("messages", result)
        # Normal files preserved with expected hashes.
        self.assertEqual(
            result["files"]["notes.txt"],
            "5bb1b72ff67223e7021515b0fc4d27a1bdfbb634a929aafc0499acc6a033ddb9",
        )
        self.assertEqual(
            result["files"]["README.txt"],
            "4ae5e28d8f88aca075c2c9fc6281f9a7f0e03be9382975bdd6c38f524323da7c",
        )
        # Messages newest-first.
        self.assertEqual(result["messages"], ["keep notes", "init"])


class RecoveryReportTests(unittest.TestCase):
    def test_report_verifies_no_secret(self):
        scan = call_candidate(
            "products/object_scan/engine.py",
            "transform",
            args=[{"bundle": REQUEST["bundle"]}, SCAN_CONTRACT],
        )
        cleaned = call_candidate(
            "products/cleaned_repo/engine.py",
            "transform",
            args=[{"bundle": REQUEST["bundle"], "scan": scan}, CLEAN_CONTRACT],
        )
        result = call_candidate(
            "products/recovery_report/engine.py",
            "transform",
            args=[{"scan": scan, "cleaned": cleaned}, REPORT_CONTRACT],
        )
        self.assertEqual(result["secret"], scan["secret"])
        self.assertEqual(result["remaining_secret_objects"], 0)
        self.assertEqual(result["messages"], ["keep notes", "init"])
        self.assertEqual(
            result["files"]["notes.txt"],
            "5bb1b72ff67223e7021515b0fc4d27a1bdfbb634a929aafc0499acc6a033ddb9",
        )


if __name__ == "__main__":
    unittest.main()
