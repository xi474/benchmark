"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    text = payload["text"]
    records = []
    for i in range(0, len(text), 34):
        chunk = text[i:i+34]
        records.append({
            "id": chunk[0:4],
            "name": chunk[4:24].rstrip(" "),
            "balance": int(chunk[24:34]),
        })
    return records

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
