"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    accounts = payload["accounts"]
    books = payload["books"]
    orders = payload["orders"]
    journal = payload["journal"]

    acct_by_id = {a["id"]: a for a in accounts}
    book_by_id = {b["id"]: b for b in books}
    statuses = []

    for o in orders:
        buyer = o["buyer"]
        seller = o["seller"]
        book_id = o["book"]
        amount = o["amount"]
        book = book_by_id[book_id]
        if book["owner"] == seller:
            acct_by_id[buyer]["balance"] -= amount
            acct_by_id[seller]["balance"] += amount
            book["owner"] = buyer
            journal += book_id + f"{amount:010d}" + seller + buyer
            statuses.append("accepted")
        else:
            statuses.append("rejected")

    def enc_accounts():
        out = ""
        for a in accounts:
            out += a["id"] + a["name"].ljust(20) + f"{a['balance']:010d}"
        return out

    def enc_books():
        out = ""
        for b in books:
            out += b["id"] + b["title"].ljust(20) + b["owner"]
        return out

    return {
        "accounts": enc_accounts(),
        "books": enc_books(),
        "journal": journal,
        "statuses": statuses,
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
