"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, build, module

ROOT = Path(__file__).resolve().parent


def main():
    root = ROOT
    (root / "outputs").mkdir(exist_ok=True)

    components = ["accounts", "books", "orders", "settlement"]
    results = {}
    for name in components:
        contract = read(root / "products" / name / "contract.json")
        eng = module(root / "products" / name, "engine.py")
        results[name] = build(root, contract, eng.transform)

    delivery = read(root / "delivery.json")
    result_file = root / delivery["result_file"]
    result = read(result_file)

    report = {
        "task": "N24",
        "results": results,
        "result": result,
    }
    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == '__main__':
    main()
