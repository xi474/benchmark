import unittest

API_BOUNDARY_REQUIREMENTS = [
    {
        "target_path": "products/accounts/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/accounts/SPEC.md",
                "requirement_quote": "按34字符定长记录解析账户，字段 ID4/姓名20/余额10。返回 [{id,name:去掉末尾填充空格,balance:整数}]，保持文件顺序。合法 ASCII 输入。",
                "reason": "SPEC only defines parsing of legal ASCII fixed records; no ValueError rule for non-finite fields is stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/accounts/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly excludes malformed input handling.",
            },
        },
    },
    {
        "target_path": "products/books/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/books/SPEC.md",
                "requirement_quote": "按28字符定长记录解析图书，字段 ID4/书名20/owner4。返回 [{id,title:去掉末尾空格,owner}]，保持文件顺序。",
                "reason": "SPEC only defines parsing of legal fixed records; no ValueError rule stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/books/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly excludes malformed input handling.",
            },
        },
    },
    {
        "target_path": "products/orders/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/orders/SPEC.md",
                "requirement_quote": "逐个解析22字符交易请求：buyer4/seller4/book4/amount10。返回 [{buyer,seller,book,amount:整数}]，保持请求顺序。",
                "reason": "SPEC only defines parsing of legal fixed records; no ValueError rule stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/orders/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly excludes malformed input handling.",
            },
        },
    },
    {
        "target_path": "products/settlement/engine.py",
        "function": "transform",
        "rules": {
            "nonfinite_unknown_field": {
                "applicable": False,
                "contract_path": "products/settlement/SPEC.md",
                "requirement_quote": "顺序执行交易。请求中的买卖账户和书均存在，买卖方不同、正常金额且余额足够；当前 owner==seller 才成功。",
                "reason": "SPEC only defines legal input domain; no ValueError rule stated.",
            },
            "invalid_payload_type": {
                "applicable": False,
                "contract_path": "products/settlement/SPEC.md",
                "requirement_quote": "仅考查公开合法输入域与明确业务拒绝分支，不要求任意畸形输入、额外字段递归检查、异常文案或隐藏兼容行为。",
                "reason": "SPEC explicitly excludes malformed input handling.",
            },
        },
    },
]


class TestAccounts(unittest.TestCase):
    def test_parse_accounts(self):
        payload = {"text": "U001John Doe            0000001000U002Jane Smith          0000002000"}
        contract = {}
        result = call_candidate("products/accounts/engine.py", "transform", args=[payload, contract])
        self.assertEqual(result, [
            {"id": "U001", "name": "John Doe", "balance": 1000},
            {"id": "U002", "name": "Jane Smith", "balance": 2000},
        ])


class TestBooks(unittest.TestCase):
    def test_parse_books(self):
        payload = {"text": "B001Python Basics       U001B003Java Tutorial       U003"}
        contract = {}
        result = call_candidate("products/books/engine.py", "transform", args=[payload, contract])
        self.assertEqual(result, [
            {"id": "B001", "title": "Python Basics", "owner": "U001"},
            {"id": "B003", "title": "Java Tutorial", "owner": "U003"},
        ])


class TestOrders(unittest.TestCase):
    def test_parse_orders(self):
        payload = {"orders": ["U001U003B0030000000020", "U002U001B0030000000050"]}
        contract = {}
        result = call_candidate("products/orders/engine.py", "transform", args=[payload, contract])
        self.assertEqual(result, [
            {"buyer": "U001", "seller": "U003", "book": "B003", "amount": 20},
            {"buyer": "U002", "seller": "U001", "book": "B003", "amount": 50},
        ])


class TestSettlement(unittest.TestCase):
    def _payload(self):
        return {
            "accounts": [
                {"id": "U001", "name": "John Doe", "balance": 1000},
                {"id": "U002", "name": "Jane Smith", "balance": 2000},
                {"id": "U003", "name": "Bob Wilson", "balance": 1500},
            ],
            "books": [
                {"id": "B001", "title": "Python Basics", "owner": "U001"},
                {"id": "B003", "title": "Java Tutorial", "owner": "U003"},
            ],
            "orders": [
                {"buyer": "U001", "seller": "U003", "book": "B003", "amount": 20},
                {"buyer": "U002", "seller": "U001", "book": "B003", "amount": 50},
                {"buyer": "U002", "seller": "U001", "book": "B001", "amount": 150},
            ],
            "journal": "",
        }

    def test_settlement_full(self):
        result = call_candidate("products/settlement/engine.py", "transform", args=[self._payload(), {}])
        self.assertEqual(result["statuses"], ["accepted", "accepted", "accepted"])
        self.assertEqual(result["accounts"], "U001John Doe            0000001180U002Jane Smith          0000001800U003Bob Wilson          0000001520")
        self.assertEqual(result["books"], "B001Python Basics       U002B003Java Tutorial       U002")
        self.assertEqual(result["journal"], "B0030000000020U003U001B0030000000050U001U002B0010000000150U001U002")

    def test_settlement_reject_wrong_owner(self):
        payload = self._payload()
        # First order: U001 buys B003 from U003 (owner U003) -> accepted.
        # Second order: U002 buys B003 from U001, but owner is now U001 -> accepted.
        # Make a rejected case: seller not owner.
        payload["orders"] = [
            {"buyer": "U002", "seller": "U001", "book": "B003", "amount": 50},
        ]
        result = call_candidate("products/settlement/engine.py", "transform", args=[payload, {}])
        self.assertEqual(result["statuses"], ["rejected"])
        # Nothing changed.
        self.assertEqual(result["accounts"], "U001John Doe            0000001000U002Jane Smith          0000002000U003Bob Wilson          0000001500")
        self.assertEqual(result["books"], "B001Python Basics       U001B003Java Tutorial       U003")
        self.assertEqual(result["journal"], "")


if __name__ == "__main__":
    unittest.main()
