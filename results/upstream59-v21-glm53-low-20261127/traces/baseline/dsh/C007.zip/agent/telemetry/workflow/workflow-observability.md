# Workflow 可观测性报告

- Trial：`C007__QnWUPiB__env`
- Task：`C007`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_9c9d65e26d064388be403cac -> tool:dsh:lead:call_6b2795de56c54b4a9df69d55 -> tool:dsh:lead:call_a6d761321b024068b7435299 -> tool:dsh:lead:call_808062db8bc642f3bcfa1832 -> tool:dsh:lead:call_6d5eaf464da049e5b0a88947 -> tool:dsh:lead:call_c93567ee41c54dc6a1e9c538 -> tool:dsh:lead:call_caed542b5b7847069dc48654 -> tool:dsh:lead:call_f3f30e7814744e8b80e96863 -> tool:dsh:lead:call_42147275aac44b4aafd76c2b -> tool:dsh:lead:call_474dc33e79fa4ad2b1e2325a -> tool:dsh:lead:call_ad4e0d9514924cc781079e9e -> tool:dsh:lead:call_2c2803e6146d4567aba773eb -> tool:dsh:lead:call_22797e7bb92c4bec8a12e6b2 -> tool:dsh:lead:call_4dd1b38f33f74afa9481e67e -> tool:dsh:lead:call_0fcf1492cece4d39bd59cf62 -> tool:dsh:lead:call_e204e4b005a24e3284279df4 -> tool:dsh:lead:call_fcc78226bf794966a2e062f2 -> tool:dsh:lead:call_fcabafe2470e40a4aac5b0b8 -> tool:dsh:lead:call_6124e1b6805342d3953162c2 -> tool:dsh:lead:call_bb2c85d6ac6447ed99e758b4 -> tool:dsh:lead:call_1b614db395a34548897951c8 -> tool:dsh:lead:call_67eb2954a2014872be3acf85 -> tool:dsh:lead:call_dbb9528eb5854cc39fb9d41a -> tool:dsh:lead:call_ab73bb43705947eb8770cb53 -> tool:dsh:lead:call_81f97a2f4df647a68a9283ab -> tool:dsh:lead:call_fc0e83d579c24a9286fcaaae -> tool:dsh:lead:call_aa8b749838834d229ee2593d -> tool:dsh:lead:call_aa32979b7ab14729be631fe6 -> tool:dsh:lead:call_2aef195481a7461d917fb54a -> tool:dsh:lead:call_f137a621d023461fb5a42c50 -> tool:dsh:lead:call_a0ed9073cd6346dc94e1e50a -> tool:dsh:lead:call_4b688787bd1547f1bbc90176 -> tool:dsh:lead:call_0fa6b8f1a4024f9f9941c5b1 -> tool:dsh:lead:call_8f01e5f8a6994fa2b40888c6 -> tool:dsh:lead:call_0270c834da4b45e5a3c805d8
- 关键路径耗时：15.362
- Makespan：851.156
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
