# Workflow 可观测性报告

- Trial：`C008__bVxJTxr__env`
- Task：`C008`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_c01b42985d994c50ae2fe7f4 -> tool:dsh:lead:call_77da942cdaf84aa48628ba5c -> tool:dsh:lead:call_120a57e2d4424ffa9743ab3e -> tool:dsh:lead:call_8ef12fddc8a943c1b77284e7 -> tool:dsh:lead:call_f6ef59dca75e4183bf25fd3d -> tool:dsh:lead:call_e1c6ae3aa51341d28c6aa14b -> tool:dsh:lead:call_43c81732f1604103b17f9c13 -> tool:dsh:lead:call_e21b245ab2f14e3ea8296910 -> tool:dsh:lead:call_cd76936b78464fc4ba9e9984 -> tool:dsh:lead:call_0a94fe7c899640baaa3e796b -> tool:dsh:lead:call_7c498273ae8446dda951e37b -> tool:dsh:lead:call_16c6e3d433614899b18acc24 -> tool:dsh:lead:call_ba8dbebe933449acbc666b3f -> tool:dsh:lead:call_ce493a65fba74f0c8af53ddb -> tool:dsh:lead:call_b866c95064f645cf884cc29d -> tool:dsh:lead:call_d01e9cf33d3e42bb8e217b94 -> tool:dsh:lead:call_d2184f69d70245e4861bd90f -> tool:dsh:lead:call_87f0c086524f41328a27c471 -> tool:dsh:lead:call_93d8d0aba6d844b7b448698e -> tool:dsh:lead:call_e695c7fb3fc44547846be537 -> tool:dsh:lead:call_bf14f95d57f54fecb9a51614 -> tool:dsh:lead:call_984cf4a84b634d468c826655 -> tool:dsh:lead:call_9f38b0afdcee46d4968754b0
- 关键路径耗时：1.096
- Makespan：237.355
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
