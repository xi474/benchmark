# Workflow 可观测性报告

- Trial：`C009__cBkiSJp__env`
- Task：`C009`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_ef1bfc31101d4cc4aae229ec -> tool:dsh:lead:call_4def98906f874fce9d95c231 -> tool:dsh:lead:call_3400ebb97a784527afcab06c -> tool:dsh:lead:call_dda24ae6857e4f8b82bbfc0a -> tool:dsh:lead:call_72ff2eeb373648c3885f9e4e -> tool:dsh:lead:call_35e02130cb02417aa3099e05 -> tool:dsh:lead:call_4b66f022564140afbc8707d9 -> tool:dsh:lead:call_87c3e0647dce494d9e39cb13 -> tool:dsh:lead:call_4f2ec85f59bd4ebc9a164b2b -> tool:dsh:lead:call_8441ad5c108f435bb6649e8b -> tool:dsh:lead:call_809b3b59058d491597e4395c -> tool:dsh:lead:call_792acb8e20544bd8bd516d4f -> tool:dsh:lead:call_f61878f5e4ba44558c2a78f6 -> tool:dsh:lead:call_2da89ca367b946b39b8a61be -> tool:dsh:lead:call_36ac31dc386c480ca7402cba -> tool:dsh:lead:call_2dd1284e2e174880aef6f6f9 -> tool:dsh:lead:call_9cc2636f642b44898a85eb36 -> tool:dsh:lead:call_015224e5da7d44d0aa08a11e
- 关键路径耗时：0.876
- Makespan：456.587
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
