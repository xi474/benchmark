# Workflow 可观测性报告

- Trial：`C017__gnK3F6d__env`
- Task：`C017`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_eaa3ea9cf20b48da9fe593fe -> tool:dsh:lead:call_a7162fc53d3449d38e2d408a -> tool:dsh:lead:call_102adca1716648878b31925b -> tool:dsh:lead:call_c4f2d224078d4126bb847b5f -> tool:dsh:lead:call_2afce28687b04e8e891b641e -> tool:dsh:lead:call_6dd83f14142a4ee5a4a1579a -> tool:dsh:lead:call_e7f96fae2a1e46be9c22a38f -> tool:dsh:lead:call_c3c9142d03d0422fb822119f -> tool:dsh:lead:call_9baf93767ccb4832ac0d653e -> tool:dsh:lead:call_c3bd1cae1aa54ff7b5389c38 -> tool:dsh:lead:call_664e0825ccb34196ab53facf -> tool:dsh:lead:call_1bd89b1a0cd942ee83db8a81 -> tool:dsh:lead:call_29d6c0166c8f4f9b8ea8ab08 -> tool:dsh:lead:call_289e066308d244dbb98e4f54 -> tool:dsh:lead:call_435419dd6af546709f1760eb -> tool:dsh:lead:call_f50db987df614fe283f1058f -> tool:dsh:lead:call_8cf4c9b7b3b24dd99be95dfe -> tool:dsh:lead:call_aa862b74528543d6a7545a07
- 关键路径耗时：0.675
- Makespan：238.829
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
