# Workflow 可观测性报告

- Trial：`C031__bPa8EjU__env`
- Task：`C031`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_a89df176c99b4367a9d923c4 -> tool:dsh:lead:call_cbb72ba949de4c0996971372 -> tool:dsh:lead:call_7ec228b22e8b4a88bd2fe8d4 -> tool:dsh:lead:call_16710cd730834ab98b386b7a -> tool:dsh:lead:call_276634c4d5944394b339c036 -> tool:dsh:lead:call_c884e5eb0f7b44c2a4bd4931 -> tool:dsh:lead:call_f83c8d9317564c09937a1bd9 -> tool:dsh:lead:call_365f09d9446e4bce8480e774 -> tool:dsh:lead:call_858ff809ae0347d3a26003a6 -> tool:dsh:lead:call_107fab21f2054256833ce95f -> tool:dsh:lead:call_a230871ce3f345e78782d02c -> tool:dsh:lead:call_0f0de1c544cf4df5a43ff9e6 -> tool:dsh:lead:call_2d88b2630a234fff8dfff52a -> tool:dsh:lead:call_0a7a796d00904160898f2745 -> tool:dsh:lead:call_896d28c1dbb14ac088e7a699 -> tool:dsh:lead:call_536b4bdb6f604892bc6ef265 -> tool:dsh:lead:call_f1cde2f7cd504d5ca7f3ae06 -> tool:dsh:lead:call_48504330f63140b8bb1b1108 -> tool:dsh:lead:call_5ad7d09212bc425a8bf1cadc -> tool:dsh:lead:call_6370d46b40b6409fac729ec9 -> tool:dsh:lead:call_9b5a07486b434d93a083cbbc -> tool:dsh:lead:call_4e77cc58f9fe4fdd960c02aa -> tool:dsh:lead:call_d00bd482dafb4d87824adee7 -> tool:dsh:lead:call_33f38a50501049538a1e3802 -> tool:dsh:lead:call_9ae878b9711e42ada0fdffc3 -> tool:dsh:lead:call_e630743818f545168225ac86 -> tool:dsh:lead:call_3aaf62bc1d23462690afe306 -> tool:dsh:lead:call_2c3cef90e87c4cccbe780947 -> tool:dsh:lead:call_b89acae6ac604284be65f06a -> tool:dsh:lead:call_6aabd89e9e374fbf9f5d6f3e -> tool:dsh:lead:call_8da0de13d1e54970a0e6fa57 -> tool:dsh:lead:call_c66a6b431b9847efa8ce34a7 -> tool:dsh:lead:call_930c6fdc6f444d489680a6cb
- 关键路径耗时：75.814
- Makespan：544.54
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
