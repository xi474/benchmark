# Workflow 可观测性报告

- Trial：`C033__JYY6GFS__env`
- Task：`C033`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_729bbe7a175e440a9b56bd2e -> tool:dsh:lead:call_8d63af6d4ca342a4ad613725 -> tool:dsh:lead:call_74628de51a854656863431b2 -> tool:dsh:lead:call_07ae767058114b4b9a639b7b -> tool:dsh:lead:call_94dcf6dcaec044389225f4b2 -> tool:dsh:lead:call_59d40011704a435eba6e5886 -> tool:dsh:lead:call_2a5adf9e89614a6f954574f6 -> tool:dsh:lead:call_640c4fb44b1a4bb89b156437 -> tool:dsh:lead:call_85a1afc64da045edbe72a739 -> tool:dsh:lead:call_61fa24eaadd7466a88ded4e8 -> tool:dsh:lead:call_a4b4ac6a4cf242d685522d0e -> tool:dsh:lead:call_7bbb265adc534092aeed7622 -> tool:dsh:lead:call_57f717ce114946b0b5faf0f8 -> tool:dsh:lead:call_04e803b26ed64f419003c488 -> tool:dsh:lead:call_7c9961bffec840ebaa80e533 -> tool:dsh:lead:call_00369ef433f44093a041054f -> tool:dsh:lead:call_edaa1457791c4bb89cb77078 -> tool:dsh:lead:call_a8de84abfd6e4088863c1e6b -> tool:dsh:lead:call_a189939a930b47ccbc7fb358 -> tool:dsh:lead:call_331b757fb01f4a6f81ad56ed -> tool:dsh:lead:call_b1964bea73594ac08ff504cf -> tool:dsh:lead:call_3c00efedf51641f5934aea7f -> tool:dsh:lead:call_c2071d79edda4372bc921675 -> tool:dsh:lead:call_20d3c5a1c2bb45029fd51870 -> tool:dsh:lead:call_1a5a6d1e4e59420eade9edf9 -> tool:dsh:lead:call_6d069fde370646dbad802971 -> tool:dsh:lead:call_f1ca6238a15a4659a5f3bc54 -> tool:dsh:lead:call_1e1283ecb7b24040b388d88a
- 关键路径耗时：1.052
- Makespan：277.94
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
