# Workflow 可观测性报告

- Trial：`C039__dRQobWR__env`
- Task：`C039`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（15 节点 / 14 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：15；执行边：14（observed=0，inferred=14）
- Execution Trace Graph：`observed`；temporal_next 边 14，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_0966df29ad75402986240b06 -> tool:dsh:lead:call_7d1db1842b5c48da88aac518 -> tool:dsh:lead:call_852a2a4150374dec9d0e3ea1 -> tool:dsh:lead:call_6f263f514203432ab0377701 -> tool:dsh:lead:call_ce064a60c4974fdc9153939f -> tool:dsh:lead:call_178c4122936b42e1af2d9acc -> tool:dsh:lead:call_e972231abcd14e52aca62be6 -> tool:dsh:lead:call_7862a9c6cd7d472cb6f92543 -> tool:dsh:lead:call_daab16cd040d427691e71a2a -> tool:dsh:lead:call_c85b6fa7f8a24d8bba9ec642 -> tool:dsh:lead:call_8585c7e8a48d4da1953fa531 -> tool:dsh:lead:call_4b61532390c9428bbf1ce0b7 -> tool:dsh:lead:call_e9f14e7693184fceaba9a4a9 -> tool:dsh:lead:call_3238d63d88ab401a8adceef9
- 关键路径耗时：0.973
- Makespan：110.387
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
