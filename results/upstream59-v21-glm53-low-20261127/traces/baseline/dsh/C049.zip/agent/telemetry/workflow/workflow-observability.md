# Workflow 可观测性报告

- Trial：`C049__sfjsTtE__env`
- Task：`C049`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5f70c3033ead400b84d4b9f4 -> tool:dsh:lead:call_4d0d0f9d742145dd91aa6a7c -> tool:dsh:lead:call_1a9c885d83094d9f89b5b471 -> tool:dsh:lead:call_4ee7e10ee496493da519e328 -> tool:dsh:lead:call_6e29b764f2d84a1bb5cff8e2 -> tool:dsh:lead:call_c49fc7a7097a4e3a9b5025b7 -> tool:dsh:lead:call_d9efcf28e3cf4498b3791423 -> tool:dsh:lead:call_4be9a288aa2646b2a663eabf -> tool:dsh:lead:call_91cb5e5fa79d41d8ab74c54d -> tool:dsh:lead:call_b653019a09dd4fce857a081f -> tool:dsh:lead:call_83f2328ffcf04fc1a0e40ca2 -> tool:dsh:lead:call_9fd1daaf00de4da3947da0d4 -> tool:dsh:lead:call_7aa827fe761142259be04b71 -> tool:dsh:lead:call_d0277f67684442be9a0775ab -> tool:dsh:lead:call_1f293d6e6fd9481cbc6bc248 -> tool:dsh:lead:call_137f6e393c614a99ab420958 -> tool:dsh:lead:call_bba397d2ddaa4ff6bbfdaadb -> tool:dsh:lead:call_48cd9c55b43b4df299814bff
- 关键路径耗时：0.733
- Makespan：176.017
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
