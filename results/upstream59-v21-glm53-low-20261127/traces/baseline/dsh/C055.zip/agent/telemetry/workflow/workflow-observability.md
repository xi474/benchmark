# Workflow 可观测性报告

- Trial：`C055__32h9hVV__env`
- Task：`C055`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（18 节点 / 17 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：18；执行边：17（observed=0，inferred=17）
- Execution Trace Graph：`observed`；temporal_next 边 17，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_11c9f6e509a94e3bb16bb02a -> tool:dsh:lead:call_8eeea34bb26e4310a933ccda -> tool:dsh:lead:call_752ed06fcd13446bb26d696b -> tool:dsh:lead:call_34cb568d6b174c9087eab9ba -> tool:dsh:lead:call_1379b7932a96486e9a74bba9 -> tool:dsh:lead:call_38515087e1794f4599e78c60 -> tool:dsh:lead:call_ce856e7b69be4540abe75943 -> tool:dsh:lead:call_9be8e2050ead46c487b49fe7 -> tool:dsh:lead:call_1d779dce1c4648a781b7f452 -> tool:dsh:lead:call_01b71c7cac0748919a462e58 -> tool:dsh:lead:call_4b4fa827621b47e881935fea -> tool:dsh:lead:call_b26c69dcd6b040f58724ef9c -> tool:dsh:lead:call_2d14caec7bed4ada8d6a6e19 -> tool:dsh:lead:call_92329bb5853642dcba92ad35 -> tool:dsh:lead:call_e45310473ac14e73b0b518ce -> tool:dsh:lead:call_8435ea63ab474a3cb7ca02d9 -> tool:dsh:lead:call_7845fbaf970d48579fdafee1
- 关键路径耗时：0.747
- Makespan：238.092
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
