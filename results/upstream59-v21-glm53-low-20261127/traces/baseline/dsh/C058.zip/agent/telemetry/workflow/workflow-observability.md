# Workflow 可观测性报告

- Trial：`C058__Thmqpg8__env`
- Task：`C058`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_e0c6c0eeb8d749d99a28dccc -> tool:dsh:lead:call_f657969c58b344a7a347094c -> tool:dsh:lead:call_e635d5bc36bf4c889b9b4fbd -> tool:dsh:lead:call_dd58e83b9f50443599662ca3 -> tool:dsh:lead:call_d525b78e0aba4d73b68649b8 -> tool:dsh:lead:call_76ac4822d61b4f66b33cb5ce -> tool:dsh:lead:call_062c0190431942bc810ec97e -> tool:dsh:lead:call_f16e76e801bf48d18ee65880 -> tool:dsh:lead:call_38608323978e4dfeaf026fd5 -> tool:dsh:lead:call_97f9eeeecc9b49c99c69e1c5 -> tool:dsh:lead:call_ff8d8909620f478dba412f24 -> tool:dsh:lead:call_a44dad7d7eb04b54ad072b07 -> tool:dsh:lead:call_6f7d53732c7545e6841f009d -> tool:dsh:lead:call_1a4ac080b55d4176a9da320d -> tool:dsh:lead:call_c3bbbfe15a954c1f9e0769fd -> tool:dsh:lead:call_abe9ccfedeb542ce93a605f2 -> tool:dsh:lead:call_7d0e1ef327414957918a2b39 -> tool:dsh:lead:call_f7d76fb4fb124307a562e104
- 关键路径耗时：0.803
- Makespan：332.434
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
