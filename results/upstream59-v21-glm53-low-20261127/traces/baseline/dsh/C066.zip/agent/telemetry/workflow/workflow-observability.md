# Workflow 可观测性报告

- Trial：`C066__W95j4bB__env`
- Task：`C066`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（16 节点 / 15 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：16；执行边：15（observed=0，inferred=15）
- Execution Trace Graph：`observed`；temporal_next 边 15，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5ae806dc0e8b49abb89478c0 -> tool:dsh:lead:call_ee9c9c772de14f8c9e9e742d -> tool:dsh:lead:call_4316eeda50a041b599e0eedf -> tool:dsh:lead:call_5daa1e77a0074a319706df3e -> tool:dsh:lead:call_bfc7df2d5e3f4fa6bcf1f29c -> tool:dsh:lead:call_65d579b324c946ecbaebd2d3 -> tool:dsh:lead:call_53151786c99743e39a12ad33 -> tool:dsh:lead:call_0559503f1a4b40428f53dc5e -> tool:dsh:lead:call_09692a9266434c9986c13386 -> tool:dsh:lead:call_991e2e45ce034c1993fbef84 -> tool:dsh:lead:call_a073d83dec2544558c36cd59 -> tool:dsh:lead:call_4284b8e8cd2e40dc93816f7d -> tool:dsh:lead:call_b12f9465163d4265a5768f88 -> tool:dsh:lead:call_53ad9603de6c4e77879ad7f4 -> tool:dsh:lead:call_afd905f9cab641e09996e0ec
- 关键路径耗时：0.461
- Makespan：145.78
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
