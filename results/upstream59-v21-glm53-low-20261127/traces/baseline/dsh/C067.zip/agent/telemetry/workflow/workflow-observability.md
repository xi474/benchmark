# Workflow 可观测性报告

- Trial：`C067__qYuCqsD__env`
- Task：`C067`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（22 节点 / 21 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：22；执行边：21（observed=0，inferred=21）
- Execution Trace Graph：`observed`；temporal_next 边 21，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_cffd890a27c84d858f0dce82 -> tool:dsh:lead:call_a56dfcf75775485d99113f23 -> tool:dsh:lead:call_afca4e5b35c04e80b5abd945 -> tool:dsh:lead:call_8fe99e3de43b478aa7216ec8 -> tool:dsh:lead:call_eea15be83b9e4e57995910bd -> tool:dsh:lead:call_d08df5d0b6f6460f93ae4e21 -> tool:dsh:lead:call_845f306d681a433388af7d5e -> tool:dsh:lead:call_fc8b46800afe42d292585de6 -> tool:dsh:lead:call_3dd222bf488e4a049cfdce18 -> tool:dsh:lead:call_d56c83ca88f8410ea0419f11 -> tool:dsh:lead:call_7cebb7652b6d4f9ba7cce6ff -> tool:dsh:lead:call_61c8fffa0d3d4ac0a1e4fa65 -> tool:dsh:lead:call_eb4a5de0801849f995cad340 -> tool:dsh:lead:call_279823196f1340cc8dcc820c -> tool:dsh:lead:call_fd3a9c6b49a84b67a4598219 -> tool:dsh:lead:call_e1ffbc85cd3c484c97b7e486 -> tool:dsh:lead:call_3800fd854bb74ec99b2f30da -> tool:dsh:lead:call_884057ce5e094adeae55eb30 -> tool:dsh:lead:call_e71a9d9a069c4be2898c0b37 -> tool:dsh:lead:call_f5faa6709a21485591e2e2bc -> tool:dsh:lead:call_805ad47c58ff40d0aea0a895
- 关键路径耗时：0.984
- Makespan：188.821
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
