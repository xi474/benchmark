# Workflow 可观测性报告

- Trial：`C068__gLBC4gQ__env`
- Task：`C068`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（17 节点 / 16 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：17；执行边：16（observed=0，inferred=16）
- Execution Trace Graph：`observed`；temporal_next 边 16，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5432db046c054cbaa46b1168 -> tool:dsh:lead:call_2b1df65ef4d3430998d3b985 -> tool:dsh:lead:call_deba4778deb94d0cbd6fe284 -> tool:dsh:lead:call_4f94e593aa8a49d7b5d62eef -> tool:dsh:lead:call_95978a38d0514f768cbe6b75 -> tool:dsh:lead:call_84d33cc9ae8146d28cf657f9 -> tool:dsh:lead:call_849ba723a8014afd93a7bbc8 -> tool:dsh:lead:call_e1ba5266288a4813a3e78e9b -> tool:dsh:lead:call_2dafac2814e743f3aefe8690 -> tool:dsh:lead:call_dc042fa949594d8da9dc9aed -> tool:dsh:lead:call_9ea9cdb90f344b9e9fad45bf -> tool:dsh:lead:call_271f159488b64ccb8dd3c237 -> tool:dsh:lead:call_479c8aeef8fd46bf94e39f31 -> tool:dsh:lead:call_72210f4a311c47f7a83b5fde -> tool:dsh:lead:call_6692f49117ba4e0c89c474d3 -> tool:dsh:lead:call_cc8732c4731d46e0a7642609
- 关键路径耗时：0.465
- Makespan：224.13
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
