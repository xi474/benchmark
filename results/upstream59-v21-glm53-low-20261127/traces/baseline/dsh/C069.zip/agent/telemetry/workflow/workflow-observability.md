# Workflow 可观测性报告

- Trial：`C069__7CaH8ef__env`
- Task：`C069`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（21 节点 / 20 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：21；执行边：20（observed=0，inferred=20）
- Execution Trace Graph：`observed`；temporal_next 边 20，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_26e23972811c47bfa89fdbe0 -> tool:dsh:lead:call_0b56edff049c4222aaadae5d -> tool:dsh:lead:call_dae0497e05184451bc92c038 -> tool:dsh:lead:call_5de5225de4204464ae0773c5 -> tool:dsh:lead:call_5bbd9539b4cb4e6b9eef2cbd -> tool:dsh:lead:call_3f717f3a896e46e8989fa71b -> tool:dsh:lead:call_cb257272967e46939100e4e5 -> tool:dsh:lead:call_f21069c28c684d0fa52036ed -> tool:dsh:lead:call_baa2b11c7cef483f92a90559 -> tool:dsh:lead:call_990e45f0f09343a98b4100c8 -> tool:dsh:lead:call_f633cb1d5eb1486fa0736042 -> tool:dsh:lead:call_299b41bc3eda46ec856a3c5d -> tool:dsh:lead:call_822e5f39f2f047449534325b -> tool:dsh:lead:call_382b9e358b4a413e95bc4128 -> tool:dsh:lead:call_3f87bead23224184ae27c900 -> tool:dsh:lead:call_aa5ed4ebe809467c9510f0f6 -> tool:dsh:lead:call_e4d9f0c6476e4610b7a867a3 -> tool:dsh:lead:call_c4b1f54d595846c18578baf2 -> tool:dsh:lead:call_f5a9669c6cf749999e345b81 -> tool:dsh:lead:call_5e4187a23b9c4b28a8da5b33
- 关键路径耗时：0.792
- Makespan：265.616
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
