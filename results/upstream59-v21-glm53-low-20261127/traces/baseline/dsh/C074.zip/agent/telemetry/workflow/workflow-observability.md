# Workflow 可观测性报告

- Trial：`C074__Ben2R6t__env`
- Task：`C074`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_6e18f0f2eee94216a2d09b4f -> tool:dsh:lead:call_3db1de2a00764d41ad41e711 -> tool:dsh:lead:call_7463e78594304edba62a5545 -> tool:dsh:lead:call_a70efd4ff6ed4518a292f635 -> tool:dsh:lead:call_d10fffeabe5743ff860706a7 -> tool:dsh:lead:call_87b21246c9ef4623966cd0cc -> tool:dsh:lead:call_2e14c7b600cd43569091c9ff -> tool:dsh:lead:call_4f182a57cdec47e6a37d1a63 -> tool:dsh:lead:call_374e988f405543b08efa7b75 -> tool:dsh:lead:call_0811b077a05547f9a00c570a -> tool:dsh:lead:call_f2465a2d3a46435c91a43f93 -> tool:dsh:lead:call_26db151a62ee43238bed3bb8 -> tool:dsh:lead:call_bd74881221bb4dd6851eb66c -> tool:dsh:lead:call_f4947f920aec4aab89073fd5 -> tool:dsh:lead:call_8634089ee8434cfbb670fe27 -> tool:dsh:lead:call_266a5cb430f4425bb2f0c5a3 -> tool:dsh:lead:call_b8bfe78dda5c4aa89ecebca6 -> tool:dsh:lead:call_bfb6acd35a4d482b8f477a15
- 关键路径耗时：0.499
- Makespan：242.873
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
