# Workflow 可观测性报告

- Trial：`C079__2SvcvmG__env`
- Task：`C079`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（16 节点 / 15 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：16；执行边：15（observed=0，inferred=15）
- Execution Trace Graph：`observed`；temporal_next 边 15，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_98ca259373a3477882ca395c -> tool:dsh:lead:call_851b8bfe6bfc40b0a2ccdbb2 -> tool:dsh:lead:call_d8838b2b07334b4d9168d86c -> tool:dsh:lead:call_29d669b462734ece87701011 -> tool:dsh:lead:call_aa8967a8678648e9b3c7d624 -> tool:dsh:lead:call_c4a4f7190a0e41f49b101030 -> tool:dsh:lead:call_4b45094bc20f41308c1813ce -> tool:dsh:lead:call_82496b76fb774932a6d10ce4 -> tool:dsh:lead:call_874333067f4048a78ae006cd -> tool:dsh:lead:call_05a4bfc6b3c34ead88e59627 -> tool:dsh:lead:call_7b2f1478779f41d195edf011 -> tool:dsh:lead:call_2628e6823b1c49fd8a4c3836 -> tool:dsh:lead:call_f34ecad0452247cc8fa9783f -> tool:dsh:lead:call_41012c961d9f4c858a5d1adf -> tool:dsh:lead:call_dc98924d19d0422b84894f7d
- 关键路径耗时：0.604
- Makespan：117.522
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
