# Workflow 可观测性报告

- Trial：`MP01__YJ6fA6f__env`
- Task：`MP01`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（25 节点 / 24 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：25；执行边：24（observed=0，inferred=24）
- Execution Trace Graph：`observed`；temporal_next 边 24，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_3c0d858a002a419dbe2d097a -> tool:dsh:lead:call_8fc93f9375ce4518ad004181 -> tool:dsh:lead:call_321bf4cd25314a938f56902a -> tool:dsh:lead:call_6bfb054ee1a74485aa3eb9fe -> tool:dsh:lead:call_f46154355f9545a4969f0b58 -> tool:dsh:lead:call_cdf0f91416f84937bdd89380 -> tool:dsh:lead:call_2f8d773f1b3f486a93da519e -> tool:dsh:lead:call_b197f323647642c5b6de7076 -> tool:dsh:lead:call_118b7d83f1e7437898cc409b -> tool:dsh:lead:call_ce50d080daa747d691e989a1 -> tool:dsh:lead:call_512cd885fc6f423e96c43150 -> tool:dsh:lead:call_0b29bb781660404b96486c7d -> tool:dsh:lead:call_d744dbbffd6744f0aece0076 -> tool:dsh:lead:call_1c61f20099b3491c9bcd81b4 -> tool:dsh:lead:call_74f486e2c7094235b708aa71 -> tool:dsh:lead:call_5c46effdcab444ffbc90a1f7 -> tool:dsh:lead:call_a0fa6a9c2fd34f1cab058f75 -> tool:dsh:lead:call_3a909537712d40ef9140a01f -> tool:dsh:lead:call_0ebca5c14a1c42548fcaf0d4 -> tool:dsh:lead:call_69404e83a20a4446a5d641c1 -> tool:dsh:lead:call_ff1090411063402ebc0d2261 -> tool:dsh:lead:call_d1aa35a701d54b76bace83ad -> tool:dsh:lead:call_3450cc93e97140b7a5d2dc85 -> tool:dsh:lead:call_298d202e5b574698aa6ae474
- 关键路径耗时：1.034
- Makespan：308.152
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
