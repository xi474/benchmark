# Workflow 可观测性报告

- Trial：`MP02__y3pXxZ4__env`
- Task：`MP02`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（39 节点 / 38 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：39；执行边：38（observed=0，inferred=38）
- Execution Trace Graph：`observed`；temporal_next 边 38，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_339acc2c3327431ea22a8b20 -> tool:dsh:lead:call_604ab0fc51474ac2a9bd80c0 -> tool:dsh:lead:call_6f569f1e38734a858049d8d5 -> tool:dsh:lead:call_541b5d5fcf224fadbcc2b05c -> tool:dsh:lead:call_e49ae33bd2bd4c6d88f20af2 -> tool:dsh:lead:call_38a4d06a58fe4255a91d656f -> tool:dsh:lead:call_25b668f3995c46d7ad4884aa -> tool:dsh:lead:call_c9ef03b59659484591c46267 -> tool:dsh:lead:call_287dc51bcbb84569ac887910 -> tool:dsh:lead:call_1e0e67d46c9d4416976b3fca -> tool:dsh:lead:call_8c9be03912d04903ba9ba4f5 -> tool:dsh:lead:call_ec42c1893ccf42a4928b1bf5 -> tool:dsh:lead:call_fbc8884e9d6f42f19a9b71f7 -> tool:dsh:lead:call_dfbce24dfb3545b393a2f8f1 -> tool:dsh:lead:call_126bfb7bd4d343ff8a28774a -> tool:dsh:lead:call_162643c9ee7243d2a2e83be7 -> tool:dsh:lead:call_11d96347e7c34f449fbf8aa9 -> tool:dsh:lead:call_3881deec5d1745ddac4f6684 -> tool:dsh:lead:call_4673f6045ddc4681a68ad46e -> tool:dsh:lead:call_05d44cb3638d4b5281fcd155 -> tool:dsh:lead:call_05c267289f3c48ac87708388 -> tool:dsh:lead:call_cc119c16b40f4fbd990c91b7 -> tool:dsh:lead:call_f16b36a9d482430e9339feba -> tool:dsh:lead:call_89cd5b4885ab47edbe06647f -> tool:dsh:lead:call_bbf8c643b98d4e4aa9c3cb37 -> tool:dsh:lead:call_e90ba62c14f94ff0972287ea -> tool:dsh:lead:call_3f773d94790a42639ad1bac9 -> tool:dsh:lead:call_79cb8e580eed43868bc77b5b -> tool:dsh:lead:call_988ced5469b74dcfbff4fcf2 -> tool:dsh:lead:call_1cbfb333b45d4bf2bbe603b4 -> tool:dsh:lead:call_cae3c22326dc44ffaa63c8aa -> tool:dsh:lead:call_b87ea76533714fb7b6a520fa -> tool:dsh:lead:call_a34e5f5cd7814e9a86177ac1 -> tool:dsh:lead:call_5c94f13d8a264932b350aee4 -> tool:dsh:lead:call_6de6a3d2b9d64bd88e67f520 -> tool:dsh:lead:call_4bdf474090504489a9f4435d -> tool:dsh:lead:call_a8e72abbb4234bd9a39f8f4e -> tool:dsh:lead:call_0b56cb93fb6e493ea75038f8
- 关键路径耗时：1.893
- Makespan：393.539
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
