# Workflow 可观测性报告

- Trial：`MP03__3XHfXUB__env`
- Task：`MP03`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_6b120495c02f41a8864db04b -> tool:dsh:lead:call_151aed6fd36140d1bbd0bca2 -> tool:dsh:lead:call_0db35847c098464094a54910 -> tool:dsh:lead:call_b15c8b9604c541358e642204 -> tool:dsh:lead:call_c4431541288c4a4bb3d60097 -> tool:dsh:lead:call_299499d845004b63a0e756b2 -> tool:dsh:lead:call_396e9231aa9f487ab5cdf0ed -> tool:dsh:lead:call_fe396e730cd2463eb5a3117e -> tool:dsh:lead:call_9670b3f2cafd4182ab11d6fc -> tool:dsh:lead:call_c09a88ccfe3b44a49f39691f -> tool:dsh:lead:call_e3a3bb133df84de1865685f1 -> tool:dsh:lead:call_065599ad590242aa8940683e -> tool:dsh:lead:call_93b15af3058b423383e196d1 -> tool:dsh:lead:call_09c832a16fa641adafcc8f01 -> tool:dsh:lead:call_0b146f8f75894b4f8a1c9cd4 -> tool:dsh:lead:call_937b0cf5d14d4c23be540d0a -> tool:dsh:lead:call_bef15861e1fb46efb57b55d3 -> tool:dsh:lead:call_d2c1241ec2f743a485be1c15 -> tool:dsh:lead:call_5e1696e5f2a64298a15c1252 -> tool:dsh:lead:call_343aa42f4a3a4c96af5228d8 -> tool:dsh:lead:call_85415aaacacb4859a0df4d41 -> tool:dsh:lead:call_2324f2d17be2431ea2e2d8d8 -> tool:dsh:lead:call_e0539e150352491a9c8304d6 -> tool:dsh:lead:call_c82a54b4ea434888ad1fecc0 -> tool:dsh:lead:call_1e4ef12cc39b4d5aa761a68d -> tool:dsh:lead:call_32df88ab8c4b48e7a3d7470e -> tool:dsh:lead:call_0546ef1f19284b74a07402c9 -> tool:dsh:lead:call_a3fbd16f15ce4d1f9f5b7989 -> tool:dsh:lead:call_9f95b7772d5c416a8141d8e1 -> tool:dsh:lead:call_f4fec7d08b6247bc9d5defd7 -> tool:dsh:lead:call_8fe935adaacb4732a03c309f -> tool:dsh:lead:call_1f8edf7d4600490d8d3c15a0 -> tool:dsh:lead:call_3baa4288e99c467f9dc85d1e -> tool:dsh:lead:call_47a49f96b2bc4748bd454ca1 -> tool:dsh:lead:call_11cfed72681744259e17545e -> tool:dsh:lead:call_e43f8db22aeb420b931e3d83 -> tool:dsh:lead:call_dcdb8d0968a3410dbfbf1068 -> tool:dsh:lead:call_375a13b77aec42e8914fc247 -> tool:dsh:lead:call_c5f1ea3845e74bcaa9eb8248
- 关键路径耗时：1.462
- Makespan：319.922
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
