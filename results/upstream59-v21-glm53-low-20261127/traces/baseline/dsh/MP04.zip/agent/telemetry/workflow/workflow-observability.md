# Workflow 可观测性报告

- Trial：`MP04__UyBWnNM__env`
- Task：`MP04`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_9f9cd1d9188f42e890c95df0 -> tool:dsh:lead:call_1064f13836954754b123b5c1 -> tool:dsh:lead:call_2879db31efa34431bea0dd91 -> tool:dsh:lead:call_9de84adb925a4171a4ac390f -> tool:dsh:lead:call_21ab954859654c939c585840 -> tool:dsh:lead:call_63ededf155524239abc7d23b -> tool:dsh:lead:call_24dc0f849fdb4fbb8a6edd8a -> tool:dsh:lead:call_d68b1b4be1af4361accd4024 -> tool:dsh:lead:call_38ec996ac2a040dd9ae3ad1d -> tool:dsh:lead:call_eb3c0703f30a4e4f85ecbf9f -> tool:dsh:lead:call_2e7ade84308f4b9daa7ae4ff -> tool:dsh:lead:call_a68fb9141d0744f09ec8b731 -> tool:dsh:lead:call_64f1848bf24c4d7fad586751 -> tool:dsh:lead:call_353b5d6acc4f4dfd819cfbde -> tool:dsh:lead:call_c9166bb445984f0687320b22 -> tool:dsh:lead:call_413386abb4f64ccdac4eea6a -> tool:dsh:lead:call_ffd6ec7da4514a80a6d12dab -> tool:dsh:lead:call_923cfc8b521b4c5f88affd77 -> tool:dsh:lead:call_0c65d2be439c4082b537bd2d -> tool:dsh:lead:call_f8826457337744f590d6ecae -> tool:dsh:lead:call_993e4eead15d41a79c438bf6 -> tool:dsh:lead:call_ecbcb9940fd14c729d5ace10 -> tool:dsh:lead:call_f23bc4f03e884ba19d2e20c2 -> tool:dsh:lead:call_86d7d18843b94621b7be5e2b -> tool:dsh:lead:call_968c134c77804d3cbf1be21a -> tool:dsh:lead:call_d8227284cf9742a5b1a1f760 -> tool:dsh:lead:call_211e13ddc5514be6a42fd706 -> tool:dsh:lead:call_f4f588e6e0684564b6821827 -> tool:dsh:lead:call_8c6e9a43c0334c6cb906f96a -> tool:dsh:lead:call_f4834cebce1241fc8865e46a -> tool:dsh:lead:call_8c0477fbd5b042adb0ffe49b -> tool:dsh:lead:call_59d5e3ae6a004f188f2a0a30 -> tool:dsh:lead:call_c0d066c859d54d4da8f4cbce -> tool:dsh:lead:call_c89b42b5176041c4969386ea -> tool:dsh:lead:call_bf9dcd390fe1418ba943b9ef
- 关键路径耗时：1.205
- Makespan：458.188
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
