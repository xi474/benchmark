# Workflow 可观测性报告

- Trial：`MP05__gDtkc94__env`
- Task：`MP05`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_ca8b786e991a4563ba28342a -> tool:dsh:lead:call_8a18bf1f1bc648c7a0c4aad9 -> tool:dsh:lead:call_b3ec8005df9e4c3f99e12777 -> tool:dsh:lead:call_c255420598054b8a8fd2a112 -> tool:dsh:lead:call_197859e0aa0347d387cc1a79 -> tool:dsh:lead:call_8db6c90bc0224526a3102172 -> tool:dsh:lead:call_e7a3c85224a44382825c1b8f -> tool:dsh:lead:call_8a3581e810f54f8db7944377 -> tool:dsh:lead:call_43546ce166c743b895cf72af -> tool:dsh:lead:call_d752d0865c8245b6b06a72e5 -> tool:dsh:lead:call_a7d01b02d04b496cb0b5dcdd -> tool:dsh:lead:call_2a3763b104f549398e449102 -> tool:dsh:lead:call_fab0f40323574ea1a0dabe69 -> tool:dsh:lead:call_34c9b2a2eeba478bb6b34893 -> tool:dsh:lead:call_70af09cdece34491b241fe6e -> tool:dsh:lead:call_680c791ce1bc463385beb64d -> tool:dsh:lead:call_21f1b2579771423794cd4bc1 -> tool:dsh:lead:call_fecf207b901f4cd19d34606d -> tool:dsh:lead:call_c10dfa8779394645886249e2 -> tool:dsh:lead:call_9dc57d2517bc4c71bd4c4cb1 -> tool:dsh:lead:call_1bc092975b2b41698fca9e7b -> tool:dsh:lead:call_8aad2f4a1fe84dc6b250753d -> tool:dsh:lead:call_d063f18a18a84034b72483fc -> tool:dsh:lead:call_4fba9fa1caaa41128a8d4131 -> tool:dsh:lead:call_8be81f6279164cbf88c11fe9 -> tool:dsh:lead:call_4bdd2d7e8caf4a0d89b95b68 -> tool:dsh:lead:call_d6318a34c5ea4e1785878122 -> tool:dsh:lead:call_00e1b57c55304b76839d28a1 -> tool:dsh:lead:call_7e85a7d1eba8465fac625c72 -> tool:dsh:lead:call_3564a2bfb7d64a328efce317 -> tool:dsh:lead:call_afc16eaa91c94245940642e4 -> tool:dsh:lead:call_dcabe1c0db95412b8c51eb67
- 关键路径耗时：1.46
- Makespan：469.917
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
