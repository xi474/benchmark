# Workflow 可观测性报告

- Trial：`MP06__NJhYb4z__env`
- Task：`MP06`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_23b8fb78f67f4da89532c995 -> tool:dsh:lead:call_f81c27da20704a5aa5a78324 -> tool:dsh:lead:call_cf12399d17674152bbb678c3 -> tool:dsh:lead:call_141f40375382421f84073e50 -> tool:dsh:lead:call_6a0331aa42824ada875ab4ff -> tool:dsh:lead:call_5b912fc574044292a6f20095 -> tool:dsh:lead:call_b2d72ecb7ff6432ab55ab5b5 -> tool:dsh:lead:call_b48fb14f228c4260b08d0b65 -> tool:dsh:lead:call_b2bde7673c9249a0b18fe623 -> tool:dsh:lead:call_5305f4da6bff42389064b159 -> tool:dsh:lead:call_82e01483611c45e9b3c7bfff -> tool:dsh:lead:call_3e751879a4a845af9d27fc0b -> tool:dsh:lead:call_59b3e9d9f3ce4f5d82922713 -> tool:dsh:lead:call_c073c4d6fdb64dcba78d4037 -> tool:dsh:lead:call_4788a306355a4e5d9e683004 -> tool:dsh:lead:call_1267807efea344378bcd8b71 -> tool:dsh:lead:call_fae3faf06e714928b3d454e6 -> tool:dsh:lead:call_8669b03f36ac469b92fde7e6 -> tool:dsh:lead:call_cf9d4559df1d4936b6b1a1bf -> tool:dsh:lead:call_1b79f779035f4fd78faf8176 -> tool:dsh:lead:call_48935c810eb84b84ba40640f -> tool:dsh:lead:call_202307a883954f16892eee28 -> tool:dsh:lead:call_37aedb538538473980e2a779 -> tool:dsh:lead:call_c993fb30b5ff4acebb95848a -> tool:dsh:lead:call_a7146b868fc34f65bfd4e830 -> tool:dsh:lead:call_410869e0b33f421ca8333d61 -> tool:dsh:lead:call_89a03af3006f46a1b0287306 -> tool:dsh:lead:call_1ea3a697fdd7467a8d3f6788 -> tool:dsh:lead:call_6ec52e9aa124437db600f3a6 -> tool:dsh:lead:call_90f024705e4a4d9791cc82a5 -> tool:dsh:lead:call_9f0c2226a67a40328adc811a -> tool:dsh:lead:call_7d1dd218df744ac0aeaa79db
- 关键路径耗时：1.154
- Makespan：286.259
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
