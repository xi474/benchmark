# Workflow 可观测性报告

- Trial：`MP08__smKj8rR__env`
- Task：`MP08`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_35898051afe240b1aba964ee -> tool:dsh:lead:call_f8abf6d9653c49d38cb0cf26 -> tool:dsh:lead:call_31023b92f04f44d894576f71 -> tool:dsh:lead:call_53aa2276a9664fd6bec4cdd7 -> tool:dsh:lead:call_7e5af48a0ed74de59b715f22 -> tool:dsh:lead:call_70bf1dbfcb9441099a8ca977 -> tool:dsh:lead:call_0efe8a7158394a049640d756 -> tool:dsh:lead:call_36cf3c2d1bdb43b786e12078 -> tool:dsh:lead:call_254bf1fa20fb4262b281e1a9 -> tool:dsh:lead:call_8149c73c1418450994817a8d -> tool:dsh:lead:call_e127a37a5b7e4e10a95a76e5 -> tool:dsh:lead:call_7c43feeeefee492d9bc8866e -> tool:dsh:lead:call_67ec377cb1904f19924191aa -> tool:dsh:lead:call_5d319d2956314edc8fab05d2 -> tool:dsh:lead:call_6f0dbc8365b44538a5103b8a -> tool:dsh:lead:call_c61d706a48ff4ad0b9838a0d -> tool:dsh:lead:call_da30d8a2634e46eb97f8d318 -> tool:dsh:lead:call_56f86269376e4c6b92dc1ca2 -> tool:dsh:lead:call_b75d4d4f08384bb498658f91 -> tool:dsh:lead:call_830dd3a292da478f97b64120 -> tool:dsh:lead:call_0235c12e2b2b47ca96f51de8 -> tool:dsh:lead:call_ccb449757fa548448c65789c -> tool:dsh:lead:call_3ee9c77c7dab43d5ab7f2049 -> tool:dsh:lead:call_425f907e1c934b0f8cfe0773 -> tool:dsh:lead:call_dce492e6223a466b8dcabf3d -> tool:dsh:lead:call_812f6f2257b347e990e6ee2f -> tool:dsh:lead:call_aa3d405412834f29bc05f6b8 -> tool:dsh:lead:call_6d8e71ec187143a2a5f41652 -> tool:dsh:lead:call_58ee1de7ed9146b9846e6287 -> tool:dsh:lead:call_41d4362b98be434990fddb21
- 关键路径耗时：1.104
- Makespan：344.303
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
