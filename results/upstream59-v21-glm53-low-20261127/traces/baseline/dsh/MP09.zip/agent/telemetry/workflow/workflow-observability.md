# Workflow 可观测性报告

- Trial：`MP09__frXLpxc__env`
- Task：`MP09`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（43 节点 / 42 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：43；执行边：42（observed=0，inferred=42）
- Execution Trace Graph：`observed`；temporal_next 边 42，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_e80b13bc41704eaa82597fff -> tool:dsh:lead:call_202c3b8be83243a081c5611e -> tool:dsh:lead:call_ec06226057cd4adda4c9c2aa -> tool:dsh:lead:call_bcad0ebe45df4cdbb013bc1a -> tool:dsh:lead:call_7c9e905550f04a8ab1563f3f -> tool:dsh:lead:call_5600a6fc038a44ac90f1310c -> tool:dsh:lead:call_739cc8c792ab4132b80670b3 -> tool:dsh:lead:call_df38d84f7b634aa8ae68ff9a -> tool:dsh:lead:call_ca71ad309e9e4e9aa1cb3cf6 -> tool:dsh:lead:call_0cb1ac08a250443fa2b95068 -> tool:dsh:lead:call_0d80411cdd8842dbabc42431 -> tool:dsh:lead:call_3b7b181e843d4f8bb276a197 -> tool:dsh:lead:call_e478c0b365e649c7ac6e7505 -> tool:dsh:lead:call_0aaa4e819d0040ab82d33f90 -> tool:dsh:lead:call_8ec9ce99364047c19ef3ecfe -> tool:dsh:lead:call_7fd37775e1c54312bcb90b3d -> tool:dsh:lead:call_4b3070f29003492b87171eff -> tool:dsh:lead:call_f0ec8f94edfc4c8f887d326b -> tool:dsh:lead:call_7ed68925a28b40f3bfcd30b8 -> tool:dsh:lead:call_ad8aa46896034a198e66d395 -> tool:dsh:lead:call_2bc646ab89a8475dbefb1a9c -> tool:dsh:lead:call_378d20092e1345a8bd9edf81 -> tool:dsh:lead:call_e22462246db14df1962317cb -> tool:dsh:lead:call_a9354f0b02a540619a4a2ed4 -> tool:dsh:lead:call_65feaa421b9d4a8bb71d581b -> tool:dsh:lead:call_3b44c3343c344d919d5f27d9 -> tool:dsh:lead:call_3c444a10bca84d788a49874a -> tool:dsh:lead:call_a9499353b8a0421cb3286a8e -> tool:dsh:lead:call_2bc9f92284ee422684e47e6c -> tool:dsh:lead:call_fc7f57e4319340218fb47301 -> tool:dsh:lead:call_9b74f81096ed4bfe90424a70 -> tool:dsh:lead:call_68c6acd6e84f4166a965984c -> tool:dsh:lead:call_6168b61124244b9fa2da8f61 -> tool:dsh:lead:call_ccee8e7021a44b4db29a27b7 -> tool:dsh:lead:call_65f6d99a81f349559e216b74 -> tool:dsh:lead:call_63ed6fe689d14e98a9d78514 -> tool:dsh:lead:call_b8d701bf795d45df94db2064 -> tool:dsh:lead:call_6ed2a6a671c6456c92112db4 -> tool:dsh:lead:call_4c80fae1eda2452693e7dfae -> tool:dsh:lead:call_8bb604b5f45248cd9361c508 -> tool:dsh:lead:call_a6f256552d10436381c3f1f5 -> tool:dsh:lead:call_14d9100bbbce4b828ed8f4c0
- 关键路径耗时：2.335
- Makespan：287.92
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
