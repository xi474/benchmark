# Workflow 可观测性报告

- Trial：`MP10__TP8PMXg__env`
- Task：`MP10`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_8df618d9a0a94fffa041e702 -> tool:dsh:lead:call_e9dcbcbe0efb4187895269f9 -> tool:dsh:lead:call_b4ccdda4f4d6409e8a27718d -> tool:dsh:lead:call_cf77370eb3714135a5d92181 -> tool:dsh:lead:call_954f4d99d6b74656b1b174f4 -> tool:dsh:lead:call_e16d7539c99f467e9c035456 -> tool:dsh:lead:call_773193f72d7c4ec08b3e5963 -> tool:dsh:lead:call_1536d5eeb91748878a03d8b9 -> tool:dsh:lead:call_d4a2a81c8f334ec4abdd5649 -> tool:dsh:lead:call_b9cf77df76df4d20872f51ff -> tool:dsh:lead:call_815854316e2f49a08ecd2a3f -> tool:dsh:lead:call_70036f83477a4493a2cc7067 -> tool:dsh:lead:call_b07da0d24a074ee2ab92c5f1 -> tool:dsh:lead:call_6227baabfc884a7c8aecb046 -> tool:dsh:lead:call_48556114de754628a95fddd7 -> tool:dsh:lead:call_ef32b2b4c9b147f0bab069a4 -> tool:dsh:lead:call_620f8f23b48b4492a0ba60df -> tool:dsh:lead:call_527879299f484a80b3c02703 -> tool:dsh:lead:call_c63ebd53c33c4fea9f80fe96 -> tool:dsh:lead:call_f1d40b2fdb2f4619a8c30734 -> tool:dsh:lead:call_15a264c67d4e4b30b9e412b5 -> tool:dsh:lead:call_ee5b2c86426444cb895b23fd -> tool:dsh:lead:call_6dbb956317b1466ba8f69906
- 关键路径耗时：0.686
- Makespan：240.734
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
