# Workflow 可观测性报告

- Trial：`MP12__g5xboMW__env`
- Task：`MP12`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（26 节点 / 25 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：26；执行边：25（observed=0，inferred=25）
- Execution Trace Graph：`observed`；temporal_next 边 25，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_9fbe51dc1b4d499aa4649984 -> tool:dsh:lead:call_4eacf5a4451e48879588db0b -> tool:dsh:lead:call_6f5753cd4e384ab2b40398ae -> tool:dsh:lead:call_902d4ae0864c49bdb043b6ad -> tool:dsh:lead:call_c441984b24df43c58ffbbf3c -> tool:dsh:lead:call_ac61c0c420ca4e91a02eecf6 -> tool:dsh:lead:call_c6b37dd4ab0a414b803d6c00 -> tool:dsh:lead:call_8c6c6705876647efa646e0e6 -> tool:dsh:lead:call_477e22adc36d4517acafd971 -> tool:dsh:lead:call_09db5c2bf01047309759302d -> tool:dsh:lead:call_85002bff81f844a7b7dccbce -> tool:dsh:lead:call_b8939bd74b904215bf91e28f -> tool:dsh:lead:call_9ea7fd2e39754ce6a14b59c9 -> tool:dsh:lead:call_237438970f594c6f8e781815 -> tool:dsh:lead:call_def3c31456614443ada67b56 -> tool:dsh:lead:call_91248f4142ba426988b1b463 -> tool:dsh:lead:call_dc8d20139df44e839cd692f5 -> tool:dsh:lead:call_d9ddca2fb6724e2db70a7a55 -> tool:dsh:lead:call_4db125192e2a4daf87e76c89 -> tool:dsh:lead:call_2f81246b4bfc4408bcbb6a1e -> tool:dsh:lead:call_2f85903a5818440ea8806b28 -> tool:dsh:lead:call_88e8af7424114c389502fd7e -> tool:dsh:lead:call_f1adbd6b0b6a42ac81bfabde -> tool:dsh:lead:call_47fcd73c85cf4469b6803ee0 -> tool:dsh:lead:call_d3e1f6bd54ed4ccda8eae61c
- 关键路径耗时：2.121
- Makespan：311.878
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
