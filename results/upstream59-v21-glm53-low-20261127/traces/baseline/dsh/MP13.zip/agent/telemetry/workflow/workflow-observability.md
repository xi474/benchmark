# Workflow 可观测性报告

- Trial：`MP13__UDA2Pfj__env`
- Task：`MP13`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_515ae0eccdc3493cb080fd2f -> tool:dsh:lead:call_b20f22a90dc447faa4aece25 -> tool:dsh:lead:call_1a67fc2c2109455b904eade8 -> tool:dsh:lead:call_8c1a2f9e88c3480a8b851ee9 -> tool:dsh:lead:call_a392ee5c5a8b4423b03d2471 -> tool:dsh:lead:call_0737f5d9cf5a4892a3549d8a -> tool:dsh:lead:call_1209de9e760846a48e509e58 -> tool:dsh:lead:call_5663ccaa30c749beb468f730 -> tool:dsh:lead:call_439cce90e1e14c93b0e13186 -> tool:dsh:lead:call_f735585c668a418aa676bcfc -> tool:dsh:lead:call_d24065b7771243e0a9f73719 -> tool:dsh:lead:call_e59e7b558470452ebab8d4d5 -> tool:dsh:lead:call_239772c56b6d4d6ea7b7c7ee -> tool:dsh:lead:call_5a4fd2c4703e4752aacd7e13 -> tool:dsh:lead:call_f5d7f8071dba40ff9f764eb8 -> tool:dsh:lead:call_e76eb6eb94584207be7dc29b -> tool:dsh:lead:call_7935eead25734f7797ce471d -> tool:dsh:lead:call_5fa1f05f283c4d0db92863c6 -> tool:dsh:lead:call_4cb9eb399c014c1facc98bd3 -> tool:dsh:lead:call_2d124091d6364396b0fe1960 -> tool:dsh:lead:call_d6222b2f5b1647b99a6e0625 -> tool:dsh:lead:call_3f85be23743841bc89c802f1 -> tool:dsh:lead:call_26d7cd3419ea44d5b225212f -> tool:dsh:lead:call_fe56eca7c67f449aaa625e41 -> tool:dsh:lead:call_5d8820bf24114469848cec4a -> tool:dsh:lead:call_0e120434579340c4a8c213c8 -> tool:dsh:lead:call_9fd9d0a982504284b2f0510f -> tool:dsh:lead:call_beb30e6f508a4651b15e56b3 -> tool:dsh:lead:call_2c15b8acaa304be49eae6253 -> tool:dsh:lead:call_1a464a2fb1e945b390849a40 -> tool:dsh:lead:call_f90c9d9e4e5643f88628029f -> tool:dsh:lead:call_cdad1d05cac44c5187f4140b -> tool:dsh:lead:call_c792cce6c24c4c0db5fc8506
- 关键路径耗时：1.3
- Makespan：286.597
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
