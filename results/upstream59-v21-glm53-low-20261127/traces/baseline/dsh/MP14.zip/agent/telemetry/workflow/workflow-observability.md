# Workflow 可观测性报告

- Trial：`MP14__79JxmZv__env`
- Task：`MP14`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（27 节点 / 26 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：27；执行边：26（observed=0，inferred=26）
- Execution Trace Graph：`observed`；temporal_next 边 26，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_dbbbe8ee4b554436b9a43131 -> tool:dsh:lead:call_6272532b3ebf4d47b28e5285 -> tool:dsh:lead:call_bb859e135f464ed382368b4f -> tool:dsh:lead:call_d4ceb78f4cf5406bbaa5004d -> tool:dsh:lead:call_fe96422474de4e0ba1d2d627 -> tool:dsh:lead:call_74e61881689e4b3b82c88a4e -> tool:dsh:lead:call_5481a37a5b9e43bda481bf3b -> tool:dsh:lead:call_b142bd19b678464fbf7a499d -> tool:dsh:lead:call_132e746238a04bff9839e0bf -> tool:dsh:lead:call_6338556212db4dc8aa226201 -> tool:dsh:lead:call_05ea252b0a1148ca8c0349ae -> tool:dsh:lead:call_c6b2a89de0344ccb8f4b7a1c -> tool:dsh:lead:call_7de6030dddd84414a16de1c1 -> tool:dsh:lead:call_ac975d123a8e49abb6558be6 -> tool:dsh:lead:call_642ce54593754de3bf411f07 -> tool:dsh:lead:call_8f1de7adc22d40d3a6160c6d -> tool:dsh:lead:call_05e277499d2b43f0b2dfdfb0 -> tool:dsh:lead:call_03d1780163c94eefb6b0e77b -> tool:dsh:lead:call_f787af9ba3d343ae92f7576a -> tool:dsh:lead:call_cf439d9f91354392a1c71a1a -> tool:dsh:lead:call_536d02f637a44882b5cb7a94 -> tool:dsh:lead:call_c5a3aa34d69d4f6c9296ea66 -> tool:dsh:lead:call_c554cd2c188f4fa793269ba0 -> tool:dsh:lead:call_9aae0848f5c44ba7abf73b77 -> tool:dsh:lead:call_c34f6e037785435a950fa461 -> tool:dsh:lead:call_b5941f90fad34ac9968b9a40
- 关键路径耗时：2.387
- Makespan：242.814
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
