# Workflow 可观测性报告

- Trial：`MP15__T44Kqj4__env`
- Task：`MP15`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（48 节点 / 47 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：48；执行边：47（observed=0，inferred=47）
- Execution Trace Graph：`observed`；temporal_next 边 47，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_376dd0081f8a426b810f4788 -> tool:dsh:lead:call_b741d37c91b4477da6ae4ffe -> tool:dsh:lead:call_94129ee2cc2046f5804fc86a -> tool:dsh:lead:call_810bae9a75a04d51ade33e44 -> tool:dsh:lead:call_7d7b436245444e179f735027 -> tool:dsh:lead:call_deb7863deebc4bfdaf9a1e71 -> tool:dsh:lead:call_c42d56abc3df494c8300db59 -> tool:dsh:lead:call_069c233ef64142cf9a396d8e -> tool:dsh:lead:call_a51619d1ff1040d69746d7d4 -> tool:dsh:lead:call_37737132ff9b4093b5ffdeca -> tool:dsh:lead:call_6444decdbeae48efbd084af5 -> tool:dsh:lead:call_24595d9081504d6288629e65 -> tool:dsh:lead:call_ecbefc28687c449684e8e2c4 -> tool:dsh:lead:call_2c89c8e5769549708bfaacf7 -> tool:dsh:lead:call_c507084302024099b3e24e57 -> tool:dsh:lead:call_3402523e89154c2abcc123da -> tool:dsh:lead:call_4c8e7cc4a13d40248472281e -> tool:dsh:lead:call_7c6d424268c34e5c8d816f2b -> tool:dsh:lead:call_7bab0db2d85842fb87f0ea30 -> tool:dsh:lead:call_05b05c50a22049829e046076 -> tool:dsh:lead:call_5ee924af6888491c9f9915a9 -> tool:dsh:lead:call_83b269d3b54b4e99a73786b7 -> tool:dsh:lead:call_153399cddbb845c99d54bd23 -> tool:dsh:lead:call_5dad7291bea94be98e5b5931 -> tool:dsh:lead:call_4ece41fd7ba04cf9bb6df957 -> tool:dsh:lead:call_3c413e2920ec4f87952722f4 -> tool:dsh:lead:call_3dbc055bf37744c38d73c523 -> tool:dsh:lead:call_208deb5594a044d8ad369111 -> tool:dsh:lead:call_1d79c85bf3694c25921f5f17 -> tool:dsh:lead:call_d6f69164d6474deab10de6ae -> tool:dsh:lead:call_d832b2913f8b45f48bb2a432 -> tool:dsh:lead:call_6529b4d680f449a8a7f8c925 -> tool:dsh:lead:call_c10bfd511cdc4523932026a5 -> tool:dsh:lead:call_5b552b3f31cd4c31922efcfb -> tool:dsh:lead:call_e4669587b5394ee59126e505 -> tool:dsh:lead:call_4fee36504a174fd1846686f9 -> tool:dsh:lead:call_f5949e2e58ca4124ab423f95 -> tool:dsh:lead:call_7cd8d005916d4faba24caf7e -> tool:dsh:lead:call_7de63e5453844cd181bd66f4 -> tool:dsh:lead:call_2095564a55104396add33be5 -> tool:dsh:lead:call_bfe53e4c4def4e20ad66a82b -> tool:dsh:lead:call_0a85709b172e421d9b59464a -> tool:dsh:lead:call_a5b62d961eea4cf5af8594e4 -> tool:dsh:lead:call_e91785de0f7449669f1663a5 -> tool:dsh:lead:call_8f637aa3d0ef4a4bbe6de171 -> tool:dsh:lead:call_a0cf2f2db8ff42b085832172 -> tool:dsh:lead:call_b26707a1c7e94e0c9bc50586
- 关键路径耗时：1.801
- Makespan：564.181
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
