# Workflow 可观测性报告

- Trial：`MP16__D4C2X5N__env`
- Task：`MP16`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5635a9298ca54c798f8dc685 -> tool:dsh:lead:call_84a1401cf789445e97a7b831 -> tool:dsh:lead:call_8b2ab7b8dec1403bbfa6cf11 -> tool:dsh:lead:call_66af9d671173419c85ebc9bd -> tool:dsh:lead:call_a58fcf0b1d074efbab3a8e74 -> tool:dsh:lead:call_9db3852e83e5448898a957e1 -> tool:dsh:lead:call_785301bbfa8647c68e66028e -> tool:dsh:lead:call_415a72d3f6b54822af7cdc1a -> tool:dsh:lead:call_19664d5f29bc44e99e253b75 -> tool:dsh:lead:call_6ee8390716574d4096a719d3 -> tool:dsh:lead:call_2330486fee544aadbab96fc6 -> tool:dsh:lead:call_5843123d4cde415782f1bc3c -> tool:dsh:lead:call_c295ebb4a60e4d69a9b76c6d -> tool:dsh:lead:call_464dcd189b35405895ffa609 -> tool:dsh:lead:call_b437307a877f43f99e431ba4 -> tool:dsh:lead:call_df1077952d4e416fb5ed13a1 -> tool:dsh:lead:call_a9ff1ea7068c44e3b78ba21e -> tool:dsh:lead:call_349bcfe864bf4754932f6bf3 -> tool:dsh:lead:call_59762d647cd8448f8a696378 -> tool:dsh:lead:call_f7c1077abcd44c668929f622 -> tool:dsh:lead:call_09e1128908ba4fed822f59ee -> tool:dsh:lead:call_fd6d67eca3544190bbba947f -> tool:dsh:lead:call_4dcd1ac690e74ab0a85334ad -> tool:dsh:lead:call_6b05c393813749a9856c4be4 -> tool:dsh:lead:call_8c8d09746d2944e9b18f6eff -> tool:dsh:lead:call_fa41334ab89b4e03b97f350d -> tool:dsh:lead:call_a52b3c5452904f92ab9376a4 -> tool:dsh:lead:call_2f719332966e4f19a744cb23 -> tool:dsh:lead:call_a352e5a1a1864a89b209eb5a -> tool:dsh:lead:call_fb6db41a7765460986e9bb59
- 关键路径耗时：1.232
- Makespan：307.472
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
