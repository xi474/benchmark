# Workflow 可观测性报告

- Trial：`MP17__mwAtcUr__env`
- Task：`MP17`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5cd8c6fba3b6477ab1faee95 -> tool:dsh:lead:call_ad5d7a91ab1f4d2eb013d30c -> tool:dsh:lead:call_bd4e7b561de34e7f83a4fa99 -> tool:dsh:lead:call_623605695ca94adfb29ff0ee -> tool:dsh:lead:call_f796f00536184b65b5b279f2 -> tool:dsh:lead:call_de05d49322094ac7ba19a52d -> tool:dsh:lead:call_b6435f7019374cedb25749ec -> tool:dsh:lead:call_fddcec4c58ee428fa0528363 -> tool:dsh:lead:call_02927eb782244358a17b6331 -> tool:dsh:lead:call_0d13de8c8cca4db68ce3f3b2 -> tool:dsh:lead:call_f878c2d710b448568c8d211a -> tool:dsh:lead:call_6b38a9d455a44fcc9eec6a5b -> tool:dsh:lead:call_37549efe62ba426a98ff78b5 -> tool:dsh:lead:call_725a40ce26d54086a7dd8602 -> tool:dsh:lead:call_4dcde610736a4adcaef50be8 -> tool:dsh:lead:call_ca521f2e19574ccfa632afdd -> tool:dsh:lead:call_f2c0ba8d47144185bae72c5c -> tool:dsh:lead:call_5c65234c07d24235925be401 -> tool:dsh:lead:call_cd23878d6a8549a1bed1f324 -> tool:dsh:lead:call_c88902c70cb1423e838b376d -> tool:dsh:lead:call_c488defb901540c19fe159b4 -> tool:dsh:lead:call_0bf1d5f3f96042bb87a78428 -> tool:dsh:lead:call_63fb00ed11864bd98e4309be -> tool:dsh:lead:call_dfd3f44c95974c419f1f2c09 -> tool:dsh:lead:call_b2b5c2b4b7104bc29bbca54c -> tool:dsh:lead:call_7195e977fd684644ac36a558 -> tool:dsh:lead:call_6d8cab390a7f48759b93e6dc -> tool:dsh:lead:call_80e4e44c1ccb47fb85f02630 -> tool:dsh:lead:call_29cc10ca489f41f7b6868c55 -> tool:dsh:lead:call_dec756a075d3434f860ffa9d -> tool:dsh:lead:call_cb1cf0f7e46b4a65a0e63925 -> tool:dsh:lead:call_017afc8a355f46cdb7fbec2b -> tool:dsh:lead:call_dd46e596b3ec4bbfae3b285c -> tool:dsh:lead:call_7929cc6e1adc40f798b58fb8 -> tool:dsh:lead:call_71f71c5e6c4440a5b766969e -> tool:dsh:lead:call_fc65c0b7c8d44a09b5a13ac2
- 关键路径耗时：1.234
- Makespan：214.447
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
