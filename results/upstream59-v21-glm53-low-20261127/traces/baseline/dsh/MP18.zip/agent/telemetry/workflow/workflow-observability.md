# Workflow 可观测性报告

- Trial：`MP18__TPPhazV__env`
- Task：`MP18`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（30 节点 / 29 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：30；执行边：29（observed=0，inferred=29）
- Execution Trace Graph：`observed`；temporal_next 边 29，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_8f392a53d41a400082f01a3c -> tool:dsh:lead:call_aa36c6a3b0784e7fa6c3aec0 -> tool:dsh:lead:call_27bcff5e969e428d90df4eda -> tool:dsh:lead:call_afe59badd25d41049aacaf95 -> tool:dsh:lead:call_fdfb2646867e44dbb0dcee47 -> tool:dsh:lead:call_832fa7a0e86a4a739a9180a2 -> tool:dsh:lead:call_4dbf73a804b142bb8ab01a5a -> tool:dsh:lead:call_f9614d4f5f5543bbb448bf81 -> tool:dsh:lead:call_9eb95290ee354ce99118e8d6 -> tool:dsh:lead:call_c02b7ac487dd468b8e41c505 -> tool:dsh:lead:call_4b6b59e1763e4ef6982171d7 -> tool:dsh:lead:call_b496dd90a7f641d9a3132842 -> tool:dsh:lead:call_837977f49bd441dea676cd92 -> tool:dsh:lead:call_3967df2bdc244ee88406bd61 -> tool:dsh:lead:call_0f56a122d5134c139278e161 -> tool:dsh:lead:call_5be54a4441004078beb1b4b9 -> tool:dsh:lead:call_47aa36d59b574bb692ef396b -> tool:dsh:lead:call_6c842f476f3b47cb9deeb55b -> tool:dsh:lead:call_71d436749c7d43578e29e6bc -> tool:dsh:lead:call_399e646f0ae9422eac31779c -> tool:dsh:lead:call_63095ec8e7284a7698ff6ad9 -> tool:dsh:lead:call_db571a54e01044a7ab862169 -> tool:dsh:lead:call_181d2b67292f4538a8118a58 -> tool:dsh:lead:call_b61c3d1d4d6b4584a9866814 -> tool:dsh:lead:call_8e09fe6f68ab4706b61e8651 -> tool:dsh:lead:call_631c6d3c89e948fd9d1be5dc -> tool:dsh:lead:call_0632ef6f163c444dbe9fcd4b -> tool:dsh:lead:call_adc189a9d2e5403985462514 -> tool:dsh:lead:call_9e7f7cd6cbf44dd3b867c2de
- 关键路径耗时：1.031
- Makespan：250.567
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
