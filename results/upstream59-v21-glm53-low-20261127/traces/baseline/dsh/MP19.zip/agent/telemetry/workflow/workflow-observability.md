# Workflow 可观测性报告

- Trial：`MP19__RsFgBDQ__env`
- Task：`MP19`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_614c1127a5a84e018786ce90 -> tool:dsh:lead:call_c1305dc74f5c4b0d879fdb66 -> tool:dsh:lead:call_6d50a9e9e24a48c5a4e9a4ac -> tool:dsh:lead:call_0088f61b42d44602921e3d57 -> tool:dsh:lead:call_05aabd7f5a894cb48e8cbefa -> tool:dsh:lead:call_2ec5928fd3ef4d8fa855cff5 -> tool:dsh:lead:call_233ac89cf41d474397ff3d69 -> tool:dsh:lead:call_3070a025d0ce448996a8354d -> tool:dsh:lead:call_64f3e29865ed4e31a8c0a1ed -> tool:dsh:lead:call_054e3a253ecd4d2c908061a5 -> tool:dsh:lead:call_004ebdaba3dd421eafc32529 -> tool:dsh:lead:call_3b3443cfb6ae4c50a24a7180 -> tool:dsh:lead:call_fa50193a1eb440e487247e22 -> tool:dsh:lead:call_8ba55396308e4a3ab03307fd -> tool:dsh:lead:call_134a0d5d1ddf4b3a85859f4c -> tool:dsh:lead:call_035daf1da7cf4186a35e8f80 -> tool:dsh:lead:call_463dffa1275b47ee9e91d0c6 -> tool:dsh:lead:call_e7c5652a3a974a08b2d34468 -> tool:dsh:lead:call_86b21336804a441f8d9106c1 -> tool:dsh:lead:call_01828a2e25a84777828e3fbc -> tool:dsh:lead:call_5c10a70264444f58bfb76461 -> tool:dsh:lead:call_f06eb52cbf7f4a2db95cad54 -> tool:dsh:lead:call_4f57c51ca13a4dfeb0d11dcb -> tool:dsh:lead:call_472915112bd34b1081b4c8df -> tool:dsh:lead:call_dc563a4159c84f51bf01472a -> tool:dsh:lead:call_7c65736ccf76448cbe119ef5 -> tool:dsh:lead:call_8678b7c60649400fa4d34bb7 -> tool:dsh:lead:call_a20a7ffe8fdc4a58836fea6a -> tool:dsh:lead:call_97ca255bd69e4995aa0725d8 -> tool:dsh:lead:call_2ccf9980f88d49e9a6915b12 -> tool:dsh:lead:call_0dc0716775cd47fdbf6ab376 -> tool:dsh:lead:call_b8c6228181194cde9f5018cc -> tool:dsh:lead:call_1365573a77a746749d9646e0 -> tool:dsh:lead:call_e153f1592b5049fa880283d7 -> tool:dsh:lead:call_ec85a9f4739b4e00aecbce3e -> tool:dsh:lead:call_9e102520591c43cbaad5178d -> tool:dsh:lead:call_811e5363f5dd468c956be08e -> tool:dsh:lead:call_ffb1ece7fe334d538686e969 -> tool:dsh:lead:call_1d54a9c6d0ff460d8ab13c36 -> tool:dsh:lead:call_706aacb2aff9409486505c98
- 关键路径耗时：1.767
- Makespan：472.043
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
