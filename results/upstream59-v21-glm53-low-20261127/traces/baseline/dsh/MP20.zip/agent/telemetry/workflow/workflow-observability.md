# Workflow 可观测性报告

- Trial：`MP20__om9pCWb__env`
- Task：`MP20`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_c924e1f8c87649c0b5eb1f82 -> tool:dsh:lead:call_8285d72bbed04d5d91adb467 -> tool:dsh:lead:call_0f6e52a341104cb198755b75 -> tool:dsh:lead:call_fd53a1a18b4b45fc8bccb0bf -> tool:dsh:lead:call_9242c8842035473e9e5cfbc2 -> tool:dsh:lead:call_34b21d475dc740828b8a2f2c -> tool:dsh:lead:call_a130b1d6c1754468b1955d7a -> tool:dsh:lead:call_47349191b7644f80a3c7f88c -> tool:dsh:lead:call_a901e654ed474af9ad987a67 -> tool:dsh:lead:call_359c0ea7c68441d9a8fc4bb3 -> tool:dsh:lead:call_5ed780eec2c44df488dc741e -> tool:dsh:lead:call_31d576b93b0941d4b256e7fe -> tool:dsh:lead:call_b076ee141d9843a7997bb6cf -> tool:dsh:lead:call_9611978cdf074a2a8ef16529 -> tool:dsh:lead:call_0645d359b7f24d6fa971f9c0 -> tool:dsh:lead:call_ee339f0188e7454a9da7b4b3 -> tool:dsh:lead:call_bde735e2618a4313bd99a4a5 -> tool:dsh:lead:call_9f5293ea86074f9d80b524be -> tool:dsh:lead:call_03d3ceb16b324448ae46d9c0 -> tool:dsh:lead:call_87d70557ca024b45a4909f6b -> tool:dsh:lead:call_53a5aaae6c62447cb119f1f3 -> tool:dsh:lead:call_afd758e7a83d4c6c8954329f -> tool:dsh:lead:call_9b801eb1bb4d4c2d809d00a7 -> tool:dsh:lead:call_c9259057a8644d72b4194edd -> tool:dsh:lead:call_266f323432c04432b796892a -> tool:dsh:lead:call_0b4258f801d04f338c1d4f79 -> tool:dsh:lead:call_f28ae6a6bd6e4cb8ac69279b -> tool:dsh:lead:call_9c2c5e76bf304342afe71ad2 -> tool:dsh:lead:call_0913f6c7009c49cebc3ff800 -> tool:dsh:lead:call_3a67bbc9733b4d38950d32fc -> tool:dsh:lead:call_6308a83ddaa841aea3e82cf7 -> tool:dsh:lead:call_bb64ef256c4d4fd7a5b504b0 -> tool:dsh:lead:call_643ca06e4a284b29a829713c
- 关键路径耗时：1.366
- Makespan：348.809
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
