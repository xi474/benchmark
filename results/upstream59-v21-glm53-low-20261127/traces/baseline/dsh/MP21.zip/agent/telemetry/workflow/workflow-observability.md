# Workflow 可观测性报告

- Trial：`MP21__Y2oNr84__env`
- Task：`MP21`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_ba1d7d2c60dd4a1a808e67d9 -> tool:dsh:lead:call_e1ff9cb2c7b2462ba5d56847 -> tool:dsh:lead:call_109e624c17cc48bebb73d0fc -> tool:dsh:lead:call_a702dfedecb34c4eb78700d4 -> tool:dsh:lead:call_9ba75dc028004463b165c5e9 -> tool:dsh:lead:call_6565373f91ff488f936a79e0 -> tool:dsh:lead:call_2829661f334b449baf414812 -> tool:dsh:lead:call_215d441aeb7b4b4cbc1b4f11 -> tool:dsh:lead:call_3efecd7b22574c4ea9e8efab -> tool:dsh:lead:call_e5fe4b89175d4e4e91fed080 -> tool:dsh:lead:call_c00d685f13a245bf83813dcf -> tool:dsh:lead:call_6e1c6b00271748de803f7697 -> tool:dsh:lead:call_19602157508f4a08a0108814 -> tool:dsh:lead:call_0cd5e71510e648ae9220b331 -> tool:dsh:lead:call_87c906f3043d4e82b7cc66db -> tool:dsh:lead:call_210de4d481724e04a96f8801 -> tool:dsh:lead:call_e378a66d5bea46b4922dde9d -> tool:dsh:lead:call_90e796e8fdcf45ac8442deda -> tool:dsh:lead:call_904c23ea66ba43f88e79f1c5 -> tool:dsh:lead:call_84cf92abae554fb2a165489d -> tool:dsh:lead:call_314f61fa9e2541c8b57bc970 -> tool:dsh:lead:call_75601d6874884741a60c9dc8 -> tool:dsh:lead:call_0deabff8ecc44bf4919d0936 -> tool:dsh:lead:call_e25e38980d5c473e9c092237 -> tool:dsh:lead:call_a10f6f3afca344b1b1502e27 -> tool:dsh:lead:call_845e068cb6c54d6987f9b5fb -> tool:dsh:lead:call_821c93cfcac44ac99ecce4b5 -> tool:dsh:lead:call_9eb25c7d4e6145cf9340ffc4 -> tool:dsh:lead:call_8918ffb90cc64aec8daafcea -> tool:dsh:lead:call_7feea12687c84255ab65c855 -> tool:dsh:lead:call_0fb8ae59b3ed4d3386eb5ed8 -> tool:dsh:lead:call_3384a19212bc48938ed4fcd6 -> tool:dsh:lead:call_901d543dadf944f69c94559b -> tool:dsh:lead:call_2fdb66e38e164a7ca79c080a -> tool:dsh:lead:call_b68afcc8b686435a805b003c
- 关键路径耗时：1.165
- Makespan：284.973
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
