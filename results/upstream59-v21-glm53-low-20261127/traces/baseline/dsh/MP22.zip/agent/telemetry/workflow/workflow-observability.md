# Workflow 可观测性报告

- Trial：`MP22__RPnPUUm__env`
- Task：`MP22`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（20 节点 / 19 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：20；执行边：19（observed=0，inferred=19）
- Execution Trace Graph：`observed`；temporal_next 边 19，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_627446a99c8445adbf91a493 -> tool:dsh:lead:call_0530d623ac7448a295f5d830 -> tool:dsh:lead:call_5c3b23ed42ba4cce8dba5c43 -> tool:dsh:lead:call_626594a8180e47129f1ab5b6 -> tool:dsh:lead:call_4a0b099ad20e47019d14ee28 -> tool:dsh:lead:call_326ef2c96ebd4a09bc75ad5f -> tool:dsh:lead:call_86efe23b848447dda8520ef5 -> tool:dsh:lead:call_f854c8bc68834f9b880b69ab -> tool:dsh:lead:call_b6900e8d69df4365baa01312 -> tool:dsh:lead:call_dae40c54584847989ef270c5 -> tool:dsh:lead:call_6aabcd1a3b99462e9363406a -> tool:dsh:lead:call_7a19b51c7da84cb48a0f6abb -> tool:dsh:lead:call_3de6801d0dd94ad588993649 -> tool:dsh:lead:call_093bd7fd1acd4de1878b40da -> tool:dsh:lead:call_f57d189cd740400d8b756505 -> tool:dsh:lead:call_636d8bc9bee945f6b7a0a209 -> tool:dsh:lead:call_cf894856226649849733792a -> tool:dsh:lead:call_a358985cf20d4315b765ba9d -> tool:dsh:lead:call_8a92f0adfa1a45a4a2943cee
- 关键路径耗时：1.268
- Makespan：235.199
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
