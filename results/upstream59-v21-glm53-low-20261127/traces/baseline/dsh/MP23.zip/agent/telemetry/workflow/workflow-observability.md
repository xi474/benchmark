# Workflow 可观测性报告

- Trial：`MP23__rsE3LSY__env`
- Task：`MP23`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_6d537ce77d704d45b5e5516e -> tool:dsh:lead:call_c69b4eb1535f4dfb8e9f3885 -> tool:dsh:lead:call_a42c6194c8b3469e9455395b -> tool:dsh:lead:call_e7cccf44c3264c6bacb54d1f -> tool:dsh:lead:call_d2920b314f664fbeb2fb929a -> tool:dsh:lead:call_557cbaa962684406bdd6e15c -> tool:dsh:lead:call_183f9c4fa75a40c9baf620c4 -> tool:dsh:lead:call_5f2dc24d5d8a4075b4a04c26 -> tool:dsh:lead:call_9fa88144419f42dfb2ad02fb -> tool:dsh:lead:call_cf0e0503422545aa94bf4bdb -> tool:dsh:lead:call_82178551524a42cc8bac5a4b -> tool:dsh:lead:call_8933893868514e92af36e958 -> tool:dsh:lead:call_12581f5272904d7480cfc7b2 -> tool:dsh:lead:call_d8e41b626cc54e8ba363dd34 -> tool:dsh:lead:call_282dbb56cb8a4f5c8be539e7 -> tool:dsh:lead:call_0e0cdda5809c4be0aacabd90 -> tool:dsh:lead:call_b829325913ed44a689bcc614 -> tool:dsh:lead:call_ae9e8266119b410dacf99433 -> tool:dsh:lead:call_555a6b1b75ab49ba98e33614 -> tool:dsh:lead:call_17eebc206b9b48aaa8afd38e -> tool:dsh:lead:call_c2a74f16f7074589aab5a801 -> tool:dsh:lead:call_d98cd4fb531b4744a67314d7 -> tool:dsh:lead:call_86784571ddb94da69b4b0fcc -> tool:dsh:lead:call_5eb1a847cfad44bb84e0d921 -> tool:dsh:lead:call_06f066c298b64401bd24c8ff -> tool:dsh:lead:call_94e05b50fcbe424e83160e32 -> tool:dsh:lead:call_2119d9aa34a748a49d46f366 -> tool:dsh:lead:call_73425c4cf976463c8e66b6d9 -> tool:dsh:lead:call_65e8a418c8c94c6c9dae1c26 -> tool:dsh:lead:call_98475d0a1e2e42f78af51e1f -> tool:dsh:lead:call_9657a0be2fc74e5ba251b96a -> tool:dsh:lead:call_c7514c0319924c529eecc610 -> tool:dsh:lead:call_5e5c3df7c0d14f60b86e70ca
- 关键路径耗时：0.972
- Makespan：279.015
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
