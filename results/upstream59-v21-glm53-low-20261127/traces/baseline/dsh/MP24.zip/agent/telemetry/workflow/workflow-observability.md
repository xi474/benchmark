# Workflow 可观测性报告

- Trial：`MP24__ABs9wzB__env`
- Task：`MP24`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（27 节点 / 26 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：27；执行边：26（observed=0，inferred=26）
- Execution Trace Graph：`observed`；temporal_next 边 26，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_12b633cffb9b4d82a5d39f0a -> tool:dsh:lead:call_3b573477772a415faffc215d -> tool:dsh:lead:call_c264942416eb48e89d60397d -> tool:dsh:lead:call_3f6e34f59cd64f4d9ef8f039 -> tool:dsh:lead:call_5e6b6f0e277e4c0e8414a596 -> tool:dsh:lead:call_bb83c73fe1164ed399b03b0b -> tool:dsh:lead:call_cb2a175641754ac2b21fde14 -> tool:dsh:lead:call_acf71b0d9ccd46569bd845bb -> tool:dsh:lead:call_7db8d1ece66044a0ae9bee5a -> tool:dsh:lead:call_920a9f80010a4e4d8fd330c4 -> tool:dsh:lead:call_e14542f654e64b6fa5fd5ac9 -> tool:dsh:lead:call_2c78d5e42f334f5b9cb62366 -> tool:dsh:lead:call_f633afc4d0d54c52997b972d -> tool:dsh:lead:call_b756ec3b4a554673bfbe8f4d -> tool:dsh:lead:call_a10e93bf2a6b4c498e73286a -> tool:dsh:lead:call_3a2d611c5244484b9894edf7 -> tool:dsh:lead:call_83b2cd34ad914c27afc64549 -> tool:dsh:lead:call_d19a98f564ae409e98f030ff -> tool:dsh:lead:call_b090b0c54749439daa2dab6f -> tool:dsh:lead:call_996ed70d8eba479db380660f -> tool:dsh:lead:call_b9709d58fb3744b99ac40d58 -> tool:dsh:lead:call_c33822ce62034839905a051e -> tool:dsh:lead:call_ee67929e0c844e1cb0af68ce -> tool:dsh:lead:call_ce6424c154c54de78a226f9c -> tool:dsh:lead:call_47b81b540da845c6b71a5503 -> tool:dsh:lead:call_57bb6281811e4d3487b19ef9
- 关键路径耗时：1.265
- Makespan：311.265
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
