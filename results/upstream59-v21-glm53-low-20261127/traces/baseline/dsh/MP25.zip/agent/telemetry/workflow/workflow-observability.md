# Workflow 可观测性报告

- Trial：`MP25__HvGYCCN__env`
- Task：`MP25`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_94d7968a20f245ef9c5c2c95 -> tool:dsh:lead:call_6f52161a6f19428fa859b6fe -> tool:dsh:lead:call_2b17421866924ba0b1253dd5 -> tool:dsh:lead:call_116351197a72469eb2951e34 -> tool:dsh:lead:call_c8ec541ed82e48cb84225882 -> tool:dsh:lead:call_817ad2b616ae48c9bdbb182f -> tool:dsh:lead:call_80bc2a98e0c2412487922d9c -> tool:dsh:lead:call_7ec5b839e38d48b5a294ec01 -> tool:dsh:lead:call_04318f7c70914031a33ee135 -> tool:dsh:lead:call_dfb78f1ea4df44cfac268143 -> tool:dsh:lead:call_d229c7155aa340d0ba8b67ce -> tool:dsh:lead:call_d9e6f2b593d14394bfb964dd -> tool:dsh:lead:call_811138760fb24f439ccec7d6 -> tool:dsh:lead:call_9b7fb6c9f9fa4008a1910e33 -> tool:dsh:lead:call_22192defa5664d429a4fef29 -> tool:dsh:lead:call_191de787703843be8affcdcc -> tool:dsh:lead:call_11df80f13c0245dd99b74ada -> tool:dsh:lead:call_24e0c6a6e054481c9925e22b -> tool:dsh:lead:call_09b9ae14872a422fa332b1fd -> tool:dsh:lead:call_8a099b96d7a448e396efc887 -> tool:dsh:lead:call_5389cf17935143ec815cced8 -> tool:dsh:lead:call_e57383aee1a0424a8408e006 -> tool:dsh:lead:call_23d0c409fd114b65b61d5758 -> tool:dsh:lead:call_b06a47e019ef4cb691632bdd -> tool:dsh:lead:call_18075d1c8d4e45b4a907bff4 -> tool:dsh:lead:call_c895c8b45010435088c794b6 -> tool:dsh:lead:call_27eb6a03220a49488b6ce250 -> tool:dsh:lead:call_956753583d694b28b3f9ec12 -> tool:dsh:lead:call_aa610e9a6fef4e26babb8ae8 -> tool:dsh:lead:call_0c3f26bb056647f982f5208e -> tool:dsh:lead:call_6cbae0236c5f4b31acb1aa9a -> tool:dsh:lead:call_e600d9609b9b450d95b799e4 -> tool:dsh:lead:call_e03ef1850deb428392521090 -> tool:dsh:lead:call_0d96e6f124bf45a6897aefc1
- 关键路径耗时：1.174
- Makespan：254.701
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
