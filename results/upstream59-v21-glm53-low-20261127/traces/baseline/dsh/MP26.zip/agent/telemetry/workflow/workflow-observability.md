# Workflow 可观测性报告

- Trial：`MP26__BV9YNqS__env`
- Task：`MP26`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_975d003551884e7db0da303d -> tool:dsh:lead:call_7fd70633812c40058fa94069 -> tool:dsh:lead:call_917dcdd71d494a64992a4af9 -> tool:dsh:lead:call_17591987608e4b9da339511c -> tool:dsh:lead:call_7d1af73b901d4422920f90a8 -> tool:dsh:lead:call_e54cbcc0b05148adadd254e8 -> tool:dsh:lead:call_6a723d64f11341048ed6aa5d -> tool:dsh:lead:call_c5423e0077d24bc4a5573680 -> tool:dsh:lead:call_ca3d2d1cc2304c0d9335c46f -> tool:dsh:lead:call_2e908c7bf0054247934f4d4b -> tool:dsh:lead:call_491b8b805e5642c797ac832d -> tool:dsh:lead:call_7ada19e57a9843879430df1a -> tool:dsh:lead:call_361d4524b2dd46c6addeb179 -> tool:dsh:lead:call_3a1f6e50008a4cee86f0cbba -> tool:dsh:lead:call_3d4c6fbd732d42c5b07b4a26 -> tool:dsh:lead:call_c86a67e475224dbfac32c8ad -> tool:dsh:lead:call_6f71cfb783fa474698392981 -> tool:dsh:lead:call_f61b5bc0ccad45b081f059f8 -> tool:dsh:lead:call_d48647b5895c443f944918ab -> tool:dsh:lead:call_fda9daef383f4fc9b901f565 -> tool:dsh:lead:call_9a64059ed61b4d6f858de211 -> tool:dsh:lead:call_6b1b6253d05348fa99391fc6 -> tool:dsh:lead:call_2378984ee47149bdaca8855e -> tool:dsh:lead:call_cc387bf1be0541fabbadc73d -> tool:dsh:lead:call_1c71c5e924b24ba7be5a9f40 -> tool:dsh:lead:call_0ebddeadae2a4691ad585dfc -> tool:dsh:lead:call_422c144708ab4e3e8d9de001 -> tool:dsh:lead:call_c2399907e49b437d887dcff4 -> tool:dsh:lead:call_6d58476a842f4ddcb2d45381 -> tool:dsh:lead:call_0da7cd69face4e8c9fb4db00 -> tool:dsh:lead:call_a3f352c854c54e58ba85bd90 -> tool:dsh:lead:call_db8393e80bca4b869a811ee8 -> tool:dsh:lead:call_9052d2079e144eca85314843
- 关键路径耗时：1.228
- Makespan：335.361
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
