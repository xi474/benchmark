# Workflow 可观测性报告

- Trial：`MS11__8pyWpdW__env`
- Task：`MS11`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（21 节点 / 20 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：21；执行边：20（observed=0，inferred=20）
- Execution Trace Graph：`observed`；temporal_next 边 20，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_09e02922af2c4a0f823b76ca -> tool:dsh:lead:call_5d01e2e6b6f847b48341f672 -> tool:dsh:lead:call_775ed38ef5cf430985bdd4dc -> tool:dsh:lead:call_a0836a8724d94290ace45b69 -> tool:dsh:lead:call_6babfbf54b0747a19144a48f -> tool:dsh:lead:call_408507c8c200456196361cbc -> tool:dsh:lead:call_6efb1e00cba04d638e46645c -> tool:dsh:lead:call_7a77201d0e21470c9f1e83f5 -> tool:dsh:lead:call_6ddd0eb192c44db88cb71255 -> tool:dsh:lead:call_4ddf00ab94cc4ba7aaa142f6 -> tool:dsh:lead:call_79d0a74a2ef8464597a8ef4f -> tool:dsh:lead:call_90b95feeb4ff4b5da9dfa182 -> tool:dsh:lead:call_dbb52484fec3424b828225f2 -> tool:dsh:lead:call_7a3e15f0bcaa4d0aa3c3cf60 -> tool:dsh:lead:call_fb1df63e732f4b53a1a0086a -> tool:dsh:lead:call_395eb883b41d45d48c319db9 -> tool:dsh:lead:call_6b82c93819844ec99559caff -> tool:dsh:lead:call_2b80c2f8cd55471e92bb4d2d -> tool:dsh:lead:call_a3013a7346074831a9f8ea8f -> tool:dsh:lead:call_3e839d2ea9ce4b6fbfc618ff
- 关键路径耗时：4.849
- Makespan：577.205
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
