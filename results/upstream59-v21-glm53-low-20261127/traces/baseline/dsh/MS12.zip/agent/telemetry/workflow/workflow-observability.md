# Workflow 可观测性报告

- Trial：`MS12__ND9Uxza__env`
- Task：`MS12`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_c6ea79238b744683aa38cf00 -> tool:dsh:lead:call_1bdf213011c04f92a31dee20 -> tool:dsh:lead:call_a040e19a326f43909a3764be -> tool:dsh:lead:call_a5a8139dfff24e55add85f24 -> tool:dsh:lead:call_8463d14f125649a196009ee4 -> tool:dsh:lead:call_4cc27f6d721d440cafb2a7f1 -> tool:dsh:lead:call_c1f6962dfd384aa3a5b08cc5 -> tool:dsh:lead:call_0eb42b333d1c4d4f8bdd26c3 -> tool:dsh:lead:call_0aa3d365688849f7ba433029 -> tool:dsh:lead:call_058c786e2dbc4e3ca14d99ad -> tool:dsh:lead:call_92f1dfe14a734f4aa6d259b9 -> tool:dsh:lead:call_0be04732c2604ec68e7e586e -> tool:dsh:lead:call_416c38986c9e47e9a98e166e -> tool:dsh:lead:call_5b0f2b617a1b4876882adca0 -> tool:dsh:lead:call_e66f65c43d4244799d31b375 -> tool:dsh:lead:call_50c6eb4f259a400d99919371 -> tool:dsh:lead:call_69ca57c832b642438a1a0722 -> tool:dsh:lead:call_eb28ff05c9904ae5b593b27e -> tool:dsh:lead:call_e82a0194dd424401841805ad -> tool:dsh:lead:call_1847699dd0f6456f820f08a8 -> tool:dsh:lead:call_fd579965ec9f44539d074bc2 -> tool:dsh:lead:call_d8be6e3362f44048b69be1d0 -> tool:dsh:lead:call_d2d4be32a1274b83958a25fc -> tool:dsh:lead:call_6184a82056b043919b6c252f -> tool:dsh:lead:call_0e54e5b419584d059343fcd9 -> tool:dsh:lead:call_cfe4abf7250445a6ac7a13a5 -> tool:dsh:lead:call_cd42123d650e4e6f92627e2c -> tool:dsh:lead:call_9d18bc3f01c542e5990e1f2e -> tool:dsh:lead:call_621507f6d89b4fe3b3ace0b3 -> tool:dsh:lead:call_77e1271a36fc4ed2834ead86 -> tool:dsh:lead:call_7216c44cb82f4fe99772f88f -> tool:dsh:lead:call_6d0d770ebd2b4f0898196597 -> tool:dsh:lead:call_7c4d80072ce2475984ef66c0 -> tool:dsh:lead:call_e91eb35dd71b47f8af663a84 -> tool:dsh:lead:call_058285977b0e4a2582c3e1c5 -> tool:dsh:lead:call_6480e29563434ec0a99493f1 -> tool:dsh:lead:call_226884b6346347f7a7414240 -> tool:dsh:lead:call_0a2bd65008654f1590a2235d -> tool:dsh:lead:call_29e7eae5f9034969bab3d0bb -> tool:dsh:lead:call_0961e28901e84de1b4383cf0 -> tool:dsh:lead:call_007ab2c9205b415d8d459e24 -> tool:dsh:lead:call_0b040d552b1a42cba0a251c9 -> tool:dsh:lead:call_c3f523575e594d61b2f2e141 -> tool:dsh:lead:call_bfd0ed06393848fabfe8bf93 -> tool:dsh:lead:call_8f25c393d47147cca16ec2dd
- 关键路径耗时：2112.764
- Makespan：3192.641
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
