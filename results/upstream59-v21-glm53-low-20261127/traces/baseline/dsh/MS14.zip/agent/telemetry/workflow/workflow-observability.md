# Workflow 可观测性报告

- Trial：`MS14__J3hBXEv__env`
- Task：`MS14`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_c3b6179e5ec6428cbf4b048b -> tool:dsh:lead:call_239b770fc99b431894b51d60 -> tool:dsh:lead:call_e413f2b38d0b4d1483081942 -> tool:dsh:lead:call_03c506c84ad644d891220a72 -> tool:dsh:lead:call_fd7bcc3a6f7048958b115e1a -> tool:dsh:lead:call_1af9a16b5b2e4b87a937e377 -> tool:dsh:lead:call_c082bb296f4d4706abdf89d3 -> tool:dsh:lead:call_da222b4a1b774e609bc81715 -> tool:dsh:lead:call_b056d73c6df24289a2cdf602 -> tool:dsh:lead:call_5f6e7d36e9cf4ba882e59e43 -> tool:dsh:lead:call_c6cdb7ddb8b141a68ebc1c3b -> tool:dsh:lead:call_2704e04cec154507973972dc -> tool:dsh:lead:call_e65b0898f72647358a472c84 -> tool:dsh:lead:call_b2e9cf651a084a3abcf38b49 -> tool:dsh:lead:call_5ce4e40f07324fdc981f7db3 -> tool:dsh:lead:call_1bdcb9d8d38c4883a184b927 -> tool:dsh:lead:call_4413cdeb004e416eb0dcd1b3 -> tool:dsh:lead:call_7e2006dcf9504ff6adc841bf -> tool:dsh:lead:call_911c31dc9a3a4ba880c6c831 -> tool:dsh:lead:call_fb7104c0a6824be6bef89d1c -> tool:dsh:lead:call_ac0f6a8857dc43b3828d95fd -> tool:dsh:lead:call_7dd99eb3e00348bbb74c05b3 -> tool:dsh:lead:call_42a784eb88b04b2dba3e3a77 -> tool:dsh:lead:call_fc47290de88b4fb59731a67e -> tool:dsh:lead:call_16cd3aab53fe4e2fbe297777 -> tool:dsh:lead:call_b8855ba8cd884bfdb54d710a -> tool:dsh:lead:call_738b807c8ccd4b81831a68e7 -> tool:dsh:lead:call_3139fb9ad4d74b7c809ede5b -> tool:dsh:lead:call_629a4d9b8a384afdae8e69ea -> tool:dsh:lead:call_496c0bd1a44e43d2b4231323 -> tool:dsh:lead:call_a1a4445ce83c4ee691dc1454 -> tool:dsh:lead:call_6200c4e7f5a240489469952a
- 关键路径耗时：566.434
- Makespan：1253.564
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
