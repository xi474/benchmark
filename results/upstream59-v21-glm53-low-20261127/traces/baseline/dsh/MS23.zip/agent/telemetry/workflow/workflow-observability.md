# Workflow 可观测性报告

- Trial：`MS23__ecvAiQg__env`
- Task：`MS23`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5a35e6d6874f4d3c9fae2aa1 -> tool:dsh:lead:call_2867e2375b134fc3a4b0a0c2 -> tool:dsh:lead:call_23e49876d1d448bea0a0eda9 -> tool:dsh:lead:call_0fb27c8daf254005bf202754 -> tool:dsh:lead:call_4d6a28d10e1b41a3ba0aa375 -> tool:dsh:lead:call_b0e10c19cc324f74b13e7bd7 -> tool:dsh:lead:call_4f1ab62b25ee4c7696b2fff4 -> tool:dsh:lead:call_6cda326bd5ba4ed9be1298cf -> tool:dsh:lead:call_b389897d9d4e4b2d81881696 -> tool:dsh:lead:call_6d2c366c1c8b404b89f86cde -> tool:dsh:lead:call_dd629d36bf0241088ebb2373 -> tool:dsh:lead:call_2634b561d6094b5cb855535d -> tool:dsh:lead:call_a1a41f5b617e46f5a07f1985 -> tool:dsh:lead:call_6d2fdbe7f0d64eda9f46934c -> tool:dsh:lead:call_4f1d91b2f792448a8a445bdd -> tool:dsh:lead:call_29b068769e434abba228c172 -> tool:dsh:lead:call_a028ad42cea94c6688b441ed -> tool:dsh:lead:call_a1855de6d71c45cb996cb358 -> tool:dsh:lead:call_55d6a953fc074ea7a635fd82 -> tool:dsh:lead:call_ad0f767fd3494e86a41d3aa7 -> tool:dsh:lead:call_92da809fed6f48a4ada590d6 -> tool:dsh:lead:call_a39eb1070fc04e77af6644ce -> tool:dsh:lead:call_3bf34f3bad584a23888da831 -> tool:dsh:lead:call_bc5a03b3694a407bb78001ce -> tool:dsh:lead:call_f6405dd52cf64948adc27145 -> tool:dsh:lead:call_4d82475193c64bf9aa992ad3 -> tool:dsh:lead:call_e6c37615deb24d4fa3dd1033 -> tool:dsh:lead:call_d9a8442b17ea465da799983e
- 关键路径耗时：5.068
- Makespan：750.252
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
