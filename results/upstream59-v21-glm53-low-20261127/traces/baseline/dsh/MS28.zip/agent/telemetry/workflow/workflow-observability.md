# Workflow 可观测性报告

- Trial：`MS28__BGkLW6J__env`
- Task：`MS28`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_ec3e6bf96e7f46ccb663cc25 -> tool:dsh:lead:call_b1d93c4849db4c1b9cbf7800 -> tool:dsh:lead:call_cf0449984e6e405cbca337d8 -> tool:dsh:lead:call_b6a7f42dac2b43de8984ec5f -> tool:dsh:lead:call_959fa71c8f604f4fbf48e493 -> tool:dsh:lead:call_f7f036b5e4c943b2b4bd3ba7 -> tool:dsh:lead:call_1969dc7fcbc84485b389a90b -> tool:dsh:lead:call_b545392975fb44ea8c1edb7f -> tool:dsh:lead:call_6884fc953dda4b70a642bc51 -> tool:dsh:lead:call_1d6e0a11cf0d4c8fa43f05fb -> tool:dsh:lead:call_d8fbeb40725c46719d1ce5f0 -> tool:dsh:lead:call_46df3ceeeddf4811ad875f02 -> tool:dsh:lead:call_063ccdfa2b5b43fd9387a66a -> tool:dsh:lead:call_8df78f4cc9b641a5bbfdbd4e -> tool:dsh:lead:call_4eee504f98b54b5a804834f1 -> tool:dsh:lead:call_670314cd162f47bdba7c42c9 -> tool:dsh:lead:call_ad0123f935014a129a06249d -> tool:dsh:lead:call_9f18e67c5d094d7a9a7c5675 -> tool:dsh:lead:call_8c28f383204f47c69546d427 -> tool:dsh:lead:call_fc690c5178bd4f9895ff02f6 -> tool:dsh:lead:call_afecab824a2a4c12b4c538e6 -> tool:dsh:lead:call_eaf78b1e1bb54280b84c0d2c -> tool:dsh:lead:call_d8414846912c450e90293a0f
- 关键路径耗时：1.019
- Makespan：262.939
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
