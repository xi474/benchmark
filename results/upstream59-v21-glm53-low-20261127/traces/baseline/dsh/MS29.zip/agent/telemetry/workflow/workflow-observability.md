# Workflow 可观测性报告

- Trial：`MS29__qfQCcHe__env`
- Task：`MS29`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（21 节点 / 20 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：21；执行边：20（observed=0，inferred=20）
- Execution Trace Graph：`observed`；temporal_next 边 20，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_c7f55efa63b947f7bb29fe8f -> tool:dsh:lead:call_f4253715657e40ea9bb407ca -> tool:dsh:lead:call_f6a779b7d2eb4c85a1deb509 -> tool:dsh:lead:call_2d242ee9c2a74ada9220113f -> tool:dsh:lead:call_39b53dd84f624ec89f62c93e -> tool:dsh:lead:call_0d66a688d28e4cdc90fe754d -> tool:dsh:lead:call_e17ba4e206c048cd9ada507d -> tool:dsh:lead:call_00681df7ff1a4186b506ae93 -> tool:dsh:lead:call_3b1ac436c66341af9d35d941 -> tool:dsh:lead:call_9db2c68a07184fb9839ad31d -> tool:dsh:lead:call_afcf7c7679f0479cbb630c2f -> tool:dsh:lead:call_bad76c3ff2734b799f73394a -> tool:dsh:lead:call_fb746b1e1c184514971438b9 -> tool:dsh:lead:call_106377b57f3c420382bd8f66 -> tool:dsh:lead:call_8e08ced6c05442af8cfb138e -> tool:dsh:lead:call_4adfe13c8fc346f4a1cf52a1 -> tool:dsh:lead:call_dbb31a6845ad449ca9c1ab76 -> tool:dsh:lead:call_70b3db0a74b04beaaaca84bd -> tool:dsh:lead:call_86db4ddc2ef9441b8f5546eb -> tool:dsh:lead:call_ee5b9bb3fcbc424da5ba1c24
- 关键路径耗时：0.874
- Makespan：196.347
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
