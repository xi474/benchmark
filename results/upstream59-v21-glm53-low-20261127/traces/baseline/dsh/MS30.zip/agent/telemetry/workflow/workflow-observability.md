# Workflow 可观测性报告

- Trial：`MS30__QhY4XBC__env`
- Task：`MS30`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（23 节点 / 22 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：23；执行边：22（observed=0，inferred=22）
- Execution Trace Graph：`observed`；temporal_next 边 22，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_59556d8649634599ba1b35f9 -> tool:dsh:lead:call_f94e1a1b936b43a6a8cf2671 -> tool:dsh:lead:call_ee7147193f9b45f4a012d384 -> tool:dsh:lead:call_04dfaa1748024ddabcc0f04d -> tool:dsh:lead:call_589c649eb857489292bf5152 -> tool:dsh:lead:call_f52bde3ef7544a6e8c800821 -> tool:dsh:lead:call_f2b0742ec7204284a76e26cb -> tool:dsh:lead:call_785fabbd6daa4428be5bf8fd -> tool:dsh:lead:call_9e31873c4e3041e9a6878bfa -> tool:dsh:lead:call_d5239caab6ec48f1b91d93a4 -> tool:dsh:lead:call_cbc4603dadbd4bca9f794982 -> tool:dsh:lead:call_59483b7c8b9f4f92b4942830 -> tool:dsh:lead:call_c4ba9742962f4cc79d96a6c6 -> tool:dsh:lead:call_5280e1bba60340d99eeccc10 -> tool:dsh:lead:call_b4cdd440696b4d489bf37060 -> tool:dsh:lead:call_ad7103357be444dc8c905cd7 -> tool:dsh:lead:call_9eb767bec5ed41f392598861 -> tool:dsh:lead:call_0a4a085a841a45f4bf39bf16 -> tool:dsh:lead:call_341b3fbb523e44f089ce2507 -> tool:dsh:lead:call_fc2d9cd70ea74121925ef828 -> tool:dsh:lead:call_5399291e37f04dcc9bf4a811 -> tool:dsh:lead:call_a745fe20814a4ae1aa109851
- 关键路径耗时：1.979
- Makespan：433.051
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
