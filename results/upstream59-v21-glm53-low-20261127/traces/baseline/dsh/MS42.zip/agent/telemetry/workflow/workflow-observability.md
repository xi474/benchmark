# Workflow 可观测性报告

- Trial：`MS42__goKEra8__env`
- Task：`MS42`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（22 节点 / 21 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：22；执行边：21（observed=0，inferred=21）
- Execution Trace Graph：`observed`；temporal_next 边 21，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_743797c030334fd8b8433457 -> tool:dsh:lead:call_97d1c73d55cf486daa29469f -> tool:dsh:lead:call_dad6901d54a34b6482c841ef -> tool:dsh:lead:call_56823ec4ee424c05aa39ffd5 -> tool:dsh:lead:call_5cc6a55fdb344049a6fc3752 -> tool:dsh:lead:call_20e467b7762e4e7fb5aeaf59 -> tool:dsh:lead:call_dc562c46de47467e9bf0ab5f -> tool:dsh:lead:call_0fae212628b94030a627647b -> tool:dsh:lead:call_e88c6e168a084c95a95a4c48 -> tool:dsh:lead:call_ce678fc0ba904d9db52952ab -> tool:dsh:lead:call_94a58d1ec90445a7beec3f94 -> tool:dsh:lead:call_36a4d9dc14a447288741199f -> tool:dsh:lead:call_32d751064b06406388869c90 -> tool:dsh:lead:call_dba88a105a594cf8a82c2b9c -> tool:dsh:lead:call_2a330cfb6b8a43f88f2d8d0d -> tool:dsh:lead:call_a229d4aa2fa8400cb2722293 -> tool:dsh:lead:call_83541c957c9b4d3c9d0a8e81 -> tool:dsh:lead:call_7872f0dc5aec490390fe7dcd -> tool:dsh:lead:call_15fbe299e6f7421bb07f95e1 -> tool:dsh:lead:call_c2e26f44373b4d928233c6be -> tool:dsh:lead:call_081599b1b9fd483da42ff29f
- 关键路径耗时：0.933
- Makespan：692.454
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
