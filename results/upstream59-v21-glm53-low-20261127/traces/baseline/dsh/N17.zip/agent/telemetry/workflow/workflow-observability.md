# Workflow 可观测性报告

- Trial：`N17__W8tMJdw__env`
- Task：`N17`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_a2edb4225bc740b881fdac4e -> tool:dsh:lead:call_0919d32bf5ee47f691d9e43b -> tool:dsh:lead:call_7d308da097994fc998a39820 -> tool:dsh:lead:call_3d0415ac4d8c40a79aff421d -> tool:dsh:lead:call_e7e41b7dd8c64af0930216ae -> tool:dsh:lead:call_4cedfcdfe8244557a07410db -> tool:dsh:lead:call_96fb5b15c4e842639aeea60a -> tool:dsh:lead:call_b82d374e186a4f2492f58456 -> tool:dsh:lead:call_79a1c779f92b45d7b8f206d8 -> tool:dsh:lead:call_0acf516bba774505bcebcca5 -> tool:dsh:lead:call_e8388c3027444f9f9722db5b -> tool:dsh:lead:call_7cc91aed46a747bbbe373156 -> tool:dsh:lead:call_54840a6cb9e94215b85b0b7b -> tool:dsh:lead:call_0dd9eb0bdb7045c49b5c30fe -> tool:dsh:lead:call_ed3ad1ea33614bce8cd27e08 -> tool:dsh:lead:call_581a014512604507bd412e39 -> tool:dsh:lead:call_4d94fa5568ff405a8bcc5d73 -> tool:dsh:lead:call_fdbd3d5331f943878d14b236
- 关键路径耗时：0.377
- Makespan：101.938
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
