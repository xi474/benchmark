# Workflow 可观测性报告

- Trial：`N22__fZ3bQdn__env`
- Task：`N22`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（27 节点 / 26 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：27；执行边：26（observed=0，inferred=26）
- Execution Trace Graph：`observed`；temporal_next 边 26，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_f75d958af172425c9aef573c -> tool:dsh:lead:call_511e229be10f45f5b81ef956 -> tool:dsh:lead:call_472177cace5e43e08a9cfcba -> tool:dsh:lead:call_b068cfa33de548d786c914e5 -> tool:dsh:lead:call_417225cba06c404e9c5a3e37 -> tool:dsh:lead:call_2cfa1424711c437e91405bbc -> tool:dsh:lead:call_a299797d875c49469052fae1 -> tool:dsh:lead:call_69f6128d9aea4aaa86e16b8f -> tool:dsh:lead:call_c3e254ed8ccd4988aa3fdcd5 -> tool:dsh:lead:call_85c590f2b9024dd192bbd091 -> tool:dsh:lead:call_38a103299485472a9a4c82d5 -> tool:dsh:lead:call_c7fe260f33e546ef9a93cfdf -> tool:dsh:lead:call_7109af781df64965bcf016e0 -> tool:dsh:lead:call_43965126ab434b889dff96c5 -> tool:dsh:lead:call_8be9e68c7a23484cba379730 -> tool:dsh:lead:call_066039dad9a6453c82c1d5a9 -> tool:dsh:lead:call_6df5def6b8df4de08fca09d6 -> tool:dsh:lead:call_99da26fd9890430098efd6d1 -> tool:dsh:lead:call_544ef391a5844060b9e3d31f -> tool:dsh:lead:call_6221743d250c41bea1ba6a0a -> tool:dsh:lead:call_c903edb4b43341d8bb0a0d56 -> tool:dsh:lead:call_e9aa2868c8124ee2a644031d -> tool:dsh:lead:call_d2c3e039cf874070b8df331f -> tool:dsh:lead:call_0b9c41d35daa436baae537d4 -> tool:dsh:lead:call_cd2ed8b8a0a94485bc6c1a95 -> tool:dsh:lead:call_061bf1f03ac94d3bbc7d5d34
- 关键路径耗时：1.323
- Makespan：159.521
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
