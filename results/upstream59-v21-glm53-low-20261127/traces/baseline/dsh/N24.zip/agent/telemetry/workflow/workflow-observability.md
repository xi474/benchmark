# Workflow 可观测性报告

- Trial：`N24__BKPP3tR__env`
- Task：`N24`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_0d62d86e40564eedb61a0888 -> tool:dsh:lead:call_cc16dd6f5d3140a7b8373185 -> tool:dsh:lead:call_e6be53ddcd5745ebb5066d48 -> tool:dsh:lead:call_575c83cf2fe440c3825fbb5f -> tool:dsh:lead:call_e6c51310ca944207ac8cf232 -> tool:dsh:lead:call_19797f3010de4916bad2814f -> tool:dsh:lead:call_a8773143081b4caf9018a39a -> tool:dsh:lead:call_2fabde4dafc84c2ebffef18b -> tool:dsh:lead:call_354017c59bc74007938b8a51 -> tool:dsh:lead:call_3101f85fd82a46d891cde3e9 -> tool:dsh:lead:call_917d0228495545d9bed86d0b -> tool:dsh:lead:call_41cb2a2586be4ace94e2ec1f -> tool:dsh:lead:call_e7b885b150884424a4d7e824 -> tool:dsh:lead:call_d2c98896e08d4c3e932dcf52 -> tool:dsh:lead:call_b487b98e9cb84a3581128fb0 -> tool:dsh:lead:call_68997b5f08444d31b913b69d -> tool:dsh:lead:call_1138f50ba5e44a26b9631ebd -> tool:dsh:lead:call_20025b5191204c6f8ca643f4 -> tool:dsh:lead:call_f14bbcdeaa6042798b65101b -> tool:dsh:lead:call_b34b86d261f1415eafe4a1f9 -> tool:dsh:lead:call_969e34d87d2343c5b22e5947 -> tool:dsh:lead:call_91203259e009404f959989a4 -> tool:dsh:lead:call_907d53ffea6849298e69ba1a
- 关键路径耗时：0.67
- Makespan：70.306
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
