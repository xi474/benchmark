# Workflow 可观测性报告

- Trial：`MP06__oVQNmP8__env`
- Task：`MP06`
- Harness：`langgraph`
- 规划等级：`P3`
- 规划来源：`model-explicit`
- 是否观察到模型显式计划：是

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：已观察到（5 节点 / 8 边，来源 `harness-generated`）
- Observed Model Plan DAG：已观察到（2 节点 / 1 边，来源 `model-explicit`）
- Execution DAG：已观察到（48 节点 / 5 边）
- Agent Topology：已观察到（3 Agent / 2 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P3`
- plan_source：`model-explicit`
- 证据事件：evt-000001-a299e7d5, evt-000006-57c81162, evt-000089-df079200, evt-000108-d393d77e
- Plan 快照数：1
- Plan revision 数：2
- 未观察到模型计划的原因：不适用

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：48；执行边：5（observed=5，inferred=0）
- Execution Trace Graph：`observed`；temporal_next 边 0，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`observed`；observed dependency 边 5，inferred dependency 边 0。
- 关键路径：node:planner -> node:parallel_workers -> node:synthesizer
- 关键路径耗时：282.544579
- Makespan：282.546552
- 子 Agent 并行宽度：1
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：agent
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | observed | 5 | 6 | tools | worker-t1, worker-t2 | 0.8 | 0.6 |
| Observed Model Plan vs Execution | observed | 2 | 6 | t1, t2 | agent, parallel_workers, planner, synthesizer, worker-t1, worker-t2 | 0.0 | 0.0 |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
