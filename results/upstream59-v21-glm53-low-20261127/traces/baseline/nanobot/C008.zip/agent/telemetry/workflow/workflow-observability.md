# Workflow 可观测性报告

- Trial：`C008__8oAGMKv__env`
- Task：`C008`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_caa5593d017446438cef85d0 -> tool:nanobot-harness-v3:call_f0829efb83ac45ae8624056d -> tool:nanobot-harness-v3:call_da9302d2d7584ceb9cdaf665 -> tool:nanobot-harness-v3:call_b0e7d027ab704bf68e0ca4ca -> tool:nanobot-harness-v3:call_e27990e32f6f4135b6dac4db -> tool:nanobot-harness-v3:call_27146faa263a4c71b165348f -> tool:nanobot-harness-v3:call_e5ad3c29f6be4561a988e6c4 -> tool:nanobot-harness-v3:call_945e5d2a39d84852a18ece15 -> tool:nanobot-harness-v3:call_67e654bc226f4624a46cc2a7 -> tool:nanobot-harness-v3:call_d9ca35de23e742e282e66652 -> tool:nanobot-harness-v3:call_ed4002af8274444c9d67144d -> tool:nanobot-harness-v3:call_575a0b10da27454190901b20 -> tool:nanobot-harness-v3:call_c9e08b896ce441cbb0471c1e -> tool:nanobot-harness-v3:call_096cedd41f2a49c4878f640b -> tool:nanobot-harness-v3:call_78d11bfca0da4daba0f40de4 -> tool:nanobot-harness-v3:call_dafeffd3f47d47508a681de5 -> tool:nanobot-harness-v3:call_1c6c8ae943824dcba0e55ce9 -> tool:nanobot-harness-v3:call_7a073397fc12401ca9f6d0b2 -> tool:nanobot-harness-v3:call_8d3dea991a0342b0bc9d8266 -> tool:nanobot-harness-v3:call_7912b534a5cc4c1ebe0147a6 -> tool:nanobot-harness-v3:call_344f56db551b4cbf9f57f029 -> tool:nanobot-harness-v3:call_6a0e84d8e7de45d69557f5d9 -> tool:nanobot-harness-v3:call_be58fbfb37b645daa6054b38 -> tool:nanobot-harness-v3:call_05d6b739c6df42219ecc29b6 -> tool:nanobot-harness-v3:call_20016f70f4404892819fc749 -> tool:nanobot-harness-v3:call_a1c9efce6ae1450a8ceb3b41 -> tool:nanobot-harness-v3:call_02657ff53ac144139302a8c5 -> tool:nanobot-harness-v3:call_5ff8904b5e83415ea0e7801b
- 关键路径耗时：0.742897
- Makespan：167.206814
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
