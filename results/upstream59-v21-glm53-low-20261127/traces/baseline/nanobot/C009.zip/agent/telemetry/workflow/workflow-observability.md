# Workflow 可观测性报告

- Trial：`C009__4ZUoAWW__env`
- Task：`C009`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_af5df7c531764c198d421aa3 -> tool:nanobot-harness-v3:call_023d2adcfbc1400488b8029a -> tool:nanobot-harness-v3:call_8482a016f0e646bba9257725 -> tool:nanobot-harness-v3:call_890d256ad3f1454fba7feb25 -> tool:nanobot-harness-v3:call_7372de558b594864a655ec3d -> tool:nanobot-harness-v3:call_41eab1744f7347c990386d94 -> tool:nanobot-harness-v3:call_5856d38c41f9476aa2c208d7 -> tool:nanobot-harness-v3:call_2bb7c659d2d44ba9a40d64e7 -> tool:nanobot-harness-v3:call_46b427ee3d7b4768b08e6df1 -> tool:nanobot-harness-v3:call_d9e4eb0f14364d76a5924fa7 -> tool:nanobot-harness-v3:call_bb05d9829c634551809bb16d -> tool:nanobot-harness-v3:call_ff97c25b481748c5a921ef14 -> tool:nanobot-harness-v3:call_452e66abd366414e83e0bc21 -> tool:nanobot-harness-v3:call_6bfb151de4db46398b755b9f -> tool:nanobot-harness-v3:call_9178210fd29945a5ba573490 -> tool:nanobot-harness-v3:call_5fee08efd0b34d63b26d9310 -> tool:nanobot-harness-v3:call_76ad5607c1284fc0ab010f59 -> tool:nanobot-harness-v3:call_999e78f70e7043938b8ef229 -> tool:nanobot-harness-v3:call_bf63e02d783f4589b4b565b6 -> tool:nanobot-harness-v3:call_c55a8ac324ea4249a19b21aa -> tool:nanobot-harness-v3:call_8892e09c60a44c859a1e555c -> tool:nanobot-harness-v3:call_28e4adf696744844b217d09a -> tool:nanobot-harness-v3:call_38c29f3f56084391b166eacf -> tool:nanobot-harness-v3:call_2dcf572c33a04223a10fc56a -> tool:nanobot-harness-v3:call_4994e96e8b9e49fb85b6e266 -> tool:nanobot-harness-v3:call_530064e5e0934e6f961602dc -> tool:nanobot-harness-v3:call_c6078133a7f2441eaf9561ae -> tool:nanobot-harness-v3:call_1bd4549e3d3042b98888aeec -> tool:nanobot-harness-v3:call_e037ed13c0044a539ce53755 -> tool:nanobot-harness-v3:call_2823476cc076400ca7627fe4
- 关键路径耗时：60.886028
- Makespan：733.648029
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
