# Workflow 可观测性报告

- Trial：`C017__ixCYN3k__env`
- Task：`C017`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（22 节点 / 21 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：22；执行边：21（observed=0，inferred=21）
- Execution Trace Graph：`observed`；temporal_next 边 21，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_ad465cedb3d847e4a10b0ed4 -> tool:nanobot-harness-v3:call_3064a8dc35ed4533b1a24c91 -> tool:nanobot-harness-v3:call_a52cf3bd51b64aaba5a46b14 -> tool:nanobot-harness-v3:call_022efc1a2cdb442eb01aa2b4 -> tool:nanobot-harness-v3:call_4febafbc512544628c5a70f8 -> tool:nanobot-harness-v3:call_8c0de71b90a045538381586d -> tool:nanobot-harness-v3:call_4a9495acecfe4189b705fdc0 -> tool:nanobot-harness-v3:call_5c778cc11c3a4282912a4d92 -> tool:nanobot-harness-v3:call_ea344da6a4444363a1ffc302 -> tool:nanobot-harness-v3:call_2b29882e716f473a9fe3b940 -> tool:nanobot-harness-v3:call_62fd0d8e419a401b8ef82045 -> tool:nanobot-harness-v3:call_70bc326177d345abb3347548 -> tool:nanobot-harness-v3:call_235f42de195f49b1927ea77d -> tool:nanobot-harness-v3:call_5e0c0dd72ecb4ee6bec056ad -> tool:nanobot-harness-v3:call_3c9097608e9a4fac90604cb4 -> tool:nanobot-harness-v3:call_ce6d8bda48ee4cdd99b96c0c -> tool:nanobot-harness-v3:call_a1e0cbcef2b94c14b35a125c -> tool:nanobot-harness-v3:call_f14357904743434697463767 -> tool:nanobot-harness-v3:call_909d62ae953e403eba2e21de -> tool:nanobot-harness-v3:call_1c3049ac6d064c039df9fe38 -> tool:nanobot-harness-v3:call_fdfe525ba48b4bd28d149e74
- 关键路径耗时：0.390317
- Makespan：137.577509
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
