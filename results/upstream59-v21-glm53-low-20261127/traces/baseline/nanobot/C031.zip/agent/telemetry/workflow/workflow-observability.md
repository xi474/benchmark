# Workflow 可观测性报告

- Trial：`C031__GzGoDZY__env`
- Task：`C031`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_9c111027991940669bbfb676 -> tool:nanobot-harness-v3:call_ad22de138b2d4ec8baa42092 -> tool:nanobot-harness-v3:call_70cf9f2240814685b301ace2 -> tool:nanobot-harness-v3:call_0d74c802be6942ba95aada95 -> tool:nanobot-harness-v3:call_94a754c36b174a22b0f3e056 -> tool:nanobot-harness-v3:call_c1752f206d48490f907f52e5 -> tool:nanobot-harness-v3:call_01277a8c65964906babed770 -> tool:nanobot-harness-v3:call_3a14312034df4518b35f2fc8 -> tool:nanobot-harness-v3:call_b8c36f937c464cd8ad1c11f8 -> tool:nanobot-harness-v3:call_9b961e1077dd4060bf2a1e9b -> tool:nanobot-harness-v3:call_0c30868a1a684b709c11a482 -> tool:nanobot-harness-v3:call_ab93201c392549bea7efeb3e -> tool:nanobot-harness-v3:call_9fc66159b3b54768b64da428 -> tool:nanobot-harness-v3:call_560191a4d0d94235a299ba9b -> tool:nanobot-harness-v3:call_27eda9fce0404f838257a73c -> tool:nanobot-harness-v3:call_b5f77ecf747c412d8509de8d -> tool:nanobot-harness-v3:call_6a86c2ed068446a8ba7311eb -> tool:nanobot-harness-v3:call_afd05227b2cb4b80920f5bf3 -> tool:nanobot-harness-v3:call_cc0f93781607434fa834944c -> tool:nanobot-harness-v3:call_e4bca2f38f4345a2a2e93de2 -> tool:nanobot-harness-v3:call_30a68e538d9445949090beb0 -> tool:nanobot-harness-v3:call_63d3427803db4c05a1c60bff -> tool:nanobot-harness-v3:call_9855a9b573fe4779ac49f462 -> tool:nanobot-harness-v3:call_899d6310c91b487299fa0a2f -> tool:nanobot-harness-v3:call_d0b6c0c724bc4b01ad941ac4 -> tool:nanobot-harness-v3:call_b3b451d6e28740d6b4514209 -> tool:nanobot-harness-v3:call_f9f1ea76c4b148b58a9ff9a5 -> tool:nanobot-harness-v3:call_f1039b28b2494b6897d82ec1 -> tool:nanobot-harness-v3:call_b8bbe748a3e74266a82a0f41 -> tool:nanobot-harness-v3:call_9122234b475b40ecb466bb4c -> tool:nanobot-harness-v3:call_cbb92d1d939744579e501d76 -> tool:nanobot-harness-v3:call_880fb072d0974b5aa6e1da70 -> tool:nanobot-harness-v3:call_a9806351563840a789a5619b -> tool:nanobot-harness-v3:call_b0d1a25dcbd348df94be23ed -> tool:nanobot-harness-v3:call_253d3cd0268f4b4bbda535f1 -> tool:nanobot-harness-v3:call_4010836f62d24264898a1ef6 -> tool:nanobot-harness-v3:call_db26d689b6564e7980c45a48 -> tool:nanobot-harness-v3:call_ec7c8d95da08463b93354d39 -> tool:nanobot-harness-v3:call_a6e1ab68014e4ba2ad3d5192
- 关键路径耗时：333.363775
- Makespan：696.815575
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
