# Workflow 可观测性报告

- Trial：`C033__EH6kKgR__env`
- Task：`C033`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_e26e1f25a1484026bafc6eef -> tool:nanobot-harness-v3:call_2147805620ad4809b1d4deb1 -> tool:nanobot-harness-v3:call_af1817d72b4545ada8fcc011 -> tool:nanobot-harness-v3:call_ed349a3a151641328d07abc7 -> tool:nanobot-harness-v3:call_c4cc1e75a7b444b7bbbf79de -> tool:nanobot-harness-v3:call_cc034e48bd1c4cfc9fd86545 -> tool:nanobot-harness-v3:call_a645e049f569452dac768aad -> tool:nanobot-harness-v3:call_72bb325f563740289f3ad5df -> tool:nanobot-harness-v3:call_0cd2c0facbee44ac8ca44200 -> tool:nanobot-harness-v3:call_4dc9f5464e6041cdaca11fe0 -> tool:nanobot-harness-v3:call_c51713a001d346888b0d4844 -> tool:nanobot-harness-v3:call_f8fce96123e442a3800f7730 -> tool:nanobot-harness-v3:call_e1af4367ebe84a468ad3ff48 -> tool:nanobot-harness-v3:call_eb564be40ff44d7aab67b525 -> tool:nanobot-harness-v3:call_2b6ed770c8c64c73af5f7125 -> tool:nanobot-harness-v3:call_6fa08403ff79417bb6149093 -> tool:nanobot-harness-v3:call_06d78b4e6d2e48c3977a510d -> tool:nanobot-harness-v3:call_aa259d56bb9a45ffb3195060 -> tool:nanobot-harness-v3:call_fbd49d7012884065a7094759 -> tool:nanobot-harness-v3:call_ed012982cc4f44a0a2252415 -> tool:nanobot-harness-v3:call_94e70eb9ead749b1a28cb6fd -> tool:nanobot-harness-v3:call_4862e3c19faf4420af623b7b -> tool:nanobot-harness-v3:call_3497319298de4a8aadd91d8b -> tool:nanobot-harness-v3:call_eb87cee6200e40c38f4cf7d4 -> tool:nanobot-harness-v3:call_af0885c20a4d4f6990572aef -> tool:nanobot-harness-v3:call_2494a3b3c8754b0db55fe730 -> tool:nanobot-harness-v3:call_18695df92d864e17b2d3c33e -> tool:nanobot-harness-v3:call_fdf484196cc44420af0aeece -> tool:nanobot-harness-v3:call_ea323522b00d40d8834e1346 -> tool:nanobot-harness-v3:call_17c696b472d448b8a037f528
- 关键路径耗时：0.406936
- Makespan：269.199925
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
