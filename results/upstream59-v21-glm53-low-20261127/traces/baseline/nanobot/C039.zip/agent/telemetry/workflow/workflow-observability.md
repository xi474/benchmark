# Workflow 可观测性报告

- Trial：`C039__qu54aqh__env`
- Task：`C039`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_08e159b985e942e3839428c8 -> tool:nanobot-harness-v3:call_d78808fe6fcb42ac99fc4e7c -> tool:nanobot-harness-v3:call_e800deffc27a4cc8945edd8a -> tool:nanobot-harness-v3:call_81a5d80c657b4d769a07c774 -> tool:nanobot-harness-v3:call_c31eeeb05ec74c0abd9eec07 -> tool:nanobot-harness-v3:call_4e97fa0304114a3e81c51125 -> tool:nanobot-harness-v3:call_8228f6b3c5044e648071a2f2 -> tool:nanobot-harness-v3:call_4c51ce9d601b4afa85a618aa -> tool:nanobot-harness-v3:call_b1af4c87db9044cba33ec2d8 -> tool:nanobot-harness-v3:call_2940a1aadc9741498a0ee3fa -> tool:nanobot-harness-v3:call_e05b92f6d75b436593f6afc2 -> tool:nanobot-harness-v3:call_cda7520c757e431d9ccdcbea -> tool:nanobot-harness-v3:call_96244c35f2a74581916080f9 -> tool:nanobot-harness-v3:call_43a8e471f21d468c80d39487 -> tool:nanobot-harness-v3:call_36e1161e5f874cc3a41ff09c -> tool:nanobot-harness-v3:call_0686c3b1434d4bd3a57373ac -> tool:nanobot-harness-v3:call_1c29e1fe307b4beb84d1d5ae -> tool:nanobot-harness-v3:call_ffbfaf64795145778cfa033d -> tool:nanobot-harness-v3:call_012561dc89a245b7affa5792 -> tool:nanobot-harness-v3:call_486c618c35294e458616c6c4 -> tool:nanobot-harness-v3:call_a64d0e9185c24caab57edd2f -> tool:nanobot-harness-v3:call_e2ab34c8b37c453db9f8c335 -> tool:nanobot-harness-v3:call_429f8558bf4549b597e62b16
- 关键路径耗时：0.744188
- Makespan：240.726197
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
