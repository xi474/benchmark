# Workflow 可观测性报告

- Trial：`C049__DAyQ4RX__env`
- Task：`C049`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_61b8b51b58954294b8d13ec0 -> tool:nanobot-harness-v3:call_38e19c828ea14edbabe0be34 -> tool:nanobot-harness-v3:call_c959ee2f23eb4ddf9ac3ef36 -> tool:nanobot-harness-v3:call_dbf9a0ad192343f98544b891 -> tool:nanobot-harness-v3:call_add07235f373486abfae10d1 -> tool:nanobot-harness-v3:call_193946e239664583bc724585 -> tool:nanobot-harness-v3:call_4592054538854ac7badaaf62 -> tool:nanobot-harness-v3:call_8356a53c86cd47e0baa405be -> tool:nanobot-harness-v3:call_3463ee84ef8f4358a1130cae -> tool:nanobot-harness-v3:call_b27c5b0568a3416e8eef5e80 -> tool:nanobot-harness-v3:call_c0eec93fc1b1422d8da3c25c -> tool:nanobot-harness-v3:call_17c1e5f154bc413b96225707 -> tool:nanobot-harness-v3:call_604aa083cbe04b318b90bb37 -> tool:nanobot-harness-v3:call_83293b580d3c4d89a6522dc8 -> tool:nanobot-harness-v3:call_4b478eed1bd746fdacfd6e86 -> tool:nanobot-harness-v3:call_bdb00452456a4c3d80748910 -> tool:nanobot-harness-v3:call_f6e38491e686434cbeae19a8 -> tool:nanobot-harness-v3:call_171dd53d3e9641e5b675bfcc -> tool:nanobot-harness-v3:call_b0144cd87c094c2eb5383b66 -> tool:nanobot-harness-v3:call_d348ed0af75b4e46a208565c -> tool:nanobot-harness-v3:call_8e0ed94599334884921241fe -> tool:nanobot-harness-v3:call_ec84d569bb6743cba6bd25a1 -> tool:nanobot-harness-v3:call_70b588340cd847519f2b6614 -> tool:nanobot-harness-v3:call_250f4859a4b7414aa608bd11 -> tool:nanobot-harness-v3:call_89b72f36d5414686a1dccd2c -> tool:nanobot-harness-v3:call_c8834dac8665477bbaa199cd -> tool:nanobot-harness-v3:call_a786ba6732a240f8b7f8219a -> tool:nanobot-harness-v3:call_401724fca85949b990248d40 -> tool:nanobot-harness-v3:call_2f9df532ebc84b3caf02a86f -> tool:nanobot-harness-v3:call_b598de1c112349c5b970f8ae -> tool:nanobot-harness-v3:call_d2455c4bf3c145ac97eda81c -> tool:nanobot-harness-v3:call_82a817f96b2b400eba61ae11 -> tool:nanobot-harness-v3:call_60ac6443993244f59384c8db
- 关键路径耗时：3.076898
- Makespan：271.664205
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
