# Workflow 可观测性报告

- Trial：`C055__NSaSyiw__env`
- Task：`C055`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_ae88a16929b34addaf707f52 -> tool:nanobot-harness-v3:call_84ce38be11ed4a63ba79a4c3 -> tool:nanobot-harness-v3:call_d399ebea2848431bb461498b -> tool:nanobot-harness-v3:call_06df71b57c764f95aee9e69c -> tool:nanobot-harness-v3:call_6f8fcb44b396473d8b57f229 -> tool:nanobot-harness-v3:call_33afae5314fe40c3b155a372 -> tool:nanobot-harness-v3:call_688b0314428a4d50b2c7d528 -> tool:nanobot-harness-v3:call_fcb79a81dba540fb945fd2cd -> tool:nanobot-harness-v3:call_b5e7b4ee0ada45b6bc2cdfa0 -> tool:nanobot-harness-v3:call_2026a6e8ebc34c2fb8f68bec -> tool:nanobot-harness-v3:call_8249e48f8a4b450aa4639c81 -> tool:nanobot-harness-v3:call_cef5b9385c654d58a96e626b -> tool:nanobot-harness-v3:call_c9f53ec2b29648098ac9ba23 -> tool:nanobot-harness-v3:call_3f64b4202d4a44949a665a0c -> tool:nanobot-harness-v3:call_16d96d9050464f46bff24d41 -> tool:nanobot-harness-v3:call_35b6d5bf89ad48329e92cd47 -> tool:nanobot-harness-v3:call_61f3875856364d2ca6f93904 -> tool:nanobot-harness-v3:call_3f90e694542c4c67bda01065 -> tool:nanobot-harness-v3:call_ea561c56839c47b6bd470018 -> tool:nanobot-harness-v3:call_8b32f7b596724cd6836c5776 -> tool:nanobot-harness-v3:call_d03df088b07640aa8f28365f -> tool:nanobot-harness-v3:call_0d70220f758f45a6ba886117 -> tool:nanobot-harness-v3:call_7e4c490ea72b4d9eb558c0ba -> tool:nanobot-harness-v3:call_5a8d45591de749be873a2ce2 -> tool:nanobot-harness-v3:call_d384d669997c493f9b12a64c -> tool:nanobot-harness-v3:call_f3724249c8ba41fc8dc94194 -> tool:nanobot-harness-v3:call_3195349026624c8ba93b724b
- 关键路径耗时：0.676002
- Makespan：187.928974
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
