# Workflow 可观测性报告

- Trial：`C056__V7EeXN5__env`
- Task：`C056`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d0a5a30c4e474120979cd8c9 -> tool:nanobot-harness-v3:call_579f856e71cc422189c08dca -> tool:nanobot-harness-v3:call_08dccf93f3bd4824bdc06b75 -> tool:nanobot-harness-v3:call_ec994db1748f458abaa90d1c -> tool:nanobot-harness-v3:call_880b8d9b9e244486b9b6d113 -> tool:nanobot-harness-v3:call_1edf1debf41e4aa09f98d25c -> tool:nanobot-harness-v3:call_7df3c74d5e2448b0a2c2029a -> tool:nanobot-harness-v3:call_551df31156bb49479a5cf343 -> tool:nanobot-harness-v3:call_e85209dadddc4e7f97619846 -> tool:nanobot-harness-v3:call_8cdda0a2fa1f45ba9b87424a -> tool:nanobot-harness-v3:call_60ce60bc3caf43119fe5cc38 -> tool:nanobot-harness-v3:call_3b367d548f174657bb386df8 -> tool:nanobot-harness-v3:call_ce5cf9b2b1e34ceba1dd88b9 -> tool:nanobot-harness-v3:call_20a1a5852f974cb6aa84542b -> tool:nanobot-harness-v3:call_30187e221d9b4a09ad2bd7e2 -> tool:nanobot-harness-v3:call_547a2aae99624011ad554f80 -> tool:nanobot-harness-v3:call_00d99bbbf20747048a8086c7 -> tool:nanobot-harness-v3:call_91f04b77334a405da5574bcf -> tool:nanobot-harness-v3:call_225ab049f19e4e24893bc17a -> tool:nanobot-harness-v3:call_58cf70cd707d401a81d82900 -> tool:nanobot-harness-v3:call_14af1a39c7ad47f098f90cfb -> tool:nanobot-harness-v3:call_ba75d5222e674636a5a453f2 -> tool:nanobot-harness-v3:call_1867610ab1d04058afc957c1 -> tool:nanobot-harness-v3:call_12a53803689945b5b5b05ec8 -> tool:nanobot-harness-v3:call_b240b556d37542039a4201ac -> tool:nanobot-harness-v3:call_d9569db6c452408ca691f7dd -> tool:nanobot-harness-v3:call_421fbfda77bc424ca128124f -> tool:nanobot-harness-v3:call_48710d865c034b4d8678e316
- 关键路径耗时：0.342145
- Makespan：168.88809
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
