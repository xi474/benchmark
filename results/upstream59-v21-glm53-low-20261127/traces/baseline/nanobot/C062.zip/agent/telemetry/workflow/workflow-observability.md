# Workflow 可观测性报告

- Trial：`C062__4ReXqxq__env`
- Task：`C062`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_b1bb457a8a524951a1363d59 -> tool:nanobot-harness-v3:call_090ca6adfc554a5db0d30ca0 -> tool:nanobot-harness-v3:call_5d20727c5b3e41beb485aa22 -> tool:nanobot-harness-v3:call_82802428524941a39d3d85c7 -> tool:nanobot-harness-v3:call_13eb7c718c524387a93b431a -> tool:nanobot-harness-v3:call_4dbeb5b74c6547aca1a0f99e -> tool:nanobot-harness-v3:call_4bd6ad9a6c1e4e37906bdc23 -> tool:nanobot-harness-v3:call_6fc3eac3089f4e2c8483fbad -> tool:nanobot-harness-v3:call_df6ed462283d43daa7418b5a -> tool:nanobot-harness-v3:call_bf1d099f4dc540f5b9733f7d -> tool:nanobot-harness-v3:call_ae792a0d41914a0d83a0f32f -> tool:nanobot-harness-v3:call_0978733d7d494598b5713b52 -> tool:nanobot-harness-v3:call_a36f72075f6d4bb48223d9ef -> tool:nanobot-harness-v3:call_95bebb515e3245f7b89bfd34 -> tool:nanobot-harness-v3:call_a9e3bcf96f4a4d488710e639 -> tool:nanobot-harness-v3:call_1a035680abc94392bbfa7032 -> tool:nanobot-harness-v3:call_c392f590dcb444f6a8d79ab9 -> tool:nanobot-harness-v3:call_0bd3f9557671401cafcfc6d6 -> tool:nanobot-harness-v3:call_6889ea9cb5af46c49c423925 -> tool:nanobot-harness-v3:call_7dd5283113d74b3dbd167d41 -> tool:nanobot-harness-v3:call_16ee07ffef4743cdb54eea20 -> tool:nanobot-harness-v3:call_bc9ebc2035664134a3aae3fc -> tool:nanobot-harness-v3:call_695aba758aca403f861f4a0f
- 关键路径耗时：0.241331
- Makespan：170.997541
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
