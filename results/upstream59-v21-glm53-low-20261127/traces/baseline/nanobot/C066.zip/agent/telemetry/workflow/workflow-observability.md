# Workflow 可观测性报告

- Trial：`C066__LHztKsc__env`
- Task：`C066`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（25 节点 / 24 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：25；执行边：24（observed=0，inferred=24）
- Execution Trace Graph：`observed`；temporal_next 边 24，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_2a19763653f24d398ded7353 -> tool:nanobot-harness-v3:call_41be84262c7e4d8c8c86556f -> tool:nanobot-harness-v3:call_9bedf96851a547d188cd0f4f -> tool:nanobot-harness-v3:call_cb09e4881536492dbbd0e4d8 -> tool:nanobot-harness-v3:call_6f2087cc53824e008e095dd0 -> tool:nanobot-harness-v3:call_74d1a2b00df4409b80554011 -> tool:nanobot-harness-v3:call_92245528129a4f5089b0334b -> tool:nanobot-harness-v3:call_677d86c77c0644d2b218a318 -> tool:nanobot-harness-v3:call_b05d36a45f7e4dde92fe9b67 -> tool:nanobot-harness-v3:call_beec41c8888f418bbbb7619b -> tool:nanobot-harness-v3:call_cef709d3bef042d79a77458e -> tool:nanobot-harness-v3:call_ebab17515bb5449bb7dc6722 -> tool:nanobot-harness-v3:call_4a533546f2e14780a2dfe905 -> tool:nanobot-harness-v3:call_60b6aaa917ac41c595bcc826 -> tool:nanobot-harness-v3:call_5befc214e88048c3abb0ccf3 -> tool:nanobot-harness-v3:call_7382472dba26485b939dd01d -> tool:nanobot-harness-v3:call_acfd14830bdb4818813e64e7 -> tool:nanobot-harness-v3:call_59c7c089b1b74c56bb4f7620 -> tool:nanobot-harness-v3:call_f8ddc412b0294021a3e3c378 -> tool:nanobot-harness-v3:call_7f1bf9c2b645498ca52fe0dc -> tool:nanobot-harness-v3:call_e922670295d44f379691c81e -> tool:nanobot-harness-v3:call_cf61cbb124264703836934d5 -> tool:nanobot-harness-v3:call_df5b7c5369c2448d9244e78d -> tool:nanobot-harness-v3:call_c2ab6ab31eb94918982a7ac5
- 关键路径耗时：0.416509
- Makespan：210.616016
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
