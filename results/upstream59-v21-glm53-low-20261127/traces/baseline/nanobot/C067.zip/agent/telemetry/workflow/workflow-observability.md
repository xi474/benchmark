# Workflow 可观测性报告

- Trial：`C067__LdjqueX__env`
- Task：`C067`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_ee4278010ff8495eadf80134 -> tool:nanobot-harness-v3:call_3d31bb011a744becb511d00d -> tool:nanobot-harness-v3:call_361638c9f664435388750c68 -> tool:nanobot-harness-v3:call_372a72dd5b8d453d93b217a9 -> tool:nanobot-harness-v3:call_81ecf14acd1c49d8a461ed57 -> tool:nanobot-harness-v3:call_5e3f0ce011f04903a80181f8 -> tool:nanobot-harness-v3:call_eb0700093be14c4da6f5ff36 -> tool:nanobot-harness-v3:call_20e785afd1684ec89ada89b6 -> tool:nanobot-harness-v3:call_c3894c8d81794b809c7e17b8 -> tool:nanobot-harness-v3:call_6e01854b2b284391952ae6d2 -> tool:nanobot-harness-v3:call_2b65816e24184e4a93184585 -> tool:nanobot-harness-v3:call_657dfe0576844882bcbbd9bf -> tool:nanobot-harness-v3:call_8b52e02e8bce4c2297f37fac -> tool:nanobot-harness-v3:call_eca5b28d78bd4f0f845c9a12 -> tool:nanobot-harness-v3:call_7c5f5c243734471892962f30 -> tool:nanobot-harness-v3:call_9feb6b3d8add426da3890697 -> tool:nanobot-harness-v3:call_c06ae55a2f9b474092b45f53 -> tool:nanobot-harness-v3:call_a38f669be2a44c9f84e78813 -> tool:nanobot-harness-v3:call_fd5c3497311548bca6b8e4c6 -> tool:nanobot-harness-v3:call_44f60af289a6411cbebc2c9f -> tool:nanobot-harness-v3:call_829c3ae386bf4c4ca02a887d -> tool:nanobot-harness-v3:call_5c3dfa825e2047a19adb4fdf -> tool:nanobot-harness-v3:call_a1e2a6def45d4dbca017b818 -> tool:nanobot-harness-v3:call_a8ed3b27d7a04f6aa741fb97 -> tool:nanobot-harness-v3:call_bf1208e010a94dc5887cfb18 -> tool:nanobot-harness-v3:call_157077b12a83477a94dfd997 -> tool:nanobot-harness-v3:call_2d30ad8b242e4026887adaf2 -> tool:nanobot-harness-v3:call_60bec93785ec4e0eaab760ac -> tool:nanobot-harness-v3:call_665a096f24244ce1911e235f -> tool:nanobot-harness-v3:call_2c72eba0557248fd88d9e6d3 -> tool:nanobot-harness-v3:call_800c2bf2f3c44beebcee7c80 -> tool:nanobot-harness-v3:call_9dfe7aa5e45840bf94311f60 -> tool:nanobot-harness-v3:call_da83030959c5454987e54ad1
- 关键路径耗时：0.373092
- Makespan：208.20486
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
