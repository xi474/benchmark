# Workflow 可观测性报告

- Trial：`C068__3zHX4zG__env`
- Task：`C068`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_40a3be8e1e9a4ced930595f2 -> tool:nanobot-harness-v3:call_3034b52b59954047b6c2ae1a -> tool:nanobot-harness-v3:call_51a08fc9be824ead93774e27 -> tool:nanobot-harness-v3:call_2105d3ffbb7d4610baf30600 -> tool:nanobot-harness-v3:call_e75584a9b9b7470bbe8e30b6 -> tool:nanobot-harness-v3:call_a2b97aa3865d427988d507fe -> tool:nanobot-harness-v3:call_0fb4f9b1d6de4e388184966d -> tool:nanobot-harness-v3:call_eb699c74c0f947c9ac0fea78 -> tool:nanobot-harness-v3:call_3afe2ce8adf847a6946656fd -> tool:nanobot-harness-v3:call_dc108148abad46eca8a8cb93 -> tool:nanobot-harness-v3:call_d56057c79af344629de9a4f0 -> tool:nanobot-harness-v3:call_98711a402d894b238101b837 -> tool:nanobot-harness-v3:call_b624751745a041378b960358 -> tool:nanobot-harness-v3:call_03aacdf93746454c9190df9f -> tool:nanobot-harness-v3:call_38fdc093414748808ae4d8dc -> tool:nanobot-harness-v3:call_7d15197b1f6449a2ac75e947 -> tool:nanobot-harness-v3:call_af0002e21e69476eaf4e8237 -> tool:nanobot-harness-v3:call_ab693ba57c674f399ef6b899 -> tool:nanobot-harness-v3:call_8cd7f84d4f5e4d989fc040ad -> tool:nanobot-harness-v3:call_e741ec2e03654541b5c19b91 -> tool:nanobot-harness-v3:call_47644e091c814414b762a9c7 -> tool:nanobot-harness-v3:call_ac04063344a84448965049a7 -> tool:nanobot-harness-v3:call_bc0f38f73d0d4452866224d8 -> tool:nanobot-harness-v3:call_2a1c1a824588458f9fda9a54 -> tool:nanobot-harness-v3:call_28ef29d636624799a08f334a -> tool:nanobot-harness-v3:call_f5d57c5a72214da6914d1dca -> tool:nanobot-harness-v3:call_abd933a6521d40a9902f4a51 -> tool:nanobot-harness-v3:call_99da940ec5f54d02956beea0 -> tool:nanobot-harness-v3:call_e8e307a2d8ed44c8b41bd149 -> tool:nanobot-harness-v3:call_b44d21b39f6a4faaa9f01424 -> tool:nanobot-harness-v3:call_fbffd3720ad745d88a178aa0 -> tool:nanobot-harness-v3:call_b062936cf573405ea666e819 -> tool:nanobot-harness-v3:call_831d8932e4574fcc87ed65f9 -> tool:nanobot-harness-v3:call_60df99d767934962a42c654e
- 关键路径耗时：0.385936
- Makespan：287.71703
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
