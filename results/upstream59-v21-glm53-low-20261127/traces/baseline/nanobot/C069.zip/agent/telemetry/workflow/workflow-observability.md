# Workflow 可观测性报告

- Trial：`C069__aYdCERr__env`
- Task：`C069`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3c9bdec0b93340a0b1604641 -> tool:nanobot-harness-v3:call_824d3246113343e6b79edd79 -> tool:nanobot-harness-v3:call_429728d8c5b1458dbdb5e691 -> tool:nanobot-harness-v3:call_65e5a6ccf78e4168bad80b38 -> tool:nanobot-harness-v3:call_a4f3b5cfff194410b5ad0bd7 -> tool:nanobot-harness-v3:call_1d276e961211447bb36e69f1 -> tool:nanobot-harness-v3:call_39963a1799874fc2aeb63889 -> tool:nanobot-harness-v3:call_6c4b8a4303b444a991a4f0e8 -> tool:nanobot-harness-v3:call_b07dc4f23f0d471f884fda91 -> tool:nanobot-harness-v3:call_21665d791f6b45d9ad8e1373 -> tool:nanobot-harness-v3:call_febb2b69f15641aa92d2c19e -> tool:nanobot-harness-v3:call_ef90d3b6cec546faaa1a53de -> tool:nanobot-harness-v3:call_9ec3c1e9f0364be3926c34b5 -> tool:nanobot-harness-v3:call_981910a2f60f4a81bda45690 -> tool:nanobot-harness-v3:call_7d064c5cd8764b32b83c047c -> tool:nanobot-harness-v3:call_6d3257fed6694081a3eaa7f9 -> tool:nanobot-harness-v3:call_35c1b63b4eca427dab35510b -> tool:nanobot-harness-v3:call_9c47ff2aa96647b7a97e79e1 -> tool:nanobot-harness-v3:call_8d613a06f566419b8151ba19 -> tool:nanobot-harness-v3:call_dc93e4a5def548c1848f452b -> tool:nanobot-harness-v3:call_7bee95815a4045d391545326 -> tool:nanobot-harness-v3:call_05eb2b26d65c46608efb653d -> tool:nanobot-harness-v3:call_61c172a2f3644d47a42e3b8e -> tool:nanobot-harness-v3:call_6621880ce7644f92a0f43679 -> tool:nanobot-harness-v3:call_ccbffeb106a84c5db6878550 -> tool:nanobot-harness-v3:call_f506cd4798ed43ed83fdc349 -> tool:nanobot-harness-v3:call_7417b0e171714cf5921fdef7 -> tool:nanobot-harness-v3:call_31ddc70bb4eb4a5aac28f542 -> tool:nanobot-harness-v3:call_a0aa7963329a4bc7a3d49abc -> tool:nanobot-harness-v3:call_c92eecb94c77496f9d6b28d9
- 关键路径耗时：0.449799
- Makespan：252.836422
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
