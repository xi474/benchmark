# Workflow 可观测性报告

- Trial：`C074__qKRJ5GS__env`
- Task：`C074`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_a7208e705b28498d8e7e0c83 -> tool:nanobot-harness-v3:call_5a2823b254ce4c2f8bf3bb93 -> tool:nanobot-harness-v3:call_3d18341ffa1d46629c8f1e63 -> tool:nanobot-harness-v3:call_a42f5b82e8f246c28eea72e4 -> tool:nanobot-harness-v3:call_153259b6c725407587b764cc -> tool:nanobot-harness-v3:call_9b10035b8d644e9c9a60fd2e -> tool:nanobot-harness-v3:call_b00ba0fb99a9404f97c6241c -> tool:nanobot-harness-v3:call_45b26ddb39ed497bb6d01998 -> tool:nanobot-harness-v3:call_b5ed979d98b241ab8f094f3d -> tool:nanobot-harness-v3:call_39090c7d385e4c909fd5b1e6 -> tool:nanobot-harness-v3:call_47c4db10dcf94364a1d2ea79 -> tool:nanobot-harness-v3:call_ec1b069e86b74369aef46875 -> tool:nanobot-harness-v3:call_3e0d2fe1aec0466aa175e5f9 -> tool:nanobot-harness-v3:call_d78f64023e3a4dfcb10d1221 -> tool:nanobot-harness-v3:call_64865e96a7ed471589b8f0ae -> tool:nanobot-harness-v3:call_6ef886dc79994984ba7411ed -> tool:nanobot-harness-v3:call_0e1a31ae6c6b44e9818a5dee -> tool:nanobot-harness-v3:call_fcae8c3324234f3881869db6 -> tool:nanobot-harness-v3:call_2bc8d2d299dc4f77b13af4c0 -> tool:nanobot-harness-v3:call_bf8666ec95144cbd8c16fd2d -> tool:nanobot-harness-v3:call_e68e9dd3a8644b7984c6bfd5 -> tool:nanobot-harness-v3:call_4e11889b1e484baca1c68aa3 -> tool:nanobot-harness-v3:call_4e8358d1fedd4ee3abe46063 -> tool:nanobot-harness-v3:call_ea1344a2f681426eb5d37b70 -> tool:nanobot-harness-v3:call_11dfc4f7d97041ae8120436f -> tool:nanobot-harness-v3:call_c59e0bbe78394fdda9e9a487 -> tool:nanobot-harness-v3:call_989cc0cf70b74a5b9c975378 -> tool:nanobot-harness-v3:call_18eec697f93748fbaba7040b -> tool:nanobot-harness-v3:call_e48f459664b846d7bf335e16 -> tool:nanobot-harness-v3:call_08ea6cec7dd145ef948dc76b -> tool:nanobot-harness-v3:call_b74f7037e7fc4260bb7a6abf -> tool:nanobot-harness-v3:call_69a69a4ae6d045909d4bc14f -> tool:nanobot-harness-v3:call_30136c3bde9c4b1d84ea33c3
- 关键路径耗时：0.50522
- Makespan：312.175693
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
