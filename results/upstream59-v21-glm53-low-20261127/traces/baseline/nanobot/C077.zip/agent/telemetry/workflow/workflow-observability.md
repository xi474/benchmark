# Workflow 可观测性报告

- Trial：`C077__KbQaJQB__env`
- Task：`C077`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_da1a9427f57748cd82e58b6a -> tool:nanobot-harness-v3:call_28b5ca233e594bc4a2e9ea62 -> tool:nanobot-harness-v3:call_5c9bec65358b44a1acb74153 -> tool:nanobot-harness-v3:call_014ed69a4eb349d9912fd5cc -> tool:nanobot-harness-v3:call_57a3962fb28c412483ca48ce -> tool:nanobot-harness-v3:call_9df0f6df52d34b038d1de338 -> tool:nanobot-harness-v3:call_a3c4613f9dcd47c7b7027f61 -> tool:nanobot-harness-v3:call_5a880682403748409f47e92f -> tool:nanobot-harness-v3:call_7b351d2f44364ad88b812676 -> tool:nanobot-harness-v3:call_30e17ce38ea7411bb9ad92a4 -> tool:nanobot-harness-v3:call_824f42dcc7244851ba664e6b -> tool:nanobot-harness-v3:call_6feceffab31f46bfb03fd365 -> tool:nanobot-harness-v3:call_2010a9d2d48b4b1ca625e2bc -> tool:nanobot-harness-v3:call_93f2ca3dfb864f91a4966e5b -> tool:nanobot-harness-v3:call_10f3526a095e4304b0ffa11a -> tool:nanobot-harness-v3:call_0863ae29ef9d43bb9d68c96b -> tool:nanobot-harness-v3:call_fad6093c415b496eb1d335dc -> tool:nanobot-harness-v3:call_957c9d30e88c4cf8adbf2e77 -> tool:nanobot-harness-v3:call_cee292eb03604aaea7819056 -> tool:nanobot-harness-v3:call_cabee627c8be4da1a4829814 -> tool:nanobot-harness-v3:call_8626aafedaaa49a1be2d750c -> tool:nanobot-harness-v3:call_4a3d60e23bd04d9d8b9d5b94 -> tool:nanobot-harness-v3:call_00c68058d5a64914bf4a4759 -> tool:nanobot-harness-v3:call_b0f8b34e6725442d9d963a7f -> tool:nanobot-harness-v3:call_562e92d363a744b598422be5 -> tool:nanobot-harness-v3:call_5880913e283b4d338fc96ac0 -> tool:nanobot-harness-v3:call_c6c182d5511143d89d5a362b
- 关键路径耗时：0.41582
- Makespan：470.407987
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
