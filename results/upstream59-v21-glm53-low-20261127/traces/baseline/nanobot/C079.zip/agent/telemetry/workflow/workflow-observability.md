# Workflow 可观测性报告

- Trial：`C079__DrdfMDr__env`
- Task：`C079`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_e8bd63e39a9d420d9423aa2d -> tool:nanobot-harness-v3:call_abccfb15ab444108b10ac533 -> tool:nanobot-harness-v3:call_f4ea3701875343df9816b711 -> tool:nanobot-harness-v3:call_ec7d36dcd3d44d92992e521d -> tool:nanobot-harness-v3:call_25ceacf6b81043b7bc948d8a -> tool:nanobot-harness-v3:call_dbeccb6fa8b74826b1f83389 -> tool:nanobot-harness-v3:call_55c8aeacf70448fea07d0bb7 -> tool:nanobot-harness-v3:call_f0e0521e6b624963a06a6941 -> tool:nanobot-harness-v3:call_da0bdf7153e6449d806f20b3 -> tool:nanobot-harness-v3:call_916e001e6c99459b94733ab8 -> tool:nanobot-harness-v3:call_03f766325663477f8d4e4d4f -> tool:nanobot-harness-v3:call_ff11bbd59d4c4c5c8b28e728 -> tool:nanobot-harness-v3:call_28e567daa16a4b7bbf7d3791 -> tool:nanobot-harness-v3:call_3644aa9aa3384743b5f07a6f -> tool:nanobot-harness-v3:call_ea0213022cc441c5b235f417 -> tool:nanobot-harness-v3:call_47d19c781915486982abaa41 -> tool:nanobot-harness-v3:call_93b7f139dcdc4c938f8da995 -> tool:nanobot-harness-v3:call_809d5d61c5ab4fef817735f2 -> tool:nanobot-harness-v3:call_5b0c2de9fb73410cbcca2075 -> tool:nanobot-harness-v3:call_7808e208e936478790b40460 -> tool:nanobot-harness-v3:call_00c7d02cee5446b680fee84b -> tool:nanobot-harness-v3:call_cbc9d83dd65642d6abe92b9f -> tool:nanobot-harness-v3:call_21479d9a02dc4b9185a4fa39 -> tool:nanobot-harness-v3:call_d065077290da40f88b95c0a0 -> tool:nanobot-harness-v3:call_b86d891c8bf04cfaa7495f89 -> tool:nanobot-harness-v3:call_10bd049fa6134e1aaa87158e -> tool:nanobot-harness-v3:call_ba781be1ae694e56af2f22b6 -> tool:nanobot-harness-v3:call_2a8dd5f4b94e4b8baa5d48db -> tool:nanobot-harness-v3:call_0dbfb30d8e0a4507b92b5bb2 -> tool:nanobot-harness-v3:call_49d487afbfea40309e488eb0 -> tool:nanobot-harness-v3:call_430a1e3a873d4e3d84e6c95f -> tool:nanobot-harness-v3:call_9a73c12ff44d447fb9371919 -> tool:nanobot-harness-v3:call_03d46436b4a84ef3a27c1209 -> tool:nanobot-harness-v3:call_7533ad02afd44ef5b1a2f7b7 -> tool:nanobot-harness-v3:call_28c585ad26424ba29f3926fd
- 关键路径耗时：0.638132
- Makespan：228.089266
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
