# Workflow 可观测性报告

- Trial：`MP01__csQpPkB__env`
- Task：`MP01`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_55fc3d3b1dfc401c95f9852e -> tool:nanobot-harness-v3:call_b7b2be73adaa4a15b86dc00b -> tool:nanobot-harness-v3:call_454c39b1cd99469187eaf611 -> tool:nanobot-harness-v3:call_1eafc7deed064559bf67bc50 -> tool:nanobot-harness-v3:call_97ff8fcfb15545c59148b978 -> tool:nanobot-harness-v3:call_c99d14e335614b43b86d6939 -> tool:nanobot-harness-v3:call_3a21156b4dff4592a9081306 -> tool:nanobot-harness-v3:call_c56d6baa12594064a4a145c1 -> tool:nanobot-harness-v3:call_57dac56753b444069479af1e -> tool:nanobot-harness-v3:call_dbb674b80d3d40448c3bae88 -> tool:nanobot-harness-v3:call_24a55b4f9b8547d7a7207286 -> tool:nanobot-harness-v3:call_79037cf7e08441ea90db5a56 -> tool:nanobot-harness-v3:call_f5056808e7b345d9a9660f82 -> tool:nanobot-harness-v3:call_d60ff29972904a0fb1a73731 -> tool:nanobot-harness-v3:call_95f1f28235e74b2494a7595a -> tool:nanobot-harness-v3:call_9fb377357f6e4b9da77bf9ca -> tool:nanobot-harness-v3:call_83f269d858f7444bb1a5d71e -> tool:nanobot-harness-v3:call_d09915f68f1440648904f48a -> tool:nanobot-harness-v3:call_76f42e7afcbb471c85b288c0 -> tool:nanobot-harness-v3:call_c3015f22402b490090793323 -> tool:nanobot-harness-v3:call_be8728d64fd645a685206ef9 -> tool:nanobot-harness-v3:call_2e9866decbbe47109ffdf35e -> tool:nanobot-harness-v3:call_a25b8f27462b44048c539df5 -> tool:nanobot-harness-v3:call_f75b74ed99654ec19533b133 -> tool:nanobot-harness-v3:call_872d49e4e68a4cfea070c421 -> tool:nanobot-harness-v3:call_9d1c9340889a496dab903a21 -> tool:nanobot-harness-v3:call_adff35ffb2a2437f852ef0a5 -> tool:nanobot-harness-v3:call_ada175cd5e1c40b18e7c74cb -> tool:nanobot-harness-v3:call_de28bdfaff7849a990a24e2d -> tool:nanobot-harness-v3:call_cd2a76b63c644bb6889978fc -> tool:nanobot-harness-v3:call_cbd2d64f856d475fbaf54b22 -> tool:nanobot-harness-v3:call_93c90da07d2b48efb44e81f3 -> tool:nanobot-harness-v3:call_39c375fdef0842d6a218b737 -> tool:nanobot-harness-v3:call_e3ded2e541c7430fba9ce430
- 关键路径耗时：0.440362
- Makespan：245.376156
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
