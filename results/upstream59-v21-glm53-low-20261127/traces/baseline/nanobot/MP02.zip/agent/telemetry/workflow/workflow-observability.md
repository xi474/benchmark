# Workflow 可观测性报告

- Trial：`MP02__QhofDNC__env`
- Task：`MP02`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_b107bea1410e418aa6d716cf -> tool:nanobot-harness-v3:call_adfcbb41cb994714a727878e -> tool:nanobot-harness-v3:call_13e84306a1f54b22b000d1e0 -> tool:nanobot-harness-v3:call_6ee3b3f4046247c09353794e -> tool:nanobot-harness-v3:call_86f2b07ba07e4b08a16827ba -> tool:nanobot-harness-v3:call_f0db263f552644c983086c07 -> tool:nanobot-harness-v3:call_c9e073ae6cb3453b9598527b -> tool:nanobot-harness-v3:call_a731dbd766c14f3897a6f69a -> tool:nanobot-harness-v3:call_0de680eb513f40e6a69e0af3 -> tool:nanobot-harness-v3:call_40d90ad1d0cf4b63a7bdf77a -> tool:nanobot-harness-v3:call_ff0005fce7c440ee95e2def5 -> tool:nanobot-harness-v3:call_7e53eb1edb3d478fbd47774d -> tool:nanobot-harness-v3:call_c4d3f1df558748e1a647df74 -> tool:nanobot-harness-v3:call_2824e17cf4e546e887f2394d -> tool:nanobot-harness-v3:call_a49f82f398cb4a729f807191 -> tool:nanobot-harness-v3:call_7d1f465a2e974902945669bb -> tool:nanobot-harness-v3:call_81c6041ba30642a0a7589751 -> tool:nanobot-harness-v3:call_a6ac9eea0a1f458b82a6f141 -> tool:nanobot-harness-v3:call_e1d3d543ebd4496babf4cc88 -> tool:nanobot-harness-v3:call_41b18d1c63a74d93898f3d28 -> tool:nanobot-harness-v3:call_cc4a97eb498b453f8fc5d953 -> tool:nanobot-harness-v3:call_14c289f5af024df1a4eb6619 -> tool:nanobot-harness-v3:call_31d429aad4744808a1beac1e -> tool:nanobot-harness-v3:call_2a1aef38aa574821b103ce9a -> tool:nanobot-harness-v3:call_443ffdf0c1cc465a9a6a3d44 -> tool:nanobot-harness-v3:call_7efd4519dccc4df48597de8f -> tool:nanobot-harness-v3:call_39ad92459e824a65a61a14a2 -> tool:nanobot-harness-v3:call_0783394a7d494368b9729a8c -> tool:nanobot-harness-v3:call_6b4aabe23e4440908a233bf5 -> tool:nanobot-harness-v3:call_cf632ff38c5041db85c7db12 -> tool:nanobot-harness-v3:call_1dbc48805fb54ad896513ebe -> tool:nanobot-harness-v3:call_87fc1c7c24574b7f97c8274f -> tool:nanobot-harness-v3:call_80262a129d0747a0a89bf82d -> tool:nanobot-harness-v3:call_2bde28cdc567432881586603 -> tool:nanobot-harness-v3:call_29d20ce37f2241cc83a4220a -> tool:nanobot-harness-v3:call_feb1aa464bb4476aab22afbe -> tool:nanobot-harness-v3:call_e5218b52a70a482a8989cfab
- 关键路径耗时：0.886709
- Makespan：501.306102
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
