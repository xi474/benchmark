# Workflow 可观测性报告

- Trial：`MP03__dCsRjqD__env`
- Task：`MP03`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f6ac7bda52cb41b9891027a3 -> tool:nanobot-harness-v3:call_6c90fa19fb364416a06752cb -> tool:nanobot-harness-v3:call_583c67d5ad6e41979ad163f7 -> tool:nanobot-harness-v3:call_da6d6c6ade0645bdb0c94e7e -> tool:nanobot-harness-v3:call_f6717e681eb747eea7d0c390 -> tool:nanobot-harness-v3:call_df0869ad50c14c8b8ab15d18 -> tool:nanobot-harness-v3:call_671e48ef142f425eb3d6f30f -> tool:nanobot-harness-v3:call_e9012926327246ca966d837b -> tool:nanobot-harness-v3:call_d25345e8ffe54150a1c485bf -> tool:nanobot-harness-v3:call_f0514a70f1824d599df55b38 -> tool:nanobot-harness-v3:call_275d0e06ca954898af65425a -> tool:nanobot-harness-v3:call_eed4232707b54b3e86c64333 -> tool:nanobot-harness-v3:call_31e787beab404372924bb5bf -> tool:nanobot-harness-v3:call_060f6e578fa24e43adb29ae2 -> tool:nanobot-harness-v3:call_4f216f9e143d46598fce7b02 -> tool:nanobot-harness-v3:call_ba62639b9e99493896fd0679 -> tool:nanobot-harness-v3:call_9b3031a0d01b4b89ad8ddcc6 -> tool:nanobot-harness-v3:call_d33ea54021194859afcfe4f0 -> tool:nanobot-harness-v3:call_927b54670b7f481ab22c2c87 -> tool:nanobot-harness-v3:call_4320b0ad4c5640a78856b939 -> tool:nanobot-harness-v3:call_e1fccc87616446bbad906f10 -> tool:nanobot-harness-v3:call_9bac3a91a13845ee9b873672 -> tool:nanobot-harness-v3:call_58a5828afb7e4459af41c10d -> tool:nanobot-harness-v3:call_ad0e2451f5754d9fad3c3947 -> tool:nanobot-harness-v3:call_9d765489e73d4423830c4aee -> tool:nanobot-harness-v3:call_4ad90e7b51ab4420ba040521 -> tool:nanobot-harness-v3:call_1f805cfd277342c096e22868 -> tool:nanobot-harness-v3:call_3bec12baef094644a78f4b64 -> tool:nanobot-harness-v3:call_fa423dfc257849fb993b54f7 -> tool:nanobot-harness-v3:call_c718057f0dd7461b9b51b88c -> tool:nanobot-harness-v3:call_3ee37c550ce444e98b165b2c -> tool:nanobot-harness-v3:call_2c8a20d296b4428f9df749f8 -> tool:nanobot-harness-v3:call_fedf102aeca84e509da9b52d -> tool:nanobot-harness-v3:call_ee1de2f5add84eaeab43dbfc -> tool:nanobot-harness-v3:call_3cda9f347cd54f9ebedb9347 -> tool:nanobot-harness-v3:call_c19498f02b5e4f93bbd0546a -> tool:nanobot-harness-v3:call_7c19607e6ad943ca9786bbe3
- 关键路径耗时：0.741092
- Makespan：524.165806
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
