# Workflow 可观测性报告

- Trial：`MP04__mMA2xWG__env`
- Task：`MP04`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（63 节点 / 62 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：63；执行边：62（observed=0，inferred=62）
- Execution Trace Graph：`observed`；temporal_next 边 62，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_57c1d23c31e849cdac7ca33b -> tool:nanobot-harness-v3:call_931513f98dd84a5b92cf3d7e -> tool:nanobot-harness-v3:call_d5ab0326147a4aac87c0a24e -> tool:nanobot-harness-v3:call_f657ae0c3e90472f884f605b -> tool:nanobot-harness-v3:call_d35e2707c86b44bc882b48d4 -> tool:nanobot-harness-v3:call_1fc8e232a823460e938ead0f -> tool:nanobot-harness-v3:call_572fcbdf47244c7d92f41e10 -> tool:nanobot-harness-v3:call_90f386c0ee744ea4b9dcd03c -> tool:nanobot-harness-v3:call_b15bee9b36cd46c3be2e60d5 -> tool:nanobot-harness-v3:call_1099fd92b0ed4fb0a0ddca4f -> tool:nanobot-harness-v3:call_acf35249281145f69ffd17e9 -> tool:nanobot-harness-v3:call_d52693e4d79a4ad1b04956dd -> tool:nanobot-harness-v3:call_1b9f285f71394c4e892b5304 -> tool:nanobot-harness-v3:call_2207642133054c20a9a868f0 -> tool:nanobot-harness-v3:call_e18520cd927447db962ebabc -> tool:nanobot-harness-v3:call_4e4f20dff21b402097d05cd4 -> tool:nanobot-harness-v3:call_a08085b2444c4d1593a8413d -> tool:nanobot-harness-v3:call_560359a6b9da4ca9acd3f681 -> tool:nanobot-harness-v3:call_f015c65e9c0645459b9e1025 -> tool:nanobot-harness-v3:call_8de1d38a7e304f2ea5c182e9 -> tool:nanobot-harness-v3:call_d113b6ee20784fd69e3d0b18 -> tool:nanobot-harness-v3:call_40e1f381c83a47789c5617d8 -> tool:nanobot-harness-v3:call_15312c7b1cb94dc5a0fc23f9 -> tool:nanobot-harness-v3:call_2e72255504df48c6a25ccd2f -> tool:nanobot-harness-v3:call_0e5aad80925f40c28b01e383 -> tool:nanobot-harness-v3:call_40bc70d52a954ceb93873e0d -> tool:nanobot-harness-v3:call_89a0ccb22a544f25bf93db81 -> tool:nanobot-harness-v3:call_9071dbb3fc71468e8e161ba9 -> tool:nanobot-harness-v3:call_e307f8cfcabf4eab8d0f07bc -> tool:nanobot-harness-v3:call_6e8755b5dd694f9ab61f2f8e -> tool:nanobot-harness-v3:call_0a369aa85a1d4c98a5e6873a -> tool:nanobot-harness-v3:call_df2f38541cc74da79b5b7ac2 -> tool:nanobot-harness-v3:call_6037cedd8ce34b57958495ce -> tool:nanobot-harness-v3:call_48d8d61eb86349789a7a359c -> tool:nanobot-harness-v3:call_281263d5a2074f9ea8c5573f -> tool:nanobot-harness-v3:call_159bca55d81f422fbf4a4877 -> tool:nanobot-harness-v3:call_2af9e403dc454ff1bfcbe48c -> tool:nanobot-harness-v3:call_1cdb20b119164d4ca0106aac -> tool:nanobot-harness-v3:call_8b280624c7fa47e2a56e1db8 -> tool:nanobot-harness-v3:call_3423b900059c46199d1afa14 -> tool:nanobot-harness-v3:call_20833692c68d49999e45fc3b -> tool:nanobot-harness-v3:call_0a924a4565e9480c89899ae2 -> tool:nanobot-harness-v3:call_47e608bef25e46a38a797bbe -> tool:nanobot-harness-v3:call_95b1cfd5d0004cbe9eecf828 -> tool:nanobot-harness-v3:call_fdfb6669dbd14cd5ad8e2dd2 -> tool:nanobot-harness-v3:call_cde38f35ebd044c1a0ec6499 -> tool:nanobot-harness-v3:call_0d980ae5fa604852b220e24a -> tool:nanobot-harness-v3:call_4cdf788568ee49c5a0855734 -> tool:nanobot-harness-v3:call_a199d22ef972451cba835047 -> tool:nanobot-harness-v3:call_aedd6fe2a3c3463f927fda63 -> tool:nanobot-harness-v3:call_1571c322e55b4265955991db -> tool:nanobot-harness-v3:call_3171928377434feca01ae692 -> tool:nanobot-harness-v3:call_c5d51fcbb0fa434aa1944e59 -> tool:nanobot-harness-v3:call_d933bd0ffadb4de9ad470d01 -> tool:nanobot-harness-v3:call_81050f67bb8043ea8ea3447c -> tool:nanobot-harness-v3:call_e24fc46a3682467d9eda2720 -> tool:nanobot-harness-v3:call_2f83185045724b76b51ab120 -> tool:nanobot-harness-v3:call_eb02d52682d442b182ee39b8 -> tool:nanobot-harness-v3:call_7f4a7e28388449998879bfea -> tool:nanobot-harness-v3:call_9e5847364dc746b19f1e9be7 -> tool:nanobot-harness-v3:call_b3c9f4fdf5b24c29a54fc256 -> tool:nanobot-harness-v3:call_a9580cd549224583a9fdacb5
- 关键路径耗时：1.063311
- Makespan：636.578575
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
