# Workflow 可观测性报告

- Trial：`MP05__g8wdK3x__env`
- Task：`MP05`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_55cccb44ba264818a8ecadde -> tool:nanobot-harness-v3:call_f5172c6fa98a49e8afe6783d -> tool:nanobot-harness-v3:call_6b830058c05e42eaa09bd136 -> tool:nanobot-harness-v3:call_c49f5230ead942a7b157890e -> tool:nanobot-harness-v3:call_acd0278f15874a9ca61b2d58 -> tool:nanobot-harness-v3:call_273e34a3c0064744ba064f4c -> tool:nanobot-harness-v3:call_73958389ba9742408875d839 -> tool:nanobot-harness-v3:call_1495715c32f24ffba8fd27cf -> tool:nanobot-harness-v3:call_d1962daa516a4c8ab0415215 -> tool:nanobot-harness-v3:call_7da794af584a4faab0f90686 -> tool:nanobot-harness-v3:call_8f23aba4f11649b8a2fc8657 -> tool:nanobot-harness-v3:call_c57ef82922744ba2bd54d019 -> tool:nanobot-harness-v3:call_448baeef41ce4095ac67d850 -> tool:nanobot-harness-v3:call_88b1bddcc69c4a429d2e0a8c -> tool:nanobot-harness-v3:call_7ad77e0212984e65bf5a88f1 -> tool:nanobot-harness-v3:call_f8c5198cb62d4a42ad41ff40 -> tool:nanobot-harness-v3:call_2c6b99758cef48b192cba30e -> tool:nanobot-harness-v3:call_ded41e9506864f36b23095f3 -> tool:nanobot-harness-v3:call_678156a09b2641508aaef62e -> tool:nanobot-harness-v3:call_fe18bd3d07a54928b0da95a5 -> tool:nanobot-harness-v3:call_854a53d4205e44d19496adce -> tool:nanobot-harness-v3:call_f23d6e71fb85480e8ac3767c -> tool:nanobot-harness-v3:call_4a1795e6717c4418b08c76d1 -> tool:nanobot-harness-v3:call_e0d2e57248564d4f8d710e02 -> tool:nanobot-harness-v3:call_61db912ce3444b8faa4ace4d -> tool:nanobot-harness-v3:call_ba868c72f6b645299f1f3981 -> tool:nanobot-harness-v3:call_9311a0df114c43abaeaf7329 -> tool:nanobot-harness-v3:call_98b5c21398fe422b98bcb672 -> tool:nanobot-harness-v3:call_27055f51ecbd4218ac359d53 -> tool:nanobot-harness-v3:call_eb4ff72ad42f44a48fde54b5 -> tool:nanobot-harness-v3:call_7c235157e55e46e8bf691999 -> tool:nanobot-harness-v3:call_f6f9b4b0efd44d24a4f37d95 -> tool:nanobot-harness-v3:call_de3f5b74609e4d4bb592d84b -> tool:nanobot-harness-v3:call_2453d2da362c4fa9b2b0a339 -> tool:nanobot-harness-v3:call_d6151e12110648c0bb6e0e51 -> tool:nanobot-harness-v3:call_70fb0f5308b14f72adc9eb0e
- 关键路径耗时：0.740882
- Makespan：367.582446
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
