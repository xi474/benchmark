# Workflow 可观测性报告

- Trial：`MP06__ACVrs5z__env`
- Task：`MP06`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（21 节点 / 20 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：21；执行边：20（observed=0，inferred=20）
- Execution Trace Graph：`observed`；temporal_next 边 20，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_fe6a99ccf2804c61a2f6fd3e -> tool:nanobot-harness-v3:call_552591335ab7443780206ff3 -> tool:nanobot-harness-v3:call_f78728235b194202aa5e4dba -> tool:nanobot-harness-v3:call_73ca7edb9ffe48969bd63376 -> tool:nanobot-harness-v3:call_823ef9cd94f14e9aa4f4ab08 -> tool:nanobot-harness-v3:call_169dc632665a44f88fd6acec -> tool:nanobot-harness-v3:call_9ee5247a5d614fa4a437d865 -> tool:nanobot-harness-v3:call_1642b74fd0ad401d98fd771e -> tool:nanobot-harness-v3:call_85408feee3804f718fb35a8d -> tool:nanobot-harness-v3:call_81a068c697e94008b28fd471 -> tool:nanobot-harness-v3:call_1fbe2ece33084deba75ffd98 -> tool:nanobot-harness-v3:call_ad78876062c94ea7a9b2db1d -> tool:nanobot-harness-v3:call_2f5caa3ed4d24c82a47f8da7 -> tool:nanobot-harness-v3:call_56e40af09c47436f9a3d38d5 -> tool:nanobot-harness-v3:call_7149ad1b7b7c4b76a025d6e1 -> tool:nanobot-harness-v3:call_8b353f17ecbd49389d79d8e9 -> tool:nanobot-harness-v3:call_4ea86d0d42cd4ede8adbe76c -> tool:nanobot-harness-v3:call_8aa7fcaf52e4447fbe8fa44e -> tool:nanobot-harness-v3:call_ce4faa5ab7bc40469ca3d383 -> tool:nanobot-harness-v3:call_29135983da284fc68be35487
- 关键路径耗时：0.092091
- Makespan：194.466638
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
