# Workflow 可观测性报告

- Trial：`MP07__nEoe7BF__env`
- Task：`MP07`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_5638ec2533c746f4916629bd -> tool:nanobot-harness-v3:call_474bcf2003a748b9a36608b9 -> tool:nanobot-harness-v3:call_21fd912016a74ddd83ebe64a -> tool:nanobot-harness-v3:call_af579cd9ffef47528ab5cb83 -> tool:nanobot-harness-v3:call_52798170102e4923a4f1c792 -> tool:nanobot-harness-v3:call_0bfe58dea8014a62a53faaec -> tool:nanobot-harness-v3:call_15b420c3331c44f5bbb41050 -> tool:nanobot-harness-v3:call_556ece97a2d347c0b7f36b63 -> tool:nanobot-harness-v3:call_d59ad5d7892d41feab5a7d99 -> tool:nanobot-harness-v3:call_bc827ba0744441a1b9cdbb97 -> tool:nanobot-harness-v3:call_c06ac085a1084c32bc898a15 -> tool:nanobot-harness-v3:call_1ef6e119a3a54f0eaaba5819 -> tool:nanobot-harness-v3:call_86925909773443429cba053f -> tool:nanobot-harness-v3:call_7ed572a596ed431995cffe9b -> tool:nanobot-harness-v3:call_c45f34c128a3472dbc1e0c7e -> tool:nanobot-harness-v3:call_863635822e564d63932b2a21 -> tool:nanobot-harness-v3:call_eb3f0883819041728114e1c9 -> tool:nanobot-harness-v3:call_296615ee2ee042b0b4eece68 -> tool:nanobot-harness-v3:call_41756cbb1fe949069c08139a -> tool:nanobot-harness-v3:call_5ec46d802a38463598eff215 -> tool:nanobot-harness-v3:call_35080fd9aeee40adb8df6721 -> tool:nanobot-harness-v3:call_9199680ce2c545d5b04fedb5 -> tool:nanobot-harness-v3:call_518ad1849937487a994d6130 -> tool:nanobot-harness-v3:call_b65020ac549d4e54a185d395 -> tool:nanobot-harness-v3:call_5734f1f50b284fc6858ac9fc -> tool:nanobot-harness-v3:call_1cb03265ae4e4a238e490eb6 -> tool:nanobot-harness-v3:call_d2d45d98718443a4adf01331 -> tool:nanobot-harness-v3:call_5e1f920af6c54050988b76f5
- 关键路径耗时：1.076007
- Makespan：365.421294
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
