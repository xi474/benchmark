# Workflow 可观测性报告

- Trial：`MP08__LgYn9iK__env`
- Task：`MP08`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_b84e56cfe74f48fd8c33bd1a -> tool:nanobot-harness-v3:call_32a8cb44ef2242b5913af14b -> tool:nanobot-harness-v3:call_468f1d6ab0db415bb1d59b9b -> tool:nanobot-harness-v3:call_b1581270ce7041779ee140f3 -> tool:nanobot-harness-v3:call_8ed59f5cb60642e3be457d0c -> tool:nanobot-harness-v3:call_633350d5349949e9b13f361b -> tool:nanobot-harness-v3:call_08de60145d604155aaeea9f3 -> tool:nanobot-harness-v3:call_afe035bd0d0b42bb97e846dc -> tool:nanobot-harness-v3:call_c2a6ddbd08494a8dacb012d1 -> tool:nanobot-harness-v3:call_3f4ba5eac8f04d1c87870cbe -> tool:nanobot-harness-v3:call_22019f79eac140a98a2651c3 -> tool:nanobot-harness-v3:call_17fa9d6ccd6e455bab0c9338 -> tool:nanobot-harness-v3:call_97b5fa4e83154bc6ad10fb5c -> tool:nanobot-harness-v3:call_56a5f286b0564e5fbfde7c26 -> tool:nanobot-harness-v3:call_7767bd342be24d619086bb0c -> tool:nanobot-harness-v3:call_62a3d4ad4e7e46f6ab6fde43 -> tool:nanobot-harness-v3:call_4aec0504c850428ca9936f3a -> tool:nanobot-harness-v3:call_69ddc3b706dd486d83fa1caf -> tool:nanobot-harness-v3:call_889ee7951b8c47df86181853 -> tool:nanobot-harness-v3:call_b5b1a549895d46a292d82a15 -> tool:nanobot-harness-v3:call_6ab1dc7c8fc648db96a9b016 -> tool:nanobot-harness-v3:call_21f21b45267841b69349e64d -> tool:nanobot-harness-v3:call_38336315c8e84aef9fbca295 -> tool:nanobot-harness-v3:call_7ce7b95c0f0d40839bad59e9 -> tool:nanobot-harness-v3:call_3643b396f7cd4c1c936a7b53 -> tool:nanobot-harness-v3:call_3a313d0939f44510872b3d34 -> tool:nanobot-harness-v3:call_c8e5aa88c33444cf8ecce44c
- 关键路径耗时：0.862213
- Makespan：287.652688
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
