# Workflow 可观测性报告

- Trial：`MP09__Ro8mgc2__env`
- Task：`MP09`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_6bcbf5b3668d45a1ad002213 -> tool:nanobot-harness-v3:call_25b0ee398a984d15ac56f789 -> tool:nanobot-harness-v3:call_2da92f48ec0c48869239a3a1 -> tool:nanobot-harness-v3:call_98cf6cc0215b4d93a6f4339d -> tool:nanobot-harness-v3:call_893c0d2472ce4dea95b24e0b -> tool:nanobot-harness-v3:call_1bfc2873af754af9828c5d5c -> tool:nanobot-harness-v3:call_cee23f9b81ad470b8932a412 -> tool:nanobot-harness-v3:call_996621d0e4544ee1b75e2ff4 -> tool:nanobot-harness-v3:call_845ab290a95f4295ba2d8cf2 -> tool:nanobot-harness-v3:call_6f7bbbe8417b4b53824d4977 -> tool:nanobot-harness-v3:call_c499c83c5bcb484abe617893 -> tool:nanobot-harness-v3:call_77c24b8345c54c279039dfb6 -> tool:nanobot-harness-v3:call_ef6cb93967534079bda9af54 -> tool:nanobot-harness-v3:call_b73331d9260644fbb3956b80 -> tool:nanobot-harness-v3:call_3c5910341bbc40d88ffcb1fb -> tool:nanobot-harness-v3:call_64b6f99ed2934004b9bfa86e -> tool:nanobot-harness-v3:call_9df82935d7a9433b98be9492 -> tool:nanobot-harness-v3:call_f38ffd39426849d2ac6e596b -> tool:nanobot-harness-v3:call_9f145ec0701c4386a7923b11 -> tool:nanobot-harness-v3:call_56a0527143914aaebc601a4a -> tool:nanobot-harness-v3:call_d4ee75abaf8e4926868526c9 -> tool:nanobot-harness-v3:call_ec5ff5398b204ef7819da960 -> tool:nanobot-harness-v3:call_67852a36c20f482aa4ce1611 -> tool:nanobot-harness-v3:call_04bfefc0d68045c4a8fc59c0 -> tool:nanobot-harness-v3:call_21ca9d4823934716bda6405f -> tool:nanobot-harness-v3:call_8b3e6f02ffcb41bba7498c2a -> tool:nanobot-harness-v3:call_1f1364c463484963b4061c99 -> tool:nanobot-harness-v3:call_a4775bdcf66b4e33ab17d67d -> tool:nanobot-harness-v3:call_b0fe37f14efd40da9f416f07 -> tool:nanobot-harness-v3:call_48b37e7474114798ab7054d1 -> tool:nanobot-harness-v3:call_cd347e6c30fd43ba94c48a4a -> tool:nanobot-harness-v3:call_c8f513f4af454646bbaedfb3 -> tool:nanobot-harness-v3:call_9034c1a950054a898d64e857
- 关键路径耗时：1.397544
- Makespan：338.276955
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
