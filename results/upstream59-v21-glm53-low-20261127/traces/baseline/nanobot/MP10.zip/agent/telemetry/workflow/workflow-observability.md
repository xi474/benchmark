# Workflow 可观测性报告

- Trial：`MP10__j92Nsgc__env`
- Task：`MP10`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（47 节点 / 46 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：47；执行边：46（observed=0，inferred=46）
- Execution Trace Graph：`observed`；temporal_next 边 46，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d5c14c72b30c4edeb47794f6 -> tool:nanobot-harness-v3:call_131c995d8a7f421497a4e5df -> tool:nanobot-harness-v3:call_facb5b96425342d2b424f5b1 -> tool:nanobot-harness-v3:call_c1e1333c654245998ccaa9f6 -> tool:nanobot-harness-v3:call_a87f4015fd0e44a4951e4bcb -> tool:nanobot-harness-v3:call_4cbf177d877547f587c8ed6d -> tool:nanobot-harness-v3:call_41747c8f779f4a568602db3a -> tool:nanobot-harness-v3:call_0174ba121ba24491a64bf523 -> tool:nanobot-harness-v3:call_e6adf066c0b14206873234c9 -> tool:nanobot-harness-v3:call_d96c058640b94970acee6e80 -> tool:nanobot-harness-v3:call_7a36f1a3531147f0a0cbddbe -> tool:nanobot-harness-v3:call_89aae6b21f1d40fab6fd63d0 -> tool:nanobot-harness-v3:call_f3080850c82340fb967ed01c -> tool:nanobot-harness-v3:call_ce016024a69343b499b6d4a9 -> tool:nanobot-harness-v3:call_03745ddbb58a4b94924a2468 -> tool:nanobot-harness-v3:call_b34d1f2077b04c03b40d7426 -> tool:nanobot-harness-v3:call_fbf9d764db494c80ab384aea -> tool:nanobot-harness-v3:call_292776dd8cd9469db2f91c91 -> tool:nanobot-harness-v3:call_a4768fb9e91c447c81e2fbef -> tool:nanobot-harness-v3:call_1ae4e702ded24785832d6ed3 -> tool:nanobot-harness-v3:call_151b442e34b540b7b49d03a4 -> tool:nanobot-harness-v3:call_304f2e38989a455eab260ad6 -> tool:nanobot-harness-v3:call_391338e9a79742d59c639bff -> tool:nanobot-harness-v3:call_d0a30802606c43119dde83c6 -> tool:nanobot-harness-v3:call_0d0f7edcf90541ae8c1b4b97 -> tool:nanobot-harness-v3:call_038cb0db85294ec98070cff6 -> tool:nanobot-harness-v3:call_6bcd66eabbc945b38c9da80e -> tool:nanobot-harness-v3:call_47f7e4151b63436ab7b209f8 -> tool:nanobot-harness-v3:call_36dde7bfbda5468bb96c3cc0 -> tool:nanobot-harness-v3:call_2b6bc572f61f40c3a9dfcc33 -> tool:nanobot-harness-v3:call_8621f0a4166c4528b76cc9a1 -> tool:nanobot-harness-v3:call_0d8744fa50024d7a93020433 -> tool:nanobot-harness-v3:call_0dcaec6c39cf46d9a57968a9 -> tool:nanobot-harness-v3:call_e4970b61019043288da49ea5 -> tool:nanobot-harness-v3:call_4ad91140f4124651bf62a31d -> tool:nanobot-harness-v3:call_384bf00562ce4caa87c080d2 -> tool:nanobot-harness-v3:call_e4a871e704de4d9594673572 -> tool:nanobot-harness-v3:call_53c7b6990331417d8943ffb3 -> tool:nanobot-harness-v3:call_ad3582b6030d4c808f12af42 -> tool:nanobot-harness-v3:call_395837b9ee084980a43d0f98 -> tool:nanobot-harness-v3:call_80c46fb7c3e44b3c8e53e0be -> tool:nanobot-harness-v3:call_ed238245d2d54c7282030395 -> tool:nanobot-harness-v3:call_7a15866a67fe4359a5381660 -> tool:nanobot-harness-v3:call_0189f8feda0d45dfab762f6f -> tool:nanobot-harness-v3:call_c91f48827712485c94b7f6e1 -> tool:nanobot-harness-v3:call_a03dc25fbec34a109dedd016
- 关键路径耗时：0.756347
- Makespan：319.037832
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
