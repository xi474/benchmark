# Workflow 可观测性报告

- Trial：`MP12__5i4wQUk__env`
- Task：`MP12`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_246aaf61a52c4333bfdbec83 -> tool:nanobot-harness-v3:call_8e76f0a00da9477b8fa67ec1 -> tool:nanobot-harness-v3:call_816afb9d2bbd41249e771f11 -> tool:nanobot-harness-v3:call_46dde1f4c209422e836015cb -> tool:nanobot-harness-v3:call_317f8c8820a440018f4dad89 -> tool:nanobot-harness-v3:call_1ff7fa28cc0f4e2384c9e787 -> tool:nanobot-harness-v3:call_2f4c51e9f9db47b39199530e -> tool:nanobot-harness-v3:call_0397ee7b1c524d8680a2c849 -> tool:nanobot-harness-v3:call_aa28d67c2f844f8fb5695a84 -> tool:nanobot-harness-v3:call_a6a2248250844ca2acee4798 -> tool:nanobot-harness-v3:call_a0532baef12e4195b8bb83c6 -> tool:nanobot-harness-v3:call_eee3aeb2101942dba29f93db -> tool:nanobot-harness-v3:call_c6afd07e71da4db1ab9e83e2 -> tool:nanobot-harness-v3:call_4c6e275702af4ff19810f04e -> tool:nanobot-harness-v3:call_02acc32e4a334479b7fe8f97 -> tool:nanobot-harness-v3:call_fa0ed4e80c094ba9abce6863 -> tool:nanobot-harness-v3:call_5cf5b9ba154048d3af70cffd -> tool:nanobot-harness-v3:call_d301a40899b345b8a6caa5ac -> tool:nanobot-harness-v3:call_4a21f037b22546cb86911aca -> tool:nanobot-harness-v3:call_4a08c0ee984344619a9c5297 -> tool:nanobot-harness-v3:call_8ce1a4ae8bd94c6985ea0aa6 -> tool:nanobot-harness-v3:call_1ff67b476716433a9fa54443 -> tool:nanobot-harness-v3:call_cb020372a347408c9eed2574 -> tool:nanobot-harness-v3:call_bbbf9dcf41b6468e958b3e4d -> tool:nanobot-harness-v3:call_bea49da7456a4bbfb0ad70cf -> tool:nanobot-harness-v3:call_c42167689911411d9412c710 -> tool:nanobot-harness-v3:call_d9b349bce3374306a67e5104 -> tool:nanobot-harness-v3:call_1701c199ce524e0badfc0f13 -> tool:nanobot-harness-v3:call_a6c62a93d52f411493dcf88e -> tool:nanobot-harness-v3:call_9dd3f196c7b54973b9658b0b -> tool:nanobot-harness-v3:call_e6d910f8ba5c411c85197135 -> tool:nanobot-harness-v3:call_32a93acccf7c405696f7ec4b -> tool:nanobot-harness-v3:call_2b1af8a616974834aa3aad4f -> tool:nanobot-harness-v3:call_6b9ccb2862484db2b3beec61 -> tool:nanobot-harness-v3:call_04f6804a3079460489af1786 -> tool:nanobot-harness-v3:call_c97904f9a1f542a29dafefa4 -> tool:nanobot-harness-v3:call_cf486935153e43f796de9cff -> tool:nanobot-harness-v3:call_69059d52e4de41ab9c1f2c28 -> tool:nanobot-harness-v3:call_522db6c83c834366a7e2a7f0 -> tool:nanobot-harness-v3:call_23808498bd1d44d7b4476b01 -> tool:nanobot-harness-v3:call_94f647be2f504afb9693f7b5 -> tool:nanobot-harness-v3:call_e400fa827cd34810bdf0bdde -> tool:nanobot-harness-v3:call_fca2d1c449464dddb8bf2684 -> tool:nanobot-harness-v3:call_507d2b80647e4d308af86a15 -> tool:nanobot-harness-v3:call_96489ff067e943a8b084849f
- 关键路径耗时：1.218696
- Makespan：463.480816
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
