# Workflow 可观测性报告

- Trial：`MP13__SccVugW__env`
- Task：`MP13`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（45 节点 / 44 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：45；执行边：44（observed=0，inferred=44）
- Execution Trace Graph：`observed`；temporal_next 边 44，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_46cde11e8b5b4c9ab0754d8f -> tool:nanobot-harness-v3:call_68ab5f28d6504fceb45d2dea -> tool:nanobot-harness-v3:call_4670a51febaf4010b400a172 -> tool:nanobot-harness-v3:call_a47336205d6b43dc81a104fa -> tool:nanobot-harness-v3:call_29e1f1713ca54630a43c3672 -> tool:nanobot-harness-v3:call_47d667f5a4484ca1b5d4cd0e -> tool:nanobot-harness-v3:call_445c9a10aafc4b45a490c00d -> tool:nanobot-harness-v3:call_1c24152b28e5457a9a4cafa1 -> tool:nanobot-harness-v3:call_d5df9c4eb042412cb248e6cc -> tool:nanobot-harness-v3:call_9c239366946d4a31bb469cdd -> tool:nanobot-harness-v3:call_9c0249af92d64edeab287844 -> tool:nanobot-harness-v3:call_08f6fc6140f8450780ed1371 -> tool:nanobot-harness-v3:call_3175c8afe59747719a92fc38 -> tool:nanobot-harness-v3:call_2acdb5727ac0426883fbf230 -> tool:nanobot-harness-v3:call_7259bfd7b61445f3959e952d -> tool:nanobot-harness-v3:call_5893fdffbc43401493250a6c -> tool:nanobot-harness-v3:call_642e0ded42b949d39adb4c0d -> tool:nanobot-harness-v3:call_1cdcce8797fb4a8e84ea75bb -> tool:nanobot-harness-v3:call_5dd9deefa1b046e0aef01849 -> tool:nanobot-harness-v3:call_ea3a4c3ae6d94ad7b714bdf1 -> tool:nanobot-harness-v3:call_72608b5f8d1840c2894f746a -> tool:nanobot-harness-v3:call_21fabb68d1624dc281082cee -> tool:nanobot-harness-v3:call_20f3eef508d34c8991a7e7f2 -> tool:nanobot-harness-v3:call_97caaf6795994dd18ac0f38e -> tool:nanobot-harness-v3:call_7093ed6b85804830b8e9094b -> tool:nanobot-harness-v3:call_61a782a7219d4f45845ca731 -> tool:nanobot-harness-v3:call_caa32f1fa9f84b259f8c0015 -> tool:nanobot-harness-v3:call_2ff4d643560449398ccbeba1 -> tool:nanobot-harness-v3:call_0d0ac4b8d8ac42a9800eb0f4 -> tool:nanobot-harness-v3:call_cff1282273f94bc6bf41e237 -> tool:nanobot-harness-v3:call_acb6623870fe4efeb6fedb40 -> tool:nanobot-harness-v3:call_ad2c9d54db3e44119bff49db -> tool:nanobot-harness-v3:call_0f9e051ebf3b4eea8f1827da -> tool:nanobot-harness-v3:call_a9208e12c11f484dbd4f3367 -> tool:nanobot-harness-v3:call_05cbca7f8b2d41d6b1c05235 -> tool:nanobot-harness-v3:call_9c77768ebf4146f4a96afc90 -> tool:nanobot-harness-v3:call_ee1c157aba7d470381fd85f9 -> tool:nanobot-harness-v3:call_bd6742d477304b4585db127b -> tool:nanobot-harness-v3:call_9fbc55c0ac01472bbfd49cad -> tool:nanobot-harness-v3:call_2944b39954df4e96b1559849 -> tool:nanobot-harness-v3:call_7ea4dc54f84e4627af97f672 -> tool:nanobot-harness-v3:call_c1db0ea53f4e4676b8e4a6e2 -> tool:nanobot-harness-v3:call_853ed6c2ff754e36a32f55e0 -> tool:nanobot-harness-v3:call_4b6a4e58240544c9b81c7617
- 关键路径耗时：0.890953
- Makespan：340.889039
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
