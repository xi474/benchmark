# Workflow 可观测性报告

- Trial：`MP14__5opomNG__env`
- Task：`MP14`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（52 节点 / 51 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：52；执行边：51（observed=0，inferred=51）
- Execution Trace Graph：`observed`；temporal_next 边 51，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_7a93b2f7a5054ba68063180a -> tool:nanobot-harness-v3:call_54093385017a437c8f473614 -> tool:nanobot-harness-v3:call_a75ba929503e409ab926cc44 -> tool:nanobot-harness-v3:call_b03210379bff4f478968ccfc -> tool:nanobot-harness-v3:call_dde3222a6d854f50b0e2da51 -> tool:nanobot-harness-v3:call_009f069b397044d9b303633e -> tool:nanobot-harness-v3:call_25e69f08b73842b781ef63bb -> tool:nanobot-harness-v3:call_8a63bc763bce40a6b87f544b -> tool:nanobot-harness-v3:call_922e550d2ec14f939fe2e906 -> tool:nanobot-harness-v3:call_6d0a623f56804f6784a51b93 -> tool:nanobot-harness-v3:call_9c0a189c574f4ebebeef5505 -> tool:nanobot-harness-v3:call_68ac53031eb84a0a8f1cbb6d -> tool:nanobot-harness-v3:call_0bba9e92ff514c7893adf683 -> tool:nanobot-harness-v3:call_a197de3c1b4946b3a322156f -> tool:nanobot-harness-v3:call_f1449dd7778d4f559ebb6291 -> tool:nanobot-harness-v3:call_0c9c46f4a05744dfb2faa8eb -> tool:nanobot-harness-v3:call_edf3e1d3538a49adb3aaad4c -> tool:nanobot-harness-v3:call_3b3b849e075741869476569a -> tool:nanobot-harness-v3:call_95fe9811388142219d774701 -> tool:nanobot-harness-v3:call_6751d46884b548d78efa6dd9 -> tool:nanobot-harness-v3:call_efb9204ce6374059a8129ee5 -> tool:nanobot-harness-v3:call_e0b2360d379b407e91068d2f -> tool:nanobot-harness-v3:call_638f944a24ad48fb8dc958e1 -> tool:nanobot-harness-v3:call_a0a5c18a3a2141ae94938a3a -> tool:nanobot-harness-v3:call_2cfe79ed9aa44244be3b9a60 -> tool:nanobot-harness-v3:call_158d79e30813465db5c479ac -> tool:nanobot-harness-v3:call_7ef7593633ac45cb8b83ecbe -> tool:nanobot-harness-v3:call_c218596cdd1c44f49941d065 -> tool:nanobot-harness-v3:call_a13a9d60bc2f4978bb3be639 -> tool:nanobot-harness-v3:call_53ed62ba478e423c9345a8f4 -> tool:nanobot-harness-v3:call_8184a6a3f6b843c5b3947acf -> tool:nanobot-harness-v3:call_cc75591167c1418f97cc788b -> tool:nanobot-harness-v3:call_68ecd235037c4139b133a4aa -> tool:nanobot-harness-v3:call_44e89a37b3094002b42ce9de -> tool:nanobot-harness-v3:call_bdc3362cd8b249009c2362e4 -> tool:nanobot-harness-v3:call_6b7135ee48aa4f97b85edc17 -> tool:nanobot-harness-v3:call_75c860f5ce6247f9873b7772 -> tool:nanobot-harness-v3:call_8e0b12bd75a445108511cacc -> tool:nanobot-harness-v3:call_4cb68fbd88954262aad35083 -> tool:nanobot-harness-v3:call_0967cbe014544f67babb8d5c -> tool:nanobot-harness-v3:call_850b8d0d252c4d548129ae92 -> tool:nanobot-harness-v3:call_067c90f233004c55a0542d17 -> tool:nanobot-harness-v3:call_6054fb9f492346dea2acae32 -> tool:nanobot-harness-v3:call_4b415a4699984f29b96ba341 -> tool:nanobot-harness-v3:call_c7f794fbf6d5415ea5ce4050 -> tool:nanobot-harness-v3:call_a98967e384c14c0bb5ba7edb -> tool:nanobot-harness-v3:call_6c2f25e8a15641f88eb50873 -> tool:nanobot-harness-v3:call_c25ad7aa775545e9a5489de3 -> tool:nanobot-harness-v3:call_eb9c1993d2de4624b95a39ef -> tool:nanobot-harness-v3:call_cf35b807d8ff48aeacc0ffbc -> tool:nanobot-harness-v3:call_539e5078eab14effb4ff6243
- 关键路径耗时：0.845322
- Makespan：520.005663
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
