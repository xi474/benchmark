# Workflow 可观测性报告

- Trial：`MP15__ZWxCFn5__env`
- Task：`MP15`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（65 节点 / 64 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：65；执行边：64（observed=0，inferred=64）
- Execution Trace Graph：`observed`；temporal_next 边 64，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_ad29cdf538df450d84bfe9ee -> tool:nanobot-harness-v3:call_611f701e58014e5caed5b53f -> tool:nanobot-harness-v3:call_63f0f55cc58d4d60acd746c9 -> tool:nanobot-harness-v3:call_88b8a6c5e3004d8ba876a7da -> tool:nanobot-harness-v3:call_d649ec0172bc4c758a5ce8a9 -> tool:nanobot-harness-v3:call_52d9ac2037b143aa8ae8b6f0 -> tool:nanobot-harness-v3:call_95759db0bb8f41bb85c0e44f -> tool:nanobot-harness-v3:call_f11d4bb668db49ca8872414f -> tool:nanobot-harness-v3:call_29b194413c88408c8ae9d338 -> tool:nanobot-harness-v3:call_a93b9eaf8bda49108481b819 -> tool:nanobot-harness-v3:call_fb8c68b68a63413fa6e5cd25 -> tool:nanobot-harness-v3:call_03d32867bd764e8ca0000c85 -> tool:nanobot-harness-v3:call_99be5a42b43c436fa3f6039f -> tool:nanobot-harness-v3:call_f0cc0e6539db4afbbf62157d -> tool:nanobot-harness-v3:call_3975d6ff942e4f6b91653a1c -> tool:nanobot-harness-v3:call_f1a6bcfad82048bf8a562d95 -> tool:nanobot-harness-v3:call_0ce4681b60c2458caf35d1ec -> tool:nanobot-harness-v3:call_2d15d66ad8ba4871bc1d8cd3 -> tool:nanobot-harness-v3:call_2b2a97dbd5534947ad908e95 -> tool:nanobot-harness-v3:call_92448516fd0e441f99f5ac8e -> tool:nanobot-harness-v3:call_b6fed8d1afe64be8befff415 -> tool:nanobot-harness-v3:call_4b53b4cf7ebd45c08e8cb826 -> tool:nanobot-harness-v3:call_62f03d483a2e4d6a8f008cdc -> tool:nanobot-harness-v3:call_0fd56b97aa9046a59ee8ef66 -> tool:nanobot-harness-v3:call_2c354de11c46424393009896 -> tool:nanobot-harness-v3:call_73b486d2e14f437e864ad46c -> tool:nanobot-harness-v3:call_fc1c87a4aab94904b9f392c1 -> tool:nanobot-harness-v3:call_f97f41f899b74929a6f05d36 -> tool:nanobot-harness-v3:call_ff2abf7ae7b84ad8be6922d7 -> tool:nanobot-harness-v3:call_39f4d03b3806458c9788ae8d -> tool:nanobot-harness-v3:call_c7f369d8a1ee48129e128db4 -> tool:nanobot-harness-v3:call_29362e3aed314393b955f963 -> tool:nanobot-harness-v3:call_f320eb72962f4dfea1260c11 -> tool:nanobot-harness-v3:call_aec2328a487e4e29963e9725 -> tool:nanobot-harness-v3:call_b7b40c3b15254072893318e7 -> tool:nanobot-harness-v3:call_a63987f6a2874546b8bc7fd4 -> tool:nanobot-harness-v3:call_99e453ed05b94577b44590ca -> tool:nanobot-harness-v3:call_69160073e225456d9bce9c74 -> tool:nanobot-harness-v3:call_a3b064b9ee9a40a784e57512 -> tool:nanobot-harness-v3:call_ef4e2e2c2d7e411892d453fb -> tool:nanobot-harness-v3:call_cf375c44e4104c50a6a4cff6 -> tool:nanobot-harness-v3:call_f0decd08135d4b6ea1db7e58 -> tool:nanobot-harness-v3:call_37c915a97785457d83facfd5 -> tool:nanobot-harness-v3:call_560b7614a884425fb6266f4d -> tool:nanobot-harness-v3:call_d13d676529f84a488e62d2d9 -> tool:nanobot-harness-v3:call_7c49a72520784bbe9a593d85 -> tool:nanobot-harness-v3:call_71e7cf5d3d8d4997bf37c800 -> tool:nanobot-harness-v3:call_d2d8e5640f2b4867b1bf3f3c -> tool:nanobot-harness-v3:call_66ecbb409b7843f590b44267 -> tool:nanobot-harness-v3:call_ed5c6a14c211418e980318e6 -> tool:nanobot-harness-v3:call_283c2b19cc724991b68b79e9 -> tool:nanobot-harness-v3:call_14738582c70441b78c673047 -> tool:nanobot-harness-v3:call_7ebadaa058f546e29514cda4 -> tool:nanobot-harness-v3:call_ee2fa9a68d974404a8e6773f -> tool:nanobot-harness-v3:call_2d4eb80f898941b3be01c05b -> tool:nanobot-harness-v3:call_9ea9e79b39e84757882db7cc -> tool:nanobot-harness-v3:call_6ffebce6ca764cc5af0f0d01 -> tool:nanobot-harness-v3:call_90bee8c4ae9e469984c4388f -> tool:nanobot-harness-v3:call_108f5e5899df4b088a36f967 -> tool:nanobot-harness-v3:call_8ec246215b0447e7acf8d078 -> tool:nanobot-harness-v3:call_54066b0823a745ba8b692b1e -> tool:nanobot-harness-v3:call_3e217deb062746aa97cebf85 -> tool:nanobot-harness-v3:call_16b757ea1e654d848a603fd3 -> tool:nanobot-harness-v3:call_7000bf03f8be462ca58f84a5
- 关键路径耗时：1.240968
- Makespan：586.854719
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
