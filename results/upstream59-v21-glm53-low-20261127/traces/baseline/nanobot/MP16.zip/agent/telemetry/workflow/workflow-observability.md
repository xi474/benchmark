# Workflow 可观测性报告

- Trial：`MP16__6woYCL9__env`
- Task：`MP16`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（61 节点 / 60 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：61；执行边：60（observed=0，inferred=60）
- Execution Trace Graph：`observed`；temporal_next 边 60，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_abc81c828ef94a0f854edf76 -> tool:nanobot-harness-v3:call_2c506cc84e1243bc85ff74a0 -> tool:nanobot-harness-v3:call_d39088b68a9e4fd6a814f786 -> tool:nanobot-harness-v3:call_293cf6d411064ba5ba32a153 -> tool:nanobot-harness-v3:call_5990b7f1f8de4fe2ab90785e -> tool:nanobot-harness-v3:call_68073511a76b4d028e393c46 -> tool:nanobot-harness-v3:call_607e47be150f4eb08ef9a47b -> tool:nanobot-harness-v3:call_1ed7b46b4bec4bec8b647c6a -> tool:nanobot-harness-v3:call_6c7c1923040841009da2f084 -> tool:nanobot-harness-v3:call_1c23977b1a004e70a940617f -> tool:nanobot-harness-v3:call_36492c9255124e869e216d64 -> tool:nanobot-harness-v3:call_5dff4465ac464a659fe4887b -> tool:nanobot-harness-v3:call_093e7f1ea683466cbaaa7d17 -> tool:nanobot-harness-v3:call_24111e1d93ef47fc8a44b058 -> tool:nanobot-harness-v3:call_eb41f6d7b362415f8e71154c -> tool:nanobot-harness-v3:call_964f9ef6c032401a8dcd4805 -> tool:nanobot-harness-v3:call_c9011ec354e645218199b296 -> tool:nanobot-harness-v3:call_fc5baa21c0ee479f92ce7d4d -> tool:nanobot-harness-v3:call_a0bb106fdd4948568df5dd85 -> tool:nanobot-harness-v3:call_a2a48a16598c464c87ee4a80 -> tool:nanobot-harness-v3:call_6685979c22754dacb2720fcd -> tool:nanobot-harness-v3:call_2fb6f9cab6e5470ab731202c -> tool:nanobot-harness-v3:call_b99790fbcfe84a2787f079bc -> tool:nanobot-harness-v3:call_7d6314ef863c4d56aa6689d5 -> tool:nanobot-harness-v3:call_745e23fe6afa471e933fd424 -> tool:nanobot-harness-v3:call_7c3f060a8ee74fbb83aef634 -> tool:nanobot-harness-v3:call_d566549d983a417fb26fd6ff -> tool:nanobot-harness-v3:call_765ebebfc91e4deeaf651e62 -> tool:nanobot-harness-v3:call_202b46dd68a14d2ea8cd558d -> tool:nanobot-harness-v3:call_e7c2f6798fa74e9f8248b74c -> tool:nanobot-harness-v3:call_2e8e627b278140f3b8b3c13f -> tool:nanobot-harness-v3:call_1d253cb3415f4f45b021fa13 -> tool:nanobot-harness-v3:call_41febe74c0144f488de8fee7 -> tool:nanobot-harness-v3:call_27cffce8975e43c292380308 -> tool:nanobot-harness-v3:call_5e8d878c6b7c47f0be15293c -> tool:nanobot-harness-v3:call_d49e1511fc8b4b21853ad455 -> tool:nanobot-harness-v3:call_726ada5d13fe43c5b195e707 -> tool:nanobot-harness-v3:call_4cbba88531d7455a8295a0d5 -> tool:nanobot-harness-v3:call_638d7708f9334c29b19ff6ad -> tool:nanobot-harness-v3:call_c8c0cf18c0474a34baa9626f -> tool:nanobot-harness-v3:call_74564ee62d0a45cb9ac5f7e7 -> tool:nanobot-harness-v3:call_7ce2597150ec471483b7697a -> tool:nanobot-harness-v3:call_e9800a7f748645a9be9d8051 -> tool:nanobot-harness-v3:call_fe80bea170e94c3fb77fd30b -> tool:nanobot-harness-v3:call_4c4ce20e0c5c4fe19a1beb94 -> tool:nanobot-harness-v3:call_3b3aa060fd9e4bc3b7a05f25 -> tool:nanobot-harness-v3:call_6af6a63a6b134897beb14b73 -> tool:nanobot-harness-v3:call_dee779491f484dab92316258 -> tool:nanobot-harness-v3:call_d56ff7a870b0461ead141ebc -> tool:nanobot-harness-v3:call_6e337dbe494d4f7cb2cf822f -> tool:nanobot-harness-v3:call_76d69bbe1c804d55b9d8eccc -> tool:nanobot-harness-v3:call_11a6c765a95d4cf2b50422a6 -> tool:nanobot-harness-v3:call_ab46997f9d4b41faa5c8f13c -> tool:nanobot-harness-v3:call_f2fda74fa6784d5fb947baac -> tool:nanobot-harness-v3:call_6ef68dfd154b4b899d2d3193 -> tool:nanobot-harness-v3:call_92c13249ff04415499573632 -> tool:nanobot-harness-v3:call_dc8cfb9c39834e80b27e938b -> tool:nanobot-harness-v3:call_2dee1849d1da40d0a1e69bea -> tool:nanobot-harness-v3:call_1955861e67d24795a19b00bf -> tool:nanobot-harness-v3:call_fc43eaa0312749e0835cd24a
- 关键路径耗时：0.771917
- Makespan：430.800614
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
