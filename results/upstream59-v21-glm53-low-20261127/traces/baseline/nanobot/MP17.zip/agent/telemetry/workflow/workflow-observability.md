# Workflow 可观测性报告

- Trial：`MP17__BGCPmnW__env`
- Task：`MP17`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（45 节点 / 44 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：45；执行边：44（observed=0，inferred=44）
- Execution Trace Graph：`observed`；temporal_next 边 44，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3edac9ac2dc14d96a2a16b14 -> tool:nanobot-harness-v3:call_c10aee6a2f9b47509fb05032 -> tool:nanobot-harness-v3:call_9a28deb0bb2645969a103a17 -> tool:nanobot-harness-v3:call_edec060b6d5145c595f97eab -> tool:nanobot-harness-v3:call_a1efc5fd876e4631bb914ed3 -> tool:nanobot-harness-v3:call_fc57d7b338ef48d9aeccc839 -> tool:nanobot-harness-v3:call_8238bf38504a4f1fbc1404a6 -> tool:nanobot-harness-v3:call_88eae999339f45f89ae730ba -> tool:nanobot-harness-v3:call_a43bf1b5fa7e46438303a72b -> tool:nanobot-harness-v3:call_7af8c86190b84dc1abfad36c -> tool:nanobot-harness-v3:call_c30b0f70a23b4fb7af57aa55 -> tool:nanobot-harness-v3:call_5a3e6b7214fb4ab8b97705c0 -> tool:nanobot-harness-v3:call_3b31842e85b44a83a3ba07ae -> tool:nanobot-harness-v3:call_ff240a7e0ce64918a0a61281 -> tool:nanobot-harness-v3:call_b1416a2164fc4b30a0fc6b61 -> tool:nanobot-harness-v3:call_18b066f20aec484e906ee817 -> tool:nanobot-harness-v3:call_a0a3d244906c47efb43aacee -> tool:nanobot-harness-v3:call_11f3b09681a64cc58fe706a4 -> tool:nanobot-harness-v3:call_2752b07cd1554866adfff53f -> tool:nanobot-harness-v3:call_fd05ac3e12734c94a3524562 -> tool:nanobot-harness-v3:call_53d6413067e84ce493bdcfbb -> tool:nanobot-harness-v3:call_df2c027266164c56b62fd421 -> tool:nanobot-harness-v3:call_a45b4b4cb923456981f47d17 -> tool:nanobot-harness-v3:call_27f66cd7fac44c88a86027ea -> tool:nanobot-harness-v3:call_456efba3084e40138c85ea49 -> tool:nanobot-harness-v3:call_d9822f8d04b14f13b49f9401 -> tool:nanobot-harness-v3:call_8deb3ad877204a4da42ec7dc -> tool:nanobot-harness-v3:call_43930b7b85d849e6a9eb45f5 -> tool:nanobot-harness-v3:call_9490ef8ed4184a76a9a9626c -> tool:nanobot-harness-v3:call_560ab80460fa437da6821621 -> tool:nanobot-harness-v3:call_f124a9f94a3a439184cb5ef9 -> tool:nanobot-harness-v3:call_2848a840338a430281d2167d -> tool:nanobot-harness-v3:call_84f5879e4cfa44758f9a99a6 -> tool:nanobot-harness-v3:call_3fe8588c2f5646fd8d4a1bea -> tool:nanobot-harness-v3:call_57510b454d3b42b7806aed29 -> tool:nanobot-harness-v3:call_ac564a078d424e1b8aef15d8 -> tool:nanobot-harness-v3:call_9d295e4dc9b347568f613bfa -> tool:nanobot-harness-v3:call_cbc2af5f8b2f4d029593655e -> tool:nanobot-harness-v3:call_b5b7a817d4e744b99883e413 -> tool:nanobot-harness-v3:call_4cac05d9d88141faa6b1979f -> tool:nanobot-harness-v3:call_2470b1d0459e4b6ea20a5840 -> tool:nanobot-harness-v3:call_1382142111b94dadb9ad5320 -> tool:nanobot-harness-v3:call_5374c7b8a8044dc4a91c67c8 -> tool:nanobot-harness-v3:call_35addb73d3c54d9b98854a20
- 关键路径耗时：0.678662
- Makespan：362.824765
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
