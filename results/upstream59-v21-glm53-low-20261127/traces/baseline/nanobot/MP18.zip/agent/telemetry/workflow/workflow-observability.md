# Workflow 可观测性报告

- Trial：`MP18__APPG37J__env`
- Task：`MP18`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f42c70fe0b6e4c65a604a068 -> tool:nanobot-harness-v3:call_5d863ac39a9f4cfe92eefbef -> tool:nanobot-harness-v3:call_c72148e89943401a8c51e778 -> tool:nanobot-harness-v3:call_888d22c6a5fb4bf6b7da5aad -> tool:nanobot-harness-v3:call_9d367ca2aaa14e0fbb2d6142 -> tool:nanobot-harness-v3:call_ee2a038bb2314e6685b893c7 -> tool:nanobot-harness-v3:call_c75717100d11472b95642bae -> tool:nanobot-harness-v3:call_b2357ebd580946c8a8044e55 -> tool:nanobot-harness-v3:call_51e8ef69b916407b8464b47c -> tool:nanobot-harness-v3:call_6781eb61218b4b0e92b4ac5f -> tool:nanobot-harness-v3:call_bb21cfd67aea45328649ef71 -> tool:nanobot-harness-v3:call_43dbd28cdc4845f5abd57953 -> tool:nanobot-harness-v3:call_6abd9e7f8ae8497b911f54ed -> tool:nanobot-harness-v3:call_fb4214441e2440e99e0ca309 -> tool:nanobot-harness-v3:call_0146cd550c764940a66c645f -> tool:nanobot-harness-v3:call_22366884bc0d4eb5890ea1dc -> tool:nanobot-harness-v3:call_65410f07d4af44e28b265f39 -> tool:nanobot-harness-v3:call_d0727c12681346e0aaa5d479 -> tool:nanobot-harness-v3:call_332b51d068944dca9a197d31 -> tool:nanobot-harness-v3:call_c222da1d7c8c47939e2adc80 -> tool:nanobot-harness-v3:call_7b391e455f7b40bf9172997d -> tool:nanobot-harness-v3:call_2b1f7d48c6804fc391d10f27 -> tool:nanobot-harness-v3:call_f3c5f23b321e4001a94a8c20 -> tool:nanobot-harness-v3:call_d3146bcc347a4cb9befbec00 -> tool:nanobot-harness-v3:call_ead04a248fc045a6a3e1ef7b -> tool:nanobot-harness-v3:call_3b3d2117ee65491989325620 -> tool:nanobot-harness-v3:call_3e7cc244d3b3494ea1513449 -> tool:nanobot-harness-v3:call_8644fcf4b8dc4ef6b68548c3 -> tool:nanobot-harness-v3:call_8baa1c7463314018bee498b1 -> tool:nanobot-harness-v3:call_810d01bb7c8046858b71058b -> tool:nanobot-harness-v3:call_c5ad54d5c4424c19a1cd3ad8 -> tool:nanobot-harness-v3:call_dba2173cbcb14b9c98e37657 -> tool:nanobot-harness-v3:call_2f06cfb2955e4137a7d3e51f -> tool:nanobot-harness-v3:call_f40f30d754b440c2bf95387c -> tool:nanobot-harness-v3:call_f3fc4aeed70b488a8deb7006 -> tool:nanobot-harness-v3:call_8431f8fb0fa64e54934d50b2 -> tool:nanobot-harness-v3:call_481cd3072ab548509023e39a -> tool:nanobot-harness-v3:call_0860a79fc1fc43778e301663 -> tool:nanobot-harness-v3:call_e6eb2fa88d8c43689c1e3842 -> tool:nanobot-harness-v3:call_afd788753fb54561b64545ee -> tool:nanobot-harness-v3:call_e8d516d3e66b48c1b45efe42
- 关键路径耗时：0.714657
- Makespan：473.836026
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
