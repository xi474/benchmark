# Workflow 可观测性报告

- Trial：`MP19__qU3hPxu__env`
- Task：`MP19`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f5bdc8915ad64ac69edaae2f -> tool:nanobot-harness-v3:call_4eefaa5c66084392af141e80 -> tool:nanobot-harness-v3:call_24c01abd1b754ca2b60866da -> tool:nanobot-harness-v3:call_6e5d95516cb34bb2b7bd02d3 -> tool:nanobot-harness-v3:call_b586ec7f08864f70814e447a -> tool:nanobot-harness-v3:call_a6bbfced670d44829334fb5e -> tool:nanobot-harness-v3:call_3291aae6c103428f989423d2 -> tool:nanobot-harness-v3:call_2a4fee0db6494059915e99ff -> tool:nanobot-harness-v3:call_71a953f97da240698eae211b -> tool:nanobot-harness-v3:call_8ff0eeb34b6e4fc19f109dd6 -> tool:nanobot-harness-v3:call_8e2233be33c6472b8dfcab6e -> tool:nanobot-harness-v3:call_3b0cfd3c02a94486907ef37a -> tool:nanobot-harness-v3:call_62aff6577d89437d8acb39c1 -> tool:nanobot-harness-v3:call_6173cb5a2d9f41a4880da707 -> tool:nanobot-harness-v3:call_ba35440c836e48c7bd47374d -> tool:nanobot-harness-v3:call_427bb25ac4e544c08701dcee -> tool:nanobot-harness-v3:call_e43af3fdc0e142f38e38aea7 -> tool:nanobot-harness-v3:call_064e028be9274798afdeb4bf -> tool:nanobot-harness-v3:call_c72275373a574d5baaf29b61 -> tool:nanobot-harness-v3:call_8964ce49ee0b4ddd90fa5304 -> tool:nanobot-harness-v3:call_55aa028c0adf44c597d7b8c4 -> tool:nanobot-harness-v3:call_0794bcf8ae3549a2b4044dd1 -> tool:nanobot-harness-v3:call_35d89cf0ca3a40f4998fed64 -> tool:nanobot-harness-v3:call_45a4552e3cb94ed59bfd4143 -> tool:nanobot-harness-v3:call_e74b18b1a54144538fc8aa4c -> tool:nanobot-harness-v3:call_2772d803c76246c68237e9c3 -> tool:nanobot-harness-v3:call_1d7cda3ef92e4057a5bdb510 -> tool:nanobot-harness-v3:call_5d811370bbc14736876f2adb -> tool:nanobot-harness-v3:call_843a944574fa4742a5999104 -> tool:nanobot-harness-v3:call_ef939569ba764baca740077d -> tool:nanobot-harness-v3:call_b2a5d0c2b7874cefb0880a7f -> tool:nanobot-harness-v3:call_f59d1553ea5148b0afb9dc8d -> tool:nanobot-harness-v3:call_4ae9b73576c4461e9ad66083 -> tool:nanobot-harness-v3:call_b7db5c58391344859369a795 -> tool:nanobot-harness-v3:call_c114e76fe9a349fcb4fa2732 -> tool:nanobot-harness-v3:call_b9449b88fdd040f385ad0116 -> tool:nanobot-harness-v3:call_3da091becf014982ab0bd4ef -> tool:nanobot-harness-v3:call_bdcb90e8bed6457983a7b636 -> tool:nanobot-harness-v3:call_bba74cc59a1f42e3b82a62f9
- 关键路径耗时：1.144484
- Makespan：432.345848
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
