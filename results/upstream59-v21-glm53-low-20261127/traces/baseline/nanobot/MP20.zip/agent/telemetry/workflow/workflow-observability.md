# Workflow 可观测性报告

- Trial：`MP20__fnhRr8U__env`
- Task：`MP20`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_2040c1eed04c40a5b6fbbbfc -> tool:nanobot-harness-v3:call_4708ecdedccc430e83f1c099 -> tool:nanobot-harness-v3:call_043a19fa0a304c2b84cbc658 -> tool:nanobot-harness-v3:call_2078757a7ea949ebb296acaa -> tool:nanobot-harness-v3:call_aa53059b96ef430bb068ded3 -> tool:nanobot-harness-v3:call_24110ad8c6174ed387598d3c -> tool:nanobot-harness-v3:call_cf331fcea891484db8bf27c7 -> tool:nanobot-harness-v3:call_ad9df031be904f889d594722 -> tool:nanobot-harness-v3:call_b9ddc9f53454456bba979126 -> tool:nanobot-harness-v3:call_f02b7ddbca674966bd6449ff -> tool:nanobot-harness-v3:call_c757a524e316488b9772fd5c -> tool:nanobot-harness-v3:call_a089a7d1b6574afdbc9179c4 -> tool:nanobot-harness-v3:call_db374fe46bb44bf2a30aca97 -> tool:nanobot-harness-v3:call_f22ec55588ec4afd9c3bcff2 -> tool:nanobot-harness-v3:call_8d0f0e434bad49078ba6402f -> tool:nanobot-harness-v3:call_04d8fa9bb5da46e69657f97e -> tool:nanobot-harness-v3:call_703cee18751247d794df1969 -> tool:nanobot-harness-v3:call_cb2976e9f2aa44ab90e66295 -> tool:nanobot-harness-v3:call_7eea0004503349308d36f1d7 -> tool:nanobot-harness-v3:call_5990d297276e4c4688089d6b -> tool:nanobot-harness-v3:call_20aa43c6eaaa4b15971593da -> tool:nanobot-harness-v3:call_40db19a1a7584fa8b85a419e -> tool:nanobot-harness-v3:call_2db3cc0760264566a035c08b -> tool:nanobot-harness-v3:call_068146c59ca74e8ea9b7e324 -> tool:nanobot-harness-v3:call_9938d3f1d91e44fb8c8c4797 -> tool:nanobot-harness-v3:call_e55dac2cbfda409094d4e3f3 -> tool:nanobot-harness-v3:call_5d7fd8cb7833414d86271777
- 关键路径耗时：0.830416
- Makespan：355.712661
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
