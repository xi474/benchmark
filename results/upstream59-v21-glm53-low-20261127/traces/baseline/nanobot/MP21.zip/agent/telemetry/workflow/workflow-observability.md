# Workflow 可观测性报告

- Trial：`MP21__9TPNWSa__env`
- Task：`MP21`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（43 节点 / 42 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：43；执行边：42（observed=0，inferred=42）
- Execution Trace Graph：`observed`；temporal_next 边 42，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_bc553cf8feba4745a79a8637 -> tool:nanobot-harness-v3:call_3652816efacd422c9f9d8838 -> tool:nanobot-harness-v3:call_cf636cf3ff42467681b5f64f -> tool:nanobot-harness-v3:call_bfd47c58651a46e0ae486989 -> tool:nanobot-harness-v3:call_8d8a7980e75f4be7bfad1039 -> tool:nanobot-harness-v3:call_02f1cdbf2440415e83a860ca -> tool:nanobot-harness-v3:call_8c3ad84caa4b4be5a3f47334 -> tool:nanobot-harness-v3:call_02bdd19758604a8f8c877ede -> tool:nanobot-harness-v3:call_1d3b10c8ad9442c1843e19d0 -> tool:nanobot-harness-v3:call_8eb5961090544923b5751e36 -> tool:nanobot-harness-v3:call_bf6061effdf04455b35e811c -> tool:nanobot-harness-v3:call_1d705d9e70934a868ef1491c -> tool:nanobot-harness-v3:call_442ae6e30fca4e1ea96655b3 -> tool:nanobot-harness-v3:call_c36ae725c3c94b7a9aab186d -> tool:nanobot-harness-v3:call_3bcde75f1e6249eeaca2151e -> tool:nanobot-harness-v3:call_80b71845755d40908123e006 -> tool:nanobot-harness-v3:call_225a9a8869904dd1bb5f9c82 -> tool:nanobot-harness-v3:call_ae438a1ef4954df8ae2fe1bb -> tool:nanobot-harness-v3:call_bda2b46db23b4d22bdf911df -> tool:nanobot-harness-v3:call_e12af021d9c449448cd93a36 -> tool:nanobot-harness-v3:call_c517483c45d5470daa3c1745 -> tool:nanobot-harness-v3:call_0cd6d72f66ea415eadbdd3f9 -> tool:nanobot-harness-v3:call_056f58f8e40a4f84a860096d -> tool:nanobot-harness-v3:call_8f058f8136ab46bc947ac694 -> tool:nanobot-harness-v3:call_ef297d66b015483a82de8865 -> tool:nanobot-harness-v3:call_747dd5d0a5944addbde47a7a -> tool:nanobot-harness-v3:call_1ce677917e184337baedb3f2 -> tool:nanobot-harness-v3:call_608472f08f804bdbb94e1098 -> tool:nanobot-harness-v3:call_2cb90b3a13a74a76961bcb42 -> tool:nanobot-harness-v3:call_8181d76e971847f9b1709579 -> tool:nanobot-harness-v3:call_59537732ee604ce899ee40ed -> tool:nanobot-harness-v3:call_89cc47cb65a74e10a345e627 -> tool:nanobot-harness-v3:call_8c974618828041009d12df35 -> tool:nanobot-harness-v3:call_66e8fe27608f4c74bcc2994f -> tool:nanobot-harness-v3:call_fab635321df343dfb91d2fc7 -> tool:nanobot-harness-v3:call_562353ae72c24941b747fcec -> tool:nanobot-harness-v3:call_ee497f9332c0421691135adc -> tool:nanobot-harness-v3:call_71242e6b123846799faa9643 -> tool:nanobot-harness-v3:call_2c07b03647bb46ff950acb5e -> tool:nanobot-harness-v3:call_419bd5cdcc6f41b98ac0fc9d -> tool:nanobot-harness-v3:call_7badc7e35da0413c8c292ae4 -> tool:nanobot-harness-v3:call_d3b423c804624668a67f6ffb
- 关键路径耗时：0.524691
- Makespan：324.931796
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
