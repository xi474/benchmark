# Workflow 可观测性报告

- Trial：`MP22__Vbg8c6Z__env`
- Task：`MP22`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（49 节点 / 48 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：49；执行边：48（observed=0，inferred=48）
- Execution Trace Graph：`observed`；temporal_next 边 48，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_2026c76c84d94f35986d4d8e -> tool:nanobot-harness-v3:call_04eb5096200549cd8f8105cf -> tool:nanobot-harness-v3:call_0fa454c7a4004d5b8d2ae730 -> tool:nanobot-harness-v3:call_5d8c1c5459754135921a3c3d -> tool:nanobot-harness-v3:call_12dc190f92b04cb68a707380 -> tool:nanobot-harness-v3:call_6e4b564089064b8d96b253e9 -> tool:nanobot-harness-v3:call_6e65c63eca474523bceb6913 -> tool:nanobot-harness-v3:call_ca79b1b978b248cd8fe4cd3c -> tool:nanobot-harness-v3:call_d2479671570d4a1abf7d6ca7 -> tool:nanobot-harness-v3:call_737a36d037f0483cbc18aca0 -> tool:nanobot-harness-v3:call_24f5e8b5ef6a4a779991a25b -> tool:nanobot-harness-v3:call_715e6f5518f24d43b72eca33 -> tool:nanobot-harness-v3:call_fcbd5f8b23d54682a631822a -> tool:nanobot-harness-v3:call_898af6757c604519a7f05b64 -> tool:nanobot-harness-v3:call_50b9161422af49ad9a67b85a -> tool:nanobot-harness-v3:call_f02393a72e3a4d10bb0c5d75 -> tool:nanobot-harness-v3:call_d5379b66ebd8499bb3daadc0 -> tool:nanobot-harness-v3:call_f32b1991789545beba929cbb -> tool:nanobot-harness-v3:call_909f888a16a34c5faee58e42 -> tool:nanobot-harness-v3:call_947d7e34a1d747fea622c13d -> tool:nanobot-harness-v3:call_4a47127004e44612a8de8326 -> tool:nanobot-harness-v3:call_44c8244bf55f41b690f2a1c4 -> tool:nanobot-harness-v3:call_45c4013b063947c69b35f9a7 -> tool:nanobot-harness-v3:call_8434cd8c565d48b79e126433 -> tool:nanobot-harness-v3:call_5f0e36c3e1f344afabc4eb50 -> tool:nanobot-harness-v3:call_a52444e0c36f46c19573624a -> tool:nanobot-harness-v3:call_db03585e9e484a4ba9801524 -> tool:nanobot-harness-v3:call_770d72159897455e8acef4c9 -> tool:nanobot-harness-v3:call_e5fb5560c4334e70adc409e6 -> tool:nanobot-harness-v3:call_1edf89629c8d4d5e9f088fc5 -> tool:nanobot-harness-v3:call_a1a09a96a3be4843b906c156 -> tool:nanobot-harness-v3:call_3af2de0f5347448ea9693803 -> tool:nanobot-harness-v3:call_65cb7f3e7284438dbc40d85d -> tool:nanobot-harness-v3:call_b869920c903f440d9b88c7f5 -> tool:nanobot-harness-v3:call_e25c4cfdcba44a64a7b8088d -> tool:nanobot-harness-v3:call_a1f1936c188a4e9598ea905c -> tool:nanobot-harness-v3:call_1e60d8b83c564c578f0aff33 -> tool:nanobot-harness-v3:call_e591b65d0cf8491d9c4d4cb8 -> tool:nanobot-harness-v3:call_85ac41a140a546e0b7fd4c65 -> tool:nanobot-harness-v3:call_161969cce73b4b89975871da -> tool:nanobot-harness-v3:call_90f3a58e00c943f4b8a0a5bd -> tool:nanobot-harness-v3:call_452f319c3f284d20913fe2db -> tool:nanobot-harness-v3:call_0d67e632379042ad961e3a5f -> tool:nanobot-harness-v3:call_137c0b1caac24bd8afe089b6 -> tool:nanobot-harness-v3:call_cfece96d51a44393b55728a3 -> tool:nanobot-harness-v3:call_df3919d136ee4a5fb5b2c580 -> tool:nanobot-harness-v3:call_8301b2f9ed9041c8b60688ca -> tool:nanobot-harness-v3:call_0bb111d082174e7fab69d976
- 关键路径耗时：1.201904
- Makespan：477.18449
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
