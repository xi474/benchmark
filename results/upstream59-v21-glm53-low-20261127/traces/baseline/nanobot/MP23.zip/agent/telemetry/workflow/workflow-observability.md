# Workflow 可观测性报告

- Trial：`MP23__HWAxm9U__env`
- Task：`MP23`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（61 节点 / 60 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：61；执行边：60（observed=0，inferred=60）
- Execution Trace Graph：`observed`；temporal_next 边 60，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_4cd37189f82c46b0ac5b4da5 -> tool:nanobot-harness-v3:call_763e0badf9364035be6f2487 -> tool:nanobot-harness-v3:call_c098f51355334f9b81288dc9 -> tool:nanobot-harness-v3:call_803dc5fb609b42beaeea1534 -> tool:nanobot-harness-v3:call_35fa37c8d66b492983a5d94c -> tool:nanobot-harness-v3:call_bd018b9b19344ff6b5568103 -> tool:nanobot-harness-v3:call_e0fc8f76045848479d8f6f8b -> tool:nanobot-harness-v3:call_c082f5f950fb4e0abbcec0ec -> tool:nanobot-harness-v3:call_ddcb24a0e3aa4c1ca67aa5ed -> tool:nanobot-harness-v3:call_8a81f3f5918746eb8d5ff791 -> tool:nanobot-harness-v3:call_05ed1ae8424b4d9a8ccd85bd -> tool:nanobot-harness-v3:call_e2db73b49cd447818480b037 -> tool:nanobot-harness-v3:call_0160eaeed5424248afbe9eb6 -> tool:nanobot-harness-v3:call_e8b36f15c6624ee3857b052d -> tool:nanobot-harness-v3:call_e0e3d555734c4387a50e56db -> tool:nanobot-harness-v3:call_aa3cf6c3de1a45289e6c422c -> tool:nanobot-harness-v3:call_68ca2b6ca6c04886a0f73ae0 -> tool:nanobot-harness-v3:call_aa2a7c5868a5418eb30b0207 -> tool:nanobot-harness-v3:call_cf8c4ead5a024b57841fa4bb -> tool:nanobot-harness-v3:call_befa5b8fe43c4172b0d83254 -> tool:nanobot-harness-v3:call_e4687364593c4c5e95a92d7c -> tool:nanobot-harness-v3:call_7c103ed2c76c43e6a6665166 -> tool:nanobot-harness-v3:call_3af10063904543ca877bf3a6 -> tool:nanobot-harness-v3:call_5455e1e2b2d24c4a8e5514e0 -> tool:nanobot-harness-v3:call_aa96a88b490147e79c487afc -> tool:nanobot-harness-v3:call_8bb6b07aee3844209abd7e05 -> tool:nanobot-harness-v3:call_9a6171f02da247dcaed695d5 -> tool:nanobot-harness-v3:call_891c0783cc384bd589b5bcbb -> tool:nanobot-harness-v3:call_441ed70977514d4c90c42fa4 -> tool:nanobot-harness-v3:call_e04c7db82611487f827040ab -> tool:nanobot-harness-v3:call_78f9e146d0ed42a8a07bb45e -> tool:nanobot-harness-v3:call_abdb2a4f81be4caebc53e20d -> tool:nanobot-harness-v3:call_ee0943e6c20645549bf19307 -> tool:nanobot-harness-v3:call_84f23570efbf4d3d8e40e201 -> tool:nanobot-harness-v3:call_90d28bdfca7a4d3094be9bfd -> tool:nanobot-harness-v3:call_9e757b495eb7476daeff743f -> tool:nanobot-harness-v3:call_40cafba5915c4b3fa7c306c9 -> tool:nanobot-harness-v3:call_8c8ffea086a14711b5eaeead -> tool:nanobot-harness-v3:call_5b580e62f1ab4bd89f030a2c -> tool:nanobot-harness-v3:call_acfbc2d59b334c3b91956f4c -> tool:nanobot-harness-v3:call_c4b5705fafc14aaba6cff6a3 -> tool:nanobot-harness-v3:call_8f4d95fce600493da489247c -> tool:nanobot-harness-v3:call_d395488b77ae410a96300b79 -> tool:nanobot-harness-v3:call_b642e78692d44a69826c687e -> tool:nanobot-harness-v3:call_c54954bcfbff441d9fe75429 -> tool:nanobot-harness-v3:call_76a92bcc77904c99880a1db3 -> tool:nanobot-harness-v3:call_b354834323b94f70a87ec2f1 -> tool:nanobot-harness-v3:call_af64e924818f44a09abcf8ef -> tool:nanobot-harness-v3:call_cf437e5dc72b4842ad11f430 -> tool:nanobot-harness-v3:call_89bda70e643e4caea4885c2b -> tool:nanobot-harness-v3:call_aecf796008c44139a52222cd -> tool:nanobot-harness-v3:call_f7f89229c00448a094adf6bc -> tool:nanobot-harness-v3:call_947e5c23564b4c07a40ed6d5 -> tool:nanobot-harness-v3:call_126e4587bfaa4a2989078af5 -> tool:nanobot-harness-v3:call_3c76d74559e44517b8ed852b -> tool:nanobot-harness-v3:call_93dce321670c44d29fe817a2 -> tool:nanobot-harness-v3:call_f52da6041fc1415eb422acbb -> tool:nanobot-harness-v3:call_2dabef2948c94c33aeeaab7c -> tool:nanobot-harness-v3:call_60f26f5572fa4b8abb068182 -> tool:nanobot-harness-v3:call_11d43a68a8c74b0184600143
- 关键路径耗时：1.266176
- Makespan：534.081573
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
