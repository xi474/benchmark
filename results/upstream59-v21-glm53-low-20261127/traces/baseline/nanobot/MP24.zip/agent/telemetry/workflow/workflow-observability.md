# Workflow 可观测性报告

- Trial：`MP24__zGG2YTo__env`
- Task：`MP24`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（54 节点 / 53 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：54；执行边：53（observed=0，inferred=53）
- Execution Trace Graph：`observed`；temporal_next 边 53，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_5434288fe55846eda656ee5d -> tool:nanobot-harness-v3:call_87f6cac95de44fdfa67b0bad -> tool:nanobot-harness-v3:call_36afc52333f1488ead43b42f -> tool:nanobot-harness-v3:call_54dc455c0db449db9ea627eb -> tool:nanobot-harness-v3:call_bbc71cdc5e48425cb3246908 -> tool:nanobot-harness-v3:call_1b505f41f3114eabb0c146a9 -> tool:nanobot-harness-v3:call_b56ebc59b5c345aeb8acf893 -> tool:nanobot-harness-v3:call_17e29d501628422d9e22b22a -> tool:nanobot-harness-v3:call_c84b1c43ddc74574a55e545e -> tool:nanobot-harness-v3:call_eb2ccbae92ff40f3a78af1bc -> tool:nanobot-harness-v3:call_8856fe15d88b44858335978c -> tool:nanobot-harness-v3:call_efd72c68dadd422e9d14e1b0 -> tool:nanobot-harness-v3:call_82494410a8e34b9fa18213c9 -> tool:nanobot-harness-v3:call_f8818d698107432ab7e6c0cb -> tool:nanobot-harness-v3:call_7dfbf0310eae4de1aab62cfa -> tool:nanobot-harness-v3:call_af37f393902946e28cc766e2 -> tool:nanobot-harness-v3:call_fc49d70fee2045438a7d5613 -> tool:nanobot-harness-v3:call_93a88606aa5a43e5874ee167 -> tool:nanobot-harness-v3:call_8f0d74a574da4e2dac912eb6 -> tool:nanobot-harness-v3:call_587ce567c2cd45a78c73e21e -> tool:nanobot-harness-v3:call_6a48fb9ddc894dffab097db7 -> tool:nanobot-harness-v3:call_a96439aec3264a5b80435555 -> tool:nanobot-harness-v3:call_9db658f3e30b449b9d27a161 -> tool:nanobot-harness-v3:call_e592c81fc3f94be6b8fdfba1 -> tool:nanobot-harness-v3:call_1aa3c13005584adb8d84eddd -> tool:nanobot-harness-v3:call_07544d05dcba4c6c8026a0fb -> tool:nanobot-harness-v3:call_949589d2f3ac4846ba66e48a -> tool:nanobot-harness-v3:call_704671d4232f4f2fbee31b38 -> tool:nanobot-harness-v3:call_bfe9c253ce254ec798d7bd82 -> tool:nanobot-harness-v3:call_5979e249629b49c3be0cc1ae -> tool:nanobot-harness-v3:call_64c50ee239a8494d8ccbf4df -> tool:nanobot-harness-v3:call_ab01bd20c62645c4909fd020 -> tool:nanobot-harness-v3:call_d768c9e5becd4977a625fc48 -> tool:nanobot-harness-v3:call_24174db26ebf4ecd960efe19 -> tool:nanobot-harness-v3:call_9e951532de0240cebdecb9f9 -> tool:nanobot-harness-v3:call_670753a1fa504fc89e957933 -> tool:nanobot-harness-v3:call_9ffe2206344843e8b4a3e2a6 -> tool:nanobot-harness-v3:call_bf2150019bc048668e3a1e78 -> tool:nanobot-harness-v3:call_54b77a3915cf4d83ae9152ef -> tool:nanobot-harness-v3:call_fc075234960842f894537f31 -> tool:nanobot-harness-v3:call_d29edb0611be4c3b8662968d -> tool:nanobot-harness-v3:call_69e99c72c20b4a93a7016be6 -> tool:nanobot-harness-v3:call_f7095ad9def3497694b45317 -> tool:nanobot-harness-v3:call_b82a90425be9429080f16b51 -> tool:nanobot-harness-v3:call_4ec89fc4a6fb4844a3889f48 -> tool:nanobot-harness-v3:call_f5f76d0e20534adea1282906 -> tool:nanobot-harness-v3:call_35462994c5ed4b90a906491f -> tool:nanobot-harness-v3:call_ebd582cac8fa427f9e5fa59b -> tool:nanobot-harness-v3:call_b83a21bd8aaf45609802f724 -> tool:nanobot-harness-v3:call_c98e04555a6849b5be154038 -> tool:nanobot-harness-v3:call_2f85897f915e42288ab5795a -> tool:nanobot-harness-v3:call_3d6d5568b9f04fc980ed473a -> tool:nanobot-harness-v3:call_17eabd63617c482aa39504ec
- 关键路径耗时：1.108915
- Makespan：390.390121
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
