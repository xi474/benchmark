# Workflow 可观测性报告

- Trial：`MP25__w3b2oaH__env`
- Task：`MP25`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（47 节点 / 46 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：47；执行边：46（observed=0，inferred=46）
- Execution Trace Graph：`observed`；temporal_next 边 46，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_16d3934ec6fb4c1fa99e2a6f -> tool:nanobot-harness-v3:call_23be261efa6d4b518d77d383 -> tool:nanobot-harness-v3:call_1dc3cab778d64555957ef97f -> tool:nanobot-harness-v3:call_d455b4c7c26d47fb89d710ee -> tool:nanobot-harness-v3:call_1ea4af70f3b24b3784b22355 -> tool:nanobot-harness-v3:call_b0837ce88a98472ba55eb0f1 -> tool:nanobot-harness-v3:call_d9b2db62b7c7419b87a9dad4 -> tool:nanobot-harness-v3:call_383346cc1c5940d593f2f84f -> tool:nanobot-harness-v3:call_e1822e7c86e34fc6a4c4dc51 -> tool:nanobot-harness-v3:call_f0a4e46a99df405b9f60563a -> tool:nanobot-harness-v3:call_a9f65fb1adf44287a0049dcb -> tool:nanobot-harness-v3:call_a8dbcb72ec964b459d71e8ad -> tool:nanobot-harness-v3:call_3731700a313d456f840a0462 -> tool:nanobot-harness-v3:call_a5e814c3c430466eacd5584c -> tool:nanobot-harness-v3:call_9da64684097744ee836989e0 -> tool:nanobot-harness-v3:call_e4999965c1bc470f91d5ce94 -> tool:nanobot-harness-v3:call_e037558fcdd048abbff7d4a6 -> tool:nanobot-harness-v3:call_123db71abf8241cf96f1537f -> tool:nanobot-harness-v3:call_c8bc419a185247cf9d00b597 -> tool:nanobot-harness-v3:call_e618cda518f54309b7f30a69 -> tool:nanobot-harness-v3:call_4339c7513bd341149e7bc955 -> tool:nanobot-harness-v3:call_bcc0f4bc88454d1cbe88ecdc -> tool:nanobot-harness-v3:call_0d37fac13b4940a488eb5015 -> tool:nanobot-harness-v3:call_e2638057d299422080223f21 -> tool:nanobot-harness-v3:call_02802bf8d07c41c6bd3a4d28 -> tool:nanobot-harness-v3:call_24e97a6668744c86a7ad1db2 -> tool:nanobot-harness-v3:call_adf7309e91be4a75a696cc30 -> tool:nanobot-harness-v3:call_3ba0e297eabd447eaabd6992 -> tool:nanobot-harness-v3:call_c2dbb3202ebf4024858c8f59 -> tool:nanobot-harness-v3:call_f5df18a626794fb2877b23f4 -> tool:nanobot-harness-v3:call_0a1fe948faa144e5a826643b -> tool:nanobot-harness-v3:call_c330d4550e6f406ea558dcdf -> tool:nanobot-harness-v3:call_770da801606c4c1c9ffecb4f -> tool:nanobot-harness-v3:call_db622b80f48b4b78a657ecfc -> tool:nanobot-harness-v3:call_684658029d854fbc8ba29269 -> tool:nanobot-harness-v3:call_7162dc8352af4c39b465e64b -> tool:nanobot-harness-v3:call_ecdb40eaff414f349b50930d -> tool:nanobot-harness-v3:call_bea32880902249f781a1c027 -> tool:nanobot-harness-v3:call_8c04e6936f7b45efaac575ee -> tool:nanobot-harness-v3:call_142b4997882c45e2a162b3e6 -> tool:nanobot-harness-v3:call_2cecd665b0da41058fab8595 -> tool:nanobot-harness-v3:call_e85b0ccb9d3f4101b611265d -> tool:nanobot-harness-v3:call_77202c64cdc244089058408e -> tool:nanobot-harness-v3:call_61225acbfc29480aa8f8cd36 -> tool:nanobot-harness-v3:call_61ebfdb266b4465597e57f70 -> tool:nanobot-harness-v3:call_2a9d4856630f4f7cbdf3d9e1
- 关键路径耗时：0.866782
- Makespan：269.816087
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
