# Workflow 可观测性报告

- Trial：`MP26__2QUJdVy__env`
- Task：`MP26`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（60 节点 / 59 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：60；执行边：59（observed=0，inferred=59）
- Execution Trace Graph：`observed`；temporal_next 边 59，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_be4b0a1a737b4327924b8b4b -> tool:nanobot-harness-v3:call_a41f4879d02b4723bba4268d -> tool:nanobot-harness-v3:call_322c075672af44eab992944c -> tool:nanobot-harness-v3:call_a0f9241b124c4ccc9e3bea4c -> tool:nanobot-harness-v3:call_b5dd14f55d2641b0a935ab8f -> tool:nanobot-harness-v3:call_adc25a333ccb4151a3f9ea35 -> tool:nanobot-harness-v3:call_da7efa0bd2954b6f964de89a -> tool:nanobot-harness-v3:call_7dd8fbc01fba4dc0b2653f6d -> tool:nanobot-harness-v3:call_3486122a99f24925ae8d2558 -> tool:nanobot-harness-v3:call_1506a48fa81f48e5a05abb8a -> tool:nanobot-harness-v3:call_c7b9167e0d32490a8de98fe5 -> tool:nanobot-harness-v3:call_3baa55ad6211428db778578b -> tool:nanobot-harness-v3:call_e73e6213e7b4454494b4080a -> tool:nanobot-harness-v3:call_c6065e691739460785425af4 -> tool:nanobot-harness-v3:call_78aba5f63d3b4a84b5adb556 -> tool:nanobot-harness-v3:call_e5d59ca43ad2430086496700 -> tool:nanobot-harness-v3:call_e032f3b5117f41bda14c05bd -> tool:nanobot-harness-v3:call_8773cf5b2497405e98924259 -> tool:nanobot-harness-v3:call_f95cfee8f3864d768e1a894c -> tool:nanobot-harness-v3:call_3f32c92653ea426ba15b25cf -> tool:nanobot-harness-v3:call_885f60dfb8bd492385d90c9e -> tool:nanobot-harness-v3:call_40946f83f7424061a6ab588f -> tool:nanobot-harness-v3:call_84a97ea13fbe4151af97facf -> tool:nanobot-harness-v3:call_156783eefca44f14a8db3cae -> tool:nanobot-harness-v3:call_1b5a6fc73b2545b5b74e9792 -> tool:nanobot-harness-v3:call_bb84de3a1d714a959469ce39 -> tool:nanobot-harness-v3:call_8802ab3b3aa941f5bf19b625 -> tool:nanobot-harness-v3:call_23d3e1c1cffd44bfba83dcdd -> tool:nanobot-harness-v3:call_9a551e1b2f374dca9adfafa0 -> tool:nanobot-harness-v3:call_85286b251ca94f7b8c057cc7 -> tool:nanobot-harness-v3:call_4ed142e405264ceb8fe8c5e8 -> tool:nanobot-harness-v3:call_5092b9e8e2a54a67b7f757bf -> tool:nanobot-harness-v3:call_26427db03522486e8ddd4e33 -> tool:nanobot-harness-v3:call_576496f2088c4bb993c45b6c -> tool:nanobot-harness-v3:call_feae296bfb76488bba10bac9 -> tool:nanobot-harness-v3:call_51db20ef3ffe4628939230ca -> tool:nanobot-harness-v3:call_f5f8b7cc863d442d95ad1a62 -> tool:nanobot-harness-v3:call_862e627142854c45b9ddf211 -> tool:nanobot-harness-v3:call_bd8831992bac4650a3f17048 -> tool:nanobot-harness-v3:call_d50245c07eb64ac1a0d834da -> tool:nanobot-harness-v3:call_9fb545b3e15d4ff69f6d8f6d -> tool:nanobot-harness-v3:call_b1e9835bc03749bd87af80f3 -> tool:nanobot-harness-v3:call_0c39e27e17eb467589e2f7fa -> tool:nanobot-harness-v3:call_7a812a00967645f291515527 -> tool:nanobot-harness-v3:call_144219b108594d3389205b71 -> tool:nanobot-harness-v3:call_f7d1b2eed1aa44c0acdcda40 -> tool:nanobot-harness-v3:call_2fcc1d91bd984774950222f4 -> tool:nanobot-harness-v3:call_101b985b798742cea357c666 -> tool:nanobot-harness-v3:call_931515194e294e5483fff1ca -> tool:nanobot-harness-v3:call_fd9ef20aca6f488fa43617b5 -> tool:nanobot-harness-v3:call_1173637a67c44d59af25b4b7 -> tool:nanobot-harness-v3:call_c557caa3738e423eba23acdd -> tool:nanobot-harness-v3:call_4102b1a140324167b164fd65 -> tool:nanobot-harness-v3:call_9f4824e285444b838d59f253 -> tool:nanobot-harness-v3:call_c5c844dd35284fe18debb152 -> tool:nanobot-harness-v3:call_5712e222ac23464fb14d197c -> tool:nanobot-harness-v3:call_f1a93942050d45b0adb8a34c -> tool:nanobot-harness-v3:call_4b5ab86fcd20402f850e5b30 -> tool:nanobot-harness-v3:call_c7cf5e8b43eb463fac6fb690
- 关键路径耗时：1.487328
- Makespan：357.591998
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
