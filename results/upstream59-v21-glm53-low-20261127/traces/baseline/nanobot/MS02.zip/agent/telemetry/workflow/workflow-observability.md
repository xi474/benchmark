# Workflow 可观测性报告

- Trial：`MS02__hC9FY5K__env`
- Task：`MS02`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（20 节点 / 19 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：20；执行边：19（observed=0，inferred=19）
- Execution Trace Graph：`observed`；temporal_next 边 19，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00968d22d1164cd4bf8e71fd -> tool:nanobot-harness-v3:call_f4fe6ecd86fa49678914a1d3 -> tool:nanobot-harness-v3:call_78493d2217124bb8b2aeb6c5 -> tool:nanobot-harness-v3:call_ac2f381c72944b5799eacbc3 -> tool:nanobot-harness-v3:call_3f188044655e40ffb0b3f842 -> tool:nanobot-harness-v3:call_1b3bb98fd4c34754b21f0da8 -> tool:nanobot-harness-v3:call_6103cd12e3f1470b87d06029 -> tool:nanobot-harness-v3:call_fbccad74a9cd4f6fa440a8d8 -> tool:nanobot-harness-v3:call_2ae0a7b39a0f46f7804f8ba3 -> tool:nanobot-harness-v3:call_63a352c1946144989533b99b -> tool:nanobot-harness-v3:call_1e98935a9df94f67b2edc535 -> tool:nanobot-harness-v3:call_8fe5e1a7a3e9459e8fb3e0f0 -> tool:nanobot-harness-v3:call_f755cc153578470ea024e8cc -> tool:nanobot-harness-v3:call_0b9eac8cf2764fed9b1d5d9a -> tool:nanobot-harness-v3:call_abf081f6e66443e790de0e28 -> tool:nanobot-harness-v3:call_74bba39364c742688c4379c2 -> tool:nanobot-harness-v3:call_b87060b4b959441b9b3cda69 -> tool:nanobot-harness-v3:call_dc073c984c7043789f552101 -> tool:nanobot-harness-v3:call_7bac5b1843e54302befab924
- 关键路径耗时：0.291501
- Makespan：121.660211
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
