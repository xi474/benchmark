# Workflow 可观测性报告

- Trial：`MS11__gWRShQv__env`
- Task：`MS11`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d4b71fd8f5424661b4ba9530 -> tool:nanobot-harness-v3:call_e721de7d9e65477399dcbc19 -> tool:nanobot-harness-v3:call_e6442937abc8436e9b82807e -> tool:nanobot-harness-v3:call_2b00fb2295b7487b8157e196 -> tool:nanobot-harness-v3:call_fc9e61a1174345fd961ac3f1 -> tool:nanobot-harness-v3:call_26a83f3a85c24476b3968736 -> tool:nanobot-harness-v3:call_9018f7eeb8714f759e56dc37 -> tool:nanobot-harness-v3:call_222da9b15f7447f3b4e12c8e -> tool:nanobot-harness-v3:call_1dd65f480b8f4710921ba3d1 -> tool:nanobot-harness-v3:call_cce846d270eb4efdb23eac1b -> tool:nanobot-harness-v3:call_78f3848cf8134bbfaa8501c7 -> tool:nanobot-harness-v3:call_e8ea26441d9a4bcfb7574216 -> tool:nanobot-harness-v3:call_1f4325e55d49401eb0172d9a -> tool:nanobot-harness-v3:call_c1531945f84d4d4d90be5ba6 -> tool:nanobot-harness-v3:call_08295b2753da4db4959dfe25 -> tool:nanobot-harness-v3:call_61ead7ac4188413e9dad8453 -> tool:nanobot-harness-v3:call_71c5c1b3d2454aee9bf1558f -> tool:nanobot-harness-v3:call_b7edfbc64b7d4222970b8c37 -> tool:nanobot-harness-v3:call_e4bc59aed83b44c3ba1ad35d -> tool:nanobot-harness-v3:call_ea96e3d282484461b4eb5b70 -> tool:nanobot-harness-v3:call_d6b225a5639647e7a7452e19 -> tool:nanobot-harness-v3:call_855207d7edbb4a608c8d15a5 -> tool:nanobot-harness-v3:call_72ffffe535d14f2781d11c10 -> tool:nanobot-harness-v3:call_8b116ca134154516af19cecd -> tool:nanobot-harness-v3:call_3e827a34e9cb41db8d0730bf -> tool:nanobot-harness-v3:call_6bf2e7a9600c4f209b16918e -> tool:nanobot-harness-v3:call_944e15ca6e1a4722ba45efb2 -> tool:nanobot-harness-v3:call_180ab26ec74b457fbb68b8cf
- 关键路径耗时：2.220814
- Makespan：256.932457
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
