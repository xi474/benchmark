# Workflow 可观测性报告

- Trial：`MS14__U9U8pPM__env`
- Task：`MS14`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（32 节点 / 31 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：32；执行边：31（observed=0，inferred=31）
- Execution Trace Graph：`observed`；temporal_next 边 31，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d25ea51bd1b64b88b0cb5a10 -> tool:nanobot-harness-v3:call_1bdddda003f54880a9259480 -> tool:nanobot-harness-v3:call_27cccf82ce784116a6994c1f -> tool:nanobot-harness-v3:call_7f47931a3e83490a86e107b1 -> tool:nanobot-harness-v3:call_634f3013a73c4a97adfe2fa6 -> tool:nanobot-harness-v3:call_73c512c1228b4412b879953f -> tool:nanobot-harness-v3:call_671228bb19524546b8f6c38b -> tool:nanobot-harness-v3:call_3c163a66579b45208686ae5d -> tool:nanobot-harness-v3:call_a36bb99bff174025a10fd82d -> tool:nanobot-harness-v3:call_b94a47bf724e4e0399f8b6aa -> tool:nanobot-harness-v3:call_b9839e12d2af47e6a791519c -> tool:nanobot-harness-v3:call_6c1a44e1c8ab48b6a17b67b2 -> tool:nanobot-harness-v3:call_06276c1dd5fc4ff98792fc77 -> tool:nanobot-harness-v3:call_44fdc5bc8d08434d8804efdc -> tool:nanobot-harness-v3:call_1685c158307a491d9a792d75 -> tool:nanobot-harness-v3:call_2975b2fe1a5a40c080cc21ee -> tool:nanobot-harness-v3:call_e0e8f45c7d2a448a9e0c78ac -> tool:nanobot-harness-v3:call_e5c5c62c156c4a20ab6be0e0 -> tool:nanobot-harness-v3:call_adddbd6d260d432b895a7f42 -> tool:nanobot-harness-v3:call_09a72b5ee19f47b982927001 -> tool:nanobot-harness-v3:call_81fa094bc1eb46e6b4d279be -> tool:nanobot-harness-v3:call_1f62f3fd61bb4c5e9d541aa4 -> tool:nanobot-harness-v3:call_c7719bd0c8b84dbba7493e3a -> tool:nanobot-harness-v3:call_406bc910e1814a72a08c62eb -> tool:nanobot-harness-v3:call_9049579b724744abb4673284 -> tool:nanobot-harness-v3:call_ebfa22c710e64bca9c7954f9 -> tool:nanobot-harness-v3:call_969f8a73389142288cbbdaa2 -> tool:nanobot-harness-v3:call_c48890e228f547fcbd9d1e8e -> tool:nanobot-harness-v3:call_7fcd641f671f43eb9a1e232e -> tool:nanobot-harness-v3:call_3bf44ce5dbb6436083825806 -> tool:nanobot-harness-v3:call_53ed40d53aaf402b8e33cef0
- 关键路径耗时：0.58968
- Makespan：402.014685
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
