# Workflow 可观测性报告

- Trial：`MS28__358qebM__env`
- Task：`MS28`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（26 节点 / 25 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：26；执行边：25（observed=0，inferred=25）
- Execution Trace Graph：`observed`；temporal_next 边 25，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_700a89fcea66484cb94cbff2 -> tool:nanobot-harness-v3:call_399a2fc0128d498b9b67c458 -> tool:nanobot-harness-v3:call_d9cd29bea7634aeb9e9b9715 -> tool:nanobot-harness-v3:call_d4926a9dee2346528e36dfdd -> tool:nanobot-harness-v3:call_af70fbf1733f4e00abd01c89 -> tool:nanobot-harness-v3:call_42949c967fc041dc851a1f97 -> tool:nanobot-harness-v3:call_f6c29346cb944b68b0a0623b -> tool:nanobot-harness-v3:call_7d7fe805852543f4847cd98d -> tool:nanobot-harness-v3:call_02fd62eefdf24056a12aa929 -> tool:nanobot-harness-v3:call_444541ecc7c94fc39f3de912 -> tool:nanobot-harness-v3:call_cd2a7226a6314df896f37fb0 -> tool:nanobot-harness-v3:call_67fe3019d02e48458bfe31de -> tool:nanobot-harness-v3:call_73da570d418d4c448fa3f6d4 -> tool:nanobot-harness-v3:call_1ec34941940d49599951c9f5 -> tool:nanobot-harness-v3:call_1aac090190f647788231d150 -> tool:nanobot-harness-v3:call_cfb8409ec69d48d5838cdeb1 -> tool:nanobot-harness-v3:call_5b471923fc104994a47839c9 -> tool:nanobot-harness-v3:call_c1335460be1b4375a3b6351d -> tool:nanobot-harness-v3:call_2ace87adf2204f8980dc9c3e -> tool:nanobot-harness-v3:call_2693bf84547c47e99acf1439 -> tool:nanobot-harness-v3:call_464870c3dd34405aae99c330 -> tool:nanobot-harness-v3:call_f6120429999b4e12bdc8e542 -> tool:nanobot-harness-v3:call_6c6e2dd9452247af951dd660 -> tool:nanobot-harness-v3:call_e89aee023619466f891d20a5 -> tool:nanobot-harness-v3:call_bf8991f2b16b4c8ea269bf9c
- 关键路径耗时：0.498816
- Makespan：260.096894
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
