# Workflow 可观测性报告

- Trial：`MS29__UiAiQJy__env`
- Task：`MS29`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（26 节点 / 25 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：26；执行边：25（observed=0，inferred=25）
- Execution Trace Graph：`observed`；temporal_next 边 25，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_05438d57019c4f1ca73096de -> tool:nanobot-harness-v3:call_fd504fed07364e7d8d0459de -> tool:nanobot-harness-v3:call_1d23a30aacd94d618cadd7a5 -> tool:nanobot-harness-v3:call_bbdf926b8c5b4cc6878c08db -> tool:nanobot-harness-v3:call_4c87f46a847a41eda7e365e8 -> tool:nanobot-harness-v3:call_19b90d98796146cbbf0df9fa -> tool:nanobot-harness-v3:call_d95dd4c57259417f8a0a9621 -> tool:nanobot-harness-v3:call_b4e559a86fe540b2b201559f -> tool:nanobot-harness-v3:call_6c9d5a60f561453b9af8028b -> tool:nanobot-harness-v3:call_9c4c4d1cd25b49feac1975a6 -> tool:nanobot-harness-v3:call_c8f0d41dfec143549668ceda -> tool:nanobot-harness-v3:call_a2c907d591554f9582858e8c -> tool:nanobot-harness-v3:call_fc4602b59dc643dea0d8423b -> tool:nanobot-harness-v3:call_ae860c0064e140d0941a6c69 -> tool:nanobot-harness-v3:call_2e710b7090f84a7f99e4147a -> tool:nanobot-harness-v3:call_951a2240df164eaea63594c4 -> tool:nanobot-harness-v3:call_81e158be817748c0ad172083 -> tool:nanobot-harness-v3:call_43b81833a3874af28cae049f -> tool:nanobot-harness-v3:call_d5e8792d9b1f4169921ba07e -> tool:nanobot-harness-v3:call_7e3c31f7ad2546e7899eca7d -> tool:nanobot-harness-v3:call_a9e5f42df3914087872ccb24 -> tool:nanobot-harness-v3:call_e2d87dc36ec74662a21a0559 -> tool:nanobot-harness-v3:call_5e06dffff8254307ae9b2dca -> tool:nanobot-harness-v3:call_a6540193ed1b40efa13a1acc -> tool:nanobot-harness-v3:call_b64e83231660413ebb23b186
- 关键路径耗时：0.649876
- Makespan：335.34261
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
