# Workflow 可观测性报告

- Trial：`MS30__MctKkmv__env`
- Task：`MS30`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（17 节点 / 16 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：17；执行边：16（observed=0，inferred=16）
- Execution Trace Graph：`observed`；temporal_next 边 16，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_91ecdabcf38a458491d25dcd -> tool:nanobot-harness-v3:call_21de4f99323d42e5a40dc82f -> tool:nanobot-harness-v3:call_b5ca488a79374900a49be9f0 -> tool:nanobot-harness-v3:call_4628df9c1e2b42a19cef5cba -> tool:nanobot-harness-v3:call_d75acc75166d43c19a7bafa6 -> tool:nanobot-harness-v3:call_a15af26f61964ebab12f6fa0 -> tool:nanobot-harness-v3:call_8277452ae19246c994705fd3 -> tool:nanobot-harness-v3:call_5b3088d97ea348db8b5926d7 -> tool:nanobot-harness-v3:call_5003e443d29c4abf8457db19 -> tool:nanobot-harness-v3:call_86ad0528e412467287b65bde -> tool:nanobot-harness-v3:call_5d53df6a4cef40a6bb51f8eb -> tool:nanobot-harness-v3:call_85364fc5f104431fa0020fe5 -> tool:nanobot-harness-v3:call_2e38adf9691b433484fd9afe -> tool:nanobot-harness-v3:call_02091989aac24c47bb02cf99 -> tool:nanobot-harness-v3:call_c4aac65019664b98af6f1334 -> tool:nanobot-harness-v3:call_d163d8ffd52f489f9eed4292
- 关键路径耗时：0.363943
- Makespan：309.182593
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
