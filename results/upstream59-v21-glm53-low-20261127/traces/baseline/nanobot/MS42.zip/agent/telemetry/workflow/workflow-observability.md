# Workflow 可观测性报告

- Trial：`MS42__5uSWPBX__env`
- Task：`MS42`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_17acf95c4ae846b5b7ae3e76 -> tool:nanobot-harness-v3:call_903e8d01537c4b20a17e7a98 -> tool:nanobot-harness-v3:call_4444a69f95084c4f9f2b7c5b -> tool:nanobot-harness-v3:call_8b02953409394681aa96d525 -> tool:nanobot-harness-v3:call_f0a2aa98b0e3446db818ede8 -> tool:nanobot-harness-v3:call_0c002c9bf5574af484d69db1 -> tool:nanobot-harness-v3:call_625aed82870d4ff79a6cea5d -> tool:nanobot-harness-v3:call_d919e6d6275d4ec58bf4ac30 -> tool:nanobot-harness-v3:call_09fa16555150426ca7eedf0e -> tool:nanobot-harness-v3:call_ca4b7576adf240d4a8ce43b1 -> tool:nanobot-harness-v3:call_e8890e0e059b44af86e842d2 -> tool:nanobot-harness-v3:call_6ef963b1e1fd415d8d2cf47d -> tool:nanobot-harness-v3:call_3961ae58610042ad9e8eef95 -> tool:nanobot-harness-v3:call_edc29b3c5aeb4f9ea5a0829e -> tool:nanobot-harness-v3:call_7e5fbc235906490c835a72d4 -> tool:nanobot-harness-v3:call_4c4fbec6b3894dc19329c5a1 -> tool:nanobot-harness-v3:call_3b056ea3b1af4691a4d2a480 -> tool:nanobot-harness-v3:call_5ae57be00fca4d9f836921d3 -> tool:nanobot-harness-v3:call_78e0f9fc35d64350be46d2ee -> tool:nanobot-harness-v3:call_5e98f6cef3614e70b6c5a478 -> tool:nanobot-harness-v3:call_de821f711f4943d39ea47a2d -> tool:nanobot-harness-v3:call_638fb84e07644268977c7296 -> tool:nanobot-harness-v3:call_05c9aff954f64bf3927209d2
- 关键路径耗时：0.584295
- Makespan：365.583123
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
