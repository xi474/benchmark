# Workflow 可观测性报告

- Trial：`N11__c7SfV3k__env`
- Task：`N11`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_a5201a88ad7744879e50ca2e -> tool:nanobot-harness-v3:call_f1092ea05b5a4cc9b8b7086d -> tool:nanobot-harness-v3:call_aa5b93bef3c0430090158318 -> tool:nanobot-harness-v3:call_4d590b1e384d4b718d95c2af -> tool:nanobot-harness-v3:call_12c8b12e903e4faf9f29a263 -> tool:nanobot-harness-v3:call_880e05686d4741db8b0de063 -> tool:nanobot-harness-v3:call_e06f1a525fc74e949038f2ba -> tool:nanobot-harness-v3:call_3a8c94a62c914e80b2e003c6 -> tool:nanobot-harness-v3:call_a2e25b49f21b421b802201ba -> tool:nanobot-harness-v3:call_a363e98756044fdb868b75e1 -> tool:nanobot-harness-v3:call_dc6d33809a444efe822c185f -> tool:nanobot-harness-v3:call_b38281016a7746a9a93d5a56 -> tool:nanobot-harness-v3:call_89f9948e618643359702275a -> tool:nanobot-harness-v3:call_232cb4d34f1b435c9eb5a2fa -> tool:nanobot-harness-v3:call_d30f47999ec840bd80de6ad7 -> tool:nanobot-harness-v3:call_692d505d5a164ec08b38a4b1 -> tool:nanobot-harness-v3:call_0f9701a15598474bbd2d9f85 -> tool:nanobot-harness-v3:call_43252f87cadf4901b2f53e90 -> tool:nanobot-harness-v3:call_f16d7d52bae649bf87d9e3d0 -> tool:nanobot-harness-v3:call_93f64ec01fc54fd9bc862902 -> tool:nanobot-harness-v3:call_d27776f3839e463e87fd637c -> tool:nanobot-harness-v3:call_742b79a0448841a385ac0091 -> tool:nanobot-harness-v3:call_2d2fa4cf6fab42bca6dad112 -> tool:nanobot-harness-v3:call_60106e63321549c2941365e6 -> tool:nanobot-harness-v3:call_466bba81f002496780d57466 -> tool:nanobot-harness-v3:call_30910814639b4673bc73bdcf -> tool:nanobot-harness-v3:call_318ca9a7e9ee4a26acc0e98c -> tool:nanobot-harness-v3:call_b51e37eda6dc4b45a3e5d075 -> tool:nanobot-harness-v3:call_3bd7f94d7340426795ad9020 -> tool:nanobot-harness-v3:call_443015d9d97242c1aacbb2dc
- 关键路径耗时：0.258418
- Makespan：142.170452
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
