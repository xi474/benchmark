# Workflow 可观测性报告

- Trial：`N17__xWVNVhG__env`
- Task：`N17`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（19 节点 / 18 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：19；执行边：18（observed=0，inferred=18）
- Execution Trace Graph：`observed`；temporal_next 边 18，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_1499f08b50db49189222217f -> tool:nanobot-harness-v3:call_e88adb2c6774463da4b57623 -> tool:nanobot-harness-v3:call_ed7dec75f0c84104aa031f0d -> tool:nanobot-harness-v3:call_fbf3a4cfb6e04165b7341168 -> tool:nanobot-harness-v3:call_3e981b4703b1471a813dd915 -> tool:nanobot-harness-v3:call_628d55bc19ae49acbfb90204 -> tool:nanobot-harness-v3:call_414bbbfe81de41d3ba326d05 -> tool:nanobot-harness-v3:call_f76f3337ccdb4db19e844a8c -> tool:nanobot-harness-v3:call_0395eec0b7904bffaec3d7b6 -> tool:nanobot-harness-v3:call_28a60a01b3f947029f35f4c3 -> tool:nanobot-harness-v3:call_465c7d8dc5ea4d73bdbe4f5b -> tool:nanobot-harness-v3:call_b16d04c175754ad394349bfa -> tool:nanobot-harness-v3:call_74b05572c18c47098149b90f -> tool:nanobot-harness-v3:call_45ec14921bda4ca79c0225d5 -> tool:nanobot-harness-v3:call_d3959b9fa59d47f8bcc3b5f0 -> tool:nanobot-harness-v3:call_44776411962148d7b031f1de -> tool:nanobot-harness-v3:call_20f773dacaba495cb4f0923c -> tool:nanobot-harness-v3:call_08c2325df2714262b660a456
- 关键路径耗时：0.139722
- Makespan：94.104005
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
