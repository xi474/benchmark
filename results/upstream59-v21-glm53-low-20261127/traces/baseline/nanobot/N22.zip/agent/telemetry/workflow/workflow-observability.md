# Workflow 可观测性报告

- Trial：`N22__H4kNBR2__env`
- Task：`N22`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_fb53888e6bd3481dafc2af7f -> tool:nanobot-harness-v3:call_1f0bdf107aaa46f484b23e68 -> tool:nanobot-harness-v3:call_e0ab0e293b994054a1816eaf -> tool:nanobot-harness-v3:call_627f3c4926d240fa86ffd2ed -> tool:nanobot-harness-v3:call_87afc49fbe1743f182f81120 -> tool:nanobot-harness-v3:call_2dd33e43960544699d0a9d3b -> tool:nanobot-harness-v3:call_6b41cff5683149b99327e727 -> tool:nanobot-harness-v3:call_3928f94697eb4d849cbdd480 -> tool:nanobot-harness-v3:call_4c58494694304af88712c932 -> tool:nanobot-harness-v3:call_02570fdd9bff453f8dc7d139 -> tool:nanobot-harness-v3:call_71eed3b743cc4ebfa0d3057b -> tool:nanobot-harness-v3:call_e7b7e68f6cfa412ca8d069c1 -> tool:nanobot-harness-v3:call_ea54bc36216f41f181d61479 -> tool:nanobot-harness-v3:call_6e4563ffb8fe4def98bdf89a -> tool:nanobot-harness-v3:call_01e44a8bbc40474a8903dc33 -> tool:nanobot-harness-v3:call_61f951de730f44c4a99eed81 -> tool:nanobot-harness-v3:call_0d0d2af0d5514ac78fe64ee1 -> tool:nanobot-harness-v3:call_f25fcfad66f046639f863649 -> tool:nanobot-harness-v3:call_2841ba1c02d7432784bc99ad -> tool:nanobot-harness-v3:call_4ea9237887cf4cc0a3cc2fe8 -> tool:nanobot-harness-v3:call_56ce3d3865b9445594b4bda2 -> tool:nanobot-harness-v3:call_2be7092967314711b792d20d -> tool:nanobot-harness-v3:call_d34ee97b7c9148b08fb81470 -> tool:nanobot-harness-v3:call_2a5ecb5c4c23442c972480b6 -> tool:nanobot-harness-v3:call_1badc2c068094dfeb7fdf543 -> tool:nanobot-harness-v3:call_9d449543d87443f0b65d6062 -> tool:nanobot-harness-v3:call_de6bc4831a34417eaf40645a -> tool:nanobot-harness-v3:call_0085224612c7411ba7ee0b13 -> tool:nanobot-harness-v3:call_3748d7b3073c47cb90b4ff55 -> tool:nanobot-harness-v3:call_e11a08e8488b4692a7e80049 -> tool:nanobot-harness-v3:call_d10245c4b14f40f496be1c48 -> tool:nanobot-harness-v3:call_e94300604fbd478fbe03948b -> tool:nanobot-harness-v3:call_5a531b6135194760b544b20a -> tool:nanobot-harness-v3:call_3c3e156bd877497ba377e0fe -> tool:nanobot-harness-v3:call_e0f2a05310294c50babe7131 -> tool:nanobot-harness-v3:call_668b964d0f6d44ba8bd7ffae
- 关键路径耗时：0.487893
- Makespan：195.380336
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
