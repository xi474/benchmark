# Workflow 可观测性报告

- Trial：`C007__zgewpPY__env`
- Task：`C007`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Ne4MacJ2SQUfq5Rr7sD91442 -> tool:dsh:lead:call_00_qx2uuHKH22tz1nU0JpbT9475 -> tool:dsh:lead:call_01_ORapSYvRyzCfJ2kpFBZF5706 -> tool:dsh:lead:call_02_964nTU7Fn54y8KL2AJ0o1339 -> tool:dsh:lead:call_03_pO3bNJCEYwHOAs28ZQNe2309 -> tool:dsh:lead:call_04_mLhp3HduNFnG7STLdIjm8740 -> tool:dsh:lead:call_05_1ubN6kU1FINk0KongTN62181 -> tool:dsh:lead:call_06_gt3H8MaglGrNxEkQrQti6103 -> tool:dsh:lead:call_07_dbU8J7E2q9ifl2nI8dem4866 -> tool:dsh:lead:call_08_wPWuUilaoowovGaAHyw41143 -> tool:dsh:lead:call_09_mQwoim4pO455oQQp91hC1319 -> tool:dsh:lead:call_00_vFK6Y2WZsTggeumWx19q1321 -> tool:dsh:lead:call_01_tGCn5aqdcO6MdN3U3EE60340 -> tool:dsh:lead:call_02_zGfuMKFatlt7oDkN2cXZ0296 -> tool:dsh:lead:call_03_Sn3aQcouQWivY9ZgU3B19192 -> tool:dsh:lead:call_04_Zt9LDwlwHxXWL8nGot8g5530 -> tool:dsh:lead:call_05_3VemV6y7w4NnALC2ubZw1712 -> tool:dsh:lead:call_06_yedfLIF3Fkw5zlD1rv7Q9000 -> tool:dsh:lead:call_07_zrVnKfjkhNKZC7R7Lud06870 -> tool:dsh:lead:call_00_lj9S2cWQXUvd3MvCUgtH9800 -> tool:dsh:lead:call_01_8MADaJkLSR9ylcGii18c9629 -> tool:dsh:lead:call_02_DqZios5y8wnejUfqv1IW4911 -> tool:dsh:lead:call_03_wtJMivMVYEOIh5caVb2X2377 -> tool:dsh:lead:call_04_9cqmFgSlz0ZLeOEn5Z3L1398 -> tool:dsh:lead:call_05_VWp9LSeg1UNVHSqSPo5S7378 -> tool:dsh:lead:call_00_IXmaTtTx18NgkQykukJU6539 -> tool:dsh:lead:call_00_Kmgu8maLEKTb3VndbB207996 -> tool:dsh:lead:call_00_jKagVykwEjQzDVVVLuQu9478 -> tool:dsh:lead:call_00_DqY93Hx498cRoGwkPMxv7534 -> tool:dsh:lead:call_00_1DSwR9hwijclVsdlMMVX3238 -> tool:dsh:lead:call_00_kjqimjzsW2Edaxlo4d690713 -> tool:dsh:lead:call_00_t4hubAV8ZkDDkYmLO1t50943 -> tool:dsh:lead:call_00_KIGJvLoHYsvartzu7Duf2815 -> tool:dsh:lead:call_00_mBOYHrhydtUADWSpDFYF4665 -> tool:dsh:lead:call_00_JClCNMnff51Dr97ebq8m2358
- 关键路径耗时：1.051
- Makespan：420.201
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
