# Workflow 可观测性报告

- Trial：`C008__UhFYyoK__env`
- Task：`C008`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_O9ohs8bo8nuF7OOuUQWv7163 -> tool:dsh:lead:call_00_LSxrOCobYk6II8FA82iV1554 -> tool:dsh:lead:call_01_osO2QurdNzoZgNp7uRMu1398 -> tool:dsh:lead:call_02_FgoaRD1IDZ17mPhQqiUV3941 -> tool:dsh:lead:call_03_h5i9zLFByMK1OGDP57SS6200 -> tool:dsh:lead:call_04_CP2vhVmR8MUA7AWfo3eZ8854 -> tool:dsh:lead:call_05_CMBlheL2n9G03N6Uogit5164 -> tool:dsh:lead:call_06_BEDOcEEE9PNIfH8RSpe30570 -> tool:dsh:lead:call_07_tXBHt5JsgSeLBgdvdu5y9066 -> tool:dsh:lead:call_08_3KGnJR31jK7rJOaXUB4j4369 -> tool:dsh:lead:call_09_ejinHsMuxR3yZVhC9Zzr3009 -> tool:dsh:lead:call_10_m6i1lzhISbMfilnH7OhE7172 -> tool:dsh:lead:call_00_c9EmQGRapwHaaWwii2mI3581 -> tool:dsh:lead:call_01_tUkPTQXnrWyOcbZ4LoS54548 -> tool:dsh:lead:call_02_kdD9Ni7IOxytBZeHnurG2902 -> tool:dsh:lead:call_03_TlZFQlYXfTPCSqETCYpy5804 -> tool:dsh:lead:call_04_TGejHy7wThzSNUBBRExl9290 -> tool:dsh:lead:call_05_AR2FYzdANEay9H3OOrEf4369 -> tool:dsh:lead:call_06_SpFrQwd9kWJ91iRZFmjV0323 -> tool:dsh:lead:call_07_L6qpj7g2a8x63Jri2f7V8156 -> tool:dsh:lead:call_08_RH8wiORre0q8X6yvr9qd5714 -> tool:dsh:lead:call_09_UlCu5dtJU7YAFe7ekohu4674 -> tool:dsh:lead:call_10_pju5JaPfrNSqJYDNYvkg8619 -> tool:dsh:lead:call_11_e5ikGboxtfJA2ukCGHtX5642 -> tool:dsh:lead:call_12_dU5VNjX4BrkK4D7sE2y72228 -> tool:dsh:lead:call_13_2UhUU3KZXiYMWzfvCD6R6953 -> tool:dsh:lead:call_00_SJq37FmbBbpVkNYPjpWR1964 -> tool:dsh:lead:call_00_7hrzqKNq0wiN45FXTdpp5363 -> tool:dsh:lead:call_01_5ykeo8qYCR6UbGQRByFT8982 -> tool:dsh:lead:call_00_8uyONYTDTwAjCxHxjvzb3656 -> tool:dsh:lead:call_00_6F91SPWFNGK25Hu0wacQ5696 -> tool:dsh:lead:call_00_r0H8z6TaQ95MRLn80NPn8277 -> tool:dsh:lead:call_00_heEA91aaFjgE78pTRLpA5959 -> tool:dsh:lead:call_00_2LVmeKbQryUMwbwLwWdm8201 -> tool:dsh:lead:call_00_8WdMh1uEDNDZG6MLBRZt0907
- 关键路径耗时：1.37
- Makespan：56.59
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
