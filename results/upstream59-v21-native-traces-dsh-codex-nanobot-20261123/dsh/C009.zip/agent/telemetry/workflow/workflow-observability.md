# Workflow 可观测性报告

- Trial：`C009__PcoLG6i__env`
- Task：`C009`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（52 节点 / 51 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：52；执行边：51（observed=0，inferred=51）
- Execution Trace Graph：`observed`；temporal_next 边 51，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_NRCLBZDiLu2XEL2sKsue6206 -> tool:dsh:lead:call_01_FcxW1lRdIdgCADTfg0WL5194 -> tool:dsh:lead:call_00_vVvc1FZ3tliQXUA74l3G1668 -> tool:dsh:lead:call_01_ytCfqL13VHB6xNJ3vlSL7055 -> tool:dsh:lead:call_02_Ro0xLpwu94eT8HE7yIwK3954 -> tool:dsh:lead:call_03_CcylJGIH1NiNwNXueHgB0343 -> tool:dsh:lead:call_04_7dLidvbDaCHk786BSeqx6398 -> tool:dsh:lead:call_05_GUKTF6f3ikE9d3yLPxxX3738 -> tool:dsh:lead:call_06_ru2LmDHrE1L7JFWsTJiI7381 -> tool:dsh:lead:call_07_05XMWCtASlazjpULvIvY2611 -> tool:dsh:lead:call_08_rd1glMdY9Zr6tfIP8vcs7543 -> tool:dsh:lead:call_09_cP2YebM4GLxtZfRddHd26681 -> tool:dsh:lead:call_00_x3ho0KPvGMNzKAEE9KNx6846 -> tool:dsh:lead:call_01_bPlDpoxqfuZEaX7xGRyl1515 -> tool:dsh:lead:call_02_0gjLSfjZBk2pg5cK4hm61470 -> tool:dsh:lead:call_03_LWehLaOgTBnGzrovldRH7646 -> tool:dsh:lead:call_04_ip6BdCol3PH05JOFoLis7721 -> tool:dsh:lead:call_05_iC3V0PcE2IpqqybHhXkX7340 -> tool:dsh:lead:call_06_GcvzwAAZRemiMa9GBiVl5555 -> tool:dsh:lead:call_07_wJAKEJtCGIwpsNHtBj0w6396 -> tool:dsh:lead:call_08_Dp47fBNsi3U5OVrBxm4h2964 -> tool:dsh:lead:call_09_VZFsXnADmbSPO23HJJTA2847 -> tool:dsh:lead:call_10_Jy9Vb26Ezf7Ke21ipwnX1080 -> tool:dsh:lead:call_11_iL6meJ0QgkrAZz79pnw51864 -> tool:dsh:lead:call_12_6kmwfiCtHuJFvXEKsHIp9554 -> tool:dsh:lead:call_13_9lZ0dXR17q1ujySL2na60323 -> tool:dsh:lead:call_14_6wdD3xar8oIkwt1yXUOC7473 -> tool:dsh:lead:call_15_MUagfnQzBLz1lPaiS2WB6004 -> tool:dsh:lead:call_00_DEJIFyzJJlMDcJ6BUasO6672 -> tool:dsh:lead:call_00_DI42y7k8E4JV5l97JrBe1630 -> tool:dsh:lead:call_00_xTow4UqaAOiBAhfuE0OZ4308 -> tool:dsh:lead:call_00_E8cGtRWLqlkjPkjIietP0777 -> tool:dsh:lead:call_01_0ZQQlsOrtXBA4xoj0spH4867 -> tool:dsh:lead:call_02_gsYH1RPyq9vjseazYaBw7781 -> tool:dsh:lead:call_00_0opKHND01Y0hcAznyJap2755 -> tool:dsh:lead:call_00_6HmDqy1zMWtQTNV085UX3637 -> tool:dsh:lead:call_00_DrOKzSnJGTBRi3XE65g45143 -> tool:dsh:lead:call_01_eli62d3ukscsbnqJ0KCW7719 -> tool:dsh:lead:call_00_gov90f7Djmo5gyH5lukr7632 -> tool:dsh:lead:call_00_nWXkb5o1606ZvoGxPlcn4626 -> tool:dsh:lead:call_00_UUEKuWrOC4Znau3S0Zk16021 -> tool:dsh:lead:call_00_woEvT9LfVT3EKAidBMfS9538 -> tool:dsh:lead:call_00_2uOo1qL4jqFVsbeIo93W2440 -> tool:dsh:lead:call_00_HfYZshz6Jeni9aCSAAUf1822 -> tool:dsh:lead:call_00_FRjvjk85vQvtBqBq9RCB3453 -> tool:dsh:lead:call_00_pIf6hy2ZWN3YXFs8OZuf9522 -> tool:dsh:lead:call_00_MYSJXBc69aZtmGA7vdrP8376 -> tool:dsh:lead:call_00_z89uQAa1HTKbZ2wmR7qz1015 -> tool:dsh:lead:call_00_ZQt1cw2l9Mh5ekCvyUlT6267 -> tool:dsh:lead:call_00_mFmPUXda4tlusT9haWNF8271 -> tool:dsh:lead:call_00_cqRN4BcM7KISsYr00RtJ5366
- 关键路径耗时：1.93
- Makespan：391.468
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
