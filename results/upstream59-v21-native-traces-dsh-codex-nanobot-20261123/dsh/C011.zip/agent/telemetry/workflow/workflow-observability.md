# Workflow 可观测性报告

- Trial：`C011__a9f23y2__env`
- Task：`C011`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_GiQf6ozTTqeqbCgL9z6u6785 -> tool:dsh:lead:call_00_4VOXBCbWKTVgripj3u617269 -> tool:dsh:lead:call_01_gdWUPmFqLNJOfrqfjgNa2087 -> tool:dsh:lead:call_02_C36TfRsIWFyC5ZTpocdX4127 -> tool:dsh:lead:call_03_eQqXBqL7at5lVkpsqbvd2584 -> tool:dsh:lead:call_04_9B0a6XKZ9B6bEhRsE3tV1231 -> tool:dsh:lead:call_00_0aakHfvmEYH7lvHEkyEG6576 -> tool:dsh:lead:call_01_ubf46gi61GndsNI6N7xL9680 -> tool:dsh:lead:call_02_F4CsTXWXbCRGUgk1mTzB7579 -> tool:dsh:lead:call_03_em3474HWBDHl11tIjigy2187 -> tool:dsh:lead:call_04_MsdGeNDliLvrkSQF3Wyy1577 -> tool:dsh:lead:call_05_1J85ZaUyrCWW0Fe44G6F9590 -> tool:dsh:lead:call_00_sBRjec80Bnvm8FGKB7q71900 -> tool:dsh:lead:call_01_U9Ul8D6caTdKACjlcZ7K0611 -> tool:dsh:lead:call_02_nkMEXJyFFwpDZqZ3KAOD2239 -> tool:dsh:lead:call_03_AtLiZpNaFyGcpb8evSVD6446 -> tool:dsh:lead:call_04_ircRSpzxY3v9ZdkZRhsv6828 -> tool:dsh:lead:call_05_GVdT4QqlHBC6Toux0S8F6523 -> tool:dsh:lead:call_06_7UDomgGeVHJ3YIB7DRWf0816 -> tool:dsh:lead:call_00_CFf4v9J9Xqa4szzSE7aO1253 -> tool:dsh:lead:call_01_2kBWqn2OP8eRdB26yUcF3817 -> tool:dsh:lead:call_02_u5Be2rbr8hoPUb1QcGJa7455 -> tool:dsh:lead:call_03_8HAJEQ0PumntoxwWF3hK4534 -> tool:dsh:lead:call_04_uTZdtqkP3bvUZ4jcPPmX1261 -> tool:dsh:lead:call_05_14ruKyoTGRDr5HHLI0Vm0818 -> tool:dsh:lead:call_06_KUV0eV3Aih3VcG1Uqc0v8537 -> tool:dsh:lead:call_07_bIFQXiINmR9TbD7ukKIx6048
- 关键路径耗时：0.475
- Makespan：494.436
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
