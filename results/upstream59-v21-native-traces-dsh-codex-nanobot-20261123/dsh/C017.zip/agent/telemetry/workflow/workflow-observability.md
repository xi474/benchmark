# Workflow 可观测性报告

- Trial：`C017__6c8NKR2__env`
- Task：`C017`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_VCJ89kp0DQwvRydtTPHx7607 -> tool:dsh:lead:call_01_AZFn0vxVa7yUgFFKby9C0123 -> tool:dsh:lead:call_00_N3wBz0PItaHGkt2L58W49685 -> tool:dsh:lead:call_01_OtkmvEesQcqzp23SEFPi3443 -> tool:dsh:lead:call_02_RuVY5Dbe2rBQRyqRAhlv0293 -> tool:dsh:lead:call_03_4CtNgUQCiqi6N1HZCnrN4874 -> tool:dsh:lead:call_04_7d71GiGNIHiq8VFcnm4R8566 -> tool:dsh:lead:call_05_1vmRhVs0lhoUTlwzNSbH2866 -> tool:dsh:lead:call_06_F3GczpD3KgZVDuAM8wlZ6233 -> tool:dsh:lead:call_07_WuzuFuFPJTZAtgAqVAmT0695 -> tool:dsh:lead:call_08_Wu0PVecwXoIwbjLvLDZ95324 -> tool:dsh:lead:call_09_2XpqOYCOKZpzQCdBt9sV1966 -> tool:dsh:lead:call_10_XXyGAVqA7yVabgCIEjog3342 -> tool:dsh:lead:call_00_g5VlKugPDnBM9WBVtaIZ1856 -> tool:dsh:lead:call_00_lR3m77SOFx9ikLhA3Zag9674 -> tool:dsh:lead:call_00_5Scg6tY9NRvnHbImv4uc5851 -> tool:dsh:lead:call_00_xabEHOGzJccsaqbGi4W53654 -> tool:dsh:lead:call_01_wJ6PaWdM9gbIU22ywyH50244 -> tool:dsh:lead:call_00_xmlunD3NhR0PigEBqXqL0803 -> tool:dsh:lead:call_01_WYsBvd7Mhde8uhcH2wxD7386 -> tool:dsh:lead:call_02_AYQCqheUKRMQTMogASAa3004 -> tool:dsh:lead:call_00_WGM9J0fzqFNxQ7lbV3Hj5028 -> tool:dsh:lead:call_01_FyaQhQfaEUHhN10ZRuyY2641 -> tool:dsh:lead:call_00_GiBqs4Gkgny3bzzwtCRC9107 -> tool:dsh:lead:call_00_pBLMdrOxCvty7gwxPBqR8674 -> tool:dsh:lead:call_00_rUsdirvVUEXRkk6dd0KN0620 -> tool:dsh:lead:call_00_j1itvsmO5U1nPvfv0YGG2224 -> tool:dsh:lead:call_00_7kaoqbHoaPlEVpazB9xx6193 -> tool:dsh:lead:call_00_ichaxwb5rJ9WxR6jk2qm6539 -> tool:dsh:lead:call_00_KjKOgzCVn6tD3JAtpk1U6043
- 关键路径耗时：0.728
- Makespan：223.956
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
