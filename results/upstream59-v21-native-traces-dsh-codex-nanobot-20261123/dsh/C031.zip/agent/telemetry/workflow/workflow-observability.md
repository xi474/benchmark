# Workflow 可观测性报告

- Trial：`C031__cFtue32__env`
- Task：`C031`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（59 节点 / 58 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：59；执行边：58（observed=0，inferred=58）
- Execution Trace Graph：`observed`；temporal_next 边 58，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_eZMAvhRkKbWO8zNrBCpj3164 -> tool:dsh:lead:call_01_xH0uRoc60fRehxtXE8Jl5035 -> tool:dsh:lead:call_00_BXIgJwzRoGE7rRZx0JGq1179 -> tool:dsh:lead:call_01_fmclIjU1KxZCf3kPYXLQ7384 -> tool:dsh:lead:call_02_xg5owUdyKE4U3njSH7F48387 -> tool:dsh:lead:call_03_SX98cWfJ1gBhzDiy0XL85926 -> tool:dsh:lead:call_04_rupcDgmMdQB2teMuWuf98914 -> tool:dsh:lead:call_05_BPSVQhDoDWeJ0ZZX3PN60668 -> tool:dsh:lead:call_00_StMQcHw13xnGUDu22xBd7270 -> tool:dsh:lead:call_01_8HLWMOLqNjmkwyA5aSFu6814 -> tool:dsh:lead:call_02_rkLXkPjFond7aRwce6Ut8812 -> tool:dsh:lead:call_03_rLpn2phmuBQe7rFsi4019069 -> tool:dsh:lead:call_04_s0UsNY8ZQAUmBO0WCiiA7609 -> tool:dsh:lead:call_05_i7e24wpqGenwtPQBxZtN5368 -> tool:dsh:lead:call_06_UFj6B8NCVUm13WLXM44R8047 -> tool:dsh:lead:call_00_eMK4Tnq8qcLyS5jLRyIR0397 -> tool:dsh:lead:call_01_cMU2Nl4KqykXLFyhRmTi9146 -> tool:dsh:lead:call_02_JMFMvSP5Nukf98rasRGU7964 -> tool:dsh:lead:call_03_aAX2jgFlgfID3Qdhz8t86070 -> tool:dsh:lead:call_04_SMQx01AOhCpS7AlJqGXC9764 -> tool:dsh:lead:call_05_Qi20mfFZY8ZgSjJ8BolJ3974 -> tool:dsh:lead:call_06_8Ea2tB7uNgWO4wEflyaV1869 -> tool:dsh:lead:call_07_Z5kvBruvrxHmoNlLLIUn3183 -> tool:dsh:lead:call_00_VHzbZvi0mCExn5RFl6VH8306 -> tool:dsh:lead:call_01_CD1cJZAv22qrURekruPH3651 -> tool:dsh:lead:call_02_MnwRIxdIUNsm6b8QBoYQ1376 -> tool:dsh:lead:call_03_0H4S1Rgekppw5HQFPj0e2744 -> tool:dsh:lead:call_04_JkF4CzQCyljg46hPkwz02538 -> tool:dsh:lead:call_05_1iOaVnbAHR8PlUOTX3z91527 -> tool:dsh:lead:call_00_qu6REyuhb5zos2Uxjxf80053 -> tool:dsh:lead:call_00_GxIbrR7nMmMBC0DEbLaf9189 -> tool:dsh:lead:call_00_H9k7MwUN6INWkIKmlJhq3264 -> tool:dsh:lead:call_00_nBLxyQUkyyKk3BrerCwK4247 -> tool:dsh:lead:call_00_9i3QjJQqlb1ldkqHpE6U8767 -> tool:dsh:lead:call_00_braJWhYZJVLV2oTGhbV22108 -> tool:dsh:lead:call_00_3Z1YJudUUG3MTTUA2C4Y7230 -> tool:dsh:lead:call_00_6aYzKFdFUfuA8BPkKMWK8100 -> tool:dsh:lead:call_00_r1rOtT1wnLJZYr1aH06j2161 -> tool:dsh:lead:call_00_Yp4WoIGWt5z81jyFJFT52387 -> tool:dsh:lead:call_00_rskox8YtEVhqlRQGvfHl4198 -> tool:dsh:lead:call_00_jcEatAZcNcAKpfRkCV8z9454 -> tool:dsh:lead:call_00_ASXvrdjJbO89VDNxv94q5407 -> tool:dsh:lead:call_00_PVrnwlvN5o2NmKox4yCo3211 -> tool:dsh:lead:call_00_buzeTSjcEI9C2dX8NuBo7568 -> tool:dsh:lead:call_00_3xXknyJ5APnrGJl3oTdb6331 -> tool:dsh:lead:call_00_UKaBnOFwdK5bQTSNT1iL5774 -> tool:dsh:lead:call_00_Ea9aeFW1D2b5Gue1jgPl3954 -> tool:dsh:lead:call_00_NIlNIZbPl7derQC7UWBg7851 -> tool:dsh:lead:call_00_gOsMZYRjUiyUKkpP4Xaa3203 -> tool:dsh:lead:call_00_39V7C1822F7e2mndMDSe4638 -> tool:dsh:lead:call_00_MOECkOW9BcMrhXQx8vWZ0006 -> tool:dsh:lead:call_00_hMQ6zxkD6gJFwhhj12KC8068 -> tool:dsh:lead:call_00_2H6EV6MiqEkblwGwz5iv7422 -> tool:dsh:lead:call_00_7BWdRjw2dMavfFsjqtbc9220 -> tool:dsh:lead:call_00_RBms8QY7RI8QBvFCq61q7366 -> tool:dsh:lead:call_00_qGK8AYDkpNmSAH02wFbY3208 -> tool:dsh:lead:call_00_3JxQGRLYnQDzOSQ7dy1O7201 -> tool:dsh:lead:call_00_hnNOe0mbrzYlXpaVbrNm0079
- 关键路径耗时：1.554
- Makespan：326.585
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
