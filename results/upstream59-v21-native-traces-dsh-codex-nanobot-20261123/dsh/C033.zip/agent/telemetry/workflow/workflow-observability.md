# Workflow 可观测性报告

- Trial：`C033__LeSzu2b__env`
- Task：`C033`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（72 节点 / 71 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：72；执行边：71（observed=0，inferred=71）
- Execution Trace Graph：`observed`；temporal_next 边 71，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_BJiX2gyvFjOSQhxWhRmR0000 -> tool:dsh:lead:call_01_efwAzX4a2RAUVBzrBrSX6070 -> tool:dsh:lead:call_00_kEhwxo9dJU9q3r1wd0eg1168 -> tool:dsh:lead:call_01_saezsSryr0ZR7oFccy9T8211 -> tool:dsh:lead:call_02_fnNoq8QgpwjSagCiIPoS4103 -> tool:dsh:lead:call_03_72FLZWh7E5aUPkUl63eW8411 -> tool:dsh:lead:call_04_90lxgKS4FuWG8BCmfVmG6314 -> tool:dsh:lead:call_05_e1UCi3W5qsUVYkqzyn1y5183 -> tool:dsh:lead:call_06_vkGiwiQ3SO3xoIJtAB2N1743 -> tool:dsh:lead:call_07_dfV6zlICOlMCgNIvp4v79970 -> tool:dsh:lead:call_08_o5hAJdQMyT6h9hCtcv5T5680 -> tool:dsh:lead:call_09_13diTlzRVSiWVJY8o87O7057 -> tool:dsh:lead:call_10_Shs9O1K5Kt4UCk5kjJZS5003 -> tool:dsh:lead:call_11_QBC6m92sYDfhDWn2nVJp6162 -> tool:dsh:lead:call_00_iXCrQasgxFM4g3mYsIJS4910 -> tool:dsh:lead:call_00_JMLXJlnYVU95NWrgueKU9504 -> tool:dsh:lead:call_00_XANd3kOGDXZ0cT6SGSeU5453 -> tool:dsh:lead:call_00_mzYjHAXcyySah2Wqrg9d8460 -> tool:dsh:lead:call_00_GCbgMBoLHJMeIjXkMtCW2254 -> tool:dsh:lead:call_01_rpeDDiqtdBM5yk0zai1c2016 -> tool:dsh:lead:call_00_pDUNiqsScR2tVNpfWzMq2732 -> tool:dsh:lead:call_01_jwjGAdaiTEniuzagQHqh0034 -> tool:dsh:lead:call_02_rmsVXuNpSEgyi3Kc58dE6798 -> tool:dsh:lead:call_00_4Y7f0NfKNSYV055ceibn6956 -> tool:dsh:lead:call_01_21s5A3X4x47On6gaIIdk0573 -> tool:dsh:lead:call_00_oJu2KQGuR0Dsyhk29s0r3430 -> tool:dsh:lead:call_00_UyNp3daCuScBD6pwuorC4573 -> tool:dsh:lead:call_00_a0Kk6IKmy6nnzEHi62Xj8975 -> tool:dsh:lead:call_00_MaD8dBXLUSMznLGoaChQ2864 -> tool:dsh:lead:call_00_ZDyDd6wr8y3q3yHD50713091 -> tool:dsh:lead:call_00_MAugIJBy5EOnPuxt1SmN2924 -> tool:dsh:lead:call_00_DLI2AWpVKWr1Vpr4qdAF4750 -> tool:dsh:lead:call_00_rYBoXfG0O0xrFAdQKPK70488 -> tool:dsh:lead:call_00_9E7MFdf62XyhnGxseRRw1651 -> tool:dsh:lead:call_00_wsTEC5NCgaZYO5uOBpra0892 -> tool:dsh:lead:call_00_25rnGHbiSsgPAWPBLuk38698 -> tool:dsh:lead:call_00_naR5lLyCOrY4iREo06zX5416 -> tool:dsh:lead:call_00_YXROjdd8CSS2DWm1BmDS1233 -> tool:dsh:lead:call_00_M0cWJpRDeh7x4fNvI3zk5012 -> tool:dsh:lead:call_00_Pkypw1qmtFqmD1MTRPJ70417 -> tool:dsh:lead:call_00_zPNA22GvafuHMw0UBhwu9830 -> tool:dsh:lead:call_00_XZSniFAV0kkdrIjvsIo34719 -> tool:dsh:lead:call_00_NFsi36YOac7T8PmeDIJ85125 -> tool:dsh:lead:call_00_32wHGE6vYZOgPaYuzOgl7096 -> tool:dsh:lead:call_00_382pp6OnGncojynhi0vU2411 -> tool:dsh:lead:call_00_YRnanccJSvATkeWge6GW6974 -> tool:dsh:lead:call_00_H5P7GIFBJ19rzXil5Iif0151 -> tool:dsh:lead:call_00_xoNDFIMr1sDixwDjEobx9336 -> tool:dsh:lead:call_00_2ww6FtV1y3iGeCbGPzOQ2580 -> tool:dsh:lead:call_00_cDxOrsk8x3QOHXCYWS7E8008 -> tool:dsh:lead:call_00_v6tcne3qMPcKrt47ztYw5651 -> tool:dsh:lead:call_00_0roJmGtxZL4YvWW0tORf1187 -> tool:dsh:lead:call_00_sloDKE2zGma7NpYw4iC36980 -> tool:dsh:lead:call_00_wnRTeC0aOcjiEcfRDZOJ5896 -> tool:dsh:lead:call_00_m5wTht2umGIhMg5uszi93885 -> tool:dsh:lead:call_00_GTs46Y2paYkuGUnlWDDH4917 -> tool:dsh:lead:call_00_wnKO438G30MSEZBcn6kx4773 -> tool:dsh:lead:call_00_teTUERxRjhnTNqNDeRP19959 -> tool:dsh:lead:call_00_i7jkFkhjGYiFLgKJef5L0004 -> tool:dsh:lead:call_00_PRtcNRWgf6YCTJszNzKH5674 -> tool:dsh:lead:call_00_Q5RMoIldjbKhtgrepS4c6071 -> tool:dsh:lead:call_00_f7E7KkUQb4zu8dHc6cO11952 -> tool:dsh:lead:call_00_SW7iK9q4loNXv1lBTGSo8748 -> tool:dsh:lead:call_00_Ws7fRbylkAJsdOsLu1a51344 -> tool:dsh:lead:call_00_6hZlE363Nv2HNMFIE0H67951 -> tool:dsh:lead:call_00_I3bDirb7gJHyuZDT8F2g8251 -> tool:dsh:lead:call_00_md7vRHtmIEWiaHxmQ6lc0150 -> tool:dsh:lead:call_00_iSPWYeykG0YWKuB2Wljj8384 -> tool:dsh:lead:call_00_Sqv8b2hmrqkoWCw16cdp6497 -> tool:dsh:lead:call_00_jGoYqF8rclzOi7f7TFN35661 -> tool:dsh:lead:call_00_nJTiZbySJGc75mVqLskT3049
- 关键路径耗时：1.716
- Makespan：512.097
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
