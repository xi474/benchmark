# Workflow 可观测性报告

- Trial：`C049__xfwUtGC__env`
- Task：`C049`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_gH0rOb74s85IIncnHvJm0583 -> tool:dsh:lead:call_01_ZupjaCfLFEkx4vOi2ZFz0017 -> tool:dsh:lead:call_00_jbVfjQincuN6xMmYPMvX3093 -> tool:dsh:lead:call_00_1irN1L3kGhgtP6kZcv0J0612 -> tool:dsh:lead:call_00_2s9xyUBg1yq6oVXtpUFr3419 -> tool:dsh:lead:call_00_pRuMWZ2ZKkBDEfgpjfx12608 -> tool:dsh:lead:call_00_0edkEAhYRblIRYOtpHdf0776 -> tool:dsh:lead:call_00_152TlKTlk9dZ0VbSCb031878 -> tool:dsh:lead:call_00_Stf1bgomoYJIPuPx7kzb4306 -> tool:dsh:lead:call_00_Dhnr7DCHYuaID6mjo7J98538 -> tool:dsh:lead:call_00_Q6hJrGDvw5GNgM3TYM535855 -> tool:dsh:lead:call_00_BAOjpvIXN8wo7jI5k5wD1472 -> tool:dsh:lead:call_00_MWZMhGG8NzIm4AZm0iVP1718 -> tool:dsh:lead:call_00_H3NXmgkBWnBodSWiHg2X5918 -> tool:dsh:lead:call_01_2xP1cMU9UaPsqZeCmhjc6620 -> tool:dsh:lead:call_02_ma5WmAMqC0qCikShcP113268 -> tool:dsh:lead:call_00_j9114zXJYgNV1wr3aixG3753 -> tool:dsh:lead:call_01_D2l3HT5O9V12RjjJNFUE5149 -> tool:dsh:lead:call_02_exPVKH8Tyz8VxawAndri8760 -> tool:dsh:lead:call_00_TchGP1oRHqqAjY6KEcln5433 -> tool:dsh:lead:call_00_CiWldBgnXQHTQFLEl0YE4221 -> tool:dsh:lead:call_00_pgjXka6AIAlsoJ4gFnCX2194 -> tool:dsh:lead:call_00_ZEIG9hl8YGRgS5eqcHku8434 -> tool:dsh:lead:call_00_FdvNmrvBtet5XVM6Bemv2301 -> tool:dsh:lead:call_00_qX79agowqimU0UMTPTmk7984 -> tool:dsh:lead:call_00_IO39ppSPD5LYJkZstAGd1227 -> tool:dsh:lead:call_00_3AN3mIq5WAa1wGiYbkv21192 -> tool:dsh:lead:call_00_KCyIvte70DJ3Bv1WD8nS5159 -> tool:dsh:lead:call_00_AhLu1AJsg2Jlx5mW5KFO5492 -> tool:dsh:lead:call_00_l9ySc9emsgITY8bWhDZJ1162 -> tool:dsh:lead:call_00_fAi51TtDKIKmjkuts5fB0868 -> tool:dsh:lead:call_00_VVJt4uFuZXSPvIfBmpA85377 -> tool:dsh:lead:call_00_tyq2n0SrzFtd6vAEDuYQ9114 -> tool:dsh:lead:call_00_x0hpZL1L4Pm6HGjhGWEe3575
- 关键路径耗时：2.017
- Makespan：247.881
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
