# Workflow 可观测性报告

- Trial：`C055__UuQecqZ__env`
- Task：`C055`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_boUub3qGSWE2FdXJbwDm9231 -> tool:dsh:lead:call_01_BnSYkc9XsO5pp333xwV24088 -> tool:dsh:lead:call_00_ubTAwU9whNpp1GOAdo3E8755 -> tool:dsh:lead:call_01_HcikdkbrNuoz3vMOwo6K5017 -> tool:dsh:lead:call_02_OuYZkvxF0PSDsB4B3E3u9688 -> tool:dsh:lead:call_03_xkvwiKn0xgh6gKPZEA3o9240 -> tool:dsh:lead:call_04_i3l0W3uLWGW74Q420nvm1843 -> tool:dsh:lead:call_05_ALOMYKvWgxXCSkP4A3yB1842 -> tool:dsh:lead:call_06_ed18mOKHIP5usVvNFC6b0659 -> tool:dsh:lead:call_07_lYUv6pH5W4zL6L62L1lq8071 -> tool:dsh:lead:call_08_05lYFK6xgVqMvFIbpLe78518 -> tool:dsh:lead:call_09_KJY2dC6Q1tA6KCe9AB5q5011 -> tool:dsh:lead:call_00_Z7sHlrg1RyGpbSruYEAV6478 -> tool:dsh:lead:call_00_03PZhIk13Sb9H7rlTGf60352 -> tool:dsh:lead:call_00_YrlL2kcjxq7CMqlxh7A00548 -> tool:dsh:lead:call_01_IwzOASQVLn6FcEtXJjBs2439 -> tool:dsh:lead:call_02_5xeJwFN7uLNByxD04dOC0303 -> tool:dsh:lead:call_00_NWOsAIYwIQ3kdretscFe3390 -> tool:dsh:lead:call_01_g4EoFMG8gZYtokPQEkpD1680 -> tool:dsh:lead:call_02_4OWJTxm8JXUut3LNk9jD6708 -> tool:dsh:lead:call_00_C0ba1YyNZkhGYq9haYAy3932 -> tool:dsh:lead:call_01_Hl26vdN1BcfFEx3QbHsc1447 -> tool:dsh:lead:call_02_B73VUpit49ByC8RwrVEZ9609 -> tool:dsh:lead:call_00_zCeuNNm34ohvzuB1CTTa7462 -> tool:dsh:lead:call_00_ZLB56Rzn0x1F6FV0iA2m7443 -> tool:dsh:lead:call_00_xcTKTIFFJTNr6eWwHrxp2503 -> tool:dsh:lead:call_00_CgKLxQ4r9J5m4WNLzlre7321
- 关键路径耗时：1.054
- Makespan：236.221
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
