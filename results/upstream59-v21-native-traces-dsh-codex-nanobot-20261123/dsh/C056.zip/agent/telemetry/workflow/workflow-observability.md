# Workflow 可观测性报告

- Trial：`C056__4ub8rWU__env`
- Task：`C056`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_moko6O1jivwK9GZ5l0Kx7125 -> tool:dsh:lead:call_00_HCrRqxUbVivj7nz4UoiF9038 -> tool:dsh:lead:call_00_g5oFQgPf2CL1fKDA57Dm5429 -> tool:dsh:lead:call_01_dau6jDuM7gKISTmXqJqj4685 -> tool:dsh:lead:call_02_Llt85hW9jNZT9fd5Hy436669 -> tool:dsh:lead:call_03_5tn4M5iORl2lkI3pGITW4732 -> tool:dsh:lead:call_00_gbPqybRcVWLeTHBuNUBj0789 -> tool:dsh:lead:call_01_EToEc4WGaC6DowK70Ntx5349 -> tool:dsh:lead:call_00_jbNOtopWlymU2BLxDXfx7567 -> tool:dsh:lead:call_01_1aiFbjheMsl42H9sWIqZ6066 -> tool:dsh:lead:call_02_r3LaRgOPl5U56HgkS5di5186 -> tool:dsh:lead:call_03_QRdOUGLNv7hGQYPtHi940902 -> tool:dsh:lead:call_00_0ECB7iNZWN5Ee6OPnfVk3393 -> tool:dsh:lead:call_01_ZrMbG0L8Gp011dHkWv3u1871 -> tool:dsh:lead:call_02_y7Yg7VadZT75pXhCZE2s4564 -> tool:dsh:lead:call_00_qZNw7pWCkWuwd3t8fWUA4677 -> tool:dsh:lead:call_01_v5I8s5yJowBbthk911CW8069 -> tool:dsh:lead:call_02_ux46Fp7fveAtgVX5fvgl1066 -> tool:dsh:lead:call_03_epSRNJfop0QIx8cRMEPd1891 -> tool:dsh:lead:call_04_QOwQbUVwwiqwNLrfEWsR2273 -> tool:dsh:lead:call_05_T19gnL80bT4Dx8neO8Fu2773 -> tool:dsh:lead:call_06_SfyJfp9z4mgqphq7FQc99872 -> tool:dsh:lead:call_07_gVraSEbRYItt4fAKSUCG8435 -> tool:dsh:lead:call_08_oRs0TCYkW93zIMlkz4AW2583 -> tool:dsh:lead:call_09_qd4nvgl3wTcypkF3DaQt7865 -> tool:dsh:lead:call_00_a4c5ZsQ7aTGbc8u6iJDJ9859 -> tool:dsh:lead:call_01_Ly0epceLiBGmM0QZ1se67512 -> tool:dsh:lead:call_00_merywAgPAPf1xL4FKVf42746 -> tool:dsh:lead:call_00_lAzqw8zvfickQNbalIxQ4158 -> tool:dsh:lead:call_00_KLwDrc1L9iZJT49U7qco4812 -> tool:dsh:lead:call_00_EVzqOAG0pWMzO5rcO6zF3730 -> tool:dsh:lead:call_00_JzaoWXr8fuAnKPQzFKm07298
- 关键路径耗时：0.786
- Makespan：115.472
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
