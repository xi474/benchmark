# Workflow 可观测性报告

- Trial：`C058__uUHqZEr__env`
- Task：`C058`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Fq0oOYAK4GeynFCu8Yx79557 -> tool:dsh:lead:call_00_WxCcxpicP6xt0EcHxrYe8179 -> tool:dsh:lead:call_01_UKRmzczWe1eFah8roHx52677 -> tool:dsh:lead:call_02_5SnqZ0KLtR8mMwCDRrfW5339 -> tool:dsh:lead:call_03_KxfWdHr8r1lD4i9TC5mF6940 -> tool:dsh:lead:call_04_Xzg39q9nUtOr7XJ4RVHw1044 -> tool:dsh:lead:call_05_JAHquJO2ryvFfYqSMhtB2899 -> tool:dsh:lead:call_06_UeYj3xi9dPbj5mBOfv6p5641 -> tool:dsh:lead:call_07_vSVdWYVcfubbSQ5wULl46549 -> tool:dsh:lead:call_08_xhSBDjiILlev5h1yaVn76520 -> tool:dsh:lead:call_00_f0NpADPXCtRMoxNXAIir6373 -> tool:dsh:lead:call_01_g5gRjgsd6mCwVkrSGr2m5157 -> tool:dsh:lead:call_02_LJUKRnAWU39Vhp4nEVql5441 -> tool:dsh:lead:call_03_OTcfe7vSGkH9godgqQau2240 -> tool:dsh:lead:call_04_8mXo0prFnvBlvwVg3eQ71574 -> tool:dsh:lead:call_05_bkVHwDuEpEPRbHBpE4Fv9404 -> tool:dsh:lead:call_06_LQMZsF1XPL48Pvjyhrot2571 -> tool:dsh:lead:call_07_wfkXB2jepytE49y7ypNB1393 -> tool:dsh:lead:call_08_My1KcCwgVEV2qETChG415504 -> tool:dsh:lead:call_09_gFO9F7x5fyeledX7rod86519 -> tool:dsh:lead:call_10_Mot0e8bBdB9SPdVGr9ds6171 -> tool:dsh:lead:call_11_VThr7N1qy1YwMhVAOFQK9151 -> tool:dsh:lead:call_12_jTDPOLfLNMgUHCNHnCgh7548 -> tool:dsh:lead:call_13_u44yLaldhjOpT0tTaRyG7001 -> tool:dsh:lead:call_14_P102Vod6KO39cQmYb0439531 -> tool:dsh:lead:call_15_1s3TsAvEC3vt1GulXqMn5331 -> tool:dsh:lead:call_16_qnGIBxNWUBZvdT21LiWa0330 -> tool:dsh:lead:call_17_INE3kvCkJ5dXoLjg2XGA9895
- 关键路径耗时：0.551
- Makespan：378.396
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
