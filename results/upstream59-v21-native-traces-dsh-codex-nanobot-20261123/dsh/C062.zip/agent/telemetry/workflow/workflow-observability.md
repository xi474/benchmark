# Workflow 可观测性报告

- Trial：`C062__bWSj2AB__env`
- Task：`C062`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_ExOpd5cyr1xcfyAeQ2Yx3083 -> tool:dsh:lead:call_01_hl1AYqy97emgCKpaDbFW6100 -> tool:dsh:lead:call_00_mVeMRHHqZM627WiaieXW6589 -> tool:dsh:lead:call_01_sJjzza4WIzK1FmwWFGv47330 -> tool:dsh:lead:call_02_TdtByhI3ZjOawzjKBQeC6532 -> tool:dsh:lead:call_03_ESnsOYab67BpNQdvntZP0769 -> tool:dsh:lead:call_04_AV3QELjP63vyEv7S9FJO1701 -> tool:dsh:lead:call_05_2TdSTRlUPnFv8a2dBI8F8538 -> tool:dsh:lead:call_06_eRdTGJlLQ2v4CHXVAB772371 -> tool:dsh:lead:call_07_FCpiy4tLryHpAbp6BNWS5624 -> tool:dsh:lead:call_08_UdOOCOwAhbwOBqsG3sKb2964 -> tool:dsh:lead:call_09_TSTe60jgDLZrgkczXRhO2052 -> tool:dsh:lead:call_10_oVpc5Yhqpx3eD205BZ8b5864 -> tool:dsh:lead:call_11_h53FVjyOw6RNszOu52cP6197 -> tool:dsh:lead:call_00_NXq7Ut8vs1HWOJEgdPlu0326 -> tool:dsh:lead:call_01_GIGI4w2ov0TFidXw27Z27896 -> tool:dsh:lead:call_02_o854PgqCudzc7i3K4IQq7081 -> tool:dsh:lead:call_03_5L0lSGJfmXi9K3fwE3le2941 -> tool:dsh:lead:call_04_ZS8A5UQtd0wZVtXWPDiL5547 -> tool:dsh:lead:call_05_eDzcAMdqK21Leu5MjfRS1849 -> tool:dsh:lead:call_06_DeyjcaioCBzuoChDk30Z8350 -> tool:dsh:lead:call_07_LwyXE8Yi9fbtjWXJlSNd0191 -> tool:dsh:lead:call_08_xgrsmdq1Zs3zZrg8J9p81716 -> tool:dsh:lead:call_09_sTpK1wBF0tFhX0Cce9xf8149 -> tool:dsh:lead:call_10_oCtF3sXBBQjt3z7pu9G98224 -> tool:dsh:lead:call_11_Ry2PbxeQgElG1d94kLtB8887 -> tool:dsh:lead:call_12_afyw8jJdfjkrmWf9LklA8309 -> tool:dsh:lead:call_13_bwhpomk9w9z0AfJet0b81222 -> tool:dsh:lead:call_14_9ux06yWdEuWKZTuQ8aR51888 -> tool:dsh:lead:call_00_V7IXyWbKAU9YptXLc8Mq0975 -> tool:dsh:lead:call_01_Lxgznob2kzC8kXqeqX7Y2256 -> tool:dsh:lead:call_02_CBGo1u3I001z3WIyMcLN6742 -> tool:dsh:lead:call_00_pElHLrldHtbwkwJOUIvk6663 -> tool:dsh:lead:call_00_YIdp4eXV3EhMyeC3B7ri3074 -> tool:dsh:lead:call_00_Vh5J7sstD6Um6rpGB9kq2316 -> tool:dsh:lead:call_00_DGp94KUWWhVsrVuqO79y1838 -> tool:dsh:lead:call_00_vtgGH5Ufq4XWnvIlXAuY2520 -> tool:dsh:lead:call_00_Im37Kc4DcLwMl77stf5m0966 -> tool:dsh:lead:call_00_OyLu7wJXqfKiLMuHx0Ym3255
- 关键路径耗时：1.233
- Makespan：217.872
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
