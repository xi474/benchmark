# Workflow 可观测性报告

- Trial：`C066__KuaKZag__env`
- Task：`C066`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（30 节点 / 29 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：30；执行边：29（observed=0，inferred=29）
- Execution Trace Graph：`observed`；temporal_next 边 29，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_10JFie5t9kPvfWOI0Xrv8464 -> tool:dsh:lead:call_00_D2tQZ5aUOiLWWa5Y0qjb8867 -> tool:dsh:lead:call_01_eA5qENuC6bNxal5ox2EA3978 -> tool:dsh:lead:call_02_8SliRVam0Nx5EygFlfTj2598 -> tool:dsh:lead:call_03_hC4MrMXCHyzURemzG8d56973 -> tool:dsh:lead:call_04_3NqM3TeWiVnrUMsjKdBg3406 -> tool:dsh:lead:call_00_zQe0Jf1NOOvx3vQziuAd7708 -> tool:dsh:lead:call_01_XGTHWNftnSPWJx8OUJVg2648 -> tool:dsh:lead:call_02_nUA1aMxQx2EVIy6W12nH6987 -> tool:dsh:lead:call_03_cPbk7g836hLkocHeEoHQ4613 -> tool:dsh:lead:call_04_a9XkqBOkUb1XueBNiFL05133 -> tool:dsh:lead:call_05_JMnuZx4Ft3epF8ap1O2L6139 -> tool:dsh:lead:call_00_ClueKhbIjxDYfmeux39t8550 -> tool:dsh:lead:call_01_RsYODN0yEr4iTNv0fonp8958 -> tool:dsh:lead:call_02_ih9AIMF5xdDDdFkH1OqT5772 -> tool:dsh:lead:call_03_0PwrpSLOuKpRZcifNz2D7059 -> tool:dsh:lead:call_04_DKOYKoK9pHBumzqgxNBe4500 -> tool:dsh:lead:call_05_maEiYcI6hv5ipPR79XbB2962 -> tool:dsh:lead:call_06_G0Q2D2n7iNazLJFxRa1p5365 -> tool:dsh:lead:call_07_NMRfKZlr9THY3gNYwTBK6323 -> tool:dsh:lead:call_00_64dCHcRvNsDAyaMTjJSn3937 -> tool:dsh:lead:call_01_HS530CMcp0BTAe6OLqwO0119 -> tool:dsh:lead:call_00_qXeOTmpHYQ8FlArn63ZE4174 -> tool:dsh:lead:call_01_MfllnAVN3LuADBIYFrTk9944 -> tool:dsh:lead:call_00_F2zKyudznpJntaRtgHH69168 -> tool:dsh:lead:call_00_JtvlwKSlwlv12smwzX0b7594 -> tool:dsh:lead:call_00_NHRJ27wXsgRbPsDzdvp36498 -> tool:dsh:lead:call_00_HHvcx4K5Zkhv610DygGw0441 -> tool:dsh:lead:call_00_ia3vRfzsxfvYOAvX9hSw6600
- 关键路径耗时：1.179
- Makespan：209.3
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
