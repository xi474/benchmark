# Workflow 可观测性报告

- Trial：`C067__ZmkL68J__env`
- Task：`C067`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_NwhVJNbEli9Y1OTvv4UF1699 -> tool:dsh:lead:call_01_TIkYsLe8n3bUeJRtz5HK6242 -> tool:dsh:lead:call_00_MUKwLfbPStaEND9RgArH4208 -> tool:dsh:lead:call_01_0oqcD7kwYdFCjMMhXs8k5097 -> tool:dsh:lead:call_02_CYzhOvkJAshTpNfKnIXF7359 -> tool:dsh:lead:call_03_CqbzggVyOYzNtFzHxYju9134 -> tool:dsh:lead:call_04_rtEURdygGVa5qPc4WqiP9790 -> tool:dsh:lead:call_05_3l0QtI4Bs21vaWIKSkYE2683 -> tool:dsh:lead:call_06_kTpNgeEm54WdixKexkCt3233 -> tool:dsh:lead:call_07_XTgrIixCp42TTt6P78yL8362 -> tool:dsh:lead:call_08_IddfgoGuAi2afAuodbE06265 -> tool:dsh:lead:call_09_PwdLNPmSeIbNvd1px7jg9559 -> tool:dsh:lead:call_10_77hsitXKC53m9Z1ElrMO2431 -> tool:dsh:lead:call_00_YJPc3QSrQvfqwhwfJQAZ7207 -> tool:dsh:lead:call_01_qWvSPl21oMFkQOYsgFxv6663 -> tool:dsh:lead:call_02_YnIbvcbr1D1glxoOWkpM7311 -> tool:dsh:lead:call_03_vDBjpmZY9ahf2LcahNZd5050 -> tool:dsh:lead:call_04_vNGnCbBBqIL0lWrgZ64V9031 -> tool:dsh:lead:call_05_arf3mGaEPmE3l8AjzgF38073 -> tool:dsh:lead:call_06_70Ugr9bgyP8uzKHxNlTL9940 -> tool:dsh:lead:call_07_vaJnMr6GS8cIgaPWFOSS1596 -> tool:dsh:lead:call_08_BRl5JY1EPd7gscXOClWI0326 -> tool:dsh:lead:call_09_OcsGooqF3FfGNxDrwxDQ8463 -> tool:dsh:lead:call_10_YUGH2Uhwcl4hm64jASbG5454 -> tool:dsh:lead:call_11_yYwRWkpldYhaD8GHb5fR8907 -> tool:dsh:lead:call_12_lBklYNric7Fq9LmOrrmH3691 -> tool:dsh:lead:call_13_HO7Ncr4NP3TcN0PhYv3s8918 -> tool:dsh:lead:call_00_UERtF61Tkbl9ukpubF2E2375 -> tool:dsh:lead:call_01_Nx4ZZ3EDkC6UxvTxZZeu9988 -> tool:dsh:lead:call_02_RfovI1Z6U4zQicpXULhb3782 -> tool:dsh:lead:call_00_Ucb45OnZf1iTbbURVppp5009 -> tool:dsh:lead:call_00_3aEtZZ3V0uN2G49okjl35663 -> tool:dsh:lead:call_00_dDAyB6xl7vbnosGWb06P6743 -> tool:dsh:lead:call_00_jXx7KOaZ13hElfpwCopH0981 -> tool:dsh:lead:call_00_on2AAHJ8XJ5MR2RG3rrF9859 -> tool:dsh:lead:call_00_HqqNqgWopVhJVpaIzUkp5450
- 关键路径耗时：1.317
- Makespan：179.129
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
