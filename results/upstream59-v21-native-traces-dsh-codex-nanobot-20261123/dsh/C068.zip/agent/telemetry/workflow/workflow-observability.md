# Workflow 可观测性报告

- Trial：`C068__U6gUpxd__env`
- Task：`C068`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_FDA6gwWSjqcIJOSR6hH47897 -> tool:dsh:lead:call_01_7UzSh6SynST2PzeSXgTu8097 -> tool:dsh:lead:call_00_Xif1l3zJHBEFAZH5bzGR2428 -> tool:dsh:lead:call_01_G90Qcc17QGF8jYMyVxhp7817 -> tool:dsh:lead:call_02_9I7ohJ6hfeDUtJYmG1Ii8968 -> tool:dsh:lead:call_03_8VdPjZO62jVOgQ0WFvxm9535 -> tool:dsh:lead:call_04_C44LO11FghRYDdkVEnnk7302 -> tool:dsh:lead:call_05_BuU1QAlG6KtaGoxM30Br1872 -> tool:dsh:lead:call_00_I2IORFY2kUjmkg9dY3i35017 -> tool:dsh:lead:call_01_19vmmJiZMWjCmwBf1nl30992 -> tool:dsh:lead:call_02_AiAsvv2BHHKDyE21y0rX7332 -> tool:dsh:lead:call_03_anNe9ojS1PMUmiqrBREi1639 -> tool:dsh:lead:call_04_iksiht2mrTybxlg2lq5j3981 -> tool:dsh:lead:call_00_1nwhLF6LuMbDOBDgvjSN0479 -> tool:dsh:lead:call_01_63EcwDOTCbg4qgi56xDa5295 -> tool:dsh:lead:call_02_KizPol60HWBw9f3vgkqE5895 -> tool:dsh:lead:call_03_1oIWU26G8OvUEH9J0lCk5236 -> tool:dsh:lead:call_04_i6xXTeDen2722ux1OCv47440 -> tool:dsh:lead:call_05_NsbyLFN2DvKA3ZnKJNmP7553 -> tool:dsh:lead:call_06_QrauXmxSU7DrAPSPsPJU3134 -> tool:dsh:lead:call_00_i0joL17eOQHoIR5tmuhS4422 -> tool:dsh:lead:call_01_YsE6x4tgMxa0dlHwiFh67105 -> tool:dsh:lead:call_02_7STfHubsOQXmCWxsRttZ1276 -> tool:dsh:lead:call_03_ckFSYR981fX4Q8QWYkkD6624 -> tool:dsh:lead:call_04_w3FVVByt95mRycTSZUph1253 -> tool:dsh:lead:call_05_85bMXhX6ey6KFIrJqLGm7356 -> tool:dsh:lead:call_06_S4is1obS4nxdlWWwoz222347 -> tool:dsh:lead:call_00_SohmLmQJEKXDNZa7gHR60110 -> tool:dsh:lead:call_01_A3rQsAvkrdorG3drRbnk2906 -> tool:dsh:lead:call_02_4V7MpS3nbICKS9xpF4vZ4135 -> tool:dsh:lead:call_00_bt039xTDnJTg0FikLJEQ2974 -> tool:dsh:lead:call_00_Gdgi36bknjDzlHbhdmt60608 -> tool:dsh:lead:call_00_k2R7ID1Sh6PDuOH49i6n0440 -> tool:dsh:lead:call_00_MyhS0CpSHEUINd6yhvCt8599 -> tool:dsh:lead:call_00_USDZtmD0semg7NjNcNwB6701 -> tool:dsh:lead:call_00_yRpGUnDHy88BT6FHGCZj3682 -> tool:dsh:lead:call_00_ltGJgcWxGqzCXyo6jM7x6234
- 关键路径耗时：1.236
- Makespan：308.2
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
