# Workflow 可观测性报告

- Trial：`C069__JgoyPLr__env`
- Task：`C069`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（49 节点 / 48 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：49；执行边：48（observed=0，inferred=48）
- Execution Trace Graph：`observed`；temporal_next 边 48，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Sk64JkW1i7ZMzH86Rlj73674 -> tool:dsh:lead:call_01_X4OGnmAQL70AEJ8jKz517870 -> tool:dsh:lead:call_00_laXSZUezbNvRLmuywzZP6541 -> tool:dsh:lead:call_01_XyLoWQZ4MTvv18Xuqv326656 -> tool:dsh:lead:call_02_R2ixGYTU2ZPr66c6zr2M0593 -> tool:dsh:lead:call_03_iQ8vR4SRXOJ0r5MHHzo29481 -> tool:dsh:lead:call_00_do0A0k61elrsgBLLJ6GJ4170 -> tool:dsh:lead:call_01_2FzkUT8zgWZlguHcHkTp4668 -> tool:dsh:lead:call_02_3cPURyk5PLUUjAtVwVsC2151 -> tool:dsh:lead:call_03_mPWMdVMLpsz5dzWC0waE0021 -> tool:dsh:lead:call_04_NeWSCDGbTVNEKQONjs1S2672 -> tool:dsh:lead:call_00_MY7pE4hb7dZu83s6V7R17370 -> tool:dsh:lead:call_01_DmdjyIUTarZP4POi5p437381 -> tool:dsh:lead:call_02_9QZeeQAoQ1Ub9k4jEUof6075 -> tool:dsh:lead:call_03_XAnl78z736uB1HouAjnV7653 -> tool:dsh:lead:call_04_IfmWctSQaVrfMKzxjpXN4622 -> tool:dsh:lead:call_05_qsAwoK97wdOU6MtphfzA7264 -> tool:dsh:lead:call_06_pEjg0JBgXuXEMUv8SdOc6785 -> tool:dsh:lead:call_07_T80LGWQyexxidkPujR9S4091 -> tool:dsh:lead:call_00_kU822UL2zMeNdO4EDku73490 -> tool:dsh:lead:call_01_lekJ0tEfsaXXGY6DTqcQ8467 -> tool:dsh:lead:call_00_cCp4OtldRoN9oe6NgkVT6648 -> tool:dsh:lead:call_01_aCdf8k7LkoA9UPdBcoFl0876 -> tool:dsh:lead:call_02_GPByAFFhfqKgphtt0Hze3340 -> tool:dsh:lead:call_03_oTEGsz9DnVj9PccG6xr47373 -> tool:dsh:lead:call_00_NfoUXLUI2T71MVYnfvxc7638 -> tool:dsh:lead:call_00_D2Q7weBcEedscXIJdc493442 -> tool:dsh:lead:call_00_MwFbKEWRcvjHfTjmJOnq8245 -> tool:dsh:lead:call_00_IWKZ8YjSS2wfUY8qSsI78746 -> tool:dsh:lead:call_00_8l91JRuk4D1MCKmi7uJv2304 -> tool:dsh:lead:call_00_8NmoEnJnb5ojalDPpLRc1497 -> tool:dsh:lead:call_00_MhYUJM1JPgrP2YIswl039926 -> tool:dsh:lead:call_00_7M9qr8t0ZayKrxBtwWxA5253 -> tool:dsh:lead:call_00_nV0fCCjS1wqj188kkIHA8528 -> tool:dsh:lead:call_00_NcDFFBK558kQtN1vOQMR8723 -> tool:dsh:lead:call_00_oLuRYxRLMAhirqdS3ggB6536 -> tool:dsh:lead:call_00_GH1NZPbUzXE36z2VqAId8780 -> tool:dsh:lead:call_00_tRUkpd69rlxdgCTdB25Z7536 -> tool:dsh:lead:call_00_CHQErd5b45F5iDQ2ONh00001 -> tool:dsh:lead:call_00_etxltgCInN4Yd83pFrb12096 -> tool:dsh:lead:call_00_QUk8MYbHfvgSghyCdnkD9720 -> tool:dsh:lead:call_00_UOidXVTuXld7wCBWNGaJ9201 -> tool:dsh:lead:call_00_YVEpzlwFlKDUSLwaf3Vi1574 -> tool:dsh:lead:call_00_Wl759BKMzt38nKjKII878079 -> tool:dsh:lead:call_00_7KIjDDp5b5P72mfGQrMg1301 -> tool:dsh:lead:call_00_EuWWWhk5xP3HJdYvcRAa0023 -> tool:dsh:lead:call_00_pxwZ9KFLuBjI4to16Rsg1943 -> tool:dsh:lead:call_00_GLYLGUIZeUyzOYxTvH652481
- 关键路径耗时：1.565
- Makespan：251.892
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
