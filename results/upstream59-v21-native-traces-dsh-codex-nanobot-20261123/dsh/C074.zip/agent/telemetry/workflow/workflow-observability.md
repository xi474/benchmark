# Workflow 可观测性报告

- Trial：`C074__JMtUMQZ__env`
- Task：`C074`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_aZ5wpbBTjrsuMQuQRvQi6848 -> tool:dsh:lead:call_01_GxDUSTPaGQiUm0SirSuH3304 -> tool:dsh:lead:call_00_7KihVpCDXruL7P1EZ0Th7773 -> tool:dsh:lead:call_01_OvZOLSlzOK8BGihjg2je9004 -> tool:dsh:lead:call_02_hovCCztuW7e7yT5N9Jtc2770 -> tool:dsh:lead:call_03_EnDi1e6eTCQ1uZaoJPjW8009 -> tool:dsh:lead:call_04_pNVEMI6eIBieP1GZTpqT0576 -> tool:dsh:lead:call_05_eUhPZwMqT0ARVZywp8FU8533 -> tool:dsh:lead:call_06_jddkHXdg7vvG25tY2DoC0727 -> tool:dsh:lead:call_07_uHS4k58IWQhFICgHmioh2588 -> tool:dsh:lead:call_08_NSk84H8GelWirdRaPmBr2604 -> tool:dsh:lead:call_09_Pmd4We1Uq1lyxUBKio2C8317 -> tool:dsh:lead:call_00_ALHh1zgmRzSwsN2mfith7111 -> tool:dsh:lead:call_00_AWjuHvdQWBCSu67SsDuU9387 -> tool:dsh:lead:call_01_Xb4eiDH0ZkpYLytnh4gT2441 -> tool:dsh:lead:call_00_vmk2T9SSJckx1kQj8nv17808 -> tool:dsh:lead:call_01_JD27NVOSUPdw5gO2QgOT8379 -> tool:dsh:lead:call_02_UyC5p0MO0mv15XH8Wqlf2638 -> tool:dsh:lead:call_00_IWLUe0Ya44qVo2MCd6I45320 -> tool:dsh:lead:call_01_FG5UotjNbXFwzMbzY2G75031 -> tool:dsh:lead:call_02_KcbZ7h0UyLqizFCjZymD8575 -> tool:dsh:lead:call_00_xbvyv5juygaAugsO30XH7976 -> tool:dsh:lead:call_00_zA0xDEETfNYO0dAHiBlk6730 -> tool:dsh:lead:call_00_SPQkvtTCSv6APUMmXp8r9941 -> tool:dsh:lead:call_00_ecYYArnk3Gk0wHZnZANj0027 -> tool:dsh:lead:call_00_1LElrnEe3mZwxLDIslr43777 -> tool:dsh:lead:call_00_SzQ8YBasY5YUmuiKhyCQ4789
- 关键路径耗时：0.755
- Makespan：263.085
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
