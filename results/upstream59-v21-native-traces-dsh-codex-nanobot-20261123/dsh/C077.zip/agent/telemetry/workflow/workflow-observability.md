# Workflow 可观测性报告

- Trial：`C077__ZAUWbbu__env`
- Task：`C077`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（43 节点 / 42 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：43；执行边：42（observed=0，inferred=42）
- Execution Trace Graph：`observed`；temporal_next 边 42，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_rA2Or3nrQi5KnnBuYyM49425 -> tool:dsh:lead:call_01_Ng48NZya3e8ot4OVLKqM1131 -> tool:dsh:lead:call_00_f1PggFOkr8lj065CbPuG3116 -> tool:dsh:lead:call_01_kXsaii47nJobZH4G1Aij3911 -> tool:dsh:lead:call_02_QAuGzwqMAYtxSGl8xymV9979 -> tool:dsh:lead:call_03_8aHOOJBsq4VWgjTmsVKv2105 -> tool:dsh:lead:call_04_49B1lwE3aVcz1DCMfW8r8610 -> tool:dsh:lead:call_05_UqbCI5zr2kl7yVZVHNkU9290 -> tool:dsh:lead:call_06_dyIFjb1UhwdP5vD0ykqi7318 -> tool:dsh:lead:call_07_YVsY8YPiL2Q5nyazqVf38184 -> tool:dsh:lead:call_08_89BQPuzRk6Tmwa09o3DJ7359 -> tool:dsh:lead:call_09_q6cKuQR5WkwwlYu6bCA12226 -> tool:dsh:lead:call_10_HxblTc6VUaUXQMZgkqAi3585 -> tool:dsh:lead:call_00_XdW3e8HWzSeNze2hY6ze7764 -> tool:dsh:lead:call_01_PlJVGgIVot1mYlJuoOsd0603 -> tool:dsh:lead:call_02_v3BubNtKBrmPL0RdU21c7044 -> tool:dsh:lead:call_03_e7uPbQISYJMsb9yFqZ1g0833 -> tool:dsh:lead:call_04_edpK2ALJSAu2GMTUorB01310 -> tool:dsh:lead:call_05_lIL41UIuzn3m8OXCgkos7177 -> tool:dsh:lead:call_06_u82BhNVxc7271Hc0s7HH2081 -> tool:dsh:lead:call_07_jaak58zstyWrLlzyo0Pz8531 -> tool:dsh:lead:call_08_g59mrY2vfQV7DcW4t2Qu2203 -> tool:dsh:lead:call_09_yMJ0OWYzn3TxpGcvEpR63901 -> tool:dsh:lead:call_10_Z8wjEe5nxK2FxERtPGiY0400 -> tool:dsh:lead:call_11_Ncu40P286KXHedBTiuN41492 -> tool:dsh:lead:call_12_NHgR96rivkAXXAQOZuXU3956 -> tool:dsh:lead:call_13_MJDzjnmo51zJH3c3gIRe1444 -> tool:dsh:lead:call_14_5WmzCQW3fB8itelVeBlC3545 -> tool:dsh:lead:call_15_QJuZxJifuyHHV8orMBoh2290 -> tool:dsh:lead:call_00_NLDRkYryMXrRLrQOXkeE1781 -> tool:dsh:lead:call_00_y6frwDnIMMRhkZo3N6qu5427 -> tool:dsh:lead:call_01_dY0q8l0qvkVsM1CDv7Ky6246 -> tool:dsh:lead:call_00_pssvHWYXXUqU87zeQH3w6449 -> tool:dsh:lead:call_00_e70WMDKtjYtJlYxLjVZU9330 -> tool:dsh:lead:call_00_98ZqReWCM5RYZrJclzMD1363 -> tool:dsh:lead:call_00_rZhsf1b60F6hYq61OzsV5963 -> tool:dsh:lead:call_00_9ki1rYx6VwVbK2iqreaT4763 -> tool:dsh:lead:call_00_6bA8YPGnJ99ntPCTIx2r7035 -> tool:dsh:lead:call_00_lZ2YIl7c3j1AB0XdWoIw8794 -> tool:dsh:lead:call_00_SmQLS06hClEiiF79o4NE8061 -> tool:dsh:lead:call_00_xhxLcjbdz98mAtxXgFM74362 -> tool:dsh:lead:call_00_iiL8HimCXuR5hGy5YBtB9893
- 关键路径耗时：2.034
- Makespan：282.869
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
