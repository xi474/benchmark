# Workflow 可观测性报告

- Trial：`C079__TJvKCKC__env`
- Task：`C079`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_UIT4QUUAyx1n4JOwXXG65268 -> tool:dsh:lead:call_01_nuM6RoZl9MxtAgjv5WPB9280 -> tool:dsh:lead:call_00_FUv4tENCM0N5Xxzic4uX9286 -> tool:dsh:lead:call_01_Qk8l41UH45FyvQ7vNiuE2592 -> tool:dsh:lead:call_02_f5ybXYq9gQcb5Ej8hXLw2565 -> tool:dsh:lead:call_03_FrUMQz1rB0DVMfUYZPWF4498 -> tool:dsh:lead:call_04_qgmbf3NJ7MWZzgiWu3wz2505 -> tool:dsh:lead:call_05_lxiX1b4jNB3oYMoXEfT16280 -> tool:dsh:lead:call_06_13h5pvvwVt0VLConNsvj5635 -> tool:dsh:lead:call_07_jbvZrKGQkARCqR09XBuE3263 -> tool:dsh:lead:call_08_MHkfTzmMgaUaP8LydKIO5822 -> tool:dsh:lead:call_09_tGBiA0YTBtdBq402RZzT3074 -> tool:dsh:lead:call_00_Hk7S2tvrmewA5W0CEQFd4177 -> tool:dsh:lead:call_00_hyCr3gy2FHF0EtwfAq298126 -> tool:dsh:lead:call_01_s6320bNT00hHGtidTkay7856 -> tool:dsh:lead:call_00_OWcVA8N3Z9dsxCYSJm305824 -> tool:dsh:lead:call_01_DIfwG6eF6kxLGPGaj3yF4956 -> tool:dsh:lead:call_00_3csHkVjKcXlZKwItrvc46934 -> tool:dsh:lead:call_01_seMkrOYHCivlwQCaIMXK7058 -> tool:dsh:lead:call_02_sphbdfMjwqRuULyJgk5R1112 -> tool:dsh:lead:call_00_Y6MeXkUfwLmg9dOgmfhR5540 -> tool:dsh:lead:call_01_5I2M5WKRNos9woPlMuZW5622 -> tool:dsh:lead:call_00_ABFHBvjgbPVv2pmAcA7v3236 -> tool:dsh:lead:call_00_8SFFMuUmkrs36L1EEbIh9512 -> tool:dsh:lead:call_00_3znZkZchfHsOPks9jsV00810 -> tool:dsh:lead:call_00_nZMjW2gxBY9h0cN2CYj37860 -> tool:dsh:lead:call_00_LzEmsHs4jP9jEaFCOHC77101 -> tool:dsh:lead:call_00_inGtSoS17i7N0QjVfbyy9577 -> tool:dsh:lead:call_00_AbVzMDgWhf1ryna2FKe63891 -> tool:dsh:lead:call_00_O3TLgJ7jzIVImFNFBHb80275 -> tool:dsh:lead:call_00_bh4V3d6xhCwNU0080DvY3282 -> tool:dsh:lead:call_00_XDx7iLI1RyPiOO3FMA3O7460 -> tool:dsh:lead:call_00_irCo227wKEOQBOP71Qi18821
- 关键路径耗时：1.001
- Makespan：106.786
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
