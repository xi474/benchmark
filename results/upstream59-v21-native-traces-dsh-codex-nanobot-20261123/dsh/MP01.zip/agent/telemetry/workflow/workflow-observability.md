# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP01__CVCYsZx__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Yej3EKGEAl4cVa63o6j22072 -> tool:dsh:lead:call_01_RR88UNHhMpCiQ2AvOXEr5894 -> tool:dsh:lead:call_00_wUxUnwL1xHV0Pi4ANadg8406 -> tool:dsh:lead:call_00_Rbb18hmBPgYzx9D3sg4L6571 -> tool:dsh:lead:call_00_Mzl8w7idCNCEVozYb0rG0454 -> tool:dsh:lead:call_00_0OoKfT6q6seqeUQ803bq1235 -> tool:dsh:lead:call_00_c5UcpsGzIbQtXgMGym1P1056 -> tool:dsh:lead:call_00_vzXmoZLWEZ5HuGzXVFYU6531 -> tool:dsh:lead:call_00_phocj6Ur1kY3ErHawSDr0605 -> tool:dsh:lead:call_00_XBflhZSy4abekFFHgfVL2215 -> tool:dsh:lead:call_00_ALGYrOaFjAcnrn4esqcy9779 -> tool:dsh:lead:call_01_i0Yqqaj58wHyGjgjLscA0130 -> tool:dsh:lead:call_02_Csdvl3fnS6PvBqJ5ND5q5526 -> tool:dsh:lead:call_03_aVm2sd9xFkIyqcG54E3m5660 -> tool:dsh:lead:call_04_YF77b73k2jdD9ZqvY5vZ1881 -> tool:dsh:lead:call_05_gpSambp1ZDpmQTFr989Q7105 -> tool:dsh:lead:call_00_EkXrHqkt7TwmVcPpofBL5003 -> tool:dsh:lead:call_01_29ZEuHsZcciXTcbAutjV4112 -> tool:dsh:lead:call_02_XlW4nY3sXlyKPkomTR7p3313 -> tool:dsh:lead:call_03_z6UxSQVAfDUuPvQJKcCN2959 -> tool:dsh:lead:call_04_Z1WJMgPjMiOHlcv9216i2990 -> tool:dsh:lead:call_05_IFCTeYJrF7vblY56wS5v1434 -> tool:dsh:lead:call_00_9Ja84rPUeNHozb9DWeLK5192 -> tool:dsh:lead:call_01_6I6md2jmzFtBHgmjd7cH9456 -> tool:dsh:lead:call_02_eFT6CXs0Z8fz2ugBKLqV0645 -> tool:dsh:lead:call_03_PUWbDssmJlET1ctsPQCF9507 -> tool:dsh:lead:call_04_T60wC6SJ7lF8akPWRpPv4979 -> tool:dsh:lead:call_05_ihwr7zmazDkNNvEkiWBJ0878 -> tool:dsh:lead:call_00_73m6b7IFAocUUXToAZ733709 -> tool:dsh:lead:call_01_de0tmL6QpIuOX5DeHIAo8914 -> tool:dsh:lead:call_00_xgOTiIPlUg9upvMnRnkx9864 -> tool:dsh:lead:call_00_SDwEixuRCPordIhudRNI6592 -> tool:dsh:lead:call_00_YypLuBnFpbsIbPLs09Bg3859 -> tool:dsh:lead:call_00_CyIiDyZAtgTCLWWbGIjW5264
- 关键路径耗时：1.276
- Makespan：466.271
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
