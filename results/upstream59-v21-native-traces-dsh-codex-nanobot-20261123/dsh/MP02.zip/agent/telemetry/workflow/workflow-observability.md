# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP02__XsYAAad__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_uiR2oBJZ6om1RvpLk3iZ3720 -> tool:dsh:lead:call_01_JnQdNOxexpwGox3BgNPY8080 -> tool:dsh:lead:call_00_PtrBR8TmNr0NYHLwdlzx2224 -> tool:dsh:lead:call_00_qVucBRHI3iW0lLHGEd140825 -> tool:dsh:lead:call_00_dTDb0gr2Rc9Dinp33vmU6811 -> tool:dsh:lead:call_00_4CXbndviF7BLCQgPcFZX3964 -> tool:dsh:lead:call_00_xNdDQwNxtk4ErkUoBFc24040 -> tool:dsh:lead:call_00_oGdUAZmUogrQ1n2rOnVj3925 -> tool:dsh:lead:call_00_rhb5Kl9E8N2QrEgJymHd6077 -> tool:dsh:lead:call_00_QGmTJtpUAFh8IvcuBVsY5533 -> tool:dsh:lead:call_01_7HaaKV2IvXmmTx6is4Ee1309 -> tool:dsh:lead:call_02_8XEAKB38pbLjqtHP74bN3711 -> tool:dsh:lead:call_00_hSFb9cpMpIyrScsNQfBo4185 -> tool:dsh:lead:call_01_DPxkJe5OYkljtSNcEukO8402 -> tool:dsh:lead:call_02_os933K8uLxGX36osyTNN3249 -> tool:dsh:lead:call_03_JI6yY4RCwTGnr5qhlT9k7981 -> tool:dsh:lead:call_04_Nag6lij9zBvYMoU0qBzH8290 -> tool:dsh:lead:call_05_kk5UH9AHS2bFDz3tgaOK6758 -> tool:dsh:lead:call_06_ayAw9olsp2SIW9adHtRt1353 -> tool:dsh:lead:call_07_2wQU1y0DAryrlSp07N6k7517 -> tool:dsh:lead:call_08_qijEf4LHpi7gMjd98JoE8021 -> tool:dsh:lead:call_09_w6zW8EiC2CkzTa6Zwc7O9085 -> tool:dsh:lead:call_10_kt6KSHkcw0ZR2FQD6d7K2645 -> tool:dsh:lead:call_00_i3tQAallzvSTXINNsvCU2233 -> tool:dsh:lead:call_01_OceQmnYEuQV1aRmNnt2T8016 -> tool:dsh:lead:call_02_kQS3laYlJ60YdNU6LJRo5619 -> tool:dsh:lead:call_00_OizSrNJXcROYQy5WvNF48771 -> tool:dsh:lead:call_00_03ckUE9p5zX56u8pidR72545 -> tool:dsh:lead:call_00_rigCpvhlcyDwc9NMgVIp3973 -> tool:dsh:lead:call_00_inE3O9kC2lqidwfPQNIS6224 -> tool:dsh:lead:call_01_tF7r7Y9gRqh2JakctGtX5978 -> tool:dsh:lead:call_02_zdfy7CoGH9D2rIQgzQHR0798 -> tool:dsh:lead:call_00_mCgAUvh1RokbfePrE6bL6099 -> tool:dsh:lead:call_01_e07AeMYFu9MBwR6F82T83037 -> tool:dsh:lead:call_00_kGygGNq0cGqB0qlW5lCc5494 -> tool:dsh:lead:call_00_hIE5DbwIwwkiqE1rFnuC2880 -> tool:dsh:lead:call_00_UxRr4duYS80QwIHLQH1n5120 -> tool:dsh:lead:call_00_1iAiB33Ppi5YsccRssk56363 -> tool:dsh:lead:call_00_Xg3tfLj4Nr6KOlwX6x3S2337 -> tool:dsh:lead:call_00_AjX2AS5vRSntBSdFSkvu6361 -> tool:dsh:lead:call_00_ZVLKHImsyt1PMUsCJLZw3761
- 关键路径耗时：1.385
- Makespan：333.511
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
