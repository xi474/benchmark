# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP03__rVNoYY2__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（45 节点 / 44 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：45；执行边：44（observed=0，inferred=44）
- Execution Trace Graph：`observed`；temporal_next 边 44，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_fiqIpFQpi2L4aT3sogs21531 -> tool:dsh:lead:call_01_Id9CBPzxLbGKXPklBrhl5506 -> tool:dsh:lead:call_00_riJGXkSnSdDB5BhYMJcI3372 -> tool:dsh:lead:call_00_e1qgCE6l8KzAhodWmkan7396 -> tool:dsh:lead:call_01_QjtRd59kzEubzXy2y4Jt2314 -> tool:dsh:lead:call_00_A1X0JWFGSB7TI3s8Z9ip2880 -> tool:dsh:lead:call_01_c9zIAnJM4BjuPYXNaK9I0507 -> tool:dsh:lead:call_00_UE8P8iI0TjaHMXEnFQZ51953 -> tool:dsh:lead:call_01_reobqaKxGwq1rKXflZ7h7830 -> tool:dsh:lead:call_00_KmdZZ8LJ3wPguJ9yiFGV6178 -> tool:dsh:lead:call_00_TlRbYWFMFA7NhRMEBN3U5039 -> tool:dsh:lead:call_00_nXw2ynZhOamMTI5PEgFZ9736 -> tool:dsh:lead:call_01_IMyr5I03i7gVd51kySjM1638 -> tool:dsh:lead:call_02_l99ZuEGcS6XgBffU7my01947 -> tool:dsh:lead:call_03_W0u1xpT9173ibaorl75n2861 -> tool:dsh:lead:call_04_wMzopZ3J5Hy8H466RIPB6153 -> tool:dsh:lead:call_00_XujY0B3HGS4dLwObD1IV4202 -> tool:dsh:lead:call_01_ji6C1uiUN2Hg5GRYBhhY4467 -> tool:dsh:lead:call_02_rTfk4Oq1YINcYctmAcon2939 -> tool:dsh:lead:call_03_wqeVb5sYHerXZ5uYOasP6760 -> tool:dsh:lead:call_04_bAT2fDPRJsjwKeWutuyk1485 -> tool:dsh:lead:call_05_DIWCG5uC3sbtL8l5Ma103181 -> tool:dsh:lead:call_06_WjZ3GwhhwbVG84szIPl93642 -> tool:dsh:lead:call_07_FKXVXwF37J16HuAeL0yH2845 -> tool:dsh:lead:call_08_bvm1nhLxMH9ICJShwljk2866 -> tool:dsh:lead:call_00_Rikcp7eGUwXJqul79FNx8374 -> tool:dsh:lead:call_00_4fnVIwSId9qkDGlStmgZ2377 -> tool:dsh:lead:call_00_fr7sarQE03AmCU52xrnb9043 -> tool:dsh:lead:call_00_aCTHYLQ7XSbEhFbMRkvk9228 -> tool:dsh:lead:call_00_Cy7tGQEFhDVcw994xajb8121 -> tool:dsh:lead:call_00_IhUmNRXe7em9ZIj0ajza1626 -> tool:dsh:lead:call_00_4O3OKDnLdzOPXow0gfBw8757 -> tool:dsh:lead:call_00_0Rk486Wtcdloo8aAwsrI0345 -> tool:dsh:lead:call_00_YwpdP6cJmkcJji8McXDt4044 -> tool:dsh:lead:call_00_KNnAqYsYqZ5wp3ND2wdz8518 -> tool:dsh:lead:call_00_USj9vdyiODG3GrsvHzDv3766 -> tool:dsh:lead:call_00_gHrMMP57aj735MyOuZo24882 -> tool:dsh:lead:call_00_rGkJu9k0Ormw50DW3xdQ8001 -> tool:dsh:lead:call_00_kC1DnSAJR2ej8sxVEuIv0669 -> tool:dsh:lead:call_00_kssRqOBBuVAIeHlLrLso0171 -> tool:dsh:lead:call_00_90nNBSqq6OkSqKQ6m4EJ2925 -> tool:dsh:lead:call_00_M9KyC48xvIfimjBDE0oj9282 -> tool:dsh:lead:call_00_IQUcVHllNceKRL2e4E758684 -> tool:dsh:lead:call_00_rOoJf6bFsDaguc1HljjX6308
- 关键路径耗时：1.686
- Makespan：526.098
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
