# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP04__BomarHU__env`
- Task：`core6/MP04`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_qkEYlQayT1OGAfKxNH9P5692 -> tool:dsh:lead:call_00_cRTpUzjMQH1z5azcpedd3668 -> tool:dsh:lead:call_01_dUAisZasslggFkPIreQG4447 -> tool:dsh:lead:call_02_N03Z5lZVXoH7H7sjGSbv7547 -> tool:dsh:lead:call_03_hdeQ0QVImbY4C38Tnu4b9161 -> tool:dsh:lead:call_04_ex4NbnHmepOOjMzMsZXj7188 -> tool:dsh:lead:call_00_fl61rzmoYgsMWlgDIwjR0158 -> tool:dsh:lead:call_01_bYxTCepNBnhAWVKLPfVr1290 -> tool:dsh:lead:call_02_beUymLT282GDTNchM97a3002 -> tool:dsh:lead:call_03_D7iSO6oE01Rymn0qJKZz0251 -> tool:dsh:lead:call_04_Wy0jNCI1ETt4fcTbx66S4205 -> tool:dsh:lead:call_00_f6AEytII9Ig2BbLEwhsn2036 -> tool:dsh:lead:call_01_dNo5HawScxB1UmaqB9Ho0240 -> tool:dsh:lead:call_02_VwY0VybxqG8EIIskzzFc7706 -> tool:dsh:lead:call_03_AyKzsKaLscOr1DUUktFP0677 -> tool:dsh:lead:call_00_PVpBAvMZNUnJJpztPuF07683 -> tool:dsh:lead:call_01_0PVaryHytmzb72KeZdYk1465 -> tool:dsh:lead:call_02_2NiImbHSHQsI9JJ7imsU2120 -> tool:dsh:lead:call_03_7vMe68MSWVeM2m4Byhzl6706 -> tool:dsh:lead:call_04_Pdu4YofsRGWQOtX7nNH29685 -> tool:dsh:lead:call_05_51nJte1hATkTn1Fihm2n8561 -> tool:dsh:lead:call_06_x4bHk5Cf61sFINJGQSTh2738 -> tool:dsh:lead:call_07_2cFNdcrB74pkd6Imelij9256 -> tool:dsh:lead:call_08_padQ5GM9VxhDMFy4Suwa4285 -> tool:dsh:lead:call_09_VaNh2UusQoUA5sivhznh8734 -> tool:dsh:lead:call_10_Y8bOWUAbvTv4EjxexRh78302 -> tool:dsh:lead:call_11_2aMWcAxVr7rvgRtt3lYP2648 -> tool:dsh:lead:call_00_gza4L6SNlsSXvPaGKlSI9731
- 关键路径耗时：0.442
- Makespan：632.758
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
