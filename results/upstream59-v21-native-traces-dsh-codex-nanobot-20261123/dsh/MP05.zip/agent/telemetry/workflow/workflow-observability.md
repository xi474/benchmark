# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP05__o79JVrf__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（60 节点 / 59 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：60；执行边：59（observed=0，inferred=59）
- Execution Trace Graph：`observed`；temporal_next 边 59，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Tp3B8BvqrXzsvBQDYVeu9929 -> tool:dsh:lead:call_00_CWKW6vcuXjM5OWSCO1Q28957 -> tool:dsh:lead:call_01_Sk4WhYz8NVPE2zJhcDhR6741 -> tool:dsh:lead:call_02_owSUHcexWztfnyQTUusX3311 -> tool:dsh:lead:call_03_ncPkQDE3ORiVbZuv5zzr7447 -> tool:dsh:lead:call_04_iaTajQK6bVInNuNu6IeK9348 -> tool:dsh:lead:call_00_QxSbayILj2Wo7pOeESMJ8908 -> tool:dsh:lead:call_00_7lIlK8xldMsj2LfYf8989477 -> tool:dsh:lead:call_00_80z2EfuUrFzHjYYRaFga4889 -> tool:dsh:lead:call_00_YUoukUZvZA75Xrfs2YBu4955 -> tool:dsh:lead:call_00_314pQtVcNayjGqaWmvNQ6916 -> tool:dsh:lead:call_00_NFUoDKCCglK64Za90SX33744 -> tool:dsh:lead:call_00_VjX9sOLkax8RBjKSUb781728 -> tool:dsh:lead:call_00_ZeRKE97jZqi9VuCZyJJM0282 -> tool:dsh:lead:call_00_cqlZDXanHYpNCceJiY1a6688 -> tool:dsh:lead:call_00_OmKK910blnFiZ0acRSfz7095 -> tool:dsh:lead:call_01_RLEZxnss1JI4adBhcU4U0407 -> tool:dsh:lead:call_02_mpU7GShYIMQJ1ACxcd0F0717 -> tool:dsh:lead:call_03_38fq6zlr5cu7A5owipAB2551 -> tool:dsh:lead:call_00_5b0h7eOpD9YalEAvoYR79295 -> tool:dsh:lead:call_01_q69qByzORH7FcSinyDOO7162 -> tool:dsh:lead:call_02_Mh3svC8lBC2YtdTH5tUK9677 -> tool:dsh:lead:call_03_EKpW3esPgX3GuDvxn7y17573 -> tool:dsh:lead:call_04_imVrEK0CUHMzfBUnJF6u5994 -> tool:dsh:lead:call_05_beoQLxZqa2wOImWoBmwA7031 -> tool:dsh:lead:call_06_8KZk8GrXJu6ZwGUxg0zx3047 -> tool:dsh:lead:call_07_yUiNrsf5pZl6dU7DSEe54567 -> tool:dsh:lead:call_08_sSVlK1R8TqIRRLDo3GnF4691 -> tool:dsh:lead:call_09_p1Yy0AQgD5gXCKIV7Fe68861 -> tool:dsh:lead:call_10_hkUtGV65d2TXllY9oUsh9883 -> tool:dsh:lead:call_11_LMdBUGA3FNU4NIeCqoo26478 -> tool:dsh:lead:call_12_haNR7Wbf3HXSh0viVf5w9563 -> tool:dsh:lead:call_13_1hFkozd4dPNBclyyOqJd0405 -> tool:dsh:lead:call_00_dx4g6MK0AOKWJsW6D8LY4676 -> tool:dsh:lead:call_01_Hn3rzIdNcUm3sRxE84IE1815 -> tool:dsh:lead:call_02_116lzdkA0lGaOVcSEWeN0083 -> tool:dsh:lead:call_03_haKT2x5gzbZYndSzctMq0660 -> tool:dsh:lead:call_00_sGadcqfKBwGo8GNcUfJi3571 -> tool:dsh:lead:call_00_lcEoZfY4tcn3s4zvoKLj2540 -> tool:dsh:lead:call_00_bcJga1KtzaUjlaVYnm3I9329 -> tool:dsh:lead:call_00_rOcDm5A6bCcwwRyxGgjh9510 -> tool:dsh:lead:call_00_ho1HkvllH3iZuv9rWp2W4600 -> tool:dsh:lead:call_01_ujnHawZ78R21ps81uXQO8754 -> tool:dsh:lead:call_02_IwqXFOXR2YxTh5Dnrijv8225 -> tool:dsh:lead:call_03_7hq6UvhNT2aTNWJktoIp0686 -> tool:dsh:lead:call_00_NoheDVzdlcLvu2Rf2zu88031 -> tool:dsh:lead:call_01_HmqDuo6tuyiUpZzkvVEj3722 -> tool:dsh:lead:call_00_qg1FZit63ZJpmfcCyy0h0858 -> tool:dsh:lead:call_00_JSDdNnaOR2ZmtCVVy4ef8639 -> tool:dsh:lead:call_00_tTfGO23XdTAfFIj7HaVQ4773 -> tool:dsh:lead:call_00_WcT9WSFyOjtwZf0s4KdP4387 -> tool:dsh:lead:call_00_bLT9bEQI4Iym9J2LSYho7573 -> tool:dsh:lead:call_00_g2NFFtE7AwT8jJA8m0FB3137 -> tool:dsh:lead:call_00_X9f1Qvqauq0sLAa4kj5C8152 -> tool:dsh:lead:call_00_0BG8YPHhwTAx0c3q3srb5927 -> tool:dsh:lead:call_00_beRNHgn3hNm7uYLBqZwJ9249 -> tool:dsh:lead:call_00_zLk7et5WcRNOnNif9BeP6127 -> tool:dsh:lead:call_00_Ox0iyADUJMsRfONtJYef8731 -> tool:dsh:lead:call_00_TSei89m4v8edeeA79Pef0817
- 关键路径耗时：2.04
- Makespan：371.365
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
