# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP06__CmdadzP__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（51 节点 / 50 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：51；执行边：50（observed=0，inferred=50）
- Execution Trace Graph：`observed`；temporal_next 边 50，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_QBWgcHMXetEuJlhyxeo80799 -> tool:dsh:lead:call_01_Te6Rs0ukGAadpsbUQLNL9306 -> tool:dsh:lead:call_00_wruu8mL0nSyIqE9ExxCg5979 -> tool:dsh:lead:call_01_Z4gETYaxIm9a5AWPzKrO3765 -> tool:dsh:lead:call_02_J6BssvDo51MR3ijvAUHz1698 -> tool:dsh:lead:call_03_jY7Reaw8M6IGVYPJD3tr9671 -> tool:dsh:lead:call_04_o54pbFQuCxxEdX2YH8Xx8208 -> tool:dsh:lead:call_00_Hrv1RFUnr2UOUl3VJRhb6199 -> tool:dsh:lead:call_00_GTXdMnXnIVqDkI3XXZab6768 -> tool:dsh:lead:call_01_E05TaL2oWZhmFyUjfnyC3038 -> tool:dsh:lead:call_00_4JtxxSj3OmRgoQ1kYBpo4486 -> tool:dsh:lead:call_01_f8GzjIcsjLdqGIZHhLAy0995 -> tool:dsh:lead:call_00_bDsX8lwgHl4aYRDLG1HX6845 -> tool:dsh:lead:call_00_fATCJJhEDkJbf8Wh8qjF7127 -> tool:dsh:lead:call_00_LWDUDu6UXe1YQ4Ec4AwT7151 -> tool:dsh:lead:call_00_lN5oCZnOpnjVjCVfwMxm7490 -> tool:dsh:lead:call_00_dPtbLC4mMbVh07m7BFvL6824 -> tool:dsh:lead:call_00_0KFRB4a9M9bmhCi1MJEs1685 -> tool:dsh:lead:call_01_liBniI9lS1jdabAuAC987008 -> tool:dsh:lead:call_02_2wO8s6wg8KQeNNKlIxy10205 -> tool:dsh:lead:call_03_RuLAr2q28tKDWAuVRQ124112 -> tool:dsh:lead:call_04_QurDBrGu71XtHN46ubQb1731 -> tool:dsh:lead:call_05_dOu12ojHb10hx43NOF2h8285 -> tool:dsh:lead:call_06_Cx2nvyfudFaB3N6JKHQc1312 -> tool:dsh:lead:call_07_cniV0tF9WEmKptOM6MfO9507 -> tool:dsh:lead:call_08_5sDAdZWGjdoLmxQKxgff4368 -> tool:dsh:lead:call_09_4L7IJPJoRy335ip4PBSD7415 -> tool:dsh:lead:call_10_Cvb1fHSJS03lcil9qyMe4566 -> tool:dsh:lead:call_00_va4oGCMwZMrPaOPPo5fz4287 -> tool:dsh:lead:call_01_gpJRX74q26uSf1FlWQzl0333 -> tool:dsh:lead:call_02_1uGSAhs5nXPo2ZSOQotu3537 -> tool:dsh:lead:call_00_cl59HwIZkZoTCvmJ8orx9156 -> tool:dsh:lead:call_00_mCmUeMKNRip7iM2K9joH8563 -> tool:dsh:lead:call_00_6axWQ0MY8JXqIoUx0sIi9061 -> tool:dsh:lead:call_01_Rg0lJBOeQdyjEPSRqbya6469 -> tool:dsh:lead:call_00_5cp5X28YSVPsx2SmXCrW2238 -> tool:dsh:lead:call_01_LLkgY2QSC5LipPk8Slt66578 -> tool:dsh:lead:call_00_uFN48vTomGOkBqHgYbiS4034 -> tool:dsh:lead:call_00_Z9oWo5dDRPaRSksHKIlM5834 -> tool:dsh:lead:call_00_EcRZIvKVL1IKViRwV3nq8029 -> tool:dsh:lead:call_00_V5LZXcG6a37OdLl5S7xp5140 -> tool:dsh:lead:call_00_6LDGob4gn5HlgNrbiDuk0587 -> tool:dsh:lead:call_00_EurTrYx8TbJpWUKBxRpG2742 -> tool:dsh:lead:call_00_7EKS25PLJ2wdmqkw9jOp8647 -> tool:dsh:lead:call_00_1FeZnCftAeuUA17Bw7ar6320 -> tool:dsh:lead:call_00_OAA1OKZFQsSIpkTjYIKc8513 -> tool:dsh:lead:call_00_cnEuUbfdKjfck4MmGWsv2498 -> tool:dsh:lead:call_00_KSOY5zvTEFLIc58mTGGg1554 -> tool:dsh:lead:call_00_EgRwyWMfDl9fHymVTmk93030 -> tool:dsh:lead:call_00_az4IcHocGyB1hPiBWyJw8634
- 关键路径耗时：1.666
- Makespan：265.112
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
