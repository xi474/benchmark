# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP07__UDrgbXe__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_lph1J7zKNumByU0oiJeI3160 -> tool:dsh:lead:call_01_brF1R7as6FDfbVrCzain6698 -> tool:dsh:lead:call_00_jq3TngqZDnnEUr5LqBh82912 -> tool:dsh:lead:call_01_QSahVzZiEq5JO5QqzFPC7821 -> tool:dsh:lead:call_02_678FCMLzQ1ajZ3AlTYyg9020 -> tool:dsh:lead:call_00_Dt5ZohBl9J3APfASAyyz3579 -> tool:dsh:lead:call_00_QFdZdIwHFN0jKN4gMrDw8265 -> tool:dsh:lead:call_00_51gyXga6D3QjcuYQi3sK3680 -> tool:dsh:lead:call_00_KwU0QfpnNL59u1MM8lyO7895 -> tool:dsh:lead:call_00_e3ETbs6Xd0j73XHdPC9e0729 -> tool:dsh:lead:call_00_5adC7uAtvL7kicsK0LuQ5363 -> tool:dsh:lead:call_00_KdB4FTapAVpHa4v5FgF16104 -> tool:dsh:lead:call_00_weldbLFQ5p7Kh1lF3DGe6321 -> tool:dsh:lead:call_00_g1j3xzFzcU4S3oMIMhlW0140 -> tool:dsh:lead:call_00_RxMge4QNYjapPaTZvOzK4259 -> tool:dsh:lead:call_01_fboYUM7bxofjPdN13ij82330 -> tool:dsh:lead:call_02_62PBkIhRSXqYPEV6Qhpg2154 -> tool:dsh:lead:call_03_SIxF41ma2caSSYqph1jt2262 -> tool:dsh:lead:call_04_lhV4U80PwaIk6cmttfuG2668 -> tool:dsh:lead:call_05_pIcwVEzmknLwsBz85GkH2647 -> tool:dsh:lead:call_06_cjQbl9Bs31F20Km6zUDG5843 -> tool:dsh:lead:call_07_My8ksW5cVOQvPqCDMHCe4605 -> tool:dsh:lead:call_08_rDsbHitsaqw1W86mbNYF6323 -> tool:dsh:lead:call_00_AixNhd7vJbhytgsAvH2d9195 -> tool:dsh:lead:call_01_3lfF61uzMuE5xlQmNQB22838 -> tool:dsh:lead:call_02_exoqXWFh1IgZJb4nXGHz3463 -> tool:dsh:lead:call_00_PXUTtmoWwW3moZgwoLgN5372 -> tool:dsh:lead:call_01_Rx0IWZeDWOKMoOtJwWkh4742 -> tool:dsh:lead:call_02_O8zKAGMs4vQjGAzQNzTo2628 -> tool:dsh:lead:call_00_S6MGSFhKG4bRCQeoNSmB8957 -> tool:dsh:lead:call_01_IF49EgwW8siOgyDdh4g74693 -> tool:dsh:lead:call_02_XUX2vYx1TEfvNr90I6j90430 -> tool:dsh:lead:call_00_vp669elwGUGFtDKgX0gv5918 -> tool:dsh:lead:call_00_y22U6ZMsORr3SRDtIzsS9325 -> tool:dsh:lead:call_01_692xHPAoaCouy5Y2MSu12884 -> tool:dsh:lead:call_00_HYmZVwuL2x2afGfz7jcJ4377 -> tool:dsh:lead:call_00_2xzJlkPiqgE4noOXNBd87050 -> tool:dsh:lead:call_00_ciAug3AWmfJ4B5dsGPDe9060 -> tool:dsh:lead:call_00_g8aEfZQCcTF0TJZnPeQK0046 -> tool:dsh:lead:call_00_Ns1Sc1VClw7JgSC1iTPR9946 -> tool:dsh:lead:call_00_LF0Lnut0daxFjJ5V1vcF8734 -> tool:dsh:lead:call_00_j3aRhLt6D1QhCjC9GybX4248 -> tool:dsh:lead:call_00_TfUcSnxVgoEbv6H6Vn6T4788 -> tool:dsh:lead:call_00_FJWLVZtB1rKY42vTzA2C9639 -> tool:dsh:lead:call_00_kKGxsA51OHDvwbuiLvGg5600
- 关键路径耗时：1.905
- Makespan：567.114
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
