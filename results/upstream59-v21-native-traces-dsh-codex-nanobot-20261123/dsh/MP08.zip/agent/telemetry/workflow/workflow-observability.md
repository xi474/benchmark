# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP08__BgyUNjt__env`
- Task：`core6/MP08`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（39 节点 / 38 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：39；执行边：38（observed=0，inferred=38）
- Execution Trace Graph：`observed`；temporal_next 边 38，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_ic2apXLWqAB5lTHk1IfC7826 -> tool:dsh:lead:call_00_TKFSxbFDepWGR0fceud54426 -> tool:dsh:lead:call_00_pd8Iyu4uy59cQIVyPHOr6546 -> tool:dsh:lead:call_00_vpFYMeeW9oU6SC7fcygL3631 -> tool:dsh:lead:call_00_NfKpgmDfZTzbJFrzTRgh3710 -> tool:dsh:lead:call_00_yd2us8ZbwKzHpBLPUfRB1842 -> tool:dsh:lead:call_00_kuOw1WMK0rytqrhRApC17813 -> tool:dsh:lead:call_00_fjCfGafwueTce7DAolz98724 -> tool:dsh:lead:call_01_TlSAvr1cKdp54WUzmml96642 -> tool:dsh:lead:call_02_Q61JnRX5VMfKVmc3IAS08258 -> tool:dsh:lead:call_03_7amyPGiYMZW7in4ZlMTu4274 -> tool:dsh:lead:call_04_eNbpxMhJ2kUHcp1feZBQ4405 -> tool:dsh:lead:call_05_IDKRmbgpI70HrpZQNpkZ0825 -> tool:dsh:lead:call_06_j8W7v0x0Wg2K4Gh0eIYD6658 -> tool:dsh:lead:call_07_jmY8xEGHGXf5Q6c6kxiL9444 -> tool:dsh:lead:call_08_X3Jx12zoWU6s0ZaWjl4N0039 -> tool:dsh:lead:call_00_URVgCyLKzd8C8jneW3QS5943 -> tool:dsh:lead:call_01_pnZ6Altdq6IvrwOXWeXv5393 -> tool:dsh:lead:call_02_5Q3obgRUDRctAS31TUdK2918 -> tool:dsh:lead:call_00_nWYFtPasmqYtOf2zjKbu5947 -> tool:dsh:lead:call_01_lNPb21jlWjBGE9uR76xv1162 -> tool:dsh:lead:call_02_7usC12Oea3aRw12AMhXe4566 -> tool:dsh:lead:call_00_qDSJcVmRJxU9JtiZGOBE0943 -> tool:dsh:lead:call_01_KZRW7Z6tp5crdC2mPlWC2032 -> tool:dsh:lead:call_02_YlVfDKoIZYllCcR7TPXN1221 -> tool:dsh:lead:call_00_p7csq4cHeWvjJmWMnN9S9543 -> tool:dsh:lead:call_01_lL7VqmC1PsASqv6F7h4v7243 -> tool:dsh:lead:call_00_29L8TS6jFXIDXEQRfshs3490 -> tool:dsh:lead:call_00_F5Z5uWMCXMgoUh0emdPz1296 -> tool:dsh:lead:call_00_t5twjbzPXyCdoMteWl6d2181 -> tool:dsh:lead:call_00_fbmmuCImE1SJnpj1QB2K4504 -> tool:dsh:lead:call_00_oTqx2X6YnFFaII3lvPXZ7348 -> tool:dsh:lead:call_00_ISZswE6vpSezRQnxaGs70403 -> tool:dsh:lead:call_00_CNvzAJtvOB6S6xuuuRGq9137 -> tool:dsh:lead:call_00_FNjosXxd3UFp4fnpYk7f0150 -> tool:dsh:lead:call_00_izgkHjf6adekroxlXuet4705 -> tool:dsh:lead:call_00_pXnfu062haoTgx9fLb2E1341 -> tool:dsh:lead:call_00_YmJRWrEvO5uNc1eCvIil1727
- 关键路径耗时：1.039
- Makespan：445.518
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
