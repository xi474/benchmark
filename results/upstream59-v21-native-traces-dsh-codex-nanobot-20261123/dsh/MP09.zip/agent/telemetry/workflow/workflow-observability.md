# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP09__7Mv3KQ6__env`
- Task：`core6/MP09`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（51 节点 / 50 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：51；执行边：50（observed=0，inferred=50）
- Execution Trace Graph：`observed`；temporal_next 边 50，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_aG63rp7L6y1Moc47T0DT0710 -> tool:dsh:lead:call_01_7DNU1OuSHsOBo7CXpwuT6939 -> tool:dsh:lead:call_00_3eX7i7YYYnW3JM6O7T7o3829 -> tool:dsh:lead:call_00_iX4qaIjLlfAq8zmR1Ebn6200 -> tool:dsh:lead:call_00_PZPUiJCv0HxUCE5gglTB1739 -> tool:dsh:lead:call_00_eMyNxLkFjoKe9zKk3E277996 -> tool:dsh:lead:call_00_C2Tt7GXt5CuIpnlSxjlr7524 -> tool:dsh:lead:call_00_oua5aMr7BmKMpIzAx4H23486 -> tool:dsh:lead:call_00_rseRGOmMzCsz6X7uVnl17509 -> tool:dsh:lead:call_00_UEALfTrdy0VcIWtLJTup1381 -> tool:dsh:lead:call_01_g62SFrx2C9lyUDzLrot99950 -> tool:dsh:lead:call_02_soWceVgJancOfxF1rQYr2215 -> tool:dsh:lead:call_03_eqtqSbcqOOVAV0wLBrJ69925 -> tool:dsh:lead:call_04_S0buIJiandzN5LWfHZ6I1870 -> tool:dsh:lead:call_05_yyDpRtmg28QMVDWtl4g80319 -> tool:dsh:lead:call_06_wfbmvG9UY6GqRwpoiOzD4756 -> tool:dsh:lead:call_07_JZKpSnFBJ8oyMhTmSzhT1334 -> tool:dsh:lead:call_08_n4eJVvrC7UPPiyxUJG2s3119 -> tool:dsh:lead:call_09_KQV7WkvnnuMCNNAP2cb09666 -> tool:dsh:lead:call_10_qjDwGRvi0qbTR3JB0R8M2155 -> tool:dsh:lead:call_11_L1Mx01QTNQEK9iGVM4W09057 -> tool:dsh:lead:call_12_xp30rRqvY7M0kKRwqdas5085 -> tool:dsh:lead:call_13_GZpvUE9Psz2hRv1FXhtG5777 -> tool:dsh:lead:call_00_9T0a0EB4B4A0B3S1ve0W8156 -> tool:dsh:lead:call_01_G8fsI69KRcqSpmHIsP2P5754 -> tool:dsh:lead:call_02_ACQn6gFmKvTtl7TQVici6159 -> tool:dsh:lead:call_03_v8pHYrIEuWoOmemKZiIx9471 -> tool:dsh:lead:call_00_qhT1BTNOl2uctmC80gmr9740 -> tool:dsh:lead:call_00_3Su20v64QfPE7PQLmW2y3634 -> tool:dsh:lead:call_01_WDQpdi8kWJcpKiClZo4y5545 -> tool:dsh:lead:call_00_LNY04xpyUcBQTTofdsqJ1917 -> tool:dsh:lead:call_00_d9lO0OHHWdm3McAEEh0F5449 -> tool:dsh:lead:call_01_TDnmrXw8MkwHv6p8fVgy4787 -> tool:dsh:lead:call_02_FHexVHjsDfIvWeqUnzH43808 -> tool:dsh:lead:call_03_gbNN9za8xPldd1rPGfn17432 -> tool:dsh:lead:call_00_UewR2olKPck8bLtdLPwK3108 -> tool:dsh:lead:call_01_C7vYXxBqWsWVvVBLUSY10633 -> tool:dsh:lead:call_00_4GHBNxLfx88pOOW4uJmC6362 -> tool:dsh:lead:call_00_VYnJRxGxVcXfw5ncNhu05496 -> tool:dsh:lead:call_00_A3RTbGi3zyaAtOUdiRV99462 -> tool:dsh:lead:call_01_vH4oIQJPRLb39s8K3KaT4265 -> tool:dsh:lead:call_00_A9qtudxIPIiooqdfC0gi9158 -> tool:dsh:lead:call_01_84fBUILNEtRHt34EnHjQ9537 -> tool:dsh:lead:call_00_EbXccN367BvWcam2FHkc6678 -> tool:dsh:lead:call_00_ZQZFPSHRccA1vvolVpte1308 -> tool:dsh:lead:call_01_kcA0ez9e5iVhrZvRkM5p0914 -> tool:dsh:lead:call_00_hV8p3jDVGBVfVKSdMKcd4800 -> tool:dsh:lead:call_00_Hh5T8ul9KrMWgZNDeLxS8354 -> tool:dsh:lead:call_00_EdsZindZ2bQn4eqLUsRY7724 -> tool:dsh:lead:call_00_PK5DpkKNBWVX2BmfHdJI6454
- 关键路径耗时：1.564
- Makespan：442.533
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
