# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP10__J3ftcqr__env`
- Task：`core6/MP10`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（50 节点 / 49 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：50；执行边：49（observed=0，inferred=49）
- Execution Trace Graph：`observed`；temporal_next 边 49，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_EUyZSsu5YnKSUqHatfYy8698 -> tool:dsh:lead:call_01_yHJaA3mddY9gT2YYPJiy6349 -> tool:dsh:lead:call_00_mIJCihEaoIK2x4Jyww0L9574 -> tool:dsh:lead:call_01_Nx7M0xygNwW9BAIKvO6M4469 -> tool:dsh:lead:call_02_aRirVYmrO8PZYijYU9h01657 -> tool:dsh:lead:call_03_kMPAJwnqa2hjdVjRNcTk2320 -> tool:dsh:lead:call_04_EAckfNKgkypqV0MFfP5a9383 -> tool:dsh:lead:call_00_V4r8RX4OS8qQIcg27sRe8093 -> tool:dsh:lead:call_00_0jT0cxPlDrgusXs4qFra2590 -> tool:dsh:lead:call_01_W7Pbd1iuagvNAUWdzVbh3170 -> tool:dsh:lead:call_00_e5iD1l8q5QedX1Uo2Wws6687 -> tool:dsh:lead:call_00_Beh4tmZOTeYE6KxWzRvy8957 -> tool:dsh:lead:call_01_aKVKeIXjpgJEP9SjtkFS9705 -> tool:dsh:lead:call_02_pn3VClLyUyQd2NMaVRfB6137 -> tool:dsh:lead:call_00_djM77sP0iqUNreA3hHyN0739 -> tool:dsh:lead:call_01_p206o7XBZhmOcsnmyWHr9080 -> tool:dsh:lead:call_02_BzH7rOaOVIheZ3srRVgi0119 -> tool:dsh:lead:call_03_Zj3fBUdUPkmjhorV6dC96356 -> tool:dsh:lead:call_04_eC8Z2DAnBomqisbXwCmZ5921 -> tool:dsh:lead:call_05_AqTPfq8unWIdkrKVWOEb2261 -> tool:dsh:lead:call_06_GzjlAYpbIwpilpbqScOj4080 -> tool:dsh:lead:call_07_Tvw47pbC86morAhtTQBP4644 -> tool:dsh:lead:call_08_GL0aONscdXj2DSQWt2a13827 -> tool:dsh:lead:call_00_zLZwLFI6fZjod4zJ1MhM4748 -> tool:dsh:lead:call_01_Y29jEiHlmpNFqQCRyVwe6089 -> tool:dsh:lead:call_02_vI19nci9WHQqBnjHBTII6848 -> tool:dsh:lead:call_00_pnxm78jAIpDecq5ciiAZ8255 -> tool:dsh:lead:call_01_UDTVFztPdXHWyJRzgYf19088 -> tool:dsh:lead:call_02_A5qqmiVoh1WZLkgKX8mA3308 -> tool:dsh:lead:call_00_KdWf5UkIdm2iWXz9liPV1698 -> tool:dsh:lead:call_01_BqTb14rhHc2XloFcUjsB3003 -> tool:dsh:lead:call_02_tYGlMqQWnQKr8VWH1yQ47596 -> tool:dsh:lead:call_00_nReJBGe4eOHQJNDo5KFT9140 -> tool:dsh:lead:call_00_ZHtU6KYhvHUkmszuTtA73705 -> tool:dsh:lead:call_01_cLsYHQS5cIXNhjUtOXLi4943 -> tool:dsh:lead:call_00_IhfNjhwMlbYFzEKdx3s15047 -> tool:dsh:lead:call_00_JPy82vsL1TKIO9ZOZk1m0205 -> tool:dsh:lead:call_00_SFNfvtKPYzZLjp5AgkX52992 -> tool:dsh:lead:call_00_BJuNs9K4wblce9dMn2tr3298 -> tool:dsh:lead:call_00_115mlHsaXg0mCoBkWM2F7153 -> tool:dsh:lead:call_01_9G7QKrofujrEvH1yEgAN9278 -> tool:dsh:lead:call_00_ZI8waIxH88TjdMvnHSWe6768 -> tool:dsh:lead:call_00_tdyZwzk63xXlCtyvx5vt0930 -> tool:dsh:lead:call_00_aAOna6JrRy7mRCCNmpQx9285 -> tool:dsh:lead:call_01_xnCwJl6q0gmUhAHVJAiu3797 -> tool:dsh:lead:call_00_khyr3dVg5XDg120UOXYY0384 -> tool:dsh:lead:call_01_Jn3oEMKL9vnmB5gye8zq0175 -> tool:dsh:lead:call_00_P2zhxZjoxRiJ4CzCtPOh2039 -> tool:dsh:lead:call_00_JuYt2d0v01JPf3N2KfHT0819
- 关键路径耗时：1.351
- Makespan：667.428
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
