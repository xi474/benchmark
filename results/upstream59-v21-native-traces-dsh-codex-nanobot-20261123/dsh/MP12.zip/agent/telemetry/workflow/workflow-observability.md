# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP12__fJdrA8B__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（59 节点 / 58 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：59；执行边：58（observed=0，inferred=58）
- Execution Trace Graph：`observed`；temporal_next 边 58，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_WyDxMPZJZQxuqSvYwTuZ8915 -> tool:dsh:lead:call_00_sFnUOBQNlsFR27wHdVGz4560 -> tool:dsh:lead:call_00_XEVrUEXJeYdjIb66XWIN9454 -> tool:dsh:lead:call_00_WPguEfP3BhnFBQtGvYtF1951 -> tool:dsh:lead:call_00_Wn9fnSvnEyN41YexNEkz3137 -> tool:dsh:lead:call_00_NHOJdRJI0oTtM4Kho5UY1678 -> tool:dsh:lead:call_00_WQilrex0Tx3XgxCNIEKy7507 -> tool:dsh:lead:call_00_1gvu6gQnMCB4sTnYT4Bs7124 -> tool:dsh:lead:call_00_1wmTon8gIExZehrpXRqp1696 -> tool:dsh:lead:call_00_irD8lgAgSe0ypBgvbbSa9609 -> tool:dsh:lead:call_00_8eNXHYBVaChq7gZmXBYI5593 -> tool:dsh:lead:call_00_99oSWvo1Uxqc7s53wcTc9489 -> tool:dsh:lead:call_00_dqMUBsBkDSsxzsfWj92D1943 -> tool:dsh:lead:call_00_eNmzNqowNBET3eeK0zbc4432 -> tool:dsh:lead:call_00_eujojVo8dgJfJ0kJSXee6246 -> tool:dsh:lead:call_00_oc2n6QIU0JBrCtQMx0Z39374 -> tool:dsh:lead:call_00_yzlkpyOZDi7VdphCQaMk7876 -> tool:dsh:lead:call_00_GrtGDe8a3FtstpZwcg6S9799 -> tool:dsh:lead:call_00_EviUuHjFiMOUPuUiBgVi9755 -> tool:dsh:lead:call_00_mPMSCIdypl83sevhhuXx8082 -> tool:dsh:lead:call_00_rz6TiImAPvlDTu8yPLah1581 -> tool:dsh:lead:call_00_FjTfzljocuvlO2dfLJzA7812 -> tool:dsh:lead:call_00_6FM3MgMTZ4QyFeigJjKv8635 -> tool:dsh:lead:call_00_9pdhSBoxy2s2fLnmsMkS3891 -> tool:dsh:lead:call_00_r9Pylq4rQVRgDQSU4y2y9398 -> tool:dsh:lead:call_00_cjIblUu70oVFL6tdcLkL7003 -> tool:dsh:lead:call_00_38sGeSr1ASZ8uGSvuMBG7580 -> tool:dsh:lead:call_00_HnaWdQ7oMwmbEVItxj2S7831 -> tool:dsh:lead:call_00_VlFBKH4jTwJucQF2DCCb3113 -> tool:dsh:lead:call_00_kLvVeujBV23GH9dEL0bt7422 -> tool:dsh:lead:call_00_AfdQXvNQGioPOnOBLPxt1601 -> tool:dsh:lead:call_00_AvHALv0NIPkaVfaQFP3E3460 -> tool:dsh:lead:call_00_fREamkfC5VTy22f0wy823559 -> tool:dsh:lead:call_00_dAb5Xav4Zv6rQ3P8qrjC8519 -> tool:dsh:lead:call_00_FpZGKqdNSwfOUIFtYkMO4635 -> tool:dsh:lead:call_00_fn74r51ccR4WTXsdLDml7093 -> tool:dsh:lead:call_00_pcN3SnCeHH7mADKxQf2E5216 -> tool:dsh:lead:call_00_ffh2NmzML2ec84THeJcY1578 -> tool:dsh:lead:call_00_C52oSVFBv3fAHOz4i2jF9285 -> tool:dsh:lead:call_00_vZdDCLx9nxvZ8C5RRuuZ4715 -> tool:dsh:lead:call_00_aS5rBSUZp7kjU9KANCDw6179 -> tool:dsh:lead:call_00_pIi2DLWbxuFgzJEJVrRt7633 -> tool:dsh:lead:call_00_gqV5E3l1WHuRQtFPI4mr3401 -> tool:dsh:lead:call_00_UKPpmg3BuqHVMYzkJKqH9825 -> tool:dsh:lead:call_00_bzbkcAaIm3j2vTClcNA92301 -> tool:dsh:lead:call_00_fPLkPwSBlezzjXhy5S523731 -> tool:dsh:lead:call_00_GPj2ldiwWgA9mVPMfbHP8751 -> tool:dsh:lead:call_00_Xt7aopcD6b6Ynlijy6086409 -> tool:dsh:lead:call_00_a9htXwvP8SjvxTgUoGLt1545 -> tool:dsh:lead:call_00_EExFAoN8chcvAxoja7AS9309 -> tool:dsh:lead:call_00_le1y3clU72bZY5Wxgz0Z2359 -> tool:dsh:lead:call_00_Ytza6lXhQemTnJunIMKe3246 -> tool:dsh:lead:call_00_cidg6Ztvf7udbh2LyXTP7997 -> tool:dsh:lead:call_00_3E2YNT3pywjelKyfNX5R1731 -> tool:dsh:lead:call_00_ZthoOnForSmDeDvWvRaD5096 -> tool:dsh:lead:call_00_uEFCj1ct0O6GwlGHJiii8396 -> tool:dsh:lead:call_00_UhQGkW8PBsTnYyNFMT3I0461 -> tool:dsh:lead:call_00_zK5QU2nYl6dNG1Kq7IML4977
- 关键路径耗时：2.693
- Makespan：878.487
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
