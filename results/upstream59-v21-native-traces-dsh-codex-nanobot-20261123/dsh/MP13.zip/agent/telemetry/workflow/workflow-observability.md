# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP13__inq3WNN__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（50 节点 / 49 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：50；执行边：49（observed=0，inferred=49）
- Execution Trace Graph：`observed`；temporal_next 边 49，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_2jNZkCMZzm45xgucgV0T7401 -> tool:dsh:lead:call_01_1jDX4PH6gdTVdPjDApI77293 -> tool:dsh:lead:call_00_vEhL5obVwymVvbQtuWME6549 -> tool:dsh:lead:call_00_tWhUDMfd4uGCGJdRApvZ7598 -> tool:dsh:lead:call_00_VmnpUXfIoMJY8zXcYOTR5084 -> tool:dsh:lead:call_00_EpYMn7bjuF8VzOey3M7h0628 -> tool:dsh:lead:call_00_9xXN660Z0SY0AkzgA6Yz8322 -> tool:dsh:lead:call_00_QEi88glT5WZOc3wMcpWF2339 -> tool:dsh:lead:call_01_xp2WENzvGTpLVrXR77YN0851 -> tool:dsh:lead:call_02_Iw8kjKi3Z97UrngBSjvQ0540 -> tool:dsh:lead:call_03_BrVduTlt08BH1chRKwHP4736 -> tool:dsh:lead:call_00_wrVmxkhpNBQTTrMb2QSO6968 -> tool:dsh:lead:call_01_hyZpDqY1guYR1zXPfI742849 -> tool:dsh:lead:call_02_441gP3TPb5ahDcO6PdgI0438 -> tool:dsh:lead:call_03_cSEuvPznOwxtN7oMAegl0688 -> tool:dsh:lead:call_04_NrhHpxkp9uV3EXQ4uwHw9155 -> tool:dsh:lead:call_05_U41W9qwjHyoG8a56HXdB0842 -> tool:dsh:lead:call_06_h4fIdlhd0OEbVVJ7mGhG4403 -> tool:dsh:lead:call_07_7V4CiyEmZLUdV5ca7VUo2428 -> tool:dsh:lead:call_08_zofDkIZNdsu4aKV1QZM33968 -> tool:dsh:lead:call_09_wbh9KQrLCAALb1KHorEi2848 -> tool:dsh:lead:call_10_wlyEOejRIqmjBXIzrTmW2357 -> tool:dsh:lead:call_11_2UiyvMsyBiCiHaOHYAOz1059 -> tool:dsh:lead:call_12_5B34TcqQcuKfMXYWga1h1073 -> tool:dsh:lead:call_13_yEhJvb3UmVCnzNW9EXsv9726 -> tool:dsh:lead:call_00_WYWHSDmxvDTnNCn1Lqgu9787 -> tool:dsh:lead:call_01_wDiYdvVoHHauwW3uUisy2120 -> tool:dsh:lead:call_02_nOOiQ32p16NSHPKBIGpq8493 -> tool:dsh:lead:call_03_RmMoeqgxnRzw0EixjmHY0250 -> tool:dsh:lead:call_00_ZPwQN9Rmfqrjo7WYaADf9950 -> tool:dsh:lead:call_01_NmTGZTdJ29jc5yN5tsWz0671 -> tool:dsh:lead:call_02_ncQP49PADamt9nLImisW4234 -> tool:dsh:lead:call_03_TtREFFhUxWuGfHYqY82d4832 -> tool:dsh:lead:call_00_a5rpGa7rvi8qUUYnvrQI2540 -> tool:dsh:lead:call_01_lOS2dgu5KuO7EZbl9JhG0879 -> tool:dsh:lead:call_02_9DVxKAPfYI9go2CdKwZv1996 -> tool:dsh:lead:call_03_PwQ1r7m22eMiUb594FDi4193 -> tool:dsh:lead:call_00_I2LeWpG07Ff7T0QPREi34885 -> tool:dsh:lead:call_01_M2PjM0Xe3oXocBmpUxh48549 -> tool:dsh:lead:call_00_9Tl6c3qTlKbNkwDNlgRv4048 -> tool:dsh:lead:call_01_EUh9BmXMvftG9ldXRjvN7823 -> tool:dsh:lead:call_00_mZjfZw9KrcZFAJcNFk1I2525 -> tool:dsh:lead:call_00_cYJdWwMFQsG6e7QP6TpB4884 -> tool:dsh:lead:call_01_Q3V7xMTpZOAabsBrnB5f0957 -> tool:dsh:lead:call_00_A2V6OCjdsuNFXyqGg0At4413 -> tool:dsh:lead:call_00_PgjhyhMG8klpC4QyFX9G2145 -> tool:dsh:lead:call_00_rvQKLyxbcntVh5xTuDeq1502 -> tool:dsh:lead:call_00_zMDkI7z845ChwqNFyRe19239 -> tool:dsh:lead:call_00_TEdnBMtWzq6bjkHop2Ba0641
- 关键路径耗时：1.564
- Makespan：600.455
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
