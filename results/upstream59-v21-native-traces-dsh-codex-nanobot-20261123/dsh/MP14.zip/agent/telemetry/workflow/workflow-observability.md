# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP14__ZtaknN9__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（44 节点 / 43 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：44；执行边：43（observed=0，inferred=43）
- Execution Trace Graph：`observed`；temporal_next 边 43，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_vgXvmT5WY4VeSIPNSfIw0225 -> tool:dsh:lead:call_01_mvSDuAHUv7s55i7edj2y6460 -> tool:dsh:lead:call_00_aYh11GbgnqurSmHUcsSt8689 -> tool:dsh:lead:call_01_NOYw4aRrXwoDcL6Tfft10189 -> tool:dsh:lead:call_02_8b3l9JTgdzMzqyRq3j4C9585 -> tool:dsh:lead:call_03_fE82SVb2oc7kvVh3w0jH7449 -> tool:dsh:lead:call_04_3eZobKVU9mSYKvBmmkHQ2851 -> tool:dsh:lead:call_00_HjmGX7QZOPm0fLZLZQK98955 -> tool:dsh:lead:call_01_fOZBevKDmaKuWNDn0HDB3962 -> tool:dsh:lead:call_00_i6PoRcQwO0npAmTK79tt8155 -> tool:dsh:lead:call_00_rLeXAYzoiOzLVmisFPvd4686 -> tool:dsh:lead:call_00_EQjc4tBBeOw92jLv45186131 -> tool:dsh:lead:call_01_zkIayx4a1iupctzJyqO47360 -> tool:dsh:lead:call_02_2YyMHZpkyb7hLPEbflaR3322 -> tool:dsh:lead:call_00_Gyas0LBGd5ZFVMHxdxpj2078 -> tool:dsh:lead:call_01_IpVlmXnhItkwT4y2pAeP9784 -> tool:dsh:lead:call_02_TFEhOBPVNwzZjDUWoBlh7695 -> tool:dsh:lead:call_03_0VUuD8PU4UG7HrCYYrje6565 -> tool:dsh:lead:call_04_ryTNhebE6SIGEZMYdFQ71657 -> tool:dsh:lead:call_05_3Hz5slPFTFOCoxQxN81A0227 -> tool:dsh:lead:call_06_cl5LmDwnHPpMixncIjFw1595 -> tool:dsh:lead:call_07_Isg0xh7jjvBwDEFG5y0T0552 -> tool:dsh:lead:call_08_2nuQNIPpOIHzt7XY41pz4176 -> tool:dsh:lead:call_00_bqsjdGcTTPvUhSFimJlv9860 -> tool:dsh:lead:call_01_jlA9Ibt3hRULFwpYprVs6749 -> tool:dsh:lead:call_02_zTcxXnFblWTTpAAecJlp2146 -> tool:dsh:lead:call_00_Gu2ZaQw0dqc0mJyAsedI3714 -> tool:dsh:lead:call_01_xyfR6V0UNj5oyBGAETta9912 -> tool:dsh:lead:call_02_rLLB8TfSchfRPSsYHNOO6664 -> tool:dsh:lead:call_00_GFVEbC1qXSFSN58CvNiy5284 -> tool:dsh:lead:call_01_EpKBleCuVBS1O6SiKUVG7945 -> tool:dsh:lead:call_02_6308y9QxAIn1zvsi2cC55079 -> tool:dsh:lead:call_00_URi3rXKbBoNcWTRvaipQ7414 -> tool:dsh:lead:call_01_vZmhjsN6pGx2GD792Esi7425 -> tool:dsh:lead:call_00_jsI9zGbdg3ljsVkwJFP37268 -> tool:dsh:lead:call_01_XLDK4yD36604DjPayBhA6696 -> tool:dsh:lead:call_00_DIUa6t0ZBXsJjEHRwe3g3456 -> tool:dsh:lead:call_00_ibfodfnhYIu7y663o2qo9473 -> tool:dsh:lead:call_01_sVsLvfVWiFgSP5jV6TXW0887 -> tool:dsh:lead:call_00_Airxc2tRFvXXwfMnl1Sh5971 -> tool:dsh:lead:call_00_XbHcc3IFsbA0MC1sxtBT2613 -> tool:dsh:lead:call_00_WTcQBLAM0XcgmxKDWNrQ7717 -> tool:dsh:lead:call_00_sLxEL4t0xJYVtNKyaL4H5834
- 关键路径耗时：1.364
- Makespan：619.402
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
