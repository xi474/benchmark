# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP15__oKxN5qU__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（76 节点 / 75 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：76；执行边：75（observed=0，inferred=75）
- Execution Trace Graph：`observed`；temporal_next 边 75，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_EkaMdw4oqvMXcD2EUAU81177 -> tool:dsh:lead:call_01_Pbfmdj0W31mXAkARY7lu8497 -> tool:dsh:lead:call_00_V0EgL0eeefTbukjmapSD9359 -> tool:dsh:lead:call_00_ORWKAdPrCT7LvnMZ247r1265 -> tool:dsh:lead:call_00_cEVGpHInAgIhp6yo0khV0029 -> tool:dsh:lead:call_00_bQSvnvBopa71o5U5D8yS8278 -> tool:dsh:lead:call_00_E23fQdHWWb6wPkLyI0Cr1452 -> tool:dsh:lead:call_00_c5hnydAlEf3g7wSt8e9X6925 -> tool:dsh:lead:call_00_KqIgT63DrKHXFXTTVxrT7775 -> tool:dsh:lead:call_00_Fx5afryOLOdUR3krowfI3550 -> tool:dsh:lead:call_00_IsJBv8jIArB0szQMwV8r7955 -> tool:dsh:lead:call_00_JYkaFbSModik5wmOCQhy0685 -> tool:dsh:lead:call_00_LdEib5XEpUXQ3nmMP06p9813 -> tool:dsh:lead:call_00_ftEtTDEApiz9oV1eQobE6055 -> tool:dsh:lead:call_00_esy4AAQ5iPeS4Hy92u7k1751 -> tool:dsh:lead:call_00_vXv51rCs7p1K1KxvwNmy5920 -> tool:dsh:lead:call_00_7asbTniKYDAL40f0UVL72050 -> tool:dsh:lead:call_00_EMwr5qXGqGOF11jKQXvz7354 -> tool:dsh:lead:call_00_YjSe6LVy8gI1hcpNr2JN6852 -> tool:dsh:lead:call_01_qTqbqkpH72RS4qBK49uT4450 -> tool:dsh:lead:call_02_TNdjb2aUmEKAiwiHZXhk0513 -> tool:dsh:lead:call_00_ZOmskpUleAVZYcWjVoic6770 -> tool:dsh:lead:call_00_yU5YsUYBWwmI44RnBEBx1023 -> tool:dsh:lead:call_01_5dNDAXSVaLmncPYTYeS98226 -> tool:dsh:lead:call_00_MC9STg7FoGD7biGx5KHD8591 -> tool:dsh:lead:call_00_0ksrMQlfmlqsEqMAGAHa8541 -> tool:dsh:lead:call_00_6vxiE2sQ2vFzh0E7BCpc4272 -> tool:dsh:lead:call_00_LK4cDnA5lRRmPF1sPCLc8373 -> tool:dsh:lead:call_00_OmN75UgwwqtWs6UyCwEw3663 -> tool:dsh:lead:call_00_GUkuLoYp9548CnF4EYaJ1017 -> tool:dsh:lead:call_00_f1JVTVRlAE4yckb9VgBo2397 -> tool:dsh:lead:call_00_nxiqdOZhxBbrepd4jfTs8722 -> tool:dsh:lead:call_01_JE1xZsFdnWUP6ePtMzPH6726 -> tool:dsh:lead:call_00_WyZMA6f96D1OItUxa0ur1947 -> tool:dsh:lead:call_00_CKANnBFKg5d6MKEdr78Y2140 -> tool:dsh:lead:call_00_VFVuRQsRyfKXmSuJ9Yc39158 -> tool:dsh:lead:call_00_NJJzX4zAxam2AIhSHhet7659 -> tool:dsh:lead:call_00_0Ef2yLnitAtKPlgnuzTR8653 -> tool:dsh:lead:call_00_wRckNXNRzs0GUqlfrZP51887 -> tool:dsh:lead:call_00_u562hSwMMligc6ih7Iw22369 -> tool:dsh:lead:call_00_cG3bvxTdEBwtSVJ7pYYG0067 -> tool:dsh:lead:call_00_EEfW6av8Ol1Z4BfScDTP7052 -> tool:dsh:lead:call_00_Koxu5xfiikENAxdzY5EP0946 -> tool:dsh:lead:call_00_nvxYqM8IG5NcN5jjnRfT7653 -> tool:dsh:lead:call_00_DXgquFQ8Z8ByfRkvrDUu9432 -> tool:dsh:lead:call_00_D5TW4tYOnAfCCrwBe6xp5806 -> tool:dsh:lead:call_00_wZMl2aOR8muHuVwRZ1AX7538 -> tool:dsh:lead:call_00_I6q270BNuJ3WxGRCo9us7651 -> tool:dsh:lead:call_00_tKVyq2clFCyVas8HDsly6459 -> tool:dsh:lead:call_00_Q86ZXQftOX4oQDxrcZmF0216 -> tool:dsh:lead:call_00_w8rxg3hlaMKKDyXpgrgQ7213 -> tool:dsh:lead:call_00_rUbsycpOzsHodwKONL2o4296 -> tool:dsh:lead:call_00_f6SbhhMEezajb5arONZd1219 -> tool:dsh:lead:call_00_U0wYFqcyterhkGlHYfe42227 -> tool:dsh:lead:call_00_0jIho8AJQwvQ1ni0muKM1487 -> tool:dsh:lead:call_00_sc6s0pGe7gPox7SupRch1128 -> tool:dsh:lead:call_00_urXFD7jT8HhUCWTTDlm59532 -> tool:dsh:lead:call_00_p9SU1tKID9jnPARO0wCu3675 -> tool:dsh:lead:call_00_fXKspIuaVORlkly5SJFF3236 -> tool:dsh:lead:call_00_gawxvnuplNWOSm3ewipv8867 -> tool:dsh:lead:call_00_oeWZZVRhXZhpxoX1dzBf4339 -> tool:dsh:lead:call_00_ylzGQiS39lfrjfGmAM1b5372 -> tool:dsh:lead:call_00_T7Ntwn558Utz5PMHad315618 -> tool:dsh:lead:call_00_G5u26nlD0pjDc8lIbAbR4408 -> tool:dsh:lead:call_00_Lw3rGfWdhyqDMBuLoS2e6432 -> tool:dsh:lead:call_00_bB2JBTEXrwr1NJBzBNTx9893 -> tool:dsh:lead:call_00_ztIZvAuA68qec2zPzKjT4863 -> tool:dsh:lead:call_00_b8i32cldp6jQCHB3VyVb1025 -> tool:dsh:lead:call_00_qCCLgaupC5UZc0mzzn4p9991 -> tool:dsh:lead:call_00_IDTStDMwlUcIdv0WCTq39015 -> tool:dsh:lead:call_00_5sH2Nu4yYnqbKPm9NcuT5633 -> tool:dsh:lead:call_00_st80y9xWr2jq2LucYhjK8795 -> tool:dsh:lead:call_00_UcWHuRat8ycPUxBBvd2U6090 -> tool:dsh:lead:call_00_X4DjjhxO2oBkMgNnATNc7762 -> tool:dsh:lead:call_00_vEDE33tUlneRAzqsrSKR8398
- 关键路径耗时：4.371
- Makespan：1412.144
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
