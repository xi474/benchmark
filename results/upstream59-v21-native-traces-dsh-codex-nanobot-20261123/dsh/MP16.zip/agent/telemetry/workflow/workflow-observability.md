# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP16__7VNpBZk__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（51 节点 / 50 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：51；执行边：50（observed=0，inferred=50）
- Execution Trace Graph：`observed`；temporal_next 边 50，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_tR2NTSof8VIv01XhxAI05313 -> tool:dsh:lead:call_01_Ai1v8LPLvgb3dw87kUUQ4022 -> tool:dsh:lead:call_00_jflpcAvqHFDd5MKBXGB27116 -> tool:dsh:lead:call_01_f5a5ZOTdKfFfo6VHo6Hl4282 -> tool:dsh:lead:call_00_cwDeJA1YKYbJPUTdQxEF0584 -> tool:dsh:lead:call_00_TpfDffZ5v46AzVpkZsl88563 -> tool:dsh:lead:call_00_JJWO1sLSxn5BPLrbpSGG0403 -> tool:dsh:lead:call_00_oQzc2SdfSRS5pBDqhszO6857 -> tool:dsh:lead:call_00_15DwDEHZQdOHLIOwcWlZ2335 -> tool:dsh:lead:call_00_fUabqdJfNq5xRcvbCGoF3001 -> tool:dsh:lead:call_00_CVN28M8iBkSrh2fC0qvE9928 -> tool:dsh:lead:call_01_jgixx4JAWprm76p8UwfC5886 -> tool:dsh:lead:call_02_QODbJrGE862AdYjCQrUU1371 -> tool:dsh:lead:call_03_8USgWTwPGU3WynbZPYrz3798 -> tool:dsh:lead:call_04_SRiywjWY4kx85jm0pnYJ3341 -> tool:dsh:lead:call_05_C09t5zTbVApfWUDHppVZ4992 -> tool:dsh:lead:call_06_cvMPWqnVETiMJ3QclBKA2863 -> tool:dsh:lead:call_07_nf7A0lHzcHXswH1mYuvw3712 -> tool:dsh:lead:call_08_KxuSF2WIoHx7mZUZGOFT4106 -> tool:dsh:lead:call_09_CWLIhwEklv45JaksfyxY2741 -> tool:dsh:lead:call_10_qdwjwEa3s6khORvmSSJ19759 -> tool:dsh:lead:call_11_qjLmO5D3TkqzehYU144N6816 -> tool:dsh:lead:call_12_CIb5BjDtDYQWVXSHQ1CA2828 -> tool:dsh:lead:call_13_p5MZhKmsKVGViqS34rv68641 -> tool:dsh:lead:call_00_Ti6x0iIlv49MxYKbWHTg0164 -> tool:dsh:lead:call_01_eguVWvYwQijgyfQcGfdb9890 -> tool:dsh:lead:call_02_svnxKDkPKvmXyqg5iVm99818 -> tool:dsh:lead:call_03_Xr4Nw7KsGDvTYSA7S40X8038 -> tool:dsh:lead:call_00_bl9TGIGgZRmBbwtA0eVU8675 -> tool:dsh:lead:call_00_3DWcxjU9ycn4SjbfOudY1210 -> tool:dsh:lead:call_00_MZhDwCg8GKTYkHUWPPL77118 -> tool:dsh:lead:call_00_1T4919NtS0Mj4QDrp4bo8122 -> tool:dsh:lead:call_00_QapMGgzZkQNtYzdbySAP7162 -> tool:dsh:lead:call_00_0ruoCpVRelTVNYbxWeZU8578 -> tool:dsh:lead:call_00_gUKPhPl8D4lfgpPucciA5046 -> tool:dsh:lead:call_00_it091cYxm58b1gTiQG7Q8789 -> tool:dsh:lead:call_00_EfjgNS4gKIeiuZCZjxNa4879 -> tool:dsh:lead:call_00_iVhCvQ50Cdy1fdnOw2w79548 -> tool:dsh:lead:call_00_rj8NEqUA0HDujblEt8kM6817 -> tool:dsh:lead:call_00_T6M6S1YbZBSGTef82mGP1550 -> tool:dsh:lead:call_00_u8ohDYdBp58HXL2jeGmi4978 -> tool:dsh:lead:call_00_WnvISdm9TPugJALUSf9S7754 -> tool:dsh:lead:call_00_gcspW0XUIIJxS3fdXo2d2866 -> tool:dsh:lead:call_00_D0LcbwZD9NZt5SGJA3hq4110 -> tool:dsh:lead:call_00_Gnt7wd3vITlPbuVEquIJ1517 -> tool:dsh:lead:call_00_tQdT26r76gdTe44SEPfJ4643 -> tool:dsh:lead:call_00_cvJQgUT02b1yyaQUV6CJ2045 -> tool:dsh:lead:call_00_VUyu4FlGpxQBLQ6n0lfp1553 -> tool:dsh:lead:call_00_kasdZZphfRvm4kHjsm5u5003 -> tool:dsh:lead:call_00_ko8E2Y8mPwQA1hAnAJ4q9122
- 关键路径耗时：2.056
- Makespan：665.083
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
