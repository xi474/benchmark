# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP17__gsUd3jv__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_MRAG1KwyETiJ2W5jnvm36728 -> tool:dsh:lead:call_00_2C4n25hupoTSF9WV1HM33711 -> tool:dsh:lead:call_00_pNfAQ1O0gY0z6OQQyBI54258 -> tool:dsh:lead:call_00_D0fbQoH3rY98Fts8YFIQ4595 -> tool:dsh:lead:call_00_g6AnoIEgOHkG0RtJfIMr2324 -> tool:dsh:lead:call_00_x9yDZ69swrI5vfVAIfZ66381 -> tool:dsh:lead:call_00_dwBQVWWKD8Zcd5gqRcMy7635 -> tool:dsh:lead:call_00_6TDAlid3XFzvZHSLh5sx3486 -> tool:dsh:lead:call_00_v3DxyRu8Wh7TwBvcB7ju9804 -> tool:dsh:lead:call_01_zh8aNIHhxN5fx4DT7T3X8861 -> tool:dsh:lead:call_02_ycXVgiGOFVOVLr8J3TE53376 -> tool:dsh:lead:call_03_8eY3D5Y0wLI5xNjnWdrF8528 -> tool:dsh:lead:call_04_6NQLuaA65E2NQrhoSKlr6921 -> tool:dsh:lead:call_05_A8AIMtM7Kt8G3XdUYajT6264 -> tool:dsh:lead:call_06_YBblUzlNeTs94hDe81Sv1722 -> tool:dsh:lead:call_07_XCIhZku49xH2Hgu8XTuN7914 -> tool:dsh:lead:call_08_Jw2XT4zzFBotEZfljX9H9471 -> tool:dsh:lead:call_09_68YZyHh2v5IRMpUrKqqs7651 -> tool:dsh:lead:call_10_GHI3MqqUYoftcNA1GYmd4145 -> tool:dsh:lead:call_00_glbWWyHiVwPGR2o88zVc0857 -> tool:dsh:lead:call_00_HI7TlBcvBJH38VI0Xoqw5400 -> tool:dsh:lead:call_00_HFCofPclfRTKQo14z6nP7448 -> tool:dsh:lead:call_00_hgvZOsZJ1rNHzZdQnOV67536 -> tool:dsh:lead:call_00_e4Y9VNfX6IR4Kk8BJb4d9112 -> tool:dsh:lead:call_00_QwdyAbbFD9Ln9latywgn2270 -> tool:dsh:lead:call_00_zKr9XqtihtS8XgsEOceC7638 -> tool:dsh:lead:call_00_MhKlqcmgYHgayL0qJ6rA9932 -> tool:dsh:lead:call_00_B6G47QK8k4MtvNzMrvpY4427 -> tool:dsh:lead:call_00_r2aFMKHvHh4I4NWho6kV4683 -> tool:dsh:lead:call_00_NsGZFIjKQdsamk4jztO76704 -> tool:dsh:lead:call_00_LRGaHeYcmGiwzVqM0p7j2912 -> tool:dsh:lead:call_00_qRCoaVTrffcV7RdvD2VA8009 -> tool:dsh:lead:call_00_YXJOg8IswLHm6bwTXEsy4489 -> tool:dsh:lead:call_00_YX8acVIjb0YELn7TpRBc4571 -> tool:dsh:lead:call_00_27en6OWyavNs6rZW9USi8323 -> tool:dsh:lead:call_00_H2qEo28vBJKhMeCIJFPM5265 -> tool:dsh:lead:call_00_BYxDyQ3fClHLwtcQwx691985
- 关键路径耗时：2.934
- Makespan：591.368
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
