# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP18__7Zmx8MD__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_dgyTU0iQg2kPYLYpomr96237 -> tool:dsh:lead:call_01_5QUqGpMV0ozXdvy5wymw6520 -> tool:dsh:lead:call_00_4ZSwfbUdMew6nomW8sc32765 -> tool:dsh:lead:call_01_pnG9cJ5qUrY0JvkmKwnY8283 -> tool:dsh:lead:call_02_EorFlQdE8U5DBUnnC4XZ5171 -> tool:dsh:lead:call_03_4bBdCv0oQ5PqGYvDC9Bz7471 -> tool:dsh:lead:call_00_ejD1CbIp5ZZbIOYFaYdI8142 -> tool:dsh:lead:call_00_vi3lsyzfU1ZUIXCpHwHI8312 -> tool:dsh:lead:call_00_XvAHki1OdiASCb3OEOax4111 -> tool:dsh:lead:call_00_KWQLdYsbExVx29mcJ9hp2811 -> tool:dsh:lead:call_00_HiO1xZtrf7oxqDw2LvwG3316 -> tool:dsh:lead:call_01_aVryROCIlFva4i2r9Vfo9793 -> tool:dsh:lead:call_02_ycyb2QOYCbtwqZZ2rVPG0259 -> tool:dsh:lead:call_00_lAPyGOcG53Oh4TdkFPKa0300 -> tool:dsh:lead:call_01_gjHN2eqzT3axBPMCLr2q6510 -> tool:dsh:lead:call_02_uhLD69zAKD6O1kLARZKN3336 -> tool:dsh:lead:call_03_Xn7qGhkiGQOcIx0Dd6eo9000 -> tool:dsh:lead:call_04_kuffOa5TxPyWYgq7d3xO6650 -> tool:dsh:lead:call_05_lpHwDZXE9HFpCLKUh9KF3111 -> tool:dsh:lead:call_06_oYAQAdBFxwEkzzsZRUmJ2951 -> tool:dsh:lead:call_07_VICDziOPSO3hegB00wRk3174 -> tool:dsh:lead:call_08_aR9Nwi4aZkFrpaSsIuTr9036 -> tool:dsh:lead:call_00_KAO3vZTDKPJCBlTukX8R5778 -> tool:dsh:lead:call_01_dpAf1bH6nrDvwgRsArQ76483 -> tool:dsh:lead:call_02_38aUSEfhZDnZYEiT9B7w9699 -> tool:dsh:lead:call_00_2Nl43JmpThD4rkfBq5ac7023 -> tool:dsh:lead:call_00_qDzePeIfykvTGABF7nge4657 -> tool:dsh:lead:call_00_eWwSOWQQNt4bfaCKgrRH8010 -> tool:dsh:lead:call_00_25bYlhjg6GwOUz8tbK918476 -> tool:dsh:lead:call_01_AqlUeHi6vFmn6CfHrkvY1151 -> tool:dsh:lead:call_02_sIdP7icL7URYMRIjLjT30599 -> tool:dsh:lead:call_00_NitnQA7Zj7oPjtGvsrHp3236 -> tool:dsh:lead:call_01_FzLii5ymzZA16xbPcagO2425 -> tool:dsh:lead:call_00_77vETN1WuAJJvUxkn5o99529 -> tool:dsh:lead:call_00_nzGGqMY97NwUVIKm90oI3849 -> tool:dsh:lead:call_00_p5fAh1d7SkSiW2q6gmmu3227 -> tool:dsh:lead:call_00_RPUoQChMMUYcjBSN9MkQ2381 -> tool:dsh:lead:call_00_OltfQvZtVM9xXwpJIRyZ1128 -> tool:dsh:lead:call_00_YWk30en6Jr0ue8oczl938282 -> tool:dsh:lead:call_00_ciYKlWxG24gdLp6533MW0595 -> tool:dsh:lead:call_00_WwTcglafq8IWu5aqBlBm2724
- 关键路径耗时：1.902
- Makespan：508.185
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
