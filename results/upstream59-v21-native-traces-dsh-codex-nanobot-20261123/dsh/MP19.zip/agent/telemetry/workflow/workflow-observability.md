# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP19__Q6LbApM__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（52 节点 / 51 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：52；执行边：51（observed=0，inferred=51）
- Execution Trace Graph：`observed`；temporal_next 边 51，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_YrmjNgXwMIaIHhSTQTem3826 -> tool:dsh:lead:call_01_XMoqmc4mXSUgQ47sFq713039 -> tool:dsh:lead:call_00_q5mN9T3LQRjBEyyeIAPf2112 -> tool:dsh:lead:call_01_8gJnMIljeqN1Hl8CO4i90505 -> tool:dsh:lead:call_02_9ZTMW7as5wATIMcucHK14842 -> tool:dsh:lead:call_03_qUVPoWHfrxOKwKcTPLIZ4206 -> tool:dsh:lead:call_04_kt1UgoTrEreYZcwIYwLD8304 -> tool:dsh:lead:call_00_2HBeKJfNY8SVCzAQQDJB5694 -> tool:dsh:lead:call_00_zHYl4Dj3QmshzuJrgWHb0679 -> tool:dsh:lead:call_00_ZxvSoslf1a0UX2AtE1QT1513 -> tool:dsh:lead:call_01_gyayG2iNoTVHTVFHL0Jf6257 -> tool:dsh:lead:call_00_CNAe55Bfip72x39nnH4J2990 -> tool:dsh:lead:call_00_zieipBFPcbLc35zFNhA86430 -> tool:dsh:lead:call_00_JxH71XGsjlMubJDHgLUE4320 -> tool:dsh:lead:call_00_wg12Fm1ezvnDPl41NQX13752 -> tool:dsh:lead:call_00_n03H2g80EykV9J5bYHQE7292 -> tool:dsh:lead:call_01_Rpk66i4I5vcrjBMKJHp07291 -> tool:dsh:lead:call_02_Y5vabymBT2I6XlrlATSL2252 -> tool:dsh:lead:call_00_eh5VsRZhi2aInpZketIr2278 -> tool:dsh:lead:call_01_FFtpamEztcQzvfIIkr7H2614 -> tool:dsh:lead:call_02_yBGIIEZFGfPyG4PMd8QY1129 -> tool:dsh:lead:call_03_5fO6RHVMvMTuMzlinfYA5031 -> tool:dsh:lead:call_04_px9PaiFHmtIK9JxpLRdq2576 -> tool:dsh:lead:call_05_yXeADxSVw1ZgiwiNQZFB1466 -> tool:dsh:lead:call_06_rXbgrMe1pYKvPHfKXm6s5558 -> tool:dsh:lead:call_07_kRJkYtKyLzCNvTUPoZLr2543 -> tool:dsh:lead:call_08_de6zL5F8waeygCYWRbBe6099 -> tool:dsh:lead:call_09_H4vbL6xdexnrUZhG88a35295 -> tool:dsh:lead:call_10_lBxZkpu4c8J5VGo1GJo13432 -> tool:dsh:lead:call_00_wJsokZvVEXhu5hMlHeez8783 -> tool:dsh:lead:call_01_wSh1yF48RVmOX6XqTv4s3652 -> tool:dsh:lead:call_02_th12vCdJJm05xOX4CxYa0144 -> tool:dsh:lead:call_00_WtrHhSHEpORshB2CQIBX8452 -> tool:dsh:lead:call_01_Yym3j27XXly8UPgRiKOe0417 -> tool:dsh:lead:call_00_4d9TJbYl9SKGUexlt1uE0039 -> tool:dsh:lead:call_01_tWluokgfi6gL3hRYGxVQ8011 -> tool:dsh:lead:call_00_x3Ebqa6Bw6sloeW2iHqs5302 -> tool:dsh:lead:call_01_jk2ggUXiBdsRdIwhckFy3478 -> tool:dsh:lead:call_00_SFC8sx1NNNXKNgccTetS5924 -> tool:dsh:lead:call_01_XvbfwZnn4eUyMSmnk2LO3978 -> tool:dsh:lead:call_00_9EWhHV05ff17nkbjMYQx0576 -> tool:dsh:lead:call_00_uvrK7WMH3OETnhonTTT27392 -> tool:dsh:lead:call_00_mOSQC9gmrbZr0NxxEgu89693 -> tool:dsh:lead:call_00_oo4KkUtHy00MUevXlmzg6018 -> tool:dsh:lead:call_00_qF3dFv2vjYTI7Dgnnqnz8865 -> tool:dsh:lead:call_00_008DYycTwlhi3mfKvP0g8754 -> tool:dsh:lead:call_00_d6Ny0LsjvqNwueWVZcVK1339 -> tool:dsh:lead:call_00_s1moYSWvD9nMMJpK8IgX3602 -> tool:dsh:lead:call_00_FqbTPmDFIkzpYyvVQ7en9645 -> tool:dsh:lead:call_00_7J6KPREi5fq0P5oB9YIn0014 -> tool:dsh:lead:call_00_sqhy8PhXuFtLZ141kgXi0788
- 关键路径耗时：2.979
- Makespan：902.657
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
