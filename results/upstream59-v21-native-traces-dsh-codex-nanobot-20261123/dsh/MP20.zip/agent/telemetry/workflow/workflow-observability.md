# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP20__QGrQjZb__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_7nqMOO6bwssPQ0xXo3Vj1496 -> tool:dsh:lead:call_00_8CHsg55sWBWmbbkyC0x32344 -> tool:dsh:lead:call_01_V1Xuin9AKyeBg6nuzyne3370 -> tool:dsh:lead:call_02_RDDL17Aco54GhGfBfyBJ2833 -> tool:dsh:lead:call_03_i7x8uRvbMkpxuPvjB6RG4272 -> tool:dsh:lead:call_04_ROXUukeJzCxgCE4p2ak21245 -> tool:dsh:lead:call_00_X5SHbzNkRcqD0k6s5BH50165 -> tool:dsh:lead:call_00_5Dt2yVvQz9LVKDHO0qSN1262 -> tool:dsh:lead:call_00_93GiKD5UqQi2JekuqT9T2121 -> tool:dsh:lead:call_00_3xQ6tCNvkFu6oCf4PMNB7779 -> tool:dsh:lead:call_00_gNNs8QIpUY3t4pjuzRO77479 -> tool:dsh:lead:call_00_8XFzj4Mi1phf22uIeJSV6523 -> tool:dsh:lead:call_00_xrEl4Orp8u4F21onTjoF4237 -> tool:dsh:lead:call_00_RfJ5YyxNobejqs1VdIrK5098 -> tool:dsh:lead:call_01_KDq0JS3cawDIaRnErmp04418 -> tool:dsh:lead:call_02_UYDmdK9sU3qUKSOHu0568721 -> tool:dsh:lead:call_03_TO924pd7gv1kSU4CXGM56016 -> tool:dsh:lead:call_00_jTuIsa6fg9MlCcKfDpif5560 -> tool:dsh:lead:call_01_m11O7V6YLpAPi6GpsctX6035 -> tool:dsh:lead:call_02_yYR98buS6fAoVMEjghtq9222 -> tool:dsh:lead:call_03_kSBVEXFSCFknH0RcrlGe4467 -> tool:dsh:lead:call_00_jMUoYTdeMJJzuPglKMs84585 -> tool:dsh:lead:call_00_WsK1tAHdywzqScr4mFuk3044 -> tool:dsh:lead:call_00_EY0Sio3cq080zsJn7oLu8068 -> tool:dsh:lead:call_00_98WbObwSlesw2SlG1dnY5157 -> tool:dsh:lead:call_00_95tsBEOLzgOrUlsgNuaV5608 -> tool:dsh:lead:call_00_gJtGlEAz8R06T9bBcMw69619 -> tool:dsh:lead:call_00_esOnXhGDNmrJUSxZTfnn7117 -> tool:dsh:lead:call_00_umnZNowRs7afEg2THSDv1622 -> tool:dsh:lead:call_00_94CCiMDTozRN8ZXGu3tQ0259 -> tool:dsh:lead:call_00_cki2WyfmVyuyTNJ0YjRU8303 -> tool:dsh:lead:call_00_uNHxb87y7rut4AdtGQ8j6857 -> tool:dsh:lead:call_00_vpin6IBIY7kWh7pjfAoV3270 -> tool:dsh:lead:call_00_FF0SIZq3crCJXsyiBvcF8116
- 关键路径耗时：2.123
- Makespan：642.911
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
