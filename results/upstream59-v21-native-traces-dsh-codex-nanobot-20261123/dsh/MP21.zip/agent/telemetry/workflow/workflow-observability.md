# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP21__jKoU2rQ__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（43 节点 / 42 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：43；执行边：42（observed=0，inferred=42）
- Execution Trace Graph：`observed`；temporal_next 边 42，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_5XYOmgQYyI8bMNHmW7O08844 -> tool:dsh:lead:call_01_eeGut5p7DUdIwrHaJXZk4387 -> tool:dsh:lead:call_00_xYmalPKRuqrSAcKEWz758419 -> tool:dsh:lead:call_01_pPbyeeiqdvdAqzrCWu9U3390 -> tool:dsh:lead:call_00_6CSj57mIUg12mb57thS43920 -> tool:dsh:lead:call_01_TUNapWan0dxFvLeITitu0328 -> tool:dsh:lead:call_00_XIh4mb8GBjmJPLMh0nfh9840 -> tool:dsh:lead:call_00_tT9UEWFGRuZPr28MHE5b8145 -> tool:dsh:lead:call_00_V4Gf7MFa5okwLJPUaQyF4943 -> tool:dsh:lead:call_00_k1vmJqK4yz0dR3s1oRxX6941 -> tool:dsh:lead:call_01_m5VxGopgiqA1oAiPk45l7355 -> tool:dsh:lead:call_02_qQcv7ouK4fgacSqwYYrq8108 -> tool:dsh:lead:call_00_qktF0Qg2oyM8bHCpHL7v3389 -> tool:dsh:lead:call_01_7EWiwFt8rlCMPeHdYpmd0286 -> tool:dsh:lead:call_02_BDZkeSK1Bzb0AWnFnqjA5518 -> tool:dsh:lead:call_03_bhHyGyWd2mSynu44pk8C3094 -> tool:dsh:lead:call_04_wdWnOWQ4m0Q0Qzc6XvQL2649 -> tool:dsh:lead:call_05_9PeD5Mo0GEWBoEzOaVY79361 -> tool:dsh:lead:call_06_JpDAWtTVjThBa94KUkAV2374 -> tool:dsh:lead:call_07_f5TDbBJphVXytN5zeOd70564 -> tool:dsh:lead:call_08_KPh2hhAKpWc9s2iG8cfM4319 -> tool:dsh:lead:call_09_fGm6Yenms3C0yK1SVPLR5023 -> tool:dsh:lead:call_10_wKnBaRjztaQPN22WEr076732 -> tool:dsh:lead:call_00_dmjlxrSdiwdsPCnPFDJV1987 -> tool:dsh:lead:call_01_HlMdQp2JF8q6nGOMHBNN4988 -> tool:dsh:lead:call_02_PEEIfT6yrharSsjcR9ZM8491 -> tool:dsh:lead:call_00_qr6eMXcUbsr1kPTiTVB58064 -> tool:dsh:lead:call_01_5dhSuW3j9qugfqaI48PB2700 -> tool:dsh:lead:call_02_G6q4yQsjMGwo32uKKn1H8338 -> tool:dsh:lead:call_00_bBZPIMrSORamPSdjt5bS0316 -> tool:dsh:lead:call_01_o2KIj64PuSh0787irjXF4241 -> tool:dsh:lead:call_02_rrxDqlFnzlgYABW5uAaZ8905 -> tool:dsh:lead:call_03_PkjftROcNMdfqtjZYliq2453 -> tool:dsh:lead:call_04_fRu3USCJ81Uky8B9DaZa7639 -> tool:dsh:lead:call_00_kyZV8KDgxXAM1u9lJLhZ8893 -> tool:dsh:lead:call_00_ZZK71PEZAa81fGxNAU787837 -> tool:dsh:lead:call_00_EEFtDcWfs2xSNTBL4oIK2854 -> tool:dsh:lead:call_00_D8W84yJ4rpds7FdzoZWr0451 -> tool:dsh:lead:call_00_I3AUM82BEiJ0rqFhBxWE5641 -> tool:dsh:lead:call_00_xQCPXsm0HG3th3POMMLk5234 -> tool:dsh:lead:call_00_UdzG0eJiVmvusJcstUik1701 -> tool:dsh:lead:call_00_Tp15nVJiqqke4DqIdFcS0985
- 关键路径耗时：1.925
- Makespan：591.141
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
