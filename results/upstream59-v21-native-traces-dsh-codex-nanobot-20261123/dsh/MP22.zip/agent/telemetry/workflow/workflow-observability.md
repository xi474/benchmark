# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP22__cfMPZF2__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（80 节点 / 79 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：80；执行边：79（observed=0，inferred=79）
- Execution Trace Graph：`observed`；temporal_next 边 79，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_iQOJ1xYyKwvOiSquJwC87961 -> tool:dsh:lead:call_01_sPBViLqmwXgnbCyXWaT01181 -> tool:dsh:lead:call_00_zfD8ksOBZH7N5uRl1iaV1363 -> tool:dsh:lead:call_01_bCT83HSSfyNDBSQHWkgw8825 -> tool:dsh:lead:call_02_RUSmqcF1cl1dHLF15ebs8144 -> tool:dsh:lead:call_03_PI0sRfXnHjgPOQlNI9LI2303 -> tool:dsh:lead:call_04_TboaYZG4GvKZPN9gi3RF6735 -> tool:dsh:lead:call_00_EWVKrEYPuCqVAiEcf6rI1520 -> tool:dsh:lead:call_00_2djhYmVxXVoBMvKCW7PW9577 -> tool:dsh:lead:call_01_1D6lI0wO4rmfPZPOs6BC2444 -> tool:dsh:lead:call_00_2MX4xzmTJy57zmroTkZW7879 -> tool:dsh:lead:call_00_YrEc0dlkFW0NrONAySqT6350 -> tool:dsh:lead:call_00_UYhjkPZWupTaBrUI8YqH4062 -> tool:dsh:lead:call_00_32FNzgmC8uw6nZPIuSRP9052 -> tool:dsh:lead:call_00_GRvclfLeTQeDWE8snqF37870 -> tool:dsh:lead:call_00_mQFukCVUcZwKOmYtDr6g2627 -> tool:dsh:lead:call_00_H3lddH5RKlUoQE9Bic3z0535 -> tool:dsh:lead:call_01_xtrfWpj8w9fNmQh8Sq2D4378 -> tool:dsh:lead:call_02_NpIX9R7nO94o6JyGfw5X8049 -> tool:dsh:lead:call_00_Fd5pv72pSeTjpNEGoIHj8550 -> tool:dsh:lead:call_01_HEwbqIRM3WKei0xEDJj34583 -> tool:dsh:lead:call_02_hpiPJxUab9IgTUaUp0yr0558 -> tool:dsh:lead:call_03_o3bdadl7IY75e1jXC3QB2136 -> tool:dsh:lead:call_04_ruc5nPNM9qu7g1hEurrV5589 -> tool:dsh:lead:call_05_9vn5CBaB6owhwu5QZi0M1724 -> tool:dsh:lead:call_06_MhNX7CxlYvt9PLhs6nga5549 -> tool:dsh:lead:call_07_jOgfjMlU7tPFhsaXP2an0485 -> tool:dsh:lead:call_08_sSfHU7UbclJZEEDAJ4Ty9819 -> tool:dsh:lead:call_09_yYa9jiHiwgUMjRyJIZs13932 -> tool:dsh:lead:call_10_EwjVqR7rV9to46A7gm6k4368 -> tool:dsh:lead:call_11_iXuLFDyJDUvNszz0hk5Y8824 -> tool:dsh:lead:call_00_0mXs2R2mXgPH5j2qfBOF0082 -> tool:dsh:lead:call_01_tiyORb1ab8eclRZMNjb49351 -> tool:dsh:lead:call_02_YxiKx47NpXBzwDOVyAeU8812 -> tool:dsh:lead:call_03_9oSZWjgzbG8ZGGkeZrjb4945 -> tool:dsh:lead:call_04_jM7y1BgD19a26sy6OEVq1950 -> tool:dsh:lead:call_00_1Ju4jv1ww9TD2TTOulIR8345 -> tool:dsh:lead:call_00_Oyk2nCqIQWDAbgBePpSb0593 -> tool:dsh:lead:call_00_TD4vZ6GfIVT9cm3CoNmy8599 -> tool:dsh:lead:call_00_aS9bKp6RhddeYJzZB3Fe9143 -> tool:dsh:lead:call_00_op6qSJQUEX0qAXgKnewi5237 -> tool:dsh:lead:call_00_VKkWM26PoxoObmnQHKmD0757 -> tool:dsh:lead:call_00_LhZxoFSn1FQWjPSW9rMH6149 -> tool:dsh:lead:call_00_pnK1HZDLacd648enDdb51546 -> tool:dsh:lead:call_00_a1538hGQ5eJwBDtka2Rd2631 -> tool:dsh:lead:call_00_0lXmaFBGg2WRZMsegqDZ5006 -> tool:dsh:lead:call_00_GRpO2EfcX9qty9HPLqYD4841 -> tool:dsh:lead:call_00_D2rqe7ds5N8fx7pmUogI1027 -> tool:dsh:lead:call_00_LoGZKkPGEowt4yAEjvKi3797 -> tool:dsh:lead:call_00_YVtQNkKyBJRMcrK5z5x28681 -> tool:dsh:lead:call_00_1lxoxEa8YwYGfnt90D380662 -> tool:dsh:lead:call_00_9HZGXTKzM8IoAJFuPA3C2212 -> tool:dsh:lead:call_00_mtXMxziUZNvuv0vBao4H4416 -> tool:dsh:lead:call_00_bpkyutj6C1RTiFx8JX5B7390 -> tool:dsh:lead:call_00_lQKMVleRopW5074tqtz07228 -> tool:dsh:lead:call_00_6u9DWTKFoMtrGBny4XK23792 -> tool:dsh:lead:call_00_Gtx0KHdTsahHuNMgMFuJ3257 -> tool:dsh:lead:call_00_I6I0pOSBPgjKhyXS3o9D3272 -> tool:dsh:lead:call_00_qYjC2S4ncwBcyWjt38Eg5079 -> tool:dsh:lead:call_00_4DxlmqRq83anSfyE4yMn8922 -> tool:dsh:lead:call_00_bZrvqvq8y7BgRskKvixT3542 -> tool:dsh:lead:call_00_MO2FWPpzcRxz8Y0SnDVV5973 -> tool:dsh:lead:call_00_8fWcUyWrIDGdyVrgiAqc2680 -> tool:dsh:lead:call_00_2wtiard4zb9clSG4Km2X5674 -> tool:dsh:lead:call_01_pzRWPLccfPhC4i6sBMdG7672 -> tool:dsh:lead:call_02_aT7KrQBujnyqUAYgH2ys6247 -> tool:dsh:lead:call_03_3XmYKVPNqRHH3eMNAgmk1552 -> tool:dsh:lead:call_04_j3FyBMzxFQPPVikX46Mn2003 -> tool:dsh:lead:call_00_M8YEYm8VBlCOdhSz6yMa5675 -> tool:dsh:lead:call_00_YyCbx96XOKc6z2Fo9RTW8642 -> tool:dsh:lead:call_00_4WEqe3PWjBbqLggVggCN3193 -> tool:dsh:lead:call_00_I2wY4iiT5DNkW5pKDLyu6779 -> tool:dsh:lead:call_00_SSjTte6qxI7eDdp4l5bM0580 -> tool:dsh:lead:call_00_66aE316uEQTsfkpaL4Mc3862 -> tool:dsh:lead:call_00_3ZkmxJunpt81LS45Jfmc2722 -> tool:dsh:lead:call_00_2LDHlBftSGVhbo9tAqXW7896 -> tool:dsh:lead:call_00_5hWlZXBCuQ7ThzknWcAg1577 -> tool:dsh:lead:call_00_H6bILZrMkcaIlenIka2g1722 -> tool:dsh:lead:call_00_VSMo12SK8SAjLdYQtWOj8405
- 关键路径耗时：3.604
- Makespan：1063.456
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
