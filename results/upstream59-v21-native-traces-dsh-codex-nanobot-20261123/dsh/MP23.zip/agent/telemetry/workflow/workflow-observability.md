# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP23__JGUeoo6__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（39 节点 / 38 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：39；执行边：38（observed=0，inferred=38）
- Execution Trace Graph：`observed`；temporal_next 边 38，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_HGg6CW1h7T6aFR8CzSuy7478 -> tool:dsh:lead:call_00_Ipxx5sdF6ZiikznpyF4y8362 -> tool:dsh:lead:call_00_2emAR9O1oYoSBWTImEKC9737 -> tool:dsh:lead:call_00_UzKWFGhCEaV3eOF17Ua99559 -> tool:dsh:lead:call_00_dBVCKmTm5x2Jv40umC5o2210 -> tool:dsh:lead:call_00_6Ljikz9hQOwSIZXq1mRR9665 -> tool:dsh:lead:call_00_9joboDuQ2DObJ3jjysfz3410 -> tool:dsh:lead:call_00_zW2TchmuEHydUTS96A8C9894 -> tool:dsh:lead:call_00_1OFcqEa14Wa6ELdw7ol62681 -> tool:dsh:lead:call_01_1nlnHjv12CASVyOeBXLc2029 -> tool:dsh:lead:call_02_1zk69chKZ1bWQ5eZkpd43124 -> tool:dsh:lead:call_03_nAqQJ91Kz2zIXxExUfQ79640 -> tool:dsh:lead:call_04_E5Be6o9FkEFd2VaTdw4s2145 -> tool:dsh:lead:call_05_mcotnb4xa9JS6wqIMwnJ1288 -> tool:dsh:lead:call_06_oayIJQQV3fozw2x28M2U5312 -> tool:dsh:lead:call_07_XqoPQ2p4ukYKXrcPOqql4422 -> tool:dsh:lead:call_08_eiZ6gJkKlaIZubNdsEhj5231 -> tool:dsh:lead:call_00_QUmBavGcQJHMAT0ZEO6c4807 -> tool:dsh:lead:call_01_N4vsOcWaPe6aZgp7UNIf2790 -> tool:dsh:lead:call_02_VEdRoCHxemtIUlKozryQ8295 -> tool:dsh:lead:call_00_44RH8cCSqT6G2B3eMWDE8599 -> tool:dsh:lead:call_00_746Ep1JvMJv58pBRtKnQ3488 -> tool:dsh:lead:call_00_Uxh6TmMR5xJLWjN0lmEm5563 -> tool:dsh:lead:call_00_aIGK0xBWlDBqD2hHBRQS5770 -> tool:dsh:lead:call_01_fZcPKFhiXWDRBaz7NCMl2767 -> tool:dsh:lead:call_02_hqPTyXy9UOrii0Jwzh9m3751 -> tool:dsh:lead:call_00_QDsz08iAsMM1pcTsuKAq6730 -> tool:dsh:lead:call_00_n7SdknxaDNB22w7XVWc51686 -> tool:dsh:lead:call_00_p5JRFpW1BAsVIO27b0LS6432 -> tool:dsh:lead:call_00_h3gVjaE7qA5LJlEF3OrA2722 -> tool:dsh:lead:call_00_NXC53ARIXXvbkd4m89Ln1432 -> tool:dsh:lead:call_00_1oo43eJrH4hO7PryJI6C4909 -> tool:dsh:lead:call_00_ZrIrLJs7WcVSCp7ahOuA7515 -> tool:dsh:lead:call_00_399NmW1fr4Zg2jhBGY7M6354 -> tool:dsh:lead:call_00_JPBnetUtRYhn2zYTJmXA1646 -> tool:dsh:lead:call_00_fSxVbBFr3JhLnSgvuhC95894 -> tool:dsh:lead:call_00_PwU3IrJo0K0dmfqR50Le4035 -> tool:dsh:lead:call_00_t98uikSyfMkjfnmMzpI17960
- 关键路径耗时：2.151
- Makespan：692.444
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
