# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP24__aY7NLvg__env`
- Task：`core6/MP24`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（50 节点 / 49 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：50；执行边：49（observed=0，inferred=49）
- Execution Trace Graph：`observed`；temporal_next 边 49，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_TLyau5QjgrY725aYh3hx1923 -> tool:dsh:lead:call_01_mJhJG2u2VzY08KDpJrXr1289 -> tool:dsh:lead:call_00_If4VzlVWMrF3l8HUlHVI2369 -> tool:dsh:lead:call_00_IsKXTqAEi9TRMTI6Dnqv5461 -> tool:dsh:lead:call_00_iNUqdLLJr8nLg6uTW2zM1970 -> tool:dsh:lead:call_00_iVz3aVDSYGUe9YocC5Bk3697 -> tool:dsh:lead:call_00_bzNAPnTE5Xjs2aLr1afc3231 -> tool:dsh:lead:call_00_Ig74fVHTOxhGLJE1k6cS5364 -> tool:dsh:lead:call_00_ZWfZbdGHGsxh4s4MYZgg4169 -> tool:dsh:lead:call_00_NoI6cOL2TbIL6cwb36m73543 -> tool:dsh:lead:call_00_IwMNVDPAs4KbKiElFQq17416 -> tool:dsh:lead:call_00_rnNpSk3uhTQqjxaXKOhh4586 -> tool:dsh:lead:call_01_lCpdrjcufFLNn17nQP2D8005 -> tool:dsh:lead:call_02_GqlKln6epuCRuTsjW2ha5794 -> tool:dsh:lead:call_00_fw24VSoYf5cALzeJ0bb12057 -> tool:dsh:lead:call_01_jvcFE2LTXXjxuL3G3RNl6750 -> tool:dsh:lead:call_02_flVJ8yKlOEqrO8QXqhl66452 -> tool:dsh:lead:call_03_ULnyXyYgciYmbv0yASbZ0033 -> tool:dsh:lead:call_04_s9RYkkf31OivylBczarG5373 -> tool:dsh:lead:call_05_wxxTlny5Sbzc1nbNhaDk8031 -> tool:dsh:lead:call_06_ct6NWTUth1JWa0goXBHj8932 -> tool:dsh:lead:call_07_4ecJ3Mg1jXjvhsMh6FC68487 -> tool:dsh:lead:call_08_IP1KTc6Q0mpFJZcIfD9G6489 -> tool:dsh:lead:call_00_LpIbbg79oor0oeaUF5ha0596 -> tool:dsh:lead:call_01_DjBbltnc5O9UiCUzFzFT6650 -> tool:dsh:lead:call_02_89Q1TX7vBCVlQS5OuhmG5046 -> tool:dsh:lead:call_03_CKJbkZSeQQbc0TOlTSUn9662 -> tool:dsh:lead:call_00_1PeREwXRJp49UIDvg2ri9015 -> tool:dsh:lead:call_01_BWQnd68HwQRT5TfANF3F5910 -> tool:dsh:lead:call_02_aftCaCKiC66nIP9SvPGK7574 -> tool:dsh:lead:call_03_Yio6LuSvVIdAH3Mqhnuh5276 -> tool:dsh:lead:call_00_QuXbn4MEI0goBFojKEMb2725 -> tool:dsh:lead:call_00_vkj3SoIkcvB9rx9Teb0J2214 -> tool:dsh:lead:call_00_cQ2KzNekvQbl1btypqH86627 -> tool:dsh:lead:call_00_xwurh1k8HbxeuX8nG6Vh8377 -> tool:dsh:lead:call_00_rBC5re6GFUkKFBNqoMRL5685 -> tool:dsh:lead:call_00_4nKIsSe50l2uUI1mQSIh2851 -> tool:dsh:lead:call_00_46VUGN7d44aS0bXQph0V6312 -> tool:dsh:lead:call_01_IjrhaKvop5xEyDw6iMAb4455 -> tool:dsh:lead:call_00_4O9JxoLcMcc72MQTBSHm3269 -> tool:dsh:lead:call_00_s84RkkZ2YbSm1XX2CpTP5645 -> tool:dsh:lead:call_00_IY2r3YV46sGS4Glreaya2790 -> tool:dsh:lead:call_00_iFEyMO4A7JKDiZOoxXiq4581 -> tool:dsh:lead:call_00_sAVIWqBKXRbPFKoLaboN6459 -> tool:dsh:lead:call_00_BnA0eojfpMBLhO7x5tNU5039 -> tool:dsh:lead:call_00_eZkXqtytOveChpfaIW9J1762 -> tool:dsh:lead:call_00_vRpSSXeMbidLqYhKbVDN3783 -> tool:dsh:lead:call_00_pAoABKZK2lskvamaHQ2c0089 -> tool:dsh:lead:call_00_dTo8FirpJSV7WqTiXHdq9074
- 关键路径耗时：1.277
- Makespan：228.697
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
