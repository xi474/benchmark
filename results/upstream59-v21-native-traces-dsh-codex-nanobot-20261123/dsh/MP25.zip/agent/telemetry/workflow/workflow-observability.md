# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP25__vj4q8TR__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_SypNyRwWTL1dI3cXPwh55279 -> tool:dsh:lead:call_01_m3DmrIswKjxrWxHM6snl5163 -> tool:dsh:lead:call_00_M8Xf408nWdLyfcgP98WL4006 -> tool:dsh:lead:call_00_X2rq6VySTtgTBhvS9dZz1638 -> tool:dsh:lead:call_00_1sAyUNEnYhBVsNpyxxiX4637 -> tool:dsh:lead:call_00_JR2bNAqjzQWLa2cwZGSU0770 -> tool:dsh:lead:call_00_du6jXWNKqgVYyd4ySanM2191 -> tool:dsh:lead:call_00_aFWomX8Z2I2zPJJrZzz66964 -> tool:dsh:lead:call_01_w7F7pSKcUcd8736qcAwC0718 -> tool:dsh:lead:call_02_v7cNLElbMhVzj1QV4SMe6566 -> tool:dsh:lead:call_00_pECq4J6wxo4pny3Dy5430643 -> tool:dsh:lead:call_01_9vBOyE9ePRHsCNrWLTdO2399 -> tool:dsh:lead:call_02_5etoBOlMSTMTWfCUC5Kp2092 -> tool:dsh:lead:call_03_JeBtMV1RDzmyxu9WrMZE9117 -> tool:dsh:lead:call_04_Btd6sj9fzpts9Lh2UaAr7712 -> tool:dsh:lead:call_05_Ks1OssuqmblgcCrHrZK69918 -> tool:dsh:lead:call_06_7NN2nhubvZlSxU3OwW4s8742 -> tool:dsh:lead:call_07_2lEtvNl6D55DRmjlX0Mk3368 -> tool:dsh:lead:call_08_o69qz5vUfXgFkvYpoDJR1551 -> tool:dsh:lead:call_09_mCw0My6wwCFyLBfU0eJ56624 -> tool:dsh:lead:call_10_cp1muqp3FlcdyuL2eYTX3981 -> tool:dsh:lead:call_00_Jhy8bNQKVEvEl65XRtWd7867 -> tool:dsh:lead:call_01_4rS4XrMQPyJIWcd5donU2967 -> tool:dsh:lead:call_02_nm613CcAiwTTFMGUjaX74352 -> tool:dsh:lead:call_00_jbte6y4C1fIkBgGRv3sA6498 -> tool:dsh:lead:call_01_gMYWEUpCoyu5slD7H1d74365 -> tool:dsh:lead:call_02_dQS4vmyNXIcUzkDubawV6278 -> tool:dsh:lead:call_00_Tl3kWtuANeNdayjLH8un5097 -> tool:dsh:lead:call_01_zua1yv73sadI5pn6PM6H8936 -> tool:dsh:lead:call_02_FTrzigR6o83oqcdj8s213877 -> tool:dsh:lead:call_00_3RifuX3FYhYf5qp44pQi8081 -> tool:dsh:lead:call_01_gyQ7hK06E2EfIckLY7Je4227 -> tool:dsh:lead:call_00_V6AXlAKhYpbIe56BHFnQ7302 -> tool:dsh:lead:call_01_XbwRsrmh1bU4d74mTlT88579 -> tool:dsh:lead:call_00_8Oe1hM8qGRd6LT01Ob7W7084 -> tool:dsh:lead:call_00_BIHQTVIQlmt6uxtTMwNK4007 -> tool:dsh:lead:call_00_JTuVJsA5laLtmRSU8bEZ1473 -> tool:dsh:lead:call_00_gJSmdSvlTFqhlnJ8dniP2367 -> tool:dsh:lead:call_00_Uzbq4d8noAuukRt0Xvmw2362 -> tool:dsh:lead:call_00_jonWxDQzCWqdcoItOWb25738
- 关键路径耗时：1.288
- Makespan：658.938
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
