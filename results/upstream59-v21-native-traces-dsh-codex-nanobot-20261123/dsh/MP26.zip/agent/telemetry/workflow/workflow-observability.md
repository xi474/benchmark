# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP26__8x9PBQx__env`
- Task：`unknown`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（62 节点 / 61 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：62；执行边：61（observed=0，inferred=61）
- Execution Trace Graph：`observed`；temporal_next 边 61，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Qo4f5ZhlqQDyv9BaJ6um8816 -> tool:dsh:lead:call_00_2kg0F3J1FxuUtQxhgq3d2320 -> tool:dsh:lead:call_00_b28dkzDiHWjXmHTTOwH24453 -> tool:dsh:lead:call_00_5I3G8NHJ3orsCbLNwVPu5709 -> tool:dsh:lead:call_00_3SGSaM8MAD8qDQx6CvGC8777 -> tool:dsh:lead:call_00_SFfL7XNEt2lzJXCEPtyO4183 -> tool:dsh:lead:call_00_fNX8HfSBwKWFv1fvTTyp1401 -> tool:dsh:lead:call_00_o9fApyADPfk7NPnvlOZM3217 -> tool:dsh:lead:call_00_nY1Y3h0YQEkqUnT1EAJG4691 -> tool:dsh:lead:call_00_oElN4ui48RAR9lQmyUNH4963 -> tool:dsh:lead:call_00_VwElXRseQzMLJRDrjv815164 -> tool:dsh:lead:call_00_IcnpOHuqBefxOhIkDuOw9808 -> tool:dsh:lead:call_00_zRFvQCY8dLEV5givg5Rq9435 -> tool:dsh:lead:call_00_8WYbwULddSJpzDXxLNk22259 -> tool:dsh:lead:call_00_5Uibdbbr66TTSsVd9Dk72621 -> tool:dsh:lead:call_01_Hcc79EbBMTfsRsFtxY2r8983 -> tool:dsh:lead:call_02_knnuXKcpFhrGbPnpVfQc4761 -> tool:dsh:lead:call_03_ebbZf2n3Xabd0JQqYvy51222 -> tool:dsh:lead:call_04_ywINzLU8FI4yc5qV4Kuw7965 -> tool:dsh:lead:call_05_aScXote4aQwHmm4HJM5p0796 -> tool:dsh:lead:call_06_3hgQFjTJfQ3M4wLKFI351715 -> tool:dsh:lead:call_07_X6u95ZMJX7TKHA0nQuFE8419 -> tool:dsh:lead:call_08_wWkvwlWD4jQyZBvinJbK6357 -> tool:dsh:lead:call_09_cBJhDXCN4xUE7DCsGq8T3369 -> tool:dsh:lead:call_10_Vj9O8SXVIIuRvfRkAumW0508 -> tool:dsh:lead:call_11_NwGcg7hmJHpWcFWb6MZh2683 -> tool:dsh:lead:call_12_duaqRcvKyAaZxr50slKD4916 -> tool:dsh:lead:call_13_wrJunA4GeHl4OtzhOIRg2880 -> tool:dsh:lead:call_14_fS9gMA4ltavxie12XYsJ7270 -> tool:dsh:lead:call_15_hHT8msPUVsuPgVrllMrE4889 -> tool:dsh:lead:call_00_QRyRd6q9YsGimA3CG5Uc8085 -> tool:dsh:lead:call_00_Ttm5qfTLlCyDoM7GpFOx6951 -> tool:dsh:lead:call_00_M68ELZFHcPOVuq8PJvMB4937 -> tool:dsh:lead:call_01_zZ5m1OB3qlrciM1PfdKO3075 -> tool:dsh:lead:call_02_7zPPuW9ngcZU5A0KlP7Q3699 -> tool:dsh:lead:call_03_2qd4mULF7Ic0JGC0AUlu7982 -> tool:dsh:lead:call_04_LKPNW5HdviAFmajnNG9U9023 -> tool:dsh:lead:call_00_XVz3pGMtfaxuitC5Zfv95512 -> tool:dsh:lead:call_01_YsU6vBW4KVOUKQVkUcv90785 -> tool:dsh:lead:call_00_wnAqATIJjesG0mGf5Yv51086 -> tool:dsh:lead:call_01_gLAjccn9KlzpVeG0d9dE4733 -> tool:dsh:lead:call_02_KxGicNzXD5ceOy6hBFQY4077 -> tool:dsh:lead:call_00_AOp9tzwdgQl0Iduzq8Xz1064 -> tool:dsh:lead:call_01_L2svQd8um46mXmtLHfr26790 -> tool:dsh:lead:call_02_twrOaHGvVLHxOVC2tU1r6971 -> tool:dsh:lead:call_03_TiCgpeiMM0S4Yb3jMJqf8306 -> tool:dsh:lead:call_04_2mXFwtXE8yF1JC1NgJqy6691 -> tool:dsh:lead:call_00_jO6bWhOYliWuZFzXu8In0604 -> tool:dsh:lead:call_01_0DrRtC5gblvicTRWlcSB1864 -> tool:dsh:lead:call_00_lfWr7hOkOIxrbV7tGrzT4486 -> tool:dsh:lead:call_00_8032Ia66rfgFzVyFfENv6397 -> tool:dsh:lead:call_00_8ImXi1GMPxwA0IVerMZt6592 -> tool:dsh:lead:call_00_jv3Cgki4LTQl8Otfu9959427 -> tool:dsh:lead:call_00_lPtRVseuJKXHp4AcALmj1350 -> tool:dsh:lead:call_00_bJgKXFZAVxlsr0o8A2Cl0469 -> tool:dsh:lead:call_00_d1YYLYTQJ5ucwjntw3lC8574 -> tool:dsh:lead:call_00_V7N4dSgNeLKYWs3kx9DG2079 -> tool:dsh:lead:call_00_XLUTvQXMmwXAiDWlzMex5805 -> tool:dsh:lead:call_00_AomJm4Dd0zg7QO6Q8GNy3324 -> tool:dsh:lead:call_00_E6vDU4ryIfvMzioGYa8G5314 -> tool:dsh:lead:call_00_URf6JYyvykH09bLxQ0D55516
- 关键路径耗时：1.958
- Makespan：588.851
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
