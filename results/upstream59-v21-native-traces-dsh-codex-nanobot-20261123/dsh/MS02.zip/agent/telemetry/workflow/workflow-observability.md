# Workflow 可观测性报告

- Trial：`MS02__e7j9JiR__env`
- Task：`MS02`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_cfyKQuxLQsI4L2b7Uja43706 -> tool:dsh:lead:call_00_xw5UgInXK3KiIpv9nWc29562 -> tool:dsh:lead:call_01_MiabZuvCF1WIhFDZheYm6909 -> tool:dsh:lead:call_02_lreHoQ189CuUbwFCco7b4998 -> tool:dsh:lead:call_03_WHjQhBae3CJ5doKEYABL5814 -> tool:dsh:lead:call_04_03Rb2z6Caj7ldH9kLvWV3414 -> tool:dsh:lead:call_05_aOrEpHz7Lq0RGAqORy8s5708 -> tool:dsh:lead:call_06_VuIz3BVilptnVMMIulPH0356 -> tool:dsh:lead:call_00_IqUXCG4a8x4aJeewDjH98781 -> tool:dsh:lead:call_01_y0Dsj7y6rXREACiiK8C24532 -> tool:dsh:lead:call_02_5XamKGUjJoal2vsEhATJ5993 -> tool:dsh:lead:call_03_2IPXpJyZNVJv2Xn23KtI6089 -> tool:dsh:lead:call_04_SOFdWqvyeMlA2XXiWR9L6650 -> tool:dsh:lead:call_05_dOGb8PyKRRYd4oLzKkoC3003 -> tool:dsh:lead:call_06_jIAQKcP4UIPAp6Dcp5S42996 -> tool:dsh:lead:call_07_0P1xFSfiN2tWwTQ2W6Mo5501 -> tool:dsh:lead:call_08_uVn3qE2HccmXgyR6FEsJ6246 -> tool:dsh:lead:call_09_DfdoAWxA0As7Hof7kaL24738 -> tool:dsh:lead:call_10_OSOXbVeBxOqpBsJu4owQ2309 -> tool:dsh:lead:call_11_qJLPQKtXxNVvJGy759Qa6142 -> tool:dsh:lead:call_12_upyjRR0qX3vbG5CGCXUi8670 -> tool:dsh:lead:call_13_TItvDX5PPlyyYWVyYXOw2485 -> tool:dsh:lead:call_14_5JDtTP9VMxyBC9DIiNoA5506 -> tool:dsh:lead:call_15_UwTzdVYjoAum6m7lg82L1840 -> tool:dsh:lead:call_00_Jmg8Ew7IWgXaM9PL838s1139 -> tool:dsh:lead:call_00_COTezLx5YURRbprrSaNj7269 -> tool:dsh:lead:call_01_D1A0y4Ewekro0rafyDtp6239 -> tool:dsh:lead:call_00_X1D5au4wzE1ONys89HRc9580 -> tool:dsh:lead:call_00_KZcEGw8h2FLQnQuzjxPB9203 -> tool:dsh:lead:call_00_5YA5dRa9334YHYyBfaXw2518 -> tool:dsh:lead:call_00_BBDOq4LMKlXxM8sZqkIk4746 -> tool:dsh:lead:call_00_k930ncCG27VxbxEBPrYB7740 -> tool:dsh:lead:call_00_0ZcIBZgFuH8KxMntrbW47116 -> tool:dsh:lead:call_00_DVfaneAEl3MSf6kD5fIU2921 -> tool:dsh:lead:call_00_jd2mcbWfpvNVgikziX5Y5456 -> tool:dsh:lead:call_00_7jXUKx6CIhbYxa0mt3RW5714 -> tool:dsh:lead:call_00_mBGYt1Evap7cufBgbxD58256 -> tool:dsh:lead:call_00_gV1qhdKtdkgpCuJylFMZ3734 -> tool:dsh:lead:call_00_RYlQAO28r8K5lgwPByfy2615 -> tool:dsh:lead:call_00_VuXibViznozNqeC7tDvM9583 -> tool:dsh:lead:call_00_5Le2xJ7I5Zk0WBlhxwm73555
- 关键路径耗时：1.381
- Makespan：160.796
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
