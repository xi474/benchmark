# Workflow 可观测性报告

- Trial：`MS11__4EcjotE__env`
- Task：`MS11`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（55 节点 / 54 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：55；执行边：54（observed=0，inferred=54）
- Execution Trace Graph：`observed`；temporal_next 边 54，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_AbUoJHlRegvXWlXwmUvK9525 -> tool:dsh:lead:call_01_IAy8D3c3K1XQphafPuLx6736 -> tool:dsh:lead:call_00_TNwEs1TsNjW0hl2QMtdp3983 -> tool:dsh:lead:call_01_UWceCYunIhwCUadZR1Gp4665 -> tool:dsh:lead:call_02_gEdZOjCi9Em71JR9GQJ05507 -> tool:dsh:lead:call_03_HDbl12En4DhKLzRVOXk86270 -> tool:dsh:lead:call_04_m4GJkMW9xRHSwv0qzpXX0030 -> tool:dsh:lead:call_05_EBZuWBTFipJuGxdIC5Yg0766 -> tool:dsh:lead:call_06_PwLWywlF5DYsdLmai0Fu5108 -> tool:dsh:lead:call_07_FuHC17t01VzZrFwWtXt75684 -> tool:dsh:lead:call_08_VMNEGaBCSN4RpQsVXMaM9975 -> tool:dsh:lead:call_09_mV3sRZbCXiitrTXksVIq8992 -> tool:dsh:lead:call_00_zbJeTf9FgAZ9psOFL9nu1241 -> tool:dsh:lead:call_00_snHRUVZUEKeybFYl0vo53133 -> tool:dsh:lead:call_01_Lbaz2Z7rvMk3S3xzD3IT4841 -> tool:dsh:lead:call_00_VIjzT2NwktEH45FsMgIv9021 -> tool:dsh:lead:call_00_U23huSJupjNEDm7Eal6k9447 -> tool:dsh:lead:call_01_3CJ35a3bKEqbnuaPnCpV8438 -> tool:dsh:lead:call_00_w9KlTzW165zXCbwkmO1Z4285 -> tool:dsh:lead:call_01_qLytuBcTI3pG0BuBaoqU6633 -> tool:dsh:lead:call_00_VnupVVsivqnDUx50TOCm4483 -> tool:dsh:lead:call_01_ijOUouzTCvy7D0l9G0fa3767 -> tool:dsh:lead:call_00_u1srZucmGpd04m3fzuRG4342 -> tool:dsh:lead:call_00_34NfOU1vp09l6EVejrLY5154 -> tool:dsh:lead:call_00_R8pISwb2EBywPzqemLnh2016 -> tool:dsh:lead:call_00_hRK6ifBhMWdo7vrIg6r31484 -> tool:dsh:lead:call_00_BtnqbE62yaDVSFnBgGgV6197 -> tool:dsh:lead:call_00_J1sCWcyMcj7BPuTiZrcY3938 -> tool:dsh:lead:call_00_TNTMmz3i4pIrQZmxJLpO7434 -> tool:dsh:lead:call_00_jKgQEf7RdXXiGrTHjii64408 -> tool:dsh:lead:call_00_9LF0cyMK1c2PAIxOzp4f1341 -> tool:dsh:lead:call_00_jklz8lyjriQJyoezXcco9775 -> tool:dsh:lead:call_00_vZIzoVYCqyd7njOIECjL4556 -> tool:dsh:lead:call_00_R5UdN5dxAKyU3FUuc7u46104 -> tool:dsh:lead:call_00_Bf1EfjbgfMexxOU7mrMS3011 -> tool:dsh:lead:call_00_jW17yDfy1gLE8oi7QE3v9982 -> tool:dsh:lead:call_00_pki8FkQXexcxsf5xAJhk5294 -> tool:dsh:lead:call_00_NSJIHAOe1AJw34VXh2Z12200 -> tool:dsh:lead:call_00_mATIgpvm2lxOSX6jQTcu1497 -> tool:dsh:lead:call_00_juR0BVUjDRufHi44pLxP5095 -> tool:dsh:lead:call_00_EX9elBKbSCQ3npBpRupQ3035 -> tool:dsh:lead:call_00_2gy8VMxd42fribuU0q7q3866 -> tool:dsh:lead:call_00_NSQp2r16i0wGdqnpiq3d0648 -> tool:dsh:lead:call_00_TYVhsPz0WdldcslX5ArD2005 -> tool:dsh:lead:call_00_gnyiF7Qq0VyBs4fsUP6J2415 -> tool:dsh:lead:call_00_N7GSLAzj2CJY3hxOXUqR5533 -> tool:dsh:lead:call_00_lAUy77S5ymCJNZyJSSOm3017 -> tool:dsh:lead:call_00_JUlqmzRl3xFkBIEQI8MR3765 -> tool:dsh:lead:call_00_Z1bILiSXNte3D8ZHi7mi3867 -> tool:dsh:lead:call_00_VntfIdHeXvFTIti0GlP84119 -> tool:dsh:lead:call_00_6DrU3ozyz4OA1QyrEQYE3367 -> tool:dsh:lead:call_00_pT2bBsWZjBwYwQVjUlzl5411 -> tool:dsh:lead:call_00_3NBlZnW8MLgaBVUCmOH66582 -> tool:dsh:lead:call_00_04ug2ilwkaUK22nDiFbr2201
- 关键路径耗时：8.724
- Makespan：886.383
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
