# Workflow 可观测性报告

- Trial：`MS12__ViFnVZb__env`
- Task：`MS12`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_J7OpjMBLgErUoqDSHfpc6698 -> tool:dsh:lead:call_01_1yNxUqn7xWUvoHHeYiPR8730 -> tool:dsh:lead:call_00_C9LYIjMJYV86H3IDCXbv2144 -> tool:dsh:lead:call_01_7rej3vmDku15eP6rtEil5031 -> tool:dsh:lead:call_02_XPNbd9jPLA7uWOw0q0Cq8072 -> tool:dsh:lead:call_03_9qrJvma6U3Caub9Bz0jn9125 -> tool:dsh:lead:call_04_Ihw5ewo0VfnmmseFJwNd3564 -> tool:dsh:lead:call_05_3CANxgk8m3p0jEfRhtEu1472 -> tool:dsh:lead:call_06_oi7FqvHPcViBq3kP84nb2271 -> tool:dsh:lead:call_07_fhlljvNQpWEsu7Rwpk6f6053 -> tool:dsh:lead:call_08_TFyJSOdfbdlisKmYW1349491 -> tool:dsh:lead:call_09_1vmSRhjK6gNio2UlnfKo6222 -> tool:dsh:lead:call_00_xfpeOnmBXl4H1OJYb6n45024 -> tool:dsh:lead:call_00_5dgXFXzfvSzlGZEEPdH59128 -> tool:dsh:lead:call_00_2osPGm2XJhnlKp1WCD4D1478 -> tool:dsh:lead:call_01_23VKmcddr7kKnb0pvQjw1092 -> tool:dsh:lead:call_00_CWILqG6FPRCYaKfanGHQ9711 -> tool:dsh:lead:call_01_pMmqa3LvfO8kLo3ay4722264 -> tool:dsh:lead:call_00_LqBrqsnBob2o1xKUooKW7317 -> tool:dsh:lead:call_01_7DiuwJYe6SJETDFAzUR04018 -> tool:dsh:lead:call_00_DVOWaaPcBSVlLjHwW2NF4218 -> tool:dsh:lead:call_00_n8EqfVh8DhK2TT8Ef0kt1857 -> tool:dsh:lead:call_00_rzXLMm6oEAXcOJA97f8s7373 -> tool:dsh:lead:call_00_SsHtbDDmKAZaeG6MMUIX8873 -> tool:dsh:lead:call_00_DUfL30u3EKHot6PVefIr0947 -> tool:dsh:lead:call_00_VEBa4puDLLhWM2cGTEfI7036 -> tool:dsh:lead:call_00_cVBc9iwtRrHWD4zCk3ym7172 -> tool:dsh:lead:call_00_VqMa6yS0pWgYFbUF0Nm85579 -> tool:dsh:lead:call_00_0ltkutcHbDI5heHwmrwr3766 -> tool:dsh:lead:call_00_LVlwLyBD8d5BkmXZY6PX0752 -> tool:dsh:lead:call_00_6iHNsGQbQ6S5OWY8YuJv7533 -> tool:dsh:lead:call_00_g7EHDzl4yBTDAwgzYQS67142 -> tool:dsh:lead:call_00_80cB8NhAYiRQ3VG3gxFI0736 -> tool:dsh:lead:call_00_eSNSzy3xqkKLfhmh42aL0191 -> tool:dsh:lead:call_00_mAiSJijS4dDlQ29SqDsA0123 -> tool:dsh:lead:call_00_si5HhvjTwHtWrcFu7Idl8567 -> tool:dsh:lead:call_00_5ID6sxbZ0idFrCvhmAVP7811
- 关键路径耗时：1.255
- Makespan：557.835
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
