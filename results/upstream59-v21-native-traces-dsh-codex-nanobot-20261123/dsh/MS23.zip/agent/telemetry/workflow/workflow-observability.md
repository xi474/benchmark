# Workflow 可观测性报告

- Trial：`MS23__3nLLjT6__env`
- Task：`MS23`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（48 节点 / 47 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：48；执行边：47（observed=0，inferred=47）
- Execution Trace Graph：`observed`；temporal_next 边 47，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_NsU5X8zHEglu9tHAs9gY6189 -> tool:dsh:lead:call_01_PZpAbHYOkb5oCPcDbO3r0053 -> tool:dsh:lead:call_00_Y9qcBtMHUowvLNAYrGcY6403 -> tool:dsh:lead:call_01_m33eP6Gu5LRqWVkNlWpK0180 -> tool:dsh:lead:call_02_y1SMlyMeHjHraFx0jW6x8068 -> tool:dsh:lead:call_03_k3c4UtGD3j55lOO3pI7E4285 -> tool:dsh:lead:call_04_KuocMPfIHi8AT018IVUY0453 -> tool:dsh:lead:call_05_JIxv0UX54OMHKLhAoij44815 -> tool:dsh:lead:call_06_BKN9dTWiEDJJanvWkrsG0570 -> tool:dsh:lead:call_07_Z7JUM2d9FBkiEE7ldQ1G0645 -> tool:dsh:lead:call_00_sb95YkJPjKkl7wVd5qd92016 -> tool:dsh:lead:call_01_yANeSQsVTj31kHKcqzSz9019 -> tool:dsh:lead:call_02_A27uJaRfk37rk38LpqqO7825 -> tool:dsh:lead:call_03_WNOMncLC6T7ewWH1l8xz9225 -> tool:dsh:lead:call_04_44VFCoKWrCivUwoUUWba3969 -> tool:dsh:lead:call_05_eio1ny9bbC6YlR1RUaXi8671 -> tool:dsh:lead:call_00_wq2f6BGB8nXIUrTDQ5qL6594 -> tool:dsh:lead:call_00_NBusZo69EFJpl1PQDW9B8639 -> tool:dsh:lead:call_01_90OhhKZGsaaQFZk7qw5x1613 -> tool:dsh:lead:call_00_uz04sk5Ag646dUd8Qwun4020 -> tool:dsh:lead:call_00_zwNqDZ1y7fB7ZOuDc8yf6754 -> tool:dsh:lead:call_00_gf5oa6ILWDreqQ4m6dDa5380 -> tool:dsh:lead:call_00_ckTZvnhT43ZEvfyIV3Kb0699 -> tool:dsh:lead:call_00_IBlFkqO6hQ53jl512ZkP7119 -> tool:dsh:lead:call_00_fDEyPVmnVOkDtpnKxTCH7568 -> tool:dsh:lead:call_00_5f6Oa33Qha8eq5ss0HcX5887 -> tool:dsh:lead:call_00_DUXAotIvtzWR4chOwvVc0186 -> tool:dsh:lead:call_00_5XAkP7W1KkBjOG6mtmZl5901 -> tool:dsh:lead:call_00_PDFn2IDRw3YO3GYMx4OK3650 -> tool:dsh:lead:call_00_wiouTcE6dscDYTIkbGcD9154 -> tool:dsh:lead:call_00_bZifEwD3VbHwrDEF3iIF8946 -> tool:dsh:lead:call_00_0kLWpMvfuTL8TcZs3Qeu8071 -> tool:dsh:lead:call_00_fZhnHP6xvUK1aIFl3Gsz7946 -> tool:dsh:lead:call_00_Y6hnQ0CjvmKMBN3d6KvG9949 -> tool:dsh:lead:call_00_iki5luIOIapljwFzQX439695 -> tool:dsh:lead:call_00_0DZ8zSrG0mFYDpwVPtAE2317 -> tool:dsh:lead:call_00_Y9Y6rJZ9UHJVFLlTtrm08565 -> tool:dsh:lead:call_00_XbDQ6b3o08vo0p2fbG594531 -> tool:dsh:lead:call_00_665pdPQbKn1BiDhLHsNu7645 -> tool:dsh:lead:call_00_2DujCZ8f7osYx7L5zg0M8588 -> tool:dsh:lead:call_00_Y8ewXXX2Odc03P8l0ODb3888 -> tool:dsh:lead:call_00_w3zs82Y0wF3pn9Uhjjgu3594 -> tool:dsh:lead:call_00_ojmuRjVeOT2NtfEgLA7m7608 -> tool:dsh:lead:call_00_9qiReIWkLqDksnaqZ9DX3083 -> tool:dsh:lead:call_00_AOyqb3CVVk9JMxc9u2dc7736 -> tool:dsh:lead:call_00_ForQ4X7tr9j9UQnNlVJ27837 -> tool:dsh:lead:call_00_KMH66XFIZdlThfHXTm883155
- 关键路径耗时：94.277
- Makespan：643.055
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
