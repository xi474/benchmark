# Workflow 可观测性报告

- Trial：`MS28__CQkXFV3__env`
- Task：`MS28`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_5ApUVXykwXn0NMzvl2Sw7506 -> tool:dsh:lead:call_00_gRwUWSWfiRxQSXS77Iwd9930 -> tool:dsh:lead:call_00_WbMhcHyo6Hi2xP9CU82n2342 -> tool:dsh:lead:call_00_6d20q3ESNVVWkyzOhGu46158 -> tool:dsh:lead:call_00_Jg8O0GlEDStMxmbmr4D06368 -> tool:dsh:lead:call_00_Pq0gYMDYxrIR3SOLTVrK1081 -> tool:dsh:lead:call_00_mCCOD7BvWe4uIrtOgR6t2916 -> tool:dsh:lead:call_00_0ieY7M63b7F3HRw6qeph6354 -> tool:dsh:lead:call_01_AemS0u7Yi2zpK8sX5qxv7723 -> tool:dsh:lead:call_00_oLsTMxWfcgxAET912aOd2611 -> tool:dsh:lead:call_01_3ffKnzkvBn8kpI9vFq2h7301 -> tool:dsh:lead:call_00_WvhHe01ESyFBm7lvPRf77740 -> tool:dsh:lead:call_00_HDa8iJMFsmmMG7ngXX5G2596 -> tool:dsh:lead:call_00_m0Z3C1LSGHOeFGtzUzzG6190 -> tool:dsh:lead:call_00_G9qJY1YJgcsro0xCFoMr2398 -> tool:dsh:lead:call_00_2lJfNhGjTiHNtcVHqDfF6935 -> tool:dsh:lead:call_00_J481MfUe5GIBzxYJ6Kql6896 -> tool:dsh:lead:call_00_wccKYZPkyjumrZTPpnxs9902 -> tool:dsh:lead:call_00_SiVxLYdGTcuBu3haifO81391 -> tool:dsh:lead:call_00_6CYZgvuIrATHAL6wRW0A3505 -> tool:dsh:lead:call_00_xt4ixjlSG3AX5rUggtme3490 -> tool:dsh:lead:call_00_8FBMaOWKFT2LHhP5WrZI0598 -> tool:dsh:lead:call_00_60TDChdJglpo3k9LjCrv4821 -> tool:dsh:lead:call_00_ubB6nU4ASpT1eBaOmK3a8232 -> tool:dsh:lead:call_00_wBB2DOSEJBngj8nDOfvk4512 -> tool:dsh:lead:call_00_gZyQSsV59SHvNa8gkZm76169 -> tool:dsh:lead:call_00_2skYfWx8V0ZRz8wm25Fe9591
- 关键路径耗时：1.086
- Makespan：271.001
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
