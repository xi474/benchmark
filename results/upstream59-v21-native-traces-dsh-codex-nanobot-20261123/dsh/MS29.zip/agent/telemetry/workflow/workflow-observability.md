# Workflow 可观测性报告

- Trial：`MS29__2QVcEaG__env`
- Task：`MS29`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_H5rEAHAtMSlWrmTyFlth3313 -> tool:dsh:lead:call_00_BABxS2RcjavC4BGoYndv9651 -> tool:dsh:lead:call_00_nHVU3zIkAidYpqw48Hhp2237 -> tool:dsh:lead:call_00_S0wNXjRkDRPcwmAbFBjY9107 -> tool:dsh:lead:call_00_IwApV8pUcb6SJT5u2Ft66317 -> tool:dsh:lead:call_00_Xg1kdrboyDyU5nD45Lx75069 -> tool:dsh:lead:call_00_k6vCpK9oKhQq2Yrlh3r86733 -> tool:dsh:lead:call_01_b1LjUZwsh4BfbQKAzvp06586 -> tool:dsh:lead:call_00_FTQmJ599amBt1fKq3jiU4240 -> tool:dsh:lead:call_01_y3YZ61SXJ7uLS5OcphM95396 -> tool:dsh:lead:call_02_UrHfAPy0xOd41jTgVCOC6027 -> tool:dsh:lead:call_00_bMJ1dUVB5v8wML437F6r1061 -> tool:dsh:lead:call_01_YV5bEP4jMuQWb4EczMTs6279 -> tool:dsh:lead:call_00_qUEP2RebxwpbrMDMZsYy8938 -> tool:dsh:lead:call_00_XLCl5pkPPNTQr9XyAUlK3884 -> tool:dsh:lead:call_00_4GWCVQVJAc2t6nil6Je51163 -> tool:dsh:lead:call_00_Ot8lDYYDDUybfj51o9Sz8061 -> tool:dsh:lead:call_00_R0GqM31Dj2QGZccL2QyL1034 -> tool:dsh:lead:call_00_aRUXmISdPJUj9ahxGgEr4509 -> tool:dsh:lead:call_00_DsA9t6zHeG789kHFFqDW0614 -> tool:dsh:lead:call_00_7WI955f3PBS2yXZBud9H3475 -> tool:dsh:lead:call_00_HIyyRihvtDvCEq4RXJY68392 -> tool:dsh:lead:call_00_dqn7aQphiZ5OCYYERu9A3832
- 关键路径耗时：0.879
- Makespan：318.781
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
