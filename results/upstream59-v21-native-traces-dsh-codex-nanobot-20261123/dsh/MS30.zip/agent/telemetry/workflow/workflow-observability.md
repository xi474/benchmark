# Workflow 可观测性报告

- Trial：`MS30__ZgrfDu6__env`
- Task：`MS30`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_YjRFTNQf0TFiKBhMzdbS9491 -> tool:dsh:lead:call_01_68cmV4KzZcuZFTkwTpz28835 -> tool:dsh:lead:call_00_stYmivbJHtKMKLz4nHB17656 -> tool:dsh:lead:call_01_QZpHEazoaa5a7H6w9W202208 -> tool:dsh:lead:call_00_Xstui33HSvU9mcoIjwya6920 -> tool:dsh:lead:call_01_MCjBxJACuWjn7qcBt57a0679 -> tool:dsh:lead:call_00_9ttcY9aMDAy7S6Q8sQm26171 -> tool:dsh:lead:call_00_pyQrYgcMuyrdiAdO7tDH9700 -> tool:dsh:lead:call_01_G4fiBjXXwjOE1cInWc2v1251 -> tool:dsh:lead:call_00_jcTFo7Ix9GcxOPPy2f4T4848 -> tool:dsh:lead:call_01_M4YVh62fzc0Yc8LK1PCR3459 -> tool:dsh:lead:call_02_DDLpiv4WF6SoC7KPasdP0630 -> tool:dsh:lead:call_00_j66mJ44NzWPqyjCfB3yH2323 -> tool:dsh:lead:call_01_7YFEVmNDcoIadeYbTfEc6810 -> tool:dsh:lead:call_00_59DGEty32K3cHOZmtdMp0293 -> tool:dsh:lead:call_00_IbmPSNcMTknUSDynB0FR8317 -> tool:dsh:lead:call_00_Wuuivdq3te2secRHhUuJ7278 -> tool:dsh:lead:call_00_YI6qXqU2QezselyF1rqR0863 -> tool:dsh:lead:call_00_28jgHnbV6LyInp47EA3o0710 -> tool:dsh:lead:call_00_fPgxuIok6MK98wKuP3F34155 -> tool:dsh:lead:call_00_O7m6GpPElHqFp7LO1TUD7008 -> tool:dsh:lead:call_00_ihyLHeegTwItb0Vqfmmp6163 -> tool:dsh:lead:call_00_NX70rkfBhV9PQpkIdAdx0194 -> tool:dsh:lead:call_00_FYZ74fS4gQsG7tqi4Rfz9986 -> tool:dsh:lead:call_00_Fioe5OHl8crbGOdMAu7N1731 -> tool:dsh:lead:call_00_NWui9vhDxvti1WDFwgpS3239 -> tool:dsh:lead:call_00_aj9iwb7VFSw6ea5DevIT7627
- 关键路径耗时：0.944
- Makespan：326.391
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
