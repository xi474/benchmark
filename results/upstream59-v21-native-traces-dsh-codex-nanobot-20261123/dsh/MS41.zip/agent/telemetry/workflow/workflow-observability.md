# Workflow 可观测性报告

- Trial：`MS41__p8TTqnP__env`
- Task：`MS41`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_vxpkNe0r1nHLFOsEY3a80813 -> tool:dsh:lead:call_00_JOTpIRoaHIQvnsEhYlNl9800 -> tool:dsh:lead:call_00_7QmPSpYrLrfrObHUesDT7080 -> tool:dsh:lead:call_00_dhEyZ7kP7r45cwK4TWCl1733 -> tool:dsh:lead:call_00_gePD9srL0Rc500n9hGe42794 -> tool:dsh:lead:call_00_Z3jpOV770ksgKLR8v75x6027 -> tool:dsh:lead:call_00_XsO3MIP118PCJsCVpf6E9476 -> tool:dsh:lead:call_00_4O7GklxJdq6Fn9QxIdzV0652 -> tool:dsh:lead:call_00_js9ACohwOratD3MVYDo12973 -> tool:dsh:lead:call_00_ydiijGr00lcgLBwEJb3s1327 -> tool:dsh:lead:call_00_jB4BeafH3lQOO6Ayn8dn3606 -> tool:dsh:lead:call_00_jKKcWQ4ZnwKROT7khVKS6547 -> tool:dsh:lead:call_00_oclt1o5KOpgOkYPlVGfy7210 -> tool:dsh:lead:call_00_x3arOeA20DRa4PiRZB1I5025 -> tool:dsh:lead:call_00_WKOTkashimONW9FoCfn53890 -> tool:dsh:lead:call_00_yEDI4Jn4ULvuTQWLipVK4245 -> tool:dsh:lead:call_00_nHW9LmCzDkR3zqStKmZe5542 -> tool:dsh:lead:call_00_nS3rk5bnuDmJ5YgTjOhe7802 -> tool:dsh:lead:call_00_ILF1LtXwQTinoao8Hc2v5234 -> tool:dsh:lead:call_00_BxclJncC8hdWH7aDpGm72117 -> tool:dsh:lead:call_00_JIUyUYPB3fkvPvLnJOpn1816 -> tool:dsh:lead:call_00_yA3Tj99K8fVHW45pTVxA8180 -> tool:dsh:lead:call_00_tcm3NiT1wTKA35HxxFRq2414
- 关键路径耗时：1.729
- Makespan：527.559
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
