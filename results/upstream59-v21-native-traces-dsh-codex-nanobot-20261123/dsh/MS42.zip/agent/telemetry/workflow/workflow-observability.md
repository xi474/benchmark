# Workflow 可观测性报告

- Trial：`MS42__mH8T7Zg__env`
- Task：`MS42`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（26 节点 / 25 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：26；执行边：25（observed=0，inferred=25）
- Execution Trace Graph：`observed`；temporal_next 边 25，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_H8g10LPUSwVlR0d4uPTI5892 -> tool:dsh:lead:call_01_bfSJt504WP9cDQ4GJpDC4865 -> tool:dsh:lead:call_00_WYc2WWER2Oj0ZrcJDwr68444 -> tool:dsh:lead:call_01_IcFdWQILVE9X0EsSmaUh4913 -> tool:dsh:lead:call_02_QeWBoIHyJMsej1FXwvUv9729 -> tool:dsh:lead:call_03_K7w4kSYvo912W79ZvKo95261 -> tool:dsh:lead:call_04_IgwLyfCs8FYvFhteeQ1B8197 -> tool:dsh:lead:call_05_Xts0r3S8GS3pQgBaaQiM1118 -> tool:dsh:lead:call_06_gaMgU8vWmm0rp5jR29T88194 -> tool:dsh:lead:call_07_VMcshXYPVCPYiBcgyYyk3559 -> tool:dsh:lead:call_08_jx0asFJkrsi4dzZFvbVp7976 -> tool:dsh:lead:call_00_456gFpzu1hzu3QNg7Tgb3649 -> tool:dsh:lead:call_01_zd9HmM53L0XcKohxjut55619 -> tool:dsh:lead:call_02_HOyct5jqN7WcURqWeWj83449 -> tool:dsh:lead:call_03_NgZ4tKUXL5wSAQiJJMIk2829 -> tool:dsh:lead:call_04_pgSmnpCJY6XXHbB600pY9766 -> tool:dsh:lead:call_05_03dAXH55U7OtWGMoDdqs7032 -> tool:dsh:lead:call_06_dmqKrTOOoHAJjC2r3Jzg1331 -> tool:dsh:lead:call_00_HfJyb6VFoSI22aEkSgNC7512 -> tool:dsh:lead:call_01_FQ95MMenrb4oC3hL30Ta6080 -> tool:dsh:lead:call_02_KK8OKsFNFgpVz5cxHxSE0643 -> tool:dsh:lead:call_03_A6WRo3JFdwEuP6lOzS7X9356 -> tool:dsh:lead:call_04_bVYB2QVex1abpCrUZ2bH4096 -> tool:dsh:lead:call_05_sOKCpwinvoIwGpgp8RbG4357 -> tool:dsh:lead:call_06_pEhghkbQ7BvcrAvKp1tp7947
- 关键路径耗时：0.519
- Makespan：423.677
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
