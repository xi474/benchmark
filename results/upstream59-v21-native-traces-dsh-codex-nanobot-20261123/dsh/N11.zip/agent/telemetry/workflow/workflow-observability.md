# Workflow 可观测性报告

- Trial：`N11__eKL9Kum__env`
- Task：`N11`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（27 节点 / 26 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：27；执行边：26（observed=0，inferred=26）
- Execution Trace Graph：`observed`；temporal_next 边 26，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Dz6xCpna55VmMtwDmJC39936 -> tool:dsh:lead:call_01_dwcBF0R2C92b7B4bqP3A3924 -> tool:dsh:lead:call_00_wOUbWW7p0TcEqxMhsISx3638 -> tool:dsh:lead:call_00_2zK9E5BgkJ0EFk3nDksi8050 -> tool:dsh:lead:call_00_PPhf0h5haMQlb8UzhYcx5834 -> tool:dsh:lead:call_00_sPhZGUkK14LKcQTaXhwW4355 -> tool:dsh:lead:call_00_7svBql1J0lDGkQDIwlIb9479 -> tool:dsh:lead:call_01_YR4ELVxSuNXOND0kaY3n7810 -> tool:dsh:lead:call_02_Mdh3OEubVV7LgV5pR1p94181 -> tool:dsh:lead:call_00_01IzXpfD7mNZWTqnTR626834 -> tool:dsh:lead:call_01_713W6pSOdcaUrWyKdejX2432 -> tool:dsh:lead:call_02_ZCISOPjNKDE4Zy0SUts10133 -> tool:dsh:lead:call_03_L8pHZsf0A4F2goDLgKzb1305 -> tool:dsh:lead:call_00_o1yD6hNCKHnKi5muN99W4307 -> tool:dsh:lead:call_01_fSUJh9HUaTWxwI40rz6W2476 -> tool:dsh:lead:call_02_kxKlfxPy5FvUpUZoDsyn7169 -> tool:dsh:lead:call_03_QLUeWvAppri7zfkV8rRd3100 -> tool:dsh:lead:call_00_ZCElKWrdaD80aiP0sEtm6075 -> tool:dsh:lead:call_00_ft2jGtpyFWVrkXQwTS210428 -> tool:dsh:lead:call_00_WkZNXJgZP1CXgOeQKrvJ7227 -> tool:dsh:lead:call_00_uMTBGvYo2apm5UIHmWgv4856 -> tool:dsh:lead:call_00_SWvHlm67Jqx4ylpOz4Uc5857 -> tool:dsh:lead:call_00_PJdK97x1jjK4uYsr9QvJ4305 -> tool:dsh:lead:call_00_Vy1wURm0vVl3BoEvCf2Q4414 -> tool:dsh:lead:call_00_r5EiAWy9oboj2IKKSIiL3304 -> tool:dsh:lead:call_00_QsssnKnFMGu5s2KEVeS88720
- 关键路径耗时：0.536
- Makespan：166.68
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
