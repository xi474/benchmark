# Workflow 可观测性报告

- Trial：`N17__uNR6JQQ__env`
- Task：`N17`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（24 节点 / 23 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：24；执行边：23（observed=0，inferred=23）
- Execution Trace Graph：`observed`；temporal_next 边 23，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_yR7Wo3pXg1GuhKhxfV5e6153 -> tool:dsh:lead:call_01_RvceVMoWTTtDUY8Ukvrs1272 -> tool:dsh:lead:call_00_wNYmX9Qb0MSFdMyYadwp7589 -> tool:dsh:lead:call_00_HrN87vOD9cgwkNBycxkZ3513 -> tool:dsh:lead:call_00_QUu0VQUFAOf2ngpruDnw6489 -> tool:dsh:lead:call_00_5dUKgJKWe6MXkDIxpBE91070 -> tool:dsh:lead:call_00_LKNdSLk2K9n8VqWm6nhm4536 -> tool:dsh:lead:call_01_1USyGXsV8tTdpcdzcro20936 -> tool:dsh:lead:call_02_ZVPQZT1IHoIViG8JtT9k8528 -> tool:dsh:lead:call_03_kf93xlJbVN6CCRnOBqtm1693 -> tool:dsh:lead:call_00_8K5bfN04ZNRqMXvyWXhC3804 -> tool:dsh:lead:call_01_weEQcQkYVnM3MacSUjHf5168 -> tool:dsh:lead:call_02_ap0JOh2xyIIMdr8lGZ6t0783 -> tool:dsh:lead:call_03_3gWeORGnl6Zr3QwcETaE2197 -> tool:dsh:lead:call_00_aeYppmWn5dUFGhzY8GKW9272 -> tool:dsh:lead:call_01_exyi81FSsl7MnosQG8l79322 -> tool:dsh:lead:call_02_dNaDTkTCFvIBIiWsDABX5776 -> tool:dsh:lead:call_03_nm4b8xQoViG6te2pNlsV1987 -> tool:dsh:lead:call_00_oCencu3S6bVsnDR5i3Pc5600 -> tool:dsh:lead:call_00_so2YfzehhOSI1EqdW9kj6693 -> tool:dsh:lead:call_00_q8MlXRhIngviKhB0uOh56095 -> tool:dsh:lead:call_00_4ypDfyzZVwR4DjCmbWXg6833 -> tool:dsh:lead:call_00_f1LirNzKCVY7XXo77bl50428
- 关键路径耗时：0.463
- Makespan：225.455
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
