# Workflow 可观测性报告

- Trial：`N22__FvdE4o7__env`
- Task：`N22`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（54 节点 / 53 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：54；执行边：53（observed=0，inferred=53）
- Execution Trace Graph：`observed`；temporal_next 边 53，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Z9fi6HPRtFW9Fm3mRqpz7208 -> tool:dsh:lead:call_01_WPZnNqUNMmXBWYVUQGbv4665 -> tool:dsh:lead:call_00_30EWleHByIHYHSqnpw8F9123 -> tool:dsh:lead:call_01_cs9eYpeHfqPrLSmzRWif7078 -> tool:dsh:lead:call_00_k08MUlrHrESgg5stBT1w2604 -> tool:dsh:lead:call_01_qPKctj2by9naUWN3erSj2455 -> tool:dsh:lead:call_00_VxGhc9HfXpbPGuCYg3yy9786 -> tool:dsh:lead:call_00_wUJ3JVvrzHL7ofD7t56e7919 -> tool:dsh:lead:call_00_p1mm0NU9omC2TLvKo6pJ5461 -> tool:dsh:lead:call_00_TOVuFpsVNeOPoADZO4Ar4988 -> tool:dsh:lead:call_00_xocTa7xMqE9m1OibE5XS5098 -> tool:dsh:lead:call_00_XKAcWtePNFhmtx7kIKrN3375 -> tool:dsh:lead:call_00_GMQ3HqjlSrZjFcKiPDgA8108 -> tool:dsh:lead:call_00_v38oegonY6mZAIQROANm6810 -> tool:dsh:lead:call_00_jiAzPq5oMQOZS2zWYUr06614 -> tool:dsh:lead:call_00_yutxPACe0mBPIFrQYJ3r2985 -> tool:dsh:lead:call_00_xRBGDdIYkgI9qaGXiWYL5401 -> tool:dsh:lead:call_00_krk4OmT1nPxIhq52vear8270 -> tool:dsh:lead:call_00_FinDX1sBgpg6WQmGN53r7659 -> tool:dsh:lead:call_00_Z5yqamhuBw0XO0yt2G071493 -> tool:dsh:lead:call_00_qMkOqTML6HbrvGBfszyy6056 -> tool:dsh:lead:call_00_RCAJem7vhlobmsSkDWut2167 -> tool:dsh:lead:call_00_hAjIgWAJNeSIJXghKS5I0566 -> tool:dsh:lead:call_01_3DxKJVOpTYcsLs7fj2QK7576 -> tool:dsh:lead:call_02_GrUsL9R7rAZlRHnLKyaZ8625 -> tool:dsh:lead:call_03_9I1VZXPxp4eJrvgGYNeG7786 -> tool:dsh:lead:call_00_bc4Emzn1dhZYMLVCL5NW2443 -> tool:dsh:lead:call_01_1nLva7wgcpB1uWrvNL291451 -> tool:dsh:lead:call_02_4tnRsDilmHwyz8mhj3eL2540 -> tool:dsh:lead:call_00_UuGgQdToHV2i8LQm8MQk3250 -> tool:dsh:lead:call_00_fm2DfNOP3u0PnPnvOpK46926 -> tool:dsh:lead:call_00_nTdBBBE2uyq0nJXmZwH98766 -> tool:dsh:lead:call_00_DAEz92xXyz4qDJRf0MGs5463 -> tool:dsh:lead:call_00_OsDFjo4sCT4L4NqqjUUS4262 -> tool:dsh:lead:call_00_xXhGeQDNCOB7rBTD3Ueu8670 -> tool:dsh:lead:call_00_zcIWd2STXZoQp9u3DcoI1740 -> tool:dsh:lead:call_00_p3t9YUhx6ReYDdqa4MYY8198 -> tool:dsh:lead:call_00_ljUMzgRxRiMjaxukTbIT3151 -> tool:dsh:lead:call_00_XBCM1NImzVBtnjfyELg89414 -> tool:dsh:lead:call_00_X7Ca0kYSwTVf3ZVo0bnN9159 -> tool:dsh:lead:call_00_SRv7QLyvN6kJkA6d45jK9830 -> tool:dsh:lead:call_00_YMDGKPTZUBC3gjMRId113930 -> tool:dsh:lead:call_00_l4dYPQhPMKSthXQbWaTF0627 -> tool:dsh:lead:call_00_T3nPn6c2EVTah88jL71F0661 -> tool:dsh:lead:call_00_zalPGaIm1rzGEWFL8RBm2598 -> tool:dsh:lead:call_00_4APIIKuYx0ph8vKgKOYo9606 -> tool:dsh:lead:call_00_JWZzT4aUNN3kRLfBAxvP2705 -> tool:dsh:lead:call_00_lswbgXilePHAZ4jn6egR6187 -> tool:dsh:lead:call_00_NH7aKnV3DyKZq9F9GoZd1509 -> tool:dsh:lead:call_00_XT3QZ0NfNMU3MzJIv7DL8817 -> tool:dsh:lead:call_00_5HMfXvpwQi0noGh6exK53961 -> tool:dsh:lead:call_00_7hHU8U8gnHya7VQG6f1F6118 -> tool:dsh:lead:call_00_4gehOzsBlUl4WnXphYK18913
- 关键路径耗时：2.014
- Makespan：503.439
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
