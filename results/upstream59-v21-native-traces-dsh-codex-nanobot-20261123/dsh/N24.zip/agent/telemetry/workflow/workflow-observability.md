# Workflow 可观测性报告

- Trial：`N24__TZ3irrc__env`
- Task：`N24`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_Qlrl9K493FuYABc5VuGN9438 -> tool:dsh:lead:call_01_Rp7r04rXr0u1DTwZ6hg01162 -> tool:dsh:lead:call_00_TsmSHEXWOveub5cA18cN1567 -> tool:dsh:lead:call_00_NjieZbLB6Bif1CIkZuRH7647 -> tool:dsh:lead:call_01_4VyURLxTR3DVJtzNhLtE4412 -> tool:dsh:lead:call_02_7KlGBiKsjukM2R9jZpXp4883 -> tool:dsh:lead:call_03_sfKG4qfqiWWrRn0IKsqZ7456 -> tool:dsh:lead:call_04_zPXytEfpBT49kpLWKdw01522 -> tool:dsh:lead:call_05_ukajUaSIN9kh3QsBOCvZ6215 -> tool:dsh:lead:call_06_abqiTk6XYNFc7i3ncGKx5130 -> tool:dsh:lead:call_00_jf9cVJR6tRNtp5wyEREz5613 -> tool:dsh:lead:call_00_t43rcHyNqGWTtYNsbM0T8093 -> tool:dsh:lead:call_01_jubpa6TkrYgOGZhydB8E8060 -> tool:dsh:lead:call_02_jsyd4bW4Um5lfSCoD5QG2404 -> tool:dsh:lead:call_03_E9XYrm86wz3IAvZUuOs05339 -> tool:dsh:lead:call_00_dzMgVirrltTF6ZMjUJMr5577 -> tool:dsh:lead:call_01_abpCfAWrlQjXcDDRTsLE8101 -> tool:dsh:lead:call_02_DAwYwZlHM96CfCxEoqNv6744 -> tool:dsh:lead:call_03_t3oycAepGnSySpV4ZUvb8446 -> tool:dsh:lead:call_04_AZ0rygwAd1ZZ5ybcgStH2063 -> tool:dsh:lead:call_00_KONZht7YhYcyVN5rHiLv8997 -> tool:dsh:lead:call_01_gJL8M6mZdSgFBV23lm3O2824 -> tool:dsh:lead:call_02_kmRXq14mpvl5m8rkHein2245 -> tool:dsh:lead:call_03_AvmUEa4uNwp0ekC5WjL71782 -> tool:dsh:lead:call_04_j26tqU6kjyVckt62ghnx4310 -> tool:dsh:lead:call_00_mk8ekpJxwUSNsuWZO6dO4484 -> tool:dsh:lead:call_00_lAW8GOpG37dum8Hm43i22469 -> tool:dsh:lead:call_00_9mt627CkRtJixMBbhG5O6730 -> tool:dsh:lead:call_00_IffqlSP6G2uaIynBW5Pa6693 -> tool:dsh:lead:call_00_bPjG2rQ3SxMFQN55QuZp5675
- 关键路径耗时：0.549
- Makespan：200.311
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
