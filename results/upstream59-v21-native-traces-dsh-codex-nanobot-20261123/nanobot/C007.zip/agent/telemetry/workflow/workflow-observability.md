# Workflow 可观测性报告

- Trial：`C007__492zHYT__env`
- Task：`C007`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（44 节点 / 43 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：44；执行边：43（observed=0，inferred=43）
- Execution Trace Graph：`observed`；temporal_next 边 43，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_CrCPk7i9CuWuX183RVcI8961 -> tool:nanobot-harness-v3:call_00_AJvHsUsKJZ69dmhFqVnF3697 -> tool:nanobot-harness-v3:call_01_tohvJZfKljoz32zKr2Nj1296 -> tool:nanobot-harness-v3:call_02_4MgBkwUUPyMZgTdeDldE7388 -> tool:nanobot-harness-v3:call_03_h4cXmCORvd6kAQAzT1Jf5378 -> tool:nanobot-harness-v3:call_04_6QpXgvGH9rVhHlkl3HGo8243 -> tool:nanobot-harness-v3:call_00_ElCjx8e1oaNLFKXTERgw4337 -> tool:nanobot-harness-v3:call_01_zcBXRKw3XGlScD1r35cE2452 -> tool:nanobot-harness-v3:call_02_keaWeJiSXWG564UIExHf1711 -> tool:nanobot-harness-v3:call_03_7xBL8ZWmUL2ejnOAM2Cp6933 -> tool:nanobot-harness-v3:call_04_mGM4g0p6ZB4lTe088NTd3670 -> tool:nanobot-harness-v3:call_00_Ed1TKrrRu5s02AYKmMhe0500 -> tool:nanobot-harness-v3:call_01_ujUMDEAQhLkHF4jRKYG72435 -> tool:nanobot-harness-v3:call_00_GKln7dQjS2srOaSH29X16547 -> tool:nanobot-harness-v3:call_00_bcb760FbX1e0T1coDqU37324 -> tool:nanobot-harness-v3:call_01_Z0pmcdTXvfMq6p98OLum8778 -> tool:nanobot-harness-v3:call_02_uWTiroQBa86VGCZ8L5Wc9540 -> tool:nanobot-harness-v3:call_03_2ud0UDjJ9MBVcRNEcavA4125 -> tool:nanobot-harness-v3:call_04_gNJjclLYS6kNFdEOC6OO3642 -> tool:nanobot-harness-v3:call_05_i7NXAvFZDmh85zi5GZrm1744 -> tool:nanobot-harness-v3:call_00_xn9XHE0IeUSC0I9s3x3s6486 -> tool:nanobot-harness-v3:call_01_RWVEiiSzXil4MoavAaA64784 -> tool:nanobot-harness-v3:call_02_XwiuXvDKKDCNeG7mJSl51860 -> tool:nanobot-harness-v3:call_03_pSQqVWqScn2giMrcFDbM9090 -> tool:nanobot-harness-v3:call_04_N7IP8wqDz6QScrtvOWNa3889 -> tool:nanobot-harness-v3:call_00_vaNQA1jFt2PpDQirhSD21551 -> tool:nanobot-harness-v3:call_01_Whclppu7XV25PMq4attb1727 -> tool:nanobot-harness-v3:call_00_UEuk1UGAxXttR7hreb7f7830 -> tool:nanobot-harness-v3:call_00_CiCyAWvdJ3FsCkxtv8Wi3992 -> tool:nanobot-harness-v3:call_00_PxjoKhZ3MCQaEExVoIID4033 -> tool:nanobot-harness-v3:call_00_hmKhdLKcLeJciAenHYzn7973 -> tool:nanobot-harness-v3:call_00_0Pr80L8I37C4EMlYmKhT4324 -> tool:nanobot-harness-v3:call_00_fygd43jG07Z7RRPlQsKd8235 -> tool:nanobot-harness-v3:call_00_S1ADkv1KzsbxWce5nKUL5393 -> tool:nanobot-harness-v3:call_00_pGOIGkdOleTLcC24WRl21354 -> tool:nanobot-harness-v3:call_00_MVslLezpBJE0K4ibwHbS3890 -> tool:nanobot-harness-v3:call_00_SB5UTU9nDU0hmzjXc1BX0033 -> tool:nanobot-harness-v3:call_00_ihIU9e2pr4ZPSSz9xn4l9866 -> tool:nanobot-harness-v3:call_00_Uy6nYqKP5QKelfsvep3Z8063 -> tool:nanobot-harness-v3:call_00_3qdZtlbgxyy7V3QtgF2p9156 -> tool:nanobot-harness-v3:call_00_zmhkXWobMJbZ1T6BnoOW9416 -> tool:nanobot-harness-v3:call_00_fGYyXDCKdFuIOJ5iP7k02108 -> tool:nanobot-harness-v3:call_00_7bvITqNX92Im65TKdTTT2686
- 关键路径耗时：13.853504
- Makespan：383.714153
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
