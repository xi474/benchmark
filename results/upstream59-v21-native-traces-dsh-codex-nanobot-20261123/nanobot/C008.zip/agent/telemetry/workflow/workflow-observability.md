# Workflow 可观测性报告

- Trial：`C008__8Dvr5gJ__env`
- Task：`C008`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_t9yo4wQXm0tRU9tkRr5D3612 -> tool:nanobot-harness-v3:call_00_bEVXcWmfaQnsMAVTJRM89903 -> tool:nanobot-harness-v3:call_01_y5Ja3Q1RhXDPADiHmD9Z2108 -> tool:nanobot-harness-v3:call_02_bM8Vl45xIqPSvSD6DLDT5695 -> tool:nanobot-harness-v3:call_03_pPr32PQPCvmju3pWybUr0097 -> tool:nanobot-harness-v3:call_00_1KVqthPfshprzH1gn5td2858 -> tool:nanobot-harness-v3:call_01_jphX8iTafj0uCbMnau7i7464 -> tool:nanobot-harness-v3:call_02_coSv4cHNzdkwWS69zlWF8961 -> tool:nanobot-harness-v3:call_03_nO6iO1IvPiugT9luGBTC2248 -> tool:nanobot-harness-v3:call_04_2sf9AkXHk7rYE108LLIs8396 -> tool:nanobot-harness-v3:call_00_PAv7dDydjNjfIDTkrp8l7203 -> tool:nanobot-harness-v3:call_01_ndutRBuS3UCwdkyHTFxa4928 -> tool:nanobot-harness-v3:call_02_Lr4AsoFdVTkD8vF4Xguc1811 -> tool:nanobot-harness-v3:call_00_W1SswVzoWWwALR9w4NGj5115 -> tool:nanobot-harness-v3:call_01_Iy4EgQQsvpvA1G5ZUELP7037 -> tool:nanobot-harness-v3:call_02_OrTAAAv3rBscOQv4Gu6r1558 -> tool:nanobot-harness-v3:call_03_1I2IOqAKMiqZrd3oGrho3504 -> tool:nanobot-harness-v3:call_04_gIe0qn4jFZOLJRjO5q3c5251 -> tool:nanobot-harness-v3:call_05_IziGXIRcfv14mD1Ke6bW0651 -> tool:nanobot-harness-v3:call_00_oO8p9F5Hv5WLtq8LLk3G8747 -> tool:nanobot-harness-v3:call_01_WDjoOH4yjBu7qexdtT2k3416 -> tool:nanobot-harness-v3:call_02_OwaFBU3pfSiEg9lOBVPH7735 -> tool:nanobot-harness-v3:call_03_KFq32KiomaSZZ5r3YTAS3003 -> tool:nanobot-harness-v3:call_04_GtEEo9n6OBLrHpuW4CjH1398 -> tool:nanobot-harness-v3:call_05_Qui9JYHNGefQhdk2SBQW9054 -> tool:nanobot-harness-v3:call_00_QZnwjFCVkLYHucMbUdgX8136 -> tool:nanobot-harness-v3:call_00_9sPo9ChyvmNtgZkAXTco6635 -> tool:nanobot-harness-v3:call_01_dDzjtdDodII6OjqdkZef8531 -> tool:nanobot-harness-v3:call_00_itqxOLVuqhNBn2A8WDCG8939 -> tool:nanobot-harness-v3:call_00_5OYKhmtdPWwgEOemszpv6257 -> tool:nanobot-harness-v3:call_00_fZbbprQL9tHpDOy4kwCr2785 -> tool:nanobot-harness-v3:call_00_SrdSEJOSTzpvWvJsHVvL5349 -> tool:nanobot-harness-v3:call_00_SyhjigAIjY2jHWCiAWLN2592
- 关键路径耗时：0.243446
- Makespan：63.013733
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
