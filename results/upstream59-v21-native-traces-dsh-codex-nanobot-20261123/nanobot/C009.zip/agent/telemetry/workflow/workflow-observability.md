# Workflow 可观测性报告

- Trial：`C009__vCaRsdt__env`
- Task：`C009`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_JcJEzUX3ic4LxMemdpCC6016 -> tool:nanobot-harness-v3:call_00_0y883vfof2TX0Q087Lqf7080 -> tool:nanobot-harness-v3:call_01_hjKrtYQFxBZRdkHQR1EJ6420 -> tool:nanobot-harness-v3:call_02_u5TPFRZN1LYR8ly5LPB37115 -> tool:nanobot-harness-v3:call_03_lJZ7Oe1UbLasPosHmLgm7649 -> tool:nanobot-harness-v3:call_00_qLLFNfs2j8nevheUPI7d1878 -> tool:nanobot-harness-v3:call_01_Ps490bPQsQW2nKBHKx4X1385 -> tool:nanobot-harness-v3:call_02_N2ZGAMTwDSGrr9FTIVLO3423 -> tool:nanobot-harness-v3:call_03_Ialz5C0vwo6RVGIh0EJ36109 -> tool:nanobot-harness-v3:call_00_nv2icNdQd0pV9r945Ji45827 -> tool:nanobot-harness-v3:call_01_JKkNjQEG4vYLJepbDuaH4083 -> tool:nanobot-harness-v3:call_00_AHpG71Ow8I6NEFUtdFJU8171 -> tool:nanobot-harness-v3:call_01_GN5kK3wZ8H31191o1N771957 -> tool:nanobot-harness-v3:call_02_WjiRIw1mMLFQp54b4mhA2962 -> tool:nanobot-harness-v3:call_03_PxCA0XouGsgXlVSs1Bql8193 -> tool:nanobot-harness-v3:call_04_91yohV8cRxWsPXw2SYLs0092 -> tool:nanobot-harness-v3:call_05_t3IaAElltvMX6X9aXRmI6214 -> tool:nanobot-harness-v3:call_00_cD1FWqfiX6ijH1OH1BQv1626 -> tool:nanobot-harness-v3:call_01_GFP7SW7VbiW0Cgt3HWuf9667 -> tool:nanobot-harness-v3:call_02_00DVZ0iWDzxb7iP4V7Lx2938 -> tool:nanobot-harness-v3:call_03_QtDmMRxxi58BURjOYFL93810 -> tool:nanobot-harness-v3:call_04_i0AXT0lH3Ui4U3DXE6wz1245 -> tool:nanobot-harness-v3:call_05_mzGPXNS9Bh7sAoPzrcu65043 -> tool:nanobot-harness-v3:call_00_vjXDSrwoxJYMZWX8qlri3647 -> tool:nanobot-harness-v3:call_01_qYTAXYUJ9ZBZ1VTxV8Rv5824 -> tool:nanobot-harness-v3:call_02_t5HzyWk9GvC2GepVJQss4258 -> tool:nanobot-harness-v3:call_03_ym7sVEDLqptReIJ3QJyX0859 -> tool:nanobot-harness-v3:call_00_M5JQJGvPh4WZ3365zYHC8529 -> tool:nanobot-harness-v3:call_01_mSK8QAScoC19262Y9jOF5914 -> tool:nanobot-harness-v3:call_02_7JXWI3e1OFQAMWGKB6d97015 -> tool:nanobot-harness-v3:call_00_9PqGBMUnJZmgpBagxIgh8248 -> tool:nanobot-harness-v3:call_00_MGOUeTKxpIcQzzsEzs982521 -> tool:nanobot-harness-v3:call_00_CI4X6vklkgG7qgwL0l496329 -> tool:nanobot-harness-v3:call_00_8h3s5Z5c5TepmA3qHWtL4972 -> tool:nanobot-harness-v3:call_00_MLXKNGNlOfN0cXJiYpfb9956 -> tool:nanobot-harness-v3:call_00_zfLCMfA6FSQbkUAKVOSy0448 -> tool:nanobot-harness-v3:call_00_qUoYqX0wRB6OGGIQjxZm3677 -> tool:nanobot-harness-v3:call_00_LVtnH6dlO919byH76PQI2551 -> tool:nanobot-harness-v3:call_00_RkoJXhyML9dKADJ2oNjj7691 -> tool:nanobot-harness-v3:call_00_Uk8eyhtNTl6okJd60FDl1267 -> tool:nanobot-harness-v3:call_00_A84ufLDF9rlztaOTKySF6899 -> tool:nanobot-harness-v3:call_00_XBaNECPszQJnY7rvYOsm4187 -> tool:nanobot-harness-v3:call_00_YlvnSsTbAwCjHmiiI41r9148 -> tool:nanobot-harness-v3:call_00_DxrPlugk7kCiaAvaHfry9698 -> tool:nanobot-harness-v3:call_00_PJc1YC9nl6UY44x3imY11051
- 关键路径耗时：0.299001
- Makespan：378.694506
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
