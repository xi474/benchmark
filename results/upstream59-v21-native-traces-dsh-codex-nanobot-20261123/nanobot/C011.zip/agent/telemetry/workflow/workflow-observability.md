# Workflow 可观测性报告

- Trial：`C011__ZYKyriV__env`
- Task：`C011`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_h3kARSnn3ffBzItmIcef6407 -> tool:nanobot-harness-v3:call_00_eAmu1rppVH1zv0ziT9Ix6060 -> tool:nanobot-harness-v3:call_01_PHJWIMsuKDgDwnyRjSBP4260 -> tool:nanobot-harness-v3:call_02_mhSao7g6WfpntCdmYRuL1772 -> tool:nanobot-harness-v3:call_03_Z5mFLSVCJbqyEbT3jVrM9680 -> tool:nanobot-harness-v3:call_00_MPCLEdAb0wLrsRuExAPK5350 -> tool:nanobot-harness-v3:call_01_uTY5r4d7N62OivZrKTVa6108 -> tool:nanobot-harness-v3:call_02_UNskGgtKRBeydAIan9Ro8621 -> tool:nanobot-harness-v3:call_03_h0GPfRPBghBQbuQPuo7x4832 -> tool:nanobot-harness-v3:call_04_vSMOE2i6W742Jk9zT4Au3372 -> tool:nanobot-harness-v3:call_00_mfMOwrmF0re5EpTFVE1V3463 -> tool:nanobot-harness-v3:call_01_uAyt4uy0BrViii1Tu86o5291 -> tool:nanobot-harness-v3:call_02_hWz6e2FjXbZJORUtzW6S2013 -> tool:nanobot-harness-v3:call_03_bv5LpiT0PKGQ5LGVTEca4165 -> tool:nanobot-harness-v3:call_04_P7WTJg9WwMwbrCuWgcMC0583 -> tool:nanobot-harness-v3:call_05_K6vVBbOSgDlWoEphq5Oy0220 -> tool:nanobot-harness-v3:call_06_TG6OrWvPK4kU20RgpaAO5338 -> tool:nanobot-harness-v3:call_00_i9kNKE6cUp9Tq8FcpA3W5971 -> tool:nanobot-harness-v3:call_01_3hrWoDcysacOaBQe4UPD0464 -> tool:nanobot-harness-v3:call_02_9rnsUYQxZKfdrjHDWvEt1859 -> tool:nanobot-harness-v3:call_03_FFIpgCRin57S6wE5X1cQ6702 -> tool:nanobot-harness-v3:call_04_LCaANPtHDZA1Xsxawsd67021 -> tool:nanobot-harness-v3:call_05_5weZKaIbHUb8cw9LX7hH4847 -> tool:nanobot-harness-v3:call_06_fO05WuckA7M5XZyXMAqP3049 -> tool:nanobot-harness-v3:call_00_sS01463bLUGDxDXjwxMp0966 -> tool:nanobot-harness-v3:call_01_CY3XBsklZrcPKEOgSdNa1580 -> tool:nanobot-harness-v3:call_00_KfQMfFNF3jXQsrulKEHz6588 -> tool:nanobot-harness-v3:call_01_35Ybxp92iePUi4nMKOTR4438 -> tool:nanobot-harness-v3:call_00_211oOFgwRkzQVTRJMwsv3775 -> tool:nanobot-harness-v3:call_00_qXRob5LMFhnAL2ev7uQu6199 -> tool:nanobot-harness-v3:call_00_5wjEMJspIlRQrLQdWb9F7974 -> tool:nanobot-harness-v3:call_00_nxkHqYFGqu6qj9d9WxS48609 -> tool:nanobot-harness-v3:call_00_w9kYWsCMkH4pFGy7MUdL0135 -> tool:nanobot-harness-v3:call_00_R51TBe1hGFAhPTfYbhJi5197
- 关键路径耗时：0.019379
- Makespan：442.080484
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
