# Workflow 可观测性报告

- Trial：`C017__PFt85xG__env`
- Task：`C017`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_yn0blfJoQ4MuUnC6qAVO7108 -> tool:nanobot-harness-v3:call_00_mhKs1g026YGfZi24RMjU2126 -> tool:nanobot-harness-v3:call_01_QSjQV5YyG6fqxuctN47z4244 -> tool:nanobot-harness-v3:call_02_4XUuvb0A8ylQymMxxPir4056 -> tool:nanobot-harness-v3:call_03_5sUBSdtXxZ6RIV2E46aM7943 -> tool:nanobot-harness-v3:call_04_y8cAOLazOh6XaSe50a1C0776 -> tool:nanobot-harness-v3:call_05_hHR8s9aRCC4MiRHdZnrO5122 -> tool:nanobot-harness-v3:call_00_YgRpLF1eD0XV0dmtFnaY4189 -> tool:nanobot-harness-v3:call_01_l2wlcmE45TqRl4d4JURp3256 -> tool:nanobot-harness-v3:call_02_fEIm3dj8srqmyf51yWmQ2055 -> tool:nanobot-harness-v3:call_03_untQguIKy800XOclqurR2536 -> tool:nanobot-harness-v3:call_04_btysg13zih5Nd2BETfVp3619 -> tool:nanobot-harness-v3:call_00_s5M66hBWB2Odi1jLuwYs6981 -> tool:nanobot-harness-v3:call_00_Agy39IiWKD4v3IPgWUAi0235 -> tool:nanobot-harness-v3:call_01_TECtzIrzDaN5EE5d2Tsh3763 -> tool:nanobot-harness-v3:call_02_zf4tJlfIqXFJe0gqrNPw3046 -> tool:nanobot-harness-v3:call_03_5IMIPCR1o5hYTSwvMoOj2822 -> tool:nanobot-harness-v3:call_04_nsDAMA02UbnzLatjDjIQ7243 -> tool:nanobot-harness-v3:call_05_fRyvBxJqEMJtEtTBrO757340 -> tool:nanobot-harness-v3:call_06_xxzc4H44blMChCzgWL4d4354 -> tool:nanobot-harness-v3:call_07_srTwEugZSpRF72T5lWNU9547 -> tool:nanobot-harness-v3:call_00_Cpmu8ewcqJtuDEOxGyl15859 -> tool:nanobot-harness-v3:call_01_reYsRL9cSZNdL6sDDcC62234 -> tool:nanobot-harness-v3:call_00_gjUvpUiCzj0QkBQUGb7v9542 -> tool:nanobot-harness-v3:call_00_NLu8RKN4Iv4xIodhMmvO9847 -> tool:nanobot-harness-v3:call_00_jmbR6MgeUH0E3eQdVC8p5945 -> tool:nanobot-harness-v3:call_00_CjfZNXGashe5eMcGpsjp9317 -> tool:nanobot-harness-v3:call_00_HRvgRimmhMyJmrmXwGhQ4463 -> tool:nanobot-harness-v3:call_00_NRM7nYozr0y3I887X97B2717 -> tool:nanobot-harness-v3:call_00_d16K34zaKwQG88ENrPQx4990
- 关键路径耗时：0.419059
- Makespan：164.198919
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
