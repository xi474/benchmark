# Workflow 可观测性报告

- Trial：`C031__T63QtHV__env`
- Task：`C031`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_FBvQaad54uptWsnnI53B7079 -> tool:nanobot-harness-v3:call_00_5JgzaSo1sFa8vnQEtR2E5314 -> tool:nanobot-harness-v3:call_01_zeg9dBRzh4t6M97TmH3t7655 -> tool:nanobot-harness-v3:call_02_88lByENJzaL2v4g0kCqg8487 -> tool:nanobot-harness-v3:call_03_80p47EyoPAuaCKmKHxr14665 -> tool:nanobot-harness-v3:call_00_WrnN3Xaa4Y8szF3ULvpK8987 -> tool:nanobot-harness-v3:call_01_PcrOZFtWvFJQgUfBQeEt3544 -> tool:nanobot-harness-v3:call_02_x1YJFN5CwlHfCvVz3bUT9034 -> tool:nanobot-harness-v3:call_03_QPFfYVNb8KBdz9wNAnW77426 -> tool:nanobot-harness-v3:call_04_iVKHUbldQgNFlOfir9nR5135 -> tool:nanobot-harness-v3:call_05_hRtQoizWyEXCQfHcwlqM1489 -> tool:nanobot-harness-v3:call_00_CvdaaYASsjBSV6wpiRpJ5925 -> tool:nanobot-harness-v3:call_00_BFY3KI4irWXfcZ0ifFfO5740 -> tool:nanobot-harness-v3:call_01_HmEQqLTtvAMW2QTiV5xi2149 -> tool:nanobot-harness-v3:call_02_SWB3TffNYe5LT5sZhMqc4300 -> tool:nanobot-harness-v3:call_03_sPh45YabmppeE0KUM2eX0468 -> tool:nanobot-harness-v3:call_04_6mOgCUPQQmc6MTDlSIDd3915 -> tool:nanobot-harness-v3:call_05_60GpX41uyFnZs1lIDhdz4171 -> tool:nanobot-harness-v3:call_00_bSD1pvJVDXTPWd6G2u3C0207 -> tool:nanobot-harness-v3:call_01_cP6eBVr9rKzZ2KaE7bQE8705 -> tool:nanobot-harness-v3:call_02_3oqJXqJy55GXK3uiCUQ02541 -> tool:nanobot-harness-v3:call_03_Gbr9p9GuJl1fvFGwFUdN6673 -> tool:nanobot-harness-v3:call_04_388he5QqM6J5niTgA8Er9256 -> tool:nanobot-harness-v3:call_05_QgKrcXljcoHTdpehmesd8247 -> tool:nanobot-harness-v3:call_00_z8n2g5SeVtVhAAw5JJsz4931 -> tool:nanobot-harness-v3:call_01_GAoiU9cNnw5wLtUxlGrP2972 -> tool:nanobot-harness-v3:call_00_z1gOoqg0DTgErBq95vtu1262 -> tool:nanobot-harness-v3:call_00_WKyq6NxehFJ6JRUWFpAt1956 -> tool:nanobot-harness-v3:call_00_H3kVe8h9X4lAiPamRNZ34160 -> tool:nanobot-harness-v3:call_00_xAT33Pjj28hwkxj37VvP4947 -> tool:nanobot-harness-v3:call_00_kCuPbGyGwGSEZ6pYofst7705 -> tool:nanobot-harness-v3:call_00_BDxIswsccWkqlXdXtPPV0954 -> tool:nanobot-harness-v3:call_00_Zy9Mnm62NsWqwyoi4agL2406 -> tool:nanobot-harness-v3:call_00_pYu2UA4wMbydlFWpt75J7681 -> tool:nanobot-harness-v3:call_00_O4THvsHUdWEoogAh7Myh7963 -> tool:nanobot-harness-v3:call_00_i9SdBwlOJGOUTe47vzFg7092 -> tool:nanobot-harness-v3:call_00_lArKgEujV51fHdDy2vBA3837 -> tool:nanobot-harness-v3:call_00_Fd8NEa1t2AQhAyknCX3F6391 -> tool:nanobot-harness-v3:call_00_p9jMTqLNj7gy2AAoE0mv4103 -> tool:nanobot-harness-v3:call_00_3TReqEmyM22CtM5vRGOo8030
- 关键路径耗时：4.585541
- Makespan：298.257249
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
