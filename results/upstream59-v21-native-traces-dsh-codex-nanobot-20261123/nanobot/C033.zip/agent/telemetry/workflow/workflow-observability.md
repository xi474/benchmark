# Workflow 可观测性报告

- Trial：`C033__ikGcisa__env`
- Task：`C033`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（55 节点 / 54 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：55；执行边：54（observed=0，inferred=54）
- Execution Trace Graph：`observed`；temporal_next 边 54，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_IjFQ5Nf599E2WCQT2s202987 -> tool:nanobot-harness-v3:call_00_1H5MtTGj4m3gFfhUYyOU9514 -> tool:nanobot-harness-v3:call_01_slWobKLahDQA1Cki11Le5455 -> tool:nanobot-harness-v3:call_02_kzfpNhphO0A5CuxvfCgC1009 -> tool:nanobot-harness-v3:call_03_PMWS8BpIckGXq6du024p2249 -> tool:nanobot-harness-v3:call_00_2BYtH0wgBYVAuKJRtkvj7660 -> tool:nanobot-harness-v3:call_01_dqJ4KvhOnyhX4ZAHxKhH9352 -> tool:nanobot-harness-v3:call_02_Ij3UzlqRcv2C8jpi7QAw3776 -> tool:nanobot-harness-v3:call_03_MQ1dpryH4MuWoLT6Wamm0841 -> tool:nanobot-harness-v3:call_00_MhiWCEdT8u0PandraMYw5724 -> tool:nanobot-harness-v3:call_00_1IB1KP4FCurMkACHXZQR5762 -> tool:nanobot-harness-v3:call_01_1J8lDPMG7MEsLBoWFtwi0377 -> tool:nanobot-harness-v3:call_02_RFF9V8FJZ1EzjhdkNo7e9737 -> tool:nanobot-harness-v3:call_03_rCmL5Bo0EBUBrSX1TPZR4592 -> tool:nanobot-harness-v3:call_04_lSfydh4uXBwkOxBxHoXm7842 -> tool:nanobot-harness-v3:call_05_0PdXBEPGMFw34VC5KgYW9548 -> tool:nanobot-harness-v3:call_00_A3K1TB8PBh9Gz2pK9WeF4299 -> tool:nanobot-harness-v3:call_01_2wtkRslETS4M6IYCbECo9696 -> tool:nanobot-harness-v3:call_02_b1HaqlfcrQ0VqvVjvcZj3317 -> tool:nanobot-harness-v3:call_03_e8Oa0kOyzvOMALVgvFiZ6617 -> tool:nanobot-harness-v3:call_04_Z5OTJmvISJJ428uUJ8mf3041 -> tool:nanobot-harness-v3:call_00_jccRSNPeHZ9C64y4I9tJ3158 -> tool:nanobot-harness-v3:call_00_9yAvbTcrsJ1ij0mY36c72293 -> tool:nanobot-harness-v3:call_00_aYdsZll0Cx7JOSFwWJGK1532 -> tool:nanobot-harness-v3:call_00_VzEdsjNOP5oKjzi2wGWw0679 -> tool:nanobot-harness-v3:call_00_HN4XpBc51uWXhe3ArI578369 -> tool:nanobot-harness-v3:call_00_aGyCuNPy7gUlQS5m6rau6709 -> tool:nanobot-harness-v3:call_00_sFj9TcssLRCgHWePtsL09147 -> tool:nanobot-harness-v3:call_01_hjkDyEU7I487XLpila4Y7298 -> tool:nanobot-harness-v3:call_00_lH0wPtWgKSA3w6plZyia9804 -> tool:nanobot-harness-v3:call_00_Abv7uZm2AaIQslHHe78n8670 -> tool:nanobot-harness-v3:call_00_Dk1q2wHAPMdxrQS8P4yh0965 -> tool:nanobot-harness-v3:call_00_OSeiVN4JQ9Ar7a0ZSQGN1155 -> tool:nanobot-harness-v3:call_00_LSku95vZ1bV6tX1d2A1T3938 -> tool:nanobot-harness-v3:call_00_VVYxR4iumtXapOUJHGtR3531 -> tool:nanobot-harness-v3:call_00_dEDBDmHPJKSISUgK25ww2482 -> tool:nanobot-harness-v3:call_00_gqY7qPF0R9AXbKZx2Zbl2896 -> tool:nanobot-harness-v3:call_00_fjQPYmvmNJui2uI0ssoG0916 -> tool:nanobot-harness-v3:call_00_UWzTtNNovo1NDsjH8pAj7704 -> tool:nanobot-harness-v3:call_00_y0wWq5J0KC90oZjeqae77129 -> tool:nanobot-harness-v3:call_00_ViD6AfllYKewnKQrgvKG2959 -> tool:nanobot-harness-v3:call_00_opJ6o2hZQMlGi3XVfYnH4401 -> tool:nanobot-harness-v3:call_00_IwhMwBjhdQgKk0owctCD8548 -> tool:nanobot-harness-v3:call_00_TPZita96Z5pgmOpwvt8B5705 -> tool:nanobot-harness-v3:call_00_XYQvNQVMiFDNgZF4FkGK8698 -> tool:nanobot-harness-v3:call_00_d1NFOGJqryuRGuEu58Xi1494 -> tool:nanobot-harness-v3:call_00_QBJ8SIJmEABVAP0YJx3h2723 -> tool:nanobot-harness-v3:call_00_ALNOnPgFKPz0s507cke06204 -> tool:nanobot-harness-v3:call_00_Ui2tcx7dtV42fBPFPk7R3013 -> tool:nanobot-harness-v3:call_00_fOj8kSY7m0wf0BNZOxNX6158 -> tool:nanobot-harness-v3:call_00_f9rpsjwyYfvK4pYetXaf1604 -> tool:nanobot-harness-v3:call_00_51Ns4sazSPXCfEMbuY718387 -> tool:nanobot-harness-v3:call_00_yJZNvOCwYr9qdNEaGprr8726 -> tool:nanobot-harness-v3:call_00_qEEkgB5dtYuV3etLCN0J4036
- 关键路径耗时：0.894712
- Makespan：413.990687
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
