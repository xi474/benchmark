# Workflow 可观测性报告

- Trial：`C039__sS4hxdT__env`
- Task：`C039`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_VgLm3gv9XHp5ZsVCR7DX3169 -> tool:nanobot-harness-v3:call_00_f89Cxp8PaNk3Rwrbxsu45606 -> tool:nanobot-harness-v3:call_01_OEKNfqYxgx122uNmQ4vC5841 -> tool:nanobot-harness-v3:call_02_YFLjPOhs2zoBpHz9ijUa4697 -> tool:nanobot-harness-v3:call_03_OfKUlE48SIymqLvFMIhZ2602 -> tool:nanobot-harness-v3:call_00_UOsaq3HKxbczHegZk7DZ2381 -> tool:nanobot-harness-v3:call_01_CjuadS5JYskX23xzWcAu0555 -> tool:nanobot-harness-v3:call_02_sGeVjf4wWZEGuxseVwr07359 -> tool:nanobot-harness-v3:call_03_aZhmCSFv5TP0tBX1Om6m2035 -> tool:nanobot-harness-v3:call_04_aUtkc2uBc2wwgZrep3Ot6113 -> tool:nanobot-harness-v3:call_05_s8CWoHOrivzZBIhd0sCy5570 -> tool:nanobot-harness-v3:call_00_4y6adi97ffI4HR7XwGp64651 -> tool:nanobot-harness-v3:call_00_elMUWnk1BAWeCCehfOpM0384 -> tool:nanobot-harness-v3:call_01_LHOPMRHk0XKm5YmgT2Ej9612 -> tool:nanobot-harness-v3:call_02_mzJ2S4FA2DGnfY3mfKwr7886 -> tool:nanobot-harness-v3:call_03_18UJrZFje8mLp5fEyqCZ5005 -> tool:nanobot-harness-v3:call_04_XsUh2IzT30hgFVp8B8ST7646 -> tool:nanobot-harness-v3:call_05_8U0eF4eJha5cBKImamqW5527 -> tool:nanobot-harness-v3:call_00_TW2Zz74XhrUTb4LxkNcb8686 -> tool:nanobot-harness-v3:call_01_CVi1EQLj8WU5MuBkErfC7945 -> tool:nanobot-harness-v3:call_02_5uNqwMRiBWkLBPHbLAkv9107 -> tool:nanobot-harness-v3:call_03_RtdMDhKukPSx6wEdYq5D3272 -> tool:nanobot-harness-v3:call_00_PWm6pzPspLEfVNvgQnsL8328 -> tool:nanobot-harness-v3:call_01_LFFejCTdiigDxeVn93Yw9051 -> tool:nanobot-harness-v3:call_02_YJ2Y7FaVQGOVBod3pYOX7756 -> tool:nanobot-harness-v3:call_00_6KnUskuE8Obku7zg2wME1623 -> tool:nanobot-harness-v3:call_00_wmQO08shCtXua0mOLIEM8297
- 关键路径耗时：0.232528
- Makespan：504.932804
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
