# Workflow 可观测性报告

- Trial：`C049__xsJKzKF__env`
- Task：`C049`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_cZVtTIvwWQpz6VJ5GU6e0637 -> tool:nanobot-harness-v3:call_00_NL5AF4IFw7ZivXhCFCZs5057 -> tool:nanobot-harness-v3:call_01_GYru3NQQvu9i6oXNd5CJ3001 -> tool:nanobot-harness-v3:call_02_SHkyR7tZa2Qk0gMk6pi99639 -> tool:nanobot-harness-v3:call_03_J5HBtpXoFm4oDdmSCKWe6406 -> tool:nanobot-harness-v3:call_00_6HjaSLuMe1IScQwtRIrU7045 -> tool:nanobot-harness-v3:call_01_A0W3LXMMBtGW21wukr584062 -> tool:nanobot-harness-v3:call_02_hf6BAmU3sKvipFXCJK9I4099 -> tool:nanobot-harness-v3:call_03_3MoPxMC3WV7KzRczAX1s7465 -> tool:nanobot-harness-v3:call_00_o1d1SfvnRUEaefnANK542514 -> tool:nanobot-harness-v3:call_01_961mFg8LOoLgUz9H3YTt8299 -> tool:nanobot-harness-v3:call_02_YWbPZr2NBk3ASgZ6Dbzd5914 -> tool:nanobot-harness-v3:call_03_DE4OLuVipaBDdEIA9wly2485 -> tool:nanobot-harness-v3:call_00_x396FSxVppFzNYjCMKkO9299 -> tool:nanobot-harness-v3:call_01_Kv7yMooGhUHzaR9ZQ1y57633 -> tool:nanobot-harness-v3:call_02_zZUv0hwriPUlRkLXCwb33400 -> tool:nanobot-harness-v3:call_03_ypBl57cthVnwYqXk5rOM3560 -> tool:nanobot-harness-v3:call_00_tJGHiYcuBpFkjiCJDDna9347 -> tool:nanobot-harness-v3:call_01_xJxbMCKQzSQ7da3bqRz67773 -> tool:nanobot-harness-v3:call_02_IA4XS7hyWD6PGc6gqhZW2827 -> tool:nanobot-harness-v3:call_03_YiSFwtJU3QkprILnMj3P1120 -> tool:nanobot-harness-v3:call_04_0woztpq2UdsTYlB7GAPH3125 -> tool:nanobot-harness-v3:call_05_egLZszh5fJRG5bO1zFbh2306 -> tool:nanobot-harness-v3:call_06_6roI1w6oeFTwoX8VynKI0098 -> tool:nanobot-harness-v3:call_00_IUKIaHAy9YbaTwRcXptH7899 -> tool:nanobot-harness-v3:call_01_fLXfgfutk97Yw1Rur3CJ6612 -> tool:nanobot-harness-v3:call_02_5BBMdSxZe5As1VBcfc3I4563 -> tool:nanobot-harness-v3:call_00_JDXYYqKdJYO0JXbnIXg63833 -> tool:nanobot-harness-v3:call_00_gpeqeIeddg4dEQ9ERs3h3198 -> tool:nanobot-harness-v3:call_00_z5lV4lOBRNQpyhGxDavK5293 -> tool:nanobot-harness-v3:call_00_pDTHZCfJMXEaGBg7hgvr6795 -> tool:nanobot-harness-v3:call_00_v7FKxRyMbtmGTcxFwHqp6356 -> tool:nanobot-harness-v3:call_00_Kzy4Bzmy9pPHUwl37nAs6697
- 关键路径耗时：2.395779
- Makespan：98.830628
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
