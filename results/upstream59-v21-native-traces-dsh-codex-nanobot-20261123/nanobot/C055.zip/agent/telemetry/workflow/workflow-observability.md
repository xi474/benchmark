# Workflow 可观测性报告

- Trial：`C055__y6P3U5q__env`
- Task：`C055`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_bSv5ikLowhWTyz4UL05c4719 -> tool:nanobot-harness-v3:call_00_sihpr2vALjAVBa52tM1y4740 -> tool:nanobot-harness-v3:call_01_DF6lB2wuDN10jp6GI4qY7120 -> tool:nanobot-harness-v3:call_02_BBWV8PerwN7t78uE84x71676 -> tool:nanobot-harness-v3:call_03_GO0MfdmsgHq6Gh3kSsXI5955 -> tool:nanobot-harness-v3:call_04_u3ttp6gwPKJ7qZBdKfKU4858 -> tool:nanobot-harness-v3:call_05_5fslthjntECQVMn4eMb36381 -> tool:nanobot-harness-v3:call_06_bWyZlYiBiudqJz3MzVNj4039 -> tool:nanobot-harness-v3:call_07_nktv06rg1g6SZ4JBfJ3a3498 -> tool:nanobot-harness-v3:call_08_vPtPzmQU00OiDZkW9s0c6349 -> tool:nanobot-harness-v3:call_00_DyVSPHNgpHWbA7Dd5VJG7348 -> tool:nanobot-harness-v3:call_01_kRq3MPX8MmWRKtXheLPL2445 -> tool:nanobot-harness-v3:call_02_wJHUgd26W6FePrnGSG7u4973 -> tool:nanobot-harness-v3:call_00_eJRAPMjhxc6TSfzJGRIn9049 -> tool:nanobot-harness-v3:call_01_xQj9kmdzNhYGCZq7DTPl7037 -> tool:nanobot-harness-v3:call_02_AlWFdOlmiSo6l9WWeXP59788 -> tool:nanobot-harness-v3:call_03_0SQcAoWGoDZ8xzU5EXwz5909 -> tool:nanobot-harness-v3:call_04_hoVv1rBWa2VXv8j9sv7G6948 -> tool:nanobot-harness-v3:call_05_sRI2inCnAMTSoI5hKQAJ8295 -> tool:nanobot-harness-v3:call_06_JaIY6oFbpA0ZG9ogncwS8875 -> tool:nanobot-harness-v3:call_07_5Wt9bAC1gYhdpW6WfVgP0377 -> tool:nanobot-harness-v3:call_00_oIN4w6FEIdH96iPEZJ5O8314 -> tool:nanobot-harness-v3:call_01_2fE3Wowi1PlWV3Eub1QZ2041 -> tool:nanobot-harness-v3:call_02_XTo41N7nmplkVUUf0aIz5730 -> tool:nanobot-harness-v3:call_03_bBvsybpQUMgOU06aZHXu0765 -> tool:nanobot-harness-v3:call_00_WZRGXnzj4hupTJCchdkB8674 -> tool:nanobot-harness-v3:call_01_lSIyZRxgvOWpVOIK0Bmq6450 -> tool:nanobot-harness-v3:call_02_DRhyzS5D8BPMMZkzsJ396756 -> tool:nanobot-harness-v3:call_03_yuwmYMJevoqy8LqxyN244874 -> tool:nanobot-harness-v3:call_00_RDLLcRckGPI15mIraYfK9555 -> tool:nanobot-harness-v3:call_00_TtenKkN5yu1SbEsuBLpD3489 -> tool:nanobot-harness-v3:call_00_y745uSND93AgNuvczHyu2332 -> tool:nanobot-harness-v3:call_00_uLX9ziSTCFcsCcLnTNMc8033 -> tool:nanobot-harness-v3:call_00_HdlkSPB8agyHBkENVWVt4382 -> tool:nanobot-harness-v3:call_00_0BYhp3Rs37yt4n5QuohV3277 -> tool:nanobot-harness-v3:call_00_NKAkJD3vKdsPmThWwsx71223
- 关键路径耗时：0.442727
- Makespan：292.766672
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
