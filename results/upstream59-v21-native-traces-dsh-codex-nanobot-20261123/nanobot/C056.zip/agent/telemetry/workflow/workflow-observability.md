# Workflow 可观测性报告

- Trial：`C056__9JctFhF__env`
- Task：`C056`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_Klvd4zcW0FxJA349yUTr5928 -> tool:nanobot-harness-v3:call_00_Br35kHlrDa1HaDD9ezUy2392 -> tool:nanobot-harness-v3:call_01_YQqHQhLU2xQZ29GcNMw26588 -> tool:nanobot-harness-v3:call_02_aMpBytQYMzqdIUoi9hLd9652 -> tool:nanobot-harness-v3:call_03_5ywROUpFWz12ccLlC5kx8550 -> tool:nanobot-harness-v3:call_04_gZujnSjRgkU5KOyVEQuu3717 -> tool:nanobot-harness-v3:call_05_Z55uaJEBx7NFL9G53BgQ1421 -> tool:nanobot-harness-v3:call_06_LB9wjbaEActekz0KVigV1681 -> tool:nanobot-harness-v3:call_07_bov4J1Gb4vpPsASh5UkU4551 -> tool:nanobot-harness-v3:call_08_dvLYQrT9VOTUfALxEu8K1112 -> tool:nanobot-harness-v3:call_00_gDHZpmU3CJqJMh3aJFIM3447 -> tool:nanobot-harness-v3:call_01_W3Oajz2t24h8OpVCLmHa6669 -> tool:nanobot-harness-v3:call_02_F1O1yC6zIkBTkNylBf7k7300 -> tool:nanobot-harness-v3:call_00_OCoaAiVCwnbU2hCx9EyY2623 -> tool:nanobot-harness-v3:call_01_ykFxRiM6AAuvyW3yA77H6164 -> tool:nanobot-harness-v3:call_02_9a0S93zy173fxxuiXC0i4501 -> tool:nanobot-harness-v3:call_03_OU6xrCrJGuJXSfuor9M91760 -> tool:nanobot-harness-v3:call_04_pzE1WKBLyiwTZRxbVFrT2281 -> tool:nanobot-harness-v3:call_05_4dEY8YGgiLg6F4Rl9nAl2636 -> tool:nanobot-harness-v3:call_06_rVirZ9eIh2ipsx6xUxBK3043 -> tool:nanobot-harness-v3:call_00_qomdlqAF9t0YnNQZXfpc0441 -> tool:nanobot-harness-v3:call_01_cSBgxE9byE7KcmkEHsOE1425 -> tool:nanobot-harness-v3:call_02_Ml8gSvaM7arKJPz6cZ7O7643 -> tool:nanobot-harness-v3:call_03_OQz88hNMu6qJ0agnpObz8736 -> tool:nanobot-harness-v3:call_00_oA1EWUmIMUK6q3gcr0uM5899 -> tool:nanobot-harness-v3:call_01_3E0Bb0xaD1tAhmTRUtba9254 -> tool:nanobot-harness-v3:call_00_fsBcqUUavOID9qNga0y32714 -> tool:nanobot-harness-v3:call_00_vR03WuOlo7lqbqoTlVwd3340 -> tool:nanobot-harness-v3:call_00_Vg4hqUOBjtGxF9BogtxD0331 -> tool:nanobot-harness-v3:call_00_8uFe7yl34VDw4rFQiEY21128 -> tool:nanobot-harness-v3:call_00_jJJbbPvX5IBstT4g0Ag88573 -> tool:nanobot-harness-v3:call_00_Wl50OJonqJImnhuCDZmv2205 -> tool:nanobot-harness-v3:call_00_yAZUEp3YodlaTsf0n4dg5305 -> tool:nanobot-harness-v3:call_00_JYBuqGzl9r8qGuq26SgD8179
- 关键路径耗时：0.287777
- Makespan：151.646252
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
