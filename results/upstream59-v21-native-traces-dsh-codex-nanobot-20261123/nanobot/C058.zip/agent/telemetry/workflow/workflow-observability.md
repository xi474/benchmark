# Workflow 可观测性报告

- Trial：`C058__WvDZXTK__env`
- Task：`C058`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（32 节点 / 31 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：32；执行边：31（observed=0，inferred=31）
- Execution Trace Graph：`observed`；temporal_next 边 31，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_oVVlJG2mSqLp2IVzUC6y2735 -> tool:nanobot-harness-v3:call_00_ESbC8RGVuWIebSHJGWE60498 -> tool:nanobot-harness-v3:call_01_PnphHidMzppiJzFBFqqc3828 -> tool:nanobot-harness-v3:call_02_KIKryhMjhDSB3rAiFhYZ8090 -> tool:nanobot-harness-v3:call_03_Gqmt8IRsLxy0K27LHM4g6144 -> tool:nanobot-harness-v3:call_00_OlCuPJf1g6enxPfxq0Ql7620 -> tool:nanobot-harness-v3:call_01_cUYqFtsGvI3GrsQSBQ3w6240 -> tool:nanobot-harness-v3:call_02_EoV0Lqd6vplZbM2EnmmA0189 -> tool:nanobot-harness-v3:call_03_CieMCdMwyHYFOKshKcmL8580 -> tool:nanobot-harness-v3:call_00_Pqh5rLQw8MMlaZKGq6kG0875 -> tool:nanobot-harness-v3:call_01_ltER1BXY5ZJs3HjayDW19895 -> tool:nanobot-harness-v3:call_02_cbF7zFLu5Eh1YRAYo17P8300 -> tool:nanobot-harness-v3:call_03_rPgtUu6Gb0czW8RMutd23228 -> tool:nanobot-harness-v3:call_00_94ljmGq7UqArDC4e8m3S7423 -> tool:nanobot-harness-v3:call_01_aKWIZqhIET8tWRXv9Quj6356 -> tool:nanobot-harness-v3:call_02_dA4HMYX32IEIDuFM6NZx0984 -> tool:nanobot-harness-v3:call_03_Z4P04wVnGZnkSgp8jkjZ2456 -> tool:nanobot-harness-v3:call_00_Knn9uH6860li7UxuRmbl1494 -> tool:nanobot-harness-v3:call_01_ECPzjAqgnhRrz4OD41kN1699 -> tool:nanobot-harness-v3:call_00_xonpSmVVbYdWCcsUVkHP6120 -> tool:nanobot-harness-v3:call_01_029xy9wsu6RFbm2dsGYr6667 -> tool:nanobot-harness-v3:call_02_sBybBKDM71SyJ4u953bI6112 -> tool:nanobot-harness-v3:call_03_4TRvqq46z2o0KwiKUxi51582 -> tool:nanobot-harness-v3:call_04_K9vSC29gtH7paQrFq5FP8080 -> tool:nanobot-harness-v3:call_00_YNX9rtMTGpVXL8DdiFHt9145 -> tool:nanobot-harness-v3:call_01_DRRLrSbYpdGntqzkgYak7277 -> tool:nanobot-harness-v3:call_02_NO5rKnJybYfS3h18ldK29953 -> tool:nanobot-harness-v3:call_03_wa2Bo6ynGcz5RltMKWNw5268 -> tool:nanobot-harness-v3:call_04_8PR1YrQTELhuzrwMKOsg9610 -> tool:nanobot-harness-v3:call_00_HZDbCWlja3ErXwtzFOB25792 -> tool:nanobot-harness-v3:call_00_xrcSQdmCWKy708zlGHjX2021
- 关键路径耗时：0.02067
- Makespan：452.623292
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
