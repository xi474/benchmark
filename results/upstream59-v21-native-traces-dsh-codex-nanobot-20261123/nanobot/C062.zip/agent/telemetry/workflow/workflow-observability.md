# Workflow 可观测性报告

- Trial：`C062__3SopB9h__env`
- Task：`C062`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_YIFiyA7EwW7ZWuHVZsFW2040 -> tool:nanobot-harness-v3:call_00_xr6MxLLDNuradbRJ0MFz4989 -> tool:nanobot-harness-v3:call_01_4RNx7sieDc1VH8PvI06x9760 -> tool:nanobot-harness-v3:call_02_ZVY6Pln9toQaExHIMuEZ0601 -> tool:nanobot-harness-v3:call_03_myhnv4Z2kveAl5zQglRu0792 -> tool:nanobot-harness-v3:call_00_7nqta2KxpXrGjFs3jR5F3973 -> tool:nanobot-harness-v3:call_01_67P4l1vwJ9b8BDd1IHU61933 -> tool:nanobot-harness-v3:call_02_FFxMFwPqPUqFbVSjumea3311 -> tool:nanobot-harness-v3:call_03_AzrDMZS7eIJICDCDcnVO1742 -> tool:nanobot-harness-v3:call_04_mwPJURu0SoN8SfqM4ZBP3038 -> tool:nanobot-harness-v3:call_00_MjmKkLuDyZmPHhn64GOB9760 -> tool:nanobot-harness-v3:call_01_03Yfi44aZWSZWqhue8Mn2602 -> tool:nanobot-harness-v3:call_02_Ct3fLfvWDs1oEfnWQikX0492 -> tool:nanobot-harness-v3:call_00_f2Mj8Tb7DnzyrRH4O23Q1330 -> tool:nanobot-harness-v3:call_01_HNbSvHXUm8gj359HaziT6336 -> tool:nanobot-harness-v3:call_02_fNU2SqU0PgCXX21xJ6Qz9812 -> tool:nanobot-harness-v3:call_03_84KK0xJLOulZcYjh5qa30595 -> tool:nanobot-harness-v3:call_04_eeraipfSeTxTBxTkaclL6164 -> tool:nanobot-harness-v3:call_05_xl84OwInYwdRi6z7x49h0645 -> tool:nanobot-harness-v3:call_00_cJL8UaTDmTJbKOz8o9zP3840 -> tool:nanobot-harness-v3:call_01_gYmFd6FOZ91bbBZrfMi26100 -> tool:nanobot-harness-v3:call_02_4984btcL4TjSiQHYoqx58532 -> tool:nanobot-harness-v3:call_03_8YiG2ADu6JYsobqIosnK7311 -> tool:nanobot-harness-v3:call_04_PdvSXn3EEG86AdbleXu62397 -> tool:nanobot-harness-v3:call_05_ssvhtSD9PYB1GMj0SRoH0954 -> tool:nanobot-harness-v3:call_00_tp8RCdBmMAmFBg0P6t2H4490 -> tool:nanobot-harness-v3:call_01_GCBfAquSaAn9xtdhLW7f9642 -> tool:nanobot-harness-v3:call_02_DuG92uvszv8iuUor4T7C0420 -> tool:nanobot-harness-v3:call_00_xhmc53yMRuv6y4kuQIzY0741 -> tool:nanobot-harness-v3:call_00_9XjhOK8WechNctLeTBq57982 -> tool:nanobot-harness-v3:call_00_pBsGenNwX0anT1ohMPXK7452 -> tool:nanobot-harness-v3:call_00_86h1wVfpMsvR9Ug5Uwm51451 -> tool:nanobot-harness-v3:call_00_u7KNvh4p5IQRg6J3iHmu3714 -> tool:nanobot-harness-v3:call_00_PRoQznA6wuuLpEZ5MY8m9160
- 关键路径耗时：0.259526
- Makespan：173.271823
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
