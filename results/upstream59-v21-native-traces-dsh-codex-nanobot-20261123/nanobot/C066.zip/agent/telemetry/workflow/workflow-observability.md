# Workflow 可观测性报告

- Trial：`C066__WURrfF4__env`
- Task：`C066`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_xZ8pN1hF2JgyLTTA2vnX8216 -> tool:nanobot-harness-v3:call_00_iEjJEeGgUYrAHgDIr91e8630 -> tool:nanobot-harness-v3:call_01_8Jn6qxIFf0xMkdD7dEN78269 -> tool:nanobot-harness-v3:call_02_wmyp7lb94kh7CLRQsu3h1536 -> tool:nanobot-harness-v3:call_03_al8Fjxn4ONtHDdq9UMhr2355 -> tool:nanobot-harness-v3:call_04_euTCUSwpWzjHFmAkdNbl3029 -> tool:nanobot-harness-v3:call_05_6IlgAjFhzqUSuMZFjNDJ4598 -> tool:nanobot-harness-v3:call_00_uHg3yH3ioGkiBhRa7c2a8770 -> tool:nanobot-harness-v3:call_01_7WYHZo4XnQ6Wa9D4ehnF5545 -> tool:nanobot-harness-v3:call_02_SjZEhA1vDmHiN7LO2eWy2901 -> tool:nanobot-harness-v3:call_03_3ffwnhqxyC2xOTyULrDZ6895 -> tool:nanobot-harness-v3:call_04_RveongtglDGoJDz7mr2p4396 -> tool:nanobot-harness-v3:call_00_80dFRbx63No8CXvHOYeN6123 -> tool:nanobot-harness-v3:call_00_qtraxpiaqe43Y74yDRx77482 -> tool:nanobot-harness-v3:call_01_lmMF3VuvzSCQabD8509N0308 -> tool:nanobot-harness-v3:call_02_xuA5uoSVse8ZdlghYiNS3039 -> tool:nanobot-harness-v3:call_03_eNdk30IXCU6eRVXG21GQ8869 -> tool:nanobot-harness-v3:call_04_mrvDe397AEMwczhyXeRC6792 -> tool:nanobot-harness-v3:call_05_tdDi6t00Sj4opnfc4Oa23456 -> tool:nanobot-harness-v3:call_00_NrYxidv3xlfFJqPFTMpW0546 -> tool:nanobot-harness-v3:call_01_W5jk2AEtZl80hqy2VWS18914 -> tool:nanobot-harness-v3:call_02_OFYyZVHIdDqqWB5FE68E2108 -> tool:nanobot-harness-v3:call_03_XiDAj5xZExPslGqA97OJ1715 -> tool:nanobot-harness-v3:call_04_mT8YwP7XQ81yBZohApof0012 -> tool:nanobot-harness-v3:call_05_QM65COW4uyI5p5s2cgXd9763 -> tool:nanobot-harness-v3:call_00_zU87IwbkNZXBzVwsHYKr8145 -> tool:nanobot-harness-v3:call_01_S2xmuuWFBIe4y8RStKtL8216 -> tool:nanobot-harness-v3:call_02_Agcz79o5nHPzpIESfm6K5046 -> tool:nanobot-harness-v3:call_00_RVv7WsXrvpR6DCCbD6yn3698 -> tool:nanobot-harness-v3:call_00_frer2XUwn3PGI227Em055983 -> tool:nanobot-harness-v3:call_00_RyrRJ2joa7HdeU7YuHy10783 -> tool:nanobot-harness-v3:call_00_4415emxEuOCftDRvLwur3147 -> tool:nanobot-harness-v3:call_00_dEog7chI5sLVGRhb9Xxc7468 -> tool:nanobot-harness-v3:call_00_PnELQ7ul91r1QJ8MfdEf5268
- 关键路径耗时：0.249136
- Makespan：251.501232
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
