# Workflow 可观测性报告

- Trial：`C067__paNXraG__env`
- Task：`C067`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_hjaMaMscaME32P4NPe5a3427 -> tool:nanobot-harness-v3:call_00_S57kQYnQywwTvEtuSo0x2209 -> tool:nanobot-harness-v3:call_01_Np3xVAP0XxDDbqg3xps15350 -> tool:nanobot-harness-v3:call_02_gu31KUuvZKcUUwY1NPm84737 -> tool:nanobot-harness-v3:call_03_X0UGnAkmi8laRceD2ROK4403 -> tool:nanobot-harness-v3:call_00_oDveIj2AprX3UMjFk8Cs0721 -> tool:nanobot-harness-v3:call_01_J98YGSdrYa45ErMjiA2C5294 -> tool:nanobot-harness-v3:call_02_IEDu3KVCfeeiRfwb3KMk9888 -> tool:nanobot-harness-v3:call_03_5Ns4fIRh9hzuCGZJu6zK7423 -> tool:nanobot-harness-v3:call_04_fH0ZCDgKmQkKPrkfbP0e5451 -> tool:nanobot-harness-v3:call_00_SieznxF6SMgqg33uZ4M69220 -> tool:nanobot-harness-v3:call_00_gwjJs0sBYKRzzwWMwfUM3682 -> tool:nanobot-harness-v3:call_01_l2DcoX8rSNWBWSuurVz00936 -> tool:nanobot-harness-v3:call_02_TDZazFG8GEc4ShNhtZJR1792 -> tool:nanobot-harness-v3:call_03_kq15H1wgo0ItrviliNMs9511 -> tool:nanobot-harness-v3:call_04_uf3nqCKkvnOSazhd28ST5451 -> tool:nanobot-harness-v3:call_05_5JNUhk2mlVCCOktgbmer0912 -> tool:nanobot-harness-v3:call_00_BidmXrs3ZDCuFT6ZMpv35249 -> tool:nanobot-harness-v3:call_01_ZZku2rEUb93wodMhIdq79303 -> tool:nanobot-harness-v3:call_02_WorZ2OZZP1ZD92fOAE3l0161 -> tool:nanobot-harness-v3:call_03_w2FfrgJLaXUMgQO0D8qT3648 -> tool:nanobot-harness-v3:call_04_70NFnrlLzwcEsoToBTUy1574 -> tool:nanobot-harness-v3:call_05_LNnaB7QXqxjy4rhN278Q1205 -> tool:nanobot-harness-v3:call_00_y8eTn2R5et2Efs4dDAXG7523 -> tool:nanobot-harness-v3:call_00_tU9EyVuhr3WnVC6ZXEo23354 -> tool:nanobot-harness-v3:call_01_DEioQGHma4gc1Mc72fRb1897 -> tool:nanobot-harness-v3:call_02_YBGx7h7YnAdrK0dIznnp0063 -> tool:nanobot-harness-v3:call_00_xmbpQX7JM4jygk21aFGX1462 -> tool:nanobot-harness-v3:call_00_0dFmeBrXH7YjTAqkdlkq2560 -> tool:nanobot-harness-v3:call_00_B08L9eBaZXrtB7TUtIEi3311 -> tool:nanobot-harness-v3:call_00_PY4ztUE9sqHW1ZARA69Q4190 -> tool:nanobot-harness-v3:call_01_iYv5tridWGO9XlbxzTD43882 -> tool:nanobot-harness-v3:call_00_Gq31GADIcZur91cKg3Qn0057 -> tool:nanobot-harness-v3:call_00_2cwCNfwvlFa1qjTEXTPY2583 -> tool:nanobot-harness-v3:call_00_8BaTV0MUnnggttjqrDet5109 -> tool:nanobot-harness-v3:call_00_VlgsKKNUqHZBvJTQddvt7123 -> tool:nanobot-harness-v3:call_00_BYp7ZHTfZT28dcQLqdtM0990 -> tool:nanobot-harness-v3:call_00_7SLKMOSHUnrENPYyGd5S4503 -> tool:nanobot-harness-v3:call_00_WPDPUWFUpffjecsoFWp13877 -> tool:nanobot-harness-v3:call_00_3VRmre4qqlhHi0q8Q9PK3311 -> tool:nanobot-harness-v3:call_00_z7Reo6Cha1WSrKdZYjlY6128 -> tool:nanobot-harness-v3:call_00_3TzGKbyaP4sNo0aNBVrb2290 -> tool:nanobot-harness-v3:call_00_y76SV1tWcOh34ZMTgklT4842 -> tool:nanobot-harness-v3:call_00_k8gAd2LJMZEzchGk8ild5705 -> tool:nanobot-harness-v3:call_00_RfCVHRI44iamFHBdvKtp2417
- 关键路径耗时：0.559991
- Makespan：162.862876
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
