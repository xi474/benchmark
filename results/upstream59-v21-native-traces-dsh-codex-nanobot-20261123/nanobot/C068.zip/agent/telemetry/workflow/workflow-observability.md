# Workflow 可观测性报告

- Trial：`C068__4gvXm8U__env`
- Task：`C068`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（43 节点 / 42 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：43；执行边：42（observed=0，inferred=42）
- Execution Trace Graph：`observed`；temporal_next 边 42，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_Hol4CJqlR5d78mQBmgaH8614 -> tool:nanobot-harness-v3:call_00_oo1DMwYY75GnPJX0mjoS0436 -> tool:nanobot-harness-v3:call_01_IF6UWaRGuT9mkFwDO2TJ4675 -> tool:nanobot-harness-v3:call_02_nc3LByDNV4KOP8RWcLXu7447 -> tool:nanobot-harness-v3:call_03_RDltofdmLEuJ0YL4ofYS5508 -> tool:nanobot-harness-v3:call_00_ViTvuyFe6eYsX1XKPINX9863 -> tool:nanobot-harness-v3:call_01_8EDChUYDvk7HA2UwL5Kv9868 -> tool:nanobot-harness-v3:call_02_wZcyIZVShGAYsuTFQIMW4042 -> tool:nanobot-harness-v3:call_03_7aPQzoiepkg0h9cF1vyd8490 -> tool:nanobot-harness-v3:call_00_5AK5b0tnlzrKSTy0tIrp7948 -> tool:nanobot-harness-v3:call_00_ZN8pQvXst3pCA7oiQyHX7580 -> tool:nanobot-harness-v3:call_01_BwkJORbY7jpA96RrWWGp7424 -> tool:nanobot-harness-v3:call_02_knGlW7EyDRdbJ64KgXjt8179 -> tool:nanobot-harness-v3:call_03_W1oE34ZqkfXo443pBP0h0207 -> tool:nanobot-harness-v3:call_04_MDPwWIAcyUr0QU450lhD3958 -> tool:nanobot-harness-v3:call_05_ztMASZ08181PkUdTEQhw9933 -> tool:nanobot-harness-v3:call_00_GmBqxUjg6zOVrkyAP81g9141 -> tool:nanobot-harness-v3:call_01_EZpjbixOUdSzHGOaU5FW7600 -> tool:nanobot-harness-v3:call_02_KDWn3gkBKqEg0vq8GIz49503 -> tool:nanobot-harness-v3:call_03_NDO9VJDoruMJCoHRgnEh9700 -> tool:nanobot-harness-v3:call_04_4DuXfHoiCNzVeeYcHZCK9929 -> tool:nanobot-harness-v3:call_05_e6ETbuyVvSzvIkgqzIBv9163 -> tool:nanobot-harness-v3:call_06_H2bc9zmo5sXl1kwue8yq0968 -> tool:nanobot-harness-v3:call_00_TyJKRVnuycD8FhemMYRe2616 -> tool:nanobot-harness-v3:call_01_CosFrRRZoTIFO2xTRGZN2411 -> tool:nanobot-harness-v3:call_02_GXbb7A1zZZxAGkGfe8UH9072 -> tool:nanobot-harness-v3:call_00_ApCy1SM0AUwNrwF9xx2R7037 -> tool:nanobot-harness-v3:call_00_1nWyQJHP0f7FH6dOXi5B7332 -> tool:nanobot-harness-v3:call_00_zHh94k2xhSV4PKzIVAx11033 -> tool:nanobot-harness-v3:call_00_BH5d7yjLXTk0hi5mcHQJ9557 -> tool:nanobot-harness-v3:call_00_yqnyv9HvFQuv2hCvtEYq9676 -> tool:nanobot-harness-v3:call_00_rtWHSTkypBlTwBSc9zQ63674 -> tool:nanobot-harness-v3:call_00_brnqLUU4WZeRmESjpFYO9827 -> tool:nanobot-harness-v3:call_00_Yb47fx85VGQcPPropbal2308 -> tool:nanobot-harness-v3:call_00_RBnfTIOkIzgMnWXYXIvC6084 -> tool:nanobot-harness-v3:call_00_9ZtwusW7e5Ncg3PWOA8n9480 -> tool:nanobot-harness-v3:call_00_uoEQYbOtQzqL3LO77QUZ0929 -> tool:nanobot-harness-v3:call_00_uVfLNIoOqKZIUCRCUlS24870 -> tool:nanobot-harness-v3:call_00_bYmDbbJmoelZ9NJ2WVGJ6197 -> tool:nanobot-harness-v3:call_00_fKbXxABlPj96nvq4Bh2s1587 -> tool:nanobot-harness-v3:call_00_JHeU51BxOf1ktgmX7GnU3920 -> tool:nanobot-harness-v3:call_01_2ygHABo3ZoLBBj2MfHwH9306
- 关键路径耗时：0.497046
- Makespan：327.456917
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
