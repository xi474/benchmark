# Workflow 可观测性报告

- Trial：`C069__phQUszA__env`
- Task：`C069`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（58 节点 / 57 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：58；执行边：57（observed=0，inferred=57）
- Execution Trace Graph：`observed`；temporal_next 边 57，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_SZ7Zx64Q9icfJxdCwFzb9411 -> tool:nanobot-harness-v3:call_00_YyDq0GQcGqzoyXSiQcwR8056 -> tool:nanobot-harness-v3:call_01_PzMUyRmfJMR9l8FRXo4E4220 -> tool:nanobot-harness-v3:call_02_Ck1kamOChDCslIcMMrdu8884 -> tool:nanobot-harness-v3:call_03_rJTpo6CceV84pnOkQAXs7420 -> tool:nanobot-harness-v3:call_00_EnFMxpTxkNECnhRo9n0r2290 -> tool:nanobot-harness-v3:call_01_s9n0rjzxhlKs63vDy3xF6911 -> tool:nanobot-harness-v3:call_02_1DlzYm1ysXNG3XD7BpRC4858 -> tool:nanobot-harness-v3:call_00_p83ZjKD7AsoxzhCZDw591814 -> tool:nanobot-harness-v3:call_01_2EXk6Jv3yu3Scl9zEedS3694 -> tool:nanobot-harness-v3:call_02_Xuqgvht74WnAy0gE5wQj1596 -> tool:nanobot-harness-v3:call_03_cdek2Sl8dtJi4nLnonsY9296 -> tool:nanobot-harness-v3:call_04_NPlJVzMLxbwQ3Havhq7R0824 -> tool:nanobot-harness-v3:call_00_u0jNgLAGpjsiuOUEiXau5637 -> tool:nanobot-harness-v3:call_01_OtqgfUsrHc2cZsBKSSQW4012 -> tool:nanobot-harness-v3:call_02_rnEciMFv3jdfQM9jVsHM8834 -> tool:nanobot-harness-v3:call_03_Oq9BoiKqEagfK1JauZXt9936 -> tool:nanobot-harness-v3:call_04_hVQLIqTEFTOGktbh07Ee0695 -> tool:nanobot-harness-v3:call_05_7eb9mnm4SK4tj3qqZSjb8942 -> tool:nanobot-harness-v3:call_00_UYwF521bFN0zs6HFfyvC7141 -> tool:nanobot-harness-v3:call_01_gdV8ouVreLunLyQN9i5j3983 -> tool:nanobot-harness-v3:call_02_t9RpoHbm4CYLg78pN0eQ0828 -> tool:nanobot-harness-v3:call_03_sgBUVsy0Ghfagx62sDtw9349 -> tool:nanobot-harness-v3:call_04_fZQ45jkhUe41LwRriR0e0688 -> tool:nanobot-harness-v3:call_00_nrFplmBQnBQjHVePHBXu9015 -> tool:nanobot-harness-v3:call_00_013KVxhd5KVGOrdBuchJ5023 -> tool:nanobot-harness-v3:call_00_W25I2DlnJCj9WrUzLKy69543 -> tool:nanobot-harness-v3:call_01_5hag1bnb90MueMJNIZxw2417 -> tool:nanobot-harness-v3:call_00_oflNhuQ7W3glQCDohQNQ7499 -> tool:nanobot-harness-v3:call_00_i8vFlN6RRL2kfiIcQj8q3327 -> tool:nanobot-harness-v3:call_00_FCcfbK3osenhJO7TkGCQ7957 -> tool:nanobot-harness-v3:call_00_5miIpHZuBsxb73cKfp1d5560 -> tool:nanobot-harness-v3:call_01_exjsfyXAT9k3fao7uSZV1668 -> tool:nanobot-harness-v3:call_00_pOKQnW1ljYcvWGDJ98kl8569 -> tool:nanobot-harness-v3:call_00_zmTmDzueWJNXJ7RP1Uoq9140 -> tool:nanobot-harness-v3:call_00_11F6Uru5LuR4Zyq1cLGr9959 -> tool:nanobot-harness-v3:call_01_b2sP8sGkndPqbG9WLA4J9642 -> tool:nanobot-harness-v3:call_02_LMPkoKynPlcYeEgWLiP28320 -> tool:nanobot-harness-v3:call_03_35yDxk14S0olmc0ILkmt1072 -> tool:nanobot-harness-v3:call_00_ZfqSW6VchmkH0JEnCzK24284 -> tool:nanobot-harness-v3:call_01_d6A2Zmo3sW8ZcSGc40Nr2532 -> tool:nanobot-harness-v3:call_02_tO8nYH7IlpP4Ssuze1ku4027 -> tool:nanobot-harness-v3:call_03_BPaSPcZT92JrRH4flPUK6679 -> tool:nanobot-harness-v3:call_00_eRD8zGkWwZn4TF9g1whJ2807 -> tool:nanobot-harness-v3:call_01_1W90BFFWZCm9DXvcPBsZ1444 -> tool:nanobot-harness-v3:call_02_C1syQsHJwfa9QhdBe5ds4311 -> tool:nanobot-harness-v3:call_03_EEHE9vrCYS3SUVnSv70g0740 -> tool:nanobot-harness-v3:call_04_qxtwkgMC5SMpARnbNQXM7763 -> tool:nanobot-harness-v3:call_05_HErdwfMDXcWxPnX5YHxU0421 -> tool:nanobot-harness-v3:call_00_YvGSjXkvGxzlYst93TFV4150 -> tool:nanobot-harness-v3:call_01_eeiqCmsAFF9V6ot4ndDl5698 -> tool:nanobot-harness-v3:call_02_p9m4QWDTk2foq5TUfmpM1162 -> tool:nanobot-harness-v3:call_00_O5efqxBDfSyMo3I1lRxQ4713 -> tool:nanobot-harness-v3:call_01_roRI5Jtlry88MT57jq2O8262 -> tool:nanobot-harness-v3:call_02_wEMrce54NaqFzCPYNbjU7150 -> tool:nanobot-harness-v3:call_00_rZSFJxZuv9z1uLtgDJXz8648 -> tool:nanobot-harness-v3:call_00_1YrwEMtq6xER8Zc9lD3g5688
- 关键路径耗时：0.266236
- Makespan：571.935675
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
