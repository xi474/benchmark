# Workflow 可观测性报告

- Trial：`C074__RS4VbfU__env`
- Task：`C074`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_o4Uh0XFoGkHzkKaztvtP2151 -> tool:nanobot-harness-v3:call_00_D8B0lngnpjbPE6KLjJJk4252 -> tool:nanobot-harness-v3:call_01_mhzVkDFyGQKPJsUhlfMg5080 -> tool:nanobot-harness-v3:call_02_9QdJgtm3O2ZjKHHVGuru4419 -> tool:nanobot-harness-v3:call_03_sIBHdD5S016SS3pnL3Pr9213 -> tool:nanobot-harness-v3:call_04_UlsZNAgr8DHOPByQjxUP4531 -> tool:nanobot-harness-v3:call_05_LEniH61vGhhviKuitbYG7340 -> tool:nanobot-harness-v3:call_06_VzAKjZRV1qV123mZ0FA12561 -> tool:nanobot-harness-v3:call_07_OWwfJocxSvAYQcJgHwUd4804 -> tool:nanobot-harness-v3:call_08_E3DuZG4gd8gx87DI9ZIw4749 -> tool:nanobot-harness-v3:call_00_sNBDFLuSxScNvv8CDcRE6940 -> tool:nanobot-harness-v3:call_01_h2kKh0AJxtIpSxy3YjB43949 -> tool:nanobot-harness-v3:call_02_VCGPb3L4Bzo4rSZv3rJW2765 -> tool:nanobot-harness-v3:call_00_HF7JMp3yGaYLSdcTIqm24837 -> tool:nanobot-harness-v3:call_01_gZ3LduiHUdReEmjlOPy21725 -> tool:nanobot-harness-v3:call_02_WYeXzaDy9QCV0gWdKBqk1915 -> tool:nanobot-harness-v3:call_03_DuKRAniWaA5V7T9vGNQX9687 -> tool:nanobot-harness-v3:call_04_w8WB9RHXFyCpJ3C1Wq4M3140 -> tool:nanobot-harness-v3:call_05_DXHBJIl8zxYnhs4Kd51B1464 -> tool:nanobot-harness-v3:call_06_EcoORNIHqcSHGfY6HHuZ5445 -> tool:nanobot-harness-v3:call_07_Cn7EtKOfTLFbajftSZVr0286 -> tool:nanobot-harness-v3:call_08_LaEMxcq0JswNT89JF7hK9508 -> tool:nanobot-harness-v3:call_09_6ll3KjybQsbJPlhPJ4wm6225 -> tool:nanobot-harness-v3:call_10_GSMtMXvEXaDxVKqVJ5ws5101 -> tool:nanobot-harness-v3:call_11_fant4MrVe4aEu0mN77Dm0747 -> tool:nanobot-harness-v3:call_00_TOHJ8BmyzUx36kI0DBH97069 -> tool:nanobot-harness-v3:call_01_gUvnCSeIYHFNZbqn4R5H7436 -> tool:nanobot-harness-v3:call_00_1xGZTrMEn4xR2jvI7iup2487 -> tool:nanobot-harness-v3:call_00_mdvUK2k7kg1ZYl4EkFAk8874 -> tool:nanobot-harness-v3:call_00_83LbzFWTIYp15Nfr1TVd6958 -> tool:nanobot-harness-v3:call_00_525b1FjByqhUM6oSXci71285 -> tool:nanobot-harness-v3:call_00_l3lgSbPw4HUporZZuJ8k5861 -> tool:nanobot-harness-v3:call_00_Ss9z9zw46wnZu9XsC9vm0418
- 关键路径耗时：0.293816
- Makespan：233.951117
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
