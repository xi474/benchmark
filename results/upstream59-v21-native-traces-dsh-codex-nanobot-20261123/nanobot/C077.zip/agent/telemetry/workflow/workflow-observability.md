# Workflow 可观测性报告

- Trial：`C077__KXutcdQ__env`
- Task：`C077`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_e58YXcQtSq3wurRkSHXH2710 -> tool:nanobot-harness-v3:call_00_GhGm2jJcsUcmisDmUo2V1673 -> tool:nanobot-harness-v3:call_01_lKmHpeSROSukxocB95gs7179 -> tool:nanobot-harness-v3:call_02_Gwg9mIJ07ZJbQmM562rv9548 -> tool:nanobot-harness-v3:call_03_6zqNI9y9TVBF6js3c7rW4256 -> tool:nanobot-harness-v3:call_00_vGRl8slM4I2iLo7Y1zNe9450 -> tool:nanobot-harness-v3:call_01_Y6UfwPi6XFmxCV3BP38Z5107 -> tool:nanobot-harness-v3:call_02_bWL4i1SBkA2QzpVL17eu1918 -> tool:nanobot-harness-v3:call_00_baOCWXYbf73PThcNLPQm5087 -> tool:nanobot-harness-v3:call_01_shSjUmgiFHKLE9N6xCAi3956 -> tool:nanobot-harness-v3:call_02_gpjuvnRk0PIm2uKAuoUR5478 -> tool:nanobot-harness-v3:call_03_U6vQm6BMoGZS0KrcVmkz5447 -> tool:nanobot-harness-v3:call_04_PA021Dt9Po2hsKqA0Qtt0897 -> tool:nanobot-harness-v3:call_00_rTrJgb2kFKIJbac9rDJA7965 -> tool:nanobot-harness-v3:call_01_oE9S3eJ85pss84t7mEKf5998 -> tool:nanobot-harness-v3:call_02_w19aWZgZKLl228QcfdNB1744 -> tool:nanobot-harness-v3:call_03_1cySxjUK1R4gNaCQ9Lr19682 -> tool:nanobot-harness-v3:call_04_1YouCLsD0Oi67IWe0V0L4913 -> tool:nanobot-harness-v3:call_05_Af3ksODaidBHgqZpxrrK3142 -> tool:nanobot-harness-v3:call_00_j3XmdeDt3DwFi8aApnGn3820 -> tool:nanobot-harness-v3:call_01_UHcLPdIOTZu2l5X2ATKw3952 -> tool:nanobot-harness-v3:call_02_Vt0SlCRuxNQE8ajuR3Im8807 -> tool:nanobot-harness-v3:call_03_zFJ8bjuN89JYTs7wWrB95733 -> tool:nanobot-harness-v3:call_04_WzCtnaZ890A068t6JZWj4121 -> tool:nanobot-harness-v3:call_00_LqCwBGz1DoQqsIgdhJK84855 -> tool:nanobot-harness-v3:call_01_Awkmt07TiOH7hg75M1Pi3361 -> tool:nanobot-harness-v3:call_02_GaOmqBewm3c3isKOqkex2540 -> tool:nanobot-harness-v3:call_00_KWU0QsIbujOZPGc9G6AY0254 -> tool:nanobot-harness-v3:call_00_lIdBXV28SMQxTGQZGqcN7937 -> tool:nanobot-harness-v3:call_00_pI3SDvhnAw9EjydPJbsO4821 -> tool:nanobot-harness-v3:call_00_sy8TcfQC8DStOUGnMSys5806 -> tool:nanobot-harness-v3:call_00_HGNmXC9FvzXLjCYMV4DR5110 -> tool:nanobot-harness-v3:call_00_gqKZ2v4mNqnVVKpr07YK8172 -> tool:nanobot-harness-v3:call_00_Mqtg5eqaw6aN3hejjsif9467 -> tool:nanobot-harness-v3:call_00_r51WvKCRl32ldRtVWmOs0318 -> tool:nanobot-harness-v3:call_00_5xknu4nnk5lmVyIKeNwb6294 -> tool:nanobot-harness-v3:call_00_fmj2UvFGkJAEznDK92bV1133 -> tool:nanobot-harness-v3:call_00_RbNBJkBVateZ5v0La6Pu1038 -> tool:nanobot-harness-v3:call_00_fO5R6gYuhUWzrR2nQzw99897
- 关键路径耗时：0.421381
- Makespan：319.996651
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
