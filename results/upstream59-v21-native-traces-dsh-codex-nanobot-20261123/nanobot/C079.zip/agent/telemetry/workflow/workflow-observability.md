# Workflow 可观测性报告

- Trial：`C079__6HeA2Yz__env`
- Task：`C079`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_SiGVKKCA4Vv5sU0olTuL3862 -> tool:nanobot-harness-v3:call_00_VzefX3Z8x7tLc6bTUl1M0940 -> tool:nanobot-harness-v3:call_01_rj47Ioao1zW9HJDVMjAv3008 -> tool:nanobot-harness-v3:call_02_GIlkM800LY2PJxX6FXtw0833 -> tool:nanobot-harness-v3:call_03_UrP7lO6aH59yR0TVLMVU1326 -> tool:nanobot-harness-v3:call_00_k2NJDXLRm0j9H0VCt60E7476 -> tool:nanobot-harness-v3:call_01_W2fP8JpL4nyGhX4BCm6k6927 -> tool:nanobot-harness-v3:call_02_iPhJcBb5d5rfVXpvm91X6322 -> tool:nanobot-harness-v3:call_03_1KIXrJfUDnrdXTXpm0Nn9262 -> tool:nanobot-harness-v3:call_00_Vc1qc2GwOgSyrAL9o1n89862 -> tool:nanobot-harness-v3:call_01_1LKlIgHsydEf6qIEJbJh7778 -> tool:nanobot-harness-v3:call_02_YrTNgsGfqFs4glWRsEHK4065 -> tool:nanobot-harness-v3:call_03_ZOmQrsfZxVRiOfr6JNsj3205 -> tool:nanobot-harness-v3:call_04_G7dYIR1fm4a0Pj9T98mF2918 -> tool:nanobot-harness-v3:call_05_7Qsjjril4HvDG8alRObQ3952 -> tool:nanobot-harness-v3:call_00_4WS9a1VTgxR1oxWZ6jfj7041 -> tool:nanobot-harness-v3:call_01_tqASPQDBvX4SJFgy7Fjr1330 -> tool:nanobot-harness-v3:call_02_EOEe01qxjapiipiVhrvH0290 -> tool:nanobot-harness-v3:call_03_jXirrupLHi5z3ueh9QGJ9312 -> tool:nanobot-harness-v3:call_04_kM2CyJpDy3ng8EjXG4kX1539 -> tool:nanobot-harness-v3:call_00_cMug88P4KHjpvfPRTPFq5268 -> tool:nanobot-harness-v3:call_01_ZtJZut9Ha6Wi6yXaTbpG8953 -> tool:nanobot-harness-v3:call_02_ccn5YP0lYMgxA914fU8j9020 -> tool:nanobot-harness-v3:call_03_RZxzlyumJTEA0OaUTCtM9228 -> tool:nanobot-harness-v3:call_04_D8qVK3MK7nD118v69c153721 -> tool:nanobot-harness-v3:call_05_NwPAnOkr1IxbRUff3o2p8400 -> tool:nanobot-harness-v3:call_00_vOeqRUW1Xz0U8oXRFWah4009 -> tool:nanobot-harness-v3:call_00_T71aqJzpun2NThK8qcOR2198 -> tool:nanobot-harness-v3:call_00_P37taXZ4Bs64DEbUmZKg5683 -> tool:nanobot-harness-v3:call_00_qKwSFP417d1z36iOfuFB3112 -> tool:nanobot-harness-v3:call_00_dgd3g7gyPy0TZ0N0NIxw6546 -> tool:nanobot-harness-v3:call_00_NIZ6KB9N5WbfgOT48NZJ5176 -> tool:nanobot-harness-v3:call_00_5YDbTy9XEM8n8tfr0et36254 -> tool:nanobot-harness-v3:call_00_FhoawxAiOFaX7laQsjiY9345 -> tool:nanobot-harness-v3:call_00_AbhRYj6JBTx40rBmlQZc3485 -> tool:nanobot-harness-v3:call_00_bYI1bXfrf0XMvPVFREW46909 -> tool:nanobot-harness-v3:call_00_96Zb6ov3nNKvcWrOvkgV7335 -> tool:nanobot-harness-v3:call_00_mRbzgIoERm1KT2jt6o1z5931 -> tool:nanobot-harness-v3:call_00_FvCYbOJ0wiv4jYpI8Eka7949 -> tool:nanobot-harness-v3:call_00_tp24RQe012OlBNVspooP2300 -> tool:nanobot-harness-v3:call_00_c1Z1LrO3XvKnetOFuTt46342 -> tool:nanobot-harness-v3:call_00_BrLF2LtPVmo7xmZk0Vjm5062 -> tool:nanobot-harness-v3:call_00_KJDnoDRgDw2cf2TY7dvc4954 -> tool:nanobot-harness-v3:call_01_GNSpflmiYd32xXxjIbBq1954 -> tool:nanobot-harness-v3:call_00_OTDiX0OBNV7uODwxPlQT7506
- 关键路径耗时：0.658069
- Makespan：127.493545
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
