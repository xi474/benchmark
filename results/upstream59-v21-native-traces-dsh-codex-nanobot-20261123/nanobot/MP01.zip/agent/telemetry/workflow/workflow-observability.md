# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP01__ZsuCUmT__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（83 节点 / 82 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：83；执行边：82（observed=0，inferred=82）
- Execution Trace Graph：`observed`；temporal_next 边 82，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_ISROGRXsFMmteRdDyzZa4397|f82da086-5f14-4441-a506-c1a93727d8ff -> tool:nanobot-harness-v3:call_00_QQc3novBu4fSZCXpATPN1702|310fdea5-2355-4833-9f6b-e931ac414f68 -> tool:nanobot-harness-v3:call_01_SA23Sg3YoQChEXfBNlHh2777|fcd65524-1d52-4e5e-8ab8-e1c8e89a6ac9 -> tool:nanobot-harness-v3:call_02_JwmaPMiTp8TJUHVjkV8G7154|0166cbc3-4312-4cb9-bbf8-66676b09d555 -> tool:nanobot-harness-v3:call_03_Tl1vIGKzdZN9MHbhlUL35886|347426b7-7c35-430e-899d-a979bf188018 -> tool:nanobot-harness-v3:call_00_AV7uR2mIJ0XEDEnTXVtE0238|df5ad7ae-334d-43de-a6bb-8b6c1663d24d -> tool:nanobot-harness-v3:call_01_DKyhhHeAdr1Eo6org27D3911|b56338a0-dabd-4b3b-b8b1-2e8895b554aa -> tool:nanobot-harness-v3:call_02_AeI2WVtiY8lGPQXB5LT72690|48aa05a9-9385-4623-98c9-e07aeb8122c7 -> tool:nanobot-harness-v3:call_03_eC2Bas8O94jHBMkFkHvT6196|2f44dd59-dfb8-4b5f-bc41-171b06488ccc -> tool:nanobot-harness-v3:call_00_4Vmva5Sp1QP3D0FRcIHo7248|e3702eae-17da-43be-872c-79cd5df07d4f -> tool:nanobot-harness-v3:call_01_dGzjAZKrQ9Lwx7ITUGji8180|6589853e-9708-4166-a381-b100cc911cd7 -> tool:nanobot-harness-v3:call_02_CyFxx8YTVK6qCIcs8q4K6213|82639921-2ac9-446a-bfa5-205745329938 -> tool:nanobot-harness-v3:call_03_uyss7DCKiZgyBL6Xa5Dn3043|ad7f7e24-b53d-42f2-b8c8-b07b25c935de -> tool:nanobot-harness-v3:call_04_qy6f3gHtXBCFFBVEadqE9125|a73e832f-2fcb-4d38-9112-ae934a34e0fb -> tool:nanobot-harness-v3:call_00_Gn0hUrKRJ3DjOuOVvSV87694|ad59c29a-39bb-4192-b79a-0deb11530fed -> tool:nanobot-harness-v3:call_01_oO4BNvZgl1UvnSxV984i7704|d35c792f-45db-479d-b3ad-f10607d9bbb4 -> tool:nanobot-harness-v3:call_02_TrasLK9GLIclmwVecP2R1575|f3dfcf06-4759-44eb-878b-896d136007e7 -> tool:nanobot-harness-v3:call_03_sj2UuLiKZ3domjirccMU6386|aabf65bc-3b9e-40ac-956d-1f6145e17ab7 -> tool:nanobot-harness-v3:call_04_HC5S09czyqa3gGbZSP917647|9fcacb4c-2016-4bed-8155-cd1799eace30 -> tool:nanobot-harness-v3:call_05_ZB15s3FLcM3WqKcc2Gb39498|35966bba-5a91-4691-8880-553a86fe5a1e -> tool:nanobot-harness-v3:call_06_KliI8f4pAH3Bwg3bWkfB1119|499e3033-bb30-4ce0-8b43-f503444da8cc -> tool:nanobot-harness-v3:call_07_7Zk17t3KJvWlMa5cpwah1804|6ac99c67-8019-4503-b1f2-81f260f68bd6 -> tool:nanobot-harness-v3:call_08_DYMxCjZVYcZkupkdwLW45496|ffa7d5fa-bf94-4687-b3d6-1930e21571bd -> tool:nanobot-harness-v3:call_09_dO8Vi4tiwExuck2RTH488114|3f938ef6-dc28-4409-99c8-befdf95db4aa -> tool:nanobot-harness-v3:call_10_6eV9iLjO7X0IEXlx3yh55067|20b5e989-3d70-4f42-aaaf-d309ed227517 -> tool:nanobot-harness-v3:call_11_XDQT68ENgywhTp0Yhiyi4463|4b9e2f34-e669-4395-a8eb-b1265f7b8ad6 -> tool:nanobot-harness-v3:call_12_hgt7qT91pGeyq9OT5N2Y1276|1087e9d6-5fbd-4fa0-81eb-e296d146706a -> tool:nanobot-harness-v3:call_13_7EgY88jwDlEBvERVUS8d5074|f70619e0-d9c4-46a3-b37a-98ec5ca7184c -> tool:nanobot-harness-v3:call_14_UrDvPUJGLzbiddX4317X8685|745e3e7f-c28d-465b-a3ce-dc311d361b12 -> tool:nanobot-harness-v3:call_00_IuTw4uNUyHGSR4ZEaWJR9788|06f96ce8-9257-4c2d-ad40-52a93a1624e1 -> tool:nanobot-harness-v3:call_01_iWnRrPypmDKF4N6FNlpH1585|b3a64043-226a-4882-ab33-5cfdae7af37f -> tool:nanobot-harness-v3:call_02_S84y1V7H0ngvC50oEGgR5058|faec9697-1b45-4d2c-a481-1ce2a40aa297 -> tool:nanobot-harness-v3:call_03_sGsajlFNMNR6sMdrVRws5584|60ef88eb-b3e2-47e2-bd29-1cff25dd7f2c -> tool:nanobot-harness-v3:call_04_2i9H7Ja6TvKvH1FYoC552328|908e0d22-2fc3-435b-8a7c-90ee9ffb9f67 -> tool:nanobot-harness-v3:call_00_PIlHmiSR8HWo3z1qGbEF2510|36b1c1fe-b928-45de-b08c-c80104c9df46 -> tool:nanobot-harness-v3:call_00_LxMSxuymvv0EEdJRumoZ3226|ffaba567-2873-48b5-b1bb-fa68ea060c98 -> tool:nanobot-harness-v3:call_00_32QhXcWuurLq60H5PHEy4915|6dfc439d-0b58-4c05-af0e-2aeefa050ff3 -> tool:nanobot-harness-v3:call_00_9yA3OUYgBIlMVQaRKXLs5695|ec337c09-ac1c-4ca4-8870-56a6b59eb5fc -> tool:nanobot-harness-v3:call_01_ygTY4f4WB2GGOKLotq0P8702|f392cf15-64ef-4e01-9596-453e44660463 -> tool:nanobot-harness-v3:call_02_PzjEmHExdlhLM9ZX7j1p8322|84e13506-0651-46de-8a29-a4cca1845ddf -> tool:nanobot-harness-v3:call_03_QJQjmvtM7GtSVgKdhGqx6171|02c74142-2ebd-45fa-8323-f29955a8fda9 -> tool:nanobot-harness-v3:call_00_ccZlXroEDHZxl5Kq1T1c0874|a41f57b3-26a9-497e-9710-107673689906 -> tool:nanobot-harness-v3:call_01_E47hv6Z9OYNlvY8EKJn58207|4270af96-5b83-4d06-805d-0aeea34dc1b4 -> tool:nanobot-harness-v3:call_02_o5bTKNRLMHqholSlOlcf8208|2f34547b-68cf-470a-8958-253f04a38d9f -> tool:nanobot-harness-v3:call_03_rlGFJxMd30Nap0wU4XFt8386|8a5d7a13-fc3b-4fcc-a65f-613b729acabe -> tool:nanobot-harness-v3:call_00_mON5khARAEv27DNw89bH6146|5add93df-50c0-4b7b-bb2b-45c092c6e175 -> tool:nanobot-harness-v3:call_01_mVBURl3wYyUriWCpMjtx7340|1bff77f7-c2cc-47db-afff-4a0ac0055708 -> tool:nanobot-harness-v3:call_02_re81JTdZeLahxrntA1rP8721|6717300e-9a6b-45af-b057-d9c1a4561b21 -> tool:nanobot-harness-v3:call_03_hQMKfFIUWl1WZfWDpgzq5221|ac482876-4915-4d7a-a25f-9e5dad931a7b -> tool:nanobot-harness-v3:call_00_b0gd1P5CNiS2v6rrAHcx9392|b11c8e4c-e4ab-42a1-aede-7e2aa580e1b5 -> tool:nanobot-harness-v3:call_01_BygssYQiebk49QXCTC6w2741|07a20adc-0910-4627-a55e-2de76e635ca9 -> tool:nanobot-harness-v3:call_00_JflJ28I9RfHgZE3N7tJe6342|e21a053d-c64d-41c3-ba57-6af5e3a77388 -> tool:nanobot-harness-v3:call_00_4j5oaIXVLGcRMHHrqDK81341|56db981a-9f5c-4048-8b0d-06a7ff8f5b3e -> tool:nanobot-harness-v3:call_00_vuG8xIAoD0EX1gvY7gHD9152|10dabb31-5a8e-4d1b-8466-f826840f2679 -> tool:nanobot-harness-v3:call_00_BpVzPkm0RXNKAKi5knL51887|5bab14ce-e956-4938-bac2-20e406dbfd18 -> tool:nanobot-harness-v3:call_00_NHvyMpPPtyUS8NIveWAB4337|e3e4efbf-8a55-4977-a468-f308e7876c00 -> tool:nanobot-harness-v3:call_00_wo3nVBiKSFPe2dSOJR354824|dac2bd69-c3c6-4d0b-b515-94ef8ab42705 -> tool:nanobot-harness-v3:call_00_fO6UURNLo1jusUHuM1kh6914|9160a143-c8da-4aac-a482-a8f5c7a1c6fa -> tool:nanobot-harness-v3:call_00_axIUmU8wruIIcyP19fwh3306|bcbefff1-337c-442d-9b8f-a9b1f23ea2ef -> tool:nanobot-harness-v3:call_00_BDV0Tvx9fTKgKyL32sg87384|9499d7d5-4987-43b2-ad78-59f733eb2ba0 -> tool:nanobot-harness-v3:call_00_JQ6dACze3iNJezJvD7Uw5348|b39dcb73-0ab2-4bd9-9fb4-2782cb574a2a -> tool:nanobot-harness-v3:call_00_jzND7XkmERxRKyepdqVN4185|a729b13e-a6ae-4e58-b7af-6a6e8f2ec021 -> tool:nanobot-harness-v3:call_00_JQOnkZPeioyNWPVsUIwJ9472|3f333722-79d0-4c16-8227-3a4ffd338cb0 -> tool:nanobot-harness-v3:call_01_PGdFQALcN4uP0BpeMJCM0752|a828a169-cfbf-4870-afb3-7c892fb938d0 -> tool:nanobot-harness-v3:call_02_R5zD4Qa6VQGPxh7dbXKJ4681|3695ddcd-73f5-479d-8a27-80217cc8e669 -> tool:nanobot-harness-v3:call_03_6iK2zo5aUaOXmNS12HNg3030|96f92197-7c7b-468f-a8a4-0e2a9d403969 -> tool:nanobot-harness-v3:call_00_XcY3wH7XCtOa1qRLkdm77029|3bdd6254-a1de-45b2-bb21-7c0a38557717 -> tool:nanobot-harness-v3:call_00_DGVjjcNMLlGeQlKpR9cd8509|04f5613c-6773-4621-8d07-6535f624123c -> tool:nanobot-harness-v3:call_00_CwBk1LWODPufdRcRXkGn4617|9a18e983-50d1-45ab-985d-6a6c1e12bfe2 -> tool:nanobot-harness-v3:call_00_yWA5XbYIOenNkD0A6tP67829|7e2ae582-8686-4f6b-9ff4-f50a53409a95 -> tool:nanobot-harness-v3:call_00_WYyJRdaNMgcBH4HS93mB3202|a8ece2cf-e0c7-4e86-98cb-7c8c015c136c -> tool:nanobot-harness-v3:call_00_IWIkR51ZIES938Ia1Rgn7567|af5ed07c-0ae9-469d-a2e2-7cd5a3b9fb3c -> tool:nanobot-harness-v3:call_00_YI8hEJ1C2iWLcgcHB0jX5823|180f3c99-7c2b-4201-91d0-3cf80927a2dc -> tool:nanobot-harness-v3:call_00_KfWJXJcf4KCpT8WtzXV55988|c5ebf179-7652-4331-b03a-cacffaac1bd8 -> tool:nanobot-harness-v3:call_00_wdWMTFSApY7pghZSUQEc2934|6851893c-eef0-4861-a9a3-e43b7f6f92a9 -> tool:nanobot-harness-v3:call_00_W5JDq9t5eS3fbzX14dc02448|70702426-af93-4d71-a920-e4d62a167bc3 -> tool:nanobot-harness-v3:call_00_NNQQQBw0FJJ8hxBZAFQY0366|158d9b16-fda4-4db3-b4eb-0270cb7f4d0d -> tool:nanobot-harness-v3:call_00_KJWZxqWlOiKhoLh5BHgM8827|767eccc0-8d1b-40c0-a3f8-12e80eac5631 -> tool:nanobot-harness-v3:call_01_8tkbTwDfC8Avrs32wGaf1919|84762038-d0a0-4124-a2ea-d1f52e79212e -> tool:nanobot-harness-v3:call_02_w97GR3HpQduqRCbzUvGi8872|517ea0c7-9bcb-4f0c-88f6-3672286b87a0 -> tool:nanobot-harness-v3:call_00_IYh2VNbEdXKkj9cMKyk90552|ca9ac320-a2cd-4830-9c01-cf6ab47ecaeb -> tool:nanobot-harness-v3:call_00_8Y1QJnOiB3zwVyGFPpCC4543|0752579d-df47-4d90-8962-b4bef670a456
- 关键路径耗时：1.90339
- Makespan：517.457447
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
