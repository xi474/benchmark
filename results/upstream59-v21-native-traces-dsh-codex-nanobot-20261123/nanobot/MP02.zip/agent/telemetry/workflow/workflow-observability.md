# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP02__pfSrukZ__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（81 节点 / 80 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：81；执行边：80（observed=0，inferred=80）
- Execution Trace Graph：`observed`；temporal_next 边 80，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_xiGRTCQ9zVe9aGloc6Bn0932|82e28f78-7772-415d-a161-5524123d5379 -> tool:nanobot-harness-v3:call_00_iuhR02Aa2QTTHWeOHabc8481|bea01f80-8c4f-4488-96ec-6874a743b6b4 -> tool:nanobot-harness-v3:call_01_vdu8npdWU2voWAbRN4rv1452|a0bf4121-1a79-4b63-83c3-1521ff8c83ce -> tool:nanobot-harness-v3:call_02_9SRox1dRjSSfyfpayjxn3032|63faae58-23f9-4e22-87ae-7c16f5e0a4d0 -> tool:nanobot-harness-v3:call_03_q3b8QoM4S86UiIlFT6cA5474|d62ace47-94fc-4379-a2f7-1bdb72f447f2 -> tool:nanobot-harness-v3:call_00_ag1KTRcDXsKBN3Vu2JW71456|24b863be-8f2b-4dfc-9f87-9703e0d59300 -> tool:nanobot-harness-v3:call_01_g60l2wlAL4Hw1I74cST89898|65174305-5d9c-474d-9e01-81fa3474a711 -> tool:nanobot-harness-v3:call_02_auU1j0Io0DXMWEKsHkxR5300|9ba79d46-9006-4e0c-a74f-0de03b08fec6 -> tool:nanobot-harness-v3:call_00_xqdNATPfSv8LId3koxoU1358|f9f10cb4-0885-42fd-96d4-fe0f4243b170 -> tool:nanobot-harness-v3:call_01_P2swTzJHliICJFTdqfmv6745|3effab91-d31e-4a3e-84d1-b7cbc76eaa36 -> tool:nanobot-harness-v3:call_02_AaYeoPGI97odldYGJBdr0258|65cedfd2-1dc8-4d49-a14a-d417205fc22b -> tool:nanobot-harness-v3:call_03_sJeF9BkDMFxtScUe5O9X3682|b402b446-8380-4ca8-9cdc-b500301965eb -> tool:nanobot-harness-v3:call_00_P5TpIMx9uncppj2m5Z707105|49a5024c-9a1a-47a2-9c2a-68e76ddbca4e -> tool:nanobot-harness-v3:call_01_VS5c5b9BAHg2KKoRgXyx9637|41b7362a-0fd0-4124-abb9-20251ebb8593 -> tool:nanobot-harness-v3:call_02_wyw1Jskw2TMTzPCPkGJQ5271|d77469cc-6806-46b1-a13f-1d27b7f3497d -> tool:nanobot-harness-v3:call_03_wK6GCQJ8e2b9R4E8DC3o8214|3bb02cef-e671-4f78-ae7a-282fe5be15c9 -> tool:nanobot-harness-v3:call_00_vWdywI0m1TYdnPxXH4Do3137|4a12f672-60b8-49f1-abd9-08134c9b7fda -> tool:nanobot-harness-v3:call_01_d13WvkbOEutOBDaGfsgH4084|021f741a-9fc7-43f8-ae17-f7356d0b242c -> tool:nanobot-harness-v3:call_02_6yKxyujWhI1m9Sp9E8KQ3021|d237c682-a241-47f1-a11c-63881cda5960 -> tool:nanobot-harness-v3:call_03_Ci55Tce8qm1qQ8CDVjJb5679|5da41251-f647-4d7b-a3ab-53a734187c54 -> tool:nanobot-harness-v3:call_04_WSzlxmBlcxESe3x1A4Qf2712|7a1ad443-fc4c-4628-84ca-2ba2ebc1945a -> tool:nanobot-harness-v3:call_05_PbwqhZJNiYbjAhx4CZ375439|84a4154f-33e4-4281-9ab4-ad7e70dfc9df -> tool:nanobot-harness-v3:call_06_8Kas6HuZMOwB6qll4bSs1065|8f1ab77f-c252-4efc-a313-73e4fb4d0509 -> tool:nanobot-harness-v3:call_07_hq9J2ysGBxiA09SLYXuI3320|14e5b4dc-5e61-45fd-a205-193d758e654a -> tool:nanobot-harness-v3:call_00_wPskf9jUB9zxTgqXqB9P9133|13454ec1-9cb2-4469-afc6-bc68ac017ac6 -> tool:nanobot-harness-v3:call_01_dpSppOcsbdmLhIujwT9G5808|ab2c9ae2-e0f5-47c5-9f55-9d6bb75ac38d -> tool:nanobot-harness-v3:call_02_BYniGvqttd411sBiIgXX4841|4466cdd5-805e-4d74-a89f-935d98dcec4c -> tool:nanobot-harness-v3:call_03_jfwFjvRwM7h7AuL2A79L6238|45ed0e1e-f01e-4747-ba94-13bd503c95cc -> tool:nanobot-harness-v3:call_00_OihS3mJdAoEIxkjTAJtU7460|0473109d-ef8e-4cbb-978e-3d7b288df3d3 -> tool:nanobot-harness-v3:call_00_G4Dpy0CFrLV79zOwxo8q7288|19a35556-2883-4933-b55e-e98ac1f15a4f -> tool:nanobot-harness-v3:call_00_JCPZe831Zf9oH2XSd24l1180|3854fd49-e02b-48f3-99f1-fce3761227b6 -> tool:nanobot-harness-v3:call_01_HWeNu2ud2P7EVH4VjxTp3187|3a59d01f-ce99-460d-ad18-2e105d96537f -> tool:nanobot-harness-v3:call_02_0Hzws7WLPTqZopSDMGTo1041|07ead2f1-8f2b-41f2-88e4-e3ddcb4888a8 -> tool:nanobot-harness-v3:call_00_tMVMlCTAZEIBbFYWlRpy7012|a465b915-b4d3-49ec-bfd9-434aa797dc5b -> tool:nanobot-harness-v3:call_00_UGIGEdoDhBp6xrJh9oVt3387|5b7fe544-f10d-4c35-a4cb-f899fb1e2b93 -> tool:nanobot-harness-v3:call_00_tv6ruiStRwV0GMGyOUJQ7338|7406c49a-c6f1-4226-a0c2-67eeac557ead -> tool:nanobot-harness-v3:call_00_e4fvAOhf97yoiMADUHLO3172|ac8998a8-fbd9-43e8-9358-3e2604f5ff68 -> tool:nanobot-harness-v3:call_01_DGB5hijVQLStpXJXPLu87490|5a642acd-4395-4488-9ccf-8b5e3eaa09f5 -> tool:nanobot-harness-v3:call_02_D5B3gQLBFPWtlQs2b16P8145|bb26095a-870b-48d2-a3cb-313571a97577 -> tool:nanobot-harness-v3:call_00_8xHiHBsqqdaZxRJd62my4022|0e5c68dd-4b40-4ee7-aa65-c2a9ac22e31a -> tool:nanobot-harness-v3:call_00_ygIxAN9riwtU0gsvoJTg2000|5a75ffb3-7c7b-4042-9f76-57de5cd5e0ff -> tool:nanobot-harness-v3:call_00_hIs45WwVnkEBPYOF7zMv3132|5b72c2c0-790f-48ec-b961-f38243baeac8 -> tool:nanobot-harness-v3:call_00_2IDNGi5xXDAqUjuqhYtz8735|6a1c3c11-1c12-47c7-8cdd-6e1282f93438 -> tool:nanobot-harness-v3:call_00_v0csAtEscX93qwNzV8Pm1830|cebede43-af89-4b8b-a05d-344e1eef8fdc -> tool:nanobot-harness-v3:call_00_q6kV9TOWOxbRi8Pj4nLr3274|ff2f2674-5090-4b7d-8176-e22708c57927 -> tool:nanobot-harness-v3:call_00_mPl3mzZC1Rye9PeMSjF72851|db817e3a-e4ce-4818-8a43-bf43846995df -> tool:nanobot-harness-v3:call_00_oT5vBQrduWYrDbhej36u5756|faadd326-d4e4-4d09-bb47-7db67aa096ea -> tool:nanobot-harness-v3:call_00_1hIpwZDcYtWjbrVumZ1W7618|2be6aadc-433d-4523-b93b-52121e0dfecf -> tool:nanobot-harness-v3:call_00_6uXtqBp4Gym0HIIlUa7c2661|c4149c8a-b555-49b5-8c8f-490ca3a57d6c -> tool:nanobot-harness-v3:call_00_vahEeoZTupISDksKjBoH8188|d8ebfc67-d48c-4e58-9376-533b7aca714e -> tool:nanobot-harness-v3:call_00_aF9RAGj69Al2LUpYkZ4M8083|55f6c52b-c311-4146-8b46-28e9d1130754 -> tool:nanobot-harness-v3:call_00_KIEN8ysRMGWR4KvS09C90295|00327ae7-69ee-4c8b-94f7-60158ca6776e -> tool:nanobot-harness-v3:call_00_g60PKuy0Smep7HePxDtF4029|dba15085-3046-4db9-9a99-3de71f266089 -> tool:nanobot-harness-v3:call_00_wts9mkkLM2NZCFd0GXo98129|6ace514b-23d0-4599-9936-1735dbf2b914 -> tool:nanobot-harness-v3:call_00_afCA9W6vV4o1QfgOqDgb0184|794cbe2c-d306-4956-aafe-845ba8d086df -> tool:nanobot-harness-v3:call_00_WPbvjPgqgjslhvRCzuTQ6005|9804ce06-f191-40da-a90f-eb410a44f825 -> tool:nanobot-harness-v3:call_00_xbRyskAmkyzCDX9Pb6Rc7189|262acda7-e22c-4627-8c06-63de955657b8 -> tool:nanobot-harness-v3:call_01_mGUJw9rGUlb8CpCqYI406420|778c9a26-c00f-4ab8-8ead-fc05187d80ae -> tool:nanobot-harness-v3:call_02_6TTRH9H7FO6JRrDJBvje4617|0bce6140-b3b2-41c2-9648-eb52f7e8a1ed -> tool:nanobot-harness-v3:call_00_zdyJNRNsLt81DwzuPxoR1371|a576d626-be0e-4d0a-a0fb-43b5b662eb3b -> tool:nanobot-harness-v3:call_00_CXnt8r7MmdV9W8HbyhNX8302|81d8f891-2475-41fc-a864-78e7bef27485 -> tool:nanobot-harness-v3:call_00_lS4mJlvazYu6tX4Va0hT2558|a9ea9bca-9c1e-49a8-b60b-b7046cda1338 -> tool:nanobot-harness-v3:call_00_QWKWYUwikWb5fbvu4eHh3094|15bed0db-4d39-499d-a6f5-08bf42421440 -> tool:nanobot-harness-v3:call_00_gFl4XpwAMtCK83NN7yd19183|a7bd328b-f8c7-4d58-bb07-eb03895db813 -> tool:nanobot-harness-v3:call_00_yLlzrP1YOrNM2CJnt9SM5695|d0fda1c6-eec7-4c14-841a-16669b01de75 -> tool:nanobot-harness-v3:call_00_BeFbjq7lxnY6fkJkfT5O0901|67644876-e7b4-4f4b-a240-1ba0bfe148c1 -> tool:nanobot-harness-v3:call_00_Qoillof91yjqggU5sa9K7074|5b2a419a-e634-4e51-bb50-3ed019b60a44 -> tool:nanobot-harness-v3:call_00_O9rxQ0RN8NKoLwnfdxDu9848|55d1c84d-3b05-457d-b044-cacc3513809f -> tool:nanobot-harness-v3:call_00_xgOAIOelNGGl96esVPdc6016|dda79601-c2c6-42db-8928-ebe28d7776e6 -> tool:nanobot-harness-v3:call_00_PsnVNir93IOm57nkqFE87396|bfff89bb-cafe-4dab-baeb-dfa18f75219d -> tool:nanobot-harness-v3:call_00_A1gVVOFRjgw1Ibm4qg0i5085|a42a528c-ae9e-462a-88f0-9caef80abd9f -> tool:nanobot-harness-v3:call_00_Q1OzTr0HGm27VkyOsyoY3781|e3dc8e1a-8508-45a9-9125-7265e1cf4d7d -> tool:nanobot-harness-v3:call_00_eZR0moU6tv42AyJ0e8EV3743|12f0938b-2e7d-4c1c-b630-b2c521089c50 -> tool:nanobot-harness-v3:call_00_MxtnMtVjLRBbxEnxPSJ14393|cad0e9e8-fbb5-4dfe-8629-bd2dced17d8f -> tool:nanobot-harness-v3:call_00_hr70RPfMM4OaxalqtMCS2516|7798d242-ba24-45db-9985-dfbbb483ebd3 -> tool:nanobot-harness-v3:call_00_kpf4L1bKHaNlvON1NfZb3724|18666eb8-ac01-440f-9a2a-75b9efc2cb4b -> tool:nanobot-harness-v3:call_00_jrwNj7XvzRFZymc7cKK33171|9df76655-35a6-4aff-ba59-ad3eb3fe365e -> tool:nanobot-harness-v3:call_00_Unyv5iSkn9ISfUTJ7mvj3249|8f5965e0-5f00-42f1-93ae-7d5313a589f4 -> tool:nanobot-harness-v3:call_00_hr8l5c6RyAs7O17HllK67405|e7083c22-83b5-4f36-93c3-9ba68d642825 -> tool:nanobot-harness-v3:call_00_C81zHI3P430RVTx4RTJn7997|9ab1c7fa-ddb5-435b-8c01-3c35821808f0
- 关键路径耗时：1.608576
- Makespan：632.233919
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
