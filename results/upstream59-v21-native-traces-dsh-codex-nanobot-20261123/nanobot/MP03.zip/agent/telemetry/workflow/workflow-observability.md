# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP03__Xjv4wT7__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（91 节点 / 90 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：91；执行边：90（observed=0，inferred=90）
- Execution Trace Graph：`observed`；temporal_next 边 90，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_whaplltPtMxv9yId9Fbk0203|419e520b-21d8-4557-b2a0-ed81e0d0c52e -> tool:nanobot-harness-v3:call_00_b1MRHv95oql0wc4u3AOC8337|b253e979-3a73-4e1a-a135-337a9838e6c0 -> tool:nanobot-harness-v3:call_01_68JpCHTLpunKYFtxJNya5394|c461322a-b560-40dd-a960-be17cdc354aa -> tool:nanobot-harness-v3:call_02_pVhqqVdyqiC1emxL3U3X3935|6c028944-375d-406f-9fbe-95f331f2bf1f -> tool:nanobot-harness-v3:call_03_88NaM90ZWNz2Vi2Hz6RK0932|7cd98a6b-3a64-4367-8662-10f562b0a334 -> tool:nanobot-harness-v3:call_00_tqtw3HBbC4sbu4wDBFpc0789|5e2c0311-53b7-43f3-9110-ac86838634f7 -> tool:nanobot-harness-v3:call_01_2UGaJqurMgE1gXnVEzKA3586|be38a8d9-2730-4974-8e1b-024b5ef748e7 -> tool:nanobot-harness-v3:call_02_hE6iJBu9MBhCobIEgMR34195|4c40359e-db17-460d-b7ef-c09ef01060bc -> tool:nanobot-harness-v3:call_03_mIcUisB0lAf3aP8oWsoS9048|9371e3a3-c812-44c1-a0fd-2fe6a3d2c951 -> tool:nanobot-harness-v3:call_00_Rcbt0ngP5JYcjMm7XEh64527|26547183-423d-4a20-96c1-f881960f9f64 -> tool:nanobot-harness-v3:call_01_pezgyLrRDMCYJ2YXAfxw7122|0135ec5f-71e6-47a9-a787-2da03877ce5d -> tool:nanobot-harness-v3:call_02_WFcgofC3SxxctRyPlanl0526|cb3666f2-7c18-43ec-912e-d04b1a200691 -> tool:nanobot-harness-v3:call_03_yxid5X41yXNbgEakijYM4226|65adf8dd-3940-4889-a7d4-1882f9b3bfa8 -> tool:nanobot-harness-v3:call_04_7aAk4aS0XLMJasYkS7YC9684|6d1a15db-e8fe-4803-86dd-9eb23e8c5088 -> tool:nanobot-harness-v3:call_00_UCVCFkiDrWUJY3VzSW707818|5ca5d68f-69c5-44f9-89f7-751b6dd0d24e -> tool:nanobot-harness-v3:call_01_AFRwsX25897gT65IqW6r0225|9f1e3f03-1a49-423c-8a68-a128c51fdf21 -> tool:nanobot-harness-v3:call_02_GXvXF9xDZSCdaV249eUi8348|bb67387b-703b-465a-b371-6ec649d7a516 -> tool:nanobot-harness-v3:call_03_JRPYZXwHK6GcMOhcwJPg9234|589f837a-40b5-4ede-8065-055f2764ad2e -> tool:nanobot-harness-v3:call_00_088NxWIa0fdNKwq29G6l3834|b23d3b21-01ad-4694-9ccf-28bef0011c02 -> tool:nanobot-harness-v3:call_01_9APYVVO1yF5MSJuZYicC3147|6dae41af-edfd-486a-901a-e7623e1c265f -> tool:nanobot-harness-v3:call_02_n79HA1E55P6dJM1W0TVl7763|b192fe8a-9314-447a-9287-6e6620e37d56 -> tool:nanobot-harness-v3:call_03_3jQTC4gki2uJZw5f946H6377|9d4a66f6-862e-4328-b07d-d19742ac6396 -> tool:nanobot-harness-v3:call_04_wofTferYPniqJg43l7XJ9609|cf432e32-f39f-418f-a6e6-5d3c99309c5a -> tool:nanobot-harness-v3:call_05_cForhawqvK8sevqd7SfU3617|74704c79-bddc-40e6-a55d-df61f2c27ea6 -> tool:nanobot-harness-v3:call_06_62csGKGzQixgnOpRFxsV9415|3b81ebf4-3b01-4976-bb2d-097ee91eaced -> tool:nanobot-harness-v3:call_07_90jRlEZvNxcZVWAy68up0442|3e905919-3e7d-40ff-9667-b778fa9289a5 -> tool:nanobot-harness-v3:call_00_qxfBJ6UXv1q4Tf2dRl0X6231|3dffd067-5f97-4d44-b604-074842c6737e -> tool:nanobot-harness-v3:call_01_Bpm2DGYiYdeVNRh2cz9L2092|928927b9-1717-4415-8800-49f08dfa144b -> tool:nanobot-harness-v3:call_02_h8fDB6rrFpHNYOo2FJUf0155|ac052c99-07e6-4caf-9446-fdb85a48ead7 -> tool:nanobot-harness-v3:call_03_DJqVQ7pGSGI0ifzIV9MK1239|9beb63db-69ea-4077-b283-d386cd089d8d -> tool:nanobot-harness-v3:call_04_OQNexaH1D2QABXzp1Cnv8275|0f796671-e522-400d-917c-597609c99967 -> tool:nanobot-harness-v3:call_05_glABGR3zhQE8jvWb1wd30190|e4ab83f2-d141-41a2-9110-ffaa53250e88 -> tool:nanobot-harness-v3:call_06_eYiU6ysIkd68WIxo8nZR1845|b1ce0fb2-cb38-422f-a983-a2e8e7f34a6e -> tool:nanobot-harness-v3:call_07_IMYkYSIJg29Fw5suTVbE6810|3fdb23e3-fd39-49c2-b9b3-5fdd13f1f3ce -> tool:nanobot-harness-v3:call_00_aTtnJ8REhdgJHx7GFt0J5156|dbd64fde-8641-43c9-9c47-eba515b936f1 -> tool:nanobot-harness-v3:call_01_f8KAd2oSzh9dfXuas4o06105|a3c38ba3-3595-41f7-84cf-c3a6923101b8 -> tool:nanobot-harness-v3:call_00_Ake2WZD2Oz8CR6LllYRu0576|696c5b0c-ba70-4b3c-9ff2-ed972f0caf8b -> tool:nanobot-harness-v3:call_01_a2hfBs7I6z3onHDkgEVo1464|a885bb54-4fdb-456a-b235-044c14aa438d -> tool:nanobot-harness-v3:call_00_sA6PFqoRsmgtUvMWBQYR5010|f9292429-e25f-43d7-8e45-b4a110b93e81 -> tool:nanobot-harness-v3:call_00_gWRZDx2k7ksEe2NA1Y1c4606|39c320b2-fb4d-493b-9854-14d665e4e0af -> tool:nanobot-harness-v3:call_01_eRFMqpGIzK6Hu7hX7Sf66190|432c018a-2d38-403d-b70c-171949251fbc -> tool:nanobot-harness-v3:call_02_eLuyPzT6Nv2gpOA6Kr6I6732|b98deea2-7110-4bef-aa98-83d2fae65ce6 -> tool:nanobot-harness-v3:call_03_RuRlKQuuDjByApkPdjvb0272|1fb7cec8-5e7c-487a-8e4b-cd73d7e418b0 -> tool:nanobot-harness-v3:call_00_k8OlvErW5EfCuOZyfdNa1550|844b0507-c138-417f-b985-4d7da38559ab -> tool:nanobot-harness-v3:call_01_pEooJYld6qQ14pO0c9Qu0704|4d73fa30-9abe-4b57-a7a0-fd10b43f086b -> tool:nanobot-harness-v3:call_02_DjUqBOSSQiryjhZtkZld7430|4ce74c15-45e0-42a5-9f96-eae856a5dba3 -> tool:nanobot-harness-v3:call_03_2kpUKmEbfpaMSdpj2hM83142|57d81c0e-9365-41c1-963e-1b460ff1df5d -> tool:nanobot-harness-v3:call_00_BLEqioynT3oCviYiNr9o9917|d351a69a-1165-4445-a945-017af54aa805 -> tool:nanobot-harness-v3:call_01_sOsmPr54XJbqFXeQebmV2510|baec3069-7f5d-4b8b-867d-ec0f63b823c6 -> tool:nanobot-harness-v3:call_02_GUYHvTIxCIuA9IcDiHqQ5710|558a9fb7-b3c6-44db-9bef-d6bb38c37705 -> tool:nanobot-harness-v3:call_03_T7hpybGyMl0vrzjFmAQ40285|bff549cf-4324-4812-9d57-ae1203eca87a -> tool:nanobot-harness-v3:call_00_0Pu4fHDtb9OQcaINoUeQ3265|29a2f67e-c25b-4f43-96e9-454fd9c8a62d -> tool:nanobot-harness-v3:call_01_qDUdeDR3GecB5aB1oroq4930|6f0ffb90-b263-4777-85d1-9942c32c76be -> tool:nanobot-harness-v3:call_00_0I9ZKVTfY6IKbNDWHvnD2425|0cf9ffbd-a614-4cd8-ae48-0b7e58de2ac7 -> tool:nanobot-harness-v3:call_00_zjluVrW3kdBPaM6vZRIB8559|b14c20a6-8873-4541-9997-1a60905be256 -> tool:nanobot-harness-v3:call_00_S3ZLxrQGQcq8T60X6kLI6202|3986a040-6a06-4486-84d8-b70da59a1e96 -> tool:nanobot-harness-v3:call_00_LmlYMxyczVDgSutIlr9g3972|efc82c1d-4f3e-493c-aaaa-e5c80b369a68 -> tool:nanobot-harness-v3:call_00_HX14v5ndJHudB2LsBw551633|aecbcea5-ec00-4474-b65d-35707a4acd06 -> tool:nanobot-harness-v3:call_00_46LKuZ6PjVEr04aH2Z6J5196|47f3128a-059e-42b7-8c60-433ac0df75fc -> tool:nanobot-harness-v3:call_00_OOyt98uuZyv7uLbFC1OV9288|66785bee-5d3b-48f1-9f3e-45f49b84c81a -> tool:nanobot-harness-v3:call_00_jtBIFFWxn22zYvf9wWQc7646|16574023-b0a3-4420-b4cd-bf3786088c06 -> tool:nanobot-harness-v3:call_00_NgG7NuAG1LBO3pUQSpjd6844|a9454ed3-bc9c-44fd-8a85-060977769c29 -> tool:nanobot-harness-v3:call_00_1Al5PwVy8nkz2gRDjmPS4687|3bd9e740-688b-4d15-8251-b9d1bba73e25 -> tool:nanobot-harness-v3:call_00_mNYlkecJuZdnN40srDGr6476|6fe0e543-a986-4d3e-9297-7b7f500899b2 -> tool:nanobot-harness-v3:call_00_Z6HJOvTIAH6IYyps0XvS4173|c2d6b591-755c-442d-b9b3-5a467b4fd67a -> tool:nanobot-harness-v3:call_00_jcDxGqOzMQaiFUDplRjW2130|de280e07-dd5d-4658-b340-04172ae8ac5c -> tool:nanobot-harness-v3:call_00_B3gNBjnFOVVLsOPpTnfi1527|e433eedd-84b7-4d6b-be0e-a002391a2946 -> tool:nanobot-harness-v3:call_00_60l44nJuOzMXOOUfd9d26782|306a8661-09ad-41bb-8e59-5399491e8b64 -> tool:nanobot-harness-v3:call_00_wdzbtulZtTijPXRxpoQN2266|7de91355-f57b-4ef2-960f-b6201e31487e -> tool:nanobot-harness-v3:call_00_aRP0IVd6nabb7d45cuPx4583|e67c6db9-e5b1-488b-a54a-7c16c39dcd2c -> tool:nanobot-harness-v3:call_00_58RlSycEwVFdrLfUcZEr6469|1fe9e68c-2250-4992-8bae-c558ae1c68d7 -> tool:nanobot-harness-v3:call_00_2nm5k2bnzU4swOrVpXJ08032|5ce867f2-8f91-4490-b2af-16f2ff6d10c0 -> tool:nanobot-harness-v3:call_00_8JgeK18EjlYqRZvmCwEp2927|c6e5ca4b-b058-4f4a-b59e-73bff9d6fb1c -> tool:nanobot-harness-v3:call_00_lDdfjlCaa9iXCLWB2qKS8222|24645085-ca23-41f2-99b0-daa15542da02 -> tool:nanobot-harness-v3:call_00_0E5ijp4H7s3YlEF68VQ35744|6dcd616f-ec69-4a89-9780-5c278eac9c76 -> tool:nanobot-harness-v3:call_00_V23XmdpyoVMjgCdhDG8p1808|313ef1bb-d706-44fa-8ce9-c96b7a0950e5 -> tool:nanobot-harness-v3:call_00_ieMjkY5Yq2iP7QfaNc1c7474|702ddab0-478a-4df7-8399-2e30657c8e0b -> tool:nanobot-harness-v3:call_00_BIjJi4WgTieeg4Zty0t32996|bce44f99-e9c8-4f20-8e71-231ecf367e67 -> tool:nanobot-harness-v3:call_00_twvi80fK2R4GPf1kKEIt2653|845c5a3a-7f35-4dbf-9bf5-2721c3c02265 -> tool:nanobot-harness-v3:call_01_7WkYiyIohXKOQ5aSwrQn9333|ec6f95dd-c28d-4082-be28-312217a99434 -> tool:nanobot-harness-v3:call_02_PCzzqPQqFnypHdMbkoG61327|050d412a-1a53-4cf3-ae1e-74c00109f8cd -> tool:nanobot-harness-v3:call_00_a5z9LHs1FTedlVzkmILe1956|5cd22531-40c3-41c2-9951-375594b98671 -> tool:nanobot-harness-v3:call_00_jdut2zUOUZhYSW7FOiE77259|86d5ab83-0928-4d90-95ca-9c99b697383f -> tool:nanobot-harness-v3:call_00_4p4HPHz7TwMPzuBt0Nb29758|131470f9-fdc4-4592-92a3-af0e632f5b01 -> tool:nanobot-harness-v3:call_00_mWnJhZgMOzEfuDJhgxeC1058|0c2f5941-b0f5-428f-b0e4-ae34f7bbce05 -> tool:nanobot-harness-v3:call_00_Vc4kIrz05sVVykvCKcRN7616|7cf0d55f-6c34-4fb2-a39e-79cc93f7a8f2 -> tool:nanobot-harness-v3:call_00_5zw0uT0zRKhmH0on1XIk5224|26af8aac-2774-40f9-9cbe-dbe0b44407fd -> tool:nanobot-harness-v3:call_00_eokOYsosvZYCVI3SLURC0043|bccad354-2127-4868-9dd5-5de4a138d5e9 -> tool:nanobot-harness-v3:call_00_MmYb6JQoWaTdbFnkOtPr5067|2008ed5a-b05e-4f28-b4cd-df3068cd9d20 -> tool:nanobot-harness-v3:call_00_WhFceKIqffiVUVwmd5Ds6626|878d56d1-05d6-4233-a769-cd0d0e68d1c2
- 关键路径耗时：2.343101
- Makespan：479.58524
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
