# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP04__9HR6uFY__env`
- Task：`core6/MP04`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（88 节点 / 87 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：88；执行边：87（observed=0，inferred=87）
- Execution Trace Graph：`observed`；temporal_next 边 87，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_tmjtF7CN6Z78G2Fi14Th8185 -> tool:nanobot-harness-v3:call_00_DmYoBbNja7J8ZshT6TUQ7878 -> tool:nanobot-harness-v3:call_01_wVJAHZQQyMPsKekUcbUU0972 -> tool:nanobot-harness-v3:call_02_iYdtnZUbPk3Lr19SEtTU4256 -> tool:nanobot-harness-v3:call_03_rM419HMtlZvIHIG07LAb5399 -> tool:nanobot-harness-v3:call_00_H1smULaBX84rFh2NHcos6053 -> tool:nanobot-harness-v3:call_01_NZGbhlOLNKjn4Le212zN9353 -> tool:nanobot-harness-v3:call_02_LFXs8UFEBM5RtBnnrCnz9582 -> tool:nanobot-harness-v3:call_03_TVU2utEd1jKI15Gsso2X3642 -> tool:nanobot-harness-v3:call_00_AfVVczOzQqR6cOzhATkj5546 -> tool:nanobot-harness-v3:call_01_oSMFPbexdtRMpcDUggWN7697 -> tool:nanobot-harness-v3:call_02_RfpyctxlqfI7vl6bKUtJ1985 -> tool:nanobot-harness-v3:call_03_H70S3eiJLieMAgFFfqfC6972 -> tool:nanobot-harness-v3:call_04_DnYFdtnnkbQOhhUzSGim9561 -> tool:nanobot-harness-v3:call_00_qNMlq5AOWeXYWSld5lVz7931 -> tool:nanobot-harness-v3:call_01_OEx0HBK7EUt7LQszO4Id1808 -> tool:nanobot-harness-v3:call_02_ra6jgx1DRHnQE4ZGg5zU0573 -> tool:nanobot-harness-v3:call_03_lPzopPUWZpvmaZ8UKD5k8713 -> tool:nanobot-harness-v3:call_04_QvMZEoKydHU41LYzyQCE3700 -> tool:nanobot-harness-v3:call_00_PcFyLJzSDQqFgUWoFIcs1060 -> tool:nanobot-harness-v3:call_01_7DWLIdt2msSmn5Xl5NL59828 -> tool:nanobot-harness-v3:call_02_ETXfkoBN3BLmo42COAAx8496 -> tool:nanobot-harness-v3:call_03_lFFELm85IFgnpyWKtg278032 -> tool:nanobot-harness-v3:call_04_DXcNgnbZc6WISxvdsnDX0008 -> tool:nanobot-harness-v3:call_00_wu2gFE9O1ww3MPyaeEfS3366 -> tool:nanobot-harness-v3:call_01_1p1HdsWjmYd0kXvncvDe1178 -> tool:nanobot-harness-v3:call_02_INNjdRYSccWw5qtrTl162038 -> tool:nanobot-harness-v3:call_03_m2xhb7H6fHUpHazlR5tQ0811 -> tool:nanobot-harness-v3:call_04_AhAaxCXKGKAJVAxQdxGe3466 -> tool:nanobot-harness-v3:call_00_CM1oixXC7XHtrodYAcsm6426 -> tool:nanobot-harness-v3:call_01_aWhHyon5r1w6wCTwh7Pe9383 -> tool:nanobot-harness-v3:call_02_dNKzb9L43jO3yZIPwfw12220 -> tool:nanobot-harness-v3:call_03_jFEc9nGTJCsOlBcJUDkc3397 -> tool:nanobot-harness-v3:call_04_bm3McrSZ5dzzeZA5dzpW1154 -> tool:nanobot-harness-v3:call_00_GIHGvXPd5FardJ3IgRk97005 -> tool:nanobot-harness-v3:call_01_ilCT4mXeRHXlTMeFNSKr7898 -> tool:nanobot-harness-v3:call_00_3OoKSego0emDgEuUyXiA2493 -> tool:nanobot-harness-v3:call_01_hIEI1OCEOtxmkTemSoLS4201 -> tool:nanobot-harness-v3:call_00_IizOxuOuyzlkXJ2aI5vI3537 -> tool:nanobot-harness-v3:call_00_hIO9vkgpMfMm0pJX9wmc0967 -> tool:nanobot-harness-v3:call_00_NZTCSrkHwMRrR4wBbIDX6220 -> tool:nanobot-harness-v3:call_01_Co95Sdt0AXFn116VtQiz4806 -> tool:nanobot-harness-v3:call_02_LcWHREO3zciajCAAClyh7148 -> tool:nanobot-harness-v3:call_00_NcBH5iK8BBMUqOduyIXP3706 -> tool:nanobot-harness-v3:call_01_IomHMvApsQGzjyc0kIiV9139 -> tool:nanobot-harness-v3:call_02_exXdTNyFtKagdB7WbYao0583 -> tool:nanobot-harness-v3:call_00_4u1XqJ0D0wER9yxAyoQL0003 -> tool:nanobot-harness-v3:call_01_sUxUYhwd02U6jYGGUVPB0291 -> tool:nanobot-harness-v3:call_02_hz1iPgYEx12zwl03sqmQ4652 -> tool:nanobot-harness-v3:call_00_EgOT45xGsjWmI90cB6DB2833 -> tool:nanobot-harness-v3:call_01_4ZeFf4K6dn6DsW9Pe4Sv8795 -> tool:nanobot-harness-v3:call_02_Gq6PSOrxfyNuBMmiqE2k8399 -> tool:nanobot-harness-v3:call_00_9HvFjXJdCFTVB5KLugz65481 -> tool:nanobot-harness-v3:call_00_7Lxggnk71k5esdZjrS9c4028 -> tool:nanobot-harness-v3:call_00_DkqgS1ghTsTYWC8u6auZ8974 -> tool:nanobot-harness-v3:call_00_s8pa6MpxYNnSv7TDbd6l9153 -> tool:nanobot-harness-v3:call_00_9JmvwWbQYMKqdCbADCZB8266 -> tool:nanobot-harness-v3:call_00_VpPOFotzkziFRGcOYznp9137 -> tool:nanobot-harness-v3:call_00_EfS6kYqMcMtuaQgnRGbk9692 -> tool:nanobot-harness-v3:call_00_uyE66C6NtXkX1oLKFiR13702 -> tool:nanobot-harness-v3:call_00_WSDxaQ5m1qtJBM5QUhNx8473 -> tool:nanobot-harness-v3:call_00_LgnpRW597c7I6TXaUVWj3040 -> tool:nanobot-harness-v3:call_00_aRF0PIyOcJFTNez7dWkb9650 -> tool:nanobot-harness-v3:call_00_aaHgXrRqFlfNTe8VfGXR6299 -> tool:nanobot-harness-v3:call_00_xmYA9C2xszJA5CIgV6Hs2391 -> tool:nanobot-harness-v3:call_00_EyUoZcrvuFDi8ZhfUgON1016 -> tool:nanobot-harness-v3:call_00_M0ZsTH64o6Q7zgecVtRU9135 -> tool:nanobot-harness-v3:call_00_AlxSWtDmTE0Bj2JjPem54669 -> tool:nanobot-harness-v3:call_00_40agxHVyG4mXafOS1hQd1345 -> tool:nanobot-harness-v3:call_00_x0TX78K6ZHNlFaLQOb5f2023 -> tool:nanobot-harness-v3:call_00_VonCRr1MgF8Rkg2mfq397584 -> tool:nanobot-harness-v3:call_00_CLh1xOJt4kxzslYzpchI5930 -> tool:nanobot-harness-v3:call_00_13pymJ66Gv760GvT1asa8848 -> tool:nanobot-harness-v3:call_00_JKsTTzAhCse8nk1x7TGL0370 -> tool:nanobot-harness-v3:call_00_JXl14YRb1XMgkSqiJE9x3107 -> tool:nanobot-harness-v3:call_00_2dHcFFlerihIbWNgBrmo1870 -> tool:nanobot-harness-v3:call_00_FP8lWm8nlQjd1L7imTcS6698 -> tool:nanobot-harness-v3:call_00_HksI12ThEwr5pMJ8iwF89941 -> tool:nanobot-harness-v3:call_00_eEyow8yIdZSAsRSCN3Yv5259 -> tool:nanobot-harness-v3:call_00_rZbIZQCFHnabGzgc50VZ1509 -> tool:nanobot-harness-v3:call_00_sRVjQtn6uq6qYdWz7OLk8113 -> tool:nanobot-harness-v3:call_00_AIrmOEwzUmmeUPo29nU32653 -> tool:nanobot-harness-v3:call_00_nyfgeMeGiKKJALy2E5kv2596 -> tool:nanobot-harness-v3:call_00_g0VbFcYwMJCQxvfAIoar3410 -> tool:nanobot-harness-v3:call_00_tUnzWBjtOTf4ieFsSyXK4239 -> tool:nanobot-harness-v3:call_00_zqXTNCsB5TFeE7infuyc1826 -> tool:nanobot-harness-v3:call_00_PAuGdp9UQcQBW5RXQY2G0680
- 关键路径耗时：1.269876
- Makespan：312.1682
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
