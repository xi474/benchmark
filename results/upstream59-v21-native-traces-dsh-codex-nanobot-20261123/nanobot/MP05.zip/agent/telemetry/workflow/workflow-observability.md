# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP05__WK4aag6__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（75 节点 / 74 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：75；执行边：74（observed=0，inferred=74）
- Execution Trace Graph：`observed`；temporal_next 边 74，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_YG1Q9W80TpEjUJIqbAdX9601|7d6dad6d-78da-4feb-b5b2-8ef006ad6302 -> tool:nanobot-harness-v3:call_00_JpGO8VLSJlaIdSdWYi0q3257|d3dd9457-d52f-4839-b555-c3efb2ad2504 -> tool:nanobot-harness-v3:call_01_rHfqdGa5GfGFmUZ3cKDu9373|8b86fb54-7993-4cfe-a8f9-c61a381de0da -> tool:nanobot-harness-v3:call_02_46C4vCKBitej1vJuc3Hi8851|ff32d3b8-2c87-484d-a6f6-7637a9629b75 -> tool:nanobot-harness-v3:call_03_eNCuxMjadJ4qAF05pDGG1330|a1126731-c401-4d49-b683-8fae920e1564 -> tool:nanobot-harness-v3:call_00_zzgZWhRaBeKEb7ofJwvc2074|32f08958-4798-41fa-9146-a6eae7c814a9 -> tool:nanobot-harness-v3:call_01_XsWMOpGhg45Eokferz2J7857|900de231-4ad0-4b70-847f-f28bded5550a -> tool:nanobot-harness-v3:call_02_SY7P5DKelG4EjeuBqdWv8601|755aed10-8116-4d2c-b35c-46ef7509e0df -> tool:nanobot-harness-v3:call_03_aoIgrA9Ev0sCQsWCZp7m6629|8a4f09cd-3d89-4110-b046-e370203a878d -> tool:nanobot-harness-v3:call_04_caE1X382Iv0S0akf3xCd4542|d2936342-d18d-4074-9091-37680126c470 -> tool:nanobot-harness-v3:call_00_itG97bwMiaVLeJQtyLCQ4344|ba305e68-861e-49cb-9ee8-bfbbba727e94 -> tool:nanobot-harness-v3:call_01_DkmxHiURY4c3bDGoOH3a1484|8cdb2a3e-a5cf-4587-b959-7a2f5d5bac5b -> tool:nanobot-harness-v3:call_02_IFUP0fazc9bTKCDy5fuI3678|6a1b86cc-82d2-424b-8554-858f25e25fb3 -> tool:nanobot-harness-v3:call_03_n5XeK61B3u7m38tQTHfI0526|da308422-c5c0-4baa-a2f1-bac3ca102c4a -> tool:nanobot-harness-v3:call_04_M2j2LrxpCvVADwG7hV0E2238|fc5e4056-67cb-4b64-8b60-6afa2194eb35 -> tool:nanobot-harness-v3:call_00_1VN79XVSDbRb0N1BqyEV5421|0e3668f5-2ad7-4a42-9589-31c4239a7cad -> tool:nanobot-harness-v3:call_01_SBSidF1BAG1CsdJjLSsa0166|0ab11f21-f851-406e-8cb3-fe6bd35506b2 -> tool:nanobot-harness-v3:call_02_BIiRUt4tMNMl8rOCQEVq3524|3b0638de-3c95-404e-9b2e-490724c11ea9 -> tool:nanobot-harness-v3:call_03_Y2QLKtw65oVAD3vo8Ass8804|a75ba874-5ae5-471c-b62b-c0fa97222b2e -> tool:nanobot-harness-v3:call_04_ThZlTelGiovVLZQgLSu41765|4b59ecb3-50ee-471e-abe3-d16d26a2424b -> tool:nanobot-harness-v3:call_00_11GhWTmrhsgnLj4ixP1l0745|f3e12950-6ff2-4cae-899e-b7c0650a97e0 -> tool:nanobot-harness-v3:call_01_IrgcmYXmWoGcenciWN4p0390|9a768548-6be1-4484-9fbe-8662abfe853a -> tool:nanobot-harness-v3:call_02_kxKJkNjzfyoOcn1aQXdK0663|0f7213e9-2a00-49c1-a654-a6c5a468d58c -> tool:nanobot-harness-v3:call_03_PvR9AvBmqzDZdGr8f8w83144|076fac4d-6c4f-40f6-a880-67f6a98453e4 -> tool:nanobot-harness-v3:call_04_XiD1g0N7g8aaiNrStQgh3197|c029bf6a-d4da-4835-aaca-e4c687da7ca2 -> tool:nanobot-harness-v3:call_00_1Y6Et3xCEQatueuynfy59188|5636a392-03e4-4c0e-8a76-7387e3dde442 -> tool:nanobot-harness-v3:call_01_MZbcPff8Bpnd6fVhfttf2686|2e84140c-8f7a-4e01-ae36-2493be238f54 -> tool:nanobot-harness-v3:call_02_oxbAYCHd2d6VCaIT4BpS5607|1e910a27-37db-4226-9c95-d762df11a31d -> tool:nanobot-harness-v3:call_03_7RkSo0jvasQ7FdDisJUo1736|6cf571f8-d148-4013-848a-c454e3c8f6b1 -> tool:nanobot-harness-v3:call_04_CrYZX6Kz3dDxYGhFLAXK8695|e57b1444-05ea-4555-bbc2-e2c9a6d38044 -> tool:nanobot-harness-v3:call_00_k5P2Pi6p4TFdBFNg0E690332|c79e30f4-99a6-457f-8579-50f9f4b1bde7 -> tool:nanobot-harness-v3:call_01_f76Dhz4aWT2eowkjS3wy1760|b4871be3-bbda-406a-9fbb-3ed6d252223a -> tool:nanobot-harness-v3:call_02_2a2nUXIOI6CW8qyoI9Yc0336|fa1b33a1-cbcc-4282-aba8-926680d31aa0 -> tool:nanobot-harness-v3:call_03_8D1c02hZjMiR9OL5arNK5211|1a919409-0c5c-4490-b306-d39f181188ee -> tool:nanobot-harness-v3:call_00_TV318VSiYmXut6bNvDWQ3898|a3e0c1c5-9b08-4968-99ad-b573aa4cf558 -> tool:nanobot-harness-v3:call_00_hPHBX0PviQsauF34u6jJ1239|a0438f44-f00e-4834-aef9-5efb55e4201b -> tool:nanobot-harness-v3:call_00_bH7AqV2JPR8Wg37y2LLr4685|a9c59f5f-df09-4930-aea9-3e3551ad3536 -> tool:nanobot-harness-v3:call_01_VMLs02FTbqoaePi3a9sy1065|e3e84f97-a2a9-42aa-b62c-2330ecbea9fd -> tool:nanobot-harness-v3:call_02_59DnIjL2bvQ7WHc8MM0G2565|1793ab53-cc7f-41df-942e-46a32c31dbf5 -> tool:nanobot-harness-v3:call_03_YU8O4RSiYVpWP4dGbFlS8813|07efabc1-0846-4d61-b273-930fff7b2489 -> tool:nanobot-harness-v3:call_00_O0uW5FqHDEoeElk4bAEz1985|7bd2211e-8056-4a70-80e2-37cf74f1c588 -> tool:nanobot-harness-v3:call_01_4YwdGGHfgnN3CWF3Lf0G0560|a318e7b4-7f59-4781-b737-4b1f0b10a230 -> tool:nanobot-harness-v3:call_00_9LZy8ot4zoo2CeTsaGNj6253|c2b03fcc-ddd5-4cb3-9751-8c788285c0f9 -> tool:nanobot-harness-v3:call_01_JeQH9ieUDsXz6tg82Xwg9950|db6dc044-eb48-42ec-9387-b4c295c61c21 -> tool:nanobot-harness-v3:call_00_lnQJYiicN3UJyGzGtdPY1790|6824b2c4-1580-4106-8e06-9429905e9c8e -> tool:nanobot-harness-v3:call_01_NUVfY7eBfDkN9nlUx7kN7484|61591b00-ad82-41c9-ad33-4e5252bce2d9 -> tool:nanobot-harness-v3:call_02_Qr8EgrWP3kftMAdIW88X1972|7274a9a2-7209-4534-9e9c-53510087d733 -> tool:nanobot-harness-v3:call_03_XyWfIcH2eXKy2mdisyj68313|05e93e9c-7850-48c6-952e-799162ab7e2b -> tool:nanobot-harness-v3:call_00_ePqXDct4miQDDDu0WFJz7851|15528dd1-0b18-4217-a81d-351f9670fe9b -> tool:nanobot-harness-v3:call_01_Yn1gVEteGis5c54qbD2D5740|e1bf8c03-df10-498a-938f-37c5f0dbf1e9 -> tool:nanobot-harness-v3:call_00_TjOFj8WEhTSE5nKxoiqi3245|2770b75a-61ec-40e1-9929-a1d981242fee -> tool:nanobot-harness-v3:call_00_jDXbZVVT1WKlaW1sBPsQ4406|bd4cf99b-7a6b-4005-8a08-d1675d6e419d -> tool:nanobot-harness-v3:call_00_MoYI3jiXPmnmD4RiWJFQ6803|e413f05d-4be8-464a-914f-003b48b22aef -> tool:nanobot-harness-v3:call_00_c2nNkEJl9zg79SWWGtDU9500|2987eff6-0cef-4b31-ab4c-f27eb0ac96ad -> tool:nanobot-harness-v3:call_00_AwKUCpz4GnXxebHHypOZ2824|362b858e-a651-4dad-b6c3-771789b0a20e -> tool:nanobot-harness-v3:call_00_GTgbqL1ZcMLEBzd97Aa66185|5f94d685-73f3-4646-874d-bcf727928676 -> tool:nanobot-harness-v3:call_00_AdshgknLIzhJXblLcgYK2034|5786b092-879d-439a-b749-82b69933825b -> tool:nanobot-harness-v3:call_00_DVsJeHzWi3FQWK49De7M5226|e046661b-e9cf-4ee2-8968-86646a86194d -> tool:nanobot-harness-v3:call_00_ei8TuT7UHk7fAOaYkFIY0780|b4eb2b45-27bd-4443-b7ac-c3dd4d825bfe -> tool:nanobot-harness-v3:call_00_4ydsOAeCvhFpmCOcGwzi5896|f81a68f0-063b-4c53-a7ba-2a159748d8ba -> tool:nanobot-harness-v3:call_00_duYTTRjMlgFBOFshV7F03998|23c73ac6-ac49-4e81-8383-c274fa3a4571 -> tool:nanobot-harness-v3:call_00_gxWY0ZkxE7WUe6WZB2pF2808|ffc60af9-fded-4562-9a76-f751d8c8f475 -> tool:nanobot-harness-v3:call_00_VgeDbTfxqxQWo5iSiyh37219|f8d8cede-8c14-4e6d-bc72-c61c86a87e01 -> tool:nanobot-harness-v3:call_00_CimlLTtax61KfTF7amFB8184|f75eb57a-a13b-49b9-bdf2-bd97cea97732 -> tool:nanobot-harness-v3:call_00_EqhdLv5DAxsLe5hTIBKk4997|d1c4a937-7379-476a-b3a2-3cbdf47e476e -> tool:nanobot-harness-v3:call_00_l32znibNSv3456SUxmf00714|ecb12ef2-8e80-4477-ace4-d2fbde75b23d -> tool:nanobot-harness-v3:call_00_RTzUZ5XkKh2n4RQ4dfKE9863|de258e80-64c8-4e13-ad11-1930d0c51994 -> tool:nanobot-harness-v3:call_00_GgWmH35dqu51CCN2ZqEC4337|8de486d3-c53d-45ad-9562-4e62da96cd19 -> tool:nanobot-harness-v3:call_00_YNxXpUzciyd25Pzklkn83246|a1cbab68-80be-440c-bf5c-9e97e073db7d -> tool:nanobot-harness-v3:call_00_WQcyq7Gbg1viZx8cN7Kn3141|c0796739-bef7-4750-a4d0-22a73f3c4401 -> tool:nanobot-harness-v3:call_00_5p6rAj2FtfsJPzOC57ps2856|304d6890-50b8-48e3-abe1-a8419e455f5b -> tool:nanobot-harness-v3:call_00_iaY0oipCEGIAuwanpSlE7080|b41ca28e-58a0-4221-acbb-32aa672a94e1 -> tool:nanobot-harness-v3:call_00_ANeVvjOg3cCVNpPiuULR5032|cb9021b9-478d-43a7-9b32-b4043dbd45f9 -> tool:nanobot-harness-v3:call_00_E9UFkXXUbdgerXLWzfhJ1488|e89302c6-5ba9-4790-9595-50666d17e168
- 关键路径耗时：1.804237
- Makespan：527.647143
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
