# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP06__Kyp2jNd__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（88 节点 / 87 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：88；执行边：87（observed=0，inferred=87）
- Execution Trace Graph：`observed`；temporal_next 边 87，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_YYGr8KeATMEYezEyL1jI3512|8653ac33-0284-482e-adfd-738ac79f97a3 -> tool:nanobot-harness-v3:call_00_iqM1L7qyPod9DixKXm6R8259|57df1da3-40f8-4672-ab1d-1f1ad5f7c8fc -> tool:nanobot-harness-v3:call_01_eRmukcFFaqTiPLN9qw1o5572|f29798a2-c94e-405c-b137-037a8f0c00dc -> tool:nanobot-harness-v3:call_02_NVXPJVkQP6PfoPxEPR6G1420|42e7d33f-880b-46b1-9ba1-722bbe177f8a -> tool:nanobot-harness-v3:call_03_s42DCDPBMoDvbUysL0m96927|67f34d75-68d9-46c6-a10b-b4837fe15b4f -> tool:nanobot-harness-v3:call_00_LdUQP24OqeBPVWx3jztN5402|980da632-0a3e-4529-9471-a68b6c28a734 -> tool:nanobot-harness-v3:call_01_53DK3kiaCn4osvKW5L6R4796|e66c2c5e-b156-46ae-9c36-b1dbb4e64186 -> tool:nanobot-harness-v3:call_02_QZW9V2ovBSBjSYghVUpN8270|6ba02a76-8228-4786-9204-1c2b9be3183d -> tool:nanobot-harness-v3:call_00_W2tAwLHLFtMAP6veZShD6322|b88c62a4-0e4f-4a2a-aa80-6c81144b9787 -> tool:nanobot-harness-v3:call_01_AK9DZ3kNGGVARZC1lILY6141|a5c6e9da-582b-40c8-83bc-23c4f1632e82 -> tool:nanobot-harness-v3:call_02_XLQDLefSpc1lvbZafPgQ0889|9f2d4d2d-97ba-4672-b035-f80020fc2ea2 -> tool:nanobot-harness-v3:call_03_rtjGVm4AyVwKjRWJs1Ny7412|5a23c65b-fb66-4e3a-bff7-7953ca61c2d0 -> tool:nanobot-harness-v3:call_00_rzZa20FQ4WvxbRqp58VE6646|af309dce-9b49-4d90-a1b7-a933a0bba328 -> tool:nanobot-harness-v3:call_01_KdTcmFREmPdwtjYowTHu4973|5aa07121-2c88-481e-a97f-d0e574db2981 -> tool:nanobot-harness-v3:call_02_cLVOz7QrFJJOBVvX6n7T5139|96e15b23-152a-41b8-b918-cb4d8d878aeb -> tool:nanobot-harness-v3:call_03_ajFXCSZsl0fNAzSfh4Ov6284|e51b9c05-4b1c-4abf-8e49-d5617b5828e4 -> tool:nanobot-harness-v3:call_00_BP4iiJZaU8TBuOaqKdtP5322|75642dbc-8bc0-4368-bf9a-42f5a2d7f071 -> tool:nanobot-harness-v3:call_01_voTi3IdeHEWYkLJbJuSd6151|58c78373-7f29-4ea1-bf5a-4c81bdf7efc5 -> tool:nanobot-harness-v3:call_02_F6UGOIabhW8Nvc30cWjW1538|f9b2a5d3-71e7-4558-8b1b-bc8aa5ced202 -> tool:nanobot-harness-v3:call_03_OrXz9zHojXuFqEgkERsr2836|44741b4d-9410-41c7-8b1b-96a3526d949e -> tool:nanobot-harness-v3:call_04_RpOrAFP1GIcYXBtq7sPj3719|2ae19dea-95fc-4197-889e-0e794a894a7a -> tool:nanobot-harness-v3:call_05_HaN76qpLE1FljiTxH4wd6152|051efef4-45a1-44c9-99b6-02bbf3bfc2a5 -> tool:nanobot-harness-v3:call_06_yS8rOQk5ab4e1XChh4vL5820|0787d28b-1048-4fe0-b0b2-100124a7aa4d -> tool:nanobot-harness-v3:call_07_BHjRVM7mlRdO06SjDVeO8795|7681c5b2-2e11-44c0-a29f-ee05f3db6e16 -> tool:nanobot-harness-v3:call_00_IqgATenwbAQzNrAV1ni34638|e9d9e887-d0b9-4b47-955f-1282a4467b21 -> tool:nanobot-harness-v3:call_01_QplOmQQatmLMYONt5VZD5885|e39144cd-7882-4753-a0cf-2c41775b80f1 -> tool:nanobot-harness-v3:call_02_yTfUDQRpDtWT1ZO79ot85892|9b530fb3-867d-49ec-b0af-b8e6a261887b -> tool:nanobot-harness-v3:call_03_iAl8GMlCsYBlIxhPD0zH3768|a9ccbf0b-decf-43c0-9ce8-b1e231fc58f9 -> tool:nanobot-harness-v3:call_00_11EoW6P1LoBnzfhkTG2l4019|5000d702-7510-476b-8f9c-8a95712f2254 -> tool:nanobot-harness-v3:call_01_4oiKC2eOGK6pkhFvzEQW6611|b1369513-5616-4198-afee-b4b7ca63bdba -> tool:nanobot-harness-v3:call_02_4N0MPtFyrKw6cL1otq6u2823|94dfd5e4-cfcc-452b-9334-e61a66363867 -> tool:nanobot-harness-v3:call_00_h5aSdihk6ukgLDW1oiJs3996|816c99da-4e49-4720-9bf5-6f8fe5effcdd -> tool:nanobot-harness-v3:call_01_TUtLoWyq3Pf95Xgn8E039611|7d72f298-11ca-4952-9022-2145c50f5426 -> tool:nanobot-harness-v3:call_00_ZZDpXnMm2Kb8toQQI4Nd8655|ab3b85d8-39b0-4cab-a660-79e2ac905105 -> tool:nanobot-harness-v3:call_00_JZBGJpUVInq7A2VFAOG59315|96fdb0b9-e606-454b-a96a-655f5565019c -> tool:nanobot-harness-v3:call_00_mYWtdyL6wqiW6P22Rkb92270|93a39be3-51e0-4f87-b2f4-bb421b6e24a5 -> tool:nanobot-harness-v3:call_00_15Ppo5NTOf0nLpmreUI64367|b12a5ecd-d5bc-4052-95dd-8a2c93189d85 -> tool:nanobot-harness-v3:call_01_pgcouob8F1fTrgRqlXQ52529|7bd4a3e9-e0dd-480d-a860-426651e8e310 -> tool:nanobot-harness-v3:call_00_Q10njLAfTugfdi0Be7No0113|f22a5527-5f29-43d1-aea1-678567a5e5ce -> tool:nanobot-harness-v3:call_00_7KdQDEefGijzUbGeV8JW1270|f28bc436-0d8f-48c3-a8ba-8c2a85a81520 -> tool:nanobot-harness-v3:call_00_U2LWDGqyjnDlw6Uxl7lp2220|7f8cf285-8915-4f8a-ad95-cb6b909c4468 -> tool:nanobot-harness-v3:call_00_9RWhovphhgg8NVYg2kYk8798|24f0d093-996e-4ad9-908b-9620986cdb11 -> tool:nanobot-harness-v3:call_00_QQvgzOqOkVXfyCqnPTMb7233|6f41d74f-aa46-476a-a53c-281d0e16ee94 -> tool:nanobot-harness-v3:call_01_XulKdGzKJxn7EY0d0a3e8732|2a4e1f73-d4a4-4070-a788-dbcfb2b324d1 -> tool:nanobot-harness-v3:call_02_9J5kXRwTFezDmILT5vMS0278|0d7d9a3a-c4fe-4acc-b4be-0aef36de6cb8 -> tool:nanobot-harness-v3:call_00_ulj3SUFpd2TCoGv0bCY89256|f60fc3c2-86c2-486c-8929-0fa9e7f01350 -> tool:nanobot-harness-v3:call_00_X8L68TiqWjChpcuJaBYz6780|b430aa77-e8f5-4702-bce7-f92543b6fdba -> tool:nanobot-harness-v3:call_00_vthGOjtCeV9mLFQ5Qm7B8467|e8b037d1-5496-4f7b-bb79-01484ecdb300 -> tool:nanobot-harness-v3:call_00_QXWRN1eIWK0BD7UmrmkO0914|5e832308-15c9-49c7-a826-3cf77f54eb81 -> tool:nanobot-harness-v3:call_00_6d4CJQtvAcoNvQrLkblG3748|82839498-45aa-43be-a51a-fbada3c368d6 -> tool:nanobot-harness-v3:call_00_DRxxg51c9yXbIjC1PzgW8001|d6b703c6-ed7d-4b33-980b-f2340baead06 -> tool:nanobot-harness-v3:call_00_rmuI9LzCG4lupCxYbUZs5023|c4e518e5-03c8-4e3c-9d2a-d2255fc29c60 -> tool:nanobot-harness-v3:call_00_qM67G555Ax8QgsliuWQT5581|19133dc3-8730-489a-8a18-edbb787e931a -> tool:nanobot-harness-v3:call_00_7svTJ8okoslcymeAOnND1941|b167c828-a8ea-449e-8357-cb26a521fd9f -> tool:nanobot-harness-v3:call_00_0dDv8ub9ZxXWiErAyNPP3648|ca5f2664-9c0b-4b30-88f7-6d632d26944f -> tool:nanobot-harness-v3:call_00_RexaffzQ3cv6xdgMcnPr9917|0b4eb5ea-462a-4a48-86ef-c3459a485fc9 -> tool:nanobot-harness-v3:call_00_QjfIDmwKX7EvxiHmBBpk5792|002c75cc-33ee-4b3a-adcb-e245feabce49 -> tool:nanobot-harness-v3:call_00_UIrvPFTpBv5AKf8ZmDIN4771|5960c78c-2130-479b-b11e-5e374acca741 -> tool:nanobot-harness-v3:call_00_NSAL6i5zKIFStejbEm2P0843|01c40b3f-a152-4069-b7fe-d0ad349ca158 -> tool:nanobot-harness-v3:call_00_fJ1ntNLmHhxO7SnDeysz8307|c3f44ed5-9aa6-43fc-a275-0b4507a76ed0 -> tool:nanobot-harness-v3:call_01_CBYwl740oy3PZB7YvzVN9977|ec1cc78a-f020-4c2a-ad37-0e3511f0f8fe -> tool:nanobot-harness-v3:call_02_DNDT7TzkzOdIX4jYDyuH3784|e8deff1f-5fd9-46c4-80e7-539340380072 -> tool:nanobot-harness-v3:call_00_NOm7xxWDrOpbuL1IIttr7789|a5e7ebb6-648e-4d65-8199-3c21b2f90fbb -> tool:nanobot-harness-v3:call_00_25WZvn73uckWHdK0k7OV9669|110ce4e3-9fec-4bb5-8398-56b45f142638 -> tool:nanobot-harness-v3:call_01_o2Bar0YC5yocic8EIJK25271|8717884a-a8ea-4d4f-ac55-7e944376c5e0 -> tool:nanobot-harness-v3:call_02_y8fYmn8ZnPtRLIfn45Wu9598|5dca891c-2612-4247-aed9-12d50c8f91a6 -> tool:nanobot-harness-v3:call_00_rYKshMr5qizWv1yu3KMg7290|3076b83a-8a84-4b2c-90a9-9509d457c12a -> tool:nanobot-harness-v3:call_00_mRzIcCjNTW6HSy7gpPsn6237|279ee606-7e6b-4b9a-938d-4c38d6740f09 -> tool:nanobot-harness-v3:call_00_GKa5ul20bao4uoY4WoA98937|c6a5e705-3e92-4ca1-bdb1-391ca350c6ea -> tool:nanobot-harness-v3:call_00_esEan7e4sJMG2Kf6WMrP6937|a7665d6b-82ef-444b-9501-3fb666ffd13a -> tool:nanobot-harness-v3:call_00_BHCjie60LmaB7rzziXfD9726|4bc54017-9784-490b-9bf1-f5d5b2aa8cff -> tool:nanobot-harness-v3:call_00_yYxcYYFNodDtv8Qsxspd5304|9e229ea8-26f1-4db0-ad89-074722ceac3b -> tool:nanobot-harness-v3:call_00_X8lNcuNJCmYniRZVyAvk4268|eb20390b-3ec4-4ce8-87ef-ac7cc39343dc -> tool:nanobot-harness-v3:call_00_at4gLL64NOvImXDutXIQ8336|816c8ee0-5b23-4ba9-959d-96f22fc33f30 -> tool:nanobot-harness-v3:call_00_noUbJfSv36hVAvEOmeaB7293|958102bf-4991-4ca4-9a9b-b76f33f6b9a1 -> tool:nanobot-harness-v3:call_00_8ywy13Ph272RL5eUz40E8202|d57aa9a1-cdc2-48e8-af73-0fdc694aaa7d -> tool:nanobot-harness-v3:call_00_W5Id6erH46KgAf9TGxAr9457|54c6eae4-7838-419a-9a60-44c1b992271c -> tool:nanobot-harness-v3:call_00_yeY2xHeFJhZdT6w1LWP86141|6c095c29-9452-4757-a373-801263ebd140 -> tool:nanobot-harness-v3:call_00_3pWrxzjvzgkpgJYibcA73649|4f71f860-4ec6-4357-94c8-7068c4009d89 -> tool:nanobot-harness-v3:call_00_UuG5jKWsspobdaGDOa9Z2313|70d70b8f-6691-4430-b453-86cd1ff6458e -> tool:nanobot-harness-v3:call_00_n8w3PHYl0FzNwlZ4rDNW5748|040e6b9e-04f5-4512-a31e-570090d1adaf -> tool:nanobot-harness-v3:call_00_KSXR0MJk9O5OCLhLJyny9790|3df2eb18-0de2-4789-81d0-8bfcc4496031 -> tool:nanobot-harness-v3:call_00_pWIfA9RA1Bc1phj9LOn14335|6d9c2416-52ca-43b8-836a-364859fcdce1 -> tool:nanobot-harness-v3:call_00_BjV0z6X0sCXeREiiWrLO5210|527e0560-be54-40ae-b7ec-774ff6141e47 -> tool:nanobot-harness-v3:call_00_Zz3tTmVvOzJ4KT8YT1ga2785|d0894f12-2a55-4431-ace2-8b06d4c7cd89 -> tool:nanobot-harness-v3:call_01_byU4lIbjmQhUZ7ZIOL9I9759|5f6f2398-e26d-4d80-921b-e80ebb748398 -> tool:nanobot-harness-v3:call_00_KBMPxWncUb8dkKVQnXLw1249|9175f843-aa7b-409a-893a-deb6331d56f8
- 关键路径耗时：2.018605
- Makespan：393.702901
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
