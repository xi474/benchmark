# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP07__2Y68Tzb__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（67 节点 / 66 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：67；执行边：66（observed=0，inferred=66）
- Execution Trace Graph：`observed`；temporal_next 边 66，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_rp1HXlo5HAKnTjzAKGLQ5515|444febb5-f410-41d0-b5de-1c9f24172908 -> tool:nanobot-harness-v3:call_00_VCYEaVXUVMgu4cfip1Ur1010|349306fe-77d6-4fb0-ab76-c3f34e1eb489 -> tool:nanobot-harness-v3:call_01_KlcV6FYO28OyK9QhgW9f6885|d3d69686-9333-4ff6-b1a0-d17daf3ff7c5 -> tool:nanobot-harness-v3:call_00_O5ESlTCatGk7TTBNPuo08134|384f2ec4-391f-468d-8d30-6f1a6d8ba2dd -> tool:nanobot-harness-v3:call_01_NoBTAPL9qqLpWxGYlymt3494|a37e26c1-8bf3-4440-9a24-7d1109893371 -> tool:nanobot-harness-v3:call_02_CnIWVCmPO3AOGc7p3qZB1562|139ebf38-48d3-4739-b4d4-605da2f25518 -> tool:nanobot-harness-v3:call_00_B7EaCfwlSbn082AVWPsd6897|878e4b95-9439-4d79-9a29-bedb1e20d962 -> tool:nanobot-harness-v3:call_00_75AqKGXbwDe5i9mJzHOh7339|4c5e9f82-dc98-4557-aa69-d81e96b15949 -> tool:nanobot-harness-v3:call_00_0KO8muKlpyi0yHzCbICi7224|b90858c4-5f1d-41c0-a980-06278dd82bb6 -> tool:nanobot-harness-v3:call_00_BBclFoTTxQqXkJunqzCH6130|98b0bdb5-7b48-41fe-9073-f679d475a12f -> tool:nanobot-harness-v3:call_01_5g9M0ffVmPEjr0xWAa7c7168|dd5edf2e-c340-4385-a9f3-85b63806cd98 -> tool:nanobot-harness-v3:call_02_vMc1fiN3UrM1p1Re6mS52346|9324aab4-3477-4caf-b8cf-0570a4df89e9 -> tool:nanobot-harness-v3:call_03_emKNTb9iNWdOTfAdltbG2949|69d00f6c-83df-4182-9fca-a53461201612 -> tool:nanobot-harness-v3:call_00_crR1X2lZdULms1nh2vUs0854|3c4c7232-bbff-4e25-8c95-9cc6be061e08 -> tool:nanobot-harness-v3:call_01_bamo3HHZI92EJZLffGA08379|69273c29-f242-42a2-9410-75657205fb73 -> tool:nanobot-harness-v3:call_02_lPyzBQZtwHAQxqtippH19104|c62e84fc-5c67-4705-a626-25a2c98fd2e0 -> tool:nanobot-harness-v3:call_03_qyZDArcCk9AXSFEFzZsM8604|ac0e29ff-e2e4-4dff-8926-5ce798171d5b -> tool:nanobot-harness-v3:call_00_U3NOwtVPvV2deQVOUQDR8972|624b3b57-7ae7-43b7-8ff2-8cae57d072a8 -> tool:nanobot-harness-v3:call_00_LikBmXKMQEdqZWm2Kr9H2978|e751a1de-ace5-485f-bbb7-b002e2664fe1 -> tool:nanobot-harness-v3:call_00_8Ka2bbOQ88IQ46FXdaQ95100|32e8b7d8-191f-4658-974e-eeb7de38b86b -> tool:nanobot-harness-v3:call_00_m6lNQbFL80VptRIfR9nI4623|c31a90ce-91c9-41a4-bfcd-5021f502f104 -> tool:nanobot-harness-v3:call_00_YWJ3PDyB3P3QOjhMZqqr6511|7fd800ae-6b60-4f3a-8b71-b28d8dab3c42 -> tool:nanobot-harness-v3:call_00_UdrMjz3GiMWhInnkpMV77455|1f5e419c-4e58-4897-894c-2539c2401556 -> tool:nanobot-harness-v3:call_00_wLgFwaJAjNK9vLw4BNYx7726|2ec0b8f2-8779-4ce7-90fa-4c720a5629c4 -> tool:nanobot-harness-v3:call_00_s7mywfGgXe2K9GkrMhMr0014|7907e5e1-1164-4a58-9562-c7b5f9b497b7 -> tool:nanobot-harness-v3:call_00_nYhm1LvPxf5dfIpE7oyA7617|0676cefd-6210-4c85-bcf8-70a95c3a79bd -> tool:nanobot-harness-v3:call_00_g4HhrXest6Kphaj0A0qx5816|21e6b01d-df82-44c4-a8ef-5ed3019df6c4 -> tool:nanobot-harness-v3:call_00_hpzn5Ghk4jvr7u2m1cox6486|18756a70-c586-45e3-bcaa-739db43fe6e4 -> tool:nanobot-harness-v3:call_00_0JkdrvSsZL9gOL1oeFeR0635|a9a7fb40-df4e-4078-b169-dd8728ae4791 -> tool:nanobot-harness-v3:call_00_c4tDvK1F1uUxvAIdWJNw9435|b4bfd02e-fd61-4863-9969-ee973cfa6d13 -> tool:nanobot-harness-v3:call_00_VmSRkIWt2OGiwvSCb9GU4897|d80de058-07a9-42cd-94f1-5b208d2e651a -> tool:nanobot-harness-v3:call_00_GJGy8umwCK8FUbpJFHHt3689|4ae1fa0d-0597-407e-9f1e-b10ccd902081 -> tool:nanobot-harness-v3:call_00_huWXZNDlJeIWXby2m6nN8214|e72f66b2-ed20-410a-8ac2-796ad2e53471 -> tool:nanobot-harness-v3:call_00_hHbUH8ZuxH3Jm4YpQZGX1016|b4f7bc54-9bf0-407c-800d-df61da49a812 -> tool:nanobot-harness-v3:call_00_MoTSmQyEWm9gc0700iz66564|fedcc5c3-f1f6-401f-a3fe-859c9585867d -> tool:nanobot-harness-v3:call_00_A5krowY9zXfehjQN4guC4023|6808f7cb-4bc1-4923-8e18-810200305798 -> tool:nanobot-harness-v3:call_00_UK6iOI2j9DmXpR6zE0gS4560|f6a92824-9c25-4a42-b350-37c7649f24f4 -> tool:nanobot-harness-v3:call_00_fAvv5cCb59Aq0qIpGZMe1478|bade8eab-b287-47f4-aeea-a274575f13ec -> tool:nanobot-harness-v3:call_00_gbPNZWX65oJTIVL7qLlh1595|64948f9c-5e9d-45c9-83a0-61faa3a724bf -> tool:nanobot-harness-v3:call_00_Iayj6PlqpzUcRiLlGERz6165|ec0f6927-772f-4121-ba25-0239c656eecb -> tool:nanobot-harness-v3:call_00_bHOcquOQleIeOC7jJKs33029|e0d2371f-4e99-4d89-8633-5992581c1f6f -> tool:nanobot-harness-v3:call_00_lrpNxsCZFc67hoCY2vsP1911|ffdf1d3b-029e-4e50-930d-3c48c81fb30a -> tool:nanobot-harness-v3:call_00_XBUdtkPSkyPR66tTKgBh7019|3da22e92-f295-4740-94e5-89943466d81e -> tool:nanobot-harness-v3:call_00_ikVSz4ch660Ifi87I6dl5628|5b32ae9e-8732-4e8d-bbc1-1ecd4e0251cf -> tool:nanobot-harness-v3:call_00_gRUAwnh3Q9IL0sgzlC8U5466|0f42b6e4-af23-44cb-93cc-52aaf9fd246b -> tool:nanobot-harness-v3:call_00_YCjmIt4NzAHxUX4TNd5R8242|691ee876-569c-4144-a3f8-28b1daf97896 -> tool:nanobot-harness-v3:call_00_RcM9dETgO0xTlmTgjam08683|8334c2c9-f04d-4584-980b-eb67946ed6af -> tool:nanobot-harness-v3:call_00_kcYbH2ZX1odXAdwGm8x12609|6b975ccf-9bd8-4ab0-b8c5-075784ba2edb -> tool:nanobot-harness-v3:call_00_CDcKR09tcGIIdC0BWuIp1456|c117d7fd-801f-47e6-b34b-40c254f7db1a -> tool:nanobot-harness-v3:call_00_BUNOyffbBjoATJUYyENY3545|0e8e049f-409e-4435-a9e2-cbb003e4ecc9 -> tool:nanobot-harness-v3:call_00_9PFIFgXaGVXrz3Dszq3f5154|cdc0dd1d-86f1-401e-b9fa-6ada6a929b48 -> tool:nanobot-harness-v3:call_00_RsqDdZI6xKLdOgsv8tyV6370|691bb592-53be-40da-bfb4-42bd94c3ef02 -> tool:nanobot-harness-v3:call_00_WGyL8X29jdHvUqT9k7h10234|eb2677dd-69b9-45be-9541-cb9796380814 -> tool:nanobot-harness-v3:call_00_LnThTQq2bwbV7AHnmuxq8827|c89ff214-ede1-40b7-8b52-b77e86703337 -> tool:nanobot-harness-v3:call_00_EplxqFuaEItvGzVd5a8r3566|c1103067-ce22-463b-97f4-127db5371a92 -> tool:nanobot-harness-v3:call_00_nPkaQfIwipmKlL8N7NaP1363|e19e9f8d-6dde-4350-8e0f-93cc3f674e59 -> tool:nanobot-harness-v3:call_00_yRj6vIY3R3VCSjoYuSty4814|8583815c-42cc-4a32-bc41-8d15440c9286 -> tool:nanobot-harness-v3:call_00_Xt4Uj2AhOTNCpzFYZUYy0668|ead66f33-52f9-438d-b63b-31acdb7cbc48 -> tool:nanobot-harness-v3:call_00_lDh4TRBnDadq55s7YTvM6192|47d824d4-382b-48d7-a1ce-dc4292ff8908 -> tool:nanobot-harness-v3:call_00_Ygcml4pP2UvQ8a7BEhv02795|2ceb115c-a72e-42db-8e62-bb0274bb141f -> tool:nanobot-harness-v3:call_00_zob8D0OGhDMefHYOWawI7067|b0ea68b7-9022-464b-9dd4-13cd5653d4a4 -> tool:nanobot-harness-v3:call_00_wXopUvdnfN6mvhmD4Kro9352|a5ce85c2-2e04-499b-9b32-cdfe780f42e4 -> tool:nanobot-harness-v3:call_00_w8JQpKee2P6mYudKOJXY1227|ccd03245-c22e-478d-b947-fa9b81d6fd6b -> tool:nanobot-harness-v3:call_00_OQMkx7DMgFaqNLXOrcwh1395|a714351c-694c-4c5f-8c28-fcccd7fda5e3 -> tool:nanobot-harness-v3:call_00_1la8DWNTwe0OFzpXBq9o2929|4e942087-2a39-4ba7-978c-0ef3f81bda81 -> tool:nanobot-harness-v3:call_00_CAwbyyapDF4qVPwRTPcQ3153|735af9ce-a384-43ef-a0bd-fcd2392d1d80
- 关键路径耗时：1.69382
- Makespan：421.43575
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
