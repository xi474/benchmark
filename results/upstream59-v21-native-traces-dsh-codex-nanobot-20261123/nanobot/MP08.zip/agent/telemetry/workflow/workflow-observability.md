# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP08__BQLP8ck__env`
- Task：`core6/MP08`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（55 节点 / 54 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：55；执行边：54（observed=0，inferred=54）
- Execution Trace Graph：`observed`；temporal_next 边 54，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_a8zgZWEDn6pLCR363Kiq4348 -> tool:nanobot-harness-v3:call_00_ezkKx6PSe7SpF2XajEyn4443 -> tool:nanobot-harness-v3:call_01_SnRTNYmu8bey7QkqnUmT0337 -> tool:nanobot-harness-v3:call_00_A66u9llFCRvLiaxj8ZPH5884 -> tool:nanobot-harness-v3:call_01_IuZVL4K9WybjTMx8NDrx4912 -> tool:nanobot-harness-v3:call_02_RNUkWngtbZRSazZuzMl77197 -> tool:nanobot-harness-v3:call_00_OndZ39Z5rrkKi2YoQlHS3714 -> tool:nanobot-harness-v3:call_00_Q6HNldQPsr86Z0GvZshL4680 -> tool:nanobot-harness-v3:call_00_MeXzDrsyU0EE8r4MwZw43163 -> tool:nanobot-harness-v3:call_00_S6YqvqoUCGPX4UFWEpQw3972 -> tool:nanobot-harness-v3:call_01_knmMxP9A0Boi4BaslAc82357 -> tool:nanobot-harness-v3:call_02_fTe5XSK3bU7IkJ1JKhrk2892 -> tool:nanobot-harness-v3:call_03_GoFpUosqCMMmAfKuxwy78112 -> tool:nanobot-harness-v3:call_00_hsrveuGr1sA3HOTdzfyy2982 -> tool:nanobot-harness-v3:call_01_ZkDTP7bz7IF3ruh6KOv05472 -> tool:nanobot-harness-v3:call_02_2fX178TMKnDKpWiq6pUV6526 -> tool:nanobot-harness-v3:call_03_E1nj15YdC6RJJNEd6ugz5330 -> tool:nanobot-harness-v3:call_00_cHm2g20LQSeecRgrH6F48148 -> tool:nanobot-harness-v3:call_00_u0b0JkZHiELQSuaMm4P51239 -> tool:nanobot-harness-v3:call_00_FVBPaQPejjBmd4p7BLfd9375 -> tool:nanobot-harness-v3:call_00_j5KGQurCMn9d1NJPfGvh0805 -> tool:nanobot-harness-v3:call_00_cRcRQc3WvwzFfCBBcTBJ9066 -> tool:nanobot-harness-v3:call_00_QBgXphA1KNwViXyipGll9531 -> tool:nanobot-harness-v3:call_00_kCQVxjYRoa5Vhq9EJNzE7189 -> tool:nanobot-harness-v3:call_00_C5AH4gWPw48wXu65rOnj8972 -> tool:nanobot-harness-v3:call_00_xJDtCTvktou5DL8Oqm7m5930 -> tool:nanobot-harness-v3:call_00_89QbvkL3OwjIjE90lvJ14113 -> tool:nanobot-harness-v3:call_00_CXbWwCANuzdm4XTd4Ur77702 -> tool:nanobot-harness-v3:call_00_121MDKTSkTtHPPGJoyxA7130 -> tool:nanobot-harness-v3:call_00_rHTaZJ1wBeOjbKnX6c0b0764 -> tool:nanobot-harness-v3:call_00_7lbfoCcl4xpDhbF2Jcau4463 -> tool:nanobot-harness-v3:call_00_b1VUgU0zASPJ6Ud9alsM5150 -> tool:nanobot-harness-v3:call_00_pOZul8MVTAXbIfRwdRUL5581 -> tool:nanobot-harness-v3:call_00_MpWQd6h1qKbRVn7oPSmf1552 -> tool:nanobot-harness-v3:call_00_FaLBj9onkyTix2v0Ch9L3535 -> tool:nanobot-harness-v3:call_00_KUckIAZMbXi55TfZ8lAu6827 -> tool:nanobot-harness-v3:call_00_GlyoQZEpvJbGC3oSjjki7735 -> tool:nanobot-harness-v3:call_00_prWO9zPFL1GjlQqCQeVP9137 -> tool:nanobot-harness-v3:call_00_dNaDr01wW3K28OTfTYdD3787 -> tool:nanobot-harness-v3:call_00_rBz9Ngs6fGVVoLnDltNi3818 -> tool:nanobot-harness-v3:call_00_PfBWoB7mJPUguAv6RY1Y0917 -> tool:nanobot-harness-v3:call_00_yZHIVQEwqwegZdSGQmFW1947 -> tool:nanobot-harness-v3:call_00_N6D1NMbl9GXTkcBa6fJh4174 -> tool:nanobot-harness-v3:call_00_3saOSeOJtmJZ8uJoMrXO6469 -> tool:nanobot-harness-v3:call_00_70haz3qJU6d3QVqKprd65591 -> tool:nanobot-harness-v3:call_00_zTe1rVVRgiCRqaEZlMub9142 -> tool:nanobot-harness-v3:call_00_slCjbNYBD83AtIlNaPUm6365 -> tool:nanobot-harness-v3:call_00_YHgJmZYGQg1LVLFkfHF20249 -> tool:nanobot-harness-v3:call_00_NKiJddUjB8bXgMS1Gafh3883 -> tool:nanobot-harness-v3:call_00_siCOsGYDrRG6mdHqJQZ95338 -> tool:nanobot-harness-v3:call_01_kCYfbGVfM14BlaUU3oLC2402 -> tool:nanobot-harness-v3:call_00_cR9iO96TS2lACVyL61Og0926 -> tool:nanobot-harness-v3:call_00_kZEgxWeg7rSCCZgyAHfA5453 -> tool:nanobot-harness-v3:call_00_0cH5X7OLnHwpyuigdL249090
- 关键路径耗时：1.345548
- Makespan：288.432768
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
