# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP09__NbXHt6V__env`
- Task：`core6/MP09`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（99 节点 / 98 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：99；执行边：98（observed=0，inferred=98）
- Execution Trace Graph：`observed`；temporal_next 边 98，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_UCfkvFMtI6aZ8kcy0p113094 -> tool:nanobot-harness-v3:call_00_XS9WNe0crocDp21cDosV2627 -> tool:nanobot-harness-v3:call_01_69wCm0Qdo6ZR3oR56B7X9606 -> tool:nanobot-harness-v3:call_02_KNPnqwIh4DcLYfS0wL9w5970 -> tool:nanobot-harness-v3:call_00_GiIxDE1FO7Pd1otBccWp1895 -> tool:nanobot-harness-v3:call_01_4qDBqh9SAxiVSEuTeXBe8218 -> tool:nanobot-harness-v3:call_02_z5XVPRVN8AgoRscwZ2Bt9150 -> tool:nanobot-harness-v3:call_03_rWq6M90SAMbUseN4Q6QA4693 -> tool:nanobot-harness-v3:call_00_Z8ZrxBy9EztOQTDXy7ZL0520 -> tool:nanobot-harness-v3:call_01_Z8ToeG2qlv2l0Hc8uHd02371 -> tool:nanobot-harness-v3:call_02_TXSxn68X7pMPUymVybyT0782 -> tool:nanobot-harness-v3:call_03_af9P9BLttR8vBLCqDuvW4454 -> tool:nanobot-harness-v3:call_04_OUva3xUy6Lrido3yb1Lj0219 -> tool:nanobot-harness-v3:call_00_i4Spw5OHJh4itTOVedGk6820 -> tool:nanobot-harness-v3:call_01_HrMNY2EB1l29S0mzUJ354126 -> tool:nanobot-harness-v3:call_02_kQ6qrQz9Rj3FPTm2xmRg4611 -> tool:nanobot-harness-v3:call_03_vrH78XFoOV2RYH5KnNDi9207 -> tool:nanobot-harness-v3:call_04_4GkQ6IIoGwDriYIfhS453197 -> tool:nanobot-harness-v3:call_00_zcjk1zzPeUrrwz9jmmDx1019 -> tool:nanobot-harness-v3:call_01_O0FqstTYz22eO8NnUIZE7080 -> tool:nanobot-harness-v3:call_02_ngKQ0S4weBHrxXGIRq5f6183 -> tool:nanobot-harness-v3:call_03_1gasM4tPgDZKT9Mrp8nb3346 -> tool:nanobot-harness-v3:call_04_XqtYsCrFMNhVyKOvMBlA0293 -> tool:nanobot-harness-v3:call_05_ll2X2qCIZyvMBSe1h3nJ9112 -> tool:nanobot-harness-v3:call_06_ljVGsyuGZZGRCs7PrfzW4883 -> tool:nanobot-harness-v3:call_07_UjE330gqIpvSUPskqApz0203 -> tool:nanobot-harness-v3:call_08_0AKcBqorRRJvkUyFgDFG2886 -> tool:nanobot-harness-v3:call_09_dMbuFVLxwbTpkzVDTVll8189 -> tool:nanobot-harness-v3:call_00_0nv3SeAZl9DPEvFgtlGw4700 -> tool:nanobot-harness-v3:call_01_tDdbAnNlhXMjN0ogQ8XQ6729 -> tool:nanobot-harness-v3:call_02_4bEJK0eSO1J2G6y7WhsB9058 -> tool:nanobot-harness-v3:call_03_vsmcKJPKQR9Wk9vhRy2i3494 -> tool:nanobot-harness-v3:call_04_yRc0meLwLZcCTsM0nIkK7547 -> tool:nanobot-harness-v3:call_00_mLvA4RT2H4mkuZPIvkHY4419 -> tool:nanobot-harness-v3:call_01_CHaQgU4XmEvE08VWgF8e0565 -> tool:nanobot-harness-v3:call_02_erxVJSgiZcy01QyRBa1l0702 -> tool:nanobot-harness-v3:call_03_ZTyZLSG6bpp3z60dnN383294 -> tool:nanobot-harness-v3:call_00_TXaiHe4a2l5PA2X9xKMY0160 -> tool:nanobot-harness-v3:call_01_iZsK23KcW8R6gawDHKvv9111 -> tool:nanobot-harness-v3:call_00_LQfwT6BaIcX05lW6etCW5224 -> tool:nanobot-harness-v3:call_00_varDBWZD1qRdgNp2qhLG9246 -> tool:nanobot-harness-v3:call_00_WCy09nHhRVL0nCrFOZhD4523 -> tool:nanobot-harness-v3:call_00_rfJBFQliGLhPNdsHRaKD1335 -> tool:nanobot-harness-v3:call_01_q4oTgVXoy9MVpuGlsItP0546 -> tool:nanobot-harness-v3:call_02_3HHIyqrpnkTB2pd5tsHl3714 -> tool:nanobot-harness-v3:call_00_U6TfOO9rbW5eIXfqwOme5589 -> tool:nanobot-harness-v3:call_00_XTzBudHS5VR0VC2ItU8d7012 -> tool:nanobot-harness-v3:call_01_WIAZZD9FEgNT0Sad8xfI1209 -> tool:nanobot-harness-v3:call_02_9P8h4Mn2yJY3WQIbDNXx7604 -> tool:nanobot-harness-v3:call_00_CEBrzqk1y8D5179FQzTe0844 -> tool:nanobot-harness-v3:call_00_YqXNCo7v2S7AyGctXBjF1555 -> tool:nanobot-harness-v3:call_00_HCe8twMNbucWcQwHzjJh4048 -> tool:nanobot-harness-v3:call_00_GILu3lCCgLLVemjHtgYE2564 -> tool:nanobot-harness-v3:call_00_OnO6aRF7igG4xhtqFbm77824 -> tool:nanobot-harness-v3:call_00_orokFZGamcjpRK7tSAx97559 -> tool:nanobot-harness-v3:call_00_fJnZWgP0W78D9zpjx2yZ2787 -> tool:nanobot-harness-v3:call_00_sNiOIGBXutJB2UFtHb8p7046 -> tool:nanobot-harness-v3:call_00_ZnngmF9PGXvs82O18bCB6695 -> tool:nanobot-harness-v3:call_00_XoO09Fq5UOntAA0hBFHS1368 -> tool:nanobot-harness-v3:call_00_0d68AJY9nJyrrKyw3omj5164 -> tool:nanobot-harness-v3:call_00_VXXPZjRhepYMa4RxTWNq2449 -> tool:nanobot-harness-v3:call_00_ZE78sq9qE6Lj7eiCD8vg8852 -> tool:nanobot-harness-v3:call_01_JXeHOJmHXZ419H5Jv5j62234 -> tool:nanobot-harness-v3:call_00_rHZUNEv31PY6XLOvFoM90136 -> tool:nanobot-harness-v3:call_00_zIA1UGgiuX9zAZ0Y1p7k6552 -> tool:nanobot-harness-v3:call_00_Oh4TJ2luMB8g6Eb8KI2r4988 -> tool:nanobot-harness-v3:call_00_fEeUol4HL5FMZrrsVpYq7632 -> tool:nanobot-harness-v3:call_00_WuBq0qkpmG6gvSrrKmId4462 -> tool:nanobot-harness-v3:call_00_dRVvMYo7ZxgtN4YsHCR30006 -> tool:nanobot-harness-v3:call_00_10WnUSjI4QiUpPyODoBD0168 -> tool:nanobot-harness-v3:call_00_wsz7YgyTfK1FcOwwu8u15081 -> tool:nanobot-harness-v3:call_00_eGeXP5AU5xoISj2mcdWx1842 -> tool:nanobot-harness-v3:call_00_cbttLjGzNRL3FwaVCPEb0628 -> tool:nanobot-harness-v3:call_01_97UsDKVpEByU5y3Z3Mn58930 -> tool:nanobot-harness-v3:call_02_terP8dvyLJqn5cuOkOW02219 -> tool:nanobot-harness-v3:call_03_H1KV9OdW1Ta6NtCvkaXx7510 -> tool:nanobot-harness-v3:call_00_ZSHr7T8we7pfRXoANa000481 -> tool:nanobot-harness-v3:call_00_RJ6KRyjxQXHkY26StYZg7879 -> tool:nanobot-harness-v3:call_00_i7R1UX3zmEFinoenRzJk8642 -> tool:nanobot-harness-v3:call_00_fYKjEJDVlrS9S9SfPT1G5125 -> tool:nanobot-harness-v3:call_00_qsH8ywQUQaEf4rFsGd1Z1017 -> tool:nanobot-harness-v3:call_00_GnquEDK9IwtcSEbVhfD97558 -> tool:nanobot-harness-v3:call_00_U7CTPhVHyBOTKcMCBJI04705 -> tool:nanobot-harness-v3:call_00_yYuhYE8FRrORAkUsCPus9098 -> tool:nanobot-harness-v3:call_00_8EMFckijlOhpI7SnKBbT7145 -> tool:nanobot-harness-v3:call_00_psbaWT9frlMByGUlOYMn3307 -> tool:nanobot-harness-v3:call_00_W99g0PV6R9SrKUpMQsDq9694 -> tool:nanobot-harness-v3:call_00_tTYq8q56uebqYlWSVqsa6070 -> tool:nanobot-harness-v3:call_00_xJfPkMMENe1UtwRTqnrl9131 -> tool:nanobot-harness-v3:call_00_lXkj8bqutbvimUImeSfW8840 -> tool:nanobot-harness-v3:call_00_wwCmQKxFrVCTYCvySWOo0310 -> tool:nanobot-harness-v3:call_00_ruc25Tlnp6SXKQtyKNM89819 -> tool:nanobot-harness-v3:call_00_EHUklsDmAlrmZFIiKbsj6025 -> tool:nanobot-harness-v3:call_00_d0DTLiez7jZAZvIkt6r40057 -> tool:nanobot-harness-v3:call_00_wKXCks3UCbStfVjtkhAI0984 -> tool:nanobot-harness-v3:call_00_7pdwiJbq9MOQguiaoEHh2724 -> tool:nanobot-harness-v3:call_00_Pz0h8iGPlV0gkgucUDss6044 -> tool:nanobot-harness-v3:call_00_XbPHKD7WgsMdE79N27yw7544
- 关键路径耗时：1.840876
- Makespan：373.950159
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
