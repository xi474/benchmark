# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP10__WuRsSqX__env`
- Task：`core6/MP10`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（100 节点 / 99 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：100；执行边：99（observed=0，inferred=99）
- Execution Trace Graph：`observed`；temporal_next 边 99，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_LIgHjtgLfT1v5kD77Ckm5055 -> tool:nanobot-harness-v3:call_00_xXvER1pLkN64LuXs3h5z4948 -> tool:nanobot-harness-v3:call_01_oytUVrrTQ4PwPBGg21x81258 -> tool:nanobot-harness-v3:call_00_F32v4E8MiEuRu9IWNZP22379 -> tool:nanobot-harness-v3:call_01_yvn6Z0QoeNTzOj19OmBo3372 -> tool:nanobot-harness-v3:call_02_jpTEOIMoqz8C8o2Uvprf7234 -> tool:nanobot-harness-v3:call_00_QMypSfcOY82KAT5eluim6343 -> tool:nanobot-harness-v3:call_01_PKzIRmhKy89ry3KOVLba4178 -> tool:nanobot-harness-v3:call_02_9nx1TE0xYF9G2U9pWxR85715 -> tool:nanobot-harness-v3:call_03_CRaPhDVZa1dYpu2MORG79159 -> tool:nanobot-harness-v3:call_04_qh0tKTTI0L2rm8mFAsyF5608 -> tool:nanobot-harness-v3:call_05_V2PkcEnImOdMI0HQKqpg0531 -> tool:nanobot-harness-v3:call_00_U8umwhzw54moDOV6mAVz7207 -> tool:nanobot-harness-v3:call_01_YalXUU7T8CGKcFO2qvJr8260 -> tool:nanobot-harness-v3:call_02_hn6rh9sLGkAd9nXgbBsO4944 -> tool:nanobot-harness-v3:call_03_zl4G7GM2SBwoKlYaQ1BW1740 -> tool:nanobot-harness-v3:call_04_HeHWrB3j9nKYptZDxzRv7421 -> tool:nanobot-harness-v3:call_00_Z93cRUSo5YKSrCH3FV9A2348 -> tool:nanobot-harness-v3:call_01_yq2dK3Y3LXn8Bnce2Ty01244 -> tool:nanobot-harness-v3:call_02_qvobOoBES9eaCNAFaFJj8636 -> tool:nanobot-harness-v3:call_03_YddUWoFyyt29eoSuQYLz2875 -> tool:nanobot-harness-v3:call_04_ez8tfyaTwNsfnqzyBkZV9006 -> tool:nanobot-harness-v3:call_05_eTOXEXo8QujP6sQ2K6QW3274 -> tool:nanobot-harness-v3:call_06_Ub4tgwtcYOgI4mOfOYaz7793 -> tool:nanobot-harness-v3:call_07_IOshwqJZwjiJdhKfH5uT9737 -> tool:nanobot-harness-v3:call_08_v3ybPeb5fcp15GekOSt29979 -> tool:nanobot-harness-v3:call_09_XOsGIQsHDyrpAQ3yqc4e4836 -> tool:nanobot-harness-v3:call_10_fE5jJKLguEDnpaef9RrH2435 -> tool:nanobot-harness-v3:call_11_PKIXQdnSMnZq3BuCytDt5165 -> tool:nanobot-harness-v3:call_00_cSvlOBUSePD6mHXJjTI34790 -> tool:nanobot-harness-v3:call_01_iLAaWNgOy66AHzVwwc3M9663 -> tool:nanobot-harness-v3:call_00_XufTJTsWBub5qS3urXc87161 -> tool:nanobot-harness-v3:call_00_Lpcj4MPCtr4OvjIft84v5942 -> tool:nanobot-harness-v3:call_01_oINFYFPNYCNZcIK22VkU6359 -> tool:nanobot-harness-v3:call_00_bXUOPwWh1A5Enjl2n8B23071 -> tool:nanobot-harness-v3:call_00_FiI6X9oWvlkyP7nf9cs50495 -> tool:nanobot-harness-v3:call_00_nY7N4JmiYOwFFqe539Mb2548 -> tool:nanobot-harness-v3:call_00_IEHKOkjoxfttagaKsv4G6531 -> tool:nanobot-harness-v3:call_01_cA3tLQUrtsofjExq3XrN4102 -> tool:nanobot-harness-v3:call_02_LeXVupeJJ4AIhxwdhv701832 -> tool:nanobot-harness-v3:call_00_2XU4AAbOyexoyE1C0LC94951 -> tool:nanobot-harness-v3:call_00_Eb2IuVlDlHzlLjNhopCL1570 -> tool:nanobot-harness-v3:call_00_KS9ff93dZKhdQyo7jIzs8710 -> tool:nanobot-harness-v3:call_00_PGsC2wj260naGMoflKqq5594 -> tool:nanobot-harness-v3:call_00_91N2JwHMdZuY376JVmqG1928 -> tool:nanobot-harness-v3:call_00_UZJrjuT6vSFW8YCuAVoI6213 -> tool:nanobot-harness-v3:call_00_0vgRxSecihRwXWpXpObs2197 -> tool:nanobot-harness-v3:call_00_ta3HvW0hzWDS3S0ByQTr1417 -> tool:nanobot-harness-v3:call_01_iLX3VjFNYFL4mcfbx9HJ8642 -> tool:nanobot-harness-v3:call_00_cjqW2bjBkrIMVfZBzbiR6727 -> tool:nanobot-harness-v3:call_00_VxEtUzlW9eAjoNXEpgXn8701 -> tool:nanobot-harness-v3:call_00_t8zmVHiSsMDyUt41Dbvw3535 -> tool:nanobot-harness-v3:call_00_LQsajqQhC9TylsH83m927016 -> tool:nanobot-harness-v3:call_00_hLgurbAWW3TBOFsKNrhn2553 -> tool:nanobot-harness-v3:call_00_YzktT9JDnFcX8dLPuTQt4746 -> tool:nanobot-harness-v3:call_00_OMnatkYu8MnMDP0aWRAH4427 -> tool:nanobot-harness-v3:call_00_b7PFu5L6BDQXXtli2w1C1393 -> tool:nanobot-harness-v3:call_00_c3qtZVTnOir1FxI1WZsH2030 -> tool:nanobot-harness-v3:call_00_7QPh59cD5y2NJ8JyAqMP1756 -> tool:nanobot-harness-v3:call_00_dbsazlhtdlz41l7s7zbi9879 -> tool:nanobot-harness-v3:call_01_y2nOJZa1PqvOvnxXh8ER4918 -> tool:nanobot-harness-v3:call_02_hOj88CLphj4uRwLLsuRr4499 -> tool:nanobot-harness-v3:call_00_CTtEyIJOmxh4UQOf9rbs4717 -> tool:nanobot-harness-v3:call_00_EJwZ6gdncThJnI2N3Ic97954 -> tool:nanobot-harness-v3:call_00_czV1RUvHi6KiApIt7n889647 -> tool:nanobot-harness-v3:call_01_wDqgP3VQDy0uHTz5R7ra0849 -> tool:nanobot-harness-v3:call_02_GR23dfIa7tIJXbRBW8p46436 -> tool:nanobot-harness-v3:call_00_VXSZ93ikEu5X3q9rMBN35093 -> tool:nanobot-harness-v3:call_00_k5dCYD7AcAfGGLorWZM18758 -> tool:nanobot-harness-v3:call_00_slLlFe2sPgSEKuqIumWo2147 -> tool:nanobot-harness-v3:call_00_S4KKsqVhKuSEFdTVVdES3628 -> tool:nanobot-harness-v3:call_00_vZP7Sr9yqGm8jfmlonp96557 -> tool:nanobot-harness-v3:call_00_tUu4JOjUyqO6YL0k6mQR0130 -> tool:nanobot-harness-v3:call_00_cjXlvOkpuesGC1fs8cCU9099 -> tool:nanobot-harness-v3:call_00_70ZuOV10BKyIqVkWM5S29161 -> tool:nanobot-harness-v3:call_00_w1BXub2k1V8jGpIo3aJV8525 -> tool:nanobot-harness-v3:call_01_rTvn6E8OMRf9z95rdQkC2141 -> tool:nanobot-harness-v3:call_02_gtkxU8cdKX1djuQtTRk21593 -> tool:nanobot-harness-v3:call_00_9XaAiyvV7jQ67cJqD9Et8419 -> tool:nanobot-harness-v3:call_00_wAtBglQdEYLs556T7jtz3445 -> tool:nanobot-harness-v3:call_00_kHm2dlOvG8ctw9hJHnMv2460 -> tool:nanobot-harness-v3:call_00_5xzNvYymRv5Puh93hJIQ3123 -> tool:nanobot-harness-v3:call_00_mU7fbpXPa2ahiLeakiGN2906 -> tool:nanobot-harness-v3:call_00_w2fXiAxuT42m8wDxjEom6585 -> tool:nanobot-harness-v3:call_00_a2C3Yj98Cc611jXnISIE6649 -> tool:nanobot-harness-v3:call_00_CCzO1ay5Ks0CC5usu8L63897 -> tool:nanobot-harness-v3:call_00_lLuOz9PUsty7CWQD8N6x2755 -> tool:nanobot-harness-v3:call_00_S5co0oLsikk2LeawVsw34941 -> tool:nanobot-harness-v3:call_00_B40jz5Pv9Z1u9aWG9myH0916 -> tool:nanobot-harness-v3:call_00_vhtGQti43s8uuzhDQXOA7117 -> tool:nanobot-harness-v3:call_00_aygH7XXJT1KXtXiZuwGd0586 -> tool:nanobot-harness-v3:call_00_jnE6Grm0HBpmupeALabN9808 -> tool:nanobot-harness-v3:call_00_S9DBV63esnsBFVpZqTBd2016 -> tool:nanobot-harness-v3:call_00_N3gnQu12IIYrP1A3Z2sA5783 -> tool:nanobot-harness-v3:call_00_iIToUg4AXMrnJf9PM8J26147 -> tool:nanobot-harness-v3:call_00_qSLuOgtYUPwuIKpH25aj0318 -> tool:nanobot-harness-v3:call_00_P6Sbo9qXOaDLdFhxFLOm1597 -> tool:nanobot-harness-v3:call_00_GsYJG8zhUOz7rbRpJa2o1918 -> tool:nanobot-harness-v3:call_00_SwNEpPoDS6fghBVUTdez3444
- 关键路径耗时：1.773395
- Makespan：371.521884
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
