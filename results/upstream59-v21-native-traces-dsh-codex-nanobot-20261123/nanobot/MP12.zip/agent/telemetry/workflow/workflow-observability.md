# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP12__DvNtjLr__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（75 节点 / 74 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：75；执行边：74（observed=0，inferred=74）
- Execution Trace Graph：`observed`；temporal_next 边 74，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_jkGtFRagScKIckhxrhFl5214|6e700844-06d2-411a-9585-ae9cf8915519 -> tool:nanobot-harness-v3:call_00_irjwBc2IqleRkoH9ZdtW1302|8f049b51-3164-4a99-b65f-6a76fe2cd503 -> tool:nanobot-harness-v3:call_01_DtJHtwNlqyjTmXbA4NIk4139|8c49fbe9-db84-4e8a-93bc-bb0adcf033b7 -> tool:nanobot-harness-v3:call_00_a5W3NCM2jdwkw3aXOPZ92335|42657bf4-6401-4a43-9961-247f43379f91 -> tool:nanobot-harness-v3:call_01_M3zssorgQEDUCes9SiMm7442|eb0add0b-52ff-43f4-a83c-09e813fb7797 -> tool:nanobot-harness-v3:call_02_EPprD5G9Fm65t4yWdJuO0008|bc09ec8d-4409-4840-bedc-e7b11932d526 -> tool:nanobot-harness-v3:call_00_uTAi3Z4q7KhC2zhznXdH2105|265f9b22-a772-4ff7-9149-5915ebc6ea2d -> tool:nanobot-harness-v3:call_00_MGGJ8hHDXv1T6K8YDN2e4054|34c801ca-19d1-42fc-ad24-943fb7b8bb88 -> tool:nanobot-harness-v3:call_00_EZVxlgpWEkES5ir3QvXo9778|0ab24572-33e7-4ad7-9c39-81e1d2c5df66 -> tool:nanobot-harness-v3:call_01_925yboNvzqHv2yz5nJ0k0919|8d68bd56-64f9-4fde-b3a9-088b885235e2 -> tool:nanobot-harness-v3:call_02_3oAFU1kzryWPGutUB26z4906|cbd19b4d-9e8d-4c67-8320-a9b52b5d5f57 -> tool:nanobot-harness-v3:call_03_I6YouNOmtJZSl0lWnA5g6316|31e0d464-8966-48a5-82b3-cfd4d734e68d -> tool:nanobot-harness-v3:call_04_DxwaGCOQ9BjDmpRqAF7F4467|5176ab6c-5779-4f3e-aa8b-0297aea81820 -> tool:nanobot-harness-v3:call_00_NRsmKLjXnjALGIIMhvTk4170|76ddf3d7-c3af-4879-9013-d516b3c8e5fd -> tool:nanobot-harness-v3:call_01_IzMQZcMGVd4jl4oysiBQ1740|e1dd2413-7e6f-41c0-9196-9a99dcaf0779 -> tool:nanobot-harness-v3:call_02_DzPbjUkBL8ef03Cswir60066|de6cc827-4f39-428c-9d83-74d2b7ec0cc6 -> tool:nanobot-harness-v3:call_03_slj3uoCYRiPW5KkB63jZ7193|dd2dbf27-37ca-4bd3-a0e1-48138ceb2bbf -> tool:nanobot-harness-v3:call_00_hAxK9Ls8wwTySuotW5e59843|81bb2191-26e4-4848-b5d8-6aaed07171d2 -> tool:nanobot-harness-v3:call_00_htjgZg1zd3LHTtP4f95P6769|ffb2fb5d-be16-4273-9e05-9d57e01d4ad9 -> tool:nanobot-harness-v3:call_00_DU9DgedBPYQQxFl5W7W86476|2a00f37b-af10-40e4-b984-6aad2862bc48 -> tool:nanobot-harness-v3:call_00_pi0i1WswmdNtm7HpBFPH6402|944a71ef-6827-44f0-9007-7e7747ab0025 -> tool:nanobot-harness-v3:call_00_3xE1bxgrRxHOG6xTCoS48219|916c1059-958f-4866-a94a-d08d239865d0 -> tool:nanobot-harness-v3:call_00_KpIP5YSHQZ80qF5TmFeQ4627|1b88fefc-6e1f-4a6d-8926-aaa81876c010 -> tool:nanobot-harness-v3:call_00_eTNez8gRLneKMhqD4EEG5685|0feb8543-40cc-416e-9bfc-ffec7960462b -> tool:nanobot-harness-v3:call_00_2CyLpoK4aj46mTjhPCsN5820|d11f9331-82ff-4063-a0fe-a9c92c8eb26d -> tool:nanobot-harness-v3:call_00_C1CvtEbwUQaM64XASgvK4704|b5b3b0aa-49a9-4d94-bf8a-4b189a3de8da -> tool:nanobot-harness-v3:call_00_6VSTXAqcwWEJf397uUxI8875|d43f92ac-8182-4cc0-b9ef-e7095c70d12e -> tool:nanobot-harness-v3:call_00_DPOOaNx6M29lZMdV8l081922|9d8715f6-c060-42a9-b692-ff48156c5ef9 -> tool:nanobot-harness-v3:call_00_tC86ftCDuUvN7udqbslB1180|a7bda1ae-00fd-42a7-886c-3f480929777d -> tool:nanobot-harness-v3:call_00_ZcBswON2YqYQOAGULWPa2194|388aa17e-5454-4024-b8b1-aa8adad38b41 -> tool:nanobot-harness-v3:call_00_dTXt9aLHJ2Wl5ig458ot9361|b1c1493d-de0e-4cfd-ae4a-35dd0ce9f50d -> tool:nanobot-harness-v3:call_00_8znF3FQCHuLn8ld4ZURH0289|fc36bcf6-af10-447c-a384-ff4080ee172d -> tool:nanobot-harness-v3:call_00_hBSwpaCewgJDvuB16F5w6544|5179a2b5-83f3-44e2-bf89-6365c3103e5f -> tool:nanobot-harness-v3:call_00_yOIwiCyUcbIIR3DBken88204|ef59cc92-e309-4564-b430-0b3d3fb61c6d -> tool:nanobot-harness-v3:call_00_Gj3bUyoyamT2KRqwY1FA0177|8ba61168-cb7c-4cf4-9b81-ee4e10df9a2b -> tool:nanobot-harness-v3:call_00_ewZhfFZbLo95PFappfeq8465|3abfe79f-20cb-4d79-83ff-78b21e287a5b -> tool:nanobot-harness-v3:call_00_nCnwbQojJUwds2otMKK99452|48464585-763a-4602-9fc6-ecdc4f260dbd -> tool:nanobot-harness-v3:call_00_RiIxYsbJINTEJD4RroGw9893|e8c01364-1d6c-438d-b40a-9ee6045c814a -> tool:nanobot-harness-v3:call_00_QXlG9EGDSKCXTflJeWfa0409|104f9423-3c40-4c9f-9371-bb74030be106 -> tool:nanobot-harness-v3:call_00_2Y4LkF8GPOYTbCVyzNZP8128|a883b30b-905e-4226-a6af-2a4ef803818a -> tool:nanobot-harness-v3:call_00_L6RkY6pe7AOEohtnVLuj4806|2a17f316-3423-4c20-8a3d-9a5a8f291a38 -> tool:nanobot-harness-v3:call_00_TWErgHIs7bfBJJxokKyu1707|d4d2305f-fc0f-4a22-bd2b-b25c4d3f58ce -> tool:nanobot-harness-v3:call_00_zOW2jK6zaRK7YoTcm4dO2436|ba9ad2ac-51e4-4a92-91ec-affcd8512723 -> tool:nanobot-harness-v3:call_00_cRg0PIgI0tcjc5wxR8sd9682|4e1160df-da73-4b27-a36c-6189bb3dab4e -> tool:nanobot-harness-v3:call_00_RCCFcUbV35i9lVCMdhN47018|a7fd514d-8e24-477f-abcc-3f0a0de31103 -> tool:nanobot-harness-v3:call_00_tXDvQoGVnNcRbxObJVFK8861|9b24db6e-6b36-487f-8b63-809e0bda01c1 -> tool:nanobot-harness-v3:call_00_CiMLv3Qpk2XohU1JxIoW6424|cc080d03-d598-4d39-8e25-ee9c95c6a4ff -> tool:nanobot-harness-v3:call_00_Xf0hMrjpRTcCzstyeCq67263|7bda74f5-f004-48af-a011-e5ada33c8a36 -> tool:nanobot-harness-v3:call_00_8Ssq00NtJu8eDY4PBw869397|dd712ec9-07e5-43b3-aaef-ff3fdcec365b -> tool:nanobot-harness-v3:call_00_ZzA0OK8h07ZW5q9u0x4h4505|6d002d51-0bc4-420d-8049-a76fedc07a42 -> tool:nanobot-harness-v3:call_00_PTJWM2hD8ftb5iAeTTlA9343|db17ff6f-6f1c-42ff-90f1-7ec496630a97 -> tool:nanobot-harness-v3:call_00_61ZEtl1yMGMdOPPnf2sZ6568|de01fb6e-1e06-41bd-bd33-3610de34348d -> tool:nanobot-harness-v3:call_00_UKGH6CT6EvsHyUAcyn4T0164|36d06f7e-c51c-4d5a-894c-17a3e8c13d9c -> tool:nanobot-harness-v3:call_00_RV850UPxrGDRSsip9Lhm6149|f4419c39-7b42-4a06-b2b9-5842465d5a80 -> tool:nanobot-harness-v3:call_00_iUVrxnp5QsXMtW9fBBiB4087|dd128972-9268-48df-8adf-b483ab2e7007 -> tool:nanobot-harness-v3:call_00_r0ucNPzbC2fLaK3hfgnZ2821|5701e158-233f-447e-ac1e-75ce36ad9d8c -> tool:nanobot-harness-v3:call_00_8Cc7cRlPVtKyNN22JpTi5946|7a253544-dbfc-4ebc-850b-5528a0daea5b -> tool:nanobot-harness-v3:call_00_uVaproEoXmfQV530XeUT9581|e0b04a48-fa88-467e-874c-58745405ca50 -> tool:nanobot-harness-v3:call_00_DFPlbWZxhCu9z9O7YWrA3268|69b9b7c7-2e28-4f49-abc5-edee1116c291 -> tool:nanobot-harness-v3:call_00_ZdbPOGaIQiGtBGu2EiT64842|340d5de1-b93d-45b5-b90f-4b373dbc978b -> tool:nanobot-harness-v3:call_00_eJXkkAvVcQ4PzkoLWpf79048|e9163810-29c3-453c-b4d4-b09f8d14eb59 -> tool:nanobot-harness-v3:call_00_KMYgU2Fwz7T8VUtO7pJX6257|546269ac-2f2b-427e-9655-428b388de41e -> tool:nanobot-harness-v3:call_00_pVBtoOYkOuzMwJ7qmAU76565|24f07b0e-ec47-454f-89bc-de4843ded185 -> tool:nanobot-harness-v3:call_00_Kb7oH8FzmP585oTxCXb42634|21531f74-7d0b-4da9-99a8-9c85f448bb7a -> tool:nanobot-harness-v3:call_00_0sBPv8xxkBbJSImJ3Nok7031|9b26c10b-4987-4f3f-bea6-b3d165a562fc -> tool:nanobot-harness-v3:call_00_poP3qwYFwlvTINm9ZWvt2375|9c93102d-6756-42f9-ab47-5eb00409d5d8 -> tool:nanobot-harness-v3:call_00_0AJtLrbp3u6349kGERe55778|0c7f262f-8e92-4bef-9bd6-d8ce8a21236c -> tool:nanobot-harness-v3:call_00_zdb1mk7nFxwZlgsGhPHK1239|e91be027-aaaf-4147-bbae-a04611ba3868 -> tool:nanobot-harness-v3:call_00_KVkif8PfW2lKBG2RdgLP6588|0add3155-a2a5-4e7b-97d6-0acf743f7c95 -> tool:nanobot-harness-v3:call_00_x0H8D37awpHqPdYoNCAc9774|81ba4f6c-b35e-450b-9e7b-63ff7f0ddead -> tool:nanobot-harness-v3:call_00_CkoPioQh8UsaLC4t4mxb4694|7d041429-d334-4583-82da-3fe1f1aa3115 -> tool:nanobot-harness-v3:call_00_4kon60Irg0IRwVzd1rCi1326|84d92ddf-037d-4dbf-946d-a9cd1cfb218c -> tool:nanobot-harness-v3:call_00_KtFr1VV8VZ031NN0RQ0J8731|aaeda69a-e1b8-40b2-881c-1ad6f8e15672 -> tool:nanobot-harness-v3:call_00_uLYLz8GtQjm3JTXGJbko8524|1b482b02-6b92-4b19-9750-b24375d01a4f
- 关键路径耗时：1.201233
- Makespan：787.176229
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
