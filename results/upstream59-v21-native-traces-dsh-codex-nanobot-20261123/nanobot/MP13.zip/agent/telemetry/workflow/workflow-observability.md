# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP13__9dBKqAe__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（83 节点 / 82 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：83；执行边：82（observed=0，inferred=82）
- Execution Trace Graph：`observed`；temporal_next 边 82，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_GZD8BXI6BR9PkkGDH3Te6032|aad90b8b-348d-476c-948e-66ac0dce4a5a -> tool:nanobot-harness-v3:call_00_hvwtPi5MBoQfJQvYPp8o2124|34bb6b0d-8c7a-4319-b061-484c4a42802b -> tool:nanobot-harness-v3:call_01_KB8w55YzJva6o4AmtY5W6161|6833bd26-ea12-4993-ae8a-91714d81bed0 -> tool:nanobot-harness-v3:call_02_ilWBZh7sd7V0y2qbBSRB5882|c854e2f5-8807-4c25-a8bd-3bcd49ef018e -> tool:nanobot-harness-v3:call_00_onFvUWDF1L3pUCSMjpuV2067|71067d68-2988-4d17-8cbf-c35d7047230a -> tool:nanobot-harness-v3:call_01_2ntDsWrocvkBDUT9EArL8044|d875212c-e961-4326-8ca6-811eb9f54639 -> tool:nanobot-harness-v3:call_02_NsSMyPVCnnhMbywjOqBf9462|88a27ec2-4e1f-4c65-aeba-1dbf4def3c1b -> tool:nanobot-harness-v3:call_03_FVPhxbH0oQniVN8tVIl73834|29e91fec-7647-4abe-b04b-3ccbc5f39bb2 -> tool:nanobot-harness-v3:call_00_KeeOmk58RGpMgGsPWyGf4159|5c250e27-a88f-426a-9b07-aac9adc766bd -> tool:nanobot-harness-v3:call_01_KU4UjoFPjDZau79bSzvS5934|6a122a54-d19f-4aef-a9d6-b7410d252701 -> tool:nanobot-harness-v3:call_02_0ixT672zzJeflL17irls2242|2ac0c82e-9d1b-4ad2-a871-c2739940dd06 -> tool:nanobot-harness-v3:call_03_37YGmJ2phT5oXCRnVh5n9881|382b4ad1-6c51-4aac-87a4-8a5d93209724 -> tool:nanobot-harness-v3:call_04_Zun7H4Y3nc5DXFgoqkN00988|a5fe5961-861e-445c-8d83-fa63952808f2 -> tool:nanobot-harness-v3:call_00_LCkZQYNmUAy82mbWxcMU4489|aaebde2e-11d3-46e8-900a-d3105a91888a -> tool:nanobot-harness-v3:call_01_4biFRVxmT4iPNL6kjDNR7952|b2144a44-ddbb-4dbb-9177-01353ea98829 -> tool:nanobot-harness-v3:call_02_bbXE9z7n9VEPeotU5A5b9856|b76c1c90-65d2-4c0d-a91c-2474f196477e -> tool:nanobot-harness-v3:call_03_evCk6Q5eBHohgOvAXcNT6743|c63bcf88-d178-4a79-8b39-5f75ad0a978c -> tool:nanobot-harness-v3:call_04_qe7CE3IPHBzFWLdQHvYz1387|fc692325-4edc-462a-aef1-abd27fa6be93 -> tool:nanobot-harness-v3:call_00_fQGzuhfNRKNgjimLhyyN7269|7f242c46-dcdc-42b0-b594-d867a12e7576 -> tool:nanobot-harness-v3:call_01_oitmMIXW8FfYLCxue31L7031|bdb5e110-6914-45c5-a9a0-bddd5635f24a -> tool:nanobot-harness-v3:call_02_XD4pu8eIxpgxI62v1A4Z4954|356e2d55-e185-46d4-8ead-41f2e77c965f -> tool:nanobot-harness-v3:call_03_XaHogrXdolGsne43pfm57404|b4947329-c72a-4a33-9905-5f4aea137a60 -> tool:nanobot-harness-v3:call_04_zPNpcNqglpsYSZqxXKlb8636|fd8d789e-72d0-4c80-9344-f8ecfcafd8bc -> tool:nanobot-harness-v3:call_00_BIHagDFHPhLD0L2P05V23652|63110911-6d81-4f2e-8efc-b4d7755e8f6f -> tool:nanobot-harness-v3:call_01_Gt4LtQsMQHHoyyz78Puk2953|59f67f8f-7cbe-47e0-a1b4-f8d9a77d8e3e -> tool:nanobot-harness-v3:call_02_GPqmxANrGyyWJtxXbIcb0330|7c36ba42-ba07-4328-b2d9-aea56e59f28b -> tool:nanobot-harness-v3:call_03_Dmc1vKgTwtko3QAzRm8B5296|5cc8be3d-e0a6-4bb4-bd2a-77cb36fc410f -> tool:nanobot-harness-v3:call_04_vfzZIcgrN5n10WO1lob42364|01dd8bb7-e8b7-41c5-bbab-1adee24bed82 -> tool:nanobot-harness-v3:call_00_rE6OqmqCA2dQvWtUAABO6052|f3714bd2-c3ec-4088-9613-dc2f4ab64ce8 -> tool:nanobot-harness-v3:call_01_LVKchgMd1GGitRgYHMxF7046|c02b6607-aeb0-4d7c-9d24-bb3adb9ef1c0 -> tool:nanobot-harness-v3:call_02_PmHotyMkXhxYSMZRDQ544627|ed3e86b6-8c07-4b1c-bc43-19f98319a1a9 -> tool:nanobot-harness-v3:call_03_7RSGqdNeJNLGSpygxyH10507|631a1c47-3252-48d6-9e13-3389ef714e14 -> tool:nanobot-harness-v3:call_04_iynMsydselt9tNYYBOTJ0121|86b03b32-24d8-4bdd-9de2-3f9c4a907a01 -> tool:nanobot-harness-v3:call_00_Wvqy4Wqk0QaPSXKmBhNz2088|1ac61ff2-7959-41ac-86b5-68e9c64975c8 -> tool:nanobot-harness-v3:call_01_BuVFvP5IBCx1hewPOvkR8304|64dac5fe-8b1e-44c9-a9dc-b26ecd398a95 -> tool:nanobot-harness-v3:call_00_wPg4zz97os8OSYHsMsAr3782|8d2b1b25-44a1-4b4f-994d-1f42b4876f5d -> tool:nanobot-harness-v3:call_00_z1K8TVm5N1jgm6R3hCQa6071|7f199d31-7b32-43a7-b28a-f5ff01006273 -> tool:nanobot-harness-v3:call_01_o4V6YmQOJdPwjPC9RSkR0521|e89ac126-c785-459e-974f-cb0baada9681 -> tool:nanobot-harness-v3:call_00_ZEMqep0tNqshdcdzJj1K6533|26b42650-cbd9-4fb5-9773-783b667eff8b -> tool:nanobot-harness-v3:call_01_3kISFvUfQQDyHIe4wZCg5978|e36e9b90-ed24-499c-b199-27a9e22e9b63 -> tool:nanobot-harness-v3:call_02_EfZxJHEYNEhX5IH09wzu6009|3fe816e4-5ae5-4830-a546-21f2d1ddf0cd -> tool:nanobot-harness-v3:call_03_3E6M0fEyj7ZP0fQdAddD1981|f0807762-4a2c-41f8-8055-2e5690a279c5 -> tool:nanobot-harness-v3:call_00_GL1mAh5OxPLMxdqKIRMw1721|520507ad-ec6c-48a3-8ba9-5223038ce1f0 -> tool:nanobot-harness-v3:call_00_gFZNr2EI9TndL3O8CMEr7357|d10c86fb-3112-428d-a447-d47c94c120f0 -> tool:nanobot-harness-v3:call_00_4mtqxlqBTXzq5WaK1fv15268|62681dfa-d82d-4d12-8f17-b905cab3d2b1 -> tool:nanobot-harness-v3:call_00_oSySQxCfc6Y2H9x0BOYu3450|fbb656e3-61a8-4788-b4f6-3378addda3e1 -> tool:nanobot-harness-v3:call_00_9MF6zFI1CwYm9Xef7YbA6774|568f8265-669d-4429-a2f4-6fdd39d3b81d -> tool:nanobot-harness-v3:call_00_XaEy56u6El4BmZGGeLEV3649|e49fa733-b82c-452e-87f8-dace06273257 -> tool:nanobot-harness-v3:call_01_K3EwUkrlCi0ngXovsyrD4188|11ffcfb2-32d4-4c89-b624-76f88b3e19a3 -> tool:nanobot-harness-v3:call_02_FNbmyEpbX512AqylI6l14349|10a1fb37-d4cf-4bb1-b70a-45c30aaf0a2c -> tool:nanobot-harness-v3:call_03_dTg7dTjpWTHowENkXU5q8756|6dd25514-52c2-45a2-86c1-103048b11866 -> tool:nanobot-harness-v3:call_00_9vjzYyQnnVPTxLiKGWvr6751|e46106fc-63b9-4af5-90b0-afa50429d2d7 -> tool:nanobot-harness-v3:call_00_RiBg4wY3kpoJvvPizMFv3885|5b812f55-d4c3-446e-82ca-241bf2673abd -> tool:nanobot-harness-v3:call_00_65HSYh4MKKX9bvJ8Ykqb4712|39c38fe4-e2d3-483e-a065-7cdd430a0dd4 -> tool:nanobot-harness-v3:call_00_PNejgcqQY4F69ZvEQMu10922|62824d20-b0c6-4b1f-9631-65ca85ecf1b4 -> tool:nanobot-harness-v3:call_00_iWzPUpckUPooqukkXL1k7369|550e3b74-f1aa-4ef4-9122-c051ec58adc4 -> tool:nanobot-harness-v3:call_00_88cmjZrT6VGHyrR14SZs5743|c5e04836-12a3-42a1-9657-8077dbdd5a0d -> tool:nanobot-harness-v3:call_00_2KJM45z8VNMdvMCDar5J5211|2c8ef010-ec91-4c19-b3e4-62c45d2ec32e -> tool:nanobot-harness-v3:call_00_RF6Kgacpu8yP3lJpNbeH9777|656c7303-039a-47ba-8190-7abce0d758bb -> tool:nanobot-harness-v3:call_00_NRMxNdb3Hs6PM4iZVdvF5290|48fc9264-c457-4727-99a3-d53e9c6a3da7 -> tool:nanobot-harness-v3:call_00_JL2jloSt55m7jXvjvey75009|a598f985-bd7a-472e-8d64-c79da1cfdbd5 -> tool:nanobot-harness-v3:call_00_mtQnqvl6zYTjmf1NRanr4828|11444784-dc9e-488a-9c55-c4fea142192e -> tool:nanobot-harness-v3:call_00_uNj4Tzx5jk9KVJrmJB0M8876|8700d38c-9610-4f10-9619-9d4f56f35f1d -> tool:nanobot-harness-v3:call_00_dpYXcMDoTKa1Z8VxrV376998|9e803759-4289-4bfa-9736-be7140b99944 -> tool:nanobot-harness-v3:call_00_k5xvgxvJpWnbBMbNvm7K0774|74c22e96-1f46-48c3-9544-d47ba92ea8bb -> tool:nanobot-harness-v3:call_00_pnzDi71LK7weZGZL6jyU4540|a0e7afad-56e6-4de4-995e-07ca57c5b0e8 -> tool:nanobot-harness-v3:call_00_aTyQmFcFBGrSWsqBTCjq2711|02872318-143a-4ad1-961e-5adc2449cda8 -> tool:nanobot-harness-v3:call_00_AB7uHLgApz16UqXFgud03138|d495f577-7b84-488c-944a-ed1bb49ed0f6 -> tool:nanobot-harness-v3:call_00_SzQcrPIGHWQrHwe9SMSJ7180|cc980de8-f037-47ed-95fe-3352eea71a90 -> tool:nanobot-harness-v3:call_00_9sJFP4dibC5NSKc7qJW84167|f2c05a72-220d-4a9c-9f22-5f67d2d5bccd -> tool:nanobot-harness-v3:call_00_ByUl6pCXm7pM3d974wz46586|2e3afd27-75b1-403c-afdb-b05f926e40fb -> tool:nanobot-harness-v3:call_00_Ql2Ntgjl6rg2Tss7pXvi1569|d1ea6b41-c0cc-4986-a507-f317e3844e53 -> tool:nanobot-harness-v3:call_00_ixmlre8YtLmGECLHwHMw6071|5b3fd96f-bcc2-483c-b65c-46e718efd57f -> tool:nanobot-harness-v3:call_00_EzctlBP9NNtD7AXsQWjz9511|16ef19df-7d4f-4a87-8029-f0488fdeb5ef -> tool:nanobot-harness-v3:call_00_5t0vT4nuHQsyNcUTpn2h0353|f62c4209-6083-4958-abf1-362cdfb57aeb -> tool:nanobot-harness-v3:call_00_bnozrrDZyyTsV8AFE1V26687|73621792-8784-47f7-9d96-ae4535e0c6d2 -> tool:nanobot-harness-v3:call_00_pGkw7MpuhrkhE7EGkgDT3497|ce9d2c7d-f98d-4029-a11f-54ee4156dde9 -> tool:nanobot-harness-v3:call_00_MlCvPB06vLWGog1didA51369|3835e201-94d9-451b-94dd-b4ada85eee61 -> tool:nanobot-harness-v3:call_00_0p5ZNx7LcqcfPbJ7hj9U6337|ef02ee86-0d59-4845-9ec6-17019da88ac3 -> tool:nanobot-harness-v3:call_00_Zcq0k0RDny3Lr4338Fk34474|8a772f58-c9d1-4ae7-a512-7072a1b91c55 -> tool:nanobot-harness-v3:call_00_rD9ECH1YB0RuY9xzdjeY1134|7c23d77e-4d8e-4b02-a2c8-7fbe5783cbaf -> tool:nanobot-harness-v3:call_00_Rv2dq5f4wtAhm3Q1Z8VN5194|ae4a135f-3553-49a5-95d2-6c2f9e63ee75
- 关键路径耗时：1.580748
- Makespan：1028.38179
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
