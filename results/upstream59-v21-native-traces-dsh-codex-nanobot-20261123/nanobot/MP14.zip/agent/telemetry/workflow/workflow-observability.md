# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP14__tbz4gqR__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（103 节点 / 102 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：103；执行边：102（observed=0，inferred=102）
- Execution Trace Graph：`observed`；temporal_next 边 102，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_RLw2LcULovHLf8mHaY596072|1d67ad75-6ab6-4624-9f32-b580890538f4 -> tool:nanobot-harness-v3:call_00_H3zAQ4jyU2PevKkk8c923752|ea3e6059-0dbf-4f89-bdf4-12044e41f679 -> tool:nanobot-harness-v3:call_01_vpN0YPxTew9MgwVLIBy44102|33c2e68b-5069-40a6-a1d3-b05246dabf68 -> tool:nanobot-harness-v3:call_02_rfF5zxqtHvrDDhxadG1i8676|7b9fa741-1bc2-4c43-8a4a-f1832d3cbbb8 -> tool:nanobot-harness-v3:call_03_d4hibU9vBJUCZ75fXRqP4015|006f4dfa-6b96-466f-9d56-e9011223a002 -> tool:nanobot-harness-v3:call_04_11JgtEx4kEvhpNykuxoq7650|2a64c550-9071-44a0-9379-3bf63d7b3fc8 -> tool:nanobot-harness-v3:call_00_xanlgoNDQATmSpcaX0Xw3067|5ceb2db0-3eff-4659-a3f7-acd22c56bca3 -> tool:nanobot-harness-v3:call_01_ZX6I3CmceeIaCMqJcCqh7263|46dd3793-0a4c-4f07-942b-1ed00f932d52 -> tool:nanobot-harness-v3:call_02_bmxW2v1uMtr3WTMahmMT9825|162b97bf-c243-48ef-b42d-e8ed4a6ec057 -> tool:nanobot-harness-v3:call_03_OGNmYRTUoAdvJ0z9wWuo4510|e97fb3bb-7c97-4e1c-b5bb-cf913cc13285 -> tool:nanobot-harness-v3:call_00_bMQMAl5dhuEj6fPiOuc89716|5173b402-ef59-4708-9cfd-408d7f4856a2 -> tool:nanobot-harness-v3:call_01_bjpS3ZOxNAaHcLfaKyvW4328|fa1eaf33-5ac6-44de-98e1-98a72bc884ba -> tool:nanobot-harness-v3:call_02_kO1eGYQR0Wn3Xrlo80Nb0875|32f411d3-c603-46c2-ade7-6ce267715a82 -> tool:nanobot-harness-v3:call_03_jAE0hBxkZg9v2fKzKZzf4062|11baab2a-4c79-40fa-acab-695cf25d2d20 -> tool:nanobot-harness-v3:call_04_hpdXhJoPPxQva2hwAp8G8426|fa760000-3237-444f-81be-562889ac39ab -> tool:nanobot-harness-v3:call_05_JBjWikayTy3rwVllvlYm9564|814a2f68-7821-4735-a031-139322c42ac4 -> tool:nanobot-harness-v3:call_00_Cc5WYTPMiyzae57qRBKs3253|b9751621-ccd5-45ec-85bd-3bbab5fc7c19 -> tool:nanobot-harness-v3:call_01_qKPntbwibxdIkwDIBtOF0815|710fea5a-c807-4915-96c4-f15fb298f2b3 -> tool:nanobot-harness-v3:call_02_YqW1dkshe1pPauE0NMqM5168|321e14b8-bb3c-4c1d-97e8-b664a8841948 -> tool:nanobot-harness-v3:call_03_6Qgqgzm9j2RM31GlDer31327|cea2b357-e415-4e9e-97e1-d36bc62c1d89 -> tool:nanobot-harness-v3:call_04_aKQkaO8pChKx5OJD8tw97682|6d7d4f22-19b1-46b4-82c4-2afe2aeb4ffa -> tool:nanobot-harness-v3:call_05_aNQJAkowwk2KiRsui8pd1580|f7b80b88-e966-43dc-96c5-9257bea5b7c3 -> tool:nanobot-harness-v3:call_00_eN0yPSsJy4kHrb2VNSoB5185|5fda1db7-17a8-4b06-8fa9-4d5fc234ccce -> tool:nanobot-harness-v3:call_01_Fn3gbRTYFpl9V3J1rwR04175|1b2f38b1-6c2b-4b20-a26f-93b7215c0e96 -> tool:nanobot-harness-v3:call_02_xaCLFcnTXojKyACTGlRT7052|67d7839d-bfcf-4710-9e5e-d5ff5711799a -> tool:nanobot-harness-v3:call_03_cJOI6g4kHGYVXtZM6bJh8386|7afb99c5-49b3-47ca-8b22-3546973ec468 -> tool:nanobot-harness-v3:call_04_LRyKNFyZdk7qixmFRdZ22242|b002cab6-782a-473a-aad5-00f5ac59462e -> tool:nanobot-harness-v3:call_05_HvHNhU3GMJav211gFcz76967|1d50c918-1a2c-4f34-83a3-ec84b54eee6e -> tool:nanobot-harness-v3:call_00_VeZsvAfu2TdLDriMhiqR5452|97ce2288-4ee1-4c6c-bf30-de1b7dc0d632 -> tool:nanobot-harness-v3:call_01_19AJy1qheibrzpvp3BjF5790|78bf2d89-2bbf-4279-92fd-471e1556060e -> tool:nanobot-harness-v3:call_02_NRihO2iMmOgDWB92weBj9391|2fd21545-229b-46c0-b89c-bfe4362d10e0 -> tool:nanobot-harness-v3:call_03_N40gsQmGJcPmRaXJLGI71452|e0335a15-3f80-4f3e-bfaf-07c128d769f9 -> tool:nanobot-harness-v3:call_00_g0FnV524Q8paKJQotTGb4679|7a4da525-7600-483f-aaee-98c4a3ec6333 -> tool:nanobot-harness-v3:call_01_62OugM6qyZvYytyfdIWk7310|8c8a5020-42ce-4c7c-b3ad-8e07e5b2c486 -> tool:nanobot-harness-v3:call_00_cEYwXW0cRgjRza5B2J3E0886|b6313dc7-ee9b-404c-b0ca-05ef2f864405 -> tool:nanobot-harness-v3:call_00_nuA3BY1Xcx2yjiT25for3549|89278339-f814-48db-a2e9-a39c2d3dd114 -> tool:nanobot-harness-v3:call_01_aZjrRLAfjWxaip81DyIp5438|27a51100-255f-424c-aa1a-79968845f6b7 -> tool:nanobot-harness-v3:call_00_VcdrcSlMGWvC5kJhslxU9216|0f75ab62-30de-4728-82ee-a13af9e149d6 -> tool:nanobot-harness-v3:call_00_Xs114Gm39RKTAjlblW5Y3968|838ee265-825e-4d35-aa51-c4b2019929c9 -> tool:nanobot-harness-v3:call_00_QE1Kc3AHAWcNqsDe55Nx6107|a931f127-c415-4480-b47f-f67b7c6eb160 -> tool:nanobot-harness-v3:call_00_YU8ujo2PlnP2zGLDz9OV1322|10465dfe-ab2a-43b2-aff7-f426da74664a -> tool:nanobot-harness-v3:call_01_k2LN1IVm9FpZXpKAUl6w1564|ae0a4793-3152-46af-a331-3e9b8de82351 -> tool:nanobot-harness-v3:call_02_IPiHkgoy8J0SYULc00wd9094|30887c79-3acb-46d0-8b94-398fc86d8e57 -> tool:nanobot-harness-v3:call_00_pfq500AOxatrlbqUckoN4364|9b827761-f063-4c85-8747-cf41dda0fde6 -> tool:nanobot-harness-v3:call_00_kbenvR5ZEVRbhaKS2eyV1461|bbe72841-65d7-4210-a879-a3e9fd1e8cc9 -> tool:nanobot-harness-v3:call_00_PLUrIKvpLRXdnnSYL6r40982|4e511b8c-04ec-4b76-9b24-cd8a696f87c7 -> tool:nanobot-harness-v3:call_00_jxSokvakrwLWUPOnNcqR7192|9055af14-96d0-4c76-b9ac-0c7d32675ae8 -> tool:nanobot-harness-v3:call_00_9UBQKHVU26oQ8m6bT3dA7222|55c04326-1319-4f62-9396-2e691d760da9 -> tool:nanobot-harness-v3:call_00_UdDwyW3j1Zt5Sr0E8vv03060|334463b6-e8de-4c7e-b79e-542613fa8615 -> tool:nanobot-harness-v3:call_00_8FFpcDtnb0TIRrPBOF3y5796|54bc629c-8648-44f0-a35f-bc84b6dfc168 -> tool:nanobot-harness-v3:call_00_I4toPPu5GLxrP1iLhDli7422|747c8f5e-4095-46c6-87e5-74bd4106e016 -> tool:nanobot-harness-v3:call_00_ElFcNhZ2hT0qzTSugeXe0637|8d99e41b-af6a-48ef-9de4-597d28046e90 -> tool:nanobot-harness-v3:call_00_ZBURmrwwm10h8cbLmfQy6472|968bfbfe-b8d8-4195-96ab-e670a5a48f09 -> tool:nanobot-harness-v3:call_00_rkVBHUyNTFysOaVqYjbE9292|b04e69e7-889e-4aae-b3f5-ac37c921f018 -> tool:nanobot-harness-v3:call_00_TWA82pfujOIM4HmyOVdj8593|da604f32-9275-4ee7-b1bc-f5465ce8183c -> tool:nanobot-harness-v3:call_00_wqkTFTqvhjrNRVtMwx5s2051|2cbbde4a-61ef-4696-972d-ddb43bb9802d -> tool:nanobot-harness-v3:call_01_ZfFWOepHTcWnf0SpCbLl8595|01d56e71-9e97-4077-bf66-0be471ec1404 -> tool:nanobot-harness-v3:call_02_HP4Sv4lLwIBooRcOQozU0358|77e6adea-533e-47ad-923a-25fc211f3e8c -> tool:nanobot-harness-v3:call_00_XDEDtXwalNMb3mBD8DwJ0015|d22d19b4-db90-427f-a947-c501320d24f7 -> tool:nanobot-harness-v3:call_00_AOqJLnRq9roEmd3cJePJ5511|f0f6f080-c88c-423b-ba7c-b2057da8f099 -> tool:nanobot-harness-v3:call_00_qnNF2O3WZhX13VWVL4ni2989|9c2aaefd-ad95-4bbe-b4c3-acbef936a025 -> tool:nanobot-harness-v3:call_00_7HZHRfjd2a6w8rwXdRJZ3601|6d5214de-20d5-4a5c-8142-ceddafa3d150 -> tool:nanobot-harness-v3:call_00_VnCittaqq6dBwolezkDt0252|92c4bb53-0918-4bcf-94f7-570a8b5752b9 -> tool:nanobot-harness-v3:call_00_FY6g5i85koh9cpsA8wnn9711|3c46fb59-6f7e-46f0-a432-4133aed069f4 -> tool:nanobot-harness-v3:call_00_ZBlBcn7uPLycJw34eXR12239|5b7a9ee8-cc8e-400e-b3e3-072f1cbd0230 -> tool:nanobot-harness-v3:call_00_iZvEWAsrG6bmWVYtmyvP7450|abee0da1-6227-45c7-9d33-260c1e30ba69 -> tool:nanobot-harness-v3:call_00_EVjFm5fMPTydNMIhdDC88199|64d37e4e-a3f6-4e75-98db-6052c24d5a32 -> tool:nanobot-harness-v3:call_00_1yalvOBmiy61a23u0z6L2228|2c53bbee-d3c8-42ba-bbf2-dd9d360581fa -> tool:nanobot-harness-v3:call_00_gAulDyc1QJENeopIYvtA9107|771faece-dab4-4f72-9ca2-dbbe2f26ec4c -> tool:nanobot-harness-v3:call_00_oV0PLa1JAYKVyS1tRjg08809|63148131-92a3-4a2a-aeb2-e62137a4b705 -> tool:nanobot-harness-v3:call_00_Bm9L8IhEHXJqN3mA8T9N2408|470bce63-1eb5-4795-b9d9-e27ac53518c9 -> tool:nanobot-harness-v3:call_01_w1mo31ZVRLZBB0pR3PND0800|fe350745-7f20-41be-b9cc-b32c2dfd12d8 -> tool:nanobot-harness-v3:call_00_sGAgHJIbwi8lp3aQ4zoa8851|63b16839-ea2d-40d2-8457-9fcae1144d7f -> tool:nanobot-harness-v3:call_00_UtZcxZsvgliUSuFhFXID0250|95511e8d-a272-40e4-a4ef-26779b07872e -> tool:nanobot-harness-v3:call_00_A5l6jGc975AElteG5dUd3493|5843f482-a600-4a28-90b0-ae09a7c6fb12 -> tool:nanobot-harness-v3:call_00_UVQbWBaKMDnr029DqnL85354|eb47945f-7e7d-4018-a27a-55cc18292485 -> tool:nanobot-harness-v3:call_00_fR5dh01AXbCnh9RVHzHV3012|6b4f41b7-90e6-4e68-899a-e09327789daf -> tool:nanobot-harness-v3:call_00_nnCxtU88uSnFUrPmvpPO6294|4196b3c2-b755-400d-a84f-51ca726ea2aa -> tool:nanobot-harness-v3:call_00_2t8woShlnSZXT3YkfiaL5080|18b6c322-0ce8-4eaa-8072-6c88208f73bb -> tool:nanobot-harness-v3:call_00_uRE6Xb5iKxd4uxvh9DHd8137|a316c4e5-f62b-4504-bdcf-0e6056012d0e -> tool:nanobot-harness-v3:call_00_PpBbQiDxw9Gkc2DKoAwS8506|8d10224c-c49f-43fd-bfbd-206e97f7acbb -> tool:nanobot-harness-v3:call_00_24FLIOmj86RvYO2mmtdZ6250|60f14f42-84d0-4574-8058-b4ebf5fbd1b4 -> tool:nanobot-harness-v3:call_00_acu73paQzCPe8OQWTXrP2648|d4e01217-fe2b-405c-ab19-dcc0fae6726d -> tool:nanobot-harness-v3:call_00_ayVtTmx4BIdzZXlViPvB6406|fb52a0e4-5e49-461f-a244-f3cc2749bc83 -> tool:nanobot-harness-v3:call_00_29AM5sBu4n8BxOyzONKS8401|036e85ca-8ea2-4bd5-a29a-d3d008214a5f -> tool:nanobot-harness-v3:call_00_QXHMsNjXA6SisDCgoceT8200|6ef12434-6b40-431f-bf71-e4cdbdd41903 -> tool:nanobot-harness-v3:call_00_vmWO32g23gwx3lAFle4O4024|f6483f7e-d163-460a-883e-f8d8ec88c8fe -> tool:nanobot-harness-v3:call_00_Ku8sR62IVTDyqzcTCaLW6075|321507cf-794c-4311-9de2-a9587f78d048 -> tool:nanobot-harness-v3:call_00_5dQOZ1gPnF3qaD2EENdt6490|ed905b84-6ee4-4e28-a13f-813e6f4f741b -> tool:nanobot-harness-v3:call_00_9niPcrmHgXgDyGksjAX36198|77a0f167-5f59-4f66-9ba4-07b031e808d9 -> tool:nanobot-harness-v3:call_00_dUk4bsc6MRQS6ZUkZjjq5825|28a6d7e2-7e1c-4ff3-9d41-eb09cb0bab38 -> tool:nanobot-harness-v3:call_00_zuG7lUVv85hJyFwHs7oL6737|aa58132b-9aa7-4ea9-8a71-83e173d019c5 -> tool:nanobot-harness-v3:call_00_c4UJFHV3YUjxCyZMAebZ8516|ee2e4f08-6a15-4efb-a007-d12603eda890 -> tool:nanobot-harness-v3:call_00_WxPV1cHY1YHiplX0RzZi2278|42f01728-08ef-416d-87a1-dbf624c82c0b -> tool:nanobot-harness-v3:call_00_sKqMwsIwdFdLYLAzGt6q9207|aeb1476b-7e01-4650-88ba-910c2e2a144d -> tool:nanobot-harness-v3:call_00_tqQtuHtVVMeMfS0FkcIT6562|9e5ce06e-c0e5-4943-b054-695e1927c13f -> tool:nanobot-harness-v3:call_00_SeJq9BK7tGJ2PqUxlNo69314|c5812bf9-a1e3-45e6-806b-48257169a428 -> tool:nanobot-harness-v3:call_00_In7IHJq4q02JRv3u7udP6582|68c421c3-92dc-4e07-8f8c-b3d1bb02fef7 -> tool:nanobot-harness-v3:call_00_6SRtMKLMnoZMhUfV3qig9718|51401302-eaf5-43aa-a098-006ca3449139 -> tool:nanobot-harness-v3:call_00_HGAUW50I7HzLoJSfxgW63092|412b0738-489a-4e6c-9478-ee8613f8c37d -> tool:nanobot-harness-v3:call_00_Tv6LcxjrAPvtOL5MuQCe0984|26e5e469-a39e-4aee-b1c4-9dda982d2815 -> tool:nanobot-harness-v3:call_00_Uz230OhqyB8Q2BhWNhmh8332|95f7985c-3696-4872-b6aa-da817cc3c11d
- 关键路径耗时：2.39127
- Makespan：777.160264
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
