# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP15__DpwjJxc__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_hrHTKDYe8HPJPcpCf3Jz3959|14d056a6-3ef6-491c-bfa3-83595fd3b237 -> tool:nanobot-harness-v3:call_00_hZbkDj5E6mu1pnmGVDeB4888|168440f4-b0aa-4cde-83eb-108fc3a9cb4c -> tool:nanobot-harness-v3:call_00_48aS1TTtQkhvm5eMj3KM5148|180c41ab-53e7-4b1b-aad2-fce6e9a38750 -> tool:nanobot-harness-v3:call_00_BNlzn1zvTHRfhi2dK4od4925|c81773f0-d761-4449-80a2-4e53068dea28 -> tool:nanobot-harness-v3:call_00_wlqOR7MFPKDCZawVuHtT7950|d233bba2-b461-4ac8-82b0-eafd42ba58f6 -> tool:nanobot-harness-v3:call_01_JmUfZwZ3d2yht9K3Djff9197|1d216537-4ead-4962-8ae2-ab0d0881abcb -> tool:nanobot-harness-v3:call_02_IQnz4PZMQD21RolQV35e1317|8ee935ac-37b6-4cda-bb32-6aa8433444da -> tool:nanobot-harness-v3:call_03_wgCpXAUGg6qBhffK8nv29368|a6fe7f7c-6ba6-47cf-931d-c3daa407e82b -> tool:nanobot-harness-v3:call_00_MxUTDFj39Alv7nbco1Dq8567|d7d70a1f-4201-4d97-a8f1-4c82e67060d7 -> tool:nanobot-harness-v3:call_00_1bIWxnzMGHxTC8XlBtSy4501|304182a6-deb5-4fb6-aa0f-4849390307a2 -> tool:nanobot-harness-v3:call_01_upPqG7JbvrWZRucTtyey8095|3fd63720-bbce-40ba-adff-7d112840f5f1 -> tool:nanobot-harness-v3:call_02_li5bguUEDeM1211Chpnb4923|0b11f304-f7ea-47ef-b6a3-53fcd1125495 -> tool:nanobot-harness-v3:call_03_5jZOjeHNMc9MYWLBv3CG4913|677abf3e-1011-4695-ac87-4d81980d3d48 -> tool:nanobot-harness-v3:call_00_lr1F8Z3gzrnWmR8i1oLZ1862|835c2a8f-bf3e-4a8b-81a0-645bf37a3722 -> tool:nanobot-harness-v3:call_01_UUwLLl4s0lePMtxeMCKN3635|5094e666-6e72-4b70-a608-aeb0dc4878f4 -> tool:nanobot-harness-v3:call_02_0B88ysW4Z2jzDTostQAX3669|9212b97a-abaa-49d8-9f94-7d1973cfab52 -> tool:nanobot-harness-v3:call_03_vaYNiO9awllCxDXtO9ds4079|48d04c98-d750-4300-a55e-6dfbb4ae1bf3 -> tool:nanobot-harness-v3:call_00_ulpoZkrgmkGguSDNyv9e6686|4d8dfcc0-21a4-4e42-a591-629cb650924e -> tool:nanobot-harness-v3:call_01_RgFSxHVRT5Wk4ERQiR5o9738|58b8d7c7-7d30-4fc0-8ec1-e9e335a9ece5 -> tool:nanobot-harness-v3:call_02_Luqahr9XLtt3Rud08ZiP0350|77becd13-d36a-4726-b410-f789b7fe7015 -> tool:nanobot-harness-v3:call_03_ZBQdwcfJWlchrHGtOucv9027|e72b9998-44cf-4d18-bcf4-42464190c0df -> tool:nanobot-harness-v3:call_00_hyUFVCB0UnXqxPkJZfX44644|2168cca1-9d1b-44f7-bd45-b9232463fd73 -> tool:nanobot-harness-v3:call_01_Bx4PZfSFoNAnOAA2vnNH6131|3b292e53-2362-4d8d-be77-3071172a0ff1 -> tool:nanobot-harness-v3:call_02_6Q6AjkA8qhrBFv7bR3nN0160|720fca22-db4b-46f2-9d43-740f4067cb70 -> tool:nanobot-harness-v3:call_03_3X5nLS9nNZWMcM72fECa6953|0543a08b-a853-4668-95ca-18ee424a93e8 -> tool:nanobot-harness-v3:call_00_jYy4XQn1y5mCqCwh7qhW9504|8518304f-a7ce-499a-8c8b-bbbf6f21501c -> tool:nanobot-harness-v3:call_01_IDi7Cy4XAdidnDTiRU9a9280|9d574bc0-a9ff-4f98-8edc-a4fbf6b42316 -> tool:nanobot-harness-v3:call_02_NdmBHsKVkP9T8FrIopu32975|831330f9-3561-4542-af1f-09b1071385c3 -> tool:nanobot-harness-v3:call_03_Ngd7Wo684uzVb01k5a4u5074|0e06e250-a3e9-445f-a030-abd188162fb2 -> tool:nanobot-harness-v3:call_00_qkbPPyQlmupixVIUdtfC0246|8f08bcc2-091d-42e5-81d0-967dab37c1a9 -> tool:nanobot-harness-v3:call_00_uKlwOaOoylAM2rV4xwnN6071|9bbbc9fc-2e79-41a0-b581-e02d57b8c8eb -> tool:nanobot-harness-v3:call_01_9ba0IKKL3OeOJReGcriP8144|9e7a9caf-57a3-4789-a1c0-919c1103c2e1 -> tool:nanobot-harness-v3:call_00_TZzhno67LjZplGeGegh90270|58e220a8-1b73-47ba-97e3-ae2554aece84
- 关键路径耗时：0.256498
- Makespan：775.66714
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
