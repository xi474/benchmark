# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP17__sSNDkXX__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（78 节点 / 77 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：78；执行边：77（observed=0，inferred=77）
- Execution Trace Graph：`observed`；temporal_next 边 77，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_8jrD5MnZi3CV15moohDt2123|31f087c5-08bd-4903-bef8-bb6e03866d47 -> tool:nanobot-harness-v3:call_00_PP4UzK55yqEjrdjFOlP75295|a7310b18-82b6-44eb-a1b0-a6edcf1c52b8 -> tool:nanobot-harness-v3:call_01_6APafAxUK0jAY61WrjBF5082|b10c0eb6-ddeb-4138-a3a0-7a2377c13e25 -> tool:nanobot-harness-v3:call_02_8Qf1pX5aCifkgrfmKLBw9489|165c82f5-2146-45df-bb69-5b31b3b3fd5b -> tool:nanobot-harness-v3:call_03_yVQRGmkVZYIlvTWW6Fq47464|9ef40d9b-9639-4868-8cf9-15864360fe8c -> tool:nanobot-harness-v3:call_04_Y4XX5hwrmCXrYoQ27NQl7264|8e66a9dd-cc5a-42b2-962e-9de0c14ffcd4 -> tool:nanobot-harness-v3:call_00_eK7gNyZwVdcEubVbW9Ms5964|503d1098-b1c9-4739-ab8d-626b1819718f -> tool:nanobot-harness-v3:call_01_MYhqS15L8iyrtiY9ittV6238|02b86ce5-122d-44a6-b11a-0bcada0f596e -> tool:nanobot-harness-v3:call_02_soEMnDJ0bHqdBz1tRgpV4155|6c38810a-2805-4695-83cf-0646ca5a9d59 -> tool:nanobot-harness-v3:call_03_Yfp8O9YzXst2mjN6c8by8584|2f3c5d7a-7bf0-4689-bd00-a099f2c057b5 -> tool:nanobot-harness-v3:call_00_R3r0ahaBKDks7Oedfzpi0195|c90929f5-74d5-4ddd-9d9b-40d9ae189cfc -> tool:nanobot-harness-v3:call_01_y40PKzjCtpXze55yx0Bp3188|cb484df8-c2ac-4e2c-91a3-ac2864bafad6 -> tool:nanobot-harness-v3:call_02_vAKxo1Vc9b6vdQflQSHR1914|08b300dd-a522-4cf8-a46e-1dd380dca73b -> tool:nanobot-harness-v3:call_03_KCTHGYLBsEGYLg1Z7fhx7180|5a38ba31-a362-4a3f-af27-4efc589297c2 -> tool:nanobot-harness-v3:call_04_S86giGyjxA3xHw2RIqWd5434|28830d99-985e-437e-8278-11fc1f563528 -> tool:nanobot-harness-v3:call_05_J2UdACUiYkhMFwdoPfXg0698|b9d060b3-7d12-4c90-8c38-84a65bc7ac57 -> tool:nanobot-harness-v3:call_00_Jz1zCxYcYMu2nCizuFEh2805|5256b53b-556e-42a5-879f-fed275f38eae -> tool:nanobot-harness-v3:call_01_J7HyyzeKYsv9DnXlQxiP8714|412c8db0-8fe7-4fe0-989a-ad6a03b27b47 -> tool:nanobot-harness-v3:call_02_LLLtMWTUygNduHhzTlpU0232|dbbf6272-f44f-47fd-9efc-e9e391f581cb -> tool:nanobot-harness-v3:call_03_3NprdiuFltNp43LQ1CP53072|9dc1d2b7-92a0-4080-a513-9d44e2fee70a -> tool:nanobot-harness-v3:call_04_w7BXH4cFMq2fgUtr5zav4315|0a886d44-cc6c-42b5-9327-fed125ca89ea -> tool:nanobot-harness-v3:call_05_55a0zj4hURQD4QPfyNhd8154|4e5c1932-b1c0-416b-b5c1-457de747b666 -> tool:nanobot-harness-v3:call_06_h8vk2I2TcazgRgYpyxJd6314|0f2491d2-1045-4c8e-a7da-791a62c2926c -> tool:nanobot-harness-v3:call_07_9ts7FQDVBAfYuadHFWhM0749|7ef3aea2-21c8-4056-b3a1-b9e27803ea1a -> tool:nanobot-harness-v3:call_08_vAZfqAx8NJPsjVDW08PV6994|237054d9-39ec-4a2e-b8ef-12cfbbd01da7 -> tool:nanobot-harness-v3:call_09_rsCvTjYg3osfGesHzzj90580|6a5e1570-2efc-4600-8581-19254b785a8e -> tool:nanobot-harness-v3:call_00_mLlnXWr2DwZAUPNz9k0A4393|8db1a533-1e0c-48eb-8528-9df3608b8e3e -> tool:nanobot-harness-v3:call_01_GFmuCI8QoVtpmjcvIXdI1737|e66c1852-b33e-4227-b1c3-d95323d89397 -> tool:nanobot-harness-v3:call_02_e76vyPAqMrPawuULyV7H3162|7525dfd2-17e7-4aa1-9b0a-637a50bd7aa0 -> tool:nanobot-harness-v3:call_03_QDtGKWVp71wVoKIkN7hd4160|3200f4b6-6317-44d8-801d-5793354655ee -> tool:nanobot-harness-v3:call_00_cd6GOLLBrK9hEzl3nWbV8851|f952a52c-1295-4a6a-acf2-db3fe7c192bc -> tool:nanobot-harness-v3:call_01_bpkpq53B4EUlDMoxa2wT7703|61988ebe-c0cf-41c1-8e77-2ad7be2cf19b -> tool:nanobot-harness-v3:call_02_XhQa7zLXsrqz8jhggqOM4657|eef7154a-ca75-4825-9b6a-8403ce7869e1 -> tool:nanobot-harness-v3:call_00_kytvO62OGNnWpYUfoJDX8125|e4f8e882-0e98-4f9f-a6aa-ccefbe59aacc -> tool:nanobot-harness-v3:call_01_tAk2Qj4gwR6Cdy60HWZT9532|9593f0a1-c635-4547-9180-9c2de9d531a8 -> tool:nanobot-harness-v3:call_02_jnBEmKdaJ1Er5d1f7FKl2320|4239aeb4-84ea-4d5e-ae07-1efab3d4bbf1 -> tool:nanobot-harness-v3:call_00_phGtpcINy8E9Hl9UGmFl2558|d2505f2e-610a-4378-a811-010c2a57e400 -> tool:nanobot-harness-v3:call_01_wuVQElysVKf31yB3a7ff9905|5b02e4ba-b4b1-4f13-8833-db2b790b87bd -> tool:nanobot-harness-v3:call_02_bBClFxKhpQHumfpmfWqK3442|9d5e25e3-5940-41a3-8006-f8e0fb7bb347 -> tool:nanobot-harness-v3:call_00_v1fk8EZDvX60rYVnPou77494|fb588596-1835-4f15-8fe6-2dd1b85c6681 -> tool:nanobot-harness-v3:call_01_jryomKAUARLzAyK6LxBp6712|698e33ab-aa39-4e9a-87d6-8849b4164da3 -> tool:nanobot-harness-v3:call_02_ELNTPeh6kgdY3GJykfFS0600|b7e679c8-4c81-4452-ab72-75279ea26630 -> tool:nanobot-harness-v3:call_00_BpbMCYNJnhxLb6z5av8X0520|e15d68b9-a81b-4fb9-8a8e-130331b2a3da -> tool:nanobot-harness-v3:call_01_IrMFzMVBfIF5tnxnAl3n0928|fcec5106-d2f2-452d-afec-1946fb4e045b -> tool:nanobot-harness-v3:call_00_YYFzteHX28rkHwVjtn5X1535|ad482cf2-f28c-4024-a609-841182a5167c -> tool:nanobot-harness-v3:call_00_tN6BJDPTkyVLUc8jzomS8915|89267f8b-c420-4c1a-a774-f3a07fbcbe13 -> tool:nanobot-harness-v3:call_00_lnDAjLQdOf8YVY5oGAxK3075|65dc6849-6b16-40d7-93a9-b123be69fc48 -> tool:nanobot-harness-v3:call_00_dD7x47mnHyea30f46IWe1139|6916f997-4f3e-445b-ae69-b13fb940b816 -> tool:nanobot-harness-v3:call_00_LDeFdIfjlV1oBq8TLlus0818|30fbbe69-26f4-4906-8f99-d883f0bdccbd -> tool:nanobot-harness-v3:call_00_wZHZ7Wu4cGNxN5sGHdmz0014|cd43a050-0c9e-4301-8c87-24b0d50e19c7 -> tool:nanobot-harness-v3:call_00_8QdkTbOclzEk5THQNEpd2615|1b69b00b-7de4-4a67-9f62-813f7530bb78 -> tool:nanobot-harness-v3:call_00_aeWtjree4R6F4tPJMts97302|9c26b1b0-4d0a-4751-9ea4-61be646a43bd -> tool:nanobot-harness-v3:call_00_uaDWe1mHVJ4s6mUzaLbi1759|50c7f69b-ae7e-462f-84cb-c9718e7a3d34 -> tool:nanobot-harness-v3:call_00_CxWHqbqSVXY9QJ2B4Ovc8787|44f57174-1ab9-49fa-880a-2e57c682f174 -> tool:nanobot-harness-v3:call_00_hI1lMhOHa96zj50nYW5U0730|ff4d9a81-718f-4f6e-bfd8-40c026db5de5 -> tool:nanobot-harness-v3:call_00_QTpa8yLKFmBorMztadLD7482|3b1da698-157b-4548-9ba2-d577ad84f4a5 -> tool:nanobot-harness-v3:call_01_QQXuYW0b0OOhK1uvqDly1360|cfff12a4-1d8e-480c-9dd6-df5da6d7e2f0 -> tool:nanobot-harness-v3:call_02_IY3Ip7zCAZyH5KVOh5zn4547|cb5f40cf-7e95-4cf1-8653-529de8df469f -> tool:nanobot-harness-v3:call_03_TQdXSIOPGy1jrvKQ6iSD2500|4fe7165f-10c8-4662-b4b5-6efd2fd2311a -> tool:nanobot-harness-v3:call_04_Re8IRTbB59s8BjO4RuDH4953|0deff0d9-1dbd-4b13-847d-a4a8c3e6d5d9 -> tool:nanobot-harness-v3:call_00_J9Q5OtggAFXoYZoG7Xkz1953|1ec19632-5ad2-4106-8623-af2ae88ecc7d -> tool:nanobot-harness-v3:call_00_MAUTcq2yfuPf8VWuRqq63004|aee15bc1-e598-4005-bfd5-f45779715349 -> tool:nanobot-harness-v3:call_00_Q8zhhkRxBTEgyOLXLDd14795|2cd376bb-d4e7-4053-9387-0f6a9ec4ccb7 -> tool:nanobot-harness-v3:call_00_sjiaadPf8pFuzoXIpNMx1019|f7f80390-b648-43d1-a6f3-643a64effccf -> tool:nanobot-harness-v3:call_00_jj8yMrrnywnYndYuSiRC2385|05bfea72-1286-420c-9716-813bc07ba76a -> tool:nanobot-harness-v3:call_00_kOmGjGUoaMRBkDkjLgRc3636|1a2ee282-e4d1-492e-bc86-ed3940a5794b -> tool:nanobot-harness-v3:call_00_cHefARftk2WhxeiDtISV0085|26e48592-d8b1-410b-bca0-3ab5bdb1e816 -> tool:nanobot-harness-v3:call_00_hB2FiZLwKxni05OxrrdV6690|6722a597-8f30-4603-b3d4-54e34321b81c -> tool:nanobot-harness-v3:call_00_HRY5BPpzToKSneuN12Xq1521|8e431790-00af-4f5e-ab2e-cab6443f2c72 -> tool:nanobot-harness-v3:call_00_KPDTojPnyuMxrUUWwHGF5122|5efcd630-7122-4107-87a5-e8271d49f15b -> tool:nanobot-harness-v3:call_00_3Ylw0hQsq3xZpA52Vafm5666|8d191c1c-8c51-4cc8-a60a-58f7db110ca6 -> tool:nanobot-harness-v3:call_00_2iW4MtImdEjP3eD9H8yI4662|c0ff6887-06a9-46f3-9cf4-52bc1fc443cc -> tool:nanobot-harness-v3:call_00_gMgcGdrMInmA3mo4GWpH0514|cd991d89-3a93-410f-bbe5-a683acfcc400 -> tool:nanobot-harness-v3:call_00_9xlhQzcqaDzYdcIVzH3X8163|2876ed88-9463-460c-bd0c-83ba5a3bf02c -> tool:nanobot-harness-v3:call_00_ZQOc8rNrHDBx0FzwSpvd8824|6ce97c73-6926-4325-8ea1-59b40ff7927e -> tool:nanobot-harness-v3:call_00_dao7teE4MJr0cBhgtrWH0736|dc78d84f-28a0-416c-98ae-cfed36d48fec -> tool:nanobot-harness-v3:call_00_7aa4BS9MthX13PhDgkCR1432|aeaabdb1-6b04-4d4d-84fd-dfe65966d4f8
- 关键路径耗时：1.90007
- Makespan：473.597114
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
