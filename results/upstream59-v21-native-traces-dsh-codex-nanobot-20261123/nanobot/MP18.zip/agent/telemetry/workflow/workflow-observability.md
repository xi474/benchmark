# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP18__j9DUeG3__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（57 节点 / 56 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：57；执行边：56（observed=0，inferred=56）
- Execution Trace Graph：`observed`；temporal_next 边 56，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_HwpgGpmymw1lC6Hp0jEr0716|32ca8129-4da2-4433-8918-1af734b7da00 -> tool:nanobot-harness-v3:call_00_XiYhd9AsYaFWb1DbqCj39861|5f6c8413-a1b5-4bff-8456-66abf1e66505 -> tool:nanobot-harness-v3:call_01_oy2LTPGCoCXvK4TGhMvF4757|75117bd3-5e27-40da-8d85-a13fe910aa4d -> tool:nanobot-harness-v3:call_02_EjoMzvneFwETIiiRjKVE6709|62209774-c4e7-4995-8f13-fb9d87414ee3 -> tool:nanobot-harness-v3:call_03_oHlCqhrxnrBtIXrDXYmX6565|ce85abbd-9fe6-4942-a011-31b74938caa5 -> tool:nanobot-harness-v3:call_00_UvkVErivnK2LyAZ5SOZl2061|c438a07e-e869-4a69-a32d-3bb8b35ba980 -> tool:nanobot-harness-v3:call_00_UTYWZ7okFYu5kXrhu5YA3999|5aeef6b2-c2b7-4a66-9b93-cf553675229b -> tool:nanobot-harness-v3:call_00_eOFPch9d5GUSvJfi0yRF4198|58648bf6-410c-4a84-b0db-4d38428a4c5d -> tool:nanobot-harness-v3:call_00_W86UHNtwOfGMi2psX7GP3188|9f955b73-73c3-4272-a030-7538ebdb2de8 -> tool:nanobot-harness-v3:call_01_R2LeBxBW9NCBJ84qA8518360|861465f3-d518-4a3e-bf22-523d074822ba -> tool:nanobot-harness-v3:call_02_Co7KYS8cKeSrW7D0w88f0451|da106ac3-9d1f-4be6-b0d8-34a7d5ff7da2 -> tool:nanobot-harness-v3:call_03_kBLjESxJ6hGNpc4WYYke1191|20238de2-5162-4287-a79f-cf5b08d82aa4 -> tool:nanobot-harness-v3:call_00_tJF0eGglhQthCYfIVT424292|b4e3bd09-c18f-4a85-8b3a-f033eed6d3af -> tool:nanobot-harness-v3:call_01_Ji7HI9SPXaTxqUum4Rkd4451|54d297a4-ba64-4d26-ae6e-555febe02e6b -> tool:nanobot-harness-v3:call_02_Uqcm1VRErO9Ge5olowJE1299|78656da5-c682-497c-84f5-62972c23c104 -> tool:nanobot-harness-v3:call_03_zYp86qW1JxrJsp5BIlaZ6294|7c647c38-22e6-408a-aced-dc2b8ee3be5e -> tool:nanobot-harness-v3:call_00_RW5zHcGzTf02K493zh4M7906|2e19d255-6b79-47a3-acc0-6dadd66450e6 -> tool:nanobot-harness-v3:call_01_WvVCuAHB3Lmy5k76KJHr4086|436a8ca6-157d-4f70-bc01-eb9f984a8ec0 -> tool:nanobot-harness-v3:call_02_ofDi3sRppBZKMfNuBeea2051|91bb1bf0-b6b4-49c1-8a01-b2f88d1cd25e -> tool:nanobot-harness-v3:call_00_ttZypFv44wzpqy7lanrg1343|0585344f-b6b2-43c4-b3b9-a1707ec1a06c -> tool:nanobot-harness-v3:call_00_aV5sVz3h3QLmGBUcMiui8330|27e96f33-7973-4363-a6ee-82bf6aa23f54 -> tool:nanobot-harness-v3:call_01_pF2LxisQSRtX98vqQGAN0368|f5bb36c3-b0fe-4e5e-8ff0-ad82ab8ba024 -> tool:nanobot-harness-v3:call_00_JGbTC8D1Qc5sElv661xZ9134|04d232b4-7904-4742-aee5-40f1bf2a3957 -> tool:nanobot-harness-v3:call_00_s5e3pdiGaBuILYNGJ9cR2758|45f147a4-fc6c-44ee-873c-f4d1ac1c3341 -> tool:nanobot-harness-v3:call_00_59kW2vAbIT1iUxplbulW5874|65aff128-2d03-483e-b670-124a2e2666dd -> tool:nanobot-harness-v3:call_00_R2SGyuqoNbEii0evKy2M9789|d61d3d31-f503-4c9e-aceb-697f01e5850c -> tool:nanobot-harness-v3:call_01_2qtfqC1PiOuSvFFSkcOB8790|cf86b445-6587-4fd6-b65a-455701e74ebb -> tool:nanobot-harness-v3:call_02_lDBzHqvNu92hVVI4c6nF7919|7c6a677e-52b1-430c-8563-60b91e11201d -> tool:nanobot-harness-v3:call_00_30z9fZczkl0FVNdnxht61336|05dda4a2-6153-431f-97d6-29a10d582bb5 -> tool:nanobot-harness-v3:call_00_uV6PvlVdlEZcDe8cKKtn3131|e01a4d87-162b-46bd-9dc1-9da6ab41a361 -> tool:nanobot-harness-v3:call_00_tRe4X6UuAzRrC6ReiZUS1399|2155219f-f169-4e91-89a3-b727ebfa82aa -> tool:nanobot-harness-v3:call_00_FDLwhYCt50RSMZcu2U415413|f4130e30-7780-40e5-acfa-fe2f83a3cbb9 -> tool:nanobot-harness-v3:call_00_Il9w42lnG7N06uYMXPXK2599|1d8c9971-2417-4bde-a29f-72fc652180b4 -> tool:nanobot-harness-v3:call_00_v68RYBfQLY2U1TrGspvY2901|2aa4765f-423b-4644-ba51-289df87186f6 -> tool:nanobot-harness-v3:call_00_1qComdmoRPTsmM80A0ZN8547|3c17eb8a-70ea-411c-8340-1309b0edd2d8 -> tool:nanobot-harness-v3:call_00_rS9hbC04029GPP6yQnsM3764|4550f589-ec7c-48b8-89f0-b980b996ea86 -> tool:nanobot-harness-v3:call_00_S1jb9pxQgRmApkZJDe4N9022|f3e86c9d-ae95-40ca-ba07-c58c0241c3aa -> tool:nanobot-harness-v3:call_00_gKmDuUCj1OrZajIDkwuu0317|bf500296-b9d1-40b5-9138-89b43b3d5083 -> tool:nanobot-harness-v3:call_00_49RKWKIH2sNSnlsy9ddc5948|ed5d6645-4dc5-4aa3-a21e-a839b4b2bd17 -> tool:nanobot-harness-v3:call_00_6dzGeknfj65cmBhcHinG8863|e42aafc8-b6bf-4dcb-b4b2-6a0a9c2f6d89 -> tool:nanobot-harness-v3:call_00_UKKaw6sUkry9jthIKza80502|8781db36-d3cd-4826-9629-3a4f30df9b29 -> tool:nanobot-harness-v3:call_00_URLBkoVFthSH82HsCL136076|4fa7368c-975e-4280-be3c-211c8851d758 -> tool:nanobot-harness-v3:call_00_zyH1IcL0mBYMwZuA3YTz3279|010a7470-1beb-47ac-80cb-15d79b5f091f -> tool:nanobot-harness-v3:call_00_rPT1iUf0uIhO5yfk0PFp1978|285143e6-7f17-4a5c-ab6d-e73f78d97ddb -> tool:nanobot-harness-v3:call_01_M0inZ03cW0M1N25efFLe8721|d7b3a849-7170-4eb5-82b9-7d1952e3f80c -> tool:nanobot-harness-v3:call_02_acv64DPUGvy2Jo6KI2QJ5000|2754158a-1e75-47a8-b89a-1b97beb99af3 -> tool:nanobot-harness-v3:call_03_rDQXCmy2sN808dpgzlfH5153|020da6bc-2c29-4efe-a029-94dd2c36f14f -> tool:nanobot-harness-v3:call_04_kknrqA7HkgWppnI4qztp8615|93e6b300-0dd9-4f50-b8e2-67f2d55971db -> tool:nanobot-harness-v3:call_00_gob0qISDyyLpFrcm69pT5712|08319474-19ea-45b7-a8c6-bcfd2348c2cc -> tool:nanobot-harness-v3:call_00_EDAGbn3NepOqE7htVbIZ1299|939ec119-9869-4ce3-89c3-2df4312d9666 -> tool:nanobot-harness-v3:call_00_zchNZznEhBdZIt6KZ4CN0645|8e985b72-4d92-409d-9199-443ba0d15ee0 -> tool:nanobot-harness-v3:call_00_5B7BauFySyrCZxOAFjSp4211|564291fa-215b-4aa2-b403-a02d62761997 -> tool:nanobot-harness-v3:call_00_xYHPPhKUh2prow5LRxQ69798|e5d6eaa2-dff6-45b3-ab72-1f5836691906 -> tool:nanobot-harness-v3:call_00_c31Une65FBQojsnXhxdY2781|98e5c17d-6bc8-4f10-8740-ca811cf9616a -> tool:nanobot-harness-v3:call_00_8t3itOgJMY2U2s1zTugO1510|9eceb0a7-eb55-4f40-8d03-81cbba212e5d -> tool:nanobot-harness-v3:call_00_sL8Nrls7shsPUXhaba6r3437|10887539-abf3-44f0-9c1c-7fef76dd86ad
- 关键路径耗时：1.50467
- Makespan：929.862917
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
