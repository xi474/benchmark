# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP19__inxy3Wc__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（82 节点 / 81 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：82；执行边：81（observed=0，inferred=81）
- Execution Trace Graph：`observed`；temporal_next 边 81，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_Ot2qMbm7Lu1vv4AxSff07945|340423df-62f9-4095-b1a1-3363649b8003 -> tool:nanobot-harness-v3:call_00_UGuPyk69FTdon52f6ciC9405|f0bdc7a2-8677-4576-9e4f-fba97958f945 -> tool:nanobot-harness-v3:call_01_fWh5OEw0rEP2cIqz2VhW4856|2fde9e8a-5bb3-4162-b362-2bf41eb1c26e -> tool:nanobot-harness-v3:call_02_xMPH6ASHfJuKVKopuzJu6091|d6ee421b-c62c-413e-aac1-b7f09663f963 -> tool:nanobot-harness-v3:call_00_s6kEKVLcLT1tFynctr3u3378|1358e488-ce04-4096-9822-c4f93563ca15 -> tool:nanobot-harness-v3:call_01_WXdnuMugQqV8kXFj5UOA4369|283dc967-d056-4071-8a10-0380b1837aa4 -> tool:nanobot-harness-v3:call_02_qgUrD50QZtr8m7QprA347984|b088d36d-ed5f-4f25-a22d-e8f0dc401eed -> tool:nanobot-harness-v3:call_00_7YHVPzwFnGK52IoZ5Ic56136|07bfffc2-0b66-47c4-b19d-da54d2142e22 -> tool:nanobot-harness-v3:call_01_cULJPTll4pD57wwb6x8A9067|9ef149d8-72e2-4f52-b405-aeb62cf0a68b -> tool:nanobot-harness-v3:call_02_0hkXGujorKqx0ecZonwH3367|5cc69dde-98d9-41fc-9aed-615fcc2dd8d9 -> tool:nanobot-harness-v3:call_03_IAbpaouBezRxb5m0dmWe4644|a3e5aba9-e236-4653-bae4-b7f63ce7a051 -> tool:nanobot-harness-v3:call_00_236g50pFPJ4DmX0nhGf05380|1db30606-b42d-4ac9-bad6-5392bd4d4098 -> tool:nanobot-harness-v3:call_01_Avpcx9GWNCkcbEIqwSpc6538|03e05c66-39b2-4eed-9990-d0286ab2f39a -> tool:nanobot-harness-v3:call_02_8nVHrBYeT8DedDY7or614483|24ae2525-0108-4ead-b520-89b8ad6a5352 -> tool:nanobot-harness-v3:call_03_2nSCblWzOFh5bk0pA3Bu0057|3e71d879-77cc-4ab4-9c50-591be4e96036 -> tool:nanobot-harness-v3:call_00_kIE2ArRpwdxLaVcZNDNJ3732|3c1cada1-bd05-4b74-968f-90777fec5231 -> tool:nanobot-harness-v3:call_01_aSe6uEhXtZteYyQcclax1588|61a31eda-0147-4a96-bd0c-ca46c63e07a8 -> tool:nanobot-harness-v3:call_02_yVLF3SmzgzQnBbNFRJg67559|fe7dbd29-d4f2-496c-8ae8-a3edaac9ba01 -> tool:nanobot-harness-v3:call_03_DDvXESW9z5Tn0vLPLAEt1059|4971746d-e11c-453a-bdc2-a278f7687c0f -> tool:nanobot-harness-v3:call_04_MBOIAVp84qvuh7M80ZAi6222|09fb6c1d-9910-4662-91ba-4ab62ae28de1 -> tool:nanobot-harness-v3:call_05_ExmPsPee2AWVBzYaTHhF7042|fecd4bb0-5c47-452f-90a7-9451ba74b25d -> tool:nanobot-harness-v3:call_06_TSQz0t4n4rnoUbc0tdBS9609|ba4b93a0-c869-4ea7-b021-b0430dc17aed -> tool:nanobot-harness-v3:call_07_rYo4fGSIMcxrq06Di72o6220|fd6e3f8f-4d1e-46c6-b453-12454d0af56b -> tool:nanobot-harness-v3:call_00_hDCIq9NMwTNibR5ttaNd3355|2d06fa36-5074-401e-8665-cab64568b8df -> tool:nanobot-harness-v3:call_01_Hl3ylv0iWKgRnrwgywmt6837|f9eba2c1-e8da-451b-9334-952602b1342e -> tool:nanobot-harness-v3:call_02_JnSshVkkoXbosfxrXq5h5725|f7177f52-cffd-4797-a9e7-80fb99912c51 -> tool:nanobot-harness-v3:call_03_0aUe3ufBJQIPoDrPtww40295|92ae3a85-8626-4ec1-94f8-74bed33210a1 -> tool:nanobot-harness-v3:call_00_Xnsr0nXMj4R0um7Mvspu9569|144948e9-53f7-44fe-834f-bfdb0d6331bf -> tool:nanobot-harness-v3:call_01_T1Lvjj6jiZRDhfU04Aix4758|c13cb7ad-63c0-4e31-a757-10f605cb065a -> tool:nanobot-harness-v3:call_02_xhYUCmUHwwt1KBACHmE42652|5d7e6ae5-cbf6-493d-9fce-e21c9a1d8baa -> tool:nanobot-harness-v3:call_00_eWZbtg3snja039dgzRmX3773|ef5e9d9c-2123-4247-8343-54fb8167386c -> tool:nanobot-harness-v3:call_01_wKYBqNDc2kCqT8JGEVyO7012|287f4f05-1aee-415e-8de8-56e1a7e0f7ff -> tool:nanobot-harness-v3:call_00_wsY4gJ9XLYKSs3nMgpQH0741|526c51f5-9a2b-4868-b26b-f81cbdf5c4fb -> tool:nanobot-harness-v3:call_00_KgETApgy2tkuYEgZa4ey0650|f0ae83a6-4a77-454d-bb2a-23753f041c3f -> tool:nanobot-harness-v3:call_01_GD7m1YouF84XjOsu8L9g6747|5a1b179d-3efd-4de7-b4f1-997f0d216d8b -> tool:nanobot-harness-v3:call_02_5VQg2ZTxsNmH1DLbShL06386|913d30bb-5ed2-4c8f-8f43-edd37664af26 -> tool:nanobot-harness-v3:call_00_2oLNBf0ZeXN53V7y8ZQN6228|6dd3cf09-4112-4502-86dd-811191efd17b -> tool:nanobot-harness-v3:call_00_gNwH7yHJdOicW9AZ6WpW5037|fbf4ebc2-f28d-41f0-ad88-16cc0a42e44e -> tool:nanobot-harness-v3:call_00_R33HXAbkTjLlFqvjBtzd5428|0454f22b-f62f-47cd-a7e6-1e5e20134788 -> tool:nanobot-harness-v3:call_00_vyXJ4lHpjk9SzBIIpmzO1351|3e95a1c6-3d97-4d36-9980-d1f53177f731 -> tool:nanobot-harness-v3:call_00_od2ABggII7qwFdWJnjHA1653|28e85e25-f06f-4909-8156-0f17696947bf -> tool:nanobot-harness-v3:call_00_0zHtBv4dKn47RtGwrif26265|e1731e32-11e3-4d59-8559-77953dd425a5 -> tool:nanobot-harness-v3:call_00_rD2me6pPfkE4OAnAl4Lv5704|e60c83da-9474-4e02-bed4-0e27c579dbd5 -> tool:nanobot-harness-v3:call_00_o13xCdOQ2fz40XrceXYj2931|95b7c922-0264-4123-9919-369a6e084db4 -> tool:nanobot-harness-v3:call_00_o5txdMHWFZFwUY0SxnRJ7145|2143bbba-17a9-4e78-bea9-4d1d63dac6fc -> tool:nanobot-harness-v3:call_00_Sy8ghniBEqb70ZDwIrdT8053|9a42e96f-05b6-4ac4-955a-f73c8068d7f8 -> tool:nanobot-harness-v3:call_00_oenX8j6VznShqnnN12gO1511|d56f1a64-4aa6-49f3-91b0-32536543cad3 -> tool:nanobot-harness-v3:call_00_o3V56q2aK8QUcP4JHa9L0710|58339805-c182-4ef5-b6d0-9847a5e5cf18 -> tool:nanobot-harness-v3:call_00_GHn72rSu0UZG3XMEMFME2097|92f22284-d1a7-4191-bd7a-405d03100a75 -> tool:nanobot-harness-v3:call_00_pCEJmnfLX0rAdx7IfJll5811|f098ee0f-fcf2-4777-ac15-1fbe86622507 -> tool:nanobot-harness-v3:call_00_cE4PZDKwSZGpjGujf33n0672|c47a3682-4bb9-4d77-a29f-b9a839f6eaaa -> tool:nanobot-harness-v3:call_00_gWvjfVT8Ec3iMh2MDblW9214|6e417323-1fcf-4e07-be23-c1c75cee0a6f -> tool:nanobot-harness-v3:call_00_XZiDGlAS7nQ9w2cV4DWp1737|61383b19-37fc-46f1-bea8-16e1b6504aae -> tool:nanobot-harness-v3:call_00_vehSrN4oFKJM8mySjVjg2617|80e68000-f133-4e86-9c3e-206501ece85f -> tool:nanobot-harness-v3:call_00_ZF9ONN1Bu0YCdJKL8wVe2683|be383344-2348-4b48-af87-09b0ab5a667a -> tool:nanobot-harness-v3:call_00_HoiApLK9vmXqkYBMCDru1152|7b55a2a1-3b65-4b97-b23d-f24c7c14c7ab -> tool:nanobot-harness-v3:call_00_6gW1V00CKNfWMD8mSvHy6314|9b9beb10-0ef3-4522-8b20-6378476bd26c -> tool:nanobot-harness-v3:call_00_ExXegppDNtLMHgqa55Q46990|b50273e5-b79b-4ad6-88f6-9c3b59869176 -> tool:nanobot-harness-v3:call_00_17IK1R2AHwDcEaEB3Jw87246|06901d59-9cd3-46d9-9020-1c91bb243605 -> tool:nanobot-harness-v3:call_00_xdGBeVS9bH3ITqqK6KQ05183|f0fe04c5-25d7-438a-a2fa-a14a13989e97 -> tool:nanobot-harness-v3:call_00_3U3ohzmLcxNWxgL41Wqb2196|bb638f55-7fdd-4bed-8825-031360be28b3 -> tool:nanobot-harness-v3:call_00_cro7nnSC2tCJs6UbrPwC5474|d75e88ce-fd25-4242-86e5-67d22bce1f91 -> tool:nanobot-harness-v3:call_00_sqPwMPmMT4VmW8SiPk9s5970|910f7080-e98c-4283-b323-9aff49b52561 -> tool:nanobot-harness-v3:call_00_rFfWVR814waU5lT3AUD85319|ff4dce01-2116-423c-a1aa-029d41ffb973 -> tool:nanobot-harness-v3:call_00_vQJy24Q9JoSj7fzY4r1x5048|f8fec3fe-733f-4c56-87b6-0d9bf327d507 -> tool:nanobot-harness-v3:call_00_eo2b0wRcq2Aztw4zZreK0366|7788e682-2e78-4ee4-8569-903928dd36df -> tool:nanobot-harness-v3:call_00_rqqTJM4yPlREOhOvxzhJ6547|18efad5c-3a15-40e5-b510-4c541234d3e8 -> tool:nanobot-harness-v3:call_00_04HE1Wamqv68GQQoKIiI0572|2292be8f-fc18-41c4-b989-dba2ea8925d8 -> tool:nanobot-harness-v3:call_00_cCGOL9MTLZZj32GpfS1r0269|674ee964-42aa-41ee-96c8-7ce5bb031474 -> tool:nanobot-harness-v3:call_00_daulihvSyCSKLu9Ah6za4538|4a59b6a2-0280-4342-af14-7427bfc9af59 -> tool:nanobot-harness-v3:call_00_5EpOHVuB3BJYWx10Q7m43452|5e972832-723f-4cc0-a218-f62f7c8f78bd -> tool:nanobot-harness-v3:call_00_he0xJ49iCQIbuU25Hq410653|2e9b8702-6321-4e61-a99f-ada722aa5010 -> tool:nanobot-harness-v3:call_00_czWsrZJDRQ8TyuhVs4tr1545|814403ac-559a-4f23-833f-ef5a38ba192b -> tool:nanobot-harness-v3:call_00_oEuvwLBK66CUnlfv6IHW7837|45bc8884-df0c-4ca0-b816-5e71cd8bdc7d -> tool:nanobot-harness-v3:call_00_BUl0WzpKjB8XsCYaeYIV2400|9f556153-d691-46eb-a323-d6ab5a8b77dd -> tool:nanobot-harness-v3:call_00_3DxqVYBtCy6A73EInt5j7828|29e70831-16e5-4f5e-ad5a-71c831808d76 -> tool:nanobot-harness-v3:call_00_XY8CnFW09W9Xnem06VfW0354|77e6db99-90e1-474f-b345-fb24f801bd80 -> tool:nanobot-harness-v3:call_00_UhZSvMH3cQfEMxa669nl2575|bb2d2f76-114e-4690-a588-cadd9d7583f6 -> tool:nanobot-harness-v3:call_01_iPheqlb4rpTXXjHC6hj46336|a05eb468-8e3f-447a-b959-eaf59792e374 -> tool:nanobot-harness-v3:call_00_ujuivzxzW3YpwPfjLqKr7272|781985e7-c31f-46fb-9112-df6cc67ecde9 -> tool:nanobot-harness-v3:call_00_Zi2vuz2r5fgz7TdG2ywJ5919|88f5902d-3d01-482a-92f9-0fedaa42f493
- 关键路径耗时：2.352228
- Makespan：1578.596107
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
