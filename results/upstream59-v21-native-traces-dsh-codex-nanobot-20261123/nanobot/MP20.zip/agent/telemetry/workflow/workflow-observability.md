# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP20__i2eU7H6__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（94 节点 / 93 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：94；执行边：93（observed=0，inferred=93）
- Execution Trace Graph：`observed`；temporal_next 边 93，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_D1P3Rh64FIlB9VPm8ANe2349|0b11140d-5ba3-43d0-b9c6-107bc4154726 -> tool:nanobot-harness-v3:call_00_QlI3wIJba4BKwhVe0pRE2155|63b600dd-45f7-48b2-8e85-14402fa69d48 -> tool:nanobot-harness-v3:call_01_nQaza2ZcE6kGtUSmFD3L6713|1c0f1cc7-999a-4304-bbdc-54846ea98b02 -> tool:nanobot-harness-v3:call_02_kfnFvwZYQuc952Lbl2n81908|4539ea7f-cc34-4518-acf6-3280feb1aa35 -> tool:nanobot-harness-v3:call_03_DWH5QH1ds4jQofC0nKAn2276|05116584-188b-424c-a14a-3ff0bcaab940 -> tool:nanobot-harness-v3:call_00_guyaXdzTeausBGJOE8M19573|985e7b64-47a6-47cc-997a-0a0a3b4a3485 -> tool:nanobot-harness-v3:call_01_2iMvqIhLQMcYGACzWeO03381|0226d18b-9e16-472a-8ba3-532c1bfb758b -> tool:nanobot-harness-v3:call_02_e1SSmdfVjfqaPWUDpUmv2208|6ba5a292-19b6-4976-9d87-4d65f51e970e -> tool:nanobot-harness-v3:call_03_vaetgh3cqMZgRHKB2RdX6485|b6a32c42-050e-4502-92d7-815375fcea5e -> tool:nanobot-harness-v3:call_00_BNcGEim3j5tTbpxDfV2D6813|971d8853-e69c-42f4-b193-65813b928ddf -> tool:nanobot-harness-v3:call_01_ABR8XP36FWW1FKjzm1VM5492|c5e93fe8-f0f3-467b-b1f6-f25bbae92aa7 -> tool:nanobot-harness-v3:call_02_GT2IcC3RGTiVKoTofFb62263|d56b8462-c25a-4b0f-9a0b-c43718b649ea -> tool:nanobot-harness-v3:call_03_MQZ9yyjn8SAIZSBzpqFQ5821|692259d0-c288-491e-b1d2-01d332585467 -> tool:nanobot-harness-v3:call_00_2eLpkePJ0RLW3ru5OmRi9909|90840ade-d9a4-4575-98ce-9127f15f19d7 -> tool:nanobot-harness-v3:call_01_NOQA4JaK9TPT6FNuBvvn3157|3a9c84ee-5cd7-40ab-8bd2-3467a743864b -> tool:nanobot-harness-v3:call_02_cm4J6B6JRPlA4FzCnGab5378|1a4bc9f1-b857-498e-90ee-52312f6674ed -> tool:nanobot-harness-v3:call_03_FZpkHHveyolbxu1zk7446438|58551d2b-c6bd-4434-b426-2d746c1e0df7 -> tool:nanobot-harness-v3:call_04_ajYIvUS1C9k8O1iBcmqk6630|2ba31488-15ed-41d2-9169-b1dd4a11b026 -> tool:nanobot-harness-v3:call_00_ukxZVsHZBxAOobxwkrEA6072|9b68205a-cd27-4e7f-abd3-2984fad6c52c -> tool:nanobot-harness-v3:call_01_mSTy5t7CwoK8UajpbDHp5264|ab71e5cb-a382-48eb-a608-d4c1e32408e5 -> tool:nanobot-harness-v3:call_02_7lGKnwJUURQ1mzVDA3WB9642|5b3dbf56-2c4c-4215-abff-b997b6d5609d -> tool:nanobot-harness-v3:call_03_v8LPCef45Cd0rPbJMQdd6933|93168e2a-f83b-4bb4-88a6-4d969d28dad1 -> tool:nanobot-harness-v3:call_04_GupVeW9uUITNDKYIGbo15166|3027eeff-4b55-4664-a3bc-9b69f850d649 -> tool:nanobot-harness-v3:call_05_k5lJfzxrC8osa10ijHpc8611|6008f01a-acf4-4c3c-b081-38c11b562608 -> tool:nanobot-harness-v3:call_06_tmiYeteuzhz5OBZqqA9L1459|4940c6cb-5193-4fe8-b4fe-ecadafe24f1e -> tool:nanobot-harness-v3:call_07_wSO6VnyyUgW3RapkCVCH0618|2f70a290-4a1f-4edb-99ef-3f20ab8927c9 -> tool:nanobot-harness-v3:call_00_f0u2WCILGPfoEJ4Fv3r61426|632f5b4f-874c-40a3-aad5-268ba8e2408a -> tool:nanobot-harness-v3:call_01_eeUBabts0aibGQlHih8o9748|cd369ff7-603d-4c3d-83b3-58e4600b4298 -> tool:nanobot-harness-v3:call_02_tRH8XfTfUD3sSd1l6qY20933|617481ff-1a5c-48d2-a6d0-f96d0bcea50e -> tool:nanobot-harness-v3:call_03_KD6uY7UdzGCKaZ2YKZwy4966|6edd6851-86e9-451e-bcc7-c205519e6949 -> tool:nanobot-harness-v3:call_04_0cowgBaUI9Ot8hyxWgC83674|56dbd124-7cd7-498c-abf3-a791dfadcd4a -> tool:nanobot-harness-v3:call_05_i7tCr7N2JbXmwY61KRdo6705|8f5150ab-4f7f-4702-a3a1-0361fec2fc32 -> tool:nanobot-harness-v3:call_06_sx2unqIdB5iXRTnMxKva5601|81562df3-8981-4f8b-8631-8cdf31b6a482 -> tool:nanobot-harness-v3:call_07_lM39SclW4poNvvoyMeeL5198|cd9b6a17-32e0-4280-9adb-a42f6ea4cbd9 -> tool:nanobot-harness-v3:call_00_cMupl1cleUTM1TKL6SJH3089|4910cc7a-b7bf-4993-8d6c-0c0be2833550 -> tool:nanobot-harness-v3:call_01_gwujJbvnyNcyJImgrMTo0855|1af512cb-21a0-454b-b269-02a881894f7e -> tool:nanobot-harness-v3:call_02_iT3TmLvlvHP3yEgxkD7l3446|539cf435-cf36-40ab-a013-1bbc1de46374 -> tool:nanobot-harness-v3:call_03_Yq7m9wdqfU43APzhNSeM1642|2b032cc7-b3f9-46b1-857d-d091d44cebb8 -> tool:nanobot-harness-v3:call_00_b1POG3Aewe2QHLXdJ8A25516|b62bc886-f216-4e04-8ef4-da6d1303bcc7 -> tool:nanobot-harness-v3:call_01_cVq34O1k2wF3zWHr7ll20970|993c6d76-435e-476d-ac9c-381f19219f82 -> tool:nanobot-harness-v3:call_00_peadJ7QqtbHx7BSvFmzn9068|2ca9ba88-b263-40e5-b265-6860dd82267d -> tool:nanobot-harness-v3:call_01_jsnVdbwPqocL1thkPEvm1141|dbaebbfa-ce71-4969-9cc3-ec4122d60a26 -> tool:nanobot-harness-v3:call_02_RXERRSGi80KWom6OgM1a0284|5349c431-9433-4bcb-bcaf-b728caacd008 -> tool:nanobot-harness-v3:call_03_YVgVzxHdPJYVr6kmJMuB1565|dc714aad-dbee-4707-bd49-761412221950 -> tool:nanobot-harness-v3:call_00_3EGAX3p822JPRjS1gLiC9533|ad6c7621-d358-473d-ae44-3b88f9e28caa -> tool:nanobot-harness-v3:call_00_9q1tBMLsKVUSrUN2uuSC5706|b2804bfa-50dd-45c7-a96d-edd7652c0e05 -> tool:nanobot-harness-v3:call_00_z1kzYaZnf1rEdVchXxc66198|4c0b2ddc-fcb2-439d-8253-708411500ec8 -> tool:nanobot-harness-v3:call_00_qWOuvzadTThIE2dqk9aB8348|d507b484-4aca-4d4e-ba95-b3b96af7bb3c -> tool:nanobot-harness-v3:call_00_bp42ZI96mGXpPYshdObk5485|977346a1-b197-49c9-bdb1-8bfe008830ff -> tool:nanobot-harness-v3:call_01_M4UBxAxSZKFIaNa2ggg77164|b6cb2d2c-6d33-4226-bf74-672a87b7e2f7 -> tool:nanobot-harness-v3:call_02_Mw5STus3DXkijESI6Op89083|82645257-d85e-4506-8a87-3b41939f9518 -> tool:nanobot-harness-v3:call_03_fHYHh5WNP5BGOpedMuDM9554|f279611e-511e-440d-8dd8-ec174fda4ac6 -> tool:nanobot-harness-v3:call_00_oqSGE5qrof9h99nrAwKR6974|87e6f844-7e11-42d1-b69d-19f70ecd7534 -> tool:nanobot-harness-v3:call_01_lmroscH14CjcrkzXMsHX7147|7f8fac36-532a-4063-9325-898e322948c0 -> tool:nanobot-harness-v3:call_00_AlKGFTXMvhjgj57gpb9y9180|7d32c102-91e2-4e9b-943f-505cf360ec00 -> tool:nanobot-harness-v3:call_00_CeGNvNJqMxPtjdTu0DC35367|87617ebc-59e3-4418-ad6b-64a4ad476ab5 -> tool:nanobot-harness-v3:call_00_7lNoc1Y7PWJSPzUJZQqv6181|e75b9255-cf46-4140-8649-c13956a3aefb -> tool:nanobot-harness-v3:call_00_qINM1tAw4AHs8BOMxVtu5649|f46608dd-b167-4701-ae83-ec9706bf8571 -> tool:nanobot-harness-v3:call_00_mQHx93DwixbVYxKxXwZO6127|d69990a8-c25a-4294-a1d8-d931af818405 -> tool:nanobot-harness-v3:call_00_6R61bbbio42bJRbMpewd8405|e2203426-865a-4b7d-94c7-41222efa3f49 -> tool:nanobot-harness-v3:call_00_4jdpAK7m7wDFuIsdhaUP3268|5080b514-8783-438d-8dd2-8b2fa0736647 -> tool:nanobot-harness-v3:call_00_dOcecSKx1pu3aAvRSbVN9115|4142892a-d34a-4082-9f09-2873b59a0a22 -> tool:nanobot-harness-v3:call_01_Qig7d9ddqQ9O95NojfIR4661|e93c77fb-ed0f-4269-8224-ee11a0b6c075 -> tool:nanobot-harness-v3:call_00_WK0AkBMEDuNdNNOcWmGH5686|bfaa509f-ede7-42cb-8160-8a5201700b4e -> tool:nanobot-harness-v3:call_00_n4bo9bMHffa0nve33nqh4272|00190874-f774-4884-a959-9fc313463568 -> tool:nanobot-harness-v3:call_00_mABh5zuC8BNorLC7JNL57538|c54ee20e-5ea4-48f5-b6e8-f1f5ab3f541c -> tool:nanobot-harness-v3:call_00_BubdH7CpJuj76o8zqLU76802|fd332fc2-fa1b-41d7-b4a2-98b83d144412 -> tool:nanobot-harness-v3:call_00_WoTpaowOIap10bROpgy75185|cd9b26c7-9785-4474-957d-1f3767d7a046 -> tool:nanobot-harness-v3:call_00_xDWko4xk8dW4158uDtAm8567|b2598e29-a880-43d0-9fec-015e7ed80114 -> tool:nanobot-harness-v3:call_01_sg3wIwBT5zJdXBD3qB0x2709|96276017-51f5-445f-8a1e-6ad63c490369 -> tool:nanobot-harness-v3:call_02_Z45GkSwQP9mreBeWFR4x2031|3a9c2e42-fe30-46df-be8b-fb51ea0431e4 -> tool:nanobot-harness-v3:call_03_wbbsV55sh9a5CV4LRvEC7835|5a7235c5-865d-4919-959d-addd017a5dba -> tool:nanobot-harness-v3:call_00_zlZWf3nWkQ4od8JXtK7A2412|5d9ef899-3be7-48da-840d-5f828a08e4ee -> tool:nanobot-harness-v3:call_00_r52S545QZlmY0NLce2eB6787|39463335-9961-48d8-ae38-2cff5d08cbd8 -> tool:nanobot-harness-v3:call_00_kIL4OVaoJjl385f7Xcq49893|e6969388-916e-4221-910e-1469738bf921 -> tool:nanobot-harness-v3:call_00_lVbaRkRErxkLMTyaP7qk7140|0f94a68b-3904-493b-814c-a3d9720a96c8 -> tool:nanobot-harness-v3:call_00_MM1MTlAGP0ceMnMHRv2K6493|320cdab5-b4a8-494e-9205-0a363afc946b -> tool:nanobot-harness-v3:call_00_RrBJm97vVzqp2CXfHnGY0717|f6d34965-f390-4884-accf-9c1079a21ba3 -> tool:nanobot-harness-v3:call_01_y1oMql5eCr2Einv1zl3M4723|5a1219b6-9a03-47b4-98ef-23e07f01a253 -> tool:nanobot-harness-v3:call_00_OncQMnK919MZq8fp2rot2376|d6555ba5-6900-4393-9b05-63477d21382b -> tool:nanobot-harness-v3:call_00_0GFoxNwdMLym6HXN6VGN9647|4cc456c3-f389-4657-b343-60bd2338bbac -> tool:nanobot-harness-v3:call_00_lYYZ5urfK6cLo7KJF9Eb7560|62ad4b9f-bf63-4ec8-a3d0-015aa0088e7c -> tool:nanobot-harness-v3:call_00_rlBmpMbVFMa9ONrhY8j11246|4dadbd30-b5de-4c14-9d7f-20821da9e684 -> tool:nanobot-harness-v3:call_00_PMTFoBP9Suj2rfJRdBfg1895|34a97d20-363c-4334-b7c4-d8d0b30446be -> tool:nanobot-harness-v3:call_00_koRmnkJSVJkFRPPMoa6l9070|c6bcc745-6c80-4d36-abca-6163ada998b3 -> tool:nanobot-harness-v3:call_00_Hk5mff1YABU2wmN6rNxV8726|585724f6-894d-402b-89f7-a382c246af5b -> tool:nanobot-harness-v3:call_00_6sN3SciIIs5PwEUQ6iDm1464|0210857a-4f35-4882-8238-ce14a9032820 -> tool:nanobot-harness-v3:call_00_ss4RfdjbM5JBpeaN5QNC1427|d19f3c30-9a52-4494-8903-87fcb0dadeef -> tool:nanobot-harness-v3:call_00_uoGm9qCR9Z1x2qAuKEVp8080|966cc17f-64b4-4c63-9fb7-92428d845dc9 -> tool:nanobot-harness-v3:call_00_BVbEuNtfV6UnGTgZ5LfS2483|bedd1be9-5e1f-46b1-8e37-aac368218555 -> tool:nanobot-harness-v3:call_00_SYhv4Vuf2jZbQdCQJMPK6602|c52560f1-0181-4442-bffd-7ad41ff1ee9a -> tool:nanobot-harness-v3:call_00_PeXoSQYosZ00PK1W7FRA1749|70faaeee-41f6-49e9-97b3-73a155781a6a -> tool:nanobot-harness-v3:call_00_jlFQoh4X6gfdRe1fLrZn7467|ddcb2f50-5f42-4a13-a40f-51036e2f309a
- 关键路径耗时：2.690358
- Makespan：1330.987152
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
