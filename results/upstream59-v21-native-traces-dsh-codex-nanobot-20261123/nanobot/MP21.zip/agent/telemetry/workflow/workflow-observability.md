# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP21__ffP6jMi__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（96 节点 / 95 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：96；执行边：95（observed=0，inferred=95）
- Execution Trace Graph：`observed`；temporal_next 边 95，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_Pv6O37CfcnzrgbwEHsar0176|70d4e37d-d13a-443f-b5f5-7b6d68f9a969 -> tool:nanobot-harness-v3:call_00_advRAQytZtpuPZX1DNvc5507|0c88ca88-edea-497c-9214-e4586531e46a -> tool:nanobot-harness-v3:call_01_BNhlLRdALRh39g9TBxay3313|22673d98-41ef-4597-895f-f63c37aa48b2 -> tool:nanobot-harness-v3:call_02_t6mBm5aqzVRLry3FPXu90946|47211675-7d50-45e1-a41c-4d5f8e635c16 -> tool:nanobot-harness-v3:call_03_cRkxvkyo2qQkmzPS0qH26186|fef77a6f-ec71-4c5a-b069-b694ca725ab0 -> tool:nanobot-harness-v3:call_04_RrRuMCvtPa9p31M44gfA8188|d217a177-38bf-49a5-90c9-14bf5aa79df6 -> tool:nanobot-harness-v3:call_00_C418XJ1HJwF3EZv3zkh76059|3574e1ef-00a3-429a-b22c-cda4372f47ac -> tool:nanobot-harness-v3:call_01_zCRmXUEYPEneSjc6RYDI5443|1bf311ca-fb3b-4184-885a-f139b49b3858 -> tool:nanobot-harness-v3:call_02_kZGyU3aVeRyoUbnxLJOU7501|0b1e83fd-1a9b-4373-be9a-0f1eac682a9f -> tool:nanobot-harness-v3:call_03_Hr8wIuaJvXB4T9PPDYJv9104|4dfe6f36-ba82-4391-aa2f-ee97585d1ec6 -> tool:nanobot-harness-v3:call_00_1teSw0zFiYjy2o1Chcx18022|97e33e50-967d-4a75-8f39-f8135c1483de -> tool:nanobot-harness-v3:call_01_OBpu3rhPJb6KrnGhd1Lw0298|71110283-323c-48b8-ae8c-8b09c90ef1b3 -> tool:nanobot-harness-v3:call_02_SyZbiFFFuOwkyOQEDxFa8645|d35dd911-e7c1-4fb7-9406-72787a0467fb -> tool:nanobot-harness-v3:call_03_ypMb9Zepro2ZecEN5DcI8259|37309b31-e49e-4863-88ac-4e665d036837 -> tool:nanobot-harness-v3:call_04_ZMcUgqlXwR4MStO5FOdM0831|78b47121-6427-48e6-b69a-5de97d036bca -> tool:nanobot-harness-v3:call_05_mEFUQpsCrhj7IA2wiGRD3748|59b45dea-c1d6-46b8-8eb7-0d868ea4303e -> tool:nanobot-harness-v3:call_00_6H97jsDRKybZ49RKLC0U1599|c6107a78-1641-44b2-b5c1-89ae85ba8b98 -> tool:nanobot-harness-v3:call_01_VoOdfW05jICa6qYE5LKI0306|f13e8414-376a-4842-aa33-8281ad694ef6 -> tool:nanobot-harness-v3:call_02_QMsRgvwJqVH0usL2v6v16916|cb55ac5c-4263-419d-912d-ef37a3e14bf2 -> tool:nanobot-harness-v3:call_03_i60EhUDpvliCZXqZxwid7081|89dcf429-55a0-484f-a98a-274f7320b43c -> tool:nanobot-harness-v3:call_04_BfEXF1L8LhmOyGr0Lxi20597|b56ffbb3-4765-4a38-a7c5-f7e6c741ec3c -> tool:nanobot-harness-v3:call_05_vughLCq1xVlt9vjbcRy59379|edbba809-44df-4529-b96f-fb2052119465 -> tool:nanobot-harness-v3:call_06_UAyapUvuv87hhz6yTsbq9227|b861e356-d466-4394-af19-bf5620b955d1 -> tool:nanobot-harness-v3:call_07_lXNgMjLQkNRbzMeUm0zs5242|08fa383f-185d-4c00-b8f8-5262710d4e94 -> tool:nanobot-harness-v3:call_08_gMiCt9loc92UAFVEZPHg3830|839be9ef-64ad-4750-875b-5fe5d53f1202 -> tool:nanobot-harness-v3:call_09_F0KPCBHVAqMcbY3mxYzO4246|a5cdf096-ce42-48dd-965b-085632848208 -> tool:nanobot-harness-v3:call_00_cc3W19DtzXBUnRhnZy8X5365|ccb2e7a7-fab5-4fd7-b569-a4fdffbe1922 -> tool:nanobot-harness-v3:call_01_9JkW022ASsbTTcK8lo9G9492|cac6533b-fd60-44b7-bd01-fa9bee6946a3 -> tool:nanobot-harness-v3:call_02_bQ5PSEq8EcPVn2qdGH9Q0367|116d8b62-eea0-4991-951f-d263a3aee756 -> tool:nanobot-harness-v3:call_03_EejWu1TbUwBlGH5EwuX09525|deed8a46-8002-411f-8eba-b8335223c31e -> tool:nanobot-harness-v3:call_00_so7pG9Zau2HBZPZkZUkY3156|d33db53a-d846-4fd3-8664-00123091de0a -> tool:nanobot-harness-v3:call_01_9tpLKcU4GlPiRO815cpe0529|f3e7c8e0-1208-4a78-b7cb-03662c9072c0 -> tool:nanobot-harness-v3:call_00_58RR76ehWrbBT5p1xWCT9208|3ea14a2c-be99-45fc-af21-e1df28613fe1 -> tool:nanobot-harness-v3:call_01_hznzl12JOGVOP3EB8i5Z0359|c370f7d8-3914-4c6e-a424-4a60a07ee299 -> tool:nanobot-harness-v3:call_00_LptguGP7A1bmsDH2Jb9B7303|ba886b7f-da13-40c8-849b-67122d57c450 -> tool:nanobot-harness-v3:call_00_TXs0pLwojEvwr4BwkMGx3876|f36a1c08-4ef8-4413-8b2e-662c19c7cb2a -> tool:nanobot-harness-v3:call_01_ZH4A6W4cs28JWiU3Wryt2362|5ef5b42b-9b8c-4f60-baf0-19cb8f8a0a72 -> tool:nanobot-harness-v3:call_00_bByNmbq8C9yXjiIwkAFj4780|29c90d93-0537-4932-8a48-36d5cbab2652 -> tool:nanobot-harness-v3:call_00_f3bFFNIG7lRRuQLkiBzy6340|7a2c25bd-cecf-4628-913d-3704e862e79d -> tool:nanobot-harness-v3:call_00_QHxfvLO2D94bVIeD1mCE0410|429ba366-9393-419b-ac41-992f29171b25 -> tool:nanobot-harness-v3:call_00_U5QEHinGuCMzhXLN1loG9782|788214b8-2808-4c4a-a062-79f4c22ee8c5 -> tool:nanobot-harness-v3:call_01_0vLy5eq4Qt7a1JykTorz1001|cb075865-e784-410b-bc86-b7df4b98e53d -> tool:nanobot-harness-v3:call_02_uvciuX4GGaYSCkWr90ZG9798|a901422d-a198-42a7-8435-9ee6d43b36ad -> tool:nanobot-harness-v3:call_00_Dw7qbpXNZ2cNtjo3mLr27185|8a17f9cc-5193-4fae-9ce7-708c4b700791 -> tool:nanobot-harness-v3:call_00_onkWnQuPXloPTG4WlZaL8924|e42b95aa-5dde-42f3-8e94-a7c251d19345 -> tool:nanobot-harness-v3:call_00_G7CDEWNaefI4kg7aKIWO7556|6f17499f-cfda-44e6-a253-f97462b2b7cf -> tool:nanobot-harness-v3:call_00_NCgQTsrgb304PD7pzbms5619|f1a72c5b-e530-47eb-b518-61db1cdbd5ef -> tool:nanobot-harness-v3:call_00_IYoXbfN9iPGT3V1ADTEC5045|0cf7d9ed-85a5-44e2-a4b3-dc08f4bd7fd1 -> tool:nanobot-harness-v3:call_00_tAbJxIp76h2nFGxbBbvb8261|e5878e76-e235-46cb-bf6c-cb81455c6a0a -> tool:nanobot-harness-v3:call_00_7HeNsXm3PADi285c5Aug6350|623f9ec6-e0ab-4bab-a549-92f55efa0ffe -> tool:nanobot-harness-v3:call_00_CpRU4Qbc3wvVQ9SOphsG2180|b8794523-555a-44cb-a4df-ca8b452c03cf -> tool:nanobot-harness-v3:call_00_NyeFrJAQtPFvmyRWpUZq0148|1022f573-21e4-46f8-807c-28850f343ea2 -> tool:nanobot-harness-v3:call_00_rDlir9B2BRagvEB0qALR4920|5118dcdd-ca80-4a4e-a43e-3c242b35efb6 -> tool:nanobot-harness-v3:call_00_o4nXmIDWLGTlhBiOzCjE2477|e2d510b3-acac-4e43-8bae-6aa74da41db6 -> tool:nanobot-harness-v3:call_00_s8QyU5btlw0Zb1lNKYzr6180|140ca3e1-2bcc-4a2c-af34-5ce2af004264 -> tool:nanobot-harness-v3:call_00_0ZbjMjvcc55c37D053Oo1004|293ad4aa-6a93-4bab-83fd-cef76fc86668 -> tool:nanobot-harness-v3:call_00_tBBuCCeGIw8kHlQNGrJJ3426|d03adc88-f7e6-4d70-9328-38787c4070b1 -> tool:nanobot-harness-v3:call_00_QIKdcQL5nPtxu3qMDuoN3411|63d9af12-307d-4d89-a8b6-1477e3e98907 -> tool:nanobot-harness-v3:call_00_Kh8zpoQyBIzSC0muPYt52114|f6670a85-5e50-418c-a228-f1a254bf803e -> tool:nanobot-harness-v3:call_01_YikAfF7sq9biIGT5nenL8482|15a5d0ca-0ad9-43a2-a218-28efab6c4db7 -> tool:nanobot-harness-v3:call_02_EU0ZjKTVtDcDA4l1RHVF1887|3ff1dd02-55ad-4f5e-a05a-e0f32e3343d9 -> tool:nanobot-harness-v3:call_00_OcOxaEWrtOjCsRHWgiX90586|4387e3ef-16ef-48a0-9cbd-d50cb864e484 -> tool:nanobot-harness-v3:call_00_TmPXBzkac0iq5FCcjYc44393|48b85a86-b85b-4613-8da5-675634afcdaa -> tool:nanobot-harness-v3:call_00_nR0fYBTzz2ynrN3cXHSL7907|4d833be2-c029-4b42-be17-1cf3dcc08bdd -> tool:nanobot-harness-v3:call_00_ODTRIWVANTaC48z3VQ7G8057|58e18e9c-c790-4ac8-957c-5c4f4880c64d -> tool:nanobot-harness-v3:call_00_bgbET300YcVePA2MdUnd2096|f80a52f9-b62b-4832-821a-1b9da983a8a3 -> tool:nanobot-harness-v3:call_00_tfvk4kirHhVc6Lvcrqcm7449|f25534b4-26a8-428a-85f8-0a637c9256c9 -> tool:nanobot-harness-v3:call_00_IB5pNjirVmVeAW1wFIzp4715|6035e51e-e53e-4afe-b9fd-78ae27634daa -> tool:nanobot-harness-v3:call_00_ngFVAu8bNYd7kmsjLOkn1899|0d8c093d-225a-4292-a8ab-596022211c29 -> tool:nanobot-harness-v3:call_00_HGpYOnsSI3fA1tNzjc3r5686|0ee1edfb-db76-44ab-b602-b32b42add909 -> tool:nanobot-harness-v3:call_00_e7j8fLIeMSJTLVjar7oZ5873|04534dfa-e3dc-448c-bcc9-061594690e28 -> tool:nanobot-harness-v3:call_00_SgZSKf1OZXeyHLpAW9VV0656|20af7e3c-7833-4110-8920-b1e6f3a486fe -> tool:nanobot-harness-v3:call_00_p45V2BhzlbMckvBX7sxV3496|9f68d5ac-08a1-431d-86e9-9d30aef1e3c4 -> tool:nanobot-harness-v3:call_00_bWSxHmMWQ9j7OF6UviiI1407|6a97e180-425d-472b-bca1-022e4336207a -> tool:nanobot-harness-v3:call_00_oLaYIw9QwjeQyTnqiVB89657|a882c36c-16e7-4c5f-9871-e4bf8a92a53e -> tool:nanobot-harness-v3:call_00_B7illYEYtEdNWatb8Lif2749|1a3b0165-2ae2-43c0-ae3f-2a30d7ee0d2f -> tool:nanobot-harness-v3:call_00_641wfgud6t1CEmtGRtj15028|8e8f63d7-e9a3-4101-837a-4a1b0d1e4c19 -> tool:nanobot-harness-v3:call_00_edhOE7gQytpAF3h1lzd52355|9655107e-0dd3-4554-ad4a-1e7cc8b36ebe -> tool:nanobot-harness-v3:call_00_wI05nPN9w5tscUSDdhqy0670|3f07cb94-e256-490b-8572-4ca10a81139a -> tool:nanobot-harness-v3:call_01_vFLfRQJMeXxicPbLy9hF1782|8321797d-befd-4e0b-92f4-a462a04126f9 -> tool:nanobot-harness-v3:call_00_AC4B2lRCgtMYDy3J3g028143|f4476daf-e1e5-473c-938c-d3edefd4fa35 -> tool:nanobot-harness-v3:call_00_G0MhwvHaV3Ieg5Vw4NWG3687|0e311827-b687-4c0b-8b31-4317ad787c5e -> tool:nanobot-harness-v3:call_00_p0r4rArZe6ACFG3U4kjb2542|14aaa220-072c-4319-b9aa-9beea1c4d86d -> tool:nanobot-harness-v3:call_00_vbxlAmKVVjBsXU50yczH2821|34f58574-1a56-4b05-a76b-33f0aea0e6b2 -> tool:nanobot-harness-v3:call_00_yDei4c8Uk05OpuWVMXw93581|3e48c03b-f68c-4588-ba10-9c150caaa2ef -> tool:nanobot-harness-v3:call_00_QXcLFRZCi8u6WVZaTNtI6513|e971c329-1153-4190-b189-c2ef480f93c1 -> tool:nanobot-harness-v3:call_00_hs6RSSujhFeKkTsWCLqV3893|7840ec0f-a269-4337-9ef0-abdac8a60827 -> tool:nanobot-harness-v3:call_00_iMDhcKhJhwV9lwTCaV5p1675|ca60a315-1234-476d-9a9a-c0523d53375e -> tool:nanobot-harness-v3:call_00_2y0rD9KqfbWCrdm3mopq4385|474bc5a4-58b2-4b4c-8616-a5a3e811bbc4 -> tool:nanobot-harness-v3:call_00_E9H3QXcTeJrAYbJTNIL86246|aa4d15b5-f36f-4b9a-9e9b-1d70a163f49f -> tool:nanobot-harness-v3:call_00_5Nb2OnDylmTh2X0RAdk45146|f720b695-7d2c-4017-a06e-2b4e8cd1e8b2 -> tool:nanobot-harness-v3:call_00_mnSd1suE969WvogJqfy84507|f0d4e70b-b95a-41d4-9ad1-47970f3db7b5 -> tool:nanobot-harness-v3:call_00_I45ZTm51jhTTEQm6LcO94985|62ad1646-e0ee-4a0e-9f55-4c1d0c3540df -> tool:nanobot-harness-v3:call_00_lEbuHzvg8plLj92vtdTB6228|d147797f-1115-4d73-85b4-541fa74de9ab -> tool:nanobot-harness-v3:call_00_8K4J0a4647i1qj7pfZZZ1266|a90191a6-e112-41dc-ac77-36855ba0efa5
- 关键路径耗时：3.468747
- Makespan：1165.559271
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
