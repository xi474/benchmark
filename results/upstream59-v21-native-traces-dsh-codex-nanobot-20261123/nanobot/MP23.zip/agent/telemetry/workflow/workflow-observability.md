# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP23__SmzJQiS__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（98 节点 / 97 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：98；执行边：97（observed=0，inferred=97）
- Execution Trace Graph：`observed`；temporal_next 边 97，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_BXat95h6vY0bvnNUEiJQ4421|5c2fc66e-4385-493f-88db-233afe528e6d -> tool:nanobot-harness-v3:call_00_Q1lvH0tl3wnN4tc0wIgQ2752|a1c7eab5-d703-4677-a3bc-39b8e290118b -> tool:nanobot-harness-v3:call_01_yX1JweyqlQK6GBoywwKu7971|a8858d3b-afc2-4ebc-ae7b-7ca57b27d01d -> tool:nanobot-harness-v3:call_00_tr0CxAZh3D8vnIyQxlzr5244|d4a14c2b-4aac-49c9-a734-07963c55ace2 -> tool:nanobot-harness-v3:call_01_gdPtGGtnQ2xlmSC8WYV05362|cd613bc4-8254-4799-b45a-bec2f3eb9e58 -> tool:nanobot-harness-v3:call_02_BdyF2tDNUBvT6rzosEBD4970|15a7c1ea-17d6-468f-8c89-a5d6ad0ba69a -> tool:nanobot-harness-v3:call_00_N4maDwdOdkHVXIdMFq0X7965|347ab21f-a4e7-4f3e-95d7-918d1a8cbfb6 -> tool:nanobot-harness-v3:call_00_qVuD7coxlS5gTj2vprqn6489|b96a9b53-1e66-41db-ae11-ace2ba74413b -> tool:nanobot-harness-v3:call_00_2kevDU9SFlZtlBlDrgFJ4662|6e06c1b0-627f-4970-b253-7d4e269a0d96 -> tool:nanobot-harness-v3:call_00_GMSyKSLhh8K8PySMNetC6363|a52260d4-d1af-4981-8b10-1723f4c126f7 -> tool:nanobot-harness-v3:call_01_aZPeAd8mWreMS8GHIboY4819|2d9463e0-6f40-4629-be01-99df02bc4001 -> tool:nanobot-harness-v3:call_02_cOu71Jh6ErWvOoqb6x1P0563|fd3f6611-eeba-4291-a24a-2be73c6bb70f -> tool:nanobot-harness-v3:call_03_qcv9KWZGcz4jrdmMlPGV2807|727b1fc5-362e-4d89-9a15-436eefd437ae -> tool:nanobot-harness-v3:call_00_u2OqlfFQNFJQ0luNH9ho1680|c6f8e565-b038-40f6-a979-f029adbd5898 -> tool:nanobot-harness-v3:call_01_Cy2LSLW4clw01lUDDwp78110|b80bab37-6fc3-4a80-a2a8-92681062deaa -> tool:nanobot-harness-v3:call_02_7jftTpfmeQw9ip3Prp9m9285|364bdb70-dee3-45f8-89d3-1b8f82a3129a -> tool:nanobot-harness-v3:call_03_T2qOMYwExGmPM8BHQnkR5570|ce292206-9a29-4d2b-a52c-400935e41e25 -> tool:nanobot-harness-v3:call_00_mEHc71Mq4i4vehhJffaO4839|489d13f4-1493-42ac-b746-f27aae82905b -> tool:nanobot-harness-v3:call_01_gRVQi6j1wsg9Z5uCftGw3456|c6fb383b-91db-4022-a1a4-d93831828d48 -> tool:nanobot-harness-v3:call_02_bbaqARQVN4yzsHqo7ebn8279|2f0fa3c3-2838-438b-9fcf-aa6d9e8409bb -> tool:nanobot-harness-v3:call_03_cY5uNnSQ7WYLnVoCLe6A1541|ba932af0-485f-4975-9b2d-02a4afbbe0ca -> tool:nanobot-harness-v3:call_00_GIziYrFiP6c5nHaY4C4r3751|5631b2e5-e1d8-450f-963b-ca113bf42c06 -> tool:nanobot-harness-v3:call_00_QV3z5rnmNVxIc1PARMAs8618|ce406200-a362-48db-a0c6-8efca2abb463 -> tool:nanobot-harness-v3:call_00_xIUmfVVyA83INLdDBquN2968|25a779e2-df8f-42b9-b32f-d51d7d6bf320 -> tool:nanobot-harness-v3:call_00_MM3pAH9TWEyjkLaE4LEL4964|1a4a65ae-2c1a-416e-bd5a-e94277ac6029 -> tool:nanobot-harness-v3:call_00_YAmfB2Ev9tLihG2AYRVK7498|378931ea-69a8-498a-b44f-41a0720e8b9a -> tool:nanobot-harness-v3:call_00_aWMjgnPWswE8PY94RTlP7106|e4ed83f5-3d7f-4ca3-859e-6e48f246b773 -> tool:nanobot-harness-v3:call_00_9O1dtTnJlfyF0OrhGSVg2041|f8619840-56f5-4f76-a571-391cd0ce080e -> tool:nanobot-harness-v3:call_00_rXWmqEGRNBfFgtWWeE3l3606|6d7b1113-8e2e-4081-b581-71e7b9bbebd8 -> tool:nanobot-harness-v3:call_00_iExokO2KYSkU42b1a1tK8431|7b0d9f48-8053-4f6e-ba25-5f36f62ee0f9 -> tool:nanobot-harness-v3:call_00_7yXoezZIKwh4p1QCpuwd3105|412ebdb6-894d-463f-b5ba-852ba686a3e7 -> tool:nanobot-harness-v3:call_00_ye5LeO7uPShr3jFBHpOD7183|5d8e64cb-a019-47f0-b7a0-273600620e59 -> tool:nanobot-harness-v3:call_00_A2hGKveGQDtaYYlNeaIe0767|48b386b8-6bb2-49b5-99f5-6c31781b021d -> tool:nanobot-harness-v3:call_00_h4xzNTuVM8ZfburRReAN5607|4c4d8a35-023b-4fe1-b806-5b64d6ec88c3 -> tool:nanobot-harness-v3:call_00_SywgVPcVRIf7De66NW000685|8673022d-0635-410f-805a-374746216d4a -> tool:nanobot-harness-v3:call_00_0l2qTWfNiKEf74WtHwvm3678|09eb74f4-bf64-4052-8e92-1e03634d93f6 -> tool:nanobot-harness-v3:call_00_CD6d6gZd8OLowq424BXP2551|cd1c2f70-e8f8-469e-93cf-d9dca760ec2e -> tool:nanobot-harness-v3:call_00_cEwfDFOIT4ah58hnsfKR0109|9dbdddbf-5819-4c8a-91ec-c6789d1be287 -> tool:nanobot-harness-v3:call_00_VgT6JOjoc8563E9f3inU7546|09474e54-ed83-4cf9-85c9-7b1c6468b067 -> tool:nanobot-harness-v3:call_00_fSmQZu1lZ59yGaIjnxam3705|1027faaf-1f25-4f32-a39b-0974ef405954 -> tool:nanobot-harness-v3:call_00_IaWcjd90aZyuZwkkcr8D9290|f4e4c28c-39e3-437c-a936-9d18cf6d1aea -> tool:nanobot-harness-v3:call_00_QSqE4SaR2x8D1pKPULJK4934|06ba75b0-cd18-4668-a869-c778d34baa2f -> tool:nanobot-harness-v3:call_00_AtirUDCnuho5gFlwf78h6369|5ed212ea-5d7d-44c4-ad6e-409b3c59405f -> tool:nanobot-harness-v3:call_00_fuioD6lZAoqA9Z22vjPe0688|d9e55556-0942-49d6-9c44-7f2d454da2cd -> tool:nanobot-harness-v3:call_00_ieETf0a4ZzuDFwC2CaaE3540|916589e3-3a8f-49fa-bc76-c1b0da6b7ea1 -> tool:nanobot-harness-v3:call_00_pZv07wOow5kMBfo9rSYR6985|d7e2ddd6-574b-4c4d-a900-4dd2b7031347 -> tool:nanobot-harness-v3:call_00_1KjuL41e1yxh5wEgC4Wv8450|7a72323e-13b5-4c40-adaa-386ad33bc777 -> tool:nanobot-harness-v3:call_00_dbzAxXdarNmuZ108lne02580|12ff070d-32b3-4d78-8f15-efba77f3efd2 -> tool:nanobot-harness-v3:call_00_BqCEp9nDa1uDpZIFNxun0686|756e18c6-bacb-48a7-bd29-abc2095f340c -> tool:nanobot-harness-v3:call_00_QdQqJddW0f3yQhxtHDpc4737|af44e044-a0aa-4828-bf87-d1159d87255f -> tool:nanobot-harness-v3:call_00_H2MIFKfjmu9my3hc77YA5413|1cde9588-7fe2-4892-9152-a6a599c5583b -> tool:nanobot-harness-v3:call_01_AmKrbESNyg9Vmj1U5ICD3556|f676accb-da2c-4776-9fbd-508fcb37fdf4 -> tool:nanobot-harness-v3:call_00_zQnWUYG1o9GdUZHuhqvO8481|1c3ea045-bf7c-4677-9e46-4090083008d6 -> tool:nanobot-harness-v3:call_00_PM01UWNwb05v8zvBe1JI4574|04679f67-a7dd-4662-9d87-1f9b13c3c6ac -> tool:nanobot-harness-v3:call_00_nvD7Ra5VV3DGHNQnaSEt8677|cd3d96ab-c236-4ee7-b137-7bcad7ebe5a5 -> tool:nanobot-harness-v3:call_00_PVohsceEcQkeSyTtjaqr5833|c721b7bb-bf69-4ef2-87c7-19a4ebd2cdcf -> tool:nanobot-harness-v3:call_00_oIQMTU26b0fyIB374Paq1079|b4cbfb34-07d6-4ad6-b4b0-8b09f001b176 -> tool:nanobot-harness-v3:call_00_Ihw0CBvhfjMHS2MtfSWT6369|76751967-9515-4b99-a425-2694916b142c -> tool:nanobot-harness-v3:call_00_NcsCr6XwNPsMWlwRNqJD1348|b50631c4-a820-4977-bec5-62bd60c95d8f -> tool:nanobot-harness-v3:call_00_Kz4YClu9RFqXVlSwD5aN2985|102701c2-624c-495c-8bad-3dcf0eaf4e31 -> tool:nanobot-harness-v3:call_00_tDfvBc69lO8l1VjPj8Np5465|a2cadcd3-faeb-4437-bcf1-f7c64fd5f282 -> tool:nanobot-harness-v3:call_00_CRnLgcih0Mfbc3nvhfuX8844|565fb468-e56f-45c8-91ce-fb287f45fc5c -> tool:nanobot-harness-v3:call_00_mWDWMR56V8r18JHg9Jnt1506|df20b9fe-89a0-4584-8b2c-cff58a9b0352 -> tool:nanobot-harness-v3:call_00_auVYW2WpcZBSBcztClnz2183|be6bb95e-afe7-4bf0-b1cf-6da1a794ea68 -> tool:nanobot-harness-v3:call_00_UlpftvNM9FVo1UtB2YyF3323|b5e45cf0-dc83-4210-a059-0319d1f59b4f -> tool:nanobot-harness-v3:call_00_ZynkrEUB9eroXDkFzNa93887|b7cce337-f723-4d7b-bd76-5ba2ddd90ff8 -> tool:nanobot-harness-v3:call_00_NzEJKYTkziCu4OMLnAmv2105|92df8bd7-4b3c-4cfc-ab2d-bc9fc40e3904 -> tool:nanobot-harness-v3:call_00_reY0YUYCvj3ee8N8O97H5880|dad5594b-04b1-4397-8858-8bbf36f405df -> tool:nanobot-harness-v3:call_00_WeYFHHc2tOXuHvHA0eZY6963|db42e517-b6cc-40dc-977b-afbaffb0976b -> tool:nanobot-harness-v3:call_00_WzbyI54gvQQX0POYiBVc0231|7f9fc0dd-d1b6-47ab-adf9-6e9b67f91fa3 -> tool:nanobot-harness-v3:call_00_6AXrUm0j4Kxdq95ZrpOZ5596|7b935fea-5895-4320-9622-b6ce7c2d7553 -> tool:nanobot-harness-v3:call_00_OMpsgSnlmnrXYzkfxwZl1482|5158b01f-823d-4966-acbc-621bdddfb158 -> tool:nanobot-harness-v3:call_00_VaRDQhBpm0OJOH1csXne4785|cd3203bb-7a37-43bc-9405-af94f921594f -> tool:nanobot-harness-v3:call_00_2FuIwOvC7TeKNrRA6gpd2883|38665d84-3d99-426f-a0b5-69e73517c41c -> tool:nanobot-harness-v3:call_00_B6nvJG87BZjcRvE6hyDN6466|431bc8a1-884c-4c7b-82d6-46060bd98704 -> tool:nanobot-harness-v3:call_00_hiNxpyXJRhtQmEcrpocM2826|b023e271-dc45-4c7f-abbe-83d9255c3151 -> tool:nanobot-harness-v3:call_00_Yr3x7J8uBzcf2TcyM1cM0318|3c473418-02c8-4324-b83a-69fc1a7f9461 -> tool:nanobot-harness-v3:call_00_pDWECEWpCkNuVeSJkm4G2802|348ff382-aef9-440c-868f-d7d691a76413 -> tool:nanobot-harness-v3:call_00_556BdNaQjBKaxFMhnIdG2660|37145db7-ce5f-48b5-be2e-cfb8cd3803af -> tool:nanobot-harness-v3:call_00_QFj57uS5wfQVKYWi1buC2652|926a037d-fc18-4f8f-92c1-25733661e4d8 -> tool:nanobot-harness-v3:call_00_fFWbuYRQL9JboMFK8vD75703|6c999a55-0747-4820-8370-78b4b9a9539f -> tool:nanobot-harness-v3:call_00_cXgIus952nRG8QVVHWm41315|a2a9ed4f-3062-42a9-a72e-437780f2580f -> tool:nanobot-harness-v3:call_00_UdbcToMnMssY57cdaOry6440|0e954624-6c85-4a92-a577-4e89d86dc023 -> tool:nanobot-harness-v3:call_00_driCRILqumJqVmWtpl8I2967|22a479a3-b945-4d95-9760-9deac0a5ab5d -> tool:nanobot-harness-v3:call_01_oTCPULitiIBRPejSEdfU2694|ecbdeda5-d803-4be6-a979-20f95dd8de7d -> tool:nanobot-harness-v3:call_00_8VhY5WoBVpgz9MYxmw9w5750|f69f32b9-7f5b-480a-9879-b171a083543c -> tool:nanobot-harness-v3:call_00_AkDIUquge4dXVMIelcGl7936|ab55ada5-7d24-4710-80aa-884626c38fd2 -> tool:nanobot-harness-v3:call_00_imDElDBGhTKnF7919ZhD1030|0ddab562-a071-4b1e-86cc-33de70c1417a -> tool:nanobot-harness-v3:call_00_xgNz3tvZzCGNpCzceBp47755|ad18b84b-59cb-42c7-98af-0299173f92de -> tool:nanobot-harness-v3:call_00_eSGEzVEewrdFJBNUlsJt5930|0e6e7504-a4fb-4ae5-b611-cf1ac314e4aa -> tool:nanobot-harness-v3:call_00_c40N04puru6x5fIiA6mO4197|c4006191-b32b-42c4-adc7-b132c3d4ddfe -> tool:nanobot-harness-v3:call_00_7O3RddwxoOEdTxyRh0g12808|2e89d688-7aed-469f-a30d-a69ec290e86d -> tool:nanobot-harness-v3:call_00_sblDidt2tFdjXV5JiRrx7422|7baefa73-41c5-48dd-a126-093d6fa9becf -> tool:nanobot-harness-v3:call_00_t87FkTKskinQLYSP17uy8797|de1c4fb3-3ef1-4ba2-911c-f18779a3b78c -> tool:nanobot-harness-v3:call_00_Z2WrmefpTs1EVOpj8f3h1027|0b4f372a-e1b6-49ec-9030-3aaed0500b28 -> tool:nanobot-harness-v3:call_00_ClohfapRhS33Z5vdlUuG5200|d723a95e-e191-448e-a091-ffa977ace720 -> tool:nanobot-harness-v3:call_00_jT6b09m1iIq08kLUspwq8194|771f617c-eb61-412f-9b5d-0b8940ccde5d
- 关键路径耗时：3.238948
- Makespan：1765.455847
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
