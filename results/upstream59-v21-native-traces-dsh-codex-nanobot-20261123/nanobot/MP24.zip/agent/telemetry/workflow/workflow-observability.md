# Workflow 可观测性报告

- Trial：`reward-v2-core6-MP24__zBfL73H__env`
- Task：`core6/MP24`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（72 节点 / 71 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：72；执行边：71（observed=0，inferred=71）
- Execution Trace Graph：`observed`；temporal_next 边 71，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_vlh0vjah6DqG0380EqNF3364 -> tool:nanobot-harness-v3:call_00_mmH7By8AEsk2aEZL4pkI2491 -> tool:nanobot-harness-v3:call_01_KDTnZ0nDqKP1uSfaUusx1430 -> tool:nanobot-harness-v3:call_02_Msrt3QVBchGciPTLqDrV3195 -> tool:nanobot-harness-v3:call_00_Rv7BM7pcwEveVwFzlr3Z4076 -> tool:nanobot-harness-v3:call_01_IClQ9ln8LB8on9V5TwV10493 -> tool:nanobot-harness-v3:call_02_qctdypdz9CohPdPKqyjH4592 -> tool:nanobot-harness-v3:call_03_PutmoYym4lJrthTNUyIH9900 -> tool:nanobot-harness-v3:call_00_RuEehIg799AfDr3qH46r4960 -> tool:nanobot-harness-v3:call_01_EF8POv7LTx5g9jWCBuVi7053 -> tool:nanobot-harness-v3:call_02_jy0ZFtjz2Skbmhl674GK3694 -> tool:nanobot-harness-v3:call_03_b2vc5r3zLjUFZZgF5yAS2227 -> tool:nanobot-harness-v3:call_04_DVEm9MAA0iT93NkJIFVO8528 -> tool:nanobot-harness-v3:call_00_9eamJ39O5L0rdBilsHJn8928 -> tool:nanobot-harness-v3:call_01_lxBWdj9nt0fA47X3NI8d3090 -> tool:nanobot-harness-v3:call_02_Kn8LcB7OsrHGblXCFXYr6733 -> tool:nanobot-harness-v3:call_03_gYjtz3PZD97vdTZRInjn0100 -> tool:nanobot-harness-v3:call_04_esAPi72NQoDUieUemvdF6824 -> tool:nanobot-harness-v3:call_00_EbAfSUnlekwcsD2VG1AI8377 -> tool:nanobot-harness-v3:call_01_DSCH6LIZjd6msfHNH2P56178 -> tool:nanobot-harness-v3:call_02_1uC1gP8kWcBR9NGtgeZ55289 -> tool:nanobot-harness-v3:call_03_5n8TpHl48xxkSgMHO9Bl0131 -> tool:nanobot-harness-v3:call_04_RrxfweZHu25Fv0z6ZAU81263 -> tool:nanobot-harness-v3:call_00_AejUCwVIZuKSxSwdKxCJ2373 -> tool:nanobot-harness-v3:call_01_AGpce9p5oDNtikgAjDmj4476 -> tool:nanobot-harness-v3:call_02_JSBCz7rVbstXQjqX4jqE3054 -> tool:nanobot-harness-v3:call_03_MFAxnhWWREIWGLkQ9gNq7699 -> tool:nanobot-harness-v3:call_04_TvQN66wXa4Dqc4n3Cbzc2868 -> tool:nanobot-harness-v3:call_00_iNJBS4wRjYmB6r6lorho9227 -> tool:nanobot-harness-v3:call_01_oFDtMdBWCGUANiMsKCCx4871 -> tool:nanobot-harness-v3:call_02_Z4qAtUK46J1fKXqisuI55105 -> tool:nanobot-harness-v3:call_03_WKkG7NOTk3xvRq7XfEW56388 -> tool:nanobot-harness-v3:call_04_AbZRWOd7tOYRrUPyxivw1571 -> tool:nanobot-harness-v3:call_00_zXpcwoA3JwqMQQY72fcW6853 -> tool:nanobot-harness-v3:call_00_1hRtobOibhqrDM64zFof7482 -> tool:nanobot-harness-v3:call_01_m92LH4WadibtEAvAOgox4478 -> tool:nanobot-harness-v3:call_00_7pGabMZM51qJ3TuYDbUR0642 -> tool:nanobot-harness-v3:call_01_MgYvg26MTZXJdTWHuFk59232 -> tool:nanobot-harness-v3:call_02_vqMvCfBBIw28R5DBHr677215 -> tool:nanobot-harness-v3:call_03_VKWf0FlOKg72Btqvw4YZ8289 -> tool:nanobot-harness-v3:call_00_D2qupB6Wm8fKz9q1P8xP6030 -> tool:nanobot-harness-v3:call_00_zOFeTaDcQkVxQahYgAZO5383 -> tool:nanobot-harness-v3:call_00_c5RaUAHUYq4sHK2Frx6C4501 -> tool:nanobot-harness-v3:call_00_0sV0soXqhyIIyKvlKcti5434 -> tool:nanobot-harness-v3:call_00_hNAIDfjFNOEnvvfpwZ6V9148 -> tool:nanobot-harness-v3:call_01_8PcxdiHIUFPcdXh4nzvS4942 -> tool:nanobot-harness-v3:call_02_MCUHWiBwHs4CYgTiU39h2279 -> tool:nanobot-harness-v3:call_03_wvG7yde2NmCGIQcVogNO6721 -> tool:nanobot-harness-v3:call_00_dncl9JycrW67cVQU2VG46782 -> tool:nanobot-harness-v3:call_00_i8BGo3X39TOm4edhSPNW9566 -> tool:nanobot-harness-v3:call_00_NXANlDDVUbNumJm5FnCS2380 -> tool:nanobot-harness-v3:call_00_jb0n41yr1jPpHi5NPKXK7209 -> tool:nanobot-harness-v3:call_00_5QbnDqGDSUP1zVnDault8420 -> tool:nanobot-harness-v3:call_00_bcBQ0Pq1jEC54LFkkeNd2750 -> tool:nanobot-harness-v3:call_00_goGGjqY51CpLIy0KzVbd6877 -> tool:nanobot-harness-v3:call_00_6YeevxBU3TpoWbry5VRr1514 -> tool:nanobot-harness-v3:call_00_K2tQqTszoTPm9FPqe8xD6380 -> tool:nanobot-harness-v3:call_00_gdYfCsF5fEJdt0uoS7FK2401 -> tool:nanobot-harness-v3:call_00_w5LwvviThu6pm6KsuyzX7427 -> tool:nanobot-harness-v3:call_00_Z2HUrVHbaObPq5UP1Cip7808 -> tool:nanobot-harness-v3:call_00_b1brTmvH4icArzxyM1Wj2252 -> tool:nanobot-harness-v3:call_00_A07Xmyi6JfzYS800ZUWT1479 -> tool:nanobot-harness-v3:call_00_AKOSxxgZgBLBGYZ8MtJE0660 -> tool:nanobot-harness-v3:call_00_Pa0YkIuysSCxApvq56gF7685 -> tool:nanobot-harness-v3:call_00_S8gTtVPEGohgbIq98wZL8731 -> tool:nanobot-harness-v3:call_00_BSHSfanNQWi74Ne3jZCt7442 -> tool:nanobot-harness-v3:call_00_c7WquzY8M6nKriua3glB6070 -> tool:nanobot-harness-v3:call_00_g2LG4xbX4n7pDlpKaEvd5070 -> tool:nanobot-harness-v3:call_00_fAM7fzL5NUC5stqLxRkb6622 -> tool:nanobot-harness-v3:call_00_lHOr8XYqWPWfGSwX6m0G9997 -> tool:nanobot-harness-v3:call_00_65ewHSIRmx2EmyukeZlG7095
- 关键路径耗时：1.011948
- Makespan：350.505765
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
