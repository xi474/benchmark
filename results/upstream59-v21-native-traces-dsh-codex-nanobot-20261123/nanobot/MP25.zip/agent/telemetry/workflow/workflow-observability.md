# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP25__hZeWDR3__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（103 节点 / 102 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：103；执行边：102（observed=0，inferred=102）
- Execution Trace Graph：`observed`；temporal_next 边 102，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_lg4HGQPwvwuKXEvu841N5988|ad89075d-c3fa-470d-b9bf-b1a41f3159eb -> tool:nanobot-harness-v3:call_00_rPh4bBfIhGviv6Itgm875994|93b3eff2-de83-4330-9ddb-1c12532ccc95 -> tool:nanobot-harness-v3:call_01_xGBI26vOGfRTsmcWGkTs4149|c8460cd9-a844-47f3-9d79-97c88abdfcc3 -> tool:nanobot-harness-v3:call_02_MEI9AG6Dwann7VjPEGQ57335|21bb657a-f3f9-4d8d-a2e6-848a08577a9d -> tool:nanobot-harness-v3:call_03_D4eGTQwVKFuHOiuy3xav4098|d9c0fcf0-590b-4dd0-b988-bc7a152c1de5 -> tool:nanobot-harness-v3:call_00_ApMR3q1CofYM7Uq2OM002592|61aa79f4-a6af-4efb-aa84-21f8c669fc62 -> tool:nanobot-harness-v3:call_01_txW3E6TNDqp2MCUozQfg5862|ec160326-6257-46c3-a2f8-0f0405538e13 -> tool:nanobot-harness-v3:call_02_gNhnWAtMelgkQRKx1Nzo6205|662b86b0-8061-43f1-b5c8-e1327e950efb -> tool:nanobot-harness-v3:call_00_gUiglLoX3LYmTZVJ2xvH9348|06d4ca17-2ed5-4d83-a814-990efe35c290 -> tool:nanobot-harness-v3:call_01_x8yVu1IfJevazn5R0J1B9320|3fcb6ac0-c472-42d4-bb61-2986f98ad949 -> tool:nanobot-harness-v3:call_02_rk3cSeWCNZcHsVP8L7zd7000|be11517d-950c-4319-9f52-fea59669b6ca -> tool:nanobot-harness-v3:call_03_FOhhBqM99p6nREcAOUMC6688|c52b6f0b-db59-4928-b0fc-32bc00a1e449 -> tool:nanobot-harness-v3:call_04_pxFPb0rv9TPfZnCI5i6L7593|730c55f4-e7a9-42ea-a44f-e82d6ecf3ffe -> tool:nanobot-harness-v3:call_00_BqRcyifibwbXhngBEsds7509|2759a0a9-9549-448a-a393-58f0bacb5b2a -> tool:nanobot-harness-v3:call_01_UTsvhZmlGTVxmNeo5m8Q0860|f845f32d-3900-4fc8-911d-046a7b1c1081 -> tool:nanobot-harness-v3:call_02_EEXWK2WuhnQug5VeG9y39562|a5bc78f9-0a39-4fe4-84e9-8a7cca1a44a1 -> tool:nanobot-harness-v3:call_03_O6kmeUBRRR961p71pPXn9557|7d02a9fa-3cbb-437c-9067-7319bc5f1d81 -> tool:nanobot-harness-v3:call_04_voONqsaH4fBwpAnr6XbR6607|b6df2f82-3b95-40d7-831f-69ae4e35c9b4 -> tool:nanobot-harness-v3:call_00_StBwQuPbmBt3QY24qTCp8030|25283c45-8b6a-493b-a560-e641c1c1b5a4 -> tool:nanobot-harness-v3:call_01_9HzHj9XDKbwUzggiqdaX2164|4ea2fad9-8937-452a-842c-50281ab4f6fd -> tool:nanobot-harness-v3:call_02_jBNiXWfjar7flcw7DClO0611|e2d8b66f-9647-4507-9fbd-cc01eb9b5cce -> tool:nanobot-harness-v3:call_03_gBQ2HN2xhuk1OAc7Nl4F4222|43fe94e8-8c93-45f3-85be-ef0fd5824871 -> tool:nanobot-harness-v3:call_04_yT8MjW1nRPYKJ929oH867432|c59dfb49-ad45-40a4-b95c-ad480866f1f1 -> tool:nanobot-harness-v3:call_00_mN6DQOO22DNsnSjWeZ3T9744|2af06fb9-18c6-4daa-ba9a-30499317e65b -> tool:nanobot-harness-v3:call_01_rmJqLH5kF9nxksDdYu6G2335|b5af3ea6-aedf-4a85-856c-178345b32643 -> tool:nanobot-harness-v3:call_02_QmadKur7pHDNpIa3orxU4030|eaac1aa3-5d07-48a9-b01a-f018912430e9 -> tool:nanobot-harness-v3:call_03_gpKl65WIxW2eob5Iigdx5733|b1186750-c87a-4797-b169-14b64d978c8d -> tool:nanobot-harness-v3:call_04_rWGMqJ5jGjjwPkprtb0i5351|1236832b-e15b-44ec-ab3f-81b2c415e12a -> tool:nanobot-harness-v3:call_00_fhIu4aYJsZjReuU9kRkf2998|89e1f9c1-3891-43cd-966a-d2620972bc5a -> tool:nanobot-harness-v3:call_01_sbOmlrv169zDQrZg4ye84551|37dcda95-6360-4e5a-8b22-3e336f0093e9 -> tool:nanobot-harness-v3:call_02_Evke3ibdnsoCkbOwlZjO2345|e7641dae-9b4c-4ef9-8d11-4867a33bfbe1 -> tool:nanobot-harness-v3:call_03_HsA1n8YmKCPtlcnLQqv01569|39b18feb-1584-40ad-945a-1df57f4cb2c9 -> tool:nanobot-harness-v3:call_00_qpXE0mGUoMSugefD8MsY6909|a4c8a1fa-f9c7-4781-ad27-4c231b7b84ac -> tool:nanobot-harness-v3:call_01_sEUWPmsr3kwmdmNfpX7l2772|d74b0e3a-cd6d-4d01-adce-de335e454208 -> tool:nanobot-harness-v3:call_00_ZhSUW8HlkGYPNh5INRoi4481|77b00cdb-4b66-41ca-b798-e07497c03aa8 -> tool:nanobot-harness-v3:call_00_ZPQDncq0hDlB8ZDv9b2B1128|4d8d3022-d261-4b1a-8ee1-fb3aa2595907 -> tool:nanobot-harness-v3:call_00_1tdByA34JTlctKTRq7ll2531|2d457e8f-6296-4b6c-a2c4-d6462b5260c8 -> tool:nanobot-harness-v3:call_01_3mJTy9v232CCpWyqzKks6391|b7f1e766-fce1-48b5-ab93-c23028b9b729 -> tool:nanobot-harness-v3:call_00_dBssOoCcKRpyWlhJPS804673|a9824037-1f43-431a-bbdd-fc054130033a -> tool:nanobot-harness-v3:call_00_K8FASA4fCxFkhwr1WWFY0809|853e3f4c-9967-4b4d-b882-7efce03d8f91 -> tool:nanobot-harness-v3:call_00_rV1UVbKHuyRdGveZuGbc6549|59c8d5d2-81b7-4162-ba19-54678c80c97b -> tool:nanobot-harness-v3:call_00_lZMzlUCUSWhwvb1WqMsM5067|5a958eef-6296-4235-a57a-9482c2dfafe2 -> tool:nanobot-harness-v3:call_01_3tjrpfDhE2iahuaWAZgQ6839|d2f888f6-162c-408b-bf49-2be068ba14c5 -> tool:nanobot-harness-v3:call_02_x0xTEDYHIwCE6rwMM1Vs6263|b230641f-5fbb-46df-9180-6e0edf6dbd59 -> tool:nanobot-harness-v3:call_00_zI2Ax9ipi2WYbJ6nbjA99664|28a7f5f9-d2ff-4f4c-8586-c985d86fb823 -> tool:nanobot-harness-v3:call_00_8EesLOkVKxdyAd6U4itD1564|27cb5f97-4317-4ddb-92a3-65a98801ea57 -> tool:nanobot-harness-v3:call_00_BjMzHzSW2KE2Xtam15HV2971|e50f7a1a-d423-468f-a372-9e9628de60f7 -> tool:nanobot-harness-v3:call_00_ccwg5ERqcGKt2OPcgBil7884|dd2f6fcb-0627-4aa6-ac42-8f9ab142f5c2 -> tool:nanobot-harness-v3:call_00_LL1HIoBLctI6w1ETxaky8908|78a81cfd-3b28-46a8-8ad5-0fd89335d998 -> tool:nanobot-harness-v3:call_00_ZCZqcG8qBbgE4KmLD3xi7304|a9cbccca-820c-4dc6-9e92-0484712d3832 -> tool:nanobot-harness-v3:call_00_PQedJjOVd8RSBeCVL6Ye9869|d5312e42-6ce8-4d42-92fe-0da11830ad63 -> tool:nanobot-harness-v3:call_00_OAeWqL0uZ0WSp2ksVlik5575|80aa9b79-e8e2-48e2-8611-b19c3f518273 -> tool:nanobot-harness-v3:call_00_miL4zDX1WyYv3mTXLxuf5519|fcfd66f4-b110-47dd-95bf-63afa084cd3a -> tool:nanobot-harness-v3:call_00_xqhe3v2fDw9vY7iqfuzs8544|5300a11f-792b-48e3-aa7a-b834c8f9eca3 -> tool:nanobot-harness-v3:call_00_e7rZQMqdiP1KYnD9B2xT9151|09066afb-a784-433b-aa77-0264a221a042 -> tool:nanobot-harness-v3:call_00_TJLVU5ZkCtsj9V9BO45x4002|af81f145-2f0e-40b0-b931-3cc3b5acace1 -> tool:nanobot-harness-v3:call_00_JumFhluTz6mk1N7NivDb1295|2875cf5f-70fe-4c4d-a377-5b9521b62f12 -> tool:nanobot-harness-v3:call_00_5z4Q27QgudZfu2SaG3jJ7168|00c82a41-6f37-4dca-8b2d-a435b887c4bb -> tool:nanobot-harness-v3:call_00_o7t59mJ4L12Zlg5T288F0494|fac80e48-68e4-4b6a-9e4a-763bb9a1d181 -> tool:nanobot-harness-v3:call_00_P30BGsOaUvAVnYGaO7kj0740|40a6bddb-cc2c-4ab6-afc1-cf61511f0bd2 -> tool:nanobot-harness-v3:call_00_6Z0kmwJcL0FXG5Ub4b1R9740|78f8c758-8c60-4700-bd1d-f3eaf9ae37c6 -> tool:nanobot-harness-v3:call_00_31KRQbEXxClkXIrMaS9l9066|42cc308b-6319-4740-b498-3ea8e7a2be22 -> tool:nanobot-harness-v3:call_00_KfQnVDUd5ND1OTaBi2lL7319|3edd1635-5936-4903-b526-2a24921ec1a3 -> tool:nanobot-harness-v3:call_00_Ndworp6CF3CFCiCjK8Wt2344|13ef85d9-ac3f-4468-8440-4838a06c1344 -> tool:nanobot-harness-v3:call_01_UFGVqNNw4QsPhbR6pLXf3168|b66585e6-66fa-49b3-bdaa-844e9180c865 -> tool:nanobot-harness-v3:call_02_IZcMuAfgaKnIsPyQOMNz3357|4f76c933-9851-4935-a5ab-a5a9fe91a03d -> tool:nanobot-harness-v3:call_00_N8LbB05wNjLejiYNtiwZ3553|16a1eb70-2533-461b-8f09-d48112b7a761 -> tool:nanobot-harness-v3:call_00_e7SXgVY9fikmo2zBtM3W5041|1a616dce-fc52-46c2-913d-619c13c96183 -> tool:nanobot-harness-v3:call_00_a81oTEOeGlBeOF9dJVHN8477|85e9f02d-40f2-4b55-bdc9-db255772a1b7 -> tool:nanobot-harness-v3:call_00_poBYaXk2ioJV2NqdTLeh4218|34110e78-083d-4365-8827-85dc621a2934 -> tool:nanobot-harness-v3:call_00_n8AW3P9aHW6jVNujPCk19259|38d01702-4f77-43fa-8893-a02de5e86b00 -> tool:nanobot-harness-v3:call_00_Dmxc7CBcUtRw0FOUShAR4805|837ae8fb-ec1d-4a65-8c6f-167598d9e343 -> tool:nanobot-harness-v3:call_00_58vgcMiGho0UNGx7RBTZ6833|218e0ef9-10f6-4094-badd-c98c2cac94eb -> tool:nanobot-harness-v3:call_00_aDbgO1FTNimq2KlK5NhE3093|3618d7b2-bc43-4cd0-a2c0-0ff896abc75e -> tool:nanobot-harness-v3:call_00_V4OaM1qC5c0DIAI2J98e9788|e6290b6d-2e1f-4dec-b646-cd6a83c272d7 -> tool:nanobot-harness-v3:call_00_7Gwevfr8NasSTqNUtWBs0329|ad49d75d-4b73-4d6b-bfc6-99ddb92c6eef -> tool:nanobot-harness-v3:call_00_Q2M7v2XdrugBDkkwhuB81298|ece66fa9-64ff-443a-bd7e-8efe38d27b88 -> tool:nanobot-harness-v3:call_00_QiTf8ODrioiyptXRu3KL0414|5c83c05e-70c8-40ec-8a51-fa6513df8145 -> tool:nanobot-harness-v3:call_00_JTdVxQknmGUHfzdvijif5381|f0d5189d-ff70-4e2b-8813-84ee38dc4307 -> tool:nanobot-harness-v3:call_00_hon5xRvRIZwYAqkLCK6F5407|729125f2-1b13-4a56-a600-32add1070ebe -> tool:nanobot-harness-v3:call_00_nGe2nTGQ789xxPz2a3Ep5394|79393c2a-75ec-42cf-9cc9-d86b09ddf2b4 -> tool:nanobot-harness-v3:call_00_5d92N1qfQfWueI8UM1qu0182|4e65351b-7b94-4c53-a672-4410abf3790f -> tool:nanobot-harness-v3:call_00_eUfTfuipmqq2ChcgpuRJ2808|64b824b6-8245-4863-bee2-26d0734c44c7 -> tool:nanobot-harness-v3:call_00_6Bp3GYAkr4ehZakPgqfm0177|d472d8ed-b22b-4d44-88da-5c65bf1f95a8 -> tool:nanobot-harness-v3:call_00_e08vyT1stmqJUEiiecaP0488|eaa692d1-569e-41b7-a1df-22e44b059c57 -> tool:nanobot-harness-v3:call_00_ad95a90ZgDf4EyyDgAY79848|fcd9d929-06aa-4265-b122-812848126a2b -> tool:nanobot-harness-v3:call_00_v6I3GA35JfpMxpVFdA0V8712|2a1a5e2e-4dfe-48b1-9e5b-8a6cfca34158 -> tool:nanobot-harness-v3:call_00_mWJg8RUExu3VBzF6yw8V2309|bd01ef38-b827-4580-b966-5e1dae051a30 -> tool:nanobot-harness-v3:call_00_0iRpuG7Px1Gs4sP7QMkL0154|3697c473-4650-4010-8f3c-e9cd8e065920 -> tool:nanobot-harness-v3:call_00_4OJgSwqbLfNJdmAyTr4i9213|2bbce72f-9dd9-4770-9e44-7fccac10d552 -> tool:nanobot-harness-v3:call_00_LFNzIrMarzW9S07xSJWq0184|2440efa9-1e1c-4faa-b310-2ad95606bbcb -> tool:nanobot-harness-v3:call_00_SmZefaboHS7OlxFvXHgW8740|40b4abdf-beee-4e66-88f7-29dc6fb903b1 -> tool:nanobot-harness-v3:call_00_j9GOUB9Ak48yrmEO5yFU4784|ff3073e2-16b4-49ac-bf9f-a5c663737574 -> tool:nanobot-harness-v3:call_00_E5PSFFZ539qZhlASyeJd4898|d51ce3ad-28ca-4292-a92d-25bf527ce892 -> tool:nanobot-harness-v3:call_00_a1nJZSO12sOuWHFGOqTG8060|d4f3cd9a-74e3-445c-b3f5-cbfc8ff319d9 -> tool:nanobot-harness-v3:call_00_LMT9GOuFI15CQQr7VXbU8924|77bcadda-81df-4914-8f5c-fdc7b1fad985 -> tool:nanobot-harness-v3:call_01_G68n1YG2xYes33TlM6f56426|f80ad130-696e-42cd-a5b4-2a812890dea1 -> tool:nanobot-harness-v3:call_00_wp0xDaeTHCgdWtb59BDA8012|1c967eba-0960-4e77-a07f-a1b4de8702f7 -> tool:nanobot-harness-v3:call_00_WuM5JWw4NdukbcJR8Xd83775|1479054b-23c2-4294-bade-eefdbf55c8bf -> tool:nanobot-harness-v3:call_00_nWGrhJQsKcTAE2CIxcB00082|165623b5-93b1-4576-af87-f85bda0f2b8f -> tool:nanobot-harness-v3:call_00_fTeZ7NkWDL9ilqdugdnY5757|1d7074be-364d-4ae5-8731-5314a47f094e -> tool:nanobot-harness-v3:call_00_CGzrTygrVwxcdj974xYj3122|fc43fc9a-4fef-4e00-a06d-60b4cb30b69e
- 关键路径耗时：2.763141
- Makespan：1112.817451
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
