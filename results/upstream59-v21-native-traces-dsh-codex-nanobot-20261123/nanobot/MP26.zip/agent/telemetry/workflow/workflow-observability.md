# Workflow 可观测性报告

- Trial：`reward-v2-medium-MP26__MFbHQQW__env`
- Task：`nanobot-config`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（86 节点 / 85 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：86；执行边：85（observed=0，inferred=85）
- Execution Trace Graph：`observed`；temporal_next 边 85，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_q2Q3KtVX207rqxkgOzEv8236|283b5b9c-6651-41c3-b3e0-4c41f35042e4 -> tool:nanobot-harness-v3:call_00_Xuwg5al39OqTCrmjFKCn7565|8593f403-8eab-468a-b00e-a5b4942fe80f -> tool:nanobot-harness-v3:call_01_PW2At5JyeJB5smXO83oB9779|cf169277-d6cc-4e5d-be8e-4dc68a8f2ffe -> tool:nanobot-harness-v3:call_02_UTQ73oFY7E5SIOSEkmAZ9813|fb1bfb3b-cfee-4043-866e-38410b6b2f8a -> tool:nanobot-harness-v3:call_00_kntYx8bI8w0vOqSSv5JC4358|fd420aa3-9fa9-4d18-9bc4-01607ac3ff26 -> tool:nanobot-harness-v3:call_01_mu9yI7ilv9xHl92SWslY0360|bd9364c2-a5d6-4446-b0ac-0222c3bb79f6 -> tool:nanobot-harness-v3:call_02_7N1aT40j3Pf6lBudE3Y33833|cf4e484d-0489-48bf-97a6-055cffdfd502 -> tool:nanobot-harness-v3:call_03_q0IH3g8grdJcJFBMFSix7770|7efd45ff-8c37-49f6-b5af-f16719bb1322 -> tool:nanobot-harness-v3:call_04_EymhhXeq6PbO5PTKIYH37067|a7abe1ee-bc49-459c-88c4-56ac79516be7 -> tool:nanobot-harness-v3:call_00_GAqxGtudxt4rG52hqCRw0060|55d0bf8e-98e0-4f7c-a524-45c3b418dad8 -> tool:nanobot-harness-v3:call_01_VSTNyPLErmLzzIoa4CTT1956|62df23e1-7750-44e5-8676-e3df235411a1 -> tool:nanobot-harness-v3:call_02_bUzraR1QCVoewTiaPFR55596|dd13eb88-87e4-45ca-8c7a-d586d2804251 -> tool:nanobot-harness-v3:call_03_iFMGgEqXwxN99UPc73o62019|beaa43e2-65a2-4be6-9acd-4ddab28aacbc -> tool:nanobot-harness-v3:call_04_h9pyL31Sn3GT9B1NteGh6613|941219dc-6052-4af3-a1cc-abd01185d762 -> tool:nanobot-harness-v3:call_00_11Jg0DPKVhbGehIzDV1j7684|a9e3478d-39bf-4332-bd82-1691247c69e3 -> tool:nanobot-harness-v3:call_01_hteztYrznxO3s4DJRx4d5826|bf1758c8-0679-45b2-9371-ff5830c2f196 -> tool:nanobot-harness-v3:call_02_SYSxFIKm0Z2QfsBPeGuQ6945|b6d1556c-4874-4b84-b09f-fba2618aa732 -> tool:nanobot-harness-v3:call_03_fE33ySAYio8TMHXBNW2y2104|a7a4d6ab-39d0-49d3-b662-74c326cef738 -> tool:nanobot-harness-v3:call_00_nnQSIiPpuc7HhadwBdXo6109|7e09a77a-e68a-497c-ba9a-af91f31be20c -> tool:nanobot-harness-v3:call_01_kEoBEeRxfHw2bnwmCNxJ2456|6189d8ab-b4fd-4158-86e6-e079b75b4c0e -> tool:nanobot-harness-v3:call_02_oXTg2lhhlrQNbAz6QQ9X3185|898566d3-d04b-4471-9939-8f673e2ef6ac -> tool:nanobot-harness-v3:call_03_MAnepokwxEHGO2cFBVPU2988|eb696d0a-c56a-4168-b6f9-9a44910c0c83 -> tool:nanobot-harness-v3:call_04_oHBAfEFthzwGd828ar9g8205|89f2e26d-632f-45eb-a75a-f5af33a3ebc1 -> tool:nanobot-harness-v3:call_00_GLQEpStEgLFPfJtWr7mc3599|d3e3558a-ba4d-4f3a-8ed8-87f874e552e1 -> tool:nanobot-harness-v3:call_01_A5h9vRDA0T1uyGyyL9ue0782|42260309-b2a9-4a09-9838-7b293461af94 -> tool:nanobot-harness-v3:call_02_YpZfWyN6O5nTyTESIRo27809|399af377-269e-45aa-978b-9512d5a8b961 -> tool:nanobot-harness-v3:call_03_uMgKr3yKuu5QghvKUAzp3894|0f673a92-3954-4ea1-a27e-53999ed71669 -> tool:nanobot-harness-v3:call_00_Sotjh325FWtfhR0I0kdw0657|d4b57804-69ed-4ac4-b9f4-b21244f12930 -> tool:nanobot-harness-v3:call_01_rbRGtM65Vey6la6KqnmS3162|c132515f-4bfc-49eb-a6a9-24390032211e -> tool:nanobot-harness-v3:call_02_vO5oQ4jUqf823e6HKQ5t1437|cefc41c1-aa2c-48b4-a96c-5bb37dc8e96f -> tool:nanobot-harness-v3:call_03_S3X2OHzIuaRFetP7LTWr0861|7dcf058f-c507-4668-a3d7-e72a70316cb7 -> tool:nanobot-harness-v3:call_04_SMRlel8HKy5NbYXP9R5o7799|ce912d55-4a4e-4c8e-aec4-c77403efe412 -> tool:nanobot-harness-v3:call_05_OVTxP8CbkYTh8tOP7AyZ4877|f8ac81b9-3399-4cd8-b11c-ba1a573b46e9 -> tool:nanobot-harness-v3:call_06_3b4b0aYE8tVCGnZb8FCr4895|ad2186ca-325a-4a63-a920-aa670f361f77 -> tool:nanobot-harness-v3:call_07_q9fvFsZJIzt8mywhbC135187|c7ae3d0d-fd83-4943-9d79-9a2bc2d225b3 -> tool:nanobot-harness-v3:call_08_2obm0lkRq0AxFEGfmJ0Z6027|b23350af-7f3b-409e-973e-194806264e4a -> tool:nanobot-harness-v3:call_00_0YToRLxAyKlkDtGm8e5m8078|c6debcc1-2492-486d-8f7a-b0c795ee5b9d -> tool:nanobot-harness-v3:call_01_Dow9Cs9qVryVlxMRerQv6955|5c2e33dd-1073-4e17-8f98-3f1fdf2a723e -> tool:nanobot-harness-v3:call_02_tVMPyy5CHHrFpFH57wz43837|daf91836-3637-4448-8bfa-b0c78eed6a72 -> tool:nanobot-harness-v3:call_03_PFIuOEmtyjZJJsv3IQti6311|aa6e001b-f1e8-4789-b2ed-329a0a54ef7e -> tool:nanobot-harness-v3:call_00_PMzhCJQvcrdLWVha0tLK8731|8318806d-46df-4279-aa53-c17af6d2467f -> tool:nanobot-harness-v3:call_01_51IIINt1WqdtkceCptHY2055|40e3f555-9f60-433a-bcbe-a3d06d0ccfcb -> tool:nanobot-harness-v3:call_00_ridRa9CivwEtH5EyC6h27773|677546c8-2acb-4df6-84a2-27d5d35c2bd6 -> tool:nanobot-harness-v3:call_00_wuxlwsJ4OxJqIBTqpMpz5827|1e88c3e3-7219-4ea4-a175-34fecc67e6e0 -> tool:nanobot-harness-v3:call_00_czVi0yktIozrpio4IMAs8036|a11b378b-2839-4007-8e0f-9193ddd8b3af -> tool:nanobot-harness-v3:call_00_oUiFeeIPDdAM0HCXboiy6863|10da57cb-fb3b-46d5-9d77-c6755db241f2 -> tool:nanobot-harness-v3:call_00_Cwa7bu3Eau24DUWdC1q45163|4ec9ea3d-c018-4a4f-aa07-fa76f1eb198f -> tool:nanobot-harness-v3:call_00_wOxs02HTA2omoIVIp5jj2820|3b0f7766-4d6f-41c2-89af-027352a0ae63 -> tool:nanobot-harness-v3:call_00_0UqihgmCDiCzuWFmGNaF5488|9704f4dd-154a-40bc-8bfe-13267304365e -> tool:nanobot-harness-v3:call_00_d2ehC3T875GRAnYnc5iN9287|8a472d50-d7e4-483a-a372-78fa4ce5126c -> tool:nanobot-harness-v3:call_00_NzVatSznClTXx14Q62To8437|b5d7704d-5cd3-4077-9cf7-a19bb1a75c45 -> tool:nanobot-harness-v3:call_00_991vFJUqjnLUcVEzm2rU9709|17c7097c-a236-4bfe-8f8b-9a5e3d1bbfdd -> tool:nanobot-harness-v3:call_00_hGakcWogo94UzlMZONMB4774|78519dfe-bb87-4490-a1b2-48e5c2f4d2aa -> tool:nanobot-harness-v3:call_00_Steq4aVC7eI8D9exIXum0689|658cc179-104f-45bc-8555-bf3020e11028 -> tool:nanobot-harness-v3:call_00_ptimxLLvTsawL0UJ21L76077|e0547334-97aa-48ed-a979-e215f481cd29 -> tool:nanobot-harness-v3:call_00_8eQyGgBcetTfLJKeSIzZ2781|51944092-6074-4bae-858d-b63c0b53560b -> tool:nanobot-harness-v3:call_00_8ocmFW1j3gTodYM6B48j1798|9d916e38-1ba7-4722-9ba4-2b7623b32fcb -> tool:nanobot-harness-v3:call_00_WsvPA8vQp5yo15mfWbgt8609|51e2531c-bc50-455a-933e-3b607c4aed2f -> tool:nanobot-harness-v3:call_00_65X1jPNHlfFYjrb7JXxT5554|a0e39963-c527-47da-8147-bc211a8a1378 -> tool:nanobot-harness-v3:call_00_pRAD6QoITKPzQtsNqfw22073|02f02f40-a56c-4b85-ae7b-404f29d5313f -> tool:nanobot-harness-v3:call_00_ZjJjnCkWZVBcQTmGXl9K5921|29665b29-76c0-491e-8ef0-f947ade4f055 -> tool:nanobot-harness-v3:call_00_SHcPPk3hu95O1JDuWl3k7566|e82a82e0-a469-4d17-a181-12cdb9984bb9 -> tool:nanobot-harness-v3:call_00_RbjQOYrXTFhTcGV8G1bh1790|9d9b47c6-4850-4db3-be1a-83d832f15fb9 -> tool:nanobot-harness-v3:call_00_y5f7MsHsk7wqOgaQEa6G0113|08d004f6-3f64-4f27-9d26-1a9852bbf1a3 -> tool:nanobot-harness-v3:call_00_PXjgbLksFrWaF6Vq5zDU6170|6ae24865-ad72-4c84-8542-ebe7e81f06b6 -> tool:nanobot-harness-v3:call_00_0S2NfeebYI0glrd1RDKy3413|5df2a45c-9899-4cf2-919c-16e0ba960e44 -> tool:nanobot-harness-v3:call_00_2bVP0IzKQhs4hzz3jCkP3742|554c2ffc-5603-4333-a99a-e8dcaf212194 -> tool:nanobot-harness-v3:call_00_RTp2g2mCCrxEdtxGImr93694|21841738-e981-4e26-925e-067d56fab9a9 -> tool:nanobot-harness-v3:call_00_vqC72KWW8QP0GgUNDPWn6738|e048ca25-daa1-41fb-885f-5e58ac2ba999 -> tool:nanobot-harness-v3:call_00_XWsY9KVFOL0foSYdmr9z1445|5f275844-0ffe-4b05-803f-13dfd819e87c -> tool:nanobot-harness-v3:call_00_6yve2bOGvsdgUSn8JsNz6699|6fbc766a-4d4f-4f09-ad12-f537cb1e311c -> tool:nanobot-harness-v3:call_00_ZkQX6ujY2T0eVWifke6o4904|3ef469d1-2639-4bf0-bc1d-4aefc0f5fc38 -> tool:nanobot-harness-v3:call_00_Qv3KbhqAel5xXRnMeyER2179|f179c115-4c37-4b60-942d-bd23aa349df7 -> tool:nanobot-harness-v3:call_00_dXkye2ar8XmzBn9FQ37r6612|17d8e458-5b2b-43cb-a0ef-f632f411ae17 -> tool:nanobot-harness-v3:call_00_SAOszlCh3j8nnqghspwh0520|3f2d2b95-b697-49dd-b525-689a4752a694 -> tool:nanobot-harness-v3:call_00_XRPeKCyBm3ZK4kwCqwLa9660|1775ed75-42ac-456b-976d-012747f032b3 -> tool:nanobot-harness-v3:call_00_aLa6AAb6oIGYizkY2iBq0065|fdd7f1da-0e77-4630-b0df-ab07cb21bc54 -> tool:nanobot-harness-v3:call_00_nPv4f4PZvm1WRl6nzF3A3945|022655ff-6446-4862-8826-edf23c045d59 -> tool:nanobot-harness-v3:call_00_jA4uBXMpmFcp134gerTm2086|e7cc0d74-2dd1-4656-97ae-3996b7a9e48a -> tool:nanobot-harness-v3:call_00_SNVjyVPBg77DfrCrFdyQ9591|0473b256-5ac3-4049-9e66-c03769b6a541 -> tool:nanobot-harness-v3:call_00_On64PIvbFaCUr3qR7UbM1170|05e59d14-5ae9-4cd1-9469-d3b3c4f44c17 -> tool:nanobot-harness-v3:call_00_gErZZiiyuY8W9ulIIlrr3065|207efa6a-39b5-418b-b01e-cdf6ebced808 -> tool:nanobot-harness-v3:call_00_jKoVZDITPocm7bxcz9x37562|8faa136a-8d4c-42db-aa09-6cdcad2ea972 -> tool:nanobot-harness-v3:call_00_dIHWdpRtYIE5nbUtWMmx2786|eebaeda7-e6c2-4cad-b80c-65ee10044dd6 -> tool:nanobot-harness-v3:call_00_re6Q8jKRNy2c2l7RWunU5483|773e0a33-a65d-40e9-9be5-72b796ccbce1
- 关键路径耗时：1.391889
- Makespan：965.787417
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
