# Workflow 可观测性报告

- Trial：`MS02__nDABs5b__env`
- Task：`MS02`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（32 节点 / 31 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：32；执行边：31（observed=0，inferred=31）
- Execution Trace Graph：`observed`；temporal_next 边 31，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_Q8KpuTeSyp8oYlqUfFZb5065 -> tool:nanobot-harness-v3:call_00_F8E055HgITKoH00YTWDz4773 -> tool:nanobot-harness-v3:call_01_Muph4Yz0TuwYwiPTQCYg7125 -> tool:nanobot-harness-v3:call_02_7GijI3A0K2AiInYjhicd8233 -> tool:nanobot-harness-v3:call_03_0fJdzjITeo7jTdyqbsyE8032 -> tool:nanobot-harness-v3:call_04_f6M01MGLom3ZeJ1X5MOM0751 -> tool:nanobot-harness-v3:call_05_Hnmu2cTuGMuaxgzZh2Q68292 -> tool:nanobot-harness-v3:call_06_FuP38f38yOBdqn0zLjk53088 -> tool:nanobot-harness-v3:call_07_8oDuaxq76cU9bszv0pjI8720 -> tool:nanobot-harness-v3:call_00_4miHAcJmsqVNTZ13wAdF9642 -> tool:nanobot-harness-v3:call_01_1VMAaKp57j9yYEX0A1lC9199 -> tool:nanobot-harness-v3:call_02_62PaaD4EKHCbYuOeqm0B3038 -> tool:nanobot-harness-v3:call_00_hgEiX1DtQpM5hZtSLcaS4943 -> tool:nanobot-harness-v3:call_00_9Hf4J2a5KgL319NXeDBU4727 -> tool:nanobot-harness-v3:call_01_YAAYiFzg51KqXpoX5PpE6444 -> tool:nanobot-harness-v3:call_02_G0uYyAI4f6SceERGNkum0037 -> tool:nanobot-harness-v3:call_03_14nKRhMWESFnsRgQ23z56734 -> tool:nanobot-harness-v3:call_04_hSkVASbB2SS8GTYEijqW7129 -> tool:nanobot-harness-v3:call_05_D1e262OqhhFEQpkTPsCV8607 -> tool:nanobot-harness-v3:call_06_c1E2bj3DdmR90MFICRKs8314 -> tool:nanobot-harness-v3:call_07_vq9LrYgRzhMJPv8yzZlM0224 -> tool:nanobot-harness-v3:call_08_1c3l8djwydBSArdZsd649126 -> tool:nanobot-harness-v3:call_09_Imk9vWZuHWwYXDAJsKK93388 -> tool:nanobot-harness-v3:call_00_HJmPkpUxhXTLArDJWAgA2430 -> tool:nanobot-harness-v3:call_01_bQ4JLOxx1Pai4ErKQGyd5113 -> tool:nanobot-harness-v3:call_00_DtyWwP8XT22h54qIeQZ23753 -> tool:nanobot-harness-v3:call_00_1LYTQ4qJtGTb1xbHisvL3265 -> tool:nanobot-harness-v3:call_00_huqJUMenwxGm9Ir6xUrp3440 -> tool:nanobot-harness-v3:call_00_nWcdjzpLmZVbdD7W08eg6139 -> tool:nanobot-harness-v3:call_01_LxFvosayCxWBdWt8cQAk4000 -> tool:nanobot-harness-v3:call_00_87xRisPnhPOmnGCdgTZn2037
- 关键路径耗时：0.296492
- Makespan：165.444722
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
