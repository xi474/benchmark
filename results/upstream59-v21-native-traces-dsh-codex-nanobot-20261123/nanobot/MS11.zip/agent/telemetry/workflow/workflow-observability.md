# Workflow 可观测性报告

- Trial：`MS11__dzZJppU__env`
- Task：`MS11`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（86 节点 / 85 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：86；执行边：85（observed=0，inferred=85）
- Execution Trace Graph：`observed`；temporal_next 边 85，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_mjrW7rSONcgdFzeqp06d5374 -> tool:nanobot-harness-v3:call_00_U7GA9ikude3fVLIBD3Xx6323 -> tool:nanobot-harness-v3:call_01_U6J7RknVnMjx0ZMdZI4a4201 -> tool:nanobot-harness-v3:call_02_stOFYmLVjNU7bhJQiFNT4508 -> tool:nanobot-harness-v3:call_03_9pUER2GDnmTWtI0ziWSi0963 -> tool:nanobot-harness-v3:call_04_Xa18NttTKuA0eS4t3nyT0770 -> tool:nanobot-harness-v3:call_05_VoId8fyewqrtjd4D7sem9404 -> tool:nanobot-harness-v3:call_06_8HazEhyzJLBQMehKMXUv4918 -> tool:nanobot-harness-v3:call_07_nonQWNVqNTBsTZ9WC9ok4554 -> tool:nanobot-harness-v3:call_08_co7BufpqFRyuK3oJ1AAt4082 -> tool:nanobot-harness-v3:call_00_WgdGNkUrwAhxDDOgoK8L9644 -> tool:nanobot-harness-v3:call_01_5Fl9jF7Lns43j1ERJR529538 -> tool:nanobot-harness-v3:call_02_UAyIGaBi4DsMS7kxkx9D7704 -> tool:nanobot-harness-v3:call_00_gW0UDGg2IoQiZWNarPci3512 -> tool:nanobot-harness-v3:call_01_QyK3lSDpIm4KtKrUqHDf7776 -> tool:nanobot-harness-v3:call_02_uwrAir7U4jtbPL2UGNdM4429 -> tool:nanobot-harness-v3:call_03_KdSSviOxgnBqf8Ufkt9q1912 -> tool:nanobot-harness-v3:call_04_wIAt01o4gj5D8XvgerBU9964 -> tool:nanobot-harness-v3:call_05_sDYULa6Vh60lvmz55Vfy8070 -> tool:nanobot-harness-v3:call_06_4jLUqkyWZ7WMctQxdO6A0399 -> tool:nanobot-harness-v3:call_07_PHT4AFcSnQBHHpUrzRdY9473 -> tool:nanobot-harness-v3:call_08_9KWLagEWxAAHvEw31swX7185 -> tool:nanobot-harness-v3:call_09_vkj9VZt559Hhvl3FCMLH5022 -> tool:nanobot-harness-v3:call_10_TCrfopKUfyDHQpDU1pGo9775 -> tool:nanobot-harness-v3:call_11_CZO51BrYa97vUdeHs8US0101 -> tool:nanobot-harness-v3:call_00_1U4US0lQYw3TcSj4mmjU0885 -> tool:nanobot-harness-v3:call_00_LzfHVAGutEkMroLutRDA4847 -> tool:nanobot-harness-v3:call_00_qgEuDCCYRut2HEiFqVRw1786 -> tool:nanobot-harness-v3:call_01_f4L2z03zdF3owei37en58744 -> tool:nanobot-harness-v3:call_02_jFTj0oWz9lWNpNgifVNi1421 -> tool:nanobot-harness-v3:call_00_m4GdKfSfYBRbly612Qv12611 -> tool:nanobot-harness-v3:call_01_Lk7dLcxE5RAfhuCUfaDz2915 -> tool:nanobot-harness-v3:call_02_RF1aAHAaxsxlbVSxkGc45266 -> tool:nanobot-harness-v3:call_03_aLQlv3ZbESn65uymiosy2607 -> tool:nanobot-harness-v3:call_04_tnBFJUztDKAI5IUcHWr15056 -> tool:nanobot-harness-v3:call_05_FnUPP1Q7ZcUu9c6lAQRM3790 -> tool:nanobot-harness-v3:call_06_U17aYN30vsRlw0tJOQVN6687 -> tool:nanobot-harness-v3:call_07_fBo5rCjw59H9wXjCyDab3146 -> tool:nanobot-harness-v3:call_00_RmbckOSGVP5Gb2ZzX3HJ7095 -> tool:nanobot-harness-v3:call_00_LLW8vSg17mICLWER1p617314 -> tool:nanobot-harness-v3:call_01_ep2BtsLlwy5ejD8taLp57178 -> tool:nanobot-harness-v3:call_02_JAJ3bdaOeFUvwa5rgolO2721 -> tool:nanobot-harness-v3:call_03_a5muZy4YqMQRYRQyMqWo6847 -> tool:nanobot-harness-v3:call_04_Br1qyakBjwHEDVwfvWJV6321 -> tool:nanobot-harness-v3:call_05_erCIfDoingGgiyRQ2xvT0484 -> tool:nanobot-harness-v3:call_06_XtFKm9AXZUDfTS8R4FlR2365 -> tool:nanobot-harness-v3:call_07_7jZysptqyO9hfqbJte9t8356 -> tool:nanobot-harness-v3:call_00_8qhMWl2YjYX9wmFoRinf5880 -> tool:nanobot-harness-v3:call_01_wBJjY5kP6oDOsAthC4yp1203 -> tool:nanobot-harness-v3:call_00_cef0OaUMU3hdTMVe79Fu3510 -> tool:nanobot-harness-v3:call_00_jAgsQ0ckmrnSL1iGA5Yp9531 -> tool:nanobot-harness-v3:call_00_qpJ1VejjOG3CZKVEHvUq0061 -> tool:nanobot-harness-v3:call_00_vg2I4uj3r5boBSUhyGWh7267 -> tool:nanobot-harness-v3:call_00_FLtSbaYUuK6aooZs7Dzx2535 -> tool:nanobot-harness-v3:call_00_hFs9F9AQCtJFZoY7BWM03075 -> tool:nanobot-harness-v3:call_00_PumRMJo2OgDzIPuXH9mC3448 -> tool:nanobot-harness-v3:call_00_a18lxoE2UEwWfCW7wLvv8440 -> tool:nanobot-harness-v3:call_01_cyNsUGj7ny3VTmrWHSgu7940 -> tool:nanobot-harness-v3:call_02_4CU3o4UzLpkhRvp3Yzc64584 -> tool:nanobot-harness-v3:call_00_tD19oFkSBJxjfMNP2RUH6061 -> tool:nanobot-harness-v3:call_01_9DRcJrFwDnGtmXGdS6Is4402 -> tool:nanobot-harness-v3:call_02_kS8qVxDH98GjiJGSVJ1N0334 -> tool:nanobot-harness-v3:call_03_H1R4gFSWNahWJLekLpbB9857 -> tool:nanobot-harness-v3:call_00_lbnfgYRdV5FkOzKhA60a0211 -> tool:nanobot-harness-v3:call_01_OgX1HCQnybn04f5G7T7z9207 -> tool:nanobot-harness-v3:call_02_mZ8g3TKRM0Ul4L2yI5qu4237 -> tool:nanobot-harness-v3:call_03_olIQebNx3FFqvUZq3QSe0380 -> tool:nanobot-harness-v3:call_00_jPrDmuNJLRHzD53MqDpV0557 -> tool:nanobot-harness-v3:call_01_qgKIl3SSbQTNKSWgKV2o7264 -> tool:nanobot-harness-v3:call_00_EoIi4asQLrLCBjqq2vye8543 -> tool:nanobot-harness-v3:call_00_FdPbvGeEFF3A4NysIq667194 -> tool:nanobot-harness-v3:call_00_l16AeQpQsGDwOc5mDL9C1209 -> tool:nanobot-harness-v3:call_00_BLwIRpFJLq2ZKzLT6WQY8648 -> tool:nanobot-harness-v3:call_01_uuoslONxHjZMzzcmighT8601 -> tool:nanobot-harness-v3:call_00_T80FQdFpMpDcrmmsC66Y2030 -> tool:nanobot-harness-v3:call_00_7Yz3sY7gQEqJeKPpJMo37693 -> tool:nanobot-harness-v3:call_00_dTBzGStqYNljqq5YRKtI4762 -> tool:nanobot-harness-v3:call_00_ryAx9pbto4WhGWRC1TKq8414 -> tool:nanobot-harness-v3:call_00_iD3Zf33xeOguf2v0nhKh5285 -> tool:nanobot-harness-v3:call_00_Q8e06tHum0OtBfiFhJtB8649 -> tool:nanobot-harness-v3:call_00_LDJqscAHhSqTnwPnVAfz8911 -> tool:nanobot-harness-v3:call_00_2X66Otdhwox75Pdjt7v61556 -> tool:nanobot-harness-v3:call_00_BKzyHDvlWMXxSRpwEbqL4354 -> tool:nanobot-harness-v3:call_00_F1zLTILBx0eDzTF6V10y6330 -> tool:nanobot-harness-v3:call_00_52oLbnaISRrxS8K8z9OP8928
- 关键路径耗时：1.244373
- Makespan：1094.548541
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
