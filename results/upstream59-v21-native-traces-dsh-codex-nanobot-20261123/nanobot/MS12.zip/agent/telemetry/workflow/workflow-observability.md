# Workflow 可观测性报告

- Trial：`MS12__exoHGCx__env`
- Task：`MS12`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（26 节点 / 25 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：26；执行边：25（observed=0，inferred=25）
- Execution Trace Graph：`observed`；temporal_next 边 25，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_DQuRVtWmFTsqtvRo2fuy4734 -> tool:nanobot-harness-v3:call_00_zn5mIPbrLrFNfwdcA66q9338 -> tool:nanobot-harness-v3:call_01_1ACYPZR1tCYUYKh1u6wm6515 -> tool:nanobot-harness-v3:call_02_polaeANwUC5UCfQNA5y03186 -> tool:nanobot-harness-v3:call_03_nAOo2KpeVuygrQKqLbWV8041 -> tool:nanobot-harness-v3:call_04_D015dFSwgdBKZhyjNpHB5776 -> tool:nanobot-harness-v3:call_00_cPBFnVwA2dF6OGgtxEYN1302 -> tool:nanobot-harness-v3:call_01_Al1Ogs8OlUKK9go0Fb8h9926 -> tool:nanobot-harness-v3:call_02_TqJQj17fy8C6ZnKB5wY64312 -> tool:nanobot-harness-v3:call_03_7mCreYJBOhahjy4MEQWI2177 -> tool:nanobot-harness-v3:call_00_5J0QgY9gmWmdhz926ba95116 -> tool:nanobot-harness-v3:call_01_gz7J5aCbjTmUZfMAFdg37446 -> tool:nanobot-harness-v3:call_02_q8qjtttfRO6Bqc3UJ0KF7867 -> tool:nanobot-harness-v3:call_00_lDSSMaklI700HY9h80Ae7530 -> tool:nanobot-harness-v3:call_01_CxaIqLg9ysuHb6mdeAnK0759 -> tool:nanobot-harness-v3:call_02_jaYi9HqSW35cH9jfUsqf0620 -> tool:nanobot-harness-v3:call_03_3HDjqtx1QUBozf2yJRrp3629 -> tool:nanobot-harness-v3:call_04_GF9TXbvcPJb5CA8WR6US0069 -> tool:nanobot-harness-v3:call_05_tb98a8qtXTxl0kL5mPGI0486 -> tool:nanobot-harness-v3:call_00_88dPQR2VvkhnmBMKPXzb7026 -> tool:nanobot-harness-v3:call_01_5fxa85bZni9beoHWAAQk2019 -> tool:nanobot-harness-v3:call_02_dYXLmjyAzXoxl5CA3TNC3578 -> tool:nanobot-harness-v3:call_03_lvPshulmJeSN7bysUy710168 -> tool:nanobot-harness-v3:call_04_QB77tE5XBr858BrPEbvB7784 -> tool:nanobot-harness-v3:call_05_Umg8kaiQYuyjaZISeTIw5270
- 关键路径耗时：0.013735
- Makespan：466.660419
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
