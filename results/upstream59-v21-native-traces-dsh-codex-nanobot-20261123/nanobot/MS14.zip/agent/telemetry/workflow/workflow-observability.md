# Workflow 可观测性报告

- Trial：`MS14__h3bzpVK__env`
- Task：`MS14`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_ovBGPxFyZL8CjS0LAS6v9143 -> tool:nanobot-harness-v3:call_00_YRV6BPcwqZO8WOmE87ic3114 -> tool:nanobot-harness-v3:call_01_AJofo9KqN7arKCDAPHQb3408 -> tool:nanobot-harness-v3:call_02_g9UWmHU3pfbgeu9btpZg4298 -> tool:nanobot-harness-v3:call_03_rOTkPpc20kxgTfiKWfgy8659 -> tool:nanobot-harness-v3:call_04_CClz9Nkae4xxyuSPr29t7199 -> tool:nanobot-harness-v3:call_05_M50Ey1szCfRLSycc7KmC8654 -> tool:nanobot-harness-v3:call_06_PBsr2i2jl5Udcv55ey0z5672 -> tool:nanobot-harness-v3:call_07_rokcMtnh9LK4aed3Dv4H2953 -> tool:nanobot-harness-v3:call_08_jq7jejP0N3lECbVyEFh35185 -> tool:nanobot-harness-v3:call_00_ObyzKTcjYa9YD8jdiVsG1267 -> tool:nanobot-harness-v3:call_01_xMRJxZUwDPYyEKZ1p80i7936 -> tool:nanobot-harness-v3:call_02_gyojPWMGO1O7xEZGYsts8015 -> tool:nanobot-harness-v3:call_00_kYgybzpnITzhoxd40BT12077 -> tool:nanobot-harness-v3:call_01_mnvlez5FJeITaZihZhwI8891 -> tool:nanobot-harness-v3:call_02_e45Og9xy4o6ewgpHy5gE4753 -> tool:nanobot-harness-v3:call_03_3dFzFhkneYkQb8HNOhot6727 -> tool:nanobot-harness-v3:call_04_taCE9wYZL4yVb6bjFXpC8047 -> tool:nanobot-harness-v3:call_05_DgIGgbs8hsweu14YOWtf4385 -> tool:nanobot-harness-v3:call_06_MyM9OXuKKXbYftDXwGoj3978 -> tool:nanobot-harness-v3:call_07_B7RFn7qYMzG1HKrQRWJ79747 -> tool:nanobot-harness-v3:call_00_bcvBhu6FFLCmNYmHZp9e9340 -> tool:nanobot-harness-v3:call_01_Q2vZqiQsHik5owyPv5cH1595 -> tool:nanobot-harness-v3:call_02_ZomHfqEZ7FM8QL9UQpu87342 -> tool:nanobot-harness-v3:call_03_dhJKpjafqxXQSkRNXqtX8244 -> tool:nanobot-harness-v3:call_04_v65yKJanXZ5tiUIT3AMB4700 -> tool:nanobot-harness-v3:call_05_8Bz3TD1E19y352SGLFn45595 -> tool:nanobot-harness-v3:call_00_s9g8kEnXO0UK5DxzP7Fb8776 -> tool:nanobot-harness-v3:call_01_tK79zar4co8Rbyf3HFZd0979 -> tool:nanobot-harness-v3:call_00_LEi7RVzqCxL8aJQ5Ikiy6262
- 关键路径耗时：0.020783
- Makespan：369.151955
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
