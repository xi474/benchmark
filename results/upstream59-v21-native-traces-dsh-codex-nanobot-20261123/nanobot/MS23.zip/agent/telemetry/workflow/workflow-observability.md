# Workflow 可观测性报告

- Trial：`MS23__27pcchX__env`
- Task：`MS23`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（47 节点 / 46 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：47；执行边：46（observed=0，inferred=46）
- Execution Trace Graph：`observed`；temporal_next 边 46，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_uhoddNeL1gPWKVEiiXVu2849 -> tool:nanobot-harness-v3:call_00_awXVTCWI2f5qlfO8q2ey8464 -> tool:nanobot-harness-v3:call_01_NhVHRw0I8c3TNmzCD3pv1265 -> tool:nanobot-harness-v3:call_02_8XoWIqoIuGW3e4qjUBra5585 -> tool:nanobot-harness-v3:call_03_3P6G11CdDAXMowQPFZkw0524 -> tool:nanobot-harness-v3:call_04_3pRCbnKGA6oLzYFSJTUe0791 -> tool:nanobot-harness-v3:call_00_brsm6TfOXPCmvMxBUAYa5046 -> tool:nanobot-harness-v3:call_01_8OAjAfvNxNh6t6GDmpvj2623 -> tool:nanobot-harness-v3:call_02_NJUKS2Ae9v7yMj13skgm9504 -> tool:nanobot-harness-v3:call_03_IVFBmcnL6hVSHRalCBX83648 -> tool:nanobot-harness-v3:call_00_piIYuY4jjtb0NjEWQF3U9262 -> tool:nanobot-harness-v3:call_01_00MNClnfvqhZvAPaSZAX4889 -> tool:nanobot-harness-v3:call_02_a7YZp029T7sY4EGvx8SL8458 -> tool:nanobot-harness-v3:call_00_QD0d9HVdjg8AR7zyCKpE2107 -> tool:nanobot-harness-v3:call_01_9P47KDOe02YXIzm0Amgx1960 -> tool:nanobot-harness-v3:call_02_gVXC9AXnvBSYILNJtxZ05860 -> tool:nanobot-harness-v3:call_03_5j5aKVB0pFgo6XDwY9JD0624 -> tool:nanobot-harness-v3:call_04_awnWyt6oawFVB5BfPCDC4792 -> tool:nanobot-harness-v3:call_05_dPOhQFOIT2E3gHrYtSPb2575 -> tool:nanobot-harness-v3:call_00_sLE1k7FHxkEGpxbKLXRO7380 -> tool:nanobot-harness-v3:call_01_cpdLF1FUaOBiveCgQrz85872 -> tool:nanobot-harness-v3:call_02_AAmWYFBtzWdp4sWFjHsL2106 -> tool:nanobot-harness-v3:call_03_apTB2eJSSkQENSImB6oC6530 -> tool:nanobot-harness-v3:call_00_uzcs0h0ZKWfxXUVHA9CC2970 -> tool:nanobot-harness-v3:call_01_FREIcXOGos4mU1hw80DS3839 -> tool:nanobot-harness-v3:call_02_GIASxwafW78a9weYSWZy2211 -> tool:nanobot-harness-v3:call_00_AlnBMyClHCRRcrfk5F7L7667 -> tool:nanobot-harness-v3:call_00_r59A6aoSDZoDa5W0bkt09867 -> tool:nanobot-harness-v3:call_00_Z9I5kPCwPX5YHX4SJDna6555 -> tool:nanobot-harness-v3:call_00_6p9f0TbJVnkzKaVwuqTu8464 -> tool:nanobot-harness-v3:call_00_FE1bclQ7F2AaJ4EKMGSu0134 -> tool:nanobot-harness-v3:call_00_9n78mjfHapGa5Qe75wh89767 -> tool:nanobot-harness-v3:call_00_8pirbDSG4ZwdT92KtsMx8999 -> tool:nanobot-harness-v3:call_00_EWBmdZVNGtwHvycNGtTf2166 -> tool:nanobot-harness-v3:call_00_DLgvlBxcrodFMEjfGSPv5404 -> tool:nanobot-harness-v3:call_00_eRRmKvlfhFxDqBFlVisM5022 -> tool:nanobot-harness-v3:call_00_o8v5BdV3etb3uJEKv7wd7108 -> tool:nanobot-harness-v3:call_00_ekW6bEtvMpXAVa0DM7iM5967 -> tool:nanobot-harness-v3:call_00_qRbse2fTSKaQMWBPQoHB5730 -> tool:nanobot-harness-v3:call_00_SirEWC9U5KXvSqyQeyKj8408 -> tool:nanobot-harness-v3:call_00_6nIyHvts9rN6btX9NymM1304 -> tool:nanobot-harness-v3:call_00_96fcBSTTsI9qKZBbrRHR1596 -> tool:nanobot-harness-v3:call_00_DXEYQBjg7iSlvwT6Kv9l8145 -> tool:nanobot-harness-v3:call_00_nIvwcbWNuAeDRoCEeYON5933 -> tool:nanobot-harness-v3:call_00_D35YLmKF5utarQSYbhg94615 -> tool:nanobot-harness-v3:call_00_RtUadMqq1NKcJr5nlWBD0461
- 关键路径耗时：196.471106
- Makespan：589.550136
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
