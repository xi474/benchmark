# Workflow 可观测性报告

- Trial：`MS28__AwH4FR6__env`
- Task：`MS28`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_4cHQU67EQDiWTxWFLMVX0705 -> tool:nanobot-harness-v3:call_00_fzMCY6rgrTZJrqgmQTlT8962 -> tool:nanobot-harness-v3:call_01_DvVLM24sj0XY1Y6zCyZZ7695 -> tool:nanobot-harness-v3:call_02_jx5AIJX36GqVg8urjOcX1948 -> tool:nanobot-harness-v3:call_03_lf6F776UJ0aYRgb6EPyX7235 -> tool:nanobot-harness-v3:call_04_HjFLtIDB8ySd1vS1P96t9267 -> tool:nanobot-harness-v3:call_05_FD0hszaxlt0cnLEG7dnU4968 -> tool:nanobot-harness-v3:call_00_Fcc1j305Owd61TU92C6m2030 -> tool:nanobot-harness-v3:call_01_yfemdQgizNOD4FT9Nm745987 -> tool:nanobot-harness-v3:call_02_cLgPVc6X1TJe7AlqOaNw1103 -> tool:nanobot-harness-v3:call_03_LSBJxao3VsSQa6QYF0A14337 -> tool:nanobot-harness-v3:call_04_unx9WpdOstWAsVEN0agm3226 -> tool:nanobot-harness-v3:call_00_ZYLqTIMAC4ddtzu2VyQm0987 -> tool:nanobot-harness-v3:call_00_1CuZ8xoV129ZjOY2lGho9609 -> tool:nanobot-harness-v3:call_01_fUqTxkfb09xW4yEvtFtQ0912 -> tool:nanobot-harness-v3:call_02_SXbqSlrB6FlS7r3krtOj1557 -> tool:nanobot-harness-v3:call_03_Q9f7V1M0JEg4Plh3g6hi9999 -> tool:nanobot-harness-v3:call_04_XgyWgiPMF29xxp2ipN2z6299 -> tool:nanobot-harness-v3:call_05_exY2I4oqTv1fob1iZstL0175 -> tool:nanobot-harness-v3:call_06_Hf9sFPqZoeHOV7paN44Q1984 -> tool:nanobot-harness-v3:call_07_j4tLnTc0UoVKQ6LRoNmL3280 -> tool:nanobot-harness-v3:call_00_px8L5uSETaLer8YwRQAs8047 -> tool:nanobot-harness-v3:call_01_GNeBXGD9Pvg9T9g3sdtN6602 -> tool:nanobot-harness-v3:call_02_Np20Xj5Ax4F4NvDf9mNj1273 -> tool:nanobot-harness-v3:call_03_v2UygqwkVljpT5yuVPzt9299 -> tool:nanobot-harness-v3:call_04_bPnxDP1whMZ8PyIAY99t7945 -> tool:nanobot-harness-v3:call_05_0ga0NgIA2WBtyBDqAJfC4070 -> tool:nanobot-harness-v3:call_00_zxL5dh6exXxTSIr094Zr0155 -> tool:nanobot-harness-v3:call_01_Jisi9w2XvKg3r6MlzALN0499 -> tool:nanobot-harness-v3:call_00_cMgU1h7KwbKy7czK7kGM1653 -> tool:nanobot-harness-v3:call_00_klubxLqs2JzoujENl8yD6019 -> tool:nanobot-harness-v3:call_00_5Zzlla8cZI6Nsrt63mMi1246 -> tool:nanobot-harness-v3:call_00_RRMeqnRkLObfyKV5BnUO8943 -> tool:nanobot-harness-v3:call_00_qtGFDOTZaBmYc29TFxw95618 -> tool:nanobot-harness-v3:call_00_8oXQfuzjSwnDBucQXiXF0041 -> tool:nanobot-harness-v3:call_00_53i6Vn8OjSSnPuNvwkKC2698 -> tool:nanobot-harness-v3:call_00_WtCEFB7w5eriroUvtZcs8035
- 关键路径耗时：0.324067
- Makespan：223.65339
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
