# Workflow 可观测性报告

- Trial：`MS29__wFe5xN2__env`
- Task：`MS29`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_E7Vy0ITSBDDwx95SfXqy6651 -> tool:nanobot-harness-v3:call_00_SkGqZFOKn2JRkTXnbQHZ9058 -> tool:nanobot-harness-v3:call_01_ePgminn0E3cugS6ZHlKx1473 -> tool:nanobot-harness-v3:call_02_jmHBdoCzObr46GUK1AMX9042 -> tool:nanobot-harness-v3:call_03_WqykNmXuD6iPyt2U5iMR8987 -> tool:nanobot-harness-v3:call_04_a2xcjpfhlAAMKlxeubsm3768 -> tool:nanobot-harness-v3:call_00_uk1hlo0Ovub7iGb1a5xI5479 -> tool:nanobot-harness-v3:call_01_EpL4VFIk4n7SsNMi9hNE4406 -> tool:nanobot-harness-v3:call_02_gF5qAdA8sGmySzIGIwuN6414 -> tool:nanobot-harness-v3:call_03_kyY2ZsXzyvNWNF4xrGRs5962 -> tool:nanobot-harness-v3:call_04_sqSdDwrMdt1ITohVKLKA3945 -> tool:nanobot-harness-v3:call_00_Fzh24GR26bYYEnQUbI9u7376 -> tool:nanobot-harness-v3:call_00_kwUF6sSkEJg5yEl550483197 -> tool:nanobot-harness-v3:call_01_W9GK0Loft7f2hJJ6Gi1h0445 -> tool:nanobot-harness-v3:call_02_SUuivOl4PjtwXGW3KZfX2827 -> tool:nanobot-harness-v3:call_03_sjV8ZQirgCG1Kk9uU9RC5441 -> tool:nanobot-harness-v3:call_04_Bp8viXTKsxwWuYPuDJqN4762 -> tool:nanobot-harness-v3:call_05_w7quPpfHpCNg9joAHEVY9879 -> tool:nanobot-harness-v3:call_00_5C1CKDfU7X1xTOl2gqNF3924 -> tool:nanobot-harness-v3:call_01_7PqR9hbPGSwGAfe1RdzO8718 -> tool:nanobot-harness-v3:call_02_AEnujYXMvMbbtJZtH3lX1803 -> tool:nanobot-harness-v3:call_03_wRCExmqvhgdO0yUVSiGf1446 -> tool:nanobot-harness-v3:call_04_sG3JMOXvcrALseSG7MDy1944 -> tool:nanobot-harness-v3:call_00_dIuhhOOvUqaJgWKXN7OW4003 -> tool:nanobot-harness-v3:call_01_uEVx6zjFAjHKpBbPyp4Y9212 -> tool:nanobot-harness-v3:call_00_J1w3IN3hONC2aqA1TJ0L6943 -> tool:nanobot-harness-v3:call_00_o1X7NKOlaDOTeltDunkp0894 -> tool:nanobot-harness-v3:call_00_yz372XCXKoa1HdeKQsMd3897 -> tool:nanobot-harness-v3:call_00_SCrg1BbsOUxF7oRJ7ucb0635 -> tool:nanobot-harness-v3:call_00_r2a2EcwiSojKCv7ZzpFG9623 -> tool:nanobot-harness-v3:call_00_MqPQwHFNMnlxNP3WRkHd5504 -> tool:nanobot-harness-v3:call_00_hV8rR8J3Vn6WsOHTMkt78822 -> tool:nanobot-harness-v3:call_00_QBLkfrPZphUOZJ5mTKra6632 -> tool:nanobot-harness-v3:call_00_OyAmhZO6LGYyR8tSl9DW1316 -> tool:nanobot-harness-v3:call_00_fSjYYMdZBLsIAN8lfWBa4595 -> tool:nanobot-harness-v3:call_00_RGrVD1FbaZUGWKuvakrS9092
- 关键路径耗时：0.303599
- Makespan：378.724065
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
