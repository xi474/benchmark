# Workflow 可观测性报告

- Trial：`MS30__qkAQjPC__env`
- Task：`MS30`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_L6VXvctUKyGoZaS9UqH89975 -> tool:nanobot-harness-v3:call_00_T1KsfxPF4sG1e6iCoqKF4762 -> tool:nanobot-harness-v3:call_01_eG2EswVgtrsjnZiwzawU9000 -> tool:nanobot-harness-v3:call_02_vVexQB1Apk94X4X4Z2255355 -> tool:nanobot-harness-v3:call_03_m5CAjsFjCpklPzgIQ1Lx9346 -> tool:nanobot-harness-v3:call_04_KZEf8SvHFOuKUO3R5Vc36741 -> tool:nanobot-harness-v3:call_05_0WUvCHwo0q7gkLaEHNQ01670 -> tool:nanobot-harness-v3:call_06_nMpOaAeKPY8Fg9VtIDxj3794 -> tool:nanobot-harness-v3:call_07_9RBzkw3GZ40GyMLKnouA4039 -> tool:nanobot-harness-v3:call_08_wWlzQGRMjL4IxpPFk7uI8227 -> tool:nanobot-harness-v3:call_00_2gBdRB5i1V58PAigmbA35990 -> tool:nanobot-harness-v3:call_01_p8WY8l3XCk4ff4p2ZMJq1584 -> tool:nanobot-harness-v3:call_02_MoItqPe6L1RTavS7l8YG9494 -> tool:nanobot-harness-v3:call_00_EP0rkrVbJI247Ev3LdWa2741 -> tool:nanobot-harness-v3:call_01_ZwU8b10bCQAHb129ECwr1720 -> tool:nanobot-harness-v3:call_02_sgcv7uWbMA1nj18NBsOG4281 -> tool:nanobot-harness-v3:call_03_FVNMrA4E7mygB3B0IPTm0970 -> tool:nanobot-harness-v3:call_04_g2Ws5HNUQqC4Gzw75SX01325 -> tool:nanobot-harness-v3:call_05_VT4ikGLd9dCcr1cLSddr4089 -> tool:nanobot-harness-v3:call_06_iwYjqg6n9RGT216UtEpe9339 -> tool:nanobot-harness-v3:call_07_yQpGDyCjcfhBlkvqJLDj6528 -> tool:nanobot-harness-v3:call_08_gZpAJq1zFZrIm01nhmj86134 -> tool:nanobot-harness-v3:call_09_fL9DClt9fKx6tjgycSpI6637 -> tool:nanobot-harness-v3:call_10_Www6zQyc7YO7EV1yihwX8843 -> tool:nanobot-harness-v3:call_11_zeqBUyHt5hfpbe5GleBS4495 -> tool:nanobot-harness-v3:call_00_9zntgLwuA9DFaEGyntYx7567 -> tool:nanobot-harness-v3:call_01_PoHZQKcFZqvdreXbBNYe6093 -> tool:nanobot-harness-v3:call_00_AQ4leQTcGc2rfI2T5pC82962 -> tool:nanobot-harness-v3:call_00_wvVtaKL3nRe8kuzUIgJL0786 -> tool:nanobot-harness-v3:call_00_sBYWxbmI28tjWYASM8Lg8509 -> tool:nanobot-harness-v3:call_00_fugTWPCrH2cGKtvFuNtb0439 -> tool:nanobot-harness-v3:call_00_9Fi20kVRmfRkA383uU8t8165 -> tool:nanobot-harness-v3:call_00_B3oa3KzfXcaVLYul1fqh2221 -> tool:nanobot-harness-v3:call_00_dZPQZYhDRjU5XmzIRK7W4866 -> tool:nanobot-harness-v3:call_00_aEEsIoU4c3ePKCoPfxzP1441 -> tool:nanobot-harness-v3:call_00_tK6inGL6CdYjRGj79Gfy2335 -> tool:nanobot-harness-v3:call_00_IfJ7fwo5mILWGenQsEEC5574
- 关键路径耗时：0.287189
- Makespan：449.643722
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
