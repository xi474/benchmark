# Workflow 可观测性报告

- Trial：`MS41__CUzJyUN__env`
- Task：`MS41`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（49 节点 / 48 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：49；执行边：48（observed=0，inferred=48）
- Execution Trace Graph：`observed`；temporal_next 边 48，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_4XBW2nwfruHUcuj3deRo9210 -> tool:nanobot-harness-v3:call_00_otRxSyxaCrBYPfGMOBbu0098 -> tool:nanobot-harness-v3:call_01_ONFLBND92pxtGRrtWGv24945 -> tool:nanobot-harness-v3:call_02_3SKNB7JJvQx0UymvCEC34821 -> tool:nanobot-harness-v3:call_03_LZIyLxyHgiksrcjwL6cM9268 -> tool:nanobot-harness-v3:call_04_yNUwn53r3EPzifzfbGyD7414 -> tool:nanobot-harness-v3:call_05_Ikzm9fUtJvN9qmqd1jtr8185 -> tool:nanobot-harness-v3:call_06_2qvCkYaeHGEzxMFbQgn87059 -> tool:nanobot-harness-v3:call_07_TIe5UKlv8MMjM2cWi0dG1126 -> tool:nanobot-harness-v3:call_00_TMrEml6DEUt1PZ4aSjTs3250 -> tool:nanobot-harness-v3:call_01_MeTdBeVAFIVA0MFCtJqy5445 -> tool:nanobot-harness-v3:call_02_MCg9aOwHgohlfpMLMOJv0103 -> tool:nanobot-harness-v3:call_00_RFHs5IRZHmAq9tcNZzov3433 -> tool:nanobot-harness-v3:call_00_fBaNjLksmx0vN71Szlxk5701 -> tool:nanobot-harness-v3:call_01_letxbNOkJEpvIRfUFlnt2314 -> tool:nanobot-harness-v3:call_02_8hZ7UHUps3tamYLFh8rI9102 -> tool:nanobot-harness-v3:call_03_JOMP6sosPiS9qoHLsk1M7935 -> tool:nanobot-harness-v3:call_04_AqIFGCluQ6alfYic73E54682 -> tool:nanobot-harness-v3:call_05_FyMjXA2CzmkOXaSZd4wO9780 -> tool:nanobot-harness-v3:call_06_dO8uCYvT0JUFMEaaXYJZ4860 -> tool:nanobot-harness-v3:call_07_aADXTezEOeH66SLPYb0t9239 -> tool:nanobot-harness-v3:call_00_8vmdwuUTZdJHNXy39UnE2218 -> tool:nanobot-harness-v3:call_01_JFRjhQ061Em4jGppQmR59290 -> tool:nanobot-harness-v3:call_02_8vKofFsDRnOeEkLwMr7I3582 -> tool:nanobot-harness-v3:call_03_5iRBuZ6Vzw2HmZ12B2pS5648 -> tool:nanobot-harness-v3:call_04_zuMglQgeHRHf0fdo5Q6o5120 -> tool:nanobot-harness-v3:call_05_TIDqFHrGSJOEtLAUcFWc8262 -> tool:nanobot-harness-v3:call_06_My64XltMs9C7Ok5JpcDm5144 -> tool:nanobot-harness-v3:call_00_GiyensrAG7qgsciUGs2O0166 -> tool:nanobot-harness-v3:call_00_QdvNR4VywgYTpszXRNYk3793 -> tool:nanobot-harness-v3:call_00_cjdOenKGRDmYy6cz9ibf2869 -> tool:nanobot-harness-v3:call_00_M7CGWdoT1WiBBIajC40U4497 -> tool:nanobot-harness-v3:call_00_pw1OtLmbCJOfCmV6MJ4A2888 -> tool:nanobot-harness-v3:call_00_cP46medSh6c2cMUpRGoE0684 -> tool:nanobot-harness-v3:call_00_l8jukCPe33hUATdeeug65548 -> tool:nanobot-harness-v3:call_00_01Vny0sWYdMZu4uMMnub2060 -> tool:nanobot-harness-v3:call_00_2S1A9JuswjbNts5BfNHb9980 -> tool:nanobot-harness-v3:call_00_uOhbO1O19DA75WB26szI9280 -> tool:nanobot-harness-v3:call_00_eDrQM6C4HAOG1wqtMXpn6635 -> tool:nanobot-harness-v3:call_00_FcHQZh8aLS3og7T1UAT46737 -> tool:nanobot-harness-v3:call_00_KmLbc6651iCCfoxNSJwP2519 -> tool:nanobot-harness-v3:call_00_py8jLLwNXQuCoDU4F4Mb5412 -> tool:nanobot-harness-v3:call_00_oqCZkznWqhs54f85pVVG2994 -> tool:nanobot-harness-v3:call_00_HvOI3Q8hismp7S4Ld4FV5646 -> tool:nanobot-harness-v3:call_00_vuW39qjBTr6dkPrGMQhU6612 -> tool:nanobot-harness-v3:call_00_RwXfnJkrGtoDPFo5mNwG6950 -> tool:nanobot-harness-v3:call_00_bUBut6plsAHK9dUuR1Zw8680 -> tool:nanobot-harness-v3:call_00_SXCy7rzstXXS0jV1anrl0433
- 关键路径耗时：0.672366
- Makespan：465.424203
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
