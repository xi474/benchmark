# Workflow 可观测性报告

- Trial：`MS42__FBWmghi__env`
- Task：`MS42`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_siXpx113JBNv9MCnFgkG2590 -> tool:nanobot-harness-v3:call_00_IyEgShIkwIVMgt8g3D8t5513 -> tool:nanobot-harness-v3:call_01_Gjgz8bll4ELLxAR3x7Ue6732 -> tool:nanobot-harness-v3:call_02_d53EDlP7Z3Nh0orXSmqL0312 -> tool:nanobot-harness-v3:call_03_rutuC8KsHg0aO3BHc8TS9933 -> tool:nanobot-harness-v3:call_04_4oyUEIaQIhpGgtAFfmvd2207 -> tool:nanobot-harness-v3:call_05_h0RrS4HBkQoBr73ceHk00339 -> tool:nanobot-harness-v3:call_06_iedKznB3nrRMUZVYlnXu5234 -> tool:nanobot-harness-v3:call_07_NwI7ZlKCIIdk8Orp2gcA9655 -> tool:nanobot-harness-v3:call_08_d5jn4t0MQRj5CnI5Alsp0193 -> tool:nanobot-harness-v3:call_00_RcLDQO4fqu8Dilh20F4c8899 -> tool:nanobot-harness-v3:call_01_Y7Ig536k2Azj5IW4Ky6k2699 -> tool:nanobot-harness-v3:call_02_KAvQ9BUd3zTrDuNDHHBG1876 -> tool:nanobot-harness-v3:call_00_uzX8QgGRK4A3O6rUFV4D7387 -> tool:nanobot-harness-v3:call_01_lDETWpn3BdR0rugOq5lX1390 -> tool:nanobot-harness-v3:call_02_U702XjoLRW74mxH69Y802511 -> tool:nanobot-harness-v3:call_03_nSD3Y23pEM3Oi4qSSgjf0880 -> tool:nanobot-harness-v3:call_04_akNAzD5FxPvkDpsNdH4X6001 -> tool:nanobot-harness-v3:call_05_m3Ti7TgITIWk33jGZ20O8767 -> tool:nanobot-harness-v3:call_06_5Z3tIFOlDjcyAmsVtHF57476 -> tool:nanobot-harness-v3:call_00_UnE9Jt9Txx9yaTYA5olM3949 -> tool:nanobot-harness-v3:call_01_QW6VleumqE5XWFVgwcKw6560 -> tool:nanobot-harness-v3:call_02_ApJsOK9paabZH9exXTFL6710 -> tool:nanobot-harness-v3:call_03_PV5j2J8ortkKnBrlXPTX4144 -> tool:nanobot-harness-v3:call_04_l6U8z0XwLzim1QPRpAsS3293 -> tool:nanobot-harness-v3:call_05_q1sW4CTF7vR1uWrz4Qih4618 -> tool:nanobot-harness-v3:call_06_crNeY3rwDZ0abRPizP1i3928 -> tool:nanobot-harness-v3:call_00_kuuvKBfrtAg2zOqKPmho7362 -> tool:nanobot-harness-v3:call_01_YE1LmPqZTlc7CFWDBkuq7006 -> tool:nanobot-harness-v3:call_00_6IZAaHqdSdf5IJItFK2T3971 -> tool:nanobot-harness-v3:call_01_Wt6HVvQAUiRect2adv1g0498 -> tool:nanobot-harness-v3:call_00_PZSNiQNvwxPJOLVXuAAO3242 -> tool:nanobot-harness-v3:call_00_f4nBQAHByPIrP9F6002M2952
- 关键路径耗时：0.017924
- Makespan：368.862547
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
