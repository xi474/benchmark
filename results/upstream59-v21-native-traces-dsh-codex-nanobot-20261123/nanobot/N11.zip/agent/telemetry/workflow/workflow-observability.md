# Workflow 可观测性报告

- Trial：`N11__g8aTPRM__env`
- Task：`N11`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（39 节点 / 38 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：39；执行边：38（observed=0，inferred=38）
- Execution Trace Graph：`observed`；temporal_next 边 38，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_IWTYLIZti7wyUH93wseU5657 -> tool:nanobot-harness-v3:call_00_BRZP8azVnMQiNHcJz4QR1535 -> tool:nanobot-harness-v3:call_01_0uzfhZ0wn8dhFYgP8fil0394 -> tool:nanobot-harness-v3:call_02_0RwhbIgPyU5md8jFU5hS5847 -> tool:nanobot-harness-v3:call_03_phF58NAUpWbLsNrXVfNK4037 -> tool:nanobot-harness-v3:call_04_G5FmwpZbi5mHlojDo6hQ1401 -> tool:nanobot-harness-v3:call_05_WODFLFQElutsqThB0VR27963 -> tool:nanobot-harness-v3:call_00_ZAPxjTdp1ZZnNfoc2jAw4250 -> tool:nanobot-harness-v3:call_01_cDZGjREKzscCysIbPdhk9398 -> tool:nanobot-harness-v3:call_00_0jSxwJyICL2a3kDR6fCk0022 -> tool:nanobot-harness-v3:call_01_OHDzdN51wI6H5DMu6lvM5302 -> tool:nanobot-harness-v3:call_02_1QonBrzYx3iLp1Py9Nri2546 -> tool:nanobot-harness-v3:call_03_udVzWzygTDnh8Gram8mJ9615 -> tool:nanobot-harness-v3:call_04_PCfIINBT60fGr8eciR8j0220 -> tool:nanobot-harness-v3:call_05_FDYP4GLcwP5kPaL5LbGf1581 -> tool:nanobot-harness-v3:call_06_onAfTJcR5IVw67LgjOf32692 -> tool:nanobot-harness-v3:call_07_na5jRHZbqF9Fsp3Yhwgh6609 -> tool:nanobot-harness-v3:call_08_gOGnhDKwW7viRon6EIYZ4079 -> tool:nanobot-harness-v3:call_09_QFJrrkQ7fikLbXwd58aG9193 -> tool:nanobot-harness-v3:call_00_CGkgkqwoKL2J75ay7PGN2734 -> tool:nanobot-harness-v3:call_01_eLWGgu8lS77fGRSCHud09813 -> tool:nanobot-harness-v3:call_02_jbAaffr3ncvLTdcGsF316698 -> tool:nanobot-harness-v3:call_00_HStEsjNuX0ZdPMh13S8Y0913 -> tool:nanobot-harness-v3:call_00_A3f53vfDgXhZ9OUDuq2P9102 -> tool:nanobot-harness-v3:call_00_9oWLgvdsOpPkDegKmxEr1520 -> tool:nanobot-harness-v3:call_00_FAoGlQp5FraQKeopH0ge3053 -> tool:nanobot-harness-v3:call_00_H2XzPgslgb8dYlXLGLEL4524 -> tool:nanobot-harness-v3:call_00_mWi7xh0bjVfQBJnqygMT4418 -> tool:nanobot-harness-v3:call_00_nE3fNKWVZDN1RRUehn0i5936 -> tool:nanobot-harness-v3:call_00_qOrZF24X7HJmo3NkJAOP0152 -> tool:nanobot-harness-v3:call_00_uTlsLTSf85x1dOHopzUf3757 -> tool:nanobot-harness-v3:call_00_JZ62pCGw8KZbwkU0fzIv7231 -> tool:nanobot-harness-v3:call_00_kgArBzYw6z6sX1HXv1Zk4488 -> tool:nanobot-harness-v3:call_00_QJLEprcQIuYTYWlw7lOD6902 -> tool:nanobot-harness-v3:call_00_hPN2DUeeGWgjlDMohKfP6300 -> tool:nanobot-harness-v3:call_00_AWvhiJbQfwa4gMHDyFxZ9062 -> tool:nanobot-harness-v3:call_00_w7T84FDTlY5JPdC0auyZ7837 -> tool:nanobot-harness-v3:call_00_hD66fIkkDYy9sRIA7JhL2725
- 关键路径耗时：0.309053
- Makespan：115.243193
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
