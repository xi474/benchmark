# Workflow 可观测性报告

- Trial：`N17__5hXnES2__env`
- Task：`N17`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（51 节点 / 50 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：51；执行边：50（observed=0，inferred=50）
- Execution Trace Graph：`observed`；temporal_next 边 50，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_a2jUGHoivpCaCe6OL5fe4041 -> tool:nanobot-harness-v3:call_00_iZPCfC5U6M62O2yAMlAR4965 -> tool:nanobot-harness-v3:call_01_rxZqAch1aJIcZqBynq8B0087 -> tool:nanobot-harness-v3:call_02_pBjXCeWlXeNKw19jTenw6961 -> tool:nanobot-harness-v3:call_03_3ALUHcQrc6GyC3NS4d411498 -> tool:nanobot-harness-v3:call_04_u2CCRUlJ6LdZkl0kryKA0055 -> tool:nanobot-harness-v3:call_05_zKd6FMovHqGGP1joIoPh8305 -> tool:nanobot-harness-v3:call_00_pxPFwZ7WTVEt8zTOkSDW3321 -> tool:nanobot-harness-v3:call_01_fuuhma1OnXFU03uomisV9123 -> tool:nanobot-harness-v3:call_00_n3qiHDjZJPFSvtpP6x541047 -> tool:nanobot-harness-v3:call_01_Fm1C36H8KAEpdWJ7GdF47376 -> tool:nanobot-harness-v3:call_02_YliIsVla7ThAAqkLF2gT4451 -> tool:nanobot-harness-v3:call_03_5J3fZI9NJoO36upU9qx20865 -> tool:nanobot-harness-v3:call_04_l73B7fZc1uy7l7t6YJ990999 -> tool:nanobot-harness-v3:call_05_1heR2BeRH18iw6FoNfuT5438 -> tool:nanobot-harness-v3:call_06_BRIab7dAEcPCnCB9VMak5598 -> tool:nanobot-harness-v3:call_07_LxtO5q4M2umokNWSefIz6653 -> tool:nanobot-harness-v3:call_08_Odi4sA7vE1PAsA8GXF6L4895 -> tool:nanobot-harness-v3:call_09_Okn6eG34WZOTClbGnBH77691 -> tool:nanobot-harness-v3:call_00_XmYdx4CIqiCcVHPQ7Wp76528 -> tool:nanobot-harness-v3:call_01_E5EyDP1mQWMRkT4Q0zG51144 -> tool:nanobot-harness-v3:call_02_7LMn7c55824uvYpUN3Gw9610 -> tool:nanobot-harness-v3:call_03_SqlBXX5qofYgajvRTqFY7074 -> tool:nanobot-harness-v3:call_00_xXj6vOOFdBII1pgu9wEB5299 -> tool:nanobot-harness-v3:call_00_V01yWdN4O9n0Ry77mcGq4969 -> tool:nanobot-harness-v3:call_00_C23qgwb7fIz2BkJokn3M1515 -> tool:nanobot-harness-v3:call_00_u3wqOAi3rUQF89A4qRzN8195 -> tool:nanobot-harness-v3:call_00_WjQa1IHHQeUgClyK9Nrw7935 -> tool:nanobot-harness-v3:call_00_HsCsex9J1FXapZF8rzNv7670 -> tool:nanobot-harness-v3:call_00_vqaH1spmGPmjt3DQN00P5933 -> tool:nanobot-harness-v3:call_00_m0C6Owiv3JsP56jg7g4f2417 -> tool:nanobot-harness-v3:call_00_rYQrwgMJCjR0KtbSsWXw7585 -> tool:nanobot-harness-v3:call_00_2zExa1I8dIRLavagHu5i1916 -> tool:nanobot-harness-v3:call_00_AyzpQVH3xpVnN1m62EwP4974 -> tool:nanobot-harness-v3:call_00_Q7fTPK7mrh3MAV67khoH4814 -> tool:nanobot-harness-v3:call_00_gzylov8wu7BBWkretgGj8032 -> tool:nanobot-harness-v3:call_00_8eFfj75uefcPe82HWokY8379 -> tool:nanobot-harness-v3:call_00_ybLcsOa88sYWyHiahney5199 -> tool:nanobot-harness-v3:call_00_EtclUR31ORwsQSkFnAcf1528 -> tool:nanobot-harness-v3:call_00_n8kJyVnhbGkVjV6Gam6A2625 -> tool:nanobot-harness-v3:call_00_qbmPyPhPxMsOgoPXRN8w1501 -> tool:nanobot-harness-v3:call_00_wwlW6X438orDZqimnDv53787 -> tool:nanobot-harness-v3:call_00_rB3k3hgI3tAbFMo0wsnS3008 -> tool:nanobot-harness-v3:call_00_wqwyPd1bxKadvMa5i0SL4655 -> tool:nanobot-harness-v3:call_00_RidPTRUZJ5tJOUz7ox5a4383 -> tool:nanobot-harness-v3:call_00_sjicnPoOtH0iWZ7YL1Qe5468 -> tool:nanobot-harness-v3:call_00_VBSzhZxbnPMzvlLmQQME9577 -> tool:nanobot-harness-v3:call_00_cjqqXmgzETUZgDbtJrCV4799 -> tool:nanobot-harness-v3:call_00_71zn4fYBFBwm4DCM5Emv8953 -> tool:nanobot-harness-v3:call_00_NbDBwvxMUSMc9oE7s5VP1535
- 关键路径耗时：0.281318
- Makespan：301.945171
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
