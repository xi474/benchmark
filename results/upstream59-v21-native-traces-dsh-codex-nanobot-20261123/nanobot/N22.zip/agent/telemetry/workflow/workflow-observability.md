# Workflow 可观测性报告

- Trial：`N22__ovtW7jC__env`
- Task：`N22`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（77 节点 / 76 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：77；执行边：76（observed=0，inferred=76）
- Execution Trace Graph：`observed`；temporal_next 边 76，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_0qT3YK3nT6hQv0UR0TWG1501 -> tool:nanobot-harness-v3:call_00_7gKcoZeNvi0DB3692Sem4307 -> tool:nanobot-harness-v3:call_01_JucI0SU4RVHpcDKaVgd36103 -> tool:nanobot-harness-v3:call_02_s49NWsBtlPFDnAoxE6M15088 -> tool:nanobot-harness-v3:call_03_0aBKc6k7Yi7hxU8XlUL47141 -> tool:nanobot-harness-v3:call_04_msFiDifCGMFPBENoMpsy6221 -> tool:nanobot-harness-v3:call_00_Tt7G4E3rnKpR8bIXCUrf9231 -> tool:nanobot-harness-v3:call_01_TZ74UEgXVYsme1DHGedq9711 -> tool:nanobot-harness-v3:call_02_xTqMIoZnpxWnT4bPOGKE9129 -> tool:nanobot-harness-v3:call_03_anlRXTv8QRInzPNfSgtH3347 -> tool:nanobot-harness-v3:call_00_TS0SrWnzlRspwGcJLUqq7277 -> tool:nanobot-harness-v3:call_01_vpa7RoDPZsQTZAgLwa2C7461 -> tool:nanobot-harness-v3:call_02_ZMPMvrEJHaVe4XBvqW9M1115 -> tool:nanobot-harness-v3:call_03_sh1SjbyW9T1RavGrwLvA3918 -> tool:nanobot-harness-v3:call_00_U6zWapGomLhcjFz2v8mv0580 -> tool:nanobot-harness-v3:call_01_MGW4hiDuIGxQKcpm8u875439 -> tool:nanobot-harness-v3:call_02_R8jvOOyeWgOyuVxY0giS8296 -> tool:nanobot-harness-v3:call_03_EdVBbx4fpL1XeiCp7qSU7954 -> tool:nanobot-harness-v3:call_04_eGjhnHv5WlQ2DTuKIGv95804 -> tool:nanobot-harness-v3:call_05_cHZkuaQiiUQ49i2ZvNvc1422 -> tool:nanobot-harness-v3:call_06_AZeVtUvSDi6KptumkdAm6291 -> tool:nanobot-harness-v3:call_07_acx5o0ZM6djKsPABOJCl0847 -> tool:nanobot-harness-v3:call_08_uF00ULMDEa89YkEAhJzI8339 -> tool:nanobot-harness-v3:call_00_FSar4lg8ZlDP3yzvNyiR2002 -> tool:nanobot-harness-v3:call_00_OmXY6uxnKyaMpUoyBMNj6579 -> tool:nanobot-harness-v3:call_00_ZgG1Ud2GliLGSZWO43eY9423 -> tool:nanobot-harness-v3:call_00_jFjE1d2IoAxxOrUksI2N6968 -> tool:nanobot-harness-v3:call_00_LlN1YRlhlNBGScGiQEYi9905 -> tool:nanobot-harness-v3:call_00_FFFmJynayTVFb84pDxd07090 -> tool:nanobot-harness-v3:call_00_S3lprFStMBrLBRYkrTwG9037 -> tool:nanobot-harness-v3:call_00_10wR3AMf9jniC6dqCN8V6706 -> tool:nanobot-harness-v3:call_00_YoU6mbl0OI7LeQFto8ZC8560 -> tool:nanobot-harness-v3:call_00_uLj8xgL4ZUKiqv4yu7wT8596 -> tool:nanobot-harness-v3:call_00_9zPL38FynzRCfTQD3oTq4351 -> tool:nanobot-harness-v3:call_00_EAulG27qaN99idRaMgda8601 -> tool:nanobot-harness-v3:call_00_mhcNswLFPIJ3CHYGBOhM3390 -> tool:nanobot-harness-v3:call_00_25l17TuRnBcdIgOdA2Xe3893 -> tool:nanobot-harness-v3:call_00_97kxiyHIVA1QL7S57aur2009 -> tool:nanobot-harness-v3:call_00_meKxzXQT1P76MRb2ScK65732 -> tool:nanobot-harness-v3:call_00_TU5Brku7mAktsCDtrJo99549 -> tool:nanobot-harness-v3:call_00_r1ScaxX2xjDa9w36Nzwf0084 -> tool:nanobot-harness-v3:call_00_jMc9waWA5qeTu5bfsGot1809 -> tool:nanobot-harness-v3:call_00_P0mlt9xA3z2BXh5BUMdx2006 -> tool:nanobot-harness-v3:call_00_2YTzQPfqhoRDOrrQP2ks0233 -> tool:nanobot-harness-v3:call_00_PLOSypjXlmiE61yiEVHc8814 -> tool:nanobot-harness-v3:call_00_APZDeqTesc4LIca4ha5j4462 -> tool:nanobot-harness-v3:call_00_onGnsiqO4z3VYOSGG4Jt4835 -> tool:nanobot-harness-v3:call_00_seAKZdxVqSXk7Hk54neN7768 -> tool:nanobot-harness-v3:call_00_dPGKlENEjQhnp7jFLtve0748 -> tool:nanobot-harness-v3:call_00_Zv59oXPtdhdRSqcepbkp8446 -> tool:nanobot-harness-v3:call_00_XnSLMP6YYHXB9m8s8T8q5907 -> tool:nanobot-harness-v3:call_00_qoHRmdVA68RQhNa96NKf5690 -> tool:nanobot-harness-v3:call_01_kRSJXtDbDCRgXMjHoVBw5893 -> tool:nanobot-harness-v3:call_02_FooLBnIqrRWQjMpYTdzz3192 -> tool:nanobot-harness-v3:call_00_8RSszwpDouO9XrlHCjYn7729 -> tool:nanobot-harness-v3:call_00_jAGUHVMpMblGEvztSZT11089 -> tool:nanobot-harness-v3:call_00_dOwEzi5GFnBBeJmx0Okz2753 -> tool:nanobot-harness-v3:call_00_g84sXRdqIsrJbi7ZC6eX8387 -> tool:nanobot-harness-v3:call_00_eAA9C9mbv4zGKlrcdrhf1028 -> tool:nanobot-harness-v3:call_00_rTUGGtJMy9IFsEnExOh13137 -> tool:nanobot-harness-v3:call_00_ijaH68lZLAg1arKcdyok5573 -> tool:nanobot-harness-v3:call_00_Vbcbh1i0P0zMZked2igs5611 -> tool:nanobot-harness-v3:call_00_EBhgG0O5eQp3eptklnXx3706 -> tool:nanobot-harness-v3:call_00_F5TWZqeGviNV2WzzukXs8241 -> tool:nanobot-harness-v3:call_00_9crassnZpei9TuTgEUUt6301 -> tool:nanobot-harness-v3:call_00_156cmDd1kCfMYHQRaaG19477 -> tool:nanobot-harness-v3:call_00_P6Ra4xgoz2q7DER05fQS7590 -> tool:nanobot-harness-v3:call_00_Quw7ZxpTaKG3b6pCp3bZ7848 -> tool:nanobot-harness-v3:call_00_LPrxzrYWYIj8iMXUenjB0212 -> tool:nanobot-harness-v3:call_00_TGrStLcHvAKlBqhi6CmI1744 -> tool:nanobot-harness-v3:call_00_OxfwJMKr9OAbs48G9DvC4015 -> tool:nanobot-harness-v3:call_00_e8i5QK0TU4nmiH6ZAJbF2725 -> tool:nanobot-harness-v3:call_00_jKf3ocb1hlpbKPXB3erK7387 -> tool:nanobot-harness-v3:call_00_pZTZsByGU40mBBYFNX7C0511 -> tool:nanobot-harness-v3:call_00_yLA7LigCawXDsy8ybHJi7838 -> tool:nanobot-harness-v3:call_00_jS9q8fnie1e9cqzkd5do0088
- 关键路径耗时：0.892874
- Makespan：344.982649
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
