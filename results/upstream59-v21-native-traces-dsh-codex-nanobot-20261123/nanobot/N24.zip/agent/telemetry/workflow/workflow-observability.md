# Workflow 可观测性报告

- Trial：`N24__PCutCvV__env`
- Task：`N24`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_IxyRhodl07qmBYhHz0Jc6943 -> tool:nanobot-harness-v3:call_00_Ev0MmdJ9ht3wxmkzlCTn6575 -> tool:nanobot-harness-v3:call_01_bojPwUnwkjrbh6fHQ1uK9063 -> tool:nanobot-harness-v3:call_02_wP23Jy6ZOVB1zAPDKB033968 -> tool:nanobot-harness-v3:call_03_29dmLWkCEqizAszuSrgs9744 -> tool:nanobot-harness-v3:call_04_QE2mNFSzOXTE6AXH99ig8602 -> tool:nanobot-harness-v3:call_05_uU1IHlSQ9ySwu27lm3Ok1898 -> tool:nanobot-harness-v3:call_06_0q0aaOHAGd480bSnj30z8155 -> tool:nanobot-harness-v3:call_00_YRlUzV9fWmT0O4iBF6VS7355 -> tool:nanobot-harness-v3:call_01_oeNqnoPxNsbzarLjMD7Z5698 -> tool:nanobot-harness-v3:call_00_0C9vGua2mhGOjmfNqvAO8143 -> tool:nanobot-harness-v3:call_01_ZfNqXjob3fJf5ZMxttnx6056 -> tool:nanobot-harness-v3:call_02_dXFhGpBw54MQp2pePVVH3758 -> tool:nanobot-harness-v3:call_03_HNTShX9JIL2gCufT0OGM1460 -> tool:nanobot-harness-v3:call_04_VWOMS6IBu5crJSVyCOsQ1247 -> tool:nanobot-harness-v3:call_05_v1vmaN1IZ6ZgK6SczVpZ3465 -> tool:nanobot-harness-v3:call_06_r8ZUYcK3NQWDLEuaHDHh7123 -> tool:nanobot-harness-v3:call_07_XUpQP28Sd0rSPRCyLZt93980 -> tool:nanobot-harness-v3:call_08_IClSn6QsQsIHWgrMYZ8c9007 -> tool:nanobot-harness-v3:call_09_6L90pwSBP5cfyyiSZGwV0769 -> tool:nanobot-harness-v3:call_10_MB07YeBCSFXUStDggNOJ9223 -> tool:nanobot-harness-v3:call_11_ZH15ATySPoGyj8AfzDxP2406 -> tool:nanobot-harness-v3:call_12_D0mssLEYF5eVSXRCA7NN4572 -> tool:nanobot-harness-v3:call_00_2I47NzdhZGBogcLzjkZY6984 -> tool:nanobot-harness-v3:call_01_NW7KOtLQah5bFHLjDZEx8882 -> tool:nanobot-harness-v3:call_02_1SB6Yq2EmDChvOld6Rtk4841 -> tool:nanobot-harness-v3:call_00_KtOQpe7kAALjWkC6HKwp2258 -> tool:nanobot-harness-v3:call_00_MiMlzmbwxxI2aS6fN7G88437 -> tool:nanobot-harness-v3:call_00_krnc4iNPMssWz4pHwPRx7824 -> tool:nanobot-harness-v3:call_00_onruVx2Kw0UoObwNe54m8552 -> tool:nanobot-harness-v3:call_00_072uxRT4bzy4OhIIOgj19094 -> tool:nanobot-harness-v3:call_00_pnG0LCpLIWYmSgF9JU3C7966 -> tool:nanobot-harness-v3:call_00_P9N2e378iD41ILVpj6HF8728 -> tool:nanobot-harness-v3:call_00_SGOMrNOAh5rLYuiaKFjS5212 -> tool:nanobot-harness-v3:call_00_7UiNYpJZXkvpiQxmhZjy3267 -> tool:nanobot-harness-v3:call_00_NK90x4gXzCkpz8sYOBtV0697 -> tool:nanobot-harness-v3:call_00_C9IPg4pPINc1qtaI9Ep86827 -> tool:nanobot-harness-v3:call_00_pwAIU33vdE4j9EhEgLzs9870 -> tool:nanobot-harness-v3:call_00_M5YeGMwuhSUC1gX1x1Iw1693 -> tool:nanobot-harness-v3:call_00_OJZBGygkYFJdHf4lXRlU8216 -> tool:nanobot-harness-v3:call_00_lhKdn1VFHRhvD3VhPUhr6429
- 关键路径耗时：0.136974
- Makespan：123.480254
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
