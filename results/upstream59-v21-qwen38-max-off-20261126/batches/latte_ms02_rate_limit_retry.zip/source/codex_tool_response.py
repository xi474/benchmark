"""Fail closed on tool fragments before translating buffered Chat to Responses."""

from copy import copy
import hashlib
import json

from normal_protocol import identifier
from tool_contract import denied_call
from tool_names import resolve_returned_name

BRIDGE_VERSION = "deepseek-codex-chat-normal/1.0.5"


def encode_tool_response(original, collector, registry, evidence):
    """Preserve usage and complete tool calls, without executing truncated calls."""
    filtered = copy(collector)
    filtered.calls = {}
    raw_calls = sorted(collector.calls.items())
    if collector.finish == "length":
        for _, call in raw_calls:
            evidence.append({
                "policy": "discard-tool-call-on-incomplete-response",
                "call_id_sha256": hashlib.sha256(call["id"].encode()).hexdigest(),
                "original_tool_executed": False,
                "tools_added": 0,
                "automatic_upstream_retry": False,
            })
        response = original(filtered, registry, evidence)
        # Retain the client's normal output-cap behavior for an incomplete turn.
        response["end_turn"] = False
        return response

    deferred_denials = []
    for position, (index, call) in enumerate(raw_calls):
        fn = call["function"]
        try:
            wire = resolve_returned_name(fn["name"], registry)
        except ValueError:
            # The existing converter decides whether the name is unoffered or ambiguous.
            filtered.calls[index] = call
            continue
        if registry[wire]["type"] == "custom":
            try:
                arguments = json.loads(fn["arguments"])
                if not isinstance(arguments, dict) or set(arguments) != {"input"}:
                    raise ValueError("Malformed custom arguments")
                arguments["input"].encode("utf-8")
            except (ValueError, AttributeError):
                denied, event = denied_call(call, registry, identifier)
                event["policy"] = "deny-malformed-custom-tool-arguments"
                evidence.append(event)
                deferred_denials.append((position, denied))
                continue
        filtered.calls[index] = call

    response = original(filtered, registry, evidence)
    prefix = len(response["output"]) - len(filtered.calls)
    for position, denied in deferred_denials:
        response["output"].insert(prefix + position, denied)
    if deferred_denials:
        response["end_turn"] = False
    return response


def install(bridge):
    """Bind the guard at the already-settled response conversion boundary."""
    if bridge.ADAPTER_VERSION == BRIDGE_VERSION:
        return
    if bridge.ADAPTER_VERSION != "deepseek-codex-chat-normal/1.0.4":
        raise RuntimeError("Unexpected Codex bridge version")
    original = bridge.output_response
    bridge.output_response = lambda col, reg, evidence: encode_tool_response(original, col, reg, evidence)
    bridge.ADAPTER_VERSION = BRIDGE_VERSION
