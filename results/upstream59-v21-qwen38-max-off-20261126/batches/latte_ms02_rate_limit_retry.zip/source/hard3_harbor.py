"""IPC-only runtime mount for the Agent; original network:none and verifier untouched."""
from pathlib import Path
import json,os
from harbor.environments.factory import EnvironmentFactory
R=Path(__file__).resolve().parent
original=EnvironmentFactory.create_environment.__func__
def ipc(cls,*args,**kwargs):
    directory=Path(kwargs.get('environment_dir',args[1] if len(args)>1 else '.'))
    if os.environ.get('HARD3_USE_UNIX_INGRESS')=='1' and directory.name=='environment':
        source=Path(os.environ['HARD3_HOST_SOCKET']);assert source.is_socket()
        overlay=R/'ipc-overlays';overlay.mkdir(exist_ok=True)
        target=overlay/(str(os.getpid())+'.json')
        target.write_text(json.dumps({'services':{'main':{'volumes':[str(source)+':/installed-agent/hard3-ingress.sock:ro']}}}))
        kwargs['extra_docker_compose']=[*(kwargs.get('extra_docker_compose') or []),target]
    return original(cls,*args,**kwargs)
EnvironmentFactory.create_environment=classmethod(ipc)
if __name__=='__main__':
    from harbor.cli.main import app
    app()
