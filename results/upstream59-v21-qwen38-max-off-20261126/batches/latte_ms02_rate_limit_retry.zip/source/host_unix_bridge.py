"""Relay the Harbor actor socket to the fixed batch gateway on localhost."""

from pathlib import Path
import select
import socket
import socketserver


class Server(socketserver.ThreadingUnixStreamServer):
    daemon_threads = True


class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        try:
            with socket.create_connection(("127.0.0.1", self.server.target_port), timeout=20) as remote:
                while True:
                    readable, _, _ = select.select([self.request, remote], [], [], 660)
                    if not readable:
                        return
                    for source in readable:
                        data = source.recv(65536)
                        if not data:
                            return
                        destination = remote if source is self.request else self.request
                        destination.sendall(data)
        except OSError:
            pass


def create(path, port):
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("Unexpected local gateway port")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError("Never overwrite a live or stale IPC endpoint")
    server = Server(str(path), Handler)
    server.target_port = port
    path.chmod(0o666)
    return server
