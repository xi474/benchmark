"""Fingerprint completed, consecutive model turns without recording their text."""
import hashlib
import json

LIMIT = 6
RESPONSES_CALLS = {"function_call", "custom_tool_call"}
RESPONSES_RESULTS = {"function_call_output", "custom_tool_call_output"}


def normalized(value):
    if isinstance(value, str):
        return value.replace("\r\n", "\n").strip()
    if isinstance(value, list):
        return [normalized(item) for item in value]
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items()
                if key not in {"call_id", "tool_call_id", "tool_use_id"}}
    return value


def content_parts(content):
    if isinstance(content, str):
        return [["text", content]] if content.strip() else []
    result = []
    for item in content or []:
        kind = item.get("type") if isinstance(item, dict) else None
        if kind in {"text", "output_text"}:
            result.append(["text", item.get("text")])
        elif kind == "tool_use":
            result.append(["call", item.get("name"), item.get("input")])
        elif kind == "tool_result":
            result.append(["result", item.get("content"), item.get("is_error", False)])
    return result


def call_parts(calls):
    return [["call", call.get("function", {}).get("name"), call.get("function", {}).get("arguments")]
            for call in calls]


def completed_turns(payload, responses):
    messages = payload.get("input") if responses else payload.get("messages")
    if not isinstance(messages, list):
        return []
    turns = []
    current = []
    for item in messages:
        if not isinstance(item, dict):
            continue
        role, kind = item.get("role"), item.get("type")
        if role == "assistant":
            if current:
                turns.append(current)
            current = content_parts(item.get("content")) + call_parts(item.get("tool_calls") or [])
        elif responses and kind in RESPONSES_CALLS:
            current.append(["call", item.get("name"), item.get("arguments", item.get("input"))])
        elif responses and kind in RESPONSES_RESULTS:
            current.append(["result", item.get("output")])
        elif role == "tool" and current:
            current.append(["result", item.get("name"), item.get("content")])
        elif role == "user":
            results = [part for part in content_parts(item.get("content")) if part[0] == "result"]
            if current and results:
                current.extend(results)
            elif current:
                # A new user intervention starts a different conversation segment.
                turns.clear()
                current = []
        elif role in {"system", "developer"} and current:
            turns.clear()
            current = []
        if responses and current[-1:] and current[-1][0] == "result":
            # Responses serializes each tool result as a separate item.
            # Finish the turn on the next call/message so all parallel results count.
            continue
    if current:
        turns.append(current)
    if responses:
        turns = split_responses_turns(turns)
    return turns


def split_responses_turns(turns):
    result = []
    for turn in turns:
        group = []
        for part in turn:
            if part[0] in {"call", "text"} and group and group[-1][0] == "result":
                result.append(group)
                group = []
            group.append(part)
        if group:
            result.append(group)
    return result


def same_tail(payload, responses):
    tail = completed_turns(payload, responses)[-LIMIT:]
    if len(tail) != LIMIT:
        return None
    encoded = [json.dumps(normalized(turn), sort_keys=True, ensure_ascii=False) for turn in tail]
    if len(set(encoded)) == 1:
        return hashlib.sha256(encoded[0].encode()).hexdigest()
    return None
