"""Test the local gateway route inside the exact Harbor actor environment."""
from pathlib import Path
import shlex

from harbor.agents.base import BaseAgent


class RouteProbe(BaseAgent):
    @staticmethod
    def name():
        return "upstream59-local-route-probe"

    def version(self):
        return "1"

    async def setup(self, environment):
        pass

    async def run(self, instruction, environment, context):
        await environment.exec(command="mkdir -p /installed-agent /logs/agent")
        await environment.upload_file(Path(__file__).with_name("unix_tcp_bridge.py"), "/installed-agent/u59-ipc.py")
        await environment.exec(command="nohup python3 /installed-agent/u59-ipc.py > /logs/agent/u59-ipc.log 2>&1 & sleep 0.4")
        code = """import urllib.request
with urllib.request.urlopen('http://127.0.0.1:19005/check.txt',timeout=5) as res:
 assert res.read().strip() == b'u59-ready'
 print('Harbor actor verified local IPC')
"""
        path = Path(self.logs_dir) / "route-report.txt"
        checked = await environment.exec(command="python3 -B -c " + shlex.quote(code), cwd="/app")
        path.write_text(f"{checked.return_code}\n{checked.stdout}\n{checked.stderr}\n", encoding="utf-8")
        if checked.return_code:
            raise RuntimeError("Local IPC probe failed")
