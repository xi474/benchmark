"""Run the frozen Upstream59 V4 Pro continuation, with per-trial loop isolation."""
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from zipfile import ZipFile

from boundary_credit import BoundaryCredit
from bridge import NormalGateway, NormalHandler
from host_unix_bridge import create as create_ipc
from loop_guard import LIMIT, same_tail
from matrix_budget import MatrixBudget, MatrixHandler
from native_evidence_batch import native
from provider_transport import install as install_provider_transport
from study_gateway import atomic_json

ROOT = Path(__file__).resolve().parent
HARBOR = "local-artifacts://wsl-home/.local/bin/harbor"
PORT = 19325
HARBOR_CAPACITY = 6
IMAGE = "upstream59-v4pro-tools:offline-r1"
CLASSES = {"codex": "Codex", "dsh": "Dsh", "opencode": "OpenCode", "langgraph": "LangGraph",
           "latte-planning-adapted": "Latte", "nanobot": "Nanobot"}
LOOP = "six-consecutive-identical-turns"
ARCHIVE = "a063237998141238ba2357ca8fce70d60d55f18dded17da533830c06c75d7135"
ISOLATABLE = {
    "transport-URLError", "transport-TimeoutError", "transport-ConnectionResetError",
    "transport-ConnectionAbortedError", "transport-RemoteDisconnected", "transport-IncompleteRead",
    "transport-BrokenPipeError", "missing-final-input-output", "upstream-http-429",
    "upstream-http-500", "upstream-http-502", "upstream-http-503", "upstream-http-504",
}


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


class BatchBudget(MatrixBudget):
    def __init__(self, root, trials):
        self.transport_recovery = None
        super().__init__(root, trials)
        self.limit = Decimal("Infinity")
        self.persist()

    def snapshot(self):
        data = super().snapshot()
        data["budget_usd"] = None
        data["batch_budget_unlimited"] = True
        return data

    def unknown(self, ticket, trial, reason):
        if reason not in ISOLATABLE or self.transport_recovery is None:
            return super().unknown(ticket, trial, reason)
        with self.lock:
            if ticket not in self.pending or ticket in self.unknown_tickets:
                return
            self.unknown_tickets.add(ticket)
            self.quarantined_tickets.add(ticket)
            self.unknown_count += 1
            self.blocked_trials.add(trial)
            self.blocked_reasons[trial] = "unknown-usage:" + reason
            self.transport_recovery.hold(reason)
            self.receipt(dict(type="unknown", request_id=ticket, trial_id=trial,
                              reason=reason, reservation_retained=True, isolated=True,
                              will_retry_model_request=False))
            self.persist()
            self.changed.notify_all()


class TransientCredit(BoundaryCredit):
    def fetch(self, force=False):
        with self.lock:
            if self.balance is not None and not force and time.monotonic() - self.last < 5:
                return self.balance
            request = urllib.request.Request("https://api.deepseek.com/user/balance",
                                             headers={"Authorization": "Bearer " + self.key})
            try:
                with urllib.request.urlopen(request, timeout=15) as response:
                    balance = json.load(response)
            except (OSError, ValueError) as error:
                balance = {"is_available": None, "balance_infos": [],
                           "error_type": type(error).__name__, "http_status": getattr(error, "code", None)}
            self.balance, self.last = balance, time.monotonic()
            with (self.root / "credit-boundary-events.jsonl").open("a", encoding="utf-8") as file:
                file.write(json.dumps(dict(time=time.time(), type="balance-readonly", model_requests=0,
                                           is_available=balance.get("is_available"),
                                           error_type=balance.get("error_type"),
                                           http_status=balance.get("http_status"))) + "\n")
            return balance


class TransportRecovery:
    def __init__(self, budget, credit):
        self.budget, self.credit = budget, credit
        self.lock = threading.Lock()
        self.probe_lock = threading.Lock()
        self.until = 0
        self.generation = 0

    def hold(self, reason):
        with self.lock:
            self.generation += 1
            self.until = max(self.until, time.monotonic() + (30 if reason == "upstream-http-429" else 8))

    def ready(self, trial=None):
        while not self.budget.stopped and not (self.budget.root / "STOP").exists():
            if trial in self.budget.blocked_trials:
                return False
            with self.lock:
                until = self.until
            if not until:
                return True
            if until > time.monotonic():
                time.sleep(min(2, until - time.monotonic()))
                continue
            with self.probe_lock:
                with self.lock:
                    generation, until = self.generation, self.until
                if not until or until > time.monotonic():
                    continue
                adjudication = self.credit.admit_trial(force=True)
                balance = self.credit.balance
                if balance.get("http_status") in (401, 402, 403):
                    self.budget.stop("provider-balance-http-" + str(balance["http_status"]))
                    return False
                if adjudication["provider_is_available"] is not None and not adjudication["passed"]:
                    self.budget.stop("provider-balance-admission-unavailable")
                    return False
                with self.budget.lock:
                    self.budget.receipt(dict(type="provider-route-readonly-recovery",
                                             recovered=adjudication["passed"], model_requests=0))
                with self.lock:
                    if self.generation == generation:
                        self.until = 0 if adjudication["passed"] else time.monotonic() + 15
        return False

    def admit_request(self, next_upper_usd, pending_upper_usd):
        result = self.credit.admit_request(next_upper_usd, pending_upper_usd)
        if result["provider_is_available"] is None and self.credit.balance.get("http_status") not in (401, 402, 403):
            self.hold("balance-transport-unavailable")
            self.budget.receipt(dict(type="provider-credit-check-delayed-before-reservation", model_requests=0))
            raise RuntimeError("Provider credit probe unavailable before reservation")
        return result


class LoopHandler(NormalHandler):
    def forward_with_slot(self, trial, payload, slot):
        is_responses = self.path.endswith("/responses")
        fingerprint = same_tail(payload, is_responses)
        budget = self.server.budget
        if fingerprint:
            with budget.lock:
                budget.receipt(dict(type="loop-detected-before-send", trial_id=trial, threshold=LIMIT,
                                    fingerprint=fingerprint, provider_send=False, text_saved=False))
                budget.block(trial, LOOP)
            self.answer(400, {"error": {"type": "invalid_request_error",
                                       "message": "Trial stopped after six identical turns. Request not sent."}})
            return
        recovery = getattr(budget, "transport_recovery", None)
        if recovery is not None and not recovery.ready(trial):
            self.answer(503, {"error": "local-admission-closed-before-send"})
            return
        if is_responses:
            return super().forward_with_slot(trial, payload, slot)
        return MatrixHandler.forward_with_slot(self, trial, payload, slot)


def task_dir(task):
    assert re.fullmatch(r"[A-Z]+\d+", task)
    return ROOT / "tasks" / task


def extract(plan, *, archive_name="capstone-upstream59-v2.0.0.zip", archive_sha=ARCHIVE):
    zip_path = ROOT / archive_name
    assert digest(zip_path.read_bytes()) == archive_sha
    tasks = {r["task_id"]: r for r in plan}
    (ROOT / "release-scoring").mkdir()
    with ZipFile(zip_path) as archive:
        for item in archive.infolist():
            rel = Path(item.filename)
            assert not rel.is_absolute() and ".." not in rel.parts
            parts = rel.parts
            if item.is_dir() or not parts:
                continue
            if parts[0] == "scoring":
                target = ROOT / "release-scoring" / Path(*parts[1:])
            elif parts[0] == "tasks" and parts[1] in tasks and parts[2] != "solution":
                target = task_dir(parts[1]) / Path(*parts[2:])
            else:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(item))
            target.chmod((item.external_attr >> 16) & 0o777)
    for task, row in tasks.items():
        folder = task_dir(task)
        assert digest((folder / "instruction.md").read_bytes()) == row["instruction_sha256"]
        assert digest((folder / "tests/release-registry.json").read_bytes()) == row["registry_sha256"]
        dockerfile = folder / "environment/Dockerfile"
        released = b"ARG BENCH_BASE=capstone-upstream59:2.0\n"
        data = dockerfile.read_bytes()
        assert data.count(released) == 1
        dockerfile.write_bytes(data.replace(released, f"ARG BENCH_BASE={IMAGE}\n".encode()))


def trial_config(cell):
    return {
        "job_name": cell["trial_id"], "jobs_dir": str(ROOT / "jobs"),
        "n_attempts": 1, "n_concurrent_trials": 1, "retry": {"max_retries": 0},
        "environment": {"type": "docker"},
        "agents": [{"import_path": "published_agents:" + CLASSES[cell["harness"]],
                    "model_name": ("local/" if cell["harness"] == "opencode" else "openai/") + "deepseek-v4-pro",
                    "override_setup_timeout_sec": 600}],
        "tasks": [{"path": str(task_dir(cell["task_id"]))}],
    }


def trial_env(cell, token):
    base = "http://127.0.0.1:19005"
    return {
        "PATH": "local-artifacts://wsl-home/.local/bin:/usr/local/bin:/usr/bin:/bin",
        "HOME": "/home/horace", "LANG": "C.UTF-8", "PYTHONPATH": os.environ["PYTHONPATH"],
        "PYTHONUNBUFFERED": "1", "PYTHON_DOTENV_DISABLED": "1", "DO_NOT_TRACK": "1",
        "COMPOSE_BAKE": "false", "ANONYMIZED_TELEMETRY": "false",
        "STUDY_PROXY_BASE": base, "BATCH_PROXY_BASE": base, "STUDY_PROXY_TOKEN": token, "BATCH_PROXY_TOKEN": token,
        "BATCH_REQUIRE_LATTE": "1", "HARNESS_LATTE_PLANNING_AUTHORIZED": "1", "HARNESS_LATTE_NATIVE": "1",
        "U59_GATEWAY": base, "NO_PROXY": "127.0.0.1,localhost", "no_proxy": "127.0.0.1,localhost",
        "HARD3_USE_UNIX_INGRESS": "1", "HARD3_HOST_SOCKET": str(ROOT / "ingress/live.sock"),
        "HARNESS_REQUIRE_RUNTIME_SNAPSHOTS": "1", "HARNESS_TASK_ID": cell["task_id"],
        "HARNESS_RUN_ID": cell["trial_id"], "HARNESS_LANGGRAPH_PARALLEL_PLAN": "1",
        "HARNESS_DSH_CONDITION": "neutral", "U59_TASK_DIR": str(task_dir(cell["task_id"])),
        "HARNESS_API_KEY": token, "OPENAI_API_KEY": token, "DEEPSEEK_API_KEY": token,
    }


def score_receipt(cell, parent, result, settled):
    from score_attempt import evaluate

    reg = read(task_dir(cell["task_id"]) / "tests/release-registry.json")
    raw = parent / "verifier/raw-checks.json"
    score_path = parent / "verifier/score.json"
    if not (raw.is_file() and score_path.is_file()):
        return {}
    score = evaluate(reg, read(raw))
    assert score == read(score_path)
    harbor_score = ((result.get("verifier_result") or {}).get("rewards") or {}).get("reward")
    assert harbor_score is not None and Decimal(str(harbor_score)) == Decimal(score["reward"])
    if settled:
        return {"score": score, "score_sha256": digest(score_path.read_bytes())}
    return {"verifier_on_zero_request_workspace": score["reward"]}


def audit(cell, returncode, budget):
    tid, harness = cell["trial_id"], cell["harness"]
    paths = list((ROOT / "jobs" / tid).glob("*/result.json"))
    out = {"trial_id": tid, "harness": harness, "task_id": cell["task_id"],
           "returncode": returncode, "score": None, "technical_passed": False,
           "budget_stop": budget.blocked_reasons.get(tid)}
    if len(paths) != 1:
        return out
    parent = paths[0].parent
    result = read(paths[0])
    exception = result.get("exception_info") or {}
    out.update(result_file=str(paths[0]), terminal=exception.get("exception_type"),
               local_gateway_unreachable="Trial gateway health failed" in str(exception.get("exception_message", "")))
    ledger_path = ROOT / "gateway-requests.jsonl"
    receipts = [json.loads(line) for line in ledger_path.read_text(encoding="utf-8").splitlines()] if ledger_path.exists() else []
    by_trial = [row for row in receipts if row.get("trial_id") == tid]
    observed = [row for row in by_trial if row.get("type") == "request-observation"]
    settled = {row["request_id"] for row in by_trial if row.get("type") == "settled"}
    unknown = {row["request_id"] for row in by_trial if row.get("type") == "unknown"}
    out.update(requests_settled=len(settled), requests_unknown=len(unknown),
               cost_estimated_usd=float(budget.costs[tid]))
    agent = parent / "agent"
    resource = agent / "native-resources.csv"
    if harness == "latte-planning-adapted":
        event_file = agent / "latte-events.jsonl"
        out["native"] = {"root_known": event_file.is_file() and event_file.stat().st_size > 0, "child_count": None}
    else:
        out["native"] = native(agent, harness, observed)
    out.update(score_receipt(cell, parent, result, settled))
    bridge = [row for row in by_trial if row.get("type") == "bridge-egress-observation"]
    mode = bool(observed) and all(row.get("model") == "deepseek-v4-pro"
                                  and (row.get("thinking_type") == "disabled"
                                       or row.get("reasoning_effort") == "none") for row in observed)
    if harness == "codex":
        mode = mode and bool(bridge) and all(row.get("thinking_type") == "disabled" for row in bridge)
    out.update(actual_mode_verified=mode, resource_observed=resource.is_file() and resource.stat().st_size > 40,
               configured_snapshot=(agent / "native-configured-capabilities.json").is_file(),
               request_tools_and_prompt_observed=bool(observed) and all("tools" in row and row.get("prompt_fingerprints")
                                                                        for row in observed))
    out["audited_score_and_mode"] = bool(out["score"] and settled and out["native"]["root_known"] and
                                         all(out[key] for key in ("actual_mode_verified", "resource_observed",
                                                                 "configured_snapshot", "request_tools_and_prompt_observed")))
    out["technical_passed"] = out["audited_score_and_mode"] and not unknown
    return out


class Controller:
    def __init__(self, pending, budget, gateway, credit, carried):
        self.pending, self.budget, self.gateway, self.credit = pending, budget, gateway, credit
        self.lock = threading.RLock()
        self.active, self.outcomes = {}, {}
        self.pilot = {h: "pending" for h in CLASSES}
        self.pilot.update({row["harness"]: "passed-after-isolated-transport" for row in carried})

    def status(self, phase):
        with self.lock:
            atomic_json(ROOT / "paid-status.json", {"phase": phase, "pid": os.getpid(), "reused": 150,
                        "scored_carried": 1, "harbor_capacity": HARBOR_CAPACITY,
                        "planned_new": len(self.pending), "finished_attempts": len(self.outcomes),
                        "scored": sum(out.get("score") is not None for out in self.outcomes.values()),
                        "active": self.active, "pilots": self.pilot, "ledger": self.budget.snapshot()})

    def one(self, cell):
        tid = cell["trial_id"]
        if not self.budget.transport_recovery.ready():
            return
        while not self.credit.admit_trial(force=True)["passed"]:
            if self.credit.balance.get("is_available") is not None or self.credit.balance.get("http_status") in (401, 402, 403):
                self.budget.stop("provider-balance-admission-unavailable")
                return
            self.budget.transport_recovery.hold("balance-transport-unavailable")
            if not self.budget.transport_recovery.ready():
                return
        with self.lock:
            with (ROOT / "trial-consumption.jsonl").open("a", encoding="utf-8") as file:
                file.write(json.dumps({"trial_id": tid, "time": time.time()}) + "\n")
            self.active[tid] = {"harness": cell["harness"], "started": time.time()}
        config = ROOT / "configs" / (tid + ".json")
        atomic_json(config, trial_config(cell))
        self.gateway.trial_modes[tid] = "normal"
        self.gateway.activate(tid)
        self.status("running")
        try:
            with (ROOT / "console" / (tid + ".log")).open("w", encoding="utf-8") as log:
                cmd = [sys.executable, str(ROOT / "hard3_harbor.py"), "run", "--config", str(config), "--yes"]
                env = trial_env(cell, self.gateway.master + ":" + tid)
                # Gateway admission closes for a blocked cell. Let Harbor finish
                # its grading and capture the existing workspace.
                code = subprocess.run(cmd, cwd="/tmp", env=env, stdout=log,
                                      stderr=subprocess.STDOUT, start_new_session=True).returncode
            deadline = time.monotonic() + 630
            while self.gateway.inflight_for(tid) and time.monotonic() < deadline:
                time.sleep(1)
            if self.gateway.inflight_for(tid):
                self.budget.stop("request-drain-timeout")
            outcome = audit(cell, code, self.budget)
            if outcome.get("local_gateway_unreachable"):
                self.budget.stop("local-container-to-gateway-health-failed")
        except Exception:
            outcome = {"trial_id": tid, "score": None, "technical_passed": False,
                       "terminal": "local-controller-or-audit-error"}
            import traceback
            with (ROOT / "console" / (tid + ".audit.log")).open("w", encoding="utf-8") as log:
                traceback.print_exc(file=log)
        finally:
            self.gateway.deactivate(tid)
        with self.lock:
            self.active.pop(tid)
            self.outcomes[tid] = outcome
            atomic_json(ROOT / "paid-outcomes.json", list(self.outcomes.values()))
        self.status("running")
        return outcome

    def run(self):
        waiting = list(self.pending)
        active = {}
        pilot_replacements = set()
        self.status("starting-six-wide")
        with ThreadPoolExecutor(max_workers=HARBOR_CAPACITY) as pool:
            while waiting or active:
                if not self.budget.stopped and not (ROOT / "STOP").exists():
                    admitted = [row for row in waiting if row["pilot"] or self.pilot[row["harness"]].startswith("passed")]
                    for row in admitted[:HARBOR_CAPACITY - len(active)]:
                        waiting.remove(row)
                        if row["pilot"]:
                            self.pilot[row["harness"]] = "running"
                        active[pool.submit(self.one, row)] = row
                if not active:
                    break
                done, _ = wait(active, return_when=FIRST_COMPLETED)
                for future in done:
                    row = active.pop(future)
                    outcome = future.result() or {}
                    if not row["pilot"]:
                        continue
                    harness = row["harness"]
                    stop = outcome.get("budget_stop") or ""
                    isolated = stop == LOOP or stop.removeprefix("unknown-usage:") in ISOLATABLE
                    if outcome.get("technical_passed"):
                        self.pilot[harness] = "passed"
                    elif isolated and outcome.get("audited_score_and_mode") and not self.budget.stopped:
                        self.pilot[harness] = "passed-after-isolated-transport"
                    else:
                        self.pilot[harness] = "held"
                        if isolated and harness not in pilot_replacements and not self.budget.stopped:
                            next_cell = next((cell for cell in waiting if cell["harness"] == harness), None)
                            if next_cell:
                                next_cell["pilot"] = True
                                waiting.remove(next_cell)
                                waiting.insert(0, next_cell)
                                pilot_replacements.add(harness)
                                self.pilot[harness] = "replacement-pilot-queued"
                    self.status("running")
        self.status("ended")


def main():
    import bridge
    from codex_tool_response import install as install_codex_response_guard

    install_codex_response_guard(bridge)
    plan_path = ROOT / "pending-v4pro-cells.json"
    plan = read(plan_path)
    consent = read(ROOT / "authorization.json")
    assert consent["allow_paid_run"] is True and consent["batch_budget_usd"] is None
    assert consent["plan_sha256"] == digest(plan_path.read_bytes())
    assert read(ROOT / "offline-acceptance.json")["passed"]
    assert len(plan["cells"]) == 203 and plan["regrade_reused_count"] == 150
    carried = read(ROOT / "carried-score.json")
    assert len(carried) == 1 and carried[0]["harness"] == "codex" and carried[0]["task_id"] == "C008"
    assert all((row["harness"], row["task_id"]) != ("codex", "C008") for row in plan["cells"])
    assert len(read(ROOT / "offline-install/receipt.json")["harnesses"]) == 6
    assert not (ROOT / "trial-consumption.jsonl").exists()
    with (ROOT / "paid-controller.lock").open("x") as lock:
        lock.write(str(os.getpid()))
    (ROOT / "configs").mkdir()
    (ROOT / "console").mkdir()
    trials = [dict(row, max_output_tokens=32768) for row in plan["cells"]]
    extract(trials)
    sys.path.insert(0, str(ROOT / "release-scoring"))
    key_path = next(Path("local-artifacts://user-home/Desktop").glob(
        "*/capstone/previous_benchmarks/harness-v3-research/harbor-agents/deepseek.env"))
    key = next(line.split("=", 1)[1].strip().strip("\"'") for line in key_path.read_text(encoding="utf-8-sig").splitlines()
               if line.partition("=")[0].strip() == "HARNESS_API_KEY")
    budget = BatchBudget(ROOT, trials)
    install_provider_transport(lambda row: budget.receipt(row))
    credit = TransientCredit(ROOT, key)
    budget.transport_recovery = TransportRecovery(budget, credit)
    budget.request_credit_guard = budget.transport_recovery.admit_request
    gateway = NormalGateway(("127.0.0.1", PORT), budget, key, secrets.token_hex(32))
    gateway.RequestHandlerClass = LoopHandler
    gateway.scope_guard = lambda: read(ROOT / "authorization.json") == consent
    ipc = create_ipc(ROOT / "ingress/live.sock", PORT)
    service = threading.Thread(target=gateway.serve_forever, daemon=True)
    service.start()
    threading.Thread(target=ipc.serve_forever, daemon=True).start()
    try:
        Controller(trials, budget, gateway, credit, carried).run()
    finally:
        gateway.close_admission()
        gateway.shutdown()
        gateway.server_close()
        ipc.shutdown()
        ipc.server_close()
        budget.persist()


if __name__ == "__main__":
    main()
