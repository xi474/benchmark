"""Freeze the GLM registration and verify the installed runtime with zero provider calls."""

from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import mkdtemp
import threading
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from zipfile import ZipFile

import paid_controller as harbor
from harbor.models.job.config import JobConfig
from repair_controller import TOOL_IMAGE, frozen_registry
from study_gateway import atomic_json
from controller import ROOT, MIRROR, config, digest, env_for, read
from qwen_gateway import ENDPOINT, Gateway, LOOP_REASON


ARCHIVE = "capstone-upstream59-workfiles-v2.1.0.zip"
ARCHIVE_SHA = "a57c75131a14b9860507f91c8d17da9e7a4b79c548ea9f8dfac90806d972f9fc"


def registry():
    precedent = read(ROOT / "deepseek-design.json")
    assert precedent["dataset_sha256"] == ARCHIVE_SHA
    assert digest(ROOT / ARCHIVE) == ARCHIVE_SHA
    cohort = [precedent["changed_tasks"], precedent["unchanged_tasks"]]
    assert tuple(map(len, cohort)) == (30, 29) and len(set(cohort[0] + cohort[1])) == 59
    assert {k.rstrip("0123456789") for k in cohort[0]} == {"C", "MS"}
    assert {k.rstrip("0123456789") for k in cohort[1]} == {"MP", "N"}
    trials = []
    with ZipFile(ROOT / ARCHIVE) as release:
        for group, rows in enumerate(cohort, 1):
            for task in rows:
                instruction = harbor.digest(release.read(f"tasks/{task}/instruction.md"))
                raw = release.read(f"tasks/{task}/tests/release-registry.json")
                weight = {"E": 1, "M": 2, "H": 3}[json.loads(raw)["reward_difficulty"]]
                for harness in harbor.CLASSES:
                    ident = f"u59-v21-qwen38-max-off-{harness}-{task.lower()}"
                    trials.append(dict(cell_id=ident, trial_id=ident, task_id=task, harness=harness,
                                       stage=group, instruction_sha256=instruction,
                                       registry_sha256=harbor.digest(raw), max_reward=weight))
    assert len(trials) == len({c["cell_id"] for c in trials}) == 354
    return {"benchmark": "Upstream59 v2.1.0", "dataset_sha256": ARCHIVE_SHA,
            "scoring_revision": "delivery-bonus-50-v1", "model": "qwen3.8-max",
            "enable_thinking": False, "pilot_cell_id": "u59-v21-qwen38-max-off-opencode-c008",
            "upstream_endpoint": ENDPOINT, "max_concurrent_harbor": 6, "max_concurrent_http": 4,
            "checkpoint_seconds": 300, "identical_turn_stop": 6, "batch_cost_cap_cny": None,
            "forced_delegation": False, "reuse_older_model_results": False,
            "price_cny_per_million": {"input_without_cache_discount": 12, "output": 36},
            "cells": trials}


def offline_gateway(root):
    captured = []

    class Mock(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            captured.append(body)
            assert body["model"] == "qwen3.8-max" and body["enable_thinking"] is False
            assert not any(k in body for k in ("thinking", "reasoning_effort")) and body["max_tokens"] <= 32768
            if len(captured) == 4:
                content = b'{"error":{"code":"1113","message":"test insufficient balance"}}'
                self.send_response(429)
            else:
                common = {"id": "mock", "object": "chat.completion.chunk", "created": 1, "model": "qwen3.8-max"}
                items = [
                    dict(common, choices=[{"index": 0, "delta": {"role": "assistant", "content": "ok"},
                                            "finish_reason": "stop"}]),
                    dict(common, choices=[], usage={"prompt_tokens": 20, "completion_tokens": 4,
                                                     "total_tokens": 24, "prompt_tokens_details": {"cached_tokens": 5}}),
                ]
                content = b"".join(b"data: " + json.dumps(item).encode() + b"\n\n" for item in items) + b"data: [DONE]\n\n"
                self.send_response(200)
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)

    provider = ThreadingHTTPServer(("127.0.0.1", 0), Mock)
    threading.Thread(target=provider.serve_forever, daemon=True).start()
    tids = ["chat", "responses", "anthropic", "loop", "overdue", "held"]
    endpoint = f"http://127.0.0.1:{provider.server_port}/mock"
    gateway = Gateway(root, [{"trial_id": tid} for tid in tids], "synthetic-key", port=0, endpoint=endpoint)
    gateway.start()
    for tid in tids:
        gateway.activate(tid)
    base = f"http://127.0.0.1:{gateway.port}"

    def post(tid, path, extra):
        body = json.dumps(dict(model="qwen3.8-max", stream=False, **extra)).encode()
        req = Request(base + path, data=body, headers={"Content-Type": "application/json",
                                                       "Authorization": "Bearer " + gateway.master + ":" + tid})
        try:
            with urlopen(req, timeout=12) as response:
                return response.status, json.loads(response.read())
        except HTTPError as error:
            return error.code, {}

    try:
        assert json.load(urlopen(base + "/health", timeout=5)) == {"ok": True}
        messages = [{"role": "user", "content": "fixture"}]
        for tid, path, extra in (("chat", "/v1/chat/completions", {"messages": messages, "tools": None}),
                                 ("responses", "/responses", {"input": messages}),
                                 ("anthropic", "/anthropic/v1/messages", {"messages": messages, "max_tokens": 128})):
            status, reply = post(tid, path, extra)
            assert status == 200 and reply["model"] == "qwen3.8-max", (tid, status)
        assert "tools" not in captured[0]
        first = gateway.trial_rows("chat")[0]["request_id"]
        observed = read(root / "request-snapshots" / (first + ".json"))
        assert observed["ingress"]["tools"] is None and observed["egress"]["tools"] == []
        repeat = messages + [{"role": "assistant", "content": "same"}] * 6
        assert post("loop", "/chat/completions", {"messages": repeat})[0] == 400
        assert len(captured) == 3 and gateway.blocked["loop"] == LOOP_REASON
        assert post("overdue", "/chat/completions", {"messages": messages})[0] == 429
        assert gateway.stop_reason == "provider-insufficient-balance"
        assert post("held", "/chat/completions", {"messages": messages})[0] == 400
        assert len(captured) == 4 and gateway.ledger()["unknown"] == 1 and gateway.ledger()["settled"] == 3
    finally:
        gateway.close()
        provider.shutdown()
        provider.server_close()
    return {"passed": True, "loop_blocked_before_send": True, "http_429_1113_halted": True,
            "explicit_null_tools_observed_then_omitted": True,
            "local_mock_requests": 4, "paid_requests": 0}


def install_check(cell, scratch):
    trial_id = "offline-qwen-" + cell["harness"]
    entry = dict(cell, trial_id=trial_id)
    cfg = scratch / (trial_id + ".json")
    atomic_json(cfg, config(entry, scratch, install_only=True))
    env = env_for(entry, "fixture-only", scratch)
    env.update(HARD3_USE_UNIX_INGRESS="0", STUDY_PROXY_BASE="http://127.0.0.1:9",
               BATCH_PROXY_BASE="http://127.0.0.1:9", CODEX_GLM_GATEWAY_BASE_URL="http://127.0.0.1:9")
    with (scratch / (trial_id + ".log")).open("w") as log:
        status = subprocess.run([sys.executable, str(ROOT / "hard3_harbor.py"), "run", "--config", str(cfg), "--yes"],
                                cwd="/tmp", env=env, timeout=900,
                                stdout=log, stderr=subprocess.STDOUT).returncode
    matches = list((scratch / "jobs" / trial_id).glob("*/result.json"))
    exception = (read(matches[0]).get("exception_info") or {}).get("exception_type") if len(matches)==1 else None
    return cell["harness"], {"passed": status == 0 and len(matches) == 1 and not exception,
                             "returncode": status, "exception_type": exception}


def main():
    harbor.ROOT = ROOT
    harbor.IMAGE = TOOL_IMAGE
    manifest = registry()
    atomic_json(ROOT / "manifest.json", manifest)
    atomic_json(MIRROR / "manifest.json", manifest)
    trials = manifest["cells"]
    if not (ROOT / "tasks").exists():
        harbor.extract(trials, archive_name=ARCHIVE, archive_sha=ARCHIVE_SHA)
    frozen_registry(trials, ROOT, ARCHIVE)
    scratch = Path(mkdtemp(prefix="offline-", dir=ROOT))
    for cell in trials:
        JobConfig.model_validate(config(cell, scratch))
    fixture = offline_gateway(scratch / "protocol-fixture")
    image = subprocess.check_output(["docker", "image", "inspect", "--format", "{{.Id}}", TOOL_IMAGE], text=True).strip()
    assert image == read(ROOT / "deepseek-offline-acceptance.json")["tool_image_id"]
    pilots = [row for row in trials if row["task_id"] == "C008"]
    with ThreadPoolExecutor(max_workers=3) as pool:
        installs = dict(pool.map(lambda c: install_check(c, scratch), pilots))
    route = None
    if all(x["passed"] for x in installs.values()):
        import prepare_repair
        prepare_repair.ROOT = ROOT
        (scratch / "tasks").symlink_to(ROOT / "tasks", target_is_directory=True)
        harbor.ROOT, harbor.PORT = scratch, 19326
        route = prepare_repair.route_check(scratch, next(c for c in pilots if c["harness"] == "opencode"))
    result = {"passed": len(installs) == 6 and all(x["passed"] for x in installs.values()), "provider_requests": 0,
              "manifest_sha256": digest(ROOT / "manifest.json"), "config_count": len(trials),
              "image_id": image, "installs": installs, "protocol_fixture": fixture, "harbor_ipc_receipt": route}
    atomic_json(ROOT / "offline-acceptance.json", result)
    atomic_json(MIRROR / "offline-acceptance.json", result)
    if not result["passed"]:
        raise SystemExit("Offline adapter installation failed")


if __name__ == "__main__":
    main()
