"""Freeze the 35-cell repair plan and verify both adapters with zero model sends."""

from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
from pathlib import Path
import subprocess
import sys
from tempfile import mkdtemp
import threading

from harbor.models.job.config import JobConfig

import paid_controller as core
from repair_controller import BRIDGE_VERSION, PILOTS, PLAN, R5, ROOT, TOOL_IMAGE
from repair_controller import VERIFIER_IMAGE, frozen_registry, setup_core, write


def repair_plan():
    assert core.read(R5 / "paid-status.json")["phase"] == "ended"
    previous = core.read(R5 / "pending-v4pro-cells.json")
    assert previous["model"] == "deepseek-v4-pro" and previous["thinking"] == {"type": "disabled"}
    assert previous["source_commit"] == "983fea412e32906e7e0f573ae1a8dd8972e4055c"
    assert previous["scoring_revision"] == "delivery-bonus-50-v1"
    candidates = [row for row in previous["cells"] if row["harness"] == "latte-planning-adapted"
                  or (row["harness"], row["task_id"]) == ("codex", "C011")]
    assert len(candidates) == 35
    outcomes = {row["trial_id"]: row for row in core.read(R5 / "paid-outcomes.json")}
    plan = []
    for row in candidates:
        old = row["trial_id"]
        (original,) = (R5 / "jobs" / old).glob("*/result.json")
        if row["harness"] == "latte-planning-adapted":
            exception = core.read(original)["exception_info"]["exception_message"]
            assert "No such file or directory: 'pytest'" in exception
            cause = "latte-pytest-not-in-path"
        else:
            assert outcomes[old]["budget_stop"] == "bridge-post-settlement-encoding-error"
            cause = "codex-truncated-tool-response"
        plan.append({
            "trial_id": old.replace("-r5-", "-r6-"), "task_id": row["task_id"], "harness": row["harness"],
            "pilot": (row["harness"], row["task_id"]) in PILOTS, "previous_attempt": old,
            "previous_result_sha256": core.digest(original.read_bytes()), "repair_reason": cause,
            "instruction_sha256": row["instruction_sha256"], "registry_sha256": row["registry_sha256"],
            "max_reward": row["max_reward"], "max_output_tokens": 32768,
        })
    assert sum(row["pilot"] for row in plan) == 2
    return plan


def install_check(scratch, cell):
    config = core.trial_config(cell)
    harness = cell["harness"]
    label = "u59-r6-install-" + harness
    config.update(job_name=label, install_only=True, jobs_dir=str(scratch / "jobs"))
    path = scratch / (label + ".json")
    write(path, config)
    env = core.trial_env(cell, "local-install-only")
    env["HARD3_USE_UNIX_INGRESS"] = "0"
    env["STUDY_PROXY_BASE"] = env["BATCH_PROXY_BASE"] = "http://127.0.0.1:9"
    with path.with_suffix(".log").open("x") as log:
        result = subprocess.run([sys.executable, str(ROOT / "hard3_harbor.py"), "run", "--config", str(path), "--yes"],
                                cwd="/tmp", env=env, timeout=900, stdout=log, stderr=subprocess.STDOUT)
    (raw,) = (scratch / "jobs" / label).glob("*/result.json")
    assert result.returncode == 0 and not core.read(raw).get("exception_info"), harness
    if harness == "latte-planning-adapted":
        assert core.read(raw.parent / "agent/latte-pytest-preflight.json")["passed"] is True
    return harness, {"passed": True, "result_file": str(raw)}


class RouteFixture(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != "/check.txt":
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Length", "9")
        self.end_headers()
        self.wfile.write(b"u59-ready")


def route_check(scratch, cell):
    label = "u59-r6-offline-ipc"
    config = core.trial_config(cell)
    config.update(job_name=label, jobs_dir=str(scratch / "jobs"))
    config["agents"][0]["import_path"] = "network_fixture:RouteProbe"
    path = scratch / (label + ".json")
    write(path, config)
    env = core.trial_env(cell, "fixture-no-provider")
    with HTTPServer(("127.0.0.1", core.PORT), RouteFixture) as target:
        ipc = core.create_ipc(scratch / "ingress/live.sock", target.server_port)
        threading.Thread(target=target.serve_forever, daemon=True).start()
        threading.Thread(target=ipc.serve_forever, daemon=True).start()
        try:
            with path.with_suffix(".log").open("x") as log:
                subprocess.run([sys.executable, str(ROOT / "hard3_harbor.py"), "run", "--config", str(path), "--yes"],
                               cwd="/tmp", env=env, timeout=900, check=True, stdout=log, stderr=subprocess.STDOUT)
        finally:
            ipc.shutdown()
            ipc.server_close()
            target.shutdown()
    (receipt,) = (scratch / "jobs" / label).glob("*/agent/route-report.txt")
    assert "Harbor actor verified local IPC" in receipt.read_text()
    return str(receipt)


def main():
    plan = repair_plan()
    write(PLAN, plan)
    scratch = Path(mkdtemp(prefix="pre-", dir=ROOT))
    os.link(ROOT / "capstone-upstream59-v2.0.0.zip", scratch / "capstone-upstream59-v2.0.0.zip")
    setup_core(scratch)
    core.extract(plan)
    frozen_registry(plan, scratch)
    for cell in plan:
        JobConfig.model_validate(core.trial_config(cell))
    tests = subprocess.run([sys.executable, "-B", "-m", "unittest", "-v",
                            "test_codex_tool_response", "test_loop_guard"], cwd=ROOT, check=True)
    pytest_probe = ROOT / "latte_pytest_probe.py"
    subprocess.run(["docker", "run", "--rm", "--pull=never", "--network=none",
                    "--entrypoint", "/opt/latte-venv/bin/python", "-e", "PYTHONPATH=/opt/latte",
                    "-v", f"{pytest_probe}:/tmp/probe.py:ro", TOOL_IMAGE, "-B", "/tmp/probe.py"], check=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        installs = dict(pool.map(lambda cell: install_check(scratch, cell),
                                 (cell for cell in plan if cell["pilot"])))
    route = route_check(scratch, next(cell for cell in plan if cell["harness"] == "codex"))
    plan_sha = core.digest(PLAN.read_bytes())
    write(ROOT / "offline-acceptance.json", {
        "passed": True, "provider_requests": 0, "plan_sha256": plan_sha, "configs": len(plan),
        "verifier_byte_identity": True, "verifier_image": VERIFIER_IMAGE, "tool_image": TOOL_IMAGE,
        "tool_image_id": (ROOT / "image-id.txt").read_text().strip(), "bridge_version": BRIDGE_VERSION,
        "bridge_and_loop_test_exit_code": tests.returncode, "latte_real_self_check_fixture": ["pass", "fail"],
        "harbor_install_checks": installs, "harbor_ipc_route_receipt": route,
    })
    write(ROOT / "authorization.json", {
        "allow_paid_run": True, "authorized_scope": "v2.0.0 LATTE 34 and Codex C011",
        "plan_sha256": plan_sha, "scope_origin": "user chat authorization 2026-11-21",
        "model": "deepseek-v4-pro", "thinking": "disabled", "batch_budget_usd": None,
        "max_harbor_concurrency": 6, "max_http_concurrency": 4, "same_complete_turn_limit": 6,
        "model_trials": 35, "paid_retries": 0,
    })


if __name__ == "__main__":
    main()
