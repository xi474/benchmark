"""Recover DNS before transmitting model requests, preserving TLS host validation."""
import http.client
import socket
import threading
import time
import urllib.request

HOST = "api.deepseek.com"


class ProviderDNSUnavailable(OSError):
    pass


class ProviderDNS:
    def __init__(self, event, resolve=socket.getaddrinfo, sleep=time.sleep, clock=time.monotonic):
        self.event, self.resolve, self.sleep, self.clock = event, resolve, sleep, clock
        self.addresses = None
        self.resolved_at = 0
        self.lock = threading.Lock()

    def lookup(self, port):
        with self.lock:
            if self.addresses and self.clock() - self.resolved_at < 60:
                return self.addresses
            for delay in (0, 1, 3, 6):
                if delay:
                    self.sleep(delay)
                try:
                    addresses = self.resolve(HOST, port, type=socket.SOCK_STREAM)
                except socket.gaierror as error:
                    self.event({"type": "provider-dns-pre-connect-recovery", "errno": error.errno,
                                "attempt_delay_seconds": delay, "paid_request_retried": False})
                else:
                    if addresses:
                        self.resolved_at = self.clock()
                        self.addresses = addresses
                        return addresses
            if self.addresses and self.clock() - self.resolved_at < 600:
                self.event({"type": "provider-dns-using-recent-address", "tls_host": HOST})
                return self.addresses
            raise ProviderDNSUnavailable("Provider DNS still unavailable before a connection was opened")

    def connect(self, endpoint, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None):
        if endpoint != (HOST, 443):
            raise ValueError("Only the registered HTTPS provider endpoint is allowed")
        error = None
        for family, sock_type, protocol, _, address in self.lookup(endpoint[1]):
            connection = socket.socket(family, sock_type, protocol)
            try:
                if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
                    connection.settimeout(min(timeout, 12) if timeout is not None else 12)
                if source_address:
                    connection.bind(source_address)
                connection.connect(address)
                # The TLS handshake and HTTP keep their normal timeouts.
                if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
                    connection.settimeout(timeout)
                return connection
            except OSError as error_at_address:
                error = error_at_address
                connection.close()
        raise error or ProviderDNSUnavailable("Provider DNS had no usable address")


class ProviderHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, dns):
        super().__init__()
        self.dns = dns

    def https_open(self, request):
        def connection(host, **kwargs):
            result = http.client.HTTPSConnection(host, **kwargs)
            result._create_connection = self.dns.connect
            return result

        return self.do_open(connection, request, context=self._context)


class NoProviderRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def install(event):
    # Both existing adapters share urllib in this one controller process.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                         ProviderHTTPSHandler(ProviderDNS(event)), NoProviderRedirect())
    urllib.request.install_opener(opener)
