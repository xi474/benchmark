"""Provider bindings for the published Upstream59 workspace."""

import os

from harbor_agents.cli_agents import OpenCodeAgent
from harbor_agents.dsh_agent import DshAgentTeamAgent
from harbor_agents.qwen_codex import GlmLowCodexAgent
from harbor_agents.langgraph_agent import LangGraphAgent
from harbor_agents.nanobot_agent import NanobotAgent
from harbor_adapter.native_planning_agent import NativePlanningLatteAgent


class Routed:
    endpoint_suffix = "/v1"

    def _get_env(self, name, *alternatives):
        if name in {"CODEX_AUTH_JSON_PATH", "CODEX_FORCE_AUTH_JSON", "HARNESS_DELEGATION_POLICY_FILE"}:
            return None
        if name in {"HARNESS_API_KEY", "OPENAI_API_KEY", "DEEPSEEK_API_KEY", "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"}:
            return os.environ["STUDY_PROXY_TOKEN"]
        if name in {"HARNESS_BASE_URL", "OPENAI_BASE_URL", "DEEPSEEK_BASE_URL", "ANTHROPIC_BASE_URL"}:
            return os.environ["STUDY_PROXY_BASE"] + self.endpoint_suffix
        if name == "HARNESS_LANGGRAPH_DISABLE_THINKING":
            return "0"
        return super()._get_env(name, *alternatives)


class NativeCodex(GlmLowCodexAgent):
    async def install(self, environment):
        class VersionProbe:
            def __getattr__(self, name):
                return getattr(environment, name)

            async def exec(self, command, *args, **kwargs):
                # This preinstalled image emits an arg0 cache warning on stderr.
                # Capture the version line without relaxing the pin.
                if command == "codex --version":
                    command = "/usr/bin/codex --version 2>/dev/null"
                return await environment.exec(command, *args, **kwargs)

        await super().install(VersionProbe())


class NativeDsh(Routed, DshAgentTeamAgent):
    endpoint_suffix = "/anthropic"


class NativeLangGraph(Routed, LangGraphAgent):
    pass


class NativeNanobot(Routed, NanobotAgent):
    pass


class BatchLatte(Routed, NativePlanningLatteAgent):
    pass


class NativeOpenCode(Routed, OpenCodeAgent):
    def __init__(self, *args, **kwargs):
        kwargs["opencode_config"] = {
            "$schema": "https://opencode.ai/config.json",
            "model": "local/qwen3.8-max",
            "small_model": "local/qwen3.8-max",
            "provider": {"local": {
                "npm": "@ai-sdk/openai-compatible",
                "name": "Qwen3.8 Max non-thinking",
                "options": {"baseURL": os.environ["STUDY_PROXY_BASE"] + self.endpoint_suffix,
                            "apiKey": os.environ["STUDY_PROXY_TOKEN"]},
                "models": {"qwen3.8-max": {"name": "Qwen3.8 Max non-thinking",
                                      "limit": {"context": 1048576, "output": 8192}}},
            }},
        }
        super().__init__(*args, **kwargs)

    async def exec_as_agent(self, environment, *, command, **kwargs):
        if "opencode --model=" in command and " run --format=json " in command:
            before, separator, output = command.partition(" 2>&1 </dev/null | stdbuf -oL tee ")
            if not separator or output.strip() != "/logs/agent/opencode.txt":
                raise RuntimeError("Unexpected OpenCode output command")
            command = before + " </dev/null > " + output + " 2>&1"
        return await super().exec_as_agent(environment, command=command, **kwargs)
