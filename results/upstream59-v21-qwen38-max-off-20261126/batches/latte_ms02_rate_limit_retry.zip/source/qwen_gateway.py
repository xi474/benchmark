"""Upstream59 policy gates around the shared GLM 1.0.0 protocol bridge."""

from http.server import ThreadingHTTPServer
from io import BytesIO
import json
from types import SimpleNamespace
import urllib.error
import urllib.request

from harbor_agents.glm_codex_bridge import gateway as shared
from loop_guard import LIMIT, same_tail


ENDPOINT = "https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1/chat/completions"
OUTPUT_LIMIT = 32768
TRIAL_TOKENS = 2000000
LOOP_REASON = "six-consecutive-identical-turns"
TOKEN_REASON = "observed-token-cap"
_translate = shared.to_chat
class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        return None

_open = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirects()).open


def translate(payload, protocol):
    body, registry = _translate(payload, protocol)
    body["max_tokens"] = min(body["max_tokens"], OUTPUT_LIMIT)
    for field in ("thinking", "reasoning", "reasoning_effort", "thinking_budget", "tool_stream"):
        body.pop(field, None)
    if body.get("tools") is None:
        body.pop("tools", None)
    fingerprint = same_tail(payload, protocol == "responses") or same_tail(body, False)
    if fingerprint:
        raise ValueError(f"{LOOP_REASON}:{fingerprint}")
    return body, registry


def open_provider(request, **options):
    wire = json.loads(request.data)
    if (wire.get("model") != "qwen3.8-max" or wire.get("enable_thinking") is not False
            or any(name in wire for name in ("thinking", "reasoning", "reasoning_effort", "thinking_budget"))):
        raise ValueError("outbound-mode-guard-rejected")
    try:
        return _open(request, **options)
    except urllib.error.HTTPError as error:
        code = None
        try:
            value = json.loads(error.read(8192))
            candidate = str(value.get("error", {}).get("code"))
            if candidate.isascii() and candidate.isdigit() and len(candidate) <= 8:
                code = candidate
        except (ValueError, OSError, AttributeError):
            pass
        safe = f"provider-http-{error.code}" + (f"-code-{code}" if code else "")
        record = BytesIO(json.dumps({"error": {"message": safe}}).encode())
        raise urllib.error.HTTPError(request.full_url, error.code, safe, error.headers, record) from None


class LoopbackServer(ThreadingHTTPServer):
    def __init__(self, address, handler):
        super().__init__(("127.0.0.1", address[1]), handler)


class Gateway(shared.Gateway):
    def __init__(self, root, trials, key, port=19326, endpoint=ENDPOINT):
        shared.to_chat = translate
        shared.ThreadingHTTPServer = LoopbackServer
        shared.urllib = SimpleNamespace(request=SimpleNamespace(Request=urllib.request.Request, urlopen=open_provider),
                                       error=urllib.error)
        super().__init__(root, {"trials": trials, "upstream_endpoint": endpoint,
                               "per_trial_token_gate": TRIAL_TOKENS}, key, port=port)

    def ledger(self):
        return dict(super().ledger(), batch_cost_cap_cny=None, observed_token_cap_per_trial=TRIAL_TOKENS,
                    loop_guard_rounds=LIMIT, fee_is_invoice=False, billing_route="token-plan",
                    actual_credit_charge=None, actual_billed_cost_cny=None,
                    cost_kind="Beijing list-price upper bound for comparison; actual Token Plan credits unknown")

    def block(self, tid, reason, shared=False):
        if "-code-1113" in reason or "provider-http-402" in reason or "欠费" in reason or "余额不足" in reason:
            reason, shared = "provider-insufficient-balance", True
        elif reason.startswith(LOOP_REASON + ":"):
            self.event({"type": "loop-detected-before-send", "trial_id": tid, "threshold": LIMIT,
                        "fingerprint": reason.split(":", 1)[1], "provider_send": False})
            reason = LOOP_REASON
        if reason.startswith("provider-http-") or reason in {
            "missing-terminal-or-usage", "provider-model-drift", "outbound-mode-guard-rejected"
        }:
            shared = True
        with self.lock:
            if any(row["trial_id"] == tid and row["state"] == "unknown" for row in self.records.values()):
                shared = True
        return super().block(tid, reason, shared=shared)

    def handler_class(self):
        base = super().handler_class()

        class Handler(base):
            def do_GET(self):
                if self.path != "/health":
                    return super().do_GET()
                payload = b'{"ok":true}'
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(payload)
                self.close_connection = True

        return Handler
