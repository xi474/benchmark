"""Harbor adapter for LATTE (local-only benchmark adapter)."""

from __future__ import annotations

import base64
import json
import os
import shlex
import tempfile
from pathlib import Path
from typing import override

from harbor.agents.installed.base import BaseInstalledAgent
from harbor.environments.base import BaseEnvironment
from harbor.models.agent.context import AgentContext

from harbor_agents.common import optional_env, required_secret, split_model_name


class LatteAgent(BaseInstalledAgent):
    """Run LATTE inside the task container against /app."""

    @staticmethod
    @override
    def name() -> str:
        return "latte-frozen"

    @override
    def get_version_command(self) -> str | None:
        return "/opt/latte-venv/bin/python -c 'import openai; print(openai.__version__)'"

    @override
    async def install(self, environment: BaseEnvironment) -> None:
        probe = await environment.exec(command="test -d /opt/latte && test -x /opt/latte-venv/bin/python")
        if probe.return_code != 0:
            raise RuntimeError("harbor-latte image is required: /opt/latte or /opt/latte-venv missing")

    @override
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        _provider, model = split_model_name(self.model_name)
        api_key = "[REDACTED]"(self, "HARNESS_API_KEY")
        base_url = optional_env(self, "HARNESS_BASE_URL") or "https://api.deepseek.com"

        task_dir = "/tmp/latte-task"
        native = str(optional_env(self, "HARNESS_LATTE_NATIVE") or "").lower() in {"1", "true", "yes"}
        await self.exec_as_agent(environment, command=f"mkdir -p {shlex.quote(task_dir)} /tmp/latte-run")
        precompiled = (
            False
            if native
            else (await environment.exec(command="test -f /opt/latte-task/task_description.json")).return_code == 0
        )
        task_file = (
            "/opt/latte-task/task_description.json"
            if precompiled
            else f"{task_dir}/task_description.json"
        )

        readme_probe = await environment.exec(command="cat /app/TASK.md")
        readme = (readme_probe.stdout or "")[:8000]
        description = (
            "You are implementing a local software-engineering task in /app. "
            "Read /app/public_check.py and /app/TASK.md. Implement all missing modules, "
            "run each local check, and do not stop until python3 public_check.py passes. "
            "Do not modify protected files. Do not create diagnostic-only tasks.\n\n"
            "TASK:\n" + instruction + "\n\nREPOSITORY README:\n" + readme
        )
        check_probe = await environment.exec(command="cat /app/public_check.py")
        check_text = check_probe.stdout or ""
        tasks = []
        if not native:
            find_probe = await environment.exec(
                command="find /app -name check_module.py -not -path '*/node_modules/*' | sort"
            )
            component_paths = [line.strip() for line in (find_probe.stdout or "").splitlines() if line.strip()]
            for index, path in enumerate(component_paths, start=1):
                component = path.rsplit("/", 2)[-2]
                task_id = "task-" + "".join(ch if ch.isalnum() else "-" for ch in component).strip("-")
                tasks.append({
                    "id": task_id,
                    "title": f"Implement {component}",
                    "description": (
                        f"Implement the `{component}` component. Read /app/TASK.md, "
                        f"/app/public_check.py, and {path}. Implement all missing modules, run "
                        f"`python3 check_module.py` from the component directory, and "
                        f"do not modify protected files."
                    ),
                    "status": "pending",
                    "owner": None,
                    "assigned_by": None,
                    "priority": index,
                    "dependencies": [],
                    "files": [],
                })
            if not tasks:
                tasks = [{
                    "id": "task-implement",
                    "title": "Implement all required modules and pass public_check.py",
                    "description": (
                        "Inspect /app/TASK.md and /app/public_check.py, implement all missing "
                        "modules, and finish only when python3 public_check.py exits 0."
                    ),
                    "status": "pending",
                    "owner": None,
                    "assigned_by": None,
                    "priority": 1,
                    "dependencies": [],
                    "files": [],
                }]
            if "run_all.py" in check_text or "final_report.py" in check_text:
                dependencies = [task["id"] for task in tasks]
                tasks.append({
                    "id": "task-root-integration",
                    "title": "Implement root run_all.py/final_report.py and pass public_check.py",
                    "description": (
                        "Create /app/run_all.py and /app/final_report.py, run all component "
                        "CLIs in dependency order, and finish only when python3 public_check.py exits 0."
                    ),
                    "status": "pending",
                    "owner": None,
                    "assigned_by": None,
                    "priority": len(tasks) + 1,
                    "dependencies": dependencies,
                    "files": [],
                })
        task = {
            "project": "Harbor LATTE task",
            "description": description,
            "repository": "/app",
            "success_criteria": "python3 public_check.py exits 0 in /app",
            "tasks": tasks,
            "freeze_graph": not native,
            "disable_verify_tasks": not native,
            "auto_complete_checks": not native,
            "root_integration": False,
            "native_dynamic": native,
        }
        test_suite = (
            "import subprocess, sys\n"
            "from pathlib import Path\n"
            "def test_latte_root_check():\n"
            "    root = Path('/app')\n"
            "    result = subprocess.run([sys.executable, 'public_check.py'], cwd=root, capture_output=True, text=True, timeout=180)\n"
            "    assert result.returncode == 0, result.stdout + result.stderr\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            task_path = Path(tmp) / "task_description.json"
            suite_path = Path(tmp) / "test_suite.py"
            task_path.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
            suite_path.write_text(test_suite, encoding="utf-8")
            if not precompiled:
                encoded = base64.b64encode(task_path.read_bytes()).decode("ascii")
                await self.exec_as_agent(
                    environment,
                    command=(
                        f"printf %s {encoded} | base64 -d > {task_dir}/task_description.json; "
                        f"test -s {task_dir}/task_description.json"
                    ),
                )
            await environment.upload_file(suite_path, "/app/test_suite.py")

        env = {
            "OPENAI_API_KEY": api_key,
            "OPENAI_BASE_URL": base_url,
            "LLM_PROVIDER": "openai",
            "LLM_MODEL": model,
        }
        command = (
            "/opt/latte-venv/bin/python /opt/latte/scripts/run_dynamic_pipeline.py "
            f"--tasks {task_file} --repo-dir /app --run-dir /logs/agent/latte-run "
            f"--n 3 --max-rounds 100 --provider openai --model {shlex.quote(model)} "
            "--dynamic-agents"
        )
        run_error = None
        await self.exec_as_agent(
            environment,
            command=(
                "mkdir -p /logs/agent; "
                "nohup sh -c 'while true; do "
                "printf \"%s,\" \"$(date +%s)\"; "
                "cat /sys/fs/cgroup/memory.current 2>/dev/null | tr -d \"\\n\" || true; printf \",\"; "
                "cat /sys/fs/cgroup/cpu.stat 2>/dev/null | head -1 | awk \"{print \\$2}\" || true; "
                "printf \"\\n\"; sleep 1; done' > /logs/agent/latte-resources.csv 2>/dev/null & "
                "echo $! > /logs/agent/latte-sampler.pid"
            ),
            cwd="/opt/latte",
        )
        run_error = None
        try:
            await self.exec_as_agent(environment, command=command, cwd="/opt/latte", env=env)
        except Exception as exc:
            run_error = exc
        finally:
            await self.exec_as_agent(
                environment,
                command=(
                    "mkdir -p /logs/agent; "
                    "if [ -f /logs/agent/latte-run/result.json ]; then cp /logs/agent/latte-run/result.json /logs/agent/latte-result.json; fi; "
                    "if [ -f /logs/agent/latte-run/events.jsonl ]; then cp /logs/agent/latte-run/events.jsonl /logs/agent/latte-events.jsonl; fi; "
                    "if [ -f /logs/agent/latte-run/tasks.json ]; then cp /logs/agent/latte-run/tasks.json /logs/agent/latte-tasks.json; fi; "
                    "if [ -f /logs/agent/latte-sampler.pid ]; then kill $(cat /logs/agent/latte-sampler.pid) 2>/dev/null || true; fi; true"
                ),
                cwd="/opt/latte",
            )

        result_probe = await environment.exec(command="cat /logs/agent/latte-result.json")
        try:
            latte_result = json.loads(result_probe.stdout)
        except Exception:
            latte_result = {}
        context.n_input_tokens = latte_result.get("total_input_tokens")
        context.n_output_tokens = latte_result.get("total_output_tokens")
        context.n_cache_tokens = latte_result.get("total_cache_tokens")
        context.cost_usd = latte_result.get("cost_usd")
        context.metadata = {"latte_result": latte_result}
        if run_error is not None:
            raise run_error
