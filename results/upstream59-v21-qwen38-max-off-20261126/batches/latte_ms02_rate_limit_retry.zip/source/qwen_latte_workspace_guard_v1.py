"""Fail before a model call for the confirmed stale LATTE workspace interface."""

import json
import os
from pathlib import Path

from qwen_agents import BatchLatte


class LATTEWorkspaceInterfaceMismatchBeforeModel(RuntimeError):
    pass


class WorkspaceGuardedLatte(BatchLatte):
    async def run(self, instruction, environment, context):
        source = Path(os.environ["U59_TASK_DIR"]) / "environment/workspace"
        mismatch = (not (source / "check.py").is_file()
                    and not (source / "README.md").is_file()
                    and (source / "public_check.py").is_file()
                    and (source / "TASK.md").is_file())
        if mismatch:
            receipt = Path(self.logs_dir) / "latte-workspace-quarantine.json"
            receipt.write_text(json.dumps({
                "schema": "latte-workspace-quarantine/1",
                "reason": "adapter requires absent check.py/README.md; task uses public_check.py/TASK.md",
                "task": source.parents[1].name,
                "model_requests_before_failure": 0,
                "quality_result": None,
                "new_paid_retry_authorized": False,
                "frozen_task_or_verifier_changed": False,
            }, indent=2) + "\n")
            raise LATTEWorkspaceInterfaceMismatchBeforeModel(
                "Known LATTE workspace interface mismatch; quarantined before provider request; preserve as infrastructure failure")
        return await super().run(instruction, environment, context)
