"""Candidate only: select the published workspace interface without changing LATTE."""

from hashlib import sha256
import json
import os
from pathlib import Path

from harbor_adapter.native_planning_agent import NativePlanningLatteAgent
from harbor_agents.common import optional_env
from qwen_agents import Routed
from qwen_latte_workspace_core_v1 import LatteAgent as WorkspaceCore


class NativePlanningWorkspaceLatte(NativePlanningLatteAgent):
    async def run(self, instruction, environment, context):
        source = Path(os.environ['U59_TASK_DIR']) / 'environment/workspace'
        revised = (source / 'TASK.md').is_file() and (source / 'public_check.py').is_file()
        legacy = (source / 'README.md').is_file() and (source / 'check.py').is_file()
        if revised == legacy:
            raise RuntimeError('Ambiguous or unknown LATTE public workspace interface')
        if optional_env(self, 'HARNESS_LATTE_PLANNING_AUTHORIZED') != '1':
            raise RuntimeError('LATTE paid execution is not explicitly authorized')
        receipt = {'schema': 'latte-workspace-binding/1',
            'adapter_version': 'qwen-latte-workspace-interface/1.0.0',
            'workspace_layout': 'revised-v21' if revised else 'legacy',
            'readme': 'TASK.md' if revised else 'README.md',
            'public_check': 'public_check.py' if revised else 'check.py',
            'task_instruction_sha256': sha256(instruction.encode()).hexdigest(),
            'frozen_task_or_verifier_changed': False,
            'planning_or_delegation_policy_changed': False}
        log = Path(self.logs_dir)
        log.mkdir(parents=True, exist_ok=True)
        (log / 'latte-workspace-binding.json').write_text(json.dumps(receipt, indent=2) + '\n')
        if revised:
            return await WorkspaceCore.run(self, instruction, environment, context)
        return await super().run(instruction, environment, context)


class BatchLatteWorkspace(Routed, NativePlanningWorkspaceLatte):
    pass
