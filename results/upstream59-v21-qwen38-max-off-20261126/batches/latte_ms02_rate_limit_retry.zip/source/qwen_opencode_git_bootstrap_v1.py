"""Versioned Qwen OpenCode fix: give Harbor's forced Git VCS a real worktree.

The CLI, model, prompt, tools, permissions and provider transport remain intact.
This creates Git metadata only. Existing task bytes must remain identical.
"""

from hashlib import sha256
import json
from pathlib import Path
import shlex

from qwen_agents import NativeOpenCode

VERSION = "qwen-opencode-git-bootstrap/1.0.0"

BOOTSTRAP = r'''
from pathlib import Path
from hashlib import sha256
import json, subprocess

root = Path('/app')
def fingerprint():
    values = {}
    for path in root.rglob('*'):
        if '.git' in path.relative_to(root).parts:
            continue
        if path.is_file():
            values[str(path.relative_to(root))] = sha256(path.read_bytes()).hexdigest()
    return values

before = fingerprint()
existed = (root / '.git').exists()
if not existed:
    subprocess.run(['git', '-C', str(root), 'init', '--quiet'], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
actual = subprocess.check_output(['git', '-C', str(root), 'rev-parse', '--show-toplevel'], text=True).strip()
if actual != str(root):
    raise RuntimeError('OpenCode Git root does not match the task workspace')
after = fingerprint()
if before != after:
    raise RuntimeError('Git bootstrap changed task bytes')
version = subprocess.check_output(['opencode', '--version'], text=True).strip()
if version != '1.19.4':
    raise RuntimeError('Unexpected OpenCode version')
report = {'schema': 'qwen-opencode-git-bootstrap/1', 'adapter_version': VERSION,
          'adapter_sha256': ADAPTER_SHA256, 'opencode_version': version,
          'worktree': actual, 'git_metadata_preexisted': existed,
          'workspace_files_before': before, 'workspace_files_after': after,
          'task_bytes_unchanged': True, 'cli_capture': 'persistent-file-original-embedded-worker',
          'model': 'qwen3.8-max', 'output_limit_unchanged': 8192,
          'added_delegation_prompt': False, 'permissions_changed': False}
Path('/logs/agent/qwen-opencode-runtime.json').write_text(json.dumps(report, indent=2) + '\n')
'''


class GitRootedOpenCode(NativeOpenCode):
    async def install(self, environment):
        await super().install(environment)
        source_hash = sha256(Path(__file__).read_bytes()).hexdigest()
        script = "VERSION=" + repr(VERSION) + "\nADAPTER_SHA256=" + repr(source_hash) + "\n" + BOOTSTRAP
        result = await environment.exec(command="python3 -B -c " + shlex.quote(script), cwd="/app")
        if result.return_code:
            raise RuntimeError("OpenCode Git bootstrap failed before model admission")
