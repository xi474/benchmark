"""Regrade archived R5 submissions after verifier task IDs failed to match."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile


ARCHIVE_SHA = "a063237998141238ba2357ca8fce70d60d55f18dded17da533830c06c75d7135"
IMAGE = "sha256:992990936f990ff46e0618e3ed844e11c57bce8ccb79a7734f800011ec029ed6"
CONTROLS = ("u59-v4pro-r5-codex-c067", "u59-v4pro-r5-langgraph-c069")


def read(path):
    return json.loads(path.read_bytes())


def write(path, payload):
    with path.open("x", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, indent=2, allow_nan=False)
        file.write("\n")


def audit_input(run, cell, outcome, archive):
    trial = cell["trial_id"]
    task = cell["task_id"]
    (result_path,) = (run / "jobs" / trial).glob("*/result.json")
    result = read(result_path)
    assert result["task_name"] == f"capstone-upstream59/{task}", trial
    assert Path(result["task_id"]["path"]) == run / "tasks" / task, trial
    paths = result_path.parent
    manifest = read(paths / "artifacts/manifest.json")
    assert any(row["source"] == "/app" and row["destination"] == "artifacts/app"
               and row["status"] == "ok" for row in manifest), trial
    candidate = paths / "artifacts/app"
    assert candidate.is_dir() and not candidate.is_symlink(), trial
    old_receipt = paths / "verifier/raw-checks.json"
    registry = run / "tasks" / task / "tests/release-registry.json"
    assert sha256(registry.read_bytes()).hexdigest() == cell["registry_sha256"], trial
    tests = registry.parent
    prefix = f"tasks/{task}/tests/"
    expected = {name[len(prefix):]: sha256(archive.read(name)).hexdigest()
                for name in archive.namelist() if name.startswith(prefix) and not name.endswith("/")}
    found = {p.relative_to(tests).as_posix(): sha256(p.read_bytes()).hexdigest()
             for p in tests.rglob("*") if p.is_file()}
    assert expected == found, trial
    assert read(registry)["task"] == task, trial
    old_task = read(old_receipt)["task"]
    if outcome["score"] is None:
        assert old_task != task, trial
    return {
        "trial_id": trial, "task_id": task, "harness": cell["harness"],
        "candidate": candidate, "tests": tests, "registry_sha256": cell["registry_sha256"],
        "original_result_sha256": sha256(result_path.read_bytes()).hexdigest(),
        "original_receipt_sha256": sha256(old_receipt.read_bytes()).hexdigest(),
        "original_receipt_task": old_task, "expected_score": outcome["score"],
        "original_reward": None if outcome["score"] is None else outcome["score"]["reward"],
    }


def regrade(item, destination):
    trial = item["trial_id"]
    command = [
        "docker", "run", "--rm", "--pull=never", "--network=none", "--read-only",
        "--security-opt=no-new-privileges", "--pids-limit=256", "--memory=3g", "--cpus=2",
        "--tmpfs", "/tmp:rw,exec,mode=1777,size=512m",
        "--tmpfs", "/app:rw,exec,mode=755,size=512m",
        "--tmpfs", "/tests:rw,exec,mode=700,size=64m",
        "--tmpfs", "/logs/verifier:rw,noexec,mode=700,size=32m",
        "--mount", f"type=bind,source={item['tests']},target=/sealed-tests,readonly",
        "--mount", f"type=bind,source={item['candidate']},target=/candidate,readonly",
        IMAGE, "sh", "-ec",
        "cp -a /sealed-tests/. /tests/; cp -a /candidate/. /app/; "
        "cd /app; sh /tests/test.sh >&2; cat /logs/verifier/score.json",
    ]
    row = {key: value for key, value in item.items() if key not in {"candidate", "tests", "expected_score"}}
    row.update(model_requests=0, image=IMAGE, score=None)
    try:
        process = subprocess.run(command, capture_output=True, timeout=600)
        if process.returncode:
            row.update(status="verifier-error", returncode=process.returncode)
        else:
            score = json.loads(process.stdout)
            assert score["task"] == item["task_id"]
            assert score["benchmark_version"] == "2.0.0"
            assert score["scoring_revision"] == "delivery-bonus-50-v1"
            assert score["status"] == "scored" and score["reward"] is not None
            expected = item["expected_score"]
            if expected is not None and score != expected:
                row.update(status="score-differs", score=score,
                           differing_fields=[key for key in sorted(score.keys() | expected.keys())
                                             if score.get(key) != expected.get(key)])
            else:
                row.update(status="scored", score=score)
    except (AssertionError, KeyError, ValueError, OSError, subprocess.TimeoutExpired) as error:
        row.update(status="replay-error", error_type=type(error).__name__)
    write(destination / (trial + ".json"), row)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--audit-all", action="store_true")
    args = parser.parse_args()
    run = args.run.resolve(strict=True)
    destination = args.destination
    archive_path = run / "capstone-upstream59-v2.0.0.zip"
    assert sha256(archive_path.read_bytes()).hexdigest() == ARCHIVE_SHA
    status = read(run / "paid-status.json")
    assert status["phase"] == "ended" and not status["active"]
    plan = {row["trial_id"]: row for row in read(run / "pending-v4pro-cells.json")["cells"]}
    outcomes = {row["trial_id"]: row for row in read(run / "paid-outcomes.json")}
    assert plan.keys() == outcomes.keys()
    affected = [trial for trial, row in outcomes.items() if row["score"] is None]
    population = list(outcomes) if args.audit_all else [*CONTROLS, *affected]
    destination.mkdir()
    items = {}
    invalid = []
    with ZipFile(archive_path) as archive:
        for trial in population:
            try:
                items[trial] = audit_input(run, plan[trial], outcomes[trial], archive)
            except (AssertionError, OSError, KeyError, ValueError) as error:
                row = {key: plan[trial][key] for key in ("trial_id", "task_id", "harness")}
                row.update(model_requests=0, status="input-not-certified", error_type=type(error).__name__, score=None)
                invalid.append(row)
                write(destination / (trial + ".json"), row)
    controls = [regrade(items[trial], destination) for trial in CONTROLS]
    results = []
    if all(row["status"] == "scored" for row in controls):
        with ThreadPoolExecutor(max_workers=6) as pool:
            results = list(pool.map(lambda item: regrade(item, destination),
                                    (item for trial, item in items.items() if trial not in CONTROLS)))
    rows = controls + results + invalid
    summary = {
        "archive_sha256": ARCHIVE_SHA, "verifier_image": IMAGE,
        "model_requests": 0, "affected": len(affected),
        "population": len(population), "processed": len(rows),
        "recovered": sum(row["trial_id"] in affected and row.get("score") is not None for row in rows),
        "changed_prior_scores": sum(row["status"] == "score-differs" for row in rows),
        "controls": [{key: row[key] for key in ("trial_id", "status")} for row in controls],
        "rows": rows,
    }
    write(destination / "summary.json", summary)
    print(json.dumps({key: value for key, value in summary.items() if key != "rows"}))


if __name__ == "__main__":
    main()
