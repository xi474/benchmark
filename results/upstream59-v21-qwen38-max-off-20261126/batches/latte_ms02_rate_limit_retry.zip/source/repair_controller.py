"""Run only the authorized v2.0.0 LATTE and Codex repair trials."""

from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import threading
from zipfile import ZipFile

import bridge
import paid_controller as core
from codex_tool_response import BRIDGE_VERSION, install
from regrade_mismatched_receipts import IMAGE as VERIFIER_IMAGE, regrade


ROOT = Path(__file__).resolve().parent
R5 = ROOT.parent / "paid-r5"
TOOL_IMAGE = "upstream59-v4pro-tools:offline-pytest-r6"
PORT = 19326
PILOTS = {("codex", "C011"), ("latte-planning-adapted", "MS02")}
IDS = {"codex", "latte-planning-adapted"}
PLAN = ROOT / "repair-plan.json"


def setup_core(root=ROOT):
    core.ROOT = root
    core.IMAGE = TOOL_IMAGE
    core.PORT = PORT
    install(bridge)


def write(path, value):
    core.atomic_json(path, value)


def frozen_registry(plan, directory, archive_name="capstone-upstream59-v2.0.0.zip"):
    """Check byte identity of instructions and the full verifier directory."""
    with ZipFile(directory / archive_name) as archive:
        names = archive.namelist()
        for cell in plan:
            task = cell["task_id"]
            prefix = f"tasks/{task}/"
            source = directory / "tasks" / task
            instruction = source / "instruction.md"
            assert instruction.read_bytes() == archive.read(prefix + "instruction.md")
            assert core.digest(instruction.read_bytes()) == cell["instruction_sha256"]
            for name in names:
                if name.startswith(prefix + "tests/") and not name.endswith("/"):
                    assert (source / name.removeprefix(prefix)).read_bytes() == archive.read(name)


def release_score(cell, parent, result, settled):
    if not settled:
        return {}
    task = cell["task_id"]
    manifest = parent / "artifacts/manifest.json"
    candidate = parent / "artifacts/app"
    if not manifest.is_file() or not candidate.is_dir() or candidate.is_symlink():
        return {"offline_score_status": "missing-harbor-workspace"}
    assert result["task_name"] == f"capstone-upstream59/{task}"
    assert any(entry.get("source") == "/app" and entry.get("status") == "ok"
               and entry.get("destination") == "artifacts/app" for entry in core.read(manifest))
    receipt = parent / "verifier/raw-checks.json"
    tests = ROOT / "tasks" / task / "tests"
    assert core.digest((tests / "release-registry.json").read_bytes()) == cell["registry_sha256"]
    item = dict(
        trial_id=cell["trial_id"], task_id=task, harness=cell["harness"],
        candidate=candidate, tests=tests, registry_sha256=cell["registry_sha256"],
        expected_score=None, original_result_sha256=core.digest((parent / "result.json").read_bytes()),
        original_receipt_sha256=core.digest(receipt.read_bytes()) if receipt.is_file() else None,
        original_receipt_task=core.read(receipt).get("task") if receipt.is_file() else None,
    )
    row = regrade(item, ROOT / "offline-scores")
    audited = {"offline_score_status": row["status"], "harbor_receipt_task": item["original_receipt_task"]}
    if row["score"] is not None:
        path = ROOT / "offline-scores" / (cell["trial_id"] + ".json")
        audited.update(score=row["score"], score_sha256=core.digest(path.read_bytes()))
    return audited


def pilot_passed(row, cell):
    if not row.get("technical_passed") or row.get("offline_score_status") != "scored":
        return False
    result_path = Path(row["result_file"])
    result = core.read(result_path)
    message = str((result.get("exception_info") or {}).get("exception_message", ""))
    if cell["harness"] == "latte-planning-adapted":
        probe = result_path.parent / "agent/latte-pytest-preflight.json"
        if not probe.is_file() or core.read(probe)["passed"] is not True:
            return False
        if not row["terminal"] and row["returncode"] == 0:
            return True
        # The dependency pilot can validate the repaired process boundary even
        # when the planner independently obtains a zero-task quality outcome.
        if row["terminal"] != "NonZeroAgentExitCodeError" or "Planning phase produced zero tasks" not in message:
            return False
        events = result_path.parent / "agent/latte-events.jsonl"
        if not events.is_file() or row.get("budget_stop"):
            return False
        trace = [json.loads(line) for line in events.read_text(encoding="utf-8").splitlines() if line]
        started = {event["span_id"] for event in trace
                   if event["type"] == "tool.started" and event.get("tool") == "run_tests"}
        finished = {event["span_id"] for event in trace
                    if event["type"] == "tool.finished" and event.get("tool") == "run_tests"}
        return (bool(started & finished) and any(event["type"] == "run_tests" and
                type(event.get("returncode")) is int for event in trace) and
                any(event["type"] == "planning_phase_end" for event in trace))
    if not row["terminal"] and row["returncode"] == 0:
        return True
    if row.get("budget_stop") == "uniform-observed-token-cap":
        return True
    # A genuine model output cap is a usable terminal state if conversion stayed healthy.
    return (not row.get("budget_stop") and ("max_output_tokens" in message or "max_output_tokens" in
            (result_path.parent / "agent/codex.txt").read_text(encoding="utf-8", errors="replace")))


class RepairController(core.Controller):
    def __init__(self, cells, budget, gateway, credit, certification=None):
        super().__init__(cells, budget, gateway, credit, [])
        self.pilot = {harness: "pending" for harness in sorted(IDS)}
        for cell in cells:
            if cell["pilot"]:
                self.pilot[cell["harness"]] = "queued"
        if certification is not None:
            self.pilot = {harness: "passed-carried" for harness in self.pilot}
        self.released = False

    def status(self, phase):
        with self.lock:
            write(ROOT / "paid-status.json", {
                "phase": phase, "pid": os.getpid(), "harbor_capacity": 6, "http_capacity": 4,
                "planned_new": len(self.pending), "full_queue_released": self.released,
                "finished_attempts": len(self.outcomes), "scored": sum(row.get("score") is not None
                                                                    for row in self.outcomes.values()),
                "active": self.active, "pilots": self.pilot, "ledger": self.budget.snapshot(),
            })

    def run(self):
        pilots = [cell for cell in self.pending if cell["pilot"]]
        if pilots:
            self.pilot = {h: "running" for h in self.pilot}
            self.status("pilots")
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {cell["harness"]: pool.submit(self.one, cell) for cell in pilots}
            for cell in pilots:
                row = futures[cell["harness"]].result() or {}
                self.pilot[cell["harness"]] = "passed" if pilot_passed(row, cell) else "held"
                self.status("pilots")
            self.released = all(state in {"passed", "passed-carried"} for state in self.pilot.values()) and not self.budget.stopped
            if self.released:
                self.status("running")
                remainder = [cell for cell in self.pending if not cell["pilot"]]
                workers = (pool.submit(self.one, cell) for cell in remainder)
                submitted = list(workers)
                for worker in submitted:
                    worker.result()
        self.status("ended" if self.released and len(self.outcomes) == len(self.pending) else "held")
        completion = []
        for cell in self.pending:
            row = self.outcomes.get(cell["trial_id"])
            completion.append({
                "trial_id": cell["trial_id"], "harness": cell["harness"], "task_id": cell["task_id"],
                "previous_attempt": cell["previous_attempt"], "score": row.get("score") if row else None,
                "terminal": row.get("terminal") if row else None,
                "technical_passed": row.get("technical_passed") if row else None,
                "budget_stop": row.get("budget_stop") if row else None,
                "disposition": "ended" if row else "not-started",
            })
        write(ROOT / "completion.json", {
            "cells": completion, "pilot": self.pilot, "released": self.released,
            "original_results_preserved": True, "scoring_revision": "delivery-bonus-50-v1",
            "model": "deepseek-v4-pro", "thinking": "disabled",
        })


def main():
    import sys

    setup_core()
    consent = core.read(ROOT / "authorization.json")
    acceptance = core.read(ROOT / "offline-acceptance.json")
    assert consent["allow_paid_run"] is True
    assert consent["plan_sha256"] == core.digest(PLAN.read_bytes()) == acceptance["plan_sha256"]
    assert consent["batch_budget_usd"] is None and acceptance["passed"] and acceptance["provider_requests"] == 0
    assert acceptance["bridge_version"] == BRIDGE_VERSION and acceptance["verifier_image"] == VERIFIER_IMAGE
    actual_image = subprocess.check_output(["docker", "image", "inspect", "--format", "{{.Id}}", TOOL_IMAGE],
                                           text=True).strip()
    assert actual_image == acceptance["tool_image_id"]
    plan = core.read(PLAN)
    certification = None
    assert len(plan) == len({cell["trial_id"] for cell in plan})
    if consent.get("pilot_adjudication_sha256"):
        receipt = ROOT / "pilot-adjudication.json"
        assert core.digest(receipt.read_bytes()) == consent["pilot_adjudication_sha256"]
        certification = core.read(receipt)
        assert certification["passed"] and certification["plan_sha256"] == consent["plan_sha256"]
        assert len(plan) == 33 and all(cell["harness"] == "latte-planning-adapted" and not cell["pilot"] for cell in plan)
    else:
        assert len(plan) == 35
        assert {(cell["harness"], cell["task_id"]) for cell in plan if cell["pilot"]} == PILOTS
        assert {(cell["harness"], cell["task_id"]) for cell in plan if cell["harness"] == "codex"} == {("codex", "C011")}
    assert all(cell["harness"] in IDS for cell in plan)
    assert not (ROOT / "trial-consumption.jsonl").exists()
    with (ROOT / "paid-controller.lock").open("x", encoding="utf-8") as lock:
        lock.write(str(os.getpid()))
    for folder in ("configs", "console", "offline-scores"):
        (ROOT / folder).mkdir()
    core.extract(plan)
    frozen_registry(plan, ROOT)
    core.score_receipt = release_score
    sys.path.insert(0, str(ROOT / "release-scoring"))
    # Load the same local credential source as R5, without exporting the secret.
    key_path = next(Path("local-artifacts://user-home/Desktop").glob(
        "*/capstone/previous_benchmarks/harness-v3-research/harbor-agents/deepseek.env"))
    key = next(value.strip().strip("\"'") for line in key_path.read_text(encoding="utf-8-sig").splitlines()
               for name, _, value in [line.partition("=")] if name.strip() == "HARNESS_API_KEY")
    budget = core.BatchBudget(ROOT, plan)
    core.install_provider_transport(lambda row: budget.receipt(row))
    credit = core.TransientCredit(ROOT, key)
    budget.transport_recovery = core.TransportRecovery(budget, credit)
    budget.request_credit_guard = budget.transport_recovery.admit_request
    gateway = core.NormalGateway(("127.0.0.1", PORT), budget, key, secrets.token_hex(32))
    gateway.RequestHandlerClass = core.LoopHandler
    gateway.scope_guard = lambda: core.read(ROOT / "authorization.json") == consent
    ipc = core.create_ipc(ROOT / "ingress/live.sock", PORT)
    threading.Thread(target=gateway.serve_forever, daemon=True).start()
    threading.Thread(target=ipc.serve_forever, daemon=True).start()
    try:
        RepairController(plan, budget, gateway, credit, certification).run()
    finally:
        gateway.close_admission()
        gateway.shutdown()
        gateway.server_close()
        ipc.shutdown()
        ipc.server_close()
        budget.persist()


if __name__ == "__main__":
    main()
