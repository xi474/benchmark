"""Container loopback -> one mounted Unix endpoint; internet stays disabled."""
import select,socket,socketserver,sys
SOCKET='/installed-agent/hard3-ingress.sock'
class H(socketserver.BaseRequestHandler):
    def handle(self):
        peer=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        try:
            peer.settimeout(20);peer.connect(SOCKET)
            while True:
                ready,_,_=select.select([self.request,peer],[],[],660)
                if not ready:return
                for source in ready:
                    data=source.recv(65536)
                    if not data:return
                    (peer if source is self.request else self.request).sendall(data)
        except OSError:pass
        finally:peer.close()
class S(socketserver.ThreadingTCPServer):
    daemon_threads=True
    allow_reuse_address=False
with S(('127.0.0.1',19005),H) as s:s.serve_forever()
