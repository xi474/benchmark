"""Run the two confirmed Upstream59 GLM stages in independent, recoverable segments."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import fcntl
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

import paid_controller as harbor_config
from host_unix_bridge import create as create_ipc
from native_evidence_batch import native
from repair_controller import TOOL_IMAGE, release_score
from study_gateway import atomic_json
from qwen_gateway import ENDPOINT, Gateway, LOOP_REASON


ROOT = Path(__file__).resolve().parent
MIRROR = Path((ROOT / "mirror.txt").read_text().strip())
CREDENTIAL = Path((ROOT / "credential-path.txt").read_text().strip())
CAPACITY = 6
PILOT_TASKS = {1: {"opencode": "C008", "codex": "C011", "dsh": "MS02", "langgraph": "C008",
                   "latte-planning-adapted": "MS02", "nanobot": "C008"},
               2: {harness: "MP17" for harness in harbor_config.CLASSES}}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load_key():
    if not CREDENTIAL.is_file():
        raise RuntimeError("The configured qwen.local.env file is missing")
    fields = {}
    for line in CREDENTIAL.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name, equals, value = line.removeprefix("export ").partition("=")
        if equals:
            name = name.strip()
            if name in fields:
                raise ValueError("Duplicate credential configuration field")
            value = value.strip()
            if value.startswith(('"', "'")):
                closing = value.find(value[0], 1)
                if closing < 0:
                    raise ValueError("Malformed quoted environment value")
                comment = value[closing + 1:].strip()
                if comment and not comment.startswith("#"):
                    raise ValueError("Unexpected text after environment value")
                value = value[1:closing]
            else:
                value = value.split(" #", 1)[0].strip()
            fields[name] = value
    key = fields.get("HARNESS_API_KEY", "")
    import re
    if not re.fullmatch(r"sk-[A-Za-z0-9_.-]{12,256}", key):
        raise RuntimeError("HARNESS_API_KEY is empty or contains invalid characters")
    base = fields.get("HARNESS_BASE_URL", "").rstrip("/")
    if base + "/chat/completions" != ENDPOINT:
        raise RuntimeError("HARNESS_BASE_URL does not match the registered Beijing Token Plan endpoint")
    if fields.get("HARNESS_MODEL") != "qwen3.8-max":
        raise RuntimeError("Model configuration drift")
    return key, base + "/chat/completions"


def append_event(path, value):
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def config(cell, segment, install_only=False):
    route = {"opencode": "local/", "codex": "qwen/"}.get(cell["harness"], "openai/")
    value = harbor_config.trial_config(cell)
    value.update(jobs_dir=str(segment / "jobs"), install_only=install_only)
    value["agents"][0]["model_name"] = route + "qwen3.8-max"
    return value


def env_for(cell, token, segment):
    env = harbor_config.trial_env(cell, token)
    env.update(CODEX_GLM_GATEWAY_BASE_URL=env["STUDY_PROXY_BASE"], CODEX_GLM_GATEWAY_TOKEN=token,
               HARD3_HOST_SOCKET=str(segment / "ingress/live.sock"),
               BATCH_REQUIRE_LATTE="0", LITELLM_LOCAL_MODEL_COST_MAP="True")
    return env


def previous_attempts():
    outcomes = {}
    consumed = {}
    for segment in sorted((ROOT / "runs").glob("segment-*")):
        receipts = segment / "trial-consumption.jsonl"
        if receipts.is_file():
            for line in receipts.read_text().splitlines():
                row = json.loads(line)
                consumed.setdefault(row["cell_id"], []).append(row["trial_id"])
        result = segment / "paid-outcomes.json"
        if result.is_file():
            for row in read(result):
                outcomes.setdefault(row["cell_id"], []).append(row)
    return consumed, outcomes


def audit(cell, code, segment, gateway):
    tid = cell["trial_id"]
    paths = list((segment / "jobs" / tid).glob("*/result.json"))
    records = gateway.trial_rows(tid)
    settled = [r for r in records if r["state"] == "settled"]
    unsettled = len(records) - len(settled)
    outcome = dict(cell, returncode=code, score=None, technical_passed=False,
                   requests_sent=len(records), requests_settled=len(settled), requests_unknown=unsettled,
                   estimated_list_cost_cny=sum(r["cost_cny_upper_bound"] for r in settled),
                   stop_reason=gateway.blocked.get(tid))
    if len(paths) != 1:
        return dict(outcome, terminal="harbor-result-missing")
    path = paths[0]
    harbor = read(path)
    outcome.update(result_file=str(path), terminal=(harbor.get("exception_info") or {}).get("exception_type"))
    snapshots = [read(segment / "request-snapshots" / (row["request_id"] + ".json"))["egress"]
                 for row in records]
    mode = bool(snapshots) and all(r["model"] == "qwen3.8-max" and r.get("enable_thinking") is False for r in snapshots)
    tools = bool(snapshots) and all(isinstance(r.get("tools"), list) and r.get("messages_sha256")
                                    and r.get("tools_sha256") for r in snapshots)
    agent = path.parent / "agent"
    if cell["harness"] == "latte-planning-adapted":
        event = agent / "latte-events.jsonl"
        root = dict(root_known=event.is_file() and event.stat().st_size > 0, child_count=None)
    else:
        root = native(agent, cell["harness"], [])
    resource = agent / "native-resources.csv"
    outcome.update(actual_mode_verified=mode, request_tools_and_prompt_observed=tools,
                   native=root, resources_observed=resource.is_file() and resource.stat().st_size > 40)
    outcome.update(release_score(cell, path.parent, harbor, settled))
    outcome["technical_passed"] = bool(outcome["score"] and mode and tools and root["root_known"]
                                       and outcome["resources_observed"] and not unsettled)
    return outcome


class Queue:
    def __init__(self, manifest, segment, gateway, consumed, old):
        self.manifest = manifest
        self.segment = segment
        self.gateway = gateway
        self.consumed = consumed
        self.old = old
        self.active, self.results = {}, {}
        self.lock = threading.RLock()
        self.done = threading.Event()
        self.phase = "starting"
        self.stage = 1
        self.pilots = {}

    def valid_previous(self, cell):
        return any(r.get("technical_passed") for r in self.old.get(cell["cell_id"], []))

    def can_run(self, cell):
        return cell["cell_id"] not in self.consumed

    def state(self):
        with self.lock, self.gateway.lock:
            current = list(self.results.values())
            carry = sum(self.valid_previous(c) for c in self.manifest["cells"])
            current_scored = sum(bool(r.get("score")) for r in current)
            return {"phase": self.phase, "stage": self.stage, "pid": os.getpid(), "segment": self.segment.name,
                    "model": "qwen3.8-max", "enable_thinking": False,
                    "planned": len(self.manifest["cells"]), "finished_attempts": len(current), "scored_this_segment": current_scored,
                    "carried_verified": carry, "active": dict(self.active), "pilots": dict(self.pilots),
                    "harbor_capacity": CAPACITY, "http_capacity": 4,
                    "updated_at": time.time(), "ledger": self.gateway.ledger()}

    def checkpoint(self, reason, full=False):
        with self.lock:
            state = self.state()
            atomic_json(self.segment / "paid-status.json", state)
            atomic_json(MIRROR / "status.json", state)
            if full:
                receipt = dict(state, checkpoint_reason=reason,
                               completed=sorted(r["cell_id"] for r in self.results.values() if r.get("technical_passed")),
                               interrupted=sorted(r["cell_id"] for r in self.results.values() if not r.get("technical_passed")))
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
                atomic_json(self.segment / "checkpoints" / (stamp + ".json"), receipt)
                atomic_json(MIRROR / "latest-checkpoint.json", receipt)

    def periodic(self):
        while not self.done.wait(300):
            self.checkpoint("periodic-300-sec", full=True)

    def run_cell(self, entry):
        tid = entry["trial_id"]
        with self.lock, self.gateway.lock:
            if self.gateway.stop_reason or (self.segment / "STOP").exists():
                return None
            append_event(self.segment / "trial-consumption.jsonl",
                         {k: entry[k] for k in ("cell_id", "trial_id", "harness", "task_id", "stage")})
            self.active[tid] = {k: entry[k] for k in ("harness", "task_id", "stage")}
            self.gateway.activate(tid)
        cfg = self.segment / "configs" / (tid + ".json")
        atomic_json(cfg, config(entry, self.segment))
        self.checkpoint("admitted")
        try:
            with (self.segment / "console" / (tid + ".log")).open("w") as log:
                proc = subprocess.run([sys.executable, str(ROOT / "hard3_harbor.py"), "run", "--config", str(cfg), "--yes"],
                                      cwd="/tmp", env=env_for(entry, self.gateway.master + ":" + tid, self.segment),
                                      stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 630
            while any(r["state"] == "sent" for r in self.gateway.trial_rows(tid)) and time.monotonic() < deadline:
                time.sleep(1)
            if any(r["state"] == "sent" for r in self.gateway.trial_rows(tid)):
                self.gateway.block(tid, "request-drain-timeout", shared=True)
            end = audit(entry, proc.returncode, self.segment, self.gateway)
        except Exception as err:
            import traceback
            with (self.segment / "console" / (tid + ".audit.log")).open("w") as log:
                log.write(self.gateway.safe_error(traceback.format_exc()))
            end = dict(entry, score=None, technical_passed=False, terminal=type(err).__name__,
                       stop_reason=self.gateway.blocked.get(tid))
        finally:
            self.gateway.deactivate(tid)
        with self.lock:
            self.active.pop(tid)
            self.results[tid] = end
            atomic_json(self.segment / "paid-outcomes.json", list(self.results.values()))
            self.checkpoint("trial-finished", full=True)
        return end

    def run_stage(self, band):
        rows = self.manifest["cells"]
        pilot_id = self.manifest["pilot_cell_id"]
        pilot = next(c for c in rows if c["cell_id"] == pilot_id)
        self.phase = "single-included-pilot"
        if self.valid_previous(pilot):
            self.pilots[pilot["harness"]] = "carried-pass"
        else:
            self.pilots[pilot["harness"]] = "pending"
            self.checkpoint("pilot-registered", full=True)
            if not self.can_run(pilot) or not self.pilot_one(
                dict(pilot, trial_id=pilot["cell_id"] + "-" + self.segment.name)
            ):
                return False
        if self.gateway.stop_reason:
            return False
        self.phase = "full-six-concurrent"
        self.checkpoint("pilot-passed-remainder-admitted", full=True)
        pending = [dict(c, trial_id=c["cell_id"] + "-" + self.segment.name)
                   for c in rows if c["cell_id"] != pilot_id and self.can_run(c)]
        with ThreadPoolExecutor(max_workers=CAPACITY) as pool:
            list(pool.map(self.run_cell, pending))
        finished = {row["cell_id"] for row in self.results.values()}
        return not self.gateway.stop_reason and all(
            c["cell_id"] == pilot_id or c["cell_id"] in self.consumed or c["cell_id"] in finished
            for c in rows
        )

    def pilot_one(self, pilot):
        result = self.run_cell(pilot) or {}
        passed = result.get("technical_passed", False)
        with self.lock:
            self.pilots[pilot["harness"]] = "passed" if passed else "held"
            self.checkpoint("pilot-adjudicated", full=True)
        return passed

    def run(self):
        pulse = threading.Thread(target=self.periodic, daemon=True)
        pulse.start()
        try:
            self.phase = "complete" if self.run_stage(1) else "held-with-checkpoint"
        finally:
            self.done.set()
            self.checkpoint("controller-closed", full=True)


def main():
    manifest = read(ROOT / "manifest.json")
    approved = read(ROOT / "offline-acceptance.json")
    assert approved["passed"] and approved["provider_requests"] == 0
    assert approved["manifest_sha256"] == digest(ROOT / "manifest.json")
    assert (manifest["max_concurrent_harbor"], manifest["max_concurrent_http"]) == (6, 4)
    assert manifest["upstream_endpoint"] == ENDPOINT and manifest["batch_cost_cap_cny"] is None
    assert subprocess.check_output(["docker", "image", "inspect", "--format", "{{.Id}}", TOOL_IMAGE],
                                   text=True).strip() == approved["image_id"]
    credential, endpoint = load_key()
    harbor_config.ROOT = ROOT
    with (ROOT / "controller.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        consumed, history = previous_attempts()
        if consumed and "--resume" not in sys.argv:
            raise RuntimeError("Use --resume after reconciling the preceding checkpoint")
        number = len(list((ROOT / "runs").glob("segment-*"))) + 1
        segment = ROOT / "runs" / f"segment-{number:02d}"
        segment.mkdir(parents=True, exist_ok=False)
        atomic_json(segment / "admission.json", {
            "model": "qwen3.8-max", "enable_thinking": False, "upstream_endpoint": endpoint,
            "manifest_sha256": approved["manifest_sha256"], "credentials_saved": False,
        })
        for name in ("configs", "jobs", "console", "checkpoints", "offline-scores"):
            (segment / name).mkdir()
        # Regrade operates on the frozen release inputs while writing only to this
        # segment. A sibling tasks link avoids changing the installed scorers.
        (segment / "tasks").symlink_to(ROOT / "tasks", target_is_directory=True)
        import repair_controller
        repair_controller.ROOT = segment
        trials = [dict(c, trial_id=c["cell_id"] + "-" + segment.name) for c in manifest["cells"]]
        gateway = Gateway(segment, trials, credential, port=0, endpoint=endpoint)
        ipc = create_ipc(segment / "ingress/live.sock", gateway.port)
        gateway.start()
        threading.Thread(target=ipc.serve_forever, daemon=True).start()
        try:
            Queue(manifest, segment, gateway, consumed, history).run()
        finally:
            gateway.close()
            ipc.shutdown()
            ipc.server_close()



_original_latte_audit = audit
def audit(cell, code, segment, gateway):
    row = _original_latte_audit(cell, code, segment, gateway)
    revision_verified = False
    allowed_terminal = False
    if row.get("result_file"):
        parent = Path(row["result_file"]).parent
        agent = parent / "agent"
        binding = agent / "latte-workspace-binding.json"
        task = agent / "latte-tasks.json"
        if binding.is_file() and task.is_file():
            proof, payload = read(binding), read(task)
            description = payload.get("description", "")
            source_text = (ROOT / "tasks" / cell["task_id"] / "instruction.md").read_text()
            revision_verified = (
                proof.get("adapter_version") == "qwen-latte-workspace-interface/1.0.0"
                and proof.get("workspace_layout") == "revised-v21"
                and proof.get("public_check") == "public_check.py"
                and payload.get("success_criteria") == "python3 public_check.py exits 0 in /app"
                and "/app/public_check.py" in description.split("TASK:", 1)[0]
                and "/app/check.py" not in description.split("TASK:", 1)[0]
                and source_text in description
                and sha256(source_text.encode()).hexdigest() == proof.get("task_instruction_sha256"))
        harbor = read(parent / "result.json")
        message = str((harbor.get("exception_info") or {}).get("exception_message", ""))
        native_result = agent / "latte-result.json"
        if row.get("terminal") is None:
            row["terminal_classification"] = "normal_scored"
            allowed_terminal = True
        elif "Planning phase produced zero tasks after 5 turns" in message:
            row["terminal_classification"] = "model_planning_empty_after_valid_interface"
            allowed_terminal = True
        elif (native_result.is_file() and read(native_result).get("success") is False
              and sum(json.loads(line).get("type") == "round_start"
                      for line in (agent / "latte-events.jsonl").read_text().splitlines()) >= 100):
            row["terminal_classification"] = "native_round_limit_incomplete"
            allowed_terminal = True
        else:
            row["terminal_classification"] = "runtime_failure_requires_audit"
    row["runtime_revision_verified"] = revision_verified
    # A quality zero is retained. The pilot screens infrastructure and observability.
    row["technical_passed"] = bool(row.get("technical_passed") and revision_verified
                                   and allowed_terminal and not row.get("stop_reason"))
    return row


def run_remaining_two_with_carried_pilot(self, band):
    carried = read(ROOT / "carried-technical-pilot.json")
    assert carried["task_id"] == "MS02" and carried["technical_passed"]
    assert carried["runtime_revision_verified"] and carried["actual_mode_verified"]
    assert carried["requests_sent"] == carried["requests_settled"] == 5
    assert carried["requests_unknown"] == 0
    assert len(self.manifest["cells"]) == 2
    assert {c["task_id"] for c in self.manifest["cells"]} == {"C055", "MS30"}
    self.pilots["latte-planning-adapted"] = "passed-carried-MS02-r3-technical-only"
    self.phase = "two-concurrent-after-carried-technical-pilot"
    self.checkpoint("carried-pilot-verified-two-cells-admitted", full=True)
    pending = [dict(c, trial_id=c["cell_id"] + "-" + self.segment.name)
               for c in self.manifest["cells"] if self.can_run(c)]
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(self.run_cell, pending))
    return (not self.gateway.stop_reason
            and len(self.results) == 2)

Queue.run_stage = run_remaining_two_with_carried_pilot

if __name__ == "__main__":
    main()
