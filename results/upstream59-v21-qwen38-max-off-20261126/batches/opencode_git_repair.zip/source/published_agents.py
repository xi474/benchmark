"""Bind the verified existing adapters to the verified release-seeded workspace."""
import hashlib
import json
import os
from pathlib import Path
import shlex

from qwen_agents import NativeCodex, NativeDsh, NativeLangGraph, NativeNanobot, NativeOpenCode, BatchLatte


class PublishedTask:
    async def run(self, instruction, environment, context):
        expected = Path(os.environ["U59_TASK_DIR"]) / "instruction.md"
        if instruction.strip() != expected.read_text(encoding="utf-8").strip():
            raise RuntimeError("Release instruction drift")
        await environment.upload_file(Path(__file__).with_name("unix_tcp_bridge.py"), "/installed-agent/u59-ipc.py")
        await environment.exec(command="mkdir -p /logs/agent; nohup python3 /installed-agent/u59-ipc.py > /logs/agent/u59-ipc.log 2>&1 & sleep 0.4", cwd="/app")
        health_url = os.environ["U59_GATEWAY"] + "/health"
        probe = ("import json,urllib.request; "
                 "opener=urllib.request.build_opener(urllib.request.ProxyHandler({})); "
                 "result=opener.open(" + repr(health_url) + ",timeout=8); "
                 "assert json.load(result)['ok']")
        check = await environment.exec(command="python3 -B -c " + shlex.quote(probe), cwd="/app")
        if check.return_code != 0:
            details = (check.stderr or check.stdout or "")[-500:]
            raise RuntimeError("Trial gateway health failed before model request: " + details)
        log = Path(self.logs_dir)
        log.mkdir(parents=True, exist_ok=True)
        (log / "native-configured-capabilities.json").write_text(json.dumps({
            "model": "qwen3.8-max", "enable_thinking": False, "condition": "native-policy",
            "task_instruction_sha256": hashlib.sha256(expected.read_bytes()).hexdigest(),
            "minimum_children": 0, "extra_delegation_prompt": False,
        }), encoding="utf-8")
        cmd = (
            "mkdir -p /logs/agent; "
            "echo unix_time,memory_current_bytes,cpu_usage_usec > /logs/agent/native-resources.csv; "
            "nohup sh -c 'while true; do "
            "echo \"$(date +%s),$(cat /sys/fs/cgroup/memory.current 2>/dev/null),"
            "$(head -n 1 /sys/fs/cgroup/cpu.stat 2>/dev/null | cut -d\" \" -f2)\"; sleep 1; done' "
            ">> /logs/agent/native-resources.csv 2>/dev/null & echo $! > /logs/agent/u59-sampler.pid"
        )
        await environment.exec(command=cmd, cwd="/app")
        try:
            # The legacy mixin installs this adapter's native CLI but copies a
            # different benchmark's starter files during run. Harbor already
            # installed the verified release workspace for this batch.
            return await super().run(instruction, environment, context)
        finally:
            await environment.exec(command="test ! -f /logs/agent/u59-sampler.pid || kill $(cat /logs/agent/u59-sampler.pid) 2>/dev/null || true", cwd="/app")


class Codex(PublishedTask, NativeCodex):
    pass


class Dsh(PublishedTask, NativeDsh):
    pass


from qwen_opencode_git_bootstrap_v1 import GitRootedOpenCode


class OpenCode(PublishedTask, GitRootedOpenCode):
    pass


class LangGraph(PublishedTask, NativeLangGraph):
    pass


from qwen_latte_workspace_guard_v1 import WorkspaceGuardedLatte


class Latte(PublishedTask, WorkspaceGuardedLatte):
    async def setup(self, environment):
        await super().setup(environment)
        result = await environment.exec(command="pytest --version", cwd="/app")
        report = {"passed": result.return_code == 0, "version": (result.stdout or "").strip()}
        (Path(self.logs_dir) / "latte-pytest-preflight.json").write_text(
            json.dumps(report), encoding="utf-8"
        )
        if not report["passed"]:
            raise RuntimeError("LATTE runtime cannot launch pytest from PATH")


class Nanobot(PublishedTask, NativeNanobot):
    pass
