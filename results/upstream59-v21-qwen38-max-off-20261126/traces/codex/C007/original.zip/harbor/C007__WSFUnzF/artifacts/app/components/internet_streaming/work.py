import re

_MONTHS = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _clean_text(value):
    if not value:
        return ''
    return re.sub(r'[^a-z0-9]', '', value.lower())


def _clean_digits(value):
    if not value:
        return ''
    return re.sub(r'[^0-9]', '', value)


def _parse_internet(record):
    fields = record['fields']
    full_name = fields.get('full_name', '')
    parts = full_name.split(None, 1)
    first = parts[0] if len(parts) > 0 else ''
    last = parts[1] if len(parts) > 1 else ''

    birth_date = fields.get('birth_date', '')
    dob = ''
    if birth_date:
        m = re.match(r'(\d{2})/(\d{2})/(\d{4})', birth_date)
        if m:
            dob = f'{m.group(3)}-{m.group(1)}-{m.group(2)}'

    return {
        'id': record['id'],
        'first': _clean_text(first),
        'last': _clean_text(last),
        'dob': dob,
        'ssn': '',
        'mail': _clean_text(fields.get('mail', '')),
        'phone': _clean_digits(fields.get('tel', '')),
        'address': _clean_text(fields.get('street', '')),
    }


def _parse_streaming(record):
    fields = record['fields']
    customer = fields.get('customer', '')
    parts = customer.split(None, 1)
    first = parts[0] if len(parts) > 0 else ''
    last = parts[1] if len(parts) > 1 else ''

    date_of_birth = fields.get('date_of_birth', '')
    dob = ''
    if date_of_birth:
        m = re.match(r'(\d{2})\s+(\w+)\s+(\d{4})', date_of_birth)
        if m:
            day = m.group(1)
            mon = _MONTHS.get(m.group(2).lower()[:3], '00')
            year = m.group(3)
            dob = f'{year}-{mon}-{day}'

    return {
        'id': record['id'],
        'first': _clean_text(first),
        'last': _clean_text(last),
        'dob': dob,
        'ssn': '',
        'mail': _clean_text(fields.get('email', '')),
        'phone': _clean_digits(fields.get('telephone', '')),
        'address': _clean_text(fields.get('address', '')),
    }


def compute(payload):
    result = []
    for idx, record in enumerate(payload['records']):
        source = record['source']
        if source == 'internet':
            result.append([idx, _parse_internet(record)])
        elif source == 'streaming':
            result.append([idx, _parse_streaming(record)])
    return result
