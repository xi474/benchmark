import re

_MONTHS = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _clean_text(value):
    if not value:
        return ''
    return re.sub(r'[^a-z0-9]', '', value.lower())


def _clean_digits(value):
    if not value:
        return ''
    return re.sub(r'[^0-9]', '', value)


def _parse_mobile(record):
    fields = record['fields']
    return {
        'id': record['id'],
        'first': _clean_text(fields.get('first', '')),
        'last': _clean_text(fields.get('last', '')),
        'dob': fields.get('dob', ''),
        'ssn': _clean_digits(fields.get('ssn', '')),
        'mail': _clean_text(fields.get('email', '')),
        'phone': _clean_digits(fields.get('phone', '')),
        'address': _clean_text(fields.get('address', '')),
    }


def _parse_cable(record):
    fields = record['fields']
    last_first = fields.get('last_first', '')
    parts = last_first.split(',', 1)
    last = parts[0].strip() if len(parts) > 0 else ''
    first = parts[1].strip() if len(parts) > 1 else ''

    birth = fields.get('birth', '')
    if len(birth) == 8:
        dob = f'{birth[:4]}-{birth[4:6]}-{birth[6:8]}'
    else:
        dob = ''

    return {
        'id': record['id'],
        'first': _clean_text(first),
        'last': _clean_text(last),
        'dob': dob,
        'ssn': _clean_digits(fields.get('government_id', '')),
        'mail': _clean_text(fields.get('contact', '')),
        'phone': _clean_digits(fields.get('phone', '')),
        'address': _clean_text(fields.get('location', '')),
    }


def compute(payload):
    result = []
    for idx, record in enumerate(payload['records']):
        source = record['source']
        if source == 'mobile':
            result.append([idx, _parse_mobile(record)])
        elif source == 'cable':
            result.append([idx, _parse_cable(record)])
    return result
