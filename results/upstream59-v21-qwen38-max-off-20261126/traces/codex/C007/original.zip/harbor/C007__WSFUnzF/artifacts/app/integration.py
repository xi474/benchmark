def combine(payload, left, right):
    """Combine normalized records from both components and cluster by entity."""
    from collections import defaultdict

    ambiguous_names = set(n.lower() for n in payload.get('ambiguous_names', []))

    all_records = list(left) + list(right)
    rec_by_id = {}
    for _idx, obj in all_records:
        rec_by_id[obj['id']] = obj

    all_ids = [obj['id'] for _idx, obj in all_records]

    # Union-Find with cluster member tracking
    parent = {rid: rid for rid in all_ids}
    members = {rid: [rid] for rid in all_ids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
            members[rb].extend(members[ra])
            del members[ra]

    def _edit_distance_1(a, b):
        la, lb = len(a), len(b)
        if abs(la - lb) > 1:
            return False
        if a == b:
            return True
        if la == lb:
            return sum(1 for i in range(la) if a[i] != b[i]) <= 1
        if la > lb:
            a, b = b, a
            la, lb = lb, la
        i = 0
        while i < la and a[i] == b[i]:
            i += 1
        return a[i:] == b[i + 1:]

    def _is_ambiguous(first):
        return first in ambiguous_names

    def _get_ssn4(ssn):
        if not ssn:
            return ''
        if len(ssn) == 4:
            return ssn
        if len(ssn) == 9:
            return ssn[-4:]
        return ''

    def _ssn_conflict(a_ssn, b_ssn):
        if not a_ssn or not b_ssn:
            return False
        if len(a_ssn) == 9 and len(b_ssn) == 9 and a_ssn != b_ssn:
            return True
        if len(a_ssn) == 4 and len(b_ssn) == 9 and b_ssn[-4:] != a_ssn:
            return True
        if len(b_ssn) == 4 and len(a_ssn) == 9 and a_ssn[-4:] != b_ssn:
            return True
        if len(a_ssn) == 4 and len(b_ssn) == 4 and a_ssn != b_ssn:
            return True
        return False

    def _pair_conflicts(id_a, id_b):
        """Check if two records directly contradict each other."""
        a = rec_by_id[id_a]
        b = rec_by_id[id_b]
        if a['last'] and b['last'] and a['last'] != b['last']:
            return True
        if a['dob'] and b['dob'] and a['dob'] != b['dob']:
            return True
        if _ssn_conflict(a['ssn'], b['ssn']):
            return True
        if (a['first'] and b['first']
                and not _is_ambiguous(a['first'])
                and not _is_ambiguous(b['first'])
                and a['first'] != b['first']):
            return True
        return False

    def _pair_score(id_a, id_b):
        """Score how strongly two records match (higher = more likely same person)."""
        a = rec_by_id[id_a]
        b = rec_by_id[id_b]
        score = 0

        if a['ssn'] and b['ssn'] and len(a['ssn']) == 9 and len(b['ssn']) == 9 and a['ssn'] == b['ssn']:
            score += 10

        ssn4_a = _get_ssn4(a['ssn'])
        ssn4_b = _get_ssn4(b['ssn'])
        if ssn4_a and ssn4_b and ssn4_a == ssn4_b:
            score += 3

        if a['mail'] and b['mail'] and a['mail'] == b['mail']:
            score += 2
        elif a['mail'] and b['mail'] and _edit_distance_1(a['mail'], b['mail']):
            score += 2

        if a['dob'] and b['dob'] and a['dob'] == b['dob']:
            score += 2

        if (a['first'] and b['first'] and a['first'] == b['first']
                and not _is_ambiguous(a['first'])):
            score += 3

        if a['first'] and b['first'] and a['first'] != b['first']:
            if _is_ambiguous(a['first']) or _is_ambiguous(b['first']):
                score += 1

        if a['phone'] and b['phone'] and a['phone'] == b['phone']:
            score += 1
        if a['address'] and b['address'] and a['address'] == b['address']:
            score += 1

        return score

    def _can_merge_clusters(ra, rb):
        """Check if merging two clusters would create any contradiction."""
        ma = members[ra]
        mb = members[rb]
        for ida in ma:
            for idb in mb:
                if _pair_conflicts(ida, idb):
                    return False
        return True

    # Candidate generation via blocking
    by_dob = defaultdict(list)
    by_phone = defaultdict(list)
    by_mail = defaultdict(list)
    by_ssn4 = defaultdict(list)
    by_ssn_full = defaultdict(list)

    for rid in all_ids:
        r = rec_by_id[rid]
        if r['dob']:
            by_dob[r['dob']].append(rid)
        if r['phone']:
            by_phone[r['phone']].append(rid)
        if r['mail']:
            by_mail[r['mail']].append(rid)
        ssn = r['ssn']
        if len(ssn) == 9:
            by_ssn_full[ssn].append(rid)
        if len(ssn) == 4:
            by_ssn4[ssn].append(rid)

    candidates = set()

    for group in by_dob.values():
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                candidates.add((group[i], group[j]))

    for group in by_phone.values():
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                candidates.add((group[i], group[j]))

    for group in by_mail.values():
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                candidates.add((group[i], group[j]))

    mail_keys = list(by_mail.keys())
    for i in range(len(mail_keys)):
        for j in range(i + 1, len(mail_keys)):
            if _edit_distance_1(mail_keys[i], mail_keys[j]):
                for ri in by_mail[mail_keys[i]]:
                    for rj in by_mail[mail_keys[j]]:
                        candidates.add((ri, rj))

    for s4, rids in by_ssn4.items():
        for full_ssn, full_rids in by_ssn_full.items():
            if full_ssn[-4:] == s4:
                for ri in rids:
                    for rj in full_rids:
                        candidates.add((ri, rj))
        for i in range(len(rids)):
            for j in range(i + 1, len(rids)):
                candidates.add((rids[i], rids[j]))

    for group in by_ssn_full.values():
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                candidates.add((group[i], group[j]))

    # Sort candidates by score (highest first) to prefer strong matches
    scored_candidates = []
    for id_a, id_b in candidates:
        if not _pair_conflicts(id_a, id_b):
            s = _pair_score(id_a, id_b)
            if s >= 5:
                scored_candidates.append((s, id_a, id_b))
    scored_candidates.sort(reverse=True)

    # Merge with cluster-level conflict checking
    for _score, id_a, id_b in scored_candidates:
        ra, rb = find(id_a), find(id_b)
        if ra != rb:
            if _can_merge_clusters(ra, rb):
                union(id_a, id_b)

    # Build clusters
    cluster_map = defaultdict(list)
    for rid in all_ids:
        cluster_map[find(rid)].append(rid)

    return {'clusters': list(cluster_map.values())}
