def compute(payload):
    """将链接和合并登记为 [起点,终点,生效时刻,失效时刻]。保留原顺序并补齐缺省区间。"""
    DEFAULT_FROM = 0
    DEFAULT_TO = 10**18
    result = []
    for link in payload.get("links", []):
        a = list(link["a"])
        b = list(link["b"])
        f = link.get("from", DEFAULT_FROM)
        t = link.get("to", DEFAULT_TO)
        result.append([a, b, f, t])
    for merge in payload.get("merges", []):
        a = list(merge["a"])
        b = list(merge["b"])
        f = merge.get("from", DEFAULT_FROM)
        t = merge.get("to", DEFAULT_TO)
        result.append([a, b, f, t])
    return result
