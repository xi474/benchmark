import hashlib
import json


def _find(parents, node):
    root = node
    while parents.get(root, root) != root:
        root = parents[root]
    while parents.get(node, node) != root:
        nxt = parents[node]
        parents[node] = root
        node = nxt
    return root


def _union(parents, a, b):
    ra, rb = _find(parents, a), _find(parents, b)
    if ra != rb:
        if ra < rb:
            parents[rb] = ra
        else:
            parents[ra] = rb


def combine(payload, windows, record_subjects):
    """Combine the two component JSON values under the business contract in TASK.md."""
    seed = payload["seed"]
    out_records = []
    for rec_info in record_subjects:
        table, row_id, time_val, subject_pair = rec_info
        tenant, subject = subject_pair
        parents = {}
        node = (tenant, subject)
        parents[node] = node
        for w in windows:
            a_pair, b_pair, w_from, w_to = w
            a_tup = tuple(a_pair)
            b_tup = tuple(b_pair)
            if w_from <= time_val < w_to:
                if a_tup not in parents:
                    parents[a_tup] = a_tup
                if b_tup not in parents:
                    parents[b_tup] = b_tup
                _union(parents, a_tup, b_tup)
        canonical = _find(parents, node)
        raw = json.dumps(
            [str(seed), canonical[0], canonical[1]],
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8")
        token = "ref_" + hashlib.sha256(raw).hexdigest()[:12]
        out_records.append({
            "table": table,
            "id": row_id,
            "time": time_val,
            "token": token,
        })
    return {"records": out_records}
