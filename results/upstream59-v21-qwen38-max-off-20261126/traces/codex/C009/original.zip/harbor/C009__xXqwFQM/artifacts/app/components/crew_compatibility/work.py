def compute(payload):
    """返回每辆车可使用的司机 ID 数组，保留司机声明顺序。"""
    vehicles = payload["vehicles"]
    drivers = payload["drivers"]
    result = {}
    for v in vehicles:
        compatible = []
        for d in drivers:
            if v["type"] in d["types"]:
                compatible.append(d["id"])
        result[v["id"]] = compatible
    return result
