def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    from itertools import product as iter_product

    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    sorted_events = left  # sorted by (visible, id)
    crew_compat = right   # vehicle_id -> [driver_ids]
    rounds = payload["rounds"]

    committed_assignments = []  # list of assignment dicts
    cancelled_jobs = set()
    all_round_results = []

    for rnd in rounds:
        cutoff = rnd["cutoff"]
        commit = rnd["commit"]

        # Determine visible events for this round
        visible_events = [e for e in sorted_events if e["visible"] <= cutoff]

        # Process cancellations
        new_cancelled = []
        ignored_cancellations = []
        for ev in visible_events:
            if ev["kind"] == "cancel":
                job_id = ev["job"]
                if job_id in cancelled_jobs:
                    continue
                # Check if any committed assignment has start < cutoff
                has_started = False
                for a in committed_assignments:
                    if a["job"] == job_id and a["start"] < cutoff:
                        has_started = True
                        break
                if has_started:
                    if job_id not in ignored_cancellations:
                        ignored_cancellations.append(job_id)
                else:
                    # Remove from committed if present (not yet started)
                    committed_assignments = [a for a in committed_assignments if a["job"] != job_id]
                    cancelled_jobs.add(job_id)
                    new_cancelled.append(job_id)

        # Collect pending jobs visible at this cutoff
        pending_jobs = {}
        for ev in visible_events:
            if ev["kind"] == "request":
                jid = ev["job"]["id"]
                if jid in cancelled_jobs:
                    continue
                # Check if already assigned (committed or tentative)
                already = False
                for a in committed_assignments:
                    if a["job"] == jid:
                        already = True
                        break
                if not already:
                    pending_jobs[jid] = ev["job"]

        # Optimize new assignments for this round
        new_assignments = _optimize(
            pending_jobs, vehicles, drivers, suppliers, crew_compat,
            committed_assignments, cutoff
        )

        # Build full assignment list for this round
        if commit:
            committed_assignments = committed_assignments + new_assignments

        all_assignments = committed_assignments + ([] if commit else new_assignments)
        # Sort by (job, start, vehicle, driver, supplier)
        all_assignments = sorted(all_assignments, key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))

        total_profit = sum(a["profit"] for a in all_assignments)

        cancelled_list = sorted(set(new_cancelled))
        ignored_list = sorted(set(ignored_cancellations))

        all_round_results.append({
            "cutoff": cutoff,
            "assignments": all_assignments,
            "profit": total_profit,
            "cancelled": cancelled_list,
            "ignored_cancellations": ignored_list,
        })

    return {"rounds": all_round_results}


def _optimize(pending_jobs, vehicles, drivers, suppliers, crew_compat,
              committed, cutoff):
    """Find optimal new assignments maximizing profit, then count, then lex-min."""
    if not pending_jobs:
        return []

    job_list = sorted(pending_jobs.keys())
    best = None  # (total_profit, count, tuple_list, assignments)

    def assign_key(a):
        return (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])

    def check_driver_constraints(driver_id, existing_tasks, new_task_start, new_task_end):
        """Check max_work, max_continuous, and break constraints for a driver."""
        drv = drivers[driver_id]
        all_tasks = existing_tasks + [(new_task_start, new_task_end)]
        all_tasks.sort()
        total_work = sum(e - s for s, e in all_tasks)
        if total_work > drv["max_work"]:
            return False
        # Check continuous work with break logic
        brk = drv["break"]
        max_cont = drv["max_continuous"]
        continuous = 0
        for i, (s, e) in enumerate(all_tasks):
            dur = e - s
            if i == 0:
                continuous = dur
            else:
                gap = s - all_tasks[i - 1][1]
                if gap >= brk:
                    continuous = dur
                else:
                    continuous += dur
            if continuous > max_cont:
                return False
        return True

    def overlaps(s1, e1, s2, e2):
        return s1 < e2 and s2 < e1

    def search(idx, current_new, current_profit, current_count,
               vehicle_schedule, driver_schedule, supplier_stock):
        nonlocal best

        if idx == len(job_list):
            tup = tuple(assign_key(a) for a in sorted(current_new, key=assign_key))
            candidate = (current_profit, current_count, tup)
            if best is None:
                best = (current_profit, current_count, tup, list(current_new))
            else:
                bp, bc, bt = best[0], best[1], best[2]
                if (current_profit > bp or
                    (current_profit == bp and current_count > bc) or
                    (current_profit == bp and current_count == bc and tup < bt)):
                    best = (current_profit, current_count, tup, list(current_new))
            return

        jid = job_list[idx]
        job = pending_jobs[jid]
        jtype = job["type"]
        qty = job["quantity"]
        release = job["release"]
        deadline = job["deadline"]
        duration = job["duration"]
        revenue = job["revenue"]
        job_suppliers = job["suppliers"]

        # Try skipping this job
        search(idx + 1, current_new, current_profit, current_count,
               vehicle_schedule, driver_schedule, supplier_stock)

        # Try assigning this job
        earliest_start = max(cutoff, release)

        for vid in sorted(vehicles.keys()):
            veh = vehicles[vid]
            if veh["type"] != jtype or veh["capacity"] < qty:
                continue
            compatible_drivers = crew_compat.get(vid, [])
            for did in compatible_drivers:
                for sid in job_suppliers:
                    sup = suppliers[sid]
                    if supplier_stock.get(sid, sup["stock"]) < qty:
                        continue
                    # Latest possible start considering supplier close and deadline
                    latest_start = min(deadline - duration, sup["close"])
                    if latest_start < earliest_start:
                        continue
                    # Try each valid start time
                    for start in range(earliest_start, latest_start + 1):
                        end = start + duration
                        if end > deadline:
                            break
                        # Check vehicle overlap
                        v_ok = True
                        for (vs, ve) in vehicle_schedule.get(vid, []):
                            if overlaps(start, end, vs, ve):
                                v_ok = False
                                break
                        if not v_ok:
                            continue
                        # Check driver overlap
                        d_ok = True
                        for (ds, de) in driver_schedule.get(did, []):
                            if overlaps(start, end, ds, de):
                                d_ok = False
                                break
                        if not d_ok:
                            continue
                        # Check driver constraints
                        driver_existing = driver_schedule.get(did, [])
                        if not check_driver_constraints(did, driver_existing, start, end):
                            continue

                        unit_cost = sup["unit_cost"]
                        cost = veh["cost"]
                        profit = revenue - qty * unit_cost - cost * duration

                        # Apply changes
                        new_a = {
                            "job": jid,
                            "vehicle": vid,
                            "driver": did,
                            "supplier": sid,
                            "start": start,
                            "end": end,
                            "quantity": qty,
                            "profit": profit,
                        }
                        vehicle_schedule[vid] = vehicle_schedule.get(vid, []) + [(start, end)]
                        driver_schedule[did] = driver_schedule.get(did, []) + [(start, end)]
                        old_stock = supplier_stock.get(sid, sup["stock"])
                        supplier_stock[sid] = old_stock - qty
                        current_new.append(new_a)

                        search(idx + 1, current_new,
                               current_profit + profit, current_count + 1,
                               vehicle_schedule, driver_schedule, supplier_stock)

                        # Undo
                        current_new.pop()
                        vehicle_schedule[vid] = vehicle_schedule[vid][:-1]
                        driver_schedule[did] = driver_schedule[did][:-1]
                        supplier_stock[sid] = old_stock

    # Build initial schedules from committed assignments
    vehicle_schedule = {}
    driver_schedule = {}
    supplier_stock = {}
    for a in committed:
        vid = a["vehicle"]
        did = a["driver"]
        sid = a["supplier"]
        vehicle_schedule.setdefault(vid, []).append((a["start"], a["end"]))
        driver_schedule.setdefault(did, []).append((a["start"], a["end"]))
        sup = suppliers[sid]
        if sid not in supplier_stock:
            supplier_stock[sid] = sup["stock"]
        supplier_stock[sid] -= a["quantity"]

    search(0, [], 0, 0, vehicle_schedule, driver_schedule, supplier_stock)

    if best is None:
        return []
    return best[3]
