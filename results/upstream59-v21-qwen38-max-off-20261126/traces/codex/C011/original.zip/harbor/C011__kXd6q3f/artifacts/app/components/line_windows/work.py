def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload["orders"]
    released = set(payload["released"])
    routing = payload["routing"]
    lines = payload["lines"]
    wip_list = payload["wip"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]

    # Build per-line WIP info: for each line, find max wip end
    line_wip_end = {}
    for w in wip_list:
        lid = w["line"]
        line_wip_end[lid] = max(line_wip_end.get(lid, 0), w["end"])

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]

        if sku not in released:
            result[oid] = []
            continue

        r = routing[sku]
        duration = r["setup"] + r["per_unit"] * qty

        triples = []
        for line in lines:
            lid = line["id"]
            if sku not in line["qualified"]:
                continue

            # Earliest start on this line: after all WIP + changeover, and after freeze
            earliest = freeze
            if lid in line_wip_end:
                earliest = max(earliest, line_wip_end[lid] + changeover)

            for ws, we in line["windows"]:
                # Task must fit entirely within [ws, we) and end <= due
                # start >= max(earliest, ws), end = start + duration <= min(we, due)
                s_min = max(earliest, ws)
                e_max = min(we, due)
                if s_min + duration <= e_max:
                    # Generate all valid integer start times
                    for s in range(s_min, e_max - duration + 1):
                        triples.append([lid, s, s + duration])

        result[oid] = triples
    return result
