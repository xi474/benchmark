def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    import itertools

    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    orders = {o["id"]: o for o in payload["orders"]}
    lots = payload["lots"]
    substitutes = payload.get("substitutes", {})
    wip_list = payload.get("wip", [])

    material_demand = left
    line_windows = right

    feasible_orders = [oid for oid in orders if line_windows.get(oid)]
    sorted_order_ids = sorted(feasible_orders, key=lambda oid: (orders[oid]["priority"], orders[oid]["due"], oid))

    order_demands = {}
    for oid in feasible_orders:
        order_demands[oid] = material_demand.get(oid, {})

    available_lots = [lot for lot in lots if lot["status"] == "PASS"]
    sub_map = dict(substitutes)

    def get_eligible_lots(comp, task_end, lot_remaining):
        valid_materials = sub_map.get(comp, [comp])
        eligible = []
        for lot in available_lots:
            if lot["material"] in valid_materials and lot["expiry"] >= task_end:
                if lot_remaining.get(lot["id"], 0) > 0:
                    eligible.append(lot)
        eligible.sort(key=lambda l: l["id"])
        return eligible

    def enumerate_allocations(comp, qty_needed, task_end, lot_remaining):
        """Enumerate all valid allocation splits for a single component demand.
        Returns list of [(lot_id, qty), ...] options, each consuming exactly qty_needed."""
        eligible = get_eligible_lots(comp, task_end, lot_remaining)
        if not eligible or qty_needed <= 0:
            return [[]] if qty_needed == 0 else []

        results = []
        def recurse(idx, remaining, current):
            if remaining == 0:
                results.append(list(current))
                return
            if idx >= len(eligible):
                return
            lot = eligible[idx]
            max_take = min(remaining, lot_remaining[lot["id"]])
            for take in range(0, max_take + 1):
                if take == 0:
                    recurse(idx + 1, remaining, current)
                else:
                    current.append((lot["id"], take))
                    recurse(idx + 1, remaining - take, current)
                    current.pop()
        recurse(0, qty_needed, [])
        return results

    def try_allocate_for_assignments(selected_assignments):
        """Try all valid global allocations. Return the one with lex-smallest alloc key, or None."""
        demands = []
        for oid, line, start, end in selected_assignments:
            for comp in sorted(order_demands[oid].keys()):
                qty = order_demands[oid][comp]
                if qty > 0:
                    demands.append((oid, comp, qty, end))
        demands.sort(key=lambda x: (x[0], x[1]))

        # We need to find allocation across all demands that respects shared lot inventory
        # and produces lex-smallest alloc key
        # Use recursive search with pruning

        best_global_alloc = None
        best_alloc_key = None

        def recurse(didx, lot_remaining, current_alloc, current_key_parts):
            nonlocal best_global_alloc, best_alloc_key

            if didx == len(demands):
                alloc_key = tuple(current_key_parts)
                if best_alloc_key is None or alloc_key < best_alloc_key:
                    best_alloc_key = alloc_key
                    best_global_alloc = {k: list(v) for k, v in current_alloc.items()}
                return

            oid, comp, qty_needed, task_end = demands[didx]
            eligible = get_eligible_lots(comp, task_end, lot_remaining)

            # Enumerate splits
            def split_recurse(eidx, rem, split):
                if rem == 0:
                    # Valid split found
                    new_lr = dict(lot_remaining)
                    for lid, q in split:
                        new_lr[lid] -= q
                    alloc_entry = tuple(sorted(split))
                    new_key = current_key_parts + [alloc_entry]

                    # Pruning
                    if best_alloc_key is not None:
                        partial = tuple(new_key)
                        if partial >= best_alloc_key[:len(partial)]:
                            return

                    current_alloc[(oid, comp)] = split
                    recurse(didx + 1, new_lr, current_alloc, new_key)
                    del current_alloc[(oid, comp)]
                    return

                if eidx >= len(eligible):
                    return

                lot = eligible[eidx]
                max_take = min(rem, lot_remaining[lot["id"]])
                # Try take from max down to 0? No, we want lex smallest alloc
                # alloc is (component, lot, qty) sorted. Smaller qty on earlier lot = lex smaller
                # Actually: alloc entries are sorted by (comp, lot, qty). 
                # For same comp, smaller lot id first. For same lot, smaller qty first.
                # To get lex smallest overall alloc tuple, we want minimal qty on earliest lots
                # Wait no - the alloc tuple per order is sorted. Let me think again.
                # The tiebreak is: per order (sorted by id), alloc = sorted (comp, lot, qty).
                # So for o2 with M demand 2: [("M","m1",1),("M","m2",1)] < [("M","m1",2)]
                # because at index 0: ("M","m1",1) < ("M","m1",2)
                # So we want to MINIMIZE qty on each lot, spreading across more lots.
                # Try take=1 first, then 2, etc. to find lex-smallest first.
                for take in range(1, max_take + 1):
                    split.append((lot["id"], take))
                    split_recurse(eidx + 1, rem - take, split)
                    split.pop()
                # Also try taking 0 from this lot
                split_recurse(eidx + 1, rem, split)

            split_recurse(0, qty_needed, [])

        init_lr = {lot["id"]: lot["qty"] for lot in available_lots}
        recurse(0, init_lr, {}, [])
        return best_global_alloc

    def check_line_conflicts(assignments):
        by_line = {}
        for oid, line, start, end in assignments:
            by_line.setdefault(line, []).append((start, end, oid))
        for line, tasks in by_line.items():
            all_tasks = []
            for w in wip_list:
                if w["line"] == line:
                    all_tasks.append((w["start"], w["end"], w["id"]))
            all_tasks.extend(tasks)
            all_tasks.sort()
            for i in range(len(all_tasks)):
                for j in range(i + 1, len(all_tasks)):
                    s1, e1, _ = all_tasks[i]
                    s2, e2, _ = all_tasks[j]
                    if s2 < e1 + changeover:
                        return False
        return True

    order_options = {}
    for oid in feasible_orders:
        order_options[oid] = [(t[0], t[1], t[2]) for t in line_windows[oid]]

    best_result = None
    best_key = None

    all_feasible = list(feasible_orders)
    n = len(all_feasible)

    for mask in range((1 << n) - 1, -1, -1):
        selected = [all_feasible[i] for i in range(n) if mask & (1 << i)]
        if not selected:
            continue

        pri_score = [0, 0, 0]
        for oid in selected:
            p = orders[oid]["priority"]
            pri_score[p - 1] += orders[oid]["qty"]

        comp_vec = tuple(1 if oid in selected else 0 for oid in sorted_order_ids)

        if best_key is not None:
            bp = best_key[0]
            if tuple(pri_score) < bp:
                continue
            if tuple(pri_score) == bp and comp_vec < best_key[1]:
                continue

        option_lists = [order_options[oid] for oid in selected]
        found_for_subset = False
        best_assignment_for_subset = None
        best_alloc_for_subset = None
        best_tiebreak = None

        for combo in itertools.product(*option_lists):
            assignments = [(selected[i], combo[i][0], combo[i][1], combo[i][2]) for i in range(len(selected))]

            if not check_line_conflicts(assignments):
                continue

            alloc = try_allocate_for_assignments(assignments)
            if alloc is None:
                continue

            tiebreak = []
            for oid in sorted(selected):
                for a_oid, a_line, a_start, a_end in assignments:
                    if a_oid == oid:
                        a_list = []
                        for comp in sorted(order_demands[oid].keys()):
                            if (oid, comp) in alloc:
                                for lot_id, qty in sorted(alloc[(oid, comp)]):
                                    if qty > 0:
                                        a_list.append((comp, lot_id, qty))
                        tiebreak.append((oid, a_line, a_start, a_end, tuple(a_list)))
                        break
            tiebreak = tuple(tiebreak)

            if best_tiebreak is None or tiebreak < best_tiebreak:
                best_tiebreak = tiebreak
                best_assignment_for_subset = assignments
                best_alloc_for_subset = alloc
                found_for_subset = True

        if found_for_subset:
            new_key = (tuple(pri_score), comp_vec, best_tiebreak)
            if best_key is None or \
               (tuple(pri_score) > best_key[0]) or \
               (tuple(pri_score) == best_key[0] and comp_vec > best_key[1]) or \
               (tuple(pri_score) == best_key[0] and comp_vec == best_key[1] and best_tiebreak < best_key[2]):
                best_key = new_key
                best_result = (selected, best_assignment_for_subset, best_alloc_for_subset)

    if best_result is None:
        selected_ids = []
        assignments = []
        alloc = {}
    else:
        selected_ids, assignments, alloc = best_result

    selected_ids_sorted = sorted(selected_ids)

    erp_orders = []
    for w in wip_list:
        erp_orders.append({
            "wo": w["id"],
            "run": run_id,
            "sku": w["sku"],
            "qty": w["qty"],
            "due": w["due"],
            "start": w["start"],
            "end": w["end"],
            "line": w["line"],
            "status": "WIP_CONT",
            "parent": None
        })
    assign_map = {}
    for oid, line, start, end in assignments:
        assign_map[oid] = (line, start, end)
    for oid in sorted(assign_map.keys()):
        line, start, end = assign_map[oid]
        o = orders[oid]
        erp_orders.append({
            "wo": oid,
            "run": run_id,
            "sku": o["sku"],
            "qty": o["qty"],
            "due": o["due"],
            "start": start,
            "end": end,
            "line": line,
            "status": "PLANNED",
            "parent": oid
        })
    erp_orders.sort(key=lambda x: x["wo"])

    erp = {
        "run": {"id": run_id, "freeze": freeze},
        "orders": erp_orders
    }

    mes_entries = []
    for w in wip_list:
        mes_entries.append({
            "line": w["line"],
            "start": w["start"],
            "wo": w["id"],
            "qty": w["qty"],
            "end": w["end"],
            "status": "WIP_CONT"
        })
    for oid, line, start, end in assignments:
        mes_entries.append({
            "line": line,
            "start": start,
            "wo": oid,
            "qty": orders[oid]["qty"],
            "end": end,
            "status": "PLANNED"
        })
    mes_entries.sort(key=lambda x: (x["line"], x["start"], x["wo"]))
    mes_result = []
    line_seq = {}
    for entry in mes_entries:
        lid = entry["line"]
        seq = line_seq.get(lid, 0) + 1
        line_seq[lid] = seq
        mes_result.append({
            "run": run_id,
            "line": lid,
            "seq": seq,
            "wo": entry["wo"],
            "qty": entry["qty"],
            "start": entry["start"],
            "end": entry["end"],
            "status": entry["status"]
        })

    wms_entries = []
    for oid in sorted(assign_map.keys()):
        for comp in sorted(order_demands[oid].keys()):
            if (oid, comp) in alloc:
                for lot_id, qty in sorted(alloc[(oid, comp)]):
                    if qty > 0:
                        wms_entries.append({
                            "wo": oid,
                            "component": comp,
                            "lot": lot_id,
                            "qty": qty
                        })
    wms_entries.sort(key=lambda x: (x["wo"], x["component"], x["lot"], x["qty"]))
    wms_result = []
    for i, entry in enumerate(wms_entries):
        wms_result.append({
            "reservation": f"r{i+1:04d}",
            "run": run_id,
            "wo": entry["wo"],
            "component": entry["component"],
            "lot": entry["lot"],
            "qty": entry["qty"],
            "status": "RESERVED"
        })

    return {
        "selected": selected_ids_sorted,
        "erp": erp,
        "mes": mes_result,
        "wms": wms_result
    }
