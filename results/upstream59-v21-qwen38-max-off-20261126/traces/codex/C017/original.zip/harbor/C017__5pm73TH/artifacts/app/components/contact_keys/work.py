def compute(payload):
    """保留批次和行序，为每条记录生成清理首尾空白并转小写的邮箱。"""
    result = []
    for batch in payload["batches"]:
        keys = []
        for record in batch:
            keys.append(record["email"].strip().lower())
        result.append(keys)
    return result
