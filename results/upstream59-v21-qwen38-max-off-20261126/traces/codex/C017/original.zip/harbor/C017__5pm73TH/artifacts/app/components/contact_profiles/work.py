def compute(payload):
    """保留批次和行序，返回 name,city,source,time 对象；姓名与城市的空白折叠为单个空格。"""
    import re
    def collapse(s):
        return re.sub(r'\s+', ' ', s).strip() if s else s
    result = []
    for batch in payload["batches"]:
        items = []
        for record in batch:
            items.append({
                "name": collapse(record.get("name", "")),
                "city": collapse(record.get("city", "")),
                "source": record["source"],
                "time": record["time"],
            })
        result.append(items)
    return result
