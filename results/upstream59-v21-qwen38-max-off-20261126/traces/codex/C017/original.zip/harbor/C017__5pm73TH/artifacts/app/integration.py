def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    # left = contact_keys result: list of batches of normalized emails
    # right = contact_profiles result: list of batches of {name, city, source, time}

    # State: email -> record dict with name, city, first_contact, sources, complete flag
    records = {}  # email -> {name, city, first_contact, sources (set), complete}

    batch_results = []

    for batch_idx in range(len(left)):
        keys = left[batch_idx]
        profiles = right[batch_idx]

        # Build temp view for this batch
        temp_entries = []
        conflict = False

        for i, email in enumerate(keys):
            prof = profiles[i]
            name = prof["name"]
            city = prof["city"]
            source = prof["source"]
            time_val = prof["time"]

            existing = records.get(email)

            if existing and existing["complete"]:
                # Already complete record - check for conflicts
                # Non-empty name/city in submission must match existing non-empty fields
                if name and existing["name"] and name != existing["name"]:
                    conflict = True
                    break
                if city and existing["city"] and city != existing["city"]:
                    conflict = True
                    break
                temp_entries.append(("duplicate", email, name, city, source, time_val))
            elif existing and not existing["complete"]:
                # Incomplete record - check conflicts with existing non-empty fields
                if name and existing["name"] and name != existing["name"]:
                    conflict = True
                    break
                if city and existing["city"] and city != existing["city"]:
                    conflict = True
                    break
                # Determine if this completes the record
                merged_name = name if name else existing["name"]
                merged_city = city if city else existing["city"]
                will_complete = bool(merged_name) and bool(merged_city)
                if will_complete:
                    temp_entries.append(("promoted", email, name, city, source, time_val))
                else:
                    temp_entries.append(("incomplete", email, name, city, source, time_val))
            else:
                # New record
                is_complete = bool(name) and bool(city)
                if is_complete:
                    temp_entries.append(("accepted", email, name, city, source, time_val))
                else:
                    temp_entries.append(("incomplete", email, name, city, source, time_val))

        if conflict:
            batch_results.append({"status": "rejected", "items": []})
            continue

        # Commit batch atomically
        items_status = []
        for entry in temp_entries:
            status, email, name, city, source, time_val = entry
            existing = records.get(email)

            if status == "duplicate":
                # Add source to existing complete record
                existing["sources"].add(source)
                items_status.append("duplicate")
            elif status == "promoted":
                merged_name = name if name else existing["name"]
                merged_city = city if city else existing["city"]
                existing["name"] = merged_name
                existing["city"] = merged_city
                existing["complete"] = True
                existing["sources"].add(source)
                items_status.append("promoted")
            elif status == "accepted":
                records[email] = {
                    "name": name,
                    "city": city,
                    "first_contact": time_val,
                    "sources": {source},
                    "complete": True,
                }
                items_status.append("accepted")
            elif status == "incomplete":
                if existing:
                    merged_name = name if name else existing["name"]
                    merged_city = city if city else existing["city"]
                    existing["name"] = merged_name
                    existing["city"] = merged_city
                    existing["sources"].add(source)
                else:
                    records[email] = {
                        "name": name,
                        "city": city,
                        "first_contact": time_val,
                        "sources": {source},
                        "complete": False,
                    }
                items_status.append("incomplete")

        batch_results.append({"status": "committed", "items": items_status})

    # Build final outputs
    accepted = []
    incomplete = []
    for email in sorted(records.keys()):
        rec = records[email]
        entry = {
            "email": email,
            "name": rec["name"],
            "city": rec["city"],
            "first_contact": rec["first_contact"],
            "sources": sorted(rec["sources"]),
        }
        if rec["complete"]:
            accepted.append(entry)
        else:
            incomplete.append(entry)

    # Build sources view: source -> sorted list of all emails that have that source
    sources_view = {}
    for email, rec in records.items():
        for src in rec["sources"]:
            if src not in sources_view:
                sources_view[src] = []
            sources_view[src].append(email)
    for src in sources_view:
        sources_view[src] = sorted(sources_view[src])

    return {
        "batches": batch_results,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_view,
    }
