def compute(payload):
    """每步按 Linux 终端键表编码为连续字节，返回十六进制字符串列表。"""
    KEY_MAP = {
        "Enter": b"\r",
        "C-c": b"\x03",
        "C-d": b"\x04",
        "C-u": b"\x15",
        "Tab": b"\t",
        "Backspace": b"\x7f",
    }
    result = []
    for step in payload.get("steps", []):
        buf = bytearray()
        for key in step.get("keys", []):
            if key in KEY_MAP:
                buf.extend(KEY_MAP[key])
            else:
                buf.extend(key.encode("utf-8"))
        result.append(buf.hex())
    return result
