def compute(payload):
    """输出 rc（固定主提示 PROMPT>、续行提示 CONT>、禁用历史、追加 startup）、timeout（缺省 4）、markers（原顺序的 until，可为 null）。"""
    startup = payload.get("startup", "") or ""
    timeout = payload.get("timeout_seconds", 4)
    if timeout is None:
        timeout = 4
    rc = "PS1='PROMPT> '\nPS2='CONT> '\nHISTFILE=/dev/null\n"
    if startup:
        rc += startup + "\n"
    else:
        rc += "\n"
    markers = [step.get("until") for step in payload.get("steps", [])]
    return {"rc": rc, "timeout": timeout, "markers": markers}
