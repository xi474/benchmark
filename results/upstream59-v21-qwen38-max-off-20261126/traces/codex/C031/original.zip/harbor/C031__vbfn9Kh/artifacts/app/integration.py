def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    import os
    import pty
    import select
    import signal
    import tempfile
    import time

    key_hex_list = left
    session_cfg = right

    rc_content = session_cfg["rc"]
    timeout = session_cfg["timeout"]
    markers = session_cfg["markers"]
    steps = payload.get("steps", [])

    tmpdir = tempfile.mkdtemp()
    hushlogin = os.path.join(tmpdir, ".hushlogin")
    with open(hushlogin, "w") as f:
        pass

    rc_file = os.path.join(tmpdir, ".bashrc_custom")
    with open(rc_file, "w") as f:
        f.write(rc_content)

    master_fd, slave_fd = pty.openpty()

    pid = os.fork()
    if pid == 0:
        os.close(master_fd)
        os.setsid()
        import fcntl
        import termios
        fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)
        os.dup2(slave_fd, 0)
        os.dup2(slave_fd, 1)
        os.dup2(slave_fd, 2)
        os.close(slave_fd)
        env = os.environ.copy()
        env["HOME"] = tmpdir
        env["TERM"] = "dumb"
        env["LC_ALL"] = "C"
        env["HISTFILE"] = "/dev/null"
        os.execvpe("/bin/bash", ["/bin/bash", "--noprofile", "--rcfile", rc_file, "-i"], env)
    else:
        os.close(slave_fd)
        try:
            chunks = []

            def read_until_marker(marker, timeout_sec):
                buf = b""
                deadline = time.monotonic() + timeout_sec
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    rlist, _, _ = select.select([master_fd], [], [], min(remaining, 0.1))
                    if rlist:
                        try:
                            data = os.read(master_fd, 4096)
                            if not data:
                                return buf, True
                            buf += data
                        except OSError:
                            return buf, True
                    if marker is not None and marker.encode("utf-8") in buf:
                        return buf, False
                return buf, False

            initial_data, eof = read_until_marker("PROMPT> ", timeout)
            text = initial_data.decode("utf-8", errors="replace")
            text = text.replace("\r\n", "\n").replace("\r", "")
            chunks.append(text)

            closed = eof
            for i, step in enumerate(steps):
                if closed:
                    chunks.append("")
                    continue
                hex_str = key_hex_list[i]
                raw_bytes = bytes.fromhex(hex_str)
                os.write(master_fd, raw_bytes)
                marker = markers[i]
                step_data, eof = read_until_marker(marker, timeout)
                if eof:
                    closed = True
                text = step_data.decode("utf-8", errors="replace")
                text = text.replace("\r\n", "\n").replace("\r", "")
                chunks.append(text)

            result = {"chunks": chunks, "closed": closed}
        finally:
            try:
                os.killpg(pid, signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                pass
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass
            try:
                os.close(master_fd)
            except OSError:
                pass
            import shutil
            shutil.rmtree(tmpdir, ignore_errors=True)

    return result
