def compute(payload):
    """输出 [入口地址, [[地址,字节],…]]，按加载后的地址升序排列，包括 PT_LOAD 零填充。"""
    import struct
    elf = bytes.fromhex(payload["elf_hex"])
    e_entry = struct.unpack_from("<I", elf, 24)[0]
    e_phoff = struct.unpack_from("<I", elf, 28)[0]
    e_phentsize = struct.unpack_from("<H", elf, 42)[0]
    e_phnum = struct.unpack_from("<H", elf, 44)[0]
    mem = {}
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        p_type = struct.unpack_from("<I", elf, off)[0]
        if p_type != 1:
            continue
        p_offset = struct.unpack_from("<I", elf, off + 4)[0]
        p_vaddr = struct.unpack_from("<I", elf, off + 8)[0]
        p_filesz = struct.unpack_from("<I", elf, off + 16)[0]
        p_memsz = struct.unpack_from("<I", elf, off + 20)[0]
        for j in range(p_filesz):
            mem[p_vaddr + j] = elf[p_offset + j]
        for j in range(p_filesz, p_memsz):
            mem[p_vaddr + j] = 0
    segments = sorted([[addr, mem[addr]] for addr in mem])
    return [e_entry, segments]
