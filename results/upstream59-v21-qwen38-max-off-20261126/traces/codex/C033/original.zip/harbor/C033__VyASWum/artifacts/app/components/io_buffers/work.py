def compute(payload):
    """返回 [文件名字页数组映射,标准输入字节数组]，未指定文件或 stdin 时为空。"""
    files_in = payload.get("files", {})
    file_map = {}
    for name, hex_str in files_in.items():
        file_map[name] = list(bytes.fromhex(hex_str))
    stdin_hex = payload.get("stdin_hex", "")
    stdin_bytes = list(bytes.fromhex(stdin_hex)) if stdin_hex else []
    return [file_map, stdin_bytes]
