def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    import struct

    entry_addr, mem_pairs = left
    file_map, stdin_bytes = right

    mem = {}
    for addr, val in mem_pairs:
        mem[addr] = val

    regs = [0] * 32
    regs[29] = payload.get("stack_pointer", 0x7fff0000)
    hi = 0
    lo = 0
    pc = entry_addr
    max_steps = payload.get("max_steps", 20000)
    steps = 0

    stdout_buf = bytearray()
    stderr_buf = bytearray()
    exit_code = None
    syscall_log = []

    fds = {0: stdin_bytes[:], 1: stdout_buf, 2: stderr_buf}
    fd_offsets = {0: 0}
    next_fd = 3
    open_files = {}

    files_state = {}
    for name, barray in file_map.items():
        files_state[name] = bytearray(barray)

    def sign_ext(val, bits):
        mask = (1 << bits) - 1
        val = val & mask
        if val & (1 << (bits - 1)):
            val -= (1 << bits)
        return val

    def to_u32(val):
        return val & 0xFFFFFFFF

    def read_mem_byte(addr):
        return mem.get(addr, 0)

    def write_mem_byte(addr, val):
        mem[addr] = val & 0xFF

    def read_mem_half(addr):
        b0 = read_mem_byte(addr)
        b1 = read_mem_byte(addr + 1)
        return (b1 << 8) | b0

    def write_mem_half(addr, val):
        write_mem_byte(addr, val & 0xFF)
        write_mem_byte(addr + 1, (val >> 8) & 0xFF)

    def read_mem_word(addr):
        b0 = read_mem_byte(addr)
        b1 = read_mem_byte(addr + 1)
        b2 = read_mem_byte(addr + 2)
        b3 = read_mem_byte(addr + 3)
        return (b3 << 24) | (b2 << 16) | (b1 << 8) | b0

    def write_mem_word(addr, val):
        write_mem_byte(addr, val & 0xFF)
        write_mem_byte(addr + 1, (val >> 8) & 0xFF)
        write_mem_byte(addr + 2, (val >> 16) & 0xFF)
        write_mem_byte(addr + 3, (val >> 24) & 0xFF)

    def handle_syscall():
        nonlocal exit_code, next_fd
        num = regs[2]
        a0, a1, a2 = regs[4], regs[5], regs[6]
        syscall_log.append({"number": num, "args": [a0, a1, a2]})
        if num == 4001:
            exit_code = a0 & 0xFF
            regs[7] = 0
        elif num == 4003:
            fd, buf_addr, count = a0, a1, a2
            data = fds.get(fd, [])
            offset = fd_offsets.get(fd, 0)
            result = bytearray()
            for i in range(count):
                if offset + i < len(data):
                    result.append(data[offset + i])
                else:
                    break
            for i, b in enumerate(result):
                write_mem_byte(buf_addr + i, b)
            fd_offsets[fd] = offset + len(result)
            regs[2] = len(result)
            regs[7] = 0
        elif num == 4004:
            fd, buf_addr, count = a0, a1, a2
            written = bytearray()
            for i in range(count):
                written.append(read_mem_byte(buf_addr + i))
            if fd == 1:
                stdout_buf.extend(written)
            elif fd == 2:
                stderr_buf.extend(written)
            else:
                if fd in fds and isinstance(fds[fd], bytearray):
                    fds[fd].extend(written)
            regs[2] = count
            regs[7] = 0
        elif num == 4005:
            filename_addr, flags, mode = a0, a1, a2
            name_bytes = bytearray()
            while True:
                ch = read_mem_byte(filename_addr + len(name_bytes))
                if ch == 0:
                    break
                name_bytes.append(ch)
            filename = name_bytes.decode("utf-8")
            fd = next_fd
            next_fd += 1
            if flags == 0:
                content = files_state.get(filename, bytearray())
                fds[fd] = bytearray(content)
                fd_offsets[fd] = 0
            elif flags == 1:
                fds[fd] = bytearray()
                fd_offsets[fd] = 0
                files_state[filename] = fds[fd]
            elif flags == 9:
                existing = files_state.get(filename, bytearray())
                fds[fd] = bytearray(existing)
                fd_offsets[fd] = len(fds[fd])
                files_state[filename] = fds[fd]
            open_files[fd] = filename
            regs[2] = fd
            regs[7] = 0
        elif num == 4006:
            fd = a0
            if fd in open_files:
                fname = open_files.pop(fd)
                if fd in fds and isinstance(fds[fd], bytearray):
                    files_state[fname] = fds[fd]
                del fds[fd]
                fd_offsets.pop(fd, None)
            regs[2] = 0
            regs[7] = 0

    while steps < max_steps and exit_code is None:
        insn = read_mem_word(pc)
        op = (insn >> 26) & 0x3F
        rs = (insn >> 21) & 0x1F
        rt = (insn >> 16) & 0x1F
        rd = (insn >> 11) & 0x1F
        sa = (insn >> 6) & 0x1F
        funct = insn & 0x3F
        imm16 = insn & 0xFFFF
        target26 = insn & 0x3FFFFFF

        next_pc = pc + 4
        delay_jump = False
        delay_target = 0

        if op == 0:
            if funct == 0:
                regs[rd] = to_u32(regs[rt] << sa)
            elif funct == 2:
                regs[rd] = to_u32(regs[rt] >> sa)
            elif funct == 3:
                val = regs[rt]
                regs[rd] = to_u32((val >> sa) | ((0xFFFFFFFF << (32 - sa)) if sa > 0 and (val & 0x80000000) else 0)) & 0xFFFFFFFF
            elif funct == 8:
                delay_jump = True
                delay_target = regs[rs]
            elif funct == 9:
                delay_jump = True
                delay_target = regs[rs]
                regs[31] = pc + 8
            elif funct == 32:
                regs[rd] = to_u32(sign_ext(regs[rs], 32) + sign_ext(regs[rt], 32))
            elif funct == 33:
                regs[rd] = to_u32(regs[rs] + regs[rt])
            elif funct == 34:
                regs[rd] = to_u32(sign_ext(regs[rs], 32) - sign_ext(regs[rt], 32))
            elif funct == 35:
                regs[rd] = to_u32(regs[rs] - regs[rt])
            elif funct == 36:
                regs[rd] = regs[rs] & regs[rt]
            elif funct == 37:
                regs[rd] = regs[rs] | regs[rt]
            elif funct == 38:
                regs[rd] = regs[rs] ^ regs[rt]
            elif funct == 39:
                regs[rd] = ~(regs[rs] | regs[rt]) & 0xFFFFFFFF
            elif funct == 42:
                regs[rd] = 1 if sign_ext(regs[rs], 32) < sign_ext(regs[rt], 32) else 0
            elif funct == 43:
                regs[rd] = 1 if regs[rs] < regs[rt] else 0
            elif funct == 16:
                regs[rd] = hi
            elif funct == 17:
                regs[rd] = lo
            elif funct == 18:
                hi = regs[rs]
            elif funct == 19:
                lo = regs[rs]
            elif funct == 24:
                product = sign_ext(regs[rs], 32) * sign_ext(regs[rt], 32)
                lo = to_u32(product & 0xFFFFFFFF)
                hi = to_u32((product >> 32) & 0xFFFFFFFF)
            elif funct == 25:
                product = regs[rs] * regs[rt]
                lo = to_u32(product & 0xFFFFFFFF)
                hi = to_u32((product >> 32) & 0xFFFFFFFF)
            elif funct == 26:
                s_rs = sign_ext(regs[rs], 32)
                s_rt = sign_ext(regs[rt], 32)
                if s_rt != 0:
                    q = int(s_rs / s_rt) if (s_rs < 0) == (s_rt < 0) or s_rs % s_rt == 0 else int(s_rs / s_rt)
                    r = s_rs - q * s_rt
                    lo = to_u32(q)
                    hi = to_u32(r)
            elif funct == 27:
                u_rs = regs[rs]
                u_rt = regs[rt]
                if u_rt != 0:
                    lo = to_u32(u_rs // u_rt)
                    hi = to_u32(u_rs % u_rt)
            elif funct == 12:
                handle_syscall()
        elif op == 2:
            delay_jump = True
            delay_target = ((pc + 4) & 0xF0000000) | (target26 << 2)
        elif op == 3:
            delay_jump = True
            delay_target = ((pc + 4) & 0xF0000000) | (target26 << 2)
            regs[31] = pc + 8
        elif op == 4:
            if regs[rs] == regs[rt]:
                delay_jump = True
                delay_target = (pc + 4 + (sign_ext(imm16, 16) << 2)) & 0xFFFFFFFF
        elif op == 5:
            if regs[rs] != regs[rt]:
                delay_jump = True
                delay_target = (pc + 4 + (sign_ext(imm16, 16) << 2)) & 0xFFFFFFFF
        elif op == 6:
            if sign_ext(regs[rs], 32) <= 0:
                delay_jump = True
                delay_target = (pc + 4 + (sign_ext(imm16, 16) << 2)) & 0xFFFFFFFF
        elif op == 7:
            if sign_ext(regs[rs], 32) > 0:
                delay_jump = True
                delay_target = (pc + 4 + (sign_ext(imm16, 16) << 2)) & 0xFFFFFFFF
        elif op == 8 or op == 9:
            regs[rt] = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
        elif op == 10:
            regs[rt] = 1 if sign_ext(regs[rs], 32) < sign_ext(imm16, 16) else 0
        elif op == 11:
            regs[rt] = 1 if regs[rs] < to_u32(sign_ext(imm16, 16)) else 0
        elif op == 12:
            regs[rt] = regs[rs] & imm16
        elif op == 13:
            regs[rt] = regs[rs] | imm16
        elif op == 14:
            regs[rt] = regs[rs] ^ imm16
        elif op == 15:
            regs[rt] = (imm16 << 16) & 0xFFFFFFFF
        elif op == 32:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            val = read_mem_byte(addr)
            regs[rt] = to_u32(sign_ext(val, 8))
        elif op == 36:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            regs[rt] = read_mem_byte(addr)
        elif op == 33:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            val = read_mem_half(addr)
            regs[rt] = to_u32(sign_ext(val, 16))
        elif op == 37:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            regs[rt] = read_mem_half(addr)
        elif op == 35:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            regs[rt] = read_mem_word(addr)
        elif op == 40:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            write_mem_byte(addr, regs[rt] & 0xFF)
        elif op == 41:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            write_mem_half(addr, regs[rt] & 0xFFFF)
        elif op == 43:
            addr = to_u32(sign_ext(regs[rs], 32) + sign_ext(imm16, 16))
            write_mem_word(addr, regs[rt])

        regs[0] = 0
        steps += 1

        if delay_jump:
            delay_insn = read_mem_word(next_pc)
            dop = (delay_insn >> 26) & 0x3F
            drs = (delay_insn >> 21) & 0x1F
            drt = (delay_insn >> 16) & 0x1F
            drd = (delay_insn >> 11) & 0x1F
            dsa = (delay_insn >> 6) & 0x1F
            dfunct = delay_insn & 0x3F
            dimm16 = delay_insn & 0xFFFF

            if dop == 0:
                if dfunct == 0:
                    regs[drd] = to_u32(regs[drt] << dsa)
                elif dfunct == 2:
                    regs[drd] = to_u32(regs[drt] >> dsa)
                elif dfunct == 3:
                    val = regs[drt]
                    regs[drd] = to_u32((val >> dsa) | ((0xFFFFFFFF << (32 - dsa)) if dsa > 0 and (val & 0x80000000) else 0)) & 0xFFFFFFFF
                elif dfunct == 32:
                    regs[drd] = to_u32(sign_ext(regs[drs], 32) + sign_ext(regs[drt], 32))
                elif dfunct == 33:
                    regs[drd] = to_u32(regs[drs] + regs[drt])
                elif dfunct == 34:
                    regs[drd] = to_u32(sign_ext(regs[drs], 32) - sign_ext(regs[drt], 32))
                elif dfunct == 35:
                    regs[drd] = to_u32(regs[drs] - regs[drt])
                elif dfunct == 36:
                    regs[drd] = regs[drs] & regs[drt]
                elif dfunct == 37:
                    regs[drd] = regs[drs] | regs[drt]
                elif dfunct == 38:
                    regs[drd] = regs[drs] ^ regs[drt]
                elif dfunct == 39:
                    regs[drd] = ~(regs[drs] | regs[drt]) & 0xFFFFFFFF
                elif dfunct == 42:
                    regs[drd] = 1 if sign_ext(regs[drs], 32) < sign_ext(regs[drt], 32) else 0
                elif dfunct == 43:
                    regs[drd] = 1 if regs[drs] < regs[drt] else 0
                elif dfunct == 16:
                    regs[drd] = hi
                elif dfunct == 17:
                    regs[drd] = lo
                elif dfunct == 18:
                    hi = regs[drs]
                elif dfunct == 19:
                    lo = regs[drs]
                elif dfunct == 24:
                    product = sign_ext(regs[drs], 32) * sign_ext(regs[drt], 32)
                    lo = to_u32(product & 0xFFFFFFFF)
                    hi = to_u32((product >> 32) & 0xFFFFFFFF)
                elif dfunct == 25:
                    product = regs[drs] * regs[drt]
                    lo = to_u32(product & 0xFFFFFFFF)
                    hi = to_u32((product >> 32) & 0xFFFFFFFF)
                elif dfunct == 26:
                    s_rs = sign_ext(regs[drs], 32)
                    s_rt = sign_ext(regs[drt], 32)
                    if s_rt != 0:
                        q = int(s_rs / s_rt) if (s_rs < 0) == (s_rt < 0) or s_rs % s_rt == 0 else int(s_rs / s_rt)
                        r = s_rs - q * s_rt
                        lo = to_u32(q)
                        hi = to_u32(r)
                elif dfunct == 27:
                    u_rs = regs[drs]
                    u_rt = regs[drt]
                    if u_rt != 0:
                        lo = to_u32(u_rs // u_rt)
                        hi = to_u32(u_rs % u_rt)
                elif dfunct == 12:
                    handle_syscall()
            elif dop == 8 or dop == 9:
                regs[drt] = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
            elif dop == 10:
                regs[drt] = 1 if sign_ext(regs[drs], 32) < sign_ext(dimm16, 16) else 0
            elif dop == 11:
                regs[drt] = 1 if regs[drs] < to_u32(sign_ext(dimm16, 16)) else 0
            elif dop == 12:
                regs[drt] = regs[drs] & dimm16
            elif dop == 13:
                regs[drt] = regs[drs] | dimm16
            elif dop == 14:
                regs[drt] = regs[drs] ^ dimm16
            elif dop == 15:
                regs[drt] = (dimm16 << 16) & 0xFFFFFFFF
            elif dop == 32:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                val = read_mem_byte(addr)
                regs[drt] = to_u32(sign_ext(val, 8))
            elif dop == 36:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                regs[drt] = read_mem_byte(addr)
            elif dop == 33:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                val = read_mem_half(addr)
                regs[drt] = to_u32(sign_ext(val, 16))
            elif dop == 37:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                regs[drt] = read_mem_half(addr)
            elif dop == 35:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                regs[drt] = read_mem_word(addr)
            elif dop == 40:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                write_mem_byte(addr, regs[drt] & 0xFF)
            elif dop == 41:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                write_mem_half(addr, regs[drt] & 0xFFFF)
            elif dop == 43:
                addr = to_u32(sign_ext(regs[drs], 32) + sign_ext(dimm16, 16))
                write_mem_word(addr, regs[drt])

            regs[0] = 0
            steps += 1
            pc = delay_target
        else:
            pc = next_pc

    out_files = {}
    for name, data in files_state.items():
        out_files[name] = data.hex()

    inspect_list = payload.get("inspect", [])
    inspect_result = []
    for item in inspect_list:
        addr = item["address"]
        length = item["length"]
        hex_str = ""
        for i in range(length):
            hex_str += format(mem.get(addr + i, 0), "02x")
        inspect_result.append({"address": addr, "hex": hex_str})

    return {
        "exit_code": exit_code if exit_code is not None else 0,
        "registers": regs,
        "hi": hi,
        "lo": lo,
        "steps": steps,
        "stdout_hex": stdout_buf.hex(),
        "stderr_hex": stderr_buf.hex(),
        "files": out_files,
        "inspect": inspect_result,
        "syscalls": syscall_log,
    }
