def compute(payload):
    """排除指向根的边，按 allowed 顺序返回节点下标对。"""
    nodes = payload["nodes"]
    allowed = payload["allowed"]
    root = payload["root"]
    node_idx = {n: i for i, n in enumerate(nodes)}
    root_idx = node_idx[root]
    result = []
    for parent, child in allowed:
        ci = node_idx[child]
        if ci != root_idx:
            result.append([node_idx[parent], ci])
    return result
