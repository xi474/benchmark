def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    cov = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload["max_parents"]
    n = len(nodes)
    node_idx = {nd: i for i, nd in enumerate(nodes)}
    root_idx = node_idx[root]
    # Build allowed parents for each child (exclude edges into root)
    allowed_parents = [[] for _ in range(n)]
    for p, c in allowed:
        pi, ci = node_idx[p], node_idx[c]
        if ci != root_idx:
            allowed_parents[ci].append(pi)
    # For each node, enumerate all subsets of allowed parents up to max_parents
    from itertools import combinations
    result = []
    for child in range(n):
        table = {}
        parents_list = sorted(allowed_parents[child])
        # Empty set
        table[""] = []
        for size in range(1, min(max_parents, len(parents_list)) + 1):
            for combo in combinations(parents_list, size):
                combo_sorted = tuple(sorted(combo))
                key = ",".join(str(x) for x in combo_sorted)
                # Compute regression coefficients: beta = Cov_PP^{-1} * Cov_Py
                pp = [[cov[p][q] for q in combo_sorted] for p in combo_sorted]
                py = [cov[p][child] for p in combo_sorted]
                # Solve pp @ beta = py using Gaussian elimination
                sz = len(combo_sorted)
                # Augmented matrix
                aug = [pp[i][:] + [py[i]] for i in range(sz)]
                for col in range(sz):
                    # Partial pivoting
                    max_row = col
                    for row in range(col + 1, sz):
                        if abs(aug[row][col]) > abs(aug[max_row][col]):
                            max_row = row
                    aug[col], aug[max_row] = aug[max_row], aug[col]
                    pivot = aug[col][col]
                    for row in range(col + 1, sz):
                        factor = aug[row][col] / pivot
                        for j in range(col, sz + 1):
                            aug[row][j] -= factor * aug[col][j]
                # Back substitution
                beta = [0.0] * sz
                for i in range(sz - 1, -1, -1):
                    s = aug[i][sz]
                    for j in range(i + 1, sz):
                        s -= aug[i][j] * beta[j]
                    beta[i] = s / aug[i][i]
                table[key] = beta
        result.append(table)
    return result
