def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    import math
    from itertools import combinations

    nodes = payload["nodes"]
    cov = payload["covariance"]
    mean_vec = payload["mean"]
    sample_size = payload["sample_size"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload["intervention"]
    n = len(nodes)
    node_idx = {nd: i for i, nd in enumerate(nodes)}

    # left = admissible edges as [parent_idx, child_idx] pairs
    # right = local regressions: list of dicts per node
    admissible = [tuple(e) for e in left]
    reg_tables = right  # list of dicts, one per node

    # Precompute residual variance for each (child, parent_set) combo
    # Residual variance = Cyy - CyP * CPP^{-1} * CPy
    def residual_variance(child, parents):
        cyy = cov[child][child]
        if not parents:
            return cyy
        pp = [[cov[p][q] for q in parents] for p in parents]
        py = [cov[p][child] for p in parents]
        sz = len(parents)
        aug = [pp[i][:] + [py[i]] for i in range(sz)]
        for col in range(sz):
            max_row = col
            for row in range(col + 1, sz):
                if abs(aug[row][col]) > abs(aug[max_row][col]):
                    max_row = row
            aug[col], aug[max_row] = aug[max_row], aug[col]
            pivot = aug[col][col]
            for row in range(col + 1, sz):
                factor = aug[row][col] / pivot
                for j in range(col, sz + 1):
                    aug[row][j] -= factor * aug[col][j]
        beta = [0.0] * sz
        for i in range(sz - 1, -1, -1):
            s = aug[i][sz]
            for j in range(i + 1, sz):
                s -= aug[i][j] * beta[j]
            beta[i] = s / aug[i][i]
        explained = sum(beta[i] * py[i] for i in range(sz))
        return cyy - explained

    # Build allowed parents per child from admissible edges
    allowed_parents_per_child = [[] for _ in range(n)]
    for pi, ci in admissible:
        allowed_parents_per_child[ci].append(pi)

    # Enumerate all valid DAGs via backtracking on edges
    # We select exactly edge_count edges from admissible list
    # Constraints: no cycles, each node's in-degree <= max_parents, root has no incoming

    best_score = None
    best_edges = None

    def has_cycle(selected_edges):
        # Build adjacency and check for cycle using topological sort
        adj = [[] for _ in range(n)]
        in_deg = [0] * n
        for pi, ci in selected_edges:
            adj[pi].append(ci)
            in_deg[ci] += 1
        queue = [i for i in range(n) if in_deg[i] == 0]
        visited = 0
        while queue:
            node = queue.pop()
            visited += 1
            for nb in adj[node]:
                in_deg[nb] -= 1
                if in_deg[nb] == 0:
                    queue.append(nb)
        return visited != n

    def score_dag(selected_edges):
        # Group edges by child
        parents_of = [[] for _ in range(n)]
        for pi, ci in selected_edges:
            parents_of[ci].append(pi)
        total = 0.0
        for child in range(n):
            parents = sorted(parents_of[child])
            rv = residual_variance(child, parents)
            total += sample_size * math.log(rv) + len(parents) * math.log(sample_size)
        return total

    def search(idx, selected, in_degree):
        nonlocal best_score, best_edges
        remaining = edge_count - len(selected)
        if remaining == 0:
            # Check cycle
            if not has_cycle(selected):
                sc = score_dag(selected)
                sc_rounded = round(sc, 9)
                sorted_edges = sorted(selected)
                if best_score is None or sc_rounded < best_score or (sc_rounded == best_score and sorted_edges < best_edges):
                    best_score = sc_rounded
                    best_edges = sorted_edges
            return
        if idx >= len(admissible):
            return
        # Pruning: not enough edges left
        if len(admissible) - idx < remaining:
            return
        pi, ci = admissible[idx]
        # Try including this edge
        if in_degree[ci] < max_parents:
            in_degree[ci] += 1
            selected.append((pi, ci))
            search(idx + 1, selected, in_degree)
            selected.pop()
            in_degree[ci] -= 1
        # Try excluding this edge
        search(idx + 1, selected, in_degree)

    search(0, [], [0] * n)

    if best_edges is None:
        return {"feasible": False}

    # Build final result
    edges_named = sorted([[nodes[p], nodes[c]] for p, c in best_edges])

    # Get coefficients from reg_tables
    parents_of = [[] for _ in range(n)]
    for pi, ci in best_edges:
        parents_of[ci].append(pi)

    coefficients = []
    for pi, ci in sorted(best_edges):
        key = ",".join(str(x) for x in sorted(parents_of[ci]))
        betas = reg_tables[ci][key]
        # Find the coefficient for parent pi in the sorted parent list
        sorted_parents = sorted(parents_of[ci])
        pos = sorted_parents.index(pi)
        slope = betas[pos]
        coefficients.append([nodes[pi], nodes[ci], round(slope, 6)])
    coefficients.sort()

    # Compute intercepts: intercept[child] = mean[child] - sum(beta_i * mean[parent_i])
    intercepts = {}
    for child in range(n):
        sp = sorted(parents_of[child])
        if sp:
            key = ",".join(str(x) for x in sp)
            betas = reg_tables[child][key]
            intercepts[child] = mean_vec[child] - sum(betas[i] * mean_vec[sp[i]] for i in range(len(sp)))
        else:
            intercepts[child] = mean_vec[child]

    # Intervention: set intervention node to value, cut all incoming edges
    int_node = node_idx[intervention["node"]]
    int_value = intervention["value"]

    # Intervened edges: edges that are NOT cut (i.e., not pointing to int_node)
    intervened_edges = sorted([[nodes[p], nodes[c]] for p, c in best_edges if c != int_node])

    # Compute post-intervention means via topological order
    post_mean = [0.0] * n
    post_mean[int_node] = int_value

    # Build adjacency for topo sort (excluding edges into int_node)
    adj = [[] for _ in range(n)]
    in_deg = [0] * n
    for pi, ci in best_edges:
        if ci != int_node:
            adj[pi].append(ci)
            in_deg[ci] += 1

    # Topological sort
    queue = [i for i in range(n) if in_deg[i] == 0]
    topo_order = []
    temp_in = in_deg[:]
    while queue:
        node = queue.pop(0)
        topo_order.append(node)
        for nb in adj[node]:
            temp_in[nb] -= 1
            if temp_in[nb] == 0:
                queue.append(nb)

    for node in topo_order:
        if node == int_node:
            continue
        sp = sorted(parents_of[node])
        # Only consider parents that are not cut (i.e., parent != int_node... actually edges into int_node are cut,
        # but we need edges where child != int_node. Parents of non-int nodes might include int_node.)
        # For non-int nodes, their parents in the DAG still apply, but if a parent is int_node, use int_value
        if sp:
            key = ",".join(str(x) for x in sp)
            betas = reg_tables[node][key]
            val = intercepts[node]
            for i, par in enumerate(sp):
                val += betas[i] * post_mean[par]
            post_mean[node] = val
        else:
            post_mean[node] = intercepts[node]

    mean_result = [round(post_mean[i], 6) for i in range(n)]

    return {
        "feasible": True,
        "edges": edges_named,
        "score": round(best_score, 6),
        "coefficients": coefficients,
        "intervened_edges": intervened_edges,
        "mean": mean_result
    }
