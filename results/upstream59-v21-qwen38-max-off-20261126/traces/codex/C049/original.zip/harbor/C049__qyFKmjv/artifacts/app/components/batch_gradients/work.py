import numpy as np


def compute(payload):
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]
    num_layers = len(layers)

    weights = [np.array(l["weight"], dtype=np.float64) for l in layers]
    biases = [np.array(l["bias"], dtype=np.float64) for l in layers]

    total_loss = 0.0
    num_mb = len(microbatches)

    grad_w = [np.zeros_like(w) for w in weights]
    grad_b = [np.zeros_like(b) for b in biases]

    for mb_idx, mb in enumerate(microbatches):
        inputs = np.array(mb["inputs"], dtype=np.float64)
        targets = mb["targets"]
        batch_size = inputs.shape[0]

        layer_pre_activations = []
        layer_post_activations = []

        current = inputs.copy()
        layer_post_activations.append(current.copy())

        for l_idx in range(num_layers):
            z = current @ weights[l_idx].T + biases[l_idx]
            layer_pre_activations.append(z.copy())

            if l_idx < num_layers - 1:
                current = np.tanh(z)
            else:
                current = z.copy()

            layer_post_activations.append(current.copy())

        logits = current

        max_logits = np.max(logits, axis=1, keepdims=True)
        exp_logits = np.exp(logits - max_logits)
        softmax = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)

        ce = -np.log(softmax[np.arange(batch_size), targets])
        mb_loss = np.mean(ce)
        total_loss += mb_loss

        d_logits = softmax.copy()
        d_logits[np.arange(batch_size), targets] -= 1.0
        d_logits /= batch_size

        delta = d_logits

        for l_idx in range(num_layers - 1, -1, -1):
            a_prev = layer_post_activations[l_idx]

            gw = delta.T @ a_prev
            gb = np.sum(delta, axis=0)

            grad_w[l_idx] += gw / num_mb
            grad_b[l_idx] += gb / num_mb

            if l_idx > 0:
                delta_prev = delta @ weights[l_idx]
                z_prev = layer_pre_activations[l_idx - 1]
                tanh_val = np.tanh(z_prev)
                delta = delta_prev * (1.0 - tanh_val ** 2)

    avg_loss = total_loss / num_mb

    gradients = []
    for l_idx in range(num_layers):
        gradients.append({
            "weight": grad_w[l_idx].tolist(),
            "bias": grad_b[l_idx].tolist()
        })

    return {
        "loss": float(avg_loss),
        "gradients": gradients
    }
