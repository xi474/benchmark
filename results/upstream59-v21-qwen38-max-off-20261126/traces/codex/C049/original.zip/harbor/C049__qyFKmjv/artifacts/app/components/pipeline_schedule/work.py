def compute(payload):
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]
    num_layers = len(layers)
    num_mb = len(microbatches)

    # Build partitions: rank r owns layers [floor(L*r/W), floor(L*(r+1)/W))
    partitions = []
    for r in range(world_size):
        start = (num_layers * r) // world_size
        stop = (num_layers * (r + 1)) // world_size
        partitions.append({
            "stage": r,
            "start": start,
            "stop": stop
        })

    # AFAB schedule: All-Forward-All-Backward
    # Forward: process each microbatch through all stages in order
    # After all forwards complete, backward in reverse microbatch order, reverse stage order
    events = []

    # Forward pass: microbatch order, stage order
    for mb_idx in range(num_mb):
        for stage_idx in range(world_size):
            events.append({
                "kind": "forward",
                "microbatch": mb_idx,
                "stage": stage_idx
            })
            # send_activation after non-last stage
            if stage_idx < world_size - 1:
                events.append({
                    "kind": "send_activation",
                    "source": stage_idx,
                    "target": stage_idx + 1
                })

    # Backward pass: reverse microbatch order, reverse stage order
    for mb_idx in range(num_mb - 1, -1, -1):
        for stage_idx in range(world_size - 1, -1, -1):
            events.append({
                "kind": "backward",
                "microbatch": mb_idx,
                "stage": stage_idx
            })
            # send_gradient after non-first stage (going backwards)
            if stage_idx > 0:
                events.append({
                    "kind": "send_gradient",
                    "source": stage_idx,
                    "target": stage_idx - 1
                })

    return {
        "partitions": partitions,
        "events": events
    }
