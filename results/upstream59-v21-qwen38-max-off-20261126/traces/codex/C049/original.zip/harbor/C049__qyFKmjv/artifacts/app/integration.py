def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    # left = batch_gradients result: {loss, gradients}
    # right = pipeline_schedule result: {partitions, events}
    return {
        "loss": left["loss"],
        "gradients": left["gradients"],
        "partitions": right["partitions"],
        "events": right["events"]
    }
