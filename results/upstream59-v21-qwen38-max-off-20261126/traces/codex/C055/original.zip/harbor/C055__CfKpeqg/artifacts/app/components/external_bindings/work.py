import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from yaml_parser import resolve_source


def compute(payload):
    """Parse untrusted sources: override + anchor resolution for untrusted docs."""
    sources = payload['sources']
    return resolve_source(sources, filter_trusted=False)
