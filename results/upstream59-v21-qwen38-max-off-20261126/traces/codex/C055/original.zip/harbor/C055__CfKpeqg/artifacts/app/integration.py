import json
import re


def combine(payload, left, right):
    """Combine trusted and external bindings into final output."""
    tags = payload.get('tags', False)
    keys = payload.get('keys', {})

    # Merge all entries from both components
    # left = trusted_bindings result, right = external_bindings result
    # Each is dict: key -> [source_idx, decl_pos, [val_pos, text, is_vault, source_trusted]]
    all_entries = {}
    for key, val in left.items():
        all_entries[key] = val
    for key, val in right.items():
        src_idx = val[0]
        if key in all_entries:
            existing_idx = all_entries[key][0]
            if src_idx >= existing_idx:
                all_entries[key] = val
        else:
            all_entries[key] = val

    # Check vault keys availability when tags=false
    if not tags:
        for key, entry in all_entries.items():
            val_info = entry[2]
            is_vault = val_info[2]
            if is_vault and key not in keys:
                return {"status": "sealed"}

    # Build final entries and compute render values
    # First pass: determine the final value info for each key
    final = {}
    for key in sorted(all_entries.keys()):
        entry = all_entries[key]
        src_idx = entry[0]
        decl_pos = entry[1]
        val_pos, text, is_vault, source_trusted = entry[2]

        if is_vault:
            if tags:
                # Keep vault as-is, trusted=false, render="[sealed]"
                trusted = False
                render = "[sealed]"
                dump_text = "!vault " + text[len("!vault "):]
            else:
                # Decrypt using keys mapping
                plain = keys[key]
                trusted = True
                render = plain
                dump_text = plain
        else:
            trusted = source_trusted
            dump_text = text
            render = text  # will be resolved in second pass

        final[key] = {
            'decl_pos': decl_pos,
            'val_pos': val_pos,
            'text': text,
            'is_vault': is_vault,
            'trusted': trusted,
            'render': render,
            'dump_text': dump_text,
        }

    # Second pass: resolve template references for trusted values
    # ${key} references are replaced with the render value of the referenced key
    # Only trusted plain values or decrypted vault values get template expansion
    def resolve_render(key, visited=None):
        if visited is None:
            visited = set()
        if key in visited:
            return final[key]['render']
        visited.add(key)
        info = final[key]
        if not info['trusted']:
            return info['render']
        text = info['render']
        def replacer(m):
            ref_key = m.group(1)
            if ref_key in final:
                return resolve_render(ref_key, visited)
            return m.group(0)
        return re.sub(r'\$\{([a-z]+)\}', replacer, text)

    for key in sorted(final.keys()):
        if final[key]['trusted']:
            final[key]['render'] = resolve_render(key)

    # Build entries list: [key, key_source, val_source, trusted, render]
    entries = []
    for key in sorted(final.keys()):
        info = final[key]
        entries.append([key, info['decl_pos'], info['val_pos'], info['trusted'], info['render']])

    # Build dump string
    dump_lines = []
    for key in sorted(final.keys()):
        info = final[key]
        if info['is_vault'] and tags:
            line = key + ': !vault ' + json.dumps(info['dump_text'].replace('!vault ', '', 1), ensure_ascii=False)
        else:
            line = key + ': ' + json.dumps(info['dump_text'], ensure_ascii=False)
        dump_lines.append(line)
    dump = '\n'.join(dump_lines) + '\n'

    return {
        "status": "ok",
        "entries": entries,
        "dump": dump,
    }
