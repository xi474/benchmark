"""Parse the flat-map YAML subset used by this task."""


def parse_yaml(yaml_text, source_name):
    """Parse flat YAML into list of entry dicts with position info."""
    entries = []
    lines = yaml_text.split('\n')
    for line_idx, line in enumerate(lines):
        lineno = line_idx + 1
        stripped = line.strip()
        if not stripped or stripped == '---':
            continue
        colon_pos = line.find(': ')
        if colon_pos < 0:
            continue
        key = line[:colon_pos]
        if not key or not all(c.islower() for c in key):
            continue
        val_start = colon_pos + 2
        raw_value = line[val_start:]
        decl_col = 1
        val_col = val_start + 1

        anchor = None
        alias = None
        is_vault = False
        text = raw_value

        if raw_value.startswith('&'):
            parts = raw_value.split(' ', 1)
            anchor = parts[0][1:]
            text = parts[1] if len(parts) > 1 else ''
        elif raw_value.startswith('*'):
            alias = raw_value[1:].strip()
            text = raw_value
        elif raw_value.startswith('!vault '):
            is_vault = True
            text = raw_value

        entries.append({
            'key': key,
            'decl_pos': [source_name, lineno, decl_col],
            'val_pos': [source_name, lineno, val_col],
            'text': text,
            'raw_value': raw_value,
            'is_vault': is_vault,
            'anchor': anchor,
            'alias': alias,
        })
    return entries


def resolve_source(sources, filter_trusted=None):
    """Parse sources and resolve anchors/aliases per-document.

    Returns dict: key -> [source_index, decl_pos, [val_pos, text, is_vault, source_trusted]]
    """
    result = {}

    for src_idx, source in enumerate(sources):
        trusted = source.get('trusted', False)
        if filter_trusted is not None and trusted != filter_trusted:
            continue

        name = source['name']
        yaml_text = source['yaml']
        entries = parse_yaml(yaml_text, name)

        anchors = {}
        for entry in entries:
            if entry['anchor'] is not None:
                anchors[entry['anchor']] = {
                    'val_pos': list(entry['val_pos']),
                    'text': entry['text'],
                    'is_vault': entry['is_vault'],
                }

        for entry in entries:
            key = entry['key']
            if entry['alias'] is not None:
                anchor_data = anchors.get(entry['alias'])
                if anchor_data is not None:
                    val_pos = anchor_data['val_pos']
                    text = anchor_data['text']
                    is_vault = anchor_data['is_vault']
                else:
                    val_pos = entry['val_pos']
                    text = entry['text']
                    is_vault = entry['is_vault']
            else:
                val_pos = entry['val_pos']
                text = entry['text']
                is_vault = entry['is_vault']

            result[key] = [
                src_idx,
                entry['decl_pos'],
                [val_pos, text, is_vault, trusted]
            ]

    return result
