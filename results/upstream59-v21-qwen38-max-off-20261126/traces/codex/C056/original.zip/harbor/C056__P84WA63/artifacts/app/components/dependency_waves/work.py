def compute(payload):
    """返回各依赖批次，每批含按 ID 升序排列的任务 ID。同批共享同一事实快照。"""
    tasks = payload["tasks"]
    task_map = {t["id"]: t for t in tasks}
    remaining = set(task_map.keys())
    completed = set()
    waves = []
    while remaining:
        wave = sorted(tid for tid in remaining if all(dep in completed for dep in task_map[tid]["needs"]))
        if not wave:
            break
        waves.append(wave)
        for tid in wave:
            remaining.discard(tid)
            completed.add(tid)
    return waves
