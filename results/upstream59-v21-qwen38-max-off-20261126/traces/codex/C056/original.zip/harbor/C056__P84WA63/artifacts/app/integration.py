def combine(payload, waves, feed_stats):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tasks_list = payload["tasks"]
    task_map = {t["id"]: t for t in tasks_list}
    initial = dict(payload["initial"])
    pools = payload["pools"]
    feeds = payload["feeds"]

    facts = dict(initial)
    pool_counters = {p: 0 for p in pools}
    feed_counters = {h: {s: 0 for s in feeds[h]} for h in feeds}
    pool_reads = {p: 0 for p in pools}
    feed_reads = {h: {s: 0 for s in feeds[h]} for h in feeds}

    task_results = {}

    for wave in waves:
        wave_deltas = {}
        host_delta_accum = {}
        for tid in wave:
            task = task_map[tid]
            pool_name = task["pool"]
            stream_name = task["stream"]
            attempts_needed = task["attempts"]

            # Pool round-robin
            hosts = pools[pool_name]
            idx = pool_counters[pool_name] % len(hosts)
            host = hosts[idx]
            pool_counters[pool_name] += 1
            pool_reads[pool_name] += 1

            # Feed round-robin
            feed_batches = feeds[host][stream_name]
            fidx = feed_counters[host][stream_name] % len(feed_batches)
            items = feed_batches[fidx]
            feed_counters[host][stream_name] += 1
            feed_reads[host][stream_name] += 1

            base = facts[host]
            parent = sum(task_results[dep]["delta"] for dep in task["needs"])

            delta = sum((base + item) * (1 + parent) for item in items)

            task_results[tid] = {
                "host": host,
                "items": list(items),
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": attempts_needed,
            }

            host_delta_accum[host] = host_delta_accum.get(host, 0) + delta

        for h, d in host_delta_accum.items():
            facts[h] += d

    return {
        "tasks": task_results,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads,
    }
