def compute(payload):
    """输出 [处理器声明顺序映射,叶节点到通知清单的映射]。叶节点按同一树位置编码；通知名去重并按声明顺序排列，含 rescue、always。"""
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})
    # Handler declaration order mapping: name -> index
    handler_order = {}
    for i, h in enumerate(handlers):
        if isinstance(h, str):
            handler_order[h] = i
        elif isinstance(h, dict) and "name" in h:
            handler_order[h["name"]] = i
    # Leaf node to notify list mapping
    notify_map = {}
    _walk_program(program, notify_map, "", handler_order)
    return [handler_order, notify_map]


def _walk_program(program, notify_map, prefix, handler_order):
    phases = ["pre", "roles", "includes", "tasks", "post"]
    for pi, phase in enumerate(phases):
        items = program.get(phase, [])
        if not isinstance(items, list):
            items = []
        for ii, item in enumerate(items):
            path = _make_path(prefix, pi, ii)
            _walk_item(item, notify_map, path, handler_order)


def _make_path(prefix, pi, ii):
    if prefix == "":
        return f"{pi}/{ii}"
    return f"{prefix}/{pi}/{ii}"


def _walk_item(item, notify_map, path, handler_order):
    if isinstance(item, dict) and "block" in item:
        block = item["block"]
        tasks = block.get("tasks", [])
        rescue = block.get("rescue", [])
        always = block.get("always", [])
        for ti, t in enumerate(tasks):
            _walk_item(t, notify_map, f"{path}/0/{ti}", handler_order)
        for ri, r in enumerate(rescue):
            _walk_item(r, notify_map, f"{path}/1/{ri}", handler_order)
        for ai, a in enumerate(always):
            _walk_item(a, notify_map, f"{path}/2/{ai}", handler_order)
    else:
        task = item if isinstance(item, dict) else {}
        notify = task.get("notify", [])
        if isinstance(notify, str):
            notify = [notify]
        if not isinstance(notify, list):
            notify = []
        # Deduplicate and sort by handler declaration order
        seen = set()
        ordered = []
        for n in notify:
            if n not in seen and n in handler_order:
                seen.add(n)
                ordered.append(n)
        # Sort by declaration order
        ordered.sort(key=lambda x: handler_order[x])
        if ordered:
            notify_map[path] = ordered
