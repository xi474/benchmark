def compute(payload):
    """每个 host 对应一张节点表，按树位置（各级整数以 / 分隔）记录 [可执行,会失败]；包含块节点。"""
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})
    result = {}
    for host in hosts:
        nodes = {}
        _walk_program(program, host, nodes, "")
        result[host] = nodes
    return result


def _walk_program(program, host, nodes, prefix):
    phases = ["pre", "roles", "includes", "tasks", "post"]
    for pi, phase in enumerate(phases):
        items = program.get(phase, [])
        if not isinstance(items, list):
            items = []
        for ii, item in enumerate(items):
            path = f"{prefix}{pi}/{ii}" if prefix == "" else f"{prefix}/{pi}/{ii}"
            # Rebuild path properly
            path = _make_path(prefix, pi, ii)
            _walk_item(item, host, nodes, path)


def _make_path(prefix, pi, ii):
    if prefix == "":
        return f"{pi}/{ii}"
    return f"{prefix}/{pi}/{ii}"


def _walk_item(item, host, nodes, path):
    if isinstance(item, dict) and "block" in item:
        block = item["block"]
        only = item.get("only")
        executable = _host_matches(host, only)
        nodes[path] = [executable, False]
        tasks = block.get("tasks", [])
        rescue = block.get("rescue", [])
        always = block.get("always", [])
        for ti, t in enumerate(tasks):
            _walk_item(t, host, nodes, f"{path}/0/{ti}")
        for ri, r in enumerate(rescue):
            _walk_item(r, host, nodes, f"{path}/1/{ri}")
        for ai, a in enumerate(always):
            _walk_item(a, host, nodes, f"{path}/2/{ai}")
    else:
        # It's a task
        task = item if isinstance(item, dict) else {}
        only = task.get("only")
        fail_hosts = task.get("fail_hosts")
        executable = _host_matches(host, only)
        will_fail = False
        if executable and isinstance(fail_hosts, list) and host in fail_hosts:
            will_fail = True
        nodes[path] = [executable, will_fail]


def _host_matches(host, only):
    if only is None:
        return True
    if isinstance(only, list):
        return host in only
    if isinstance(only, str):
        return host == only
    return True
