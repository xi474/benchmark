def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    hosts = payload.get("hosts", [])
    handlers_list = payload.get("handlers", [])
    program = payload.get("program", {})

    host_conditions = left
    handler_order_map = right[0] if isinstance(right, list) else {}
    leaf_notify_map = right[1] if isinstance(right, list) else {}

    if not hosts or not program:
        return {"batches": [], "final": {h: "ok" for h in hosts}}

    phases = ["pre", "roles", "includes", "tasks", "post"]

    # Build a tree of nodes for simulation
    tree = _build_tree(program, phases)

    class HostState:
        __slots__ = ['cursor', 'status', 'pending_notifs', 'failed']
        def __init__(self):
            self.cursor = []  # stack of (node, child_index, branch_context)
            self.status = "ok"
            self.pending_notifs = {}
            self.failed = False

    states = {h: HostState() for h in hosts}
    batches = []

    max_rounds = 10000
    for _ in range(max_rounds):
        candidates = []
        for h in hosts:
            st = states[h]
            resolved = _resolve(st, tree, host_conditions, h, handler_order_map, phases)
            if resolved is not None:
                candidates.append((resolved["canon_key"], h, resolved))

        if not candidates:
            break

        candidates.sort(key=lambda c: c[0])
        best_key = candidates[0][0]

        for ck, h, action in candidates:
            if ck == best_key:
                entries = _exec(h, action, states, tree, host_conditions,
                                leaf_notify_map, handler_order_map, program, phases)
                if isinstance(entries, list):
                    batches.extend(entries)
                else:
                    batches.append(entries)

    final = {h: states[h].status for h in hosts}
    return {"batches": batches, "final": final}


class Node:
    """Represents a node in the program tree."""
    __slots__ = ['ntype', 'path_tuple', 'path_str', 'phase_idx', 'children',
                 'block_tasks', 'block_rescue', 'block_always', 'task_data']
    def __init__(self, ntype, path_tuple, path_str, phase_idx):
        self.ntype = ntype  # 'task', 'block', 'flush'
        self.path_tuple = path_tuple
        self.path_str = path_str
        self.phase_idx = phase_idx
        self.children = []  # for phase-level children
        self.block_tasks = []
        self.block_rescue = []
        self.block_always = []
        self.task_data = None


def _build_tree(program, phases):
    """Build a tree representation of the program."""
    root = Node("root", (), "", -1)
    for pi, phase in enumerate(phases):
        items = program.get(phase, [])
        if not isinstance(items, list):
            items = []
        phase_node = Node("phase", (pi,), str(pi), pi)
        for ii, item in enumerate(items):
            pt = (pi, ii)
            ps = f"{pi}/{ii}"
            if isinstance(item, dict) and "block" in item:
                bnode = Node("block", pt, ps, pi)
                _fill_block(bnode, item["block"], pt, pi)
                phase_node.children.append(bnode)
            else:
                tnode = Node("task", pt, ps, pi)
                tnode.task_data = item
                phase_node.children.append(tnode)
        flush_node = Node("flush", (pi,), f"{pi}/flush", pi)
        phase_node.children.append(flush_node)
        root.children.append(phase_node)
    return root


def _fill_block(bnode, block, parent_pt, pi):
    tasks = block.get("tasks", [])
    rescue = block.get("rescue", [])
    always = block.get("always", [])
    for ti, t in enumerate(tasks):
        pt = parent_pt + (0, ti)
        ps = "/".join(str(x) for x in pt)
        if isinstance(t, dict) and "block" in t:
            child = Node("block", pt, ps, pi)
            _fill_block(child, t["block"], pt, pi)
            bnode.block_tasks.append(child)
        else:
            child = Node("task", pt, ps, pi)
            child.task_data = t
            bnode.block_tasks.append(child)
    for ri, r in enumerate(rescue):
        pt = parent_pt + (1, ri)
        ps = "/".join(str(x) for x in pt)
        if isinstance(r, dict) and "block" in r:
            child = Node("block", pt, ps, pi)
            _fill_block(child, r["block"], pt, pi)
            bnode.block_rescue.append(child)
        else:
            child = Node("task", pt, ps, pi)
            child.task_data = r
            bnode.block_rescue.append(child)
    for ai, a in enumerate(always):
        pt = parent_pt + (2, ai)
        ps = "/".join(str(x) for x in pt)
        if isinstance(a, dict) and "block" in a:
            child = Node("block", pt, ps, pi)
            _fill_block(child, a["block"], pt, pi)
            bnode.block_always.append(child)
        else:
            child = Node("task", pt, ps, pi)
            child.task_data = a
            bnode.block_always.append(child)


# Cursor format: list of frames
# Each frame: (node, child_index, branch_type)
# branch_type: 'phase_children', 'block_tasks', 'block_rescue', 'block_always'

def _resolve(state, tree, host_conds, host, handler_order_map, phases):
    """Find the next actionable node for this host."""
    if not state.cursor:
        # Start at root -> first phase
        state.cursor = [(tree, 0, 'phase_children')]

    while True:
        if not state.cursor:
            return None

        frame_node, child_idx, branch = state.cursor[-1]

        if frame_node.ntype == "root":
            children = frame_node.children
            if child_idx >= len(children):
                return None  # Done
            phase_node = children[child_idx]
            # Enter phase
            state.cursor[-1] = (frame_node, child_idx, branch)
            state.cursor.append((phase_node, 0, 'phase_children'))
            continue

        if frame_node.ntype == "phase":
            children = frame_node.children
            if child_idx >= len(children):
                # Phase done, go to next phase
                state.cursor.pop()
                if state.cursor:
                    parent_node, pidx, pbranch = state.cursor[-1]
                    state.cursor[-1] = (parent_node, pidx + 1, pbranch)
                continue
            child = children[child_idx]
            if child.ntype == "flush":
                pending = state.pending_notifs.get(frame_node.phase_idx, set())
                if pending:
                    handlers_sorted = sorted(pending, key=lambda h: handler_order_map.get(h, 999))
                    return {
                        "type": "flush",
                        "pi": frame_node.phase_idx,
                        "canon_key": (frame_node.phase_idx, (float('inf'),)),
                        "handlers": handlers_sorted,
                    }
                else:
                    state.pending_notifs.pop(frame_node.phase_idx, None)
                    # Advance past flush
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    if state.failed:
                        # Skip remaining phases
                        state.cursor = [(tree, len(tree.children), 'phase_children')]
                        return None
                    continue
            elif child.ntype == "block":
                cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                if not cond[0]:
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    continue
                # Enter block -> start with tasks
                state.cursor.append((child, 0, 'block_tasks'))
                continue
            elif child.ntype == "task":
                if state.failed:
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    continue
                cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                if not cond[0]:
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    continue
                will_fail = cond[1]
                return {
                    "type": "task",
                    "pstr": child.path_str,
                    "pt": child.path_tuple,
                    "pi": child.phase_idx,
                    "will_fail": will_fail,
                    "canon_key": (child.phase_idx, child.path_tuple),
                    "node": child,
                }
            else:
                state.cursor[-1] = (frame_node, child_idx + 1, branch)
                continue

        if frame_node.ntype == "block":
            if branch == 'block_tasks':
                tasks = frame_node.block_tasks
                if child_idx >= len(tasks):
                    # All normal tasks done (without failure) -> skip to always
                    if frame_node.block_always:
                        state.cursor[-1] = (frame_node, 0, 'block_always')
                    else:
                        # Block complete, pop
                        state.cursor.pop()
                        if state.cursor:
                            pn, pi2, pb = state.cursor[-1]
                            state.cursor[-1] = (pn, pi2 + 1, pb)
                    continue
                child = tasks[child_idx]
                if child.ntype == "block":
                    cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                    if not cond[0]:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    state.cursor.append((child, 0, 'block_tasks'))
                    continue
                elif child.ntype == "task":
                    if state.failed:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                    if not cond[0]:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    will_fail = cond[1]
                    return {
                        "type": "task",
                        "pstr": child.path_str,
                        "pt": child.path_tuple,
                        "pi": child.phase_idx,
                        "will_fail": will_fail,
                        "canon_key": (child.phase_idx, child.path_tuple),
                        "node": child,
                    }
                else:
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    continue

            elif branch == 'block_rescue':
                rescue = frame_node.block_rescue
                if child_idx >= len(rescue):
                    # Rescue done -> go to always
                    if frame_node.block_always:
                        state.cursor[-1] = (frame_node, 0, 'block_always')
                    else:
                        state.cursor.pop()
                        if state.cursor:
                            pn, pi2, pb = state.cursor[-1]
                            state.cursor[-1] = (pn, pi2 + 1, pb)
                    continue
                child = rescue[child_idx]
                if child.ntype == "block":
                    cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                    if not cond[0]:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    state.cursor.append((child, 0, 'block_tasks'))
                    continue
                elif child.ntype == "task":
                    cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                    if not cond[0]:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    will_fail = cond[1]
                    return {
                        "type": "task",
                        "pstr": child.path_str,
                        "pt": child.path_tuple,
                        "pi": child.phase_idx,
                        "will_fail": will_fail,
                        "canon_key": (child.phase_idx, child.path_tuple),
                        "node": child,
                    }
                else:
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    continue

            elif branch == 'block_always':
                always = frame_node.block_always
                if child_idx >= len(always):
                    # Always done -> block complete, pop
                    state.cursor.pop()
                    if state.cursor:
                        pn, pi2, pb = state.cursor[-1]
                        state.cursor[-1] = (pn, pi2 + 1, pb)
                    continue
                child = always[child_idx]
                if child.ntype == "block":
                    cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                    if not cond[0]:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    state.cursor.append((child, 0, 'block_tasks'))
                    continue
                elif child.ntype == "task":
                    cond = host_conds.get(host, {}).get(child.path_str, [True, False])
                    if not cond[0]:
                        state.cursor[-1] = (frame_node, child_idx + 1, branch)
                        continue
                    will_fail = cond[1]
                    return {
                        "type": "task",
                        "pstr": child.path_str,
                        "pt": child.path_tuple,
                        "pi": child.phase_idx,
                        "will_fail": will_fail,
                        "canon_key": (child.phase_idx, child.path_tuple),
                        "node": child,
                    }
                else:
                    state.cursor[-1] = (frame_node, child_idx + 1, branch)
                    continue

        # Fallback
        return None

    return None


def _exec(host, action, states, tree, host_conds, leaf_notify_map, handler_order_map, program, phases):
    st = states[host]

    if action["type"] == "flush":
        pi = action["pi"]
        handlers = action["handlers"]
        st.pending_notifs.pop(pi, None)
        # Advance past flush in cursor
        if st.cursor:
            fn, ci, br = st.cursor[-1]
            st.cursor[-1] = (fn, ci + 1, br)
        if st.failed:
            st.cursor = [(tree, len(tree.children), 'phase_children')]
        entries = [{"host": host, "task": None, "kind": "flush", "status": "ok", "handlers": handlers}]
        for hname in handlers:
            entries.append({"host": host, "task": None, "kind": "handler", "status": "ok"})
        return entries

    if action["type"] == "task":
        pstr = action["pstr"]
        pt = action["pt"]
        pi = action["pi"]
        will_fail = action["will_fail"]

        task_id = _get_task_id_from_data(action.get("node"))
        status = "failed" if will_fail else "ok"
        entry = {"host": host, "task": task_id, "kind": "task", "status": status}

        if not will_fail:
            notif_list = leaf_notify_map.get(pstr, [])
            if notif_list:
                if pi not in st.pending_notifs:
                    st.pending_notifs[pi] = set()
                st.pending_notifs[pi].update(notif_list)
            # Advance cursor
            if st.cursor:
                fn, ci, br = st.cursor[-1]
                st.cursor[-1] = (fn, ci + 1, br)
        else:
            _handle_failure_cursor(st, tree, pi)

        return entry

    return {"host": host, "task": None, "kind": "task", "status": "ok"}


def _get_task_id_from_data(node):
    if node and hasattr(node, 'task_data') and isinstance(node.task_data, dict):
        return node.task_data.get("id")
    return None


def _handle_failure_cursor(state, tree, fail_pi):
    """Handle task failure by manipulating the cursor."""
    # Walk up the cursor to find the enclosing block
    # The cursor stack has frames; we need to find the nearest block frame
    # and determine which branch we're in

    while len(state.cursor) > 0:
        fn, ci, br = state.cursor[-1]

        if fn.ntype == "block":
            if br == 'block_tasks':
                # Failed in normal tasks
                if fn.block_rescue:
                    # Jump to rescue
                    state.cursor[-1] = (fn, 0, 'block_rescue')
                    return
                elif fn.block_always:
                    # No rescue, go to always with failure
                    state.cursor[-1] = (fn, 0, 'block_always')
                    state.failed = True
                    state.status = "failed"
                    return
                else:
                    # No rescue, no always - propagate outward
                    state.failed = True
                    state.status = "failed"
                    state.cursor.pop()
                    if state.cursor:
                        pn, pi2, pb = state.cursor[-1]
                        state.cursor[-1] = (pn, pi2 + 1, pb)
                    continue

            elif br == 'block_rescue':
                # Failed in rescue
                if fn.block_always:
                    state.cursor[-1] = (fn, 0, 'block_always')
                    state.failed = True
                    state.status = "failed"
                    return
                else:
                    state.failed = True
                    state.status = "failed"
                    state.cursor.pop()
                    if state.cursor:
                        pn, pi2, pb = state.cursor[-1]
                        state.cursor[-1] = (pn, pi2 + 1, pb)
                    continue

            elif br == 'block_always':
                # Failed in always - propagate outward
                state.failed = True
                state.status = "failed"
                state.cursor.pop()
                if state.cursor:
                    pn, pi2, pb = state.cursor[-1]
                    state.cursor[-1] = (pn, pi2 + 1, pb)
                continue

        elif fn.ntype == "phase":
            # Top-level failure in a phase
            state.failed = True
            state.status = "failed"
            # Skip to flush
            # Find flush in remaining children
            found_flush = False
            children = fn.children
            for i in range(ci, len(children)):
                if children[i].ntype == "flush":
                    state.cursor[-1] = (fn, i, br)
                    found_flush = True
                    break
            if not found_flush:
                # Skip to next phase
                state.cursor.pop()
                if state.cursor:
                    pn, pi2, pb = state.cursor[-1]
                    state.cursor[-1] = (pn, pi2 + 1, pb)
            return

        else:
            # Pop and continue
            state.cursor.pop()
            if state.cursor:
                pn, pi2, pb = state.cursor[-1]
                state.cursor[-1] = (pn, pi2 + 1, pb)
            continue

    # Should not reach here normally
    state.failed = True
    state.status = "failed"
