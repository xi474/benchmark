def compute(payload):
    """对每个 complete 事件按原始位置记录 [正常完成事件名,新 revision 或 null]。取消与关闭优先级由整合逻辑决定。"""
    result = {}
    for idx, ev in enumerate(payload.get("events", [])):
        if ev.get("op") == "complete":
            new_rev = ev.get("revision") if ev.get("changed") else None
            event_name = "snapshot_updated" if ev.get("changed") else "poll_unchanged"
            result[str(idx)] = [event_name, new_rev]
    return result
