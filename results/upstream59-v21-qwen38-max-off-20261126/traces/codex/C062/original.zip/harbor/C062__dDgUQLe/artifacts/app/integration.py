def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    import copy
    events = payload.get("events", [])
    # Initialize stores from store_initializers component (left)
    stores = {}
    for idx_str, init_state in left.items():
        idx = int(idx_str)
        ev = events[idx]
        stores[ev["store"]] = copy.deepcopy(init_state)

    # Build completion effects lookup (right)
    completion_effects = {}
    for idx_str, effect in right.items():
        completion_effects[int(idx_str)] = effect

    # Track which jobs are cancelled (due to close with in-flight job)
    cancelled_jobs = set()
    # Track per-store: current in-flight job info
    # We need to simulate event processing order

    output_events = []
    # Per-store state tracking beyond what's in stores dict
    store_meta = {}  # store -> {"closing": bool, "close_waiters": int}

    for idx, ev in enumerate(events):
        store_name = ev["store"]
        op = ev["op"]
        t = ev["time"]

        if op == "open":
            output_events.append({"time": t, "store": store_name, "event": "opened"})

        elif op == "poll":
            st = stores[store_name]
            meta = store_meta.get(store_name, {})
            job = ev["job"]
            if st["state"] in ("closing", "closed"):
                output_events.append({"time": t, "store": store_name, "event": "poll_rejected"})
            elif st["job"] is not None:
                # Already has in-flight job, coalesce
                output_events.append({"time": t, "store": store_name, "event": "poll_coalesced"})
            else:
                # Start new job
                st["job"] = job
                output_events.append({"time": t, "store": store_name, "event": "poll_started", "job": job})

        elif op == "complete":
            st = stores[store_name]
            job = ev["job"]
            changed = ev.get("changed", False)

            if job in cancelled_jobs:
                # This complete is for a cancelled job
                output_events.append({"time": t, "store": store_name, "event": "callback_cancelled", "job": job})
                cancelled_jobs.discard(job)
                st["job"] = None
                # Check if we were closing and this was the last barrier
                meta = store_meta.get(store_name, {})
                if st["state"] == "closing" and st["job"] is None:
                    st["state"] = "closed"
                    st["closed_at"] = t
                    output_events.append({"time": t, "store": store_name, "event": "close_returned"})
            else:
                # Normal complete
                effect = completion_effects.get(idx)
                if effect:
                    event_name, new_rev = effect
                else:
                    event_name = "snapshot_updated" if changed else "poll_unchanged"
                    new_rev = ev.get("revision") if changed else None

                if changed and new_rev is not None:
                    st["revision"] = new_rev
                    st["updates"] += 1
                    output_events.append({"time": t, "store": store_name, "event": "snapshot_updated", "job": job})
                else:
                    output_events.append({"time": t, "store": store_name, "event": "poll_unchanged", "job": job})

                st["job"] = None
                # If closing and no more in-flight, transition to closed
                if st["state"] == "closing" and st["job"] is None:
                    st["state"] = "closed"
                    st["closed_at"] = t
                    output_events.append({"time": t, "store": store_name, "event": "close_returned"})

        elif op == "close":
            st = stores[store_name]
            if st["state"] == "closed":
                # Already closed, immediate return
                output_events.append({"time": t, "store": store_name, "event": "close_returned"})
            elif st["state"] == "closing":
                # Already closing, wait on same barrier
                output_events.append({"time": t, "store": store_name, "event": "close_waiting"})
            elif st["job"] is not None:
                # Has in-flight job, send cancel
                st["state"] = "closing"
                cancelled_jobs.add(st["job"])
                output_events.append({"time": t, "store": store_name, "event": "cancel_sent", "job": st["job"]})
                output_events.append({"time": t, "store": store_name, "event": "close_waiting"})
            else:
                # No in-flight job, close immediately
                st["state"] = "closed"
                st["closed_at"] = t
                output_events.append({"time": t, "store": store_name, "event": "close_returned"})

    return {"events": output_events, "stores": stores}
