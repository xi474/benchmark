def compute(payload):
    """按事务、语句、行变更生成已解码的列映射。D 用空对象；类型错误用 null，使整合端按事务回滚。"""
    EXPECTED_TYPES = {"key": "text", "body": "text", "rank": "int"}
    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        tx_decoded = []
        for stmt in tx.get("statements", []):
            stmt_decoded = []
            for op in stmt:
                if op["op"] == "D":
                    stmt_decoded.append({})
                    continue
                cols = op.get("cols", [])
                decoded = {}
                type_error = False
                for col in cols:
                    name = col["name"]
                    ctype = col["type"]
                    value = col["value"]
                    expected = EXPECTED_TYPES.get(name)
                    if expected is None or ctype != expected:
                        type_error = True
                        break
                    if name == "rank" and value is not None:
                        try:
                            decoded[name] = int(value)
                        except (ValueError, TypeError):
                            type_error = True
                            break
                    else:
                        decoded[name] = value
                if type_error:
                    stmt_decoded.append(None)
                else:
                    stmt_decoded.append(decoded)
            tx_decoded.append(stmt_decoded)
        result.append(tx_decoded)
    return result
