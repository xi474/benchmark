def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    left = row_identities result (consumed old keys per tx/statement)
    right = column_decoding result (decoded cols per tx/statement/op)
    """
    initial = payload.get("initial", {})
    txs = payload.get("txs", [])

    rows = {}
    for k, v in initial.items():
        rows[k] = {"body": v["body"], "rank": v["rank"]}

    committed_lsns = set()
    log = []

    for tx_idx, tx in enumerate(txs):
        lsn = tx["lsn"]
        if lsn in committed_lsns:
            log.append([lsn, "REPLAY"])
            continue

        statements = tx.get("statements", [])
        consumed_keys = left[tx_idx]
        decoded_ops = right[tx_idx]

        tx_snapshot = {k: {"body": v["body"], "rank": v["rank"]} for k, v in rows.items()}
        abort = False

        for stmt_idx, stmt in enumerate(statements):
            if abort:
                break
            stmt_consumed = consumed_keys[stmt_idx]
            stmt_decoded = decoded_ops[stmt_idx]

            for d in stmt_decoded:
                if d is None:
                    abort = True
                    break
            if abort:
                break

            for old_key in stmt_consumed:
                if old_key not in rows:
                    abort = True
                    break
            if abort:
                break

            # Per-statement snapshot for U inheritance
            stmt_snapshot = {k: {"body": v["body"], "rank": v["rank"]} for k, v in rows.items()}

            # Remove old identities
            working = {k: {"body": v["body"], "rank": v["rank"]} for k, v in rows.items()}
            for old_key in stmt_consumed:
                del working[old_key]

            # Place new rows
            new_keys_placed = set()
            for op_idx, op in enumerate(stmt):
                decoded = stmt_decoded[op_idx]
                if op["op"] == "I":
                    new_key = decoded["key"]
                    if new_key in working or new_key in new_keys_placed:
                        abort = True
                        break
                    new_keys_placed.add(new_key)
                    working[new_key] = {
                        "body": decoded.get("body"),
                        "rank": decoded.get("rank")
                    }
                elif op["op"] == "U":
                    old_key = op["old"]
                    old_row = stmt_snapshot[old_key]
                    new_key = decoded.get("key", old_key)
                    new_body = decoded["body"] if "body" in decoded else old_row["body"]
                    new_rank = decoded["rank"] if "rank" in decoded else old_row["rank"]
                    if new_key != old_key:
                        if new_key in working or new_key in new_keys_placed:
                            abort = True
                            break
                    new_keys_placed.add(new_key)
                    working[new_key] = {"body": new_body, "rank": new_rank}

            if abort:
                break

            rows = working

        if abort:
            rows = tx_snapshot
            log.append([lsn, "ABORT"])
        else:
            committed_lsns.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": rows}
