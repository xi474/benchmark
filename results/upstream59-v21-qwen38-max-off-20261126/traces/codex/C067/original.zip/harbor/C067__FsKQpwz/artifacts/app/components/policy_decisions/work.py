def compute(payload):
    """按输入顺序重放策略变更，为每个 request 原位置生成授权布尔值。"""
    policies = {user: list(rules) for user, rules in payload.get("policies", {}).items()}
    events = payload.get("events", [])
    decisions = {}
    req_index = 0
    for event in events:
        op = event.get("op")
        if op == "policy":
            user = event["user"]
            policies[user] = list(event.get("allow", []))
        elif op == "request":
            user = event["user"]
            cluster = event["cluster"]
            verb = event["verb"]
            service = event.get("service")
            allowed = False
            user_rules = policies.get(user, [])
            for rule in user_rules:
                if rule["cluster"] != cluster:
                    continue
                if rule["verb"] != verb:
                    continue
                rule_service = rule.get("service")
                if rule_service is None or rule_service == "*":
                    allowed = True
                    break
                if service is not None and rule_service == service:
                    allowed = True
                    break
            decisions[str(req_index)] = allowed
            req_index += 1
    return decisions
