def compute(payload):
    """按事件位置返回请求当时的 [集群模式,服务是否可用]；合并端负责授权优先和实际计数。"""
    clusters = {}
    for cname, cinfo in payload.get("clusters", {}).items():
        clusters[cname] = {
            "mode": cinfo["mode"],
            "services": dict(cinfo.get("services", {}))
        }
    events = payload.get("events", [])
    results = {}
    req_index = 0
    for event in events:
        op = event.get("op")
        if op == "service":
            cluster = event["cluster"]
            service = event["service"]
            available = event["available"]
            if cluster in clusters:
                clusters[cluster]["services"][service] = available
        elif op == "request":
            cluster = event["cluster"]
            service = event.get("service")
            cinfo = clusters.get(cluster)
            if cinfo is None:
                mode = "unknown"
                svc_available = False
            else:
                mode = cinfo["mode"]
                svc_available = cinfo["services"].get(service, False) if service else False
            results[str(req_index)] = [mode, svc_available]
            req_index += 1
    return results
