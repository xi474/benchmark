def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload.get("events", [])

    replies = []
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0
    cert_counter = 0
    cache = {}

    req_index = 0
    for event in events:
        if event.get("op") != "request":
            continue

        authorized = left[str(req_index)]
        mode, svc_available = right[str(req_index)]
        req_index += 1

        authorizer_calls += 1

        if not authorized:
            replies.append({"id": event["id"], "status": "denied"})
            continue

        service_lookups += 1

        if not svc_available:
            replies.append({"id": event["id"], "status": "not_found"})
            continue

        user = event["user"]
        cluster = event["cluster"]
        service = event["service"]
        now = event["time"]

        if mode == "local":
            replies.append({
                "id": event["id"],
                "status": "ok",
                "credential": "local",
                "route": "local"
            })
        else:
            remote_routes += 1
            cache_key = (user, cluster, service)
            entry = cache.get(cache_key)
            if entry is not None and entry["expires"] > now:
                credential = entry["credential"]
            else:
                cert_counter += 1
                credential = f"cert-{cert_counter}"
                certificates_issued += 1
                cache[cache_key] = {
                    "credential": credential,
                    "expires": now + ttl
                }
            replies.append({
                "id": event["id"],
                "status": "ok",
                "credential": credential,
                "route": "reverse_tunnel"
            })

    sorted_keys = sorted(cache.keys())
    cache_list = []
    for key in sorted_keys:
        entry = cache[key]
        cache_list.append({
            "user": key[0],
            "cluster": key[1],
            "service": key[2],
            "credential": entry["credential"],
            "expires": entry["expires"]
        })

    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": cache_list
    }
