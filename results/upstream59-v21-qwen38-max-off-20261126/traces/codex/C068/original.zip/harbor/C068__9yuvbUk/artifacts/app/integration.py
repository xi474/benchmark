def combine(payload, cleanup_clock_data, load_proposals_data):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # Cache: key -> {"value": ..., "error": ..., "expires": ...}
    cache = {}
    next_cleanup = 16 * ttl

    # In-flight loads: key -> {"started_at": ..., "finished_at": ..., "value": ..., "error": ..., "waiters": [...]}
    inflight = {}

    # Completed loads list (only actually started ones)
    loads = []

    # Results indexed by get id
    results_map = {}
    # Track order of get ids
    get_order = []

    # Pending gets waiting for a load to complete: list of (id, key, time_of_get)
    # They are resolved when the load completes
    pending_gets = {}  # id -> {"key": ..., "get_time": ...}

    # Collect all event times and process in order
    # We need to process events sequentially, completing loads before each event

    def complete_loads_up_to(now):
        """Complete all in-flight loads whose finished_at <= now, in start order."""
        while True:
            # Find the earliest finishing in-flight load with finished_at <= now
            candidates = [(k, v) for k, v in inflight.items() if v["finished_at"] <= now]
            if not candidates:
                break
            # Sort by started_at (start order), then by key for stability
            candidates.sort(key=lambda x: (x[1]["started_at"], x[0]))
            key, info = candidates[0]
            finish_time = info["finished_at"]
            value = info["value"]
            error = info["error"]

            # Stamp cache
            cache[key] = {
                "value": value if error is None else None,
                "error": error,
                "expires": finish_time + ttl
            }

            # Record load
            loads.append({
                "key": key,
                "started_at": info["started_at"],
                "finished_at": finish_time
            })

            # Resolve waiters
            for waiter_id in info["waiters"]:
                if waiter_id in cancelled_ids:
                    results_map[waiter_id] = {
                        "id": waiter_id,
                        "status": "cancelled",
                        "value": None,
                        "error": "cancelled",
                        "finished_at": finish_time
                    }
                else:
                    if error is not None:
                        results_map[waiter_id] = {
                            "id": waiter_id,
                            "status": "error",
                            "value": None,
                            "error": error,
                            "finished_at": finish_time
                        }
                    else:
                        results_map[waiter_id] = {
                            "id": waiter_id,
                            "status": "ok",
                            "value": value,
                            "error": None,
                            "finished_at": finish_time
                        }

            del inflight[key]

    cancelled_ids = set()

    for idx, ev in enumerate(events):
        op = ev["op"]

        if op == "advance":
            t = ev["time"]
            complete_loads_up_to(t)

        elif op == "cancel":
            cid = ev["id"]
            cancelled_ids.add(cid)
            # If this get was pending (waiting for a load), mark it cancelled
            # The actual result will be set when the load completes
            # But we also need to handle the case where the load already completed
            # Actually cancel just marks; resolution happens at load completion
            # If the waiter hasn't been resolved yet, it stays pending until load completes

        elif op == "get":
            gid = ev["id"]
            key = ev["key"]
            delay = ev["delay"]
            value = ev["value"]
            error = ev.get("error")
            t = ev["time"]

            get_order.append(gid)

            # Before processing this get, complete loads up to current time
            complete_loads_up_to(t)

            # Check if cleanup is needed
            if t >= next_cleanup:
                # Remove all expired entries
                expired_keys = [k for k, v in cache.items() if v["expires"] <= t]
                for k in expired_keys:
                    del cache[k]
                next_cleanup = t + 16 * ttl

            # Also remove this specific key if expired
            if key in cache and cache[key]["expires"] <= t:
                del cache[key]

            # Check cache hit
            if key in cache:
                entry = cache[key]
                if entry["error"] is not None:
                    results_map[gid] = {
                        "id": gid,
                        "status": "error",
                        "value": None,
                        "error": entry["error"],
                        "finished_at": t
                    }
                else:
                    results_map[gid] = {
                        "id": gid,
                        "status": "ok",
                        "value": entry["value"],
                        "error": None,
                        "finished_at": t
                    }
            elif key in inflight:
                # Join existing in-flight load
                inflight[key]["waiters"].append(gid)
            else:
                # Start new load
                finished_at = t + delay
                if delay == 0:
                    # Completes immediately within this get
                    # Stamp cache
                    cache[key] = {
                        "value": value if error is None else None,
                        "error": error,
                        "expires": finished_at + ttl
                    }
                    loads.append({
                        "key": key,
                        "started_at": t,
                        "finished_at": finished_at
                    })
                    if error is not None:
                        results_map[gid] = {
                            "id": gid,
                            "status": "error",
                            "value": None,
                            "error": error,
                            "finished_at": finished_at
                        }
                    else:
                        results_map[gid] = {
                            "id": gid,
                            "status": "ok",
                            "value": value,
                            "error": None,
                            "finished_at": finished_at
                        }
                else:
                    # Start in-flight load
                    inflight[key] = {
                        "started_at": t,
                        "finished_at": finished_at,
                        "value": value,
                        "error": error,
                        "waiters": [gid]
                    }

    # Build final results in get order
    results = [results_map[gid] for gid in get_order]

    # Build cache output sorted by key
    cache_out = []
    for k in sorted(cache.keys()):
        entry = cache[k]
        cache_out.append({
            "key": k,
            "value": entry["value"],
            "error": entry["error"],
            "expires": entry["expires"]
        })

    return {
        "results": results,
        "loads": loads,
        "cache": cache_out,
        "next_cleanup": next_cleanup
    }
