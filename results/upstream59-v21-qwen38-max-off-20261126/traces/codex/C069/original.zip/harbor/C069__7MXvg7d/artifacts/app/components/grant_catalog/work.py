def compute(payload):
    """Generate grant catalog entries with approval status, expiry, roles, resources."""
    access_requests = payload.get("access_requests", {})
    result = {}
    for req_id, req in access_requests.items():
        entry = {
            "approved": req.get("approved", False),
            "expiry": req["expiry"],
            "roles": sorted(req.get("roles", [])),
            "resources": sorted(req.get("resources", [])),
        }
        result[req_id] = entry
    return result
