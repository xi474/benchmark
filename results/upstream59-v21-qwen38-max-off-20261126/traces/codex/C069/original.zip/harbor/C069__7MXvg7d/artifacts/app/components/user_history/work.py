def compute(payload):
    """Record user snapshots at update_user events, keyed by position string."""
    import copy
    user = copy.deepcopy(payload["user"])
    events = payload.get("events", [])
    result = {}
    # Index 0 is always the initial user state
    result["0"] = copy.deepcopy(user)
    idx = 1
    for ev in events:
        if ev.get("op") == "update_user":
            updates = ev.get("user", {})
            if "roles" in updates:
                user["roles"] = list(updates["roles"])
            if "traits" in updates:
                user["traits"] = copy.deepcopy(updates["traits"])
            result[str(idx)] = copy.deepcopy(user)
            idx += 1
    return result
