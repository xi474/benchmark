def combine(payload, left, right):
    """Combine user_history and grant_catalog to produce session replies and certificates."""
    import base64
    import copy
    import json

    user_base = payload["user"]
    start_time = payload["start_time"]
    session_ttl = payload["session_ttl"]
    events = payload.get("events", [])
    initial_id = payload.get("initial_id", "s0")

    # left = user_history snapshots keyed by string index
    # right = grant_catalog entries keyed by request id
    grant_catalog = right

    sessions = {}
    session_order = [initial_id]
    sessions[initial_id] = {
        "login_time": start_time,
        "expiry": start_time + session_ttl,
        "cached_user": copy.deepcopy(user_base),
        "active_requests": {},
    }

    replies = []

    for ev in events:
        op = ev.get("op")
        if op == "update_user":
            updates = ev.get("user", {})
            if "roles" in updates:
                user_base["roles"] = list(updates["roles"])
            if "traits" in updates:
                user_base["traits"] = copy.deepcopy(updates["traits"])
            continue

        if op != "renew":
            continue

        new_id = ev["id"]
        prev_id = ev["prev"]
        now = ev["time"]
        reload_user = ev.get("reload_user", False)
        switchback = ev.get("switchback", False)
        assume_req = ev.get("access_request", None)

        if prev_id not in sessions:
            replies.append({"id": new_id, "status": "error"})
            continue

        prev = sessions[prev_id]

        if prev["expiry"] <= now:
            replies.append({"id": new_id, "status": "expired"})
            continue

        if reload_user:
            cached_user = copy.deepcopy(user_base)
        else:
            cached_user = copy.deepcopy(prev["cached_user"])

        active_requests = dict(prev["active_requests"])

        if switchback:
            active_requests = {}

        if assume_req is not None:
            req_info = grant_catalog.get(assume_req)
            if req_info is None or not req_info["approved"]:
                replies.append({"id": new_id, "status": "request_unavailable"})
                continue
            if req_info["expiry"] <= now:
                replies.append({"id": new_id, "status": "request_unavailable"})
                continue

            has_resources = len(req_info.get("resources", [])) > 0
            if has_resources:
                conflict = False
                for ainfo in active_requests.values():
                    if len(ainfo.get("resources", [])) > 0:
                        conflict = True
                        break
                if conflict:
                    replies.append({"id": new_id, "status": "resource_already_active"})
                    continue

            active_requests[assume_req] = req_info

        expired_reqs = [rid for rid, rinfo in active_requests.items() if rinfo["expiry"] <= now]
        for rid in expired_reqs:
            del active_requests[rid]

        base_roles = set(cached_user.get("roles", []))
        all_roles = set(base_roles)
        all_resources = set()
        for rinfo in active_requests.values():
            all_roles.update(rinfo.get("roles", []))
            all_resources.update(rinfo.get("resources", []))

        sorted_roles = sorted(all_roles)
        sorted_resources = sorted(all_resources)

        default_expiry = now + session_ttl
        if active_requests:
            min_req_expiry = min(rinfo["expiry"] for rinfo in active_requests.values())
            expiry = min(default_expiry, min_req_expiry)
        else:
            expiry = default_expiry

        login_time = prev["login_time"]

        new_session = {
            "login_time": login_time,
            "expiry": expiry,
            "cached_user": cached_user,
            "active_requests": active_requests,
        }
        sessions[new_id] = new_session
        session_order.append(new_id)

        ssh_obj = {
            "roles": sorted_roles,
            "allowed_resources": sorted_resources,
            "extensions": {
                "logins": sorted(cached_user.get("traits", {}).get("logins", [])),
                "db_users": sorted(cached_user.get("traits", {}).get("db_users", [])),
            },
            "login_time": login_time,
            "expires": expiry,
        }
        ssh_json = json.dumps(ssh_obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        ssh_b64 = base64.urlsafe_b64encode(ssh_json.encode("utf-8")).decode("ascii").rstrip("=")
        ssh_cert = "SSH-MODEL1." + ssh_b64

        active_req_list = sorted(active_requests.keys())
        tls_obj = {
            "user": cached_user.get("name", ""),
            "active_requests": active_req_list,
            "login_time": login_time,
            "expires": expiry,
        }
        tls_json = json.dumps(tls_obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        tls_b64 = base64.urlsafe_b64encode(tls_json.encode("utf-8")).decode("ascii").rstrip("=")
        tls_cert = "TLS-MODEL1." + tls_b64

        replies.append({
            "id": new_id,
            "status": "ok",
            "ssh_certificate": ssh_cert,
            "tls_certificate": tls_cert,
        })

    return {
        "replies": replies,
        "session_ids": session_order,
    }
