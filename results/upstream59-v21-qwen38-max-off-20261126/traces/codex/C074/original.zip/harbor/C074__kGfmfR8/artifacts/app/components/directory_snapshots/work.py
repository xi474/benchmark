def compute(payload):
    """按扫描轮次生成映射，从每个完成目录的逻辑路径映射至 [保留文件映射,可见子目录名升序数组]。按轮累计替换节点。"""
    import copy

    nodes = copy.deepcopy(payload.get("nodes", {}))
    mounts = payload.get("mounts", {})
    scans = payload.get("scans", [])

    # Build reverse mapping: node_id -> list of mount names pointing to it (for root-level)
    # We need to resolve logical paths to nodes.

    def parse_logical_path(path):
        """Parse a logical path into (mount_name, remaining_parts)."""
        parts = path.split("/")
        return parts[0], parts[1:]

    def resolve_node(mount_name, parts, nodes_dict):
        """Given a mount name and path parts, resolve to the node id."""
        if mount_name not in mounts:
            return None
        node_id = mounts[mount_name]
        for part in parts:
            node = nodes_dict.get(node_id)
            if node is None:
                return None
            dirs = node.get("dirs", {})
            if part not in dirs:
                return None
            node_id = dirs[part]
        return node_id

    def get_snapshot(logical_path, nodes_dict):
        """Get the snapshot for a logical path: [files_map, sorted_visible_subdir_names]."""
        mount_name, parts = parse_logical_path(logical_path)
        node_id = resolve_node(mount_name, parts, nodes_dict)
        if node_id is None:
            return [{}, []]
        node = nodes_dict.get(node_id, {})
        ignore_set = set(node.get("ignore", []))
        files = {k: v for k, v in node.get("files", {}).items() if k not in ignore_set}
        dirs = node.get("dirs", {})
        visible_dirs = sorted([d for d in dirs if d not in ignore_set])
        return [files, visible_dirs]

    result = []
    for scan in scans:
        # Apply replacements first (simultaneously)
        replace = scan.get("replace", {})
        for node_id, new_def in replace.items():
            nodes[node_id] = copy.deepcopy(new_def)

        # Generate snapshots for finished directories
        finish = scan.get("finish", [])
        snap = {}
        for lp in finish:
            snap[lp] = get_snapshot(lp, nodes)
        result.append(snap)

    return result
