def compute(payload):
    """每轮返回完成的逻辑路径，按深度先父后子，同深度维持输入顺序。"""
    result = []
    for scan in payload.get("scans", []):
        finish = scan.get("finish", [])
        # Sort by depth (number of '/' separators), stable sort preserves input order for same depth
        ordered = sorted(finish, key=lambda p: p.count("/"))
        result.append(ordered)
    return result
