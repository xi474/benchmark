def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = directory_snapshots result: list of {logical_path: [files_map, visible_subdirs]} per scan
    right = scan_precedence result: list of [ordered_logical_paths] per scan
    """
    initial = dict(payload.get("initial", {}))
    scans = payload.get("scans", [])

    results = []
    index = dict(initial)

    for scan_idx, scan in enumerate(scans):
        old_index = dict(index)
        ordered_paths = right[scan_idx]  # precedence-ordered finish list
        snapshots = left[scan_idx]       # {logical_path: [files_map, visible_subdirs]}

        for lp in ordered_paths:
            if lp not in snapshots:
                continue
            files_map, visible_subdirs = snapshots[lp]
            prefix = lp + "/"

            # Collect all current index entries under this directory
            old_entries = {}
            for path, tid in list(index.items()):
                if path.startswith(prefix):
                    remainder = path[len(prefix):]
                    # Only consider direct children (no further '/')
                    # Actually we need ALL entries under this prefix for cleanup
                    old_entries[path] = tid

            # Determine which direct child names exist now (files + visible subdirs)
            current_direct_names = set(files_map.keys()) | set(visible_subdirs)

            # Find old direct child names that had index entries
            old_direct_names = set()
            for path in old_entries:
                remainder = path[len(prefix):]
                first_part = remainder.split("/")[0]
                old_direct_names.add(first_part)

            # Names that disappeared or were ignored (and thus should be cleaned)
            removed_names = old_direct_names - current_direct_names

            # Remove all index entries under removed direct names
            for path in list(index.keys()):
                if path.startswith(prefix):
                    remainder = path[len(prefix):]
                    first_part = remainder.split("/")[0]
                    if first_part in removed_names:
                        del index[path]

            # Set direct files in index
            for fname, tid in files_map.items():
                index[prefix + fname] = tid

        # Compute changed
        changed = {}
        all_tids = set(old_index.values()) | set(index.values())
        for tid in all_tids:
            old_paths = sorted([p for p, t in old_index.items() if t == tid])
            new_paths = sorted([p for p, t in index.items() if t == tid])
            if old_paths != new_paths:
                changed[tid] = [old_paths, new_paths]

        results.append({"index": dict(index), "changed": changed})

    return results
