def compute(payload):
    """对 start/finish 事件按输入位置给出处理后仍活动的修改 ID 有序列表。"""
    events = payload.get("events", [])
    result = {}
    active = []
    for idx, ev in enumerate(events):
        op = ev.get("op")
        if op == "start":
            mid = ev["id"]
            if mid not in active:
                active.append(mid)
        elif op == "finish":
            mid = ev["id"]
            if mid in active:
                active.remove(mid)
        if op in ("start", "finish"):
            result[str(idx)] = list(active)
    return result
