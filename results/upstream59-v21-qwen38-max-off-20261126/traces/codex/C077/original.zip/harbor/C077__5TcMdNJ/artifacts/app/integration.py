def combine(payload, membership_map, deadline_map):
    """Combine the two component JSON values under the business contract in TASK.md."""
    events = payload.get("events", [])

    fetches = []
    commits = []
    audit = []

    active = []
    owed = False
    loading = False
    in_flight = None
    retry_at = None
    items = []
    fetch_counter = 0

    def is_loading():
        return bool(in_flight is not None or retry_at is not None or owed)

    def do_fetch(time):
        nonlocal fetch_counter, in_flight, loading, owed
        owed = False
        fetch_counter += 1
        fid = f"fetch-{fetch_counter}"
        in_flight = fid
        fetches.append({"id": fid, "time": time})
        audit.append({"time": time, "event": "fetch", "id": fid})
        loading = True

    # Group events by time, preserving array order within same time
    i = 0
    n = len(events)
    while i < n:
        current_time = events[i]["time"]
        batch = []
        while i < n and events[i]["time"] == current_time:
            batch.append((i, events[i]))
            i += 1

        # Check if a retry timer fires at this exact time before external events
        if retry_at is not None and retry_at <= current_time:
            fire_time = retry_at
            retry_at = None
            old_in_flight = in_flight
            in_flight = None
            if len(active) > 0:
                owed = True
            else:
                do_fetch(fire_time)

        for orig_idx, ev in batch:
            op = ev.get("op")

            if op == "start":
                mid = ev["id"]
                if mid not in active:
                    active.append(mid)
                audit.append({"time": current_time, "event": "modification_started", "id": mid})

            elif op == "finish":
                mid = ev["id"]
                if mid in active:
                    active.remove(mid)
                audit.append({"time": current_time, "event": "modification_finished", "id": mid})
                owed = True
                if len(active) == 0 and in_flight is None and retry_at is None:
                    do_fetch(current_time)

            elif op == "refresh":
                owed = True
                if len(active) == 0 and in_flight is None and retry_at is None:
                    do_fetch(current_time)

            elif op == "response":
                resp_id = ev["id"]
                dl_info = deadline_map.get(str(orig_idx))

                if isinstance(dl_info, list):
                    reason = dl_info[0]
                    due = dl_info[1]
                    if reason == "failure":
                        audit.append({"time": current_time, "event": "retry_scheduled", "due": due, "reason": "failure"})
                        if retry_at is None:
                            retry_at = due
                        # in_flight stays until retry fires
                    elif reason == "stale":
                        audit.append({"time": current_time, "event": "retry_scheduled", "due": due, "reason": "stale"})
                        if retry_at is None:
                            retry_at = due
                        # in_flight stays until retry fires
                else:
                    new_items = ev.get("items", [])
                    items = new_items
                    commits.append({"time": current_time, "items": new_items})
                    audit.append({"time": current_time, "event": "committed", "id": resp_id})
                    in_flight = None
                    if owed and len(active) == 0:
                        owed = False
                        do_fetch(current_time)

            elif op == "advance":
                pass

        loading = is_loading()

    placeholders = loading
    state = {
        "active": list(active),
        "owed": owed,
        "loading": loading,
        "placeholders": placeholders,
        "in_flight": in_flight,
        "retry_at": retry_at,
        "items": items,
    }

    return {
        "fetches": fetches,
        "commits": commits,
        "events": audit,
        "state": state,
    }
