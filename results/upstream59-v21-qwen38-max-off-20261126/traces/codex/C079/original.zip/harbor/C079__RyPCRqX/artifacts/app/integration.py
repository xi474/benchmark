def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    import hashlib

    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce = int.from_bytes(bytes.fromhex(payload["base_nonce_hex"]), "big")
    max_retries = payload.get("max_retries", 0)
    corrupt_map = right if isinstance(right, dict) else {}
    blocks_manifest = left

    aesgcm = AESGCM(session_key)

    blocks_out = []
    attempts_out = []
    notifications = []
    failed_block = None
    file_sha = hashlib.sha256()
    global_attempt = 0

    for kind, index, hex_data in blocks_manifest:
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(hex_data)
        aad = f"thumbnail:{index}" if kind == "thumbnail" else f"file:{index}"
        aad_bytes = aad.encode("utf-8")
        corrupt_set = set(corrupt_map.get(label, []))

        verified = False
        first_fail_notified = False

        for attempt_num in range(1 + max_retries):
            nonce_int = base_nonce + global_attempt
            nonce = nonce_int.to_bytes(12, "big")
            ciphertext = aesgcm.encrypt(nonce, plaintext, aad_bytes)

            if attempt_num in corrupt_set:
                ct_arr = bytearray(ciphertext)
                ct_arr[-1] ^= 0x01
                ciphertext = bytes(ct_arr)

            try:
                decrypted = aesgcm.decrypt(nonce, ciphertext, aad_bytes)
                if decrypted == plaintext:
                    verified = True
                    blocks_out.append({
                        "kind": kind,
                        "index": index,
                        "nonce_hex": nonce.hex(),
                        "ciphertext_hex": ciphertext.hex(),
                        "plaintext_sha256": hashlib.sha256(plaintext).hexdigest(),
                    })
                    attempts_out.append({
                        "block": label,
                        "attempt": attempt_num,
                        "verified": True,
                    })
                    if kind == "file":
                        file_sha.update(plaintext)
                    global_attempt += 1
                    break
            except Exception:
                pass

            if not verified:
                if not first_fail_notified:
                    notifications.append({"block": label, "error": "verification_failed"})
                    first_fail_notified = True
                attempts_out.append({
                    "block": label,
                    "attempt": attempt_num,
                    "verified": False,
                })
                global_attempt += 1

        if not verified:
            failed_block = label
            break

    status = "ok" if failed_block is None else "verification_failed"
    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks_out,
        "attempts": attempts_out,
        "notifications": notifications,
        "file_sha256": file_sha.hexdigest(),
    }
