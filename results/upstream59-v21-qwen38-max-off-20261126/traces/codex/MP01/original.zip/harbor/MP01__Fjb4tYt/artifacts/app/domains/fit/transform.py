import copy

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    classes = case['classes']
    sample_weight = case['sample_weight']
    members = case['members']
    if not isinstance(classes, list) or not all(isinstance(c, str) and c.strip() for c in classes):
        raise ValueError("invalid classes")
    if len(set(classes)) != len(classes):
        raise ValueError("duplicate classes")
    if not isinstance(sample_weight, list):
        raise ValueError("sample_weight must be list")
    sample_count = len(sample_weight)
    for sw in sample_weight:
        if isinstance(sw, bool) or not isinstance(sw, (int, float)):
            raise ValueError("sample_weight entries must be non-negative numbers")
        if sw < 0:
            raise ValueError("negative sample weight")
    seen_ids = set()
    active_members = []
    for m in members:
        if not isinstance(m, dict):
            raise ValueError("member must be dict")
        mid = m.get('id')
        active = m.get('active')
        if not isinstance(mid, str) or not mid.strip():
            raise ValueError("invalid member id")
        if not isinstance(active, bool):
            raise ValueError("active must be bool")
        if mid in seen_ids:
            raise ValueError("duplicate member id")
        seen_ids.add(mid)
        if active:
            w = m.get('weight')
            if isinstance(w, bool) or not isinstance(w, (int, float)):
                raise ValueError("member weight must be non-negative number")
            if w < 0:
                raise ValueError("negative member weight")
            preds = m.get('predictions')
            if not isinstance(preds, list) or len(preds) != sample_count:
                raise ValueError("predictions length mismatch")
            for p in preds:
                if p not in classes:
                    raise ValueError("prediction not in global classes")
            mc = m.get('classes')
            if not isinstance(mc, list) or sorted(mc) != sorted(classes):
                raise ValueError("member classes must be permutation of global classes")
            probs = m.get('probabilities')
            if not isinstance(probs, list) or len(probs) != sample_count:
                raise ValueError("probabilities row count mismatch")
            for row in probs:
                if not isinstance(row, list) or len(row) != len(mc):
                    raise ValueError("probabilities column count mismatch")
                s = 0.0
                for v in row:
                    if isinstance(v, bool) or not isinstance(v, (int, float)):
                        raise ValueError("probability must be number")
                    if v < 0:
                        raise ValueError("negative probability")
                    s += v
                if abs(s - 1.0) > 1e-9:
                    raise ValueError("probability row does not sum to 1")
            active_members.append(copy.deepcopy(m))
    if not active_members:
        raise ValueError("no active members")
    total_w = sum(am['weight'] for am in active_members)
    if total_w <= 0:
        raise ValueError("active member weights sum must be > 0")
    result_members = []
    for am in active_members:
        am['fit_weight'] = list(sample_weight)
        result_members.append(am)
    return {
        'name': contract['name'],
        'result': {
            'classes': list(classes),
            'sample_count': sample_count,
            'members': result_members
        }
    }
