import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))
    components = core['components']
    title = '可关闭成员的硬/软加权投票'
    component_count = len(components)
    serialized = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        if 'blocked' in result and result['blocked'] is True:
            triggered = True
        if not triggered:
            for key in ('complete', 'checkout', 'committed', 'ok'):
                if key in result and result[key] is False:
                    triggered = True
                    break
        if not triggered:
            for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
                if key not in result:
                    continue
                val = result[key]
                if isinstance(val, bool):
                    continue
                if isinstance(val, (list, dict)):
                    if len(val) > 0:
                        triggered = True
                        break
                elif isinstance(val, str):
                    if len(val) > 0:
                        triggered = True
                        break
                elif isinstance(val, (int, float)):
                    if val != 0:
                        triggered = True
                        break
                elif val is not None:
                    triggered = True
                    break
        if triggered:
            attention.append(name)
    attention = sorted(set(attention))
    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention
    }
    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')

if __name__ == '__main__':
    main()
