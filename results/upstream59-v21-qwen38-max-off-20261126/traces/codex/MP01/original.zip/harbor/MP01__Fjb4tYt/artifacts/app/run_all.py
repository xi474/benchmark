import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)
    name_to_cp = {}
    name_to_contract = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name_to_cp[c['name']] = cp
        name_to_contract[c['name']] = c
    done = set()
    order = []
    def resolve(name, visiting=None):
        if name in done:
            return
        if visiting is None:
            visiting = set()
        if name in visiting:
            print(f"circular dependency detected: {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        c = name_to_contract[name]
        for inp in c['inputs']:
            inp_path = ROOT / inp
            if inp_path.exists():
                continue
            dep_name = None
            for n2, c2 in name_to_contract.items():
                if c2['output'] == inp:
                    dep_name = n2
                    break
            if dep_name is None:
                print(f"missing input {inp} for {name}", file=sys.stderr)
                sys.exit(1)
            resolve(dep_name, visiting)
        visiting.discard(name)
        done.add(name)
        order.append(name)
    for name in sorted(name_to_contract.keys()):
        resolve(name)
    for name in order:
        cp = name_to_cp[name]
        comp_dir = cp.parent
        render_py = comp_dir / 'render.py'
        if not render_py.exists():
            print(f"render.py missing for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(comp_dir),
            timeout=60
        )
        if result.returncode != 0:
            print(f"render failed for {name}", file=sys.stderr)
            sys.exit(1)
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate failed", file=sys.stderr)
            sys.exit(1)
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report failed", file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()
