def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    hard_result = payloads[0]
    soft_result = payloads[1]
    if isinstance(hard_result, dict) and set(hard_result.keys()) == {'name', 'result'}:
        hard_data = hard_result['result']
    else:
        hard_data = hard_result
    if isinstance(soft_result, dict) and set(soft_result.keys()) == {'name', 'result'}:
        soft_data = soft_result['result']
    else:
        soft_data = soft_result
    hard_preds = hard_data['predictions']
    soft_preds = soft_data['predictions']
    if len(hard_preds) != len(soft_preds):
        raise ValueError("sample count mismatch between hard and soft")
    disagreements = [i for i in range(len(hard_preds)) if hard_preds[i] != soft_preds[i]]
    return {
        'name': contract['name'],
        'result': {
            'hard': list(hard_preds),
            'soft': list(soft_preds),
            'disagreements': disagreements
        }
    }
