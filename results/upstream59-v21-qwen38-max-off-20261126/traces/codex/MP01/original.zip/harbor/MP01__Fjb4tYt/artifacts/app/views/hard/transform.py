def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    fit_result = payloads[0]
    if isinstance(fit_result, dict) and set(fit_result.keys()) == {'name', 'result'}:
        fit_data = fit_result['result']
    else:
        fit_data = fit_result
    classes = fit_data['classes']
    members = fit_data['members']
    sample_count = fit_data['sample_count']
    predictions = []
    scores = []
    for i in range(sample_count):
        votes = {c: 0.0 for c in classes}
        for m in members:
            w = m['weight']
            pred = m['predictions'][i]
            votes[pred] += w
        score_row = [votes[c] for c in classes]
        max_score = max(score_row)
        winner = None
        for c in classes:
            if votes[c] == max_score:
                winner = c
                break
        predictions.append(winner)
        scores.append(score_row)
    return {
        'name': contract['name'],
        'result': {
            'predictions': predictions,
            'scores': scores
        }
    }
