def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    fit_result = payloads[0]
    if isinstance(fit_result, dict) and set(fit_result.keys()) == {'name', 'result'}:
        fit_data = fit_result['result']
    else:
        fit_data = fit_result
    classes = fit_data['classes']
    members = fit_data['members']
    sample_count = fit_data['sample_count']
    num_classes = len(classes)
    class_idx = {c: i for i, c in enumerate(classes)}
    total_weight = sum(m['weight'] for m in members)
    agg_probs = [[0.0] * num_classes for _ in range(sample_count)]
    for m in members:
        w = m['weight']
        mc = m['classes']
        probs = m['probabilities']
        col_map = [class_idx[c] for c in mc]
        for i in range(sample_count):
            row = probs[i]
            for j, gi in enumerate(col_map):
                agg_probs[i][gi] += w * row[j]
    predictions = []
    out_probs = []
    for i in range(sample_count):
        if total_weight > 0:
            normed = [v / total_weight for v in agg_probs[i]]
        else:
            normed = [0.0] * num_classes
        max_val = max(normed)
        winner = None
        for ci, c in enumerate(classes):
            if abs(normed[ci] - max_val) < 1e-15:
                winner = c
                break
        predictions.append(winner)
        out_probs.append(normed)
    return {
        'name': contract['name'],
        'result': {
            'predictions': predictions,
            'probabilities': out_probs
        }
    }
