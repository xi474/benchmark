def load_payload(path):
    import json, math
    from pathlib import Path
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}")
    if not isinstance(obj, (dict, list)):
        raise ValueError("top-level must be object or array")
    def _check_finite(o):
        if isinstance(o, float):
            if math.isnan(o) or math.isinf(o):
                raise ValueError("non-finite number in JSON")
        elif isinstance(o, dict):
            for v in o.values():
                _check_finite(v)
        elif isinstance(o, list):
            for v in o:
                _check_finite(v)
    _check_finite(obj)
    return obj
