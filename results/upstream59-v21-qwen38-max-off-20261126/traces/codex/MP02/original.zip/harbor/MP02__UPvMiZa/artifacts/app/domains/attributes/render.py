def build_component(root,contract_path):
    import json
    from pathlib import Path
    root = Path(root)
    contract_path = Path(contract_path)
    import sys
    comp_dir = str(contract_path.parent)
    if comp_dir not in sys.path:
        sys.path.insert(0, comp_dir)
    from model import load_payload
    from transform import transform
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__=="__main__":
    import sys
    from pathlib import Path
    comp_dir = Path(__file__).resolve().parent
    root = comp_dir.parents[1]
    contract_path = comp_dir / 'contract.json'
    build_component(root, contract_path)
