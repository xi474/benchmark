def transform(payloads,contract):
    import json
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    for k in ('columns', 'pieces', 'attribute_policy'):
        if k not in payload:
            raise ValueError(f"missing field: {k}")
    pieces = payload['pieces']
    policy = payload['attribute_policy']
    if policy not in ('drop_conflicts', 'first'):
        raise ValueError("invalid attribute_policy")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be list")
    # Collect all keys and their values per piece order
    key_values = {}  # key -> list of values in piece order
    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be object")
        if 'attrs' not in piece:
            raise ValueError("piece missing attrs")
        attrs = piece['attrs']
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be object")
        for k, v in attrs.items():
            if k not in key_values:
                key_values[k] = []
            key_values[k].append(v)
    merged = {}
    conflicts = []
    for k in sorted(key_values.keys()):
        vals = key_values[k]
        if policy == 'first':
            merged[k] = vals[0]
            # Check if there are conflicting values
            first_json = json.dumps(vals[0], sort_keys=True)
            has_conflict = False
            for v in vals[1:]:
                if json.dumps(v, sort_keys=True) != first_json:
                    has_conflict = True
                    break
            if has_conflict:
                conflicts.append(k)
        else:  # drop_conflicts
            first_json = json.dumps(vals[0], sort_keys=True)
            all_same = True
            for v in vals[1:]:
                if json.dumps(v, sort_keys=True) != first_json:
                    all_same = False
                    break
            if all_same:
                merged[k] = vals[0]
            else:
                conflicts.append(k)
    result = {'attrs': merged, 'conflicts': sorted(conflicts)}
    return {'name': contract['name'], 'result': result}
