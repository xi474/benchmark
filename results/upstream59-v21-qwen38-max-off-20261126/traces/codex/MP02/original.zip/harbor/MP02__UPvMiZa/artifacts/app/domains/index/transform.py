def transform(payloads,contract):
    import math
    def _is_finite(v):
        if isinstance(v, bool):
            return False
        if isinstance(v, int):
            return True
        if isinstance(v, float):
            return math.isfinite(v)
        return False

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    for k in ('columns', 'pieces', 'attribute_policy'):
        if k not in payload:
            raise ValueError(f"missing field: {k}")
    columns = payload['columns']
    pieces = payload['pieces']
    policy = payload['attribute_policy']
    if not isinstance(columns, list):
        raise ValueError("columns must be list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be list")
    if policy not in ('drop_conflicts', 'first'):
        raise ValueError("invalid attribute_policy")
    col_names = set()
    for c in columns:
        if not isinstance(c, str):
            raise ValueError("column name must be string")
        if c in col_names:
            raise ValueError(f"duplicate column: {c}")
        col_names.add(c)
    ids = set()
    all_coords = set()
    entries = []
    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be object")
        for k in ('id', 'coordinates', 'data', 'attrs'):
            if k not in piece:
                raise ValueError(f"piece missing field: {k}")
        pid = piece['id']
        if not isinstance(pid, str):
            raise ValueError("piece id must be string")
        if pid in ids:
            raise ValueError(f"duplicate piece id: {pid}")
        ids.add(pid)
        coords = piece['coordinates']
        data = piece['data']
        attrs = piece['attrs']
        if not isinstance(coords, list):
            raise ValueError("coordinates must be list")
        if not isinstance(data, list):
            raise ValueError("data must be list")
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be object")
        if len(coords) != len(data):
            raise ValueError("coordinates and data length mismatch")
        coord_set = set()
        for ci, coord in enumerate(coords):
            if not _is_finite(coord):
                raise ValueError("coordinate must be finite number")
            if coord in coord_set:
                raise ValueError("duplicate coordinate within piece")
            coord_set.add(coord)
            if coord in all_coords:
                raise ValueError("coordinate overlap across pieces")
            all_coords.add(coord)
            row = data[ci]
            if not isinstance(row, list):
                raise ValueError("data row must be list")
            if len(row) != len(columns):
                raise ValueError("data row width mismatch")
            for v in row:
                if not _is_finite(v):
                    raise ValueError("data value must be finite number")
            entries.append((coord, pid, ci))
    order = [{'coordinate': e[0], 'piece': e[1], 'row': e[2]} for e in sorted(entries, key=lambda x: x[0])]
    result = {'columns': columns, 'order': order}
    return {'name': contract['name'], 'result': result}
