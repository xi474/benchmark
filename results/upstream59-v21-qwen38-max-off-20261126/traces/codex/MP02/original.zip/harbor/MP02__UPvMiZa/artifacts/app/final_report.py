import json, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    # sha256 of the canonical serialization of the full core object
    canonical = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    sha = hashlib.sha256(canonical).hexdigest()
    components = core['components']
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        # result.blocked explicitly true
        if result.get('blocked') is True:
            triggered = True
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                triggered = True
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    triggered = True
        if triggered:
            attention.append(name)
    attention = sorted(set(attention))
    report = {
        'title': '单变化轴的数据分片拼接',
        'component_count': len(components),
        'sha256': sha,
        'attention': attention
    }
    out = ROOT / 'outputs' / 'final_report.json'
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

if __name__ == '__main__':
    main()
