import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        raise ValueError("no contracts found")
    comp_map = {}
    output_to_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_map[c['name']] = cp
        output_to_name[c['output']] = c['name']
    executed = set()
    def execute(name):
        if name in executed:
            return
        cp = comp_map[name]
        c = json.loads(cp.read_text(encoding='utf-8'))
        for inp in c['inputs']:
            if inp in output_to_name:
                dep = output_to_name[inp]
                execute(dep)
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            raise ValueError(f"missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"component {name} failed")
        executed.add(name)
    for name in comp_map:
        execute(name)
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError("integrate failed")
    report_py = ROOT / 'final_report.py'
    if report_py.exists():
        result = subprocess.run(
            [sys.executable, str(report_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError("final_report failed")

if __name__ == '__main__':
    main()
