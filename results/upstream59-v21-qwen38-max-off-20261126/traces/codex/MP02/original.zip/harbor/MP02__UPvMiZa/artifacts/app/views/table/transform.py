def transform(payloads,contract):
    # payloads[0] = original input (case.json)
    # payloads[1] = segment_index result (from outputs/index.json)
    # payloads[2] = segment_attributes result (from outputs/attributes.json)
    original = payloads[0]
    index_result = payloads[1]
    attrs_result = payloads[2]
    if not isinstance(original, dict):
        raise ValueError("original must be object")
    if not isinstance(index_result, dict):
        raise ValueError("index_result must be object")
    if not isinstance(attrs_result, dict):
        raise ValueError("attrs_result must be object")
    # Extract from index result
    if 'result' in index_result and 'name' in index_result:
        idx = index_result['result']
    else:
        idx = index_result
    if 'result' in attrs_result and 'name' in attrs_result:
        att = attrs_result['result']
    else:
        att = attrs_result
    columns = idx['columns']
    order = idx['order']
    # Build piece lookup from original
    pieces_map = {}
    for p in original['pieces']:
        pieces_map[p['id']] = p
    coordinates = []
    data = []
    for entry in order:
        coord = entry['coordinate']
        pid = entry['piece']
        row_idx = entry['row']
        piece = pieces_map[pid]
        coordinates.append(coord)
        data.append(piece['data'][row_idx])
    result = {
        'coordinates': coordinates,
        'columns': columns,
        'data': data,
        'attrs': att['attrs'],
        'attribute_conflicts': att['conflicts']
    }
    return {'name': contract['name'], 'result': result}
