def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    raw = case.get("aix")
    if not isinstance(raw, str):
        raise ValueError("aix field must be str")
    records = []
    current_mount = None
    current_attrs = {}
    known_keys = {"dev", "vfs", "options"}

    def _flush():
        nonlocal current_mount, current_attrs
        if current_mount is not None:
            if "dev" not in current_attrs:
                raise ValueError("missing dev in aix stanza")
            vfs = current_attrs.get("vfs", "jfs2")
            options = current_attrs.get("options", "rw")
            opts = ",".join(sorted(set(options.split(","))))
            records.append({
                "device": current_attrs["dev"],
                "mount": current_mount,
                "fstype": vfs,
                "options": opts,
            })
            current_mount = None
            current_attrs = {}

    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if not line[0].isspace() and stripped.endswith(":"):
            _flush()
            current_mount = stripped[:-1]
            if not current_mount:
                raise ValueError("empty mount point header")
            continue
        if "=" in stripped:
            if current_mount is None:
                raise ValueError("key=value without stanza header")
            key, _, value = stripped.partition("=")
            key = key.strip()
            value = value.strip()
            if key not in known_keys:
                raise ValueError(f"unknown key: {key}")
            if key in current_attrs:
                raise ValueError(f"duplicate key: {key}")
            current_attrs[key] = value
        else:
            if current_mount is None:
                raise ValueError("content without stanza header")
            raise ValueError(f"unparseable line in stanza: {stripped}")
    _flush()
    return {"name": contract["name"], "result": {"records": records}}
