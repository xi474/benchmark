def _unescape(s):
    s = s.replace("\\040", " ")
    s = s.replace("\\011", "\t")
    s = s.replace("\\134", "\\")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    raw = case.get("fstab")
    if not isinstance(raw, str):
        raise ValueError("fstab field must be str")
    records = []
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        cols = stripped.split()
        if len(cols) < 4 or len(cols) > 6:
            raise ValueError("invalid fstab line")
        device = _unescape(cols[0])
        mount = _unescape(cols[1])
        fstype = _unescape(cols[2])
        opts_raw = _unescape(cols[3])
        opts = ",".join(sorted(set(opts_raw.split(","))))
        records.append({
            "device": device,
            "mount": mount,
            "fstype": fstype,
            "options": opts,
        })
    return {"name": contract["name"], "result": {"records": records}}
