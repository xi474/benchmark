import re


def _unescape(s):
    s = s.replace("\\040", " ")
    return s


_PATTERN = re.compile(
    r'^(\S+)\s+on\s+(\S+)\s+type\s+(\S+)\s+\(([^)]+)\)$'
)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    raw = case.get("mount")
    if not isinstance(raw, str):
        raise ValueError("mount field must be str")
    records = []
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        m = _PATTERN.match(stripped)
        if not m:
            raise ValueError(f"invalid mount line: {stripped}")
        device = _unescape(m.group(1))
        mount = _unescape(m.group(2))
        fstype = m.group(3)
        opts_raw = m.group(4).strip()
        if not opts_raw:
            raise ValueError("empty options in mount line")
        opts = ",".join(sorted(set(opts_raw.split(","))))
        records.append({
            "device": device,
            "mount": mount,
            "fstype": fstype,
            "options": opts,
        })
    return {"name": contract["name"], "result": {"records": records}}
