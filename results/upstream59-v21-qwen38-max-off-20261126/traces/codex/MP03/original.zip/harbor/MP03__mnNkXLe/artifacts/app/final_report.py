import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    title = "\u4e09\u79cd\u6302\u8f7d\u683c\u5f0f\u7684\u79bb\u7ebf\u4e8b\u5b9e\u5f52\u5e76"
    component_count = len(core["components"])

    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    attention = set()
    for comp_name, result in core["components"].items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.add(comp_name)
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None:
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(comp_name)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": sorted(attention),
    }

    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
