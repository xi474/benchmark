import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        by_name[c["name"]] = (cp, c)

    visited = set()
    order = []

    def visit(name):
        if name in visited:
            return
        visited.add(name)
        cp, c = by_name[name]
        for inp in c["inputs"]:
            for other_cp, other_c in by_name.values():
                if str(other_c["output"]) == inp:
                    visit(other_c["name"])
        order.append((cp, c))

    for name in sorted(by_name.keys()):
        visit(name)

    for cp, c in order:
        render_py = cp.with_name("render.py")
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
