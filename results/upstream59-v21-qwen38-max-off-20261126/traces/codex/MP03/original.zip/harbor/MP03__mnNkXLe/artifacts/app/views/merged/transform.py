def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    source_names = ["fstab", "aix", "mount"]
    all_records = []
    for idx, payload in enumerate(payloads):
        src = source_names[idx]
        for rec in payload.get("result", {}).get("records", []):
            entry = dict(rec)
            entry["source"] = src
            all_records.append(entry)

    winners = {}
    for rec in all_records:
        mnt = rec["mount"]
        if mnt not in winners:
            winners[mnt] = rec

    sorted_records = [winners[k] for k in sorted(winners.keys())]

    conflicts = []
    mounts_seen = {}
    for rec in all_records:
        mnt = rec["mount"]
        if mnt not in mounts_seen:
            mounts_seen[mnt] = []
        mounts_seen[mnt].append(rec)

    for mnt in sorted(mounts_seen.keys()):
        entries = mounts_seen[mnt]
        if len(entries) < 2:
            continue
        winner = winners[mnt]
        has_conflict = False
        for e in entries:
            if e is winner:
                continue
            if (e["device"] != winner["device"] or
                    e["fstype"] != winner["fstype"] or
                    e["options"] != winner["options"]):
                has_conflict = True
                break
        if has_conflict:
            conflicts.append({
                "mount": mnt,
                "evidence": entries,
            })

    return {
        "name": contract["name"],
        "result": {
            "records": sorted_records,
            "conflicts": conflicts,
        },
    }
