import csv, io, re

def _parse_date(val):
    if val is None:
        return None
    if not isinstance(val, str):
        raise ValueError(f"joined must be string, got {type(val).__name__}")
    s = val.strip()
    if not s:
        return None
    m1 = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m1:
        y, mo, d = int(m1.group(1)), int(m1.group(2)), int(m1.group(3))
        import datetime
        datetime.date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    m2 = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m2:
        d, mo, y = int(m2.group(1)), int(m2.group(2)), int(m2.group(3))
        import datetime
        datetime.date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    raise ValueError(f"invalid date format: {val!r}")

def _normalize_id(raw_id):
    if isinstance(raw_id, bool):
        raise ValueError("id cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        s = raw_id.strip()
        if not s:
            raise ValueError("id cannot be empty string")
        return s
    raise ValueError(f"id must be str or int, got {type(raw_id).__name__}")

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'csv_text' not in payload:
        raise ValueError("missing csv_text")
    csv_text = payload['csv_text']
    if not isinstance(csv_text, str):
        raise ValueError("csv_text must be string")
    if not csv_text.strip():
        return {"name": contract["name"], "result": {"records": []}}
    reader = csv.DictReader(io.StringIO(csv_text))
    headers = reader.fieldnames
    if headers is None:
        return {"name": contract["name"], "result": {"records": []}}
    if len(headers) != len(set(headers)):
        raise ValueError("duplicate column names")
    has_id = 'id' in headers
    has_user_id = 'user_id' in headers
    if not has_id and not has_user_id:
        raise ValueError("CSV must have id or user_id column")
    allowed = {'id', 'user_id', 'name', 'full_name', 'email', 'mail', 'joined', 'joined_at'}
    for h in headers:
        if h not in allowed:
            raise ValueError(f"unexpected column: {h}")
    merged = {}
    for row in reader:
        raw_id = row.get('user_id', row.get('id'))
        if raw_id is None or raw_id == '':
            continue
        uid = _normalize_id(raw_id)
        if uid not in merged:
            merged[uid] = {'id': uid}
        rec = merged[uid]
        field_map = [
            ('name', 'name'), ('full_name', 'name'),
            ('email', 'email'), ('mail', 'email'),
            ('joined', 'joined'), ('joined_at', 'joined'),
        ]
        for src_key, dst_key in field_map:
            if src_key in row:
                val = row[src_key]
                if val == '' or val is None:
                    continue
                if dst_key == 'joined':
                    parsed = _parse_date(val)
                    if parsed is not None:
                        rec['joined'] = parsed
                elif dst_key in ('name', 'email'):
                    rec[dst_key] = val
    result = []
    for uid in sorted(merged.keys()):
        entry = {'id': uid}
        for field in ('name', 'email', 'joined'):
            if field in merged[uid]:
                entry[field] = merged[uid][field]
        result.append(entry)
    return {"name": contract["name"], "result": {"records": result}}
