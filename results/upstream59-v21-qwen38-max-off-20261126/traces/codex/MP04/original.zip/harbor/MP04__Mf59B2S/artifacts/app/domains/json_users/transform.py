import re

def _parse_date(val):
    if val is None:
        return None
    if not isinstance(val, str):
        raise ValueError(f"joined must be string, got {type(val).__name__}")
    s = val.strip()
    if not s:
        return None
    m1 = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m1:
        y, mo, d = int(m1.group(1)), int(m1.group(2)), int(m1.group(3))
        import datetime
        datetime.date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    m2 = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m2:
        d, mo, y = int(m2.group(1)), int(m2.group(2)), int(m2.group(3))
        import datetime
        datetime.date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    raise ValueError(f"invalid date format: {val!r}")

def _normalize_id(raw_id):
    if isinstance(raw_id, bool):
        raise ValueError("id cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        s = raw_id.strip()
        if not s:
            raise ValueError("id cannot be empty string")
        return s
    raise ValueError(f"id must be str or int, got {type(raw_id).__name__}")

def _process_records(items):
    merged = {}
    order_keys = {}
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("each record must be an object")
        if 'id' not in item and 'user_id' not in item:
            raise ValueError("record missing id/user_id")
        raw_id = item.get('user_id', item.get('id'))
        uid = _normalize_id(raw_id)
        if uid not in merged:
            merged[uid] = {'id': uid}
            order_keys[uid] = len(order_keys)
        rec = merged[uid]
        for src_key, dst_key in [('name', 'name'), ('full_name', 'name'),
                                  ('email', 'email'), ('mail', 'email'),
                                  ('joined', 'joined'), ('joined_at', 'joined')]:
            if src_key in item:
                val = item[src_key]
                if val is None:
                    continue
                if dst_key == 'joined':
                    parsed = _parse_date(val)
                    if parsed is not None:
                        rec['joined'] = parsed
                elif dst_key in ('name', 'email'):
                    if not isinstance(val, str):
                        raise ValueError(f"{dst_key} must be string")
                    rec[dst_key] = val
    result = []
    for uid in sorted(merged.keys()):
        entry = {'id': uid}
        for field in ('name', 'email', 'joined'):
            if field in merged[uid]:
                entry[field] = merged[uid][field]
        result.append(entry)
    return result

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'json_text' not in payload:
        raise ValueError("missing json_text")
    json_text = payload['json_text']
    if not isinstance(json_text, str):
        raise ValueError("json_text must be string")
    import json as _json
    try:
        items = _json.loads(json_text)
    except _json.JSONDecodeError as e:
        raise ValueError(f"invalid json_text: {e}") from e
    if not isinstance(items, list):
        raise ValueError("json_text must parse to array")
    records = _process_records(items)
    return {"name": contract["name"], "result": {"records": records}}
