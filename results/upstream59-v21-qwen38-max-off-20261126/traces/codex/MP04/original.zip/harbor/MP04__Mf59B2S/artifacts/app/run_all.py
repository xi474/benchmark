import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    dep_order = []
    domain_contracts = [c for c in contracts if 'domains' in c.relative_to(ROOT).parts]
    view_contracts = [c for c in contracts if 'views' in c.relative_to(ROOT).parts]
    dep_order.extend(sorted(domain_contracts))
    dep_order.extend(sorted(view_contracts))
    for cp in dep_order:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {render_py}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()
