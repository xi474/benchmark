def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    source_names = ['json', 'csv', 'jsonl']
    user_fields = {}
    conflict_map = {}
    for idx, payload in enumerate(payloads):
        src = source_names[idx]
        if not isinstance(payload, dict):
            raise ValueError(f"payload {src} must be object")
        if 'result' not in payload:
            raise ValueError(f"payload {src} missing result")
        res = payload['result']
        if not isinstance(res, dict) or 'records' not in res:
            raise ValueError(f"payload {src} result missing records")
        records = res['records']
        if not isinstance(records, list):
            raise ValueError(f"payload {src} records must be array")
        for rec in records:
            if not isinstance(rec, dict) or 'id' not in rec:
                raise ValueError(f"record in {src} missing id")
            uid = rec['id']
            if uid not in user_fields:
                user_fields[uid] = {}
            for field in ('name', 'email', 'joined'):
                if field in rec:
                    if field not in user_fields[uid]:
                        user_fields[uid][field] = rec[field]
                    ckey = (uid, field)
                    if ckey not in conflict_map:
                        conflict_map[ckey] = []
                    conflict_map[ckey].append({'source': src, 'value': rec[field]})
    users = []
    for uid in sorted(user_fields.keys()):
        user = {'id': uid}
        for field in ('name', 'email', 'joined'):
            if field in user_fields[uid]:
                user[field] = user_fields[uid][field]
        users.append(user)
    conflicts = []
    for (uid, field) in sorted(conflict_map.keys()):
        entries = conflict_map[(uid, field)]
        values_set = set()
        for e in entries:
            values_set.add(e['value'])
        if len(values_set) > 1:
            conflicts.append({
                'id': uid,
                'field': field,
                'values': entries
            })
    return {"name": contract["name"], "result": {"users": users, "conflicts": conflicts}}
