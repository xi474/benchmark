def load_payload(path):
    import json, math
    from pathlib import Path
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        raise ValueError("invalid JSON")
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    def check_finite(obj):
        if isinstance(obj, float):
            if math.isnan(obj) or math.isinf(obj):
                raise ValueError("non-finite number")
        elif isinstance(obj, dict):
            for v in obj.values():
                check_finite(v)
        elif isinstance(obj, list):
            for v in obj:
                check_finite(v)
    check_finite(data)
    return data
