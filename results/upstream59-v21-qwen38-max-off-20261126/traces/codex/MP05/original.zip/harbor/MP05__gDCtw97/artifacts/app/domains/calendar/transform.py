def transform(payloads,contract):
    case = payloads[0]
    contacts = case['contacts']
    self_id = case['self_id']
    window = case['window']
    events = case['events']
    contact_map = {c['id']: c for c in contacts}
    w_start, w_end = window[0], window[1]
    minutes = {}
    for cid in contact_map:
        if cid != self_id:
            minutes[cid] = 0
    for ev in events:
        attendees = list(set(ev['attendees']))
        if self_id not in attendees:
            continue
        ev_start = ev['start']
        ev_end = ev['end']
        clip_start = max(ev_start, w_start)
        clip_end = min(ev_end, w_end)
        duration = max(0, clip_end - clip_start)
        for a in attendees:
            if a == self_id:
                continue
            if a not in contact_map:
                raise ValueError(f"attendee {a} not in contacts")
            minutes[a] += duration
    return {"name": contract["name"], "result": {"minutes": minutes}}
