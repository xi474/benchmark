def transform(payloads,contract):
    case = payloads[0]
    contacts = case['contacts']
    self_id = case['self_id']
    keyword = case['keyword']
    groups = case['groups']
    contact_map = {c['id']: c for c in contacts}
    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    candidate_ids = set()
    for g in groups:
        members = g['members']
        messages = g['messages']
        matched = False
        for msg in messages:
            if keyword.casefold() in msg.casefold():
                matched = True
                break
        if matched:
            for m in members:
                if m not in contact_map:
                    raise ValueError(f"member {m} not in contacts")
                if m != self_id:
                    candidate_ids.add(m)
    return {"name": contract["name"], "result": {"ids": sorted(candidate_ids)}}
