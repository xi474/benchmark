def transform(payloads,contract):
    case = payloads[0]
    contacts = case['contacts']
    self_id = case['self_id']
    keyword = case['keyword']
    emails = case['emails']
    contact_map = {c['id']: c for c in contacts}
    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    candidate_ids = set()
    for e in emails:
        sender = e['sender']
        subject = e['subject']
        if sender not in contact_map:
            raise ValueError(f"unknown sender {sender}")
        if keyword.casefold() in subject.casefold():
            if sender != self_id:
                candidate_ids.add(sender)
    return {"name": contract["name"], "result": {"ids": sorted(candidate_ids)}}
