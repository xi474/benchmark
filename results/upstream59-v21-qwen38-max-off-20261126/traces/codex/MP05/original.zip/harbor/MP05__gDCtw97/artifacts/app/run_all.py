import json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    # Topological sort based on dependencies
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = (cp, c)
    done = set()
    order = []
    def visit(name):
        if name in done:
            return
        cp, c = contract_map[name]
        for inp in c['inputs']:
            # Check if this input is an output of another component
            for other_cp in contracts:
                other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                if other_c['output'] == inp and other_c['name'] != name:
                    visit(other_c['name'])
        order.append((cp, c))
        done.add(name)
    for cp, c in contract_map.values():
        visit(c['name'])
    for cp, c in order:
        comp_dir = cp.parent
        render_py = comp_dir / 'render.py'
        result = subprocess.run([sys.executable, str(render_py)], cwd=ROOT, timeout=60)
        if result.returncode != 0:
            sys.exit(result.returncode)
    # Run integrate
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=60)
    # Run final_report
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=60)

if __name__ == '__main__':
    main()
