def transform(payloads,contract):
    case = payloads[0]
    groups_result = payloads[1]['result']
    mail_result = payloads[2]['result']
    calendar_result = payloads[3]['result']
    contacts = case['contacts']
    contact_map = {c['id']: c for c in contacts}
    candidate_ids = set(groups_result['ids']) | set(mail_result['ids'])
    cal_minutes = calendar_result['minutes']
    ranking_list = []
    for cid in candidate_ids:
        age = contact_map[cid]['age']
        mins = cal_minutes.get(cid, 0)
        ranking_list.append({"id": cid, "minutes": mins, "age": age})
    ranking_list.sort(key=lambda x: (-x['minutes'], -x['age'], x['id']))
    winner = ranking_list[0]['id'] if ranking_list else None
    return {"name": contract["name"], "result": {"ranking": ranking_list, "winner": winner}}
