def build_component(root,contract_path):
    import json
    from pathlib import Path
    root = Path(root)
    contract_path = Path(contract_path)
    with open(contract_path, encoding='utf-8') as f:
        contract = json.load(f)
    payloads = []
    for inp in contract['inputs']:
        with open(root / inp, encoding='utf-8') as f:
            payloads.append(json.load(f))
    from transform import transform
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    return result

if __name__=="__main__":
    import sys
    from pathlib import Path
    cp = Path(__file__).resolve().with_name('contract.json')
    root = Path(__file__).resolve().parents[2]
    build_component(root, cp)
