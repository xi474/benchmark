def transform(payloads,contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    events = case['events']
    day = case['day']
    lo = day * 1440
    hi = lo + 720
    cancelled_ids = []
    snapshots = {}
    remaining = {}
    for ev in events:
        eid = ev['id']
        if ev['start'] >= lo and ev['start'] < hi and ev['social'] and not ev['cancelled'] and ev['end'] > ev['start']:
            cancelled_ids.append(eid)
            snapshots[eid] = dict(ev)
        else:
            remaining[eid] = dict(ev)
    cancelled_ids.sort()
    snapshots = {k: snapshots[k] for k in sorted(snapshots)}
    remaining = {k: remaining[k] for k in sorted(remaining)}
    return {"name": contract["name"], "result": {"cancelled": cancelled_ids, "snapshots": snapshots, "remaining": remaining}}
