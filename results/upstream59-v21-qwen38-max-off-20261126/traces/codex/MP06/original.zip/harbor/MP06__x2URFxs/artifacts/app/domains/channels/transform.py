def transform(payloads,contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    contacts_list = case['contacts']
    seen = set()
    contacts = {}
    for c in contacts_list:
        cid = c['id']
        if cid in seen:
            raise ValueError(f"duplicate contact id: {cid}")
        seen.add(cid)
        email = c.get('email')
        message = c.get('message')
        chat = c.get('chat')
        for val, name in [(email,'email'),(message,'message'),(chat,'chat')]:
            if val is not None and not isinstance(val, str):
                raise ValueError(f"field {name} must be null or string")
            if isinstance(val, str) and val.strip() == '':
                raise ValueError(f"field {name} empty after strip")
        primary = message if message is not None else chat
        address = primary if primary is not None else None
        contacts[cid] = {"email": email, "primary": primary, "address": address}
    return {"name": contract["name"], "result": {"contacts": contacts}}
