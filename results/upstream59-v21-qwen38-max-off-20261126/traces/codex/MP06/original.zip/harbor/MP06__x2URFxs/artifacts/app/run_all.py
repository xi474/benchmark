import json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def main():
    contracts = sorted(ROOT.rglob('contract.json'))
    contracts = [c for c in contracts if 'outputs' not in c.relative_to(ROOT).parts]
    if not contracts:
        raise ValueError("no contracts found")
    order = []
    by_name = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        by_name[c['name']] = (cp, c)
    resolved = set()
    def resolve(name):
        if name in resolved:
            return
        cp, c = by_name[name]
        for inp in c['inputs']:
            for other_name, (_, oc) in by_name.items():
                if oc['output'] == inp:
                    resolve(other_name)
        order.append(name)
        resolved.add(name)
    for name in sorted(by_name):
        resolve(name)
    for name in order:
        cp, c = by_name[name]
        subprocess.run([sys.executable, str(cp.with_name('render.py'))], cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=60)

if __name__ == '__main__':
    main()
