def transform(payloads,contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    cal = payloads[0]['result']
    chan = payloads[1]['result']
    cancelled_ids = cal['cancelled']
    snapshots = cal['snapshots']
    contacts_map = chan['contacts']
    requires = sorted(cancelled_ids)
    attendee_ids = set()
    for eid in cancelled_ids:
        ev = snapshots[eid]
        for aid in ev['attendees']:
            if aid not in contacts_map:
                raise ValueError(f"unknown contact id: {aid}")
            attendee_ids.add(aid)
    outbox = []
    unreachable = []
    group_members = []
    for aid in sorted(attendee_ids):
        c = contacts_map[aid]
        email = c['email']
        primary = c['primary']
        has_email = email is not None
        has_primary = primary is not None
        if has_email:
            outbox.append({"channel": "email", "to": aid, "recipients": [aid], "requires": requires})
        if has_primary:
            group_members.append(aid)
        if not has_email and not has_primary:
            unreachable.append(aid)
    group = None
    if group_members:
        group_members.sort()
        group = {"id": "cancelled-social", "members": group_members, "requires": requires}
        outbox.append({"channel": "message_group", "to": "cancelled-social", "recipients": group_members, "requires": requires})
    outbox.sort(key=lambda x: (x['channel'], x['to']))
    return {"name": contract["name"], "result": {"outbox": outbox, "unreachable": sorted(unreachable), "group": group}}
