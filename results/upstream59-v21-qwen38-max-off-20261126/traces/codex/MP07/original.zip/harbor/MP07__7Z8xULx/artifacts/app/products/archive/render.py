import json
from pathlib import Path
import sys

def build_component(root, contract_path):
    from model import load_payload
    from transform import transform
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__ == "__main__":
    cp = Path(__file__).resolve().with_name('contract.json')
    root = cp.parents[2]
    build_component(root, cp)
