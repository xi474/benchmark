def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    receipts_result = payloads[1]['result']
    cleanup_result = payloads[2]['result']

    archive_prefix = case['archive_prefix']
    files = case['files']
    file_map = {f['path']: f for f in files}

    all_ok = all(r['ok'] for r in receipts_result['receipts'])
    has_recipients = len(receipts_result['receipts']) > 0

    blocked = not (all_ok and has_recipients)

    deleted = sorted(cleanup_result['delete'])

    moves = []
    if not blocked:
        att_paths = [a['path'] for a in receipts_result['attachments']]
        move_targets = set()
        delete_set = set(deleted)
        for ap in att_paths:
            to_path = archive_prefix + '/' + ap
            if to_path in move_targets:
                raise ValueError(f"duplicate move target: {to_path}")
            if to_path in file_map:
                raise ValueError(f"move target already exists: {to_path}")
            if ap in delete_set:
                raise ValueError(f"move source overlaps with cleanup: {ap}")
            move_targets.add(to_path)
            moves.append({"from": ap, "to": to_path})
        moves.sort(key=lambda m: m['from'])

    result_files = []
    for f in sorted(files, key=lambda x: x['path']):
        result_files.append({"path": f['path'], "hex": f['hex']})

    return {"name": contract["name"], "result": {
        "moves": moves,
        "deleted": deleted,
        "blocked": blocked,
        "files": result_files
    }}
