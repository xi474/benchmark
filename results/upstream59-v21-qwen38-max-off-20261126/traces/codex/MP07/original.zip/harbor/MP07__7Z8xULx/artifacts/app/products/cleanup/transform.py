def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    files = case['files']
    cleanup_prefix = case['cleanup_prefix']

    delete = []
    prefix = cleanup_prefix + '/'
    for f in files:
        p = f['path']
        if p.startswith(prefix) and p.endswith('.tmp'):
            delete.append(p)
    delete.sort()

    return {"name": contract["name"], "result": {"delete": delete}}
