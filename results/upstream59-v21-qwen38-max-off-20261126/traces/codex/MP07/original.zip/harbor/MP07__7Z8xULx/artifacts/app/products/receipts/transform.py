import hashlib

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    files = case['files']
    attachments = case['attachments']
    recipients = case['recipients']
    send_ok = case['send_ok']

    file_map = {f['path']: f for f in files}
    seen = set()
    unique_attachments = []
    for a in attachments:
        if a not in seen:
            seen.add(a)
            unique_attachments.append(a)
    unique_attachments.sort()

    for a in unique_attachments:
        if a not in file_map:
            raise ValueError(f"attachment {a} not found in files")

    att_results = []
    for a in unique_attachments:
        hex_str = file_map[a]['hex']
        raw_bytes = bytes.fromhex(hex_str)
        sha = hashlib.sha256(raw_bytes).hexdigest()
        att_results.append({"path": a, "sha256": sha})

    if len(recipients) != len(set(recipients)):
        raise ValueError("duplicate recipients")

    sorted_recipients = sorted(recipients)
    receipts = []
    for r in sorted_recipients:
        if r not in send_ok:
            raise ValueError(f"recipient {r} not in send_ok")
        ok = send_ok[r]
        if not isinstance(ok, bool):
            raise ValueError(f"send_ok[{r}] must be bool")
        receipts.append({"recipient": r, "ok": ok})

    return {"name": contract["name"], "result": {"attachments": att_results, "receipts": receipts}}
