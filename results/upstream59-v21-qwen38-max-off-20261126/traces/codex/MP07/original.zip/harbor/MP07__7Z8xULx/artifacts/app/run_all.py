import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    # Collect all contracts, determine execution order based on dependencies
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts.append((cp, c))

    if not contracts:
        raise ValueError("no contracts found")

    # Topological sort based on input dependencies
    # A component depends on another if its inputs reference outputs/ files
    name_to_cp = {c['name']: cp for cp, c in contracts}
    name_to_c = {c['name']: c for cp, c in contracts}

    # Build dependency graph
    deps = {}
    for cp, c in contracts:
        dep_names = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                # Find which component produces this output
                for cp2, c2 in contracts:
                    if c2['output'] == inp:
                        dep_names.add(c2['name'])
        deps[c['name']] = dep_names

    # Topological sort
    ordered = []
    visited = set()
    temp = set()

    def visit(name):
        if name in temp:
            raise ValueError(f"circular dependency involving {name}")
        if name in visited:
            return
        temp.add(name)
        for d in sorted(deps.get(name, [])):
            visit(d)
        temp.remove(name)
        visited.add(name)
        ordered.append(name)

    for cp, c in contracts:
        visit(c['name'])

    # Execute each component's render.py in order
    for name in ordered:
        cp = name_to_cp[name]
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            raise ValueError(f"render.py not found for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(cp.parent),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED {name}: {result.stderr}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"integrate.py failed: {result.stderr}", file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"final_report.py failed: {result.stderr}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
