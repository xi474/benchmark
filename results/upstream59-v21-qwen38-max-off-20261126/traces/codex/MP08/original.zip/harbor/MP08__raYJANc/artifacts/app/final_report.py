import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # sha256 of the full core object, compact JSON, no trailing newline
    compact = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha = hashlib.sha256(compact).hexdigest()

    components = core["components"]

    # attention: component names where any condition triggers
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != "" and val != {}:
                if isinstance(val, (list, str, dict)) and len(val) > 0:
                    attention.add(name)

    report = {
        "title": "节日照片迁移后发送与缺失报告",
        "component_count": len(components),
        "sha256": sha,
        "attention": sorted(attention)
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )


if __name__ == "__main__":
    main()
