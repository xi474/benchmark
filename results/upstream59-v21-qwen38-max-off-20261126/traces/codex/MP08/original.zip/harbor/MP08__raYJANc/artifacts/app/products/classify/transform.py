def transform(payloads, contract):
    case = payloads[0]
    files = case["files"]
    photos = case["photos"]
    festivals = case["festivals"]
    destination = case["destination"]
    recipient = case["recipient"]

    # Validate
    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(photos, list):
        raise ValueError("photos must be list")
    if not isinstance(festivals, list):
        raise ValueError("festivals must be list")
    if not isinstance(destination, str) or not destination.strip():
        raise ValueError("destination must be non-empty string")
    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be non-empty string")

    file_paths = set()
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path or hex")
        if not isinstance(f["path"], str) or not f["path"].strip():
            raise ValueError("file path must be non-empty string")
        if not isinstance(f["hex"], str):
            raise ValueError("file hex must be string")
        file_paths.add(f["path"])

    festival_set = set()
    for fest in festivals:
        if not isinstance(fest, str) or not fest.strip():
            raise ValueError("festival must be non-empty string")
        if fest in festival_set:
            raise ValueError("duplicate festival")
        festival_set.add(fest)

    photo_paths = set()
    for p in photos:
        if not isinstance(p, dict):
            raise ValueError("photo entry must be object")
        if "path" not in p or "festival" not in p:
            raise ValueError("photo entry missing path or festival")
        if not isinstance(p["path"], str) or not p["path"].strip():
            raise ValueError("photo path must be non-empty string")
        if not isinstance(p["festival"], str) or not p["festival"].strip():
            raise ValueError("photo festival must be non-empty string")
        if p["path"] not in file_paths:
            raise ValueError("photo path not in files")
        if p["path"] in photo_paths:
            raise ValueError("duplicate photo path")
        photo_paths.add(p["path"])

    # Select photos whose festival is in festivals list
    selected = []
    for p in photos:
        if p["festival"] in festival_set:
            selected.append({"path": p["path"], "festival": p["festival"]})

    # Sort by (festival, path)
    selected.sort(key=lambda x: (x["festival"], x["path"]))

    # Missing: festivals with no photos
    used_festivals = set(p["festival"] for p in selected)
    missing = sorted(f for f in festivals if f not in used_festivals)

    return {
        "name": contract["name"],
        "result": {
            "selected": selected,
            "missing": missing
        }
    }
