def transform(payloads, contract):
    case = payloads[0]
    classify_result = payloads[1]["result"]

    files = case["files"]
    destination = case["destination"]
    selected = classify_result["selected"]

    # Build file hex map
    file_hex = {}
    for f in files:
        file_hex[f["path"]] = f["hex"]

    moves = []
    new_files = []

    for sel in selected:
        src = sel["path"]
        festival = sel["festival"]
        dst = destination + "/" + src
        moves.append({"from": src, "to": dst, "festival": festival})
        new_files.append({"path": dst, "hex": file_hex[src]})

    # Sort moves by (from, to)
    moves.sort(key=lambda x: (x["from"], x["to"]))
    # Sort files by path
    new_files.sort(key=lambda x: x["path"])

    return {
        "name": contract["name"],
        "result": {
            "moves": moves,
            "files": new_files
        }
    }
