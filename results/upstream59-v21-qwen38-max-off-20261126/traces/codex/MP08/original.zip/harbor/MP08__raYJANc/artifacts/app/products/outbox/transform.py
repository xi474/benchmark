def transform(payloads, contract):
    case = payloads[0]
    classify_result = payloads[1]["result"]
    migrate_result = payloads[2]["result"]

    recipient = case["recipient"]
    missing = classify_result["missing"]

    # Attachments are the migrated paths (to), sorted
    attachments = sorted(m["to"] for m in migrate_result["moves"])

    if not missing:
        message = "Photos ready"
    else:
        message = "Missing: " + ", ".join(missing)

    return {
        "name": contract["name"],
        "result": {
            "to": recipient,
            "attachments": attachments,
            "missing": missing,
            "message": message
        }
    }
