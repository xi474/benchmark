import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all component directories with contract.json (excluding outputs)
    contracts = sorted(
        cp for cp in ROOT.rglob("contract.json")
        if "outputs" not in cp.relative_to(ROOT).parts
    )
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency map
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = (cp, c)

    # Topological sort
    visited = set()
    order = []

    def visit(name):
        if name in visited:
            return
        visited.add(name)
        cp, c = contract_map[name]
        for inp in c["inputs"]:
            for other_name, (other_cp, other_c) in contract_map.items():
                if other_c["output"] == inp and other_name != name:
                    visit(other_name)
        order.append(name)

    for name in contract_map:
        visit(name)

    # Execute each component's render.py in order
    for name in order:
        cp, c = contract_map[name]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            print(f"No render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("Integration failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("Final report failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
