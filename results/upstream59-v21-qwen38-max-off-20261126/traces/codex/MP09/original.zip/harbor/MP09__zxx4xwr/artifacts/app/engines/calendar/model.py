import json
import math
from pathlib import Path


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"invalid JSON in {path}") from exc
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array in {path}")
    _check_finite(data, path)
    return data


def _check_finite(obj, path):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError(f"non-finite number in {path}")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v, path)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v, path)
