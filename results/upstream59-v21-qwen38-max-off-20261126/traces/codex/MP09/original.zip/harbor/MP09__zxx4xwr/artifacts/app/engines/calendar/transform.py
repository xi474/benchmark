def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    now = case["now"]
    windows = case["windows"]
    busy = case["busy"]
    duration = case["duration"]
    gap = case["gap"]

    if not isinstance(now, int) or isinstance(now, bool):
        raise ValueError("now must be int")
    if not isinstance(duration, int) or isinstance(duration, bool) or duration < 1:
        raise ValueError("duration must be int >= 1")
    if not isinstance(gap, int) or isinstance(gap, bool) or gap < 0:
        raise ValueError("gap must be int >= 0")

    for w in windows:
        if not isinstance(w["start"], int) or isinstance(w["start"], bool):
            raise ValueError("window start must be int")
        if not isinstance(w["end"], int) or isinstance(w["end"], bool):
            raise ValueError("window end must be int")
        if w["end"] <= w["start"]:
            raise ValueError("window end must be > start")

    for b in busy:
        if not isinstance(b["start"], int) or isinstance(b["start"], bool):
            raise ValueError("busy start must be int")
        if not isinstance(b["end"], int) or isinstance(b["end"], bool):
            raise ValueError("busy end must be int")
        if b["end"] <= b["start"]:
            raise ValueError("busy end must be > start")

    # Build available intervals: union of windows minus busy minus before now
    # Collect all window intervals clipped to [now, infinity)
    avail = []
    for w in windows:
        s = max(w["start"], now)
        e = w["end"]
        if s < e:
            avail.append((s, e))

    # Sort and merge overlapping intervals
    avail.sort()
    merged = []
    for s, e in avail:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    # Subtract busy intervals
    busy_sorted = sorted(busy, key=lambda b: (b["start"], b["end"]))
    free = []
    for s, e in merged:
        cur_s = s
        for b in busy_sorted:
            bs, be = b["start"], b["end"]
            if be <= cur_s:
                continue
            if bs >= e:
                break
            if bs > cur_s:
                free.append((cur_s, bs))
            cur_s = max(cur_s, be)
        if cur_s < e:
            free.append((cur_s, e))

    # Greedy: find earliest slot for first session
    slots = []
    first_end = None
    for s, e in free:
        if e - s >= duration:
            slots.append({"start": s, "end": s + duration})
            first_end = s + duration
            break

    if first_end is not None:
        # Find second slot: start >= first_end + gap
        second_earliest = first_end + gap
        for s, e in free:
            eff_s = max(s, second_earliest)
            if e - eff_s >= duration:
                slots.append({"start": eff_s, "end": eff_s + duration})
                break

    result = {
        "slots": slots,
        "complete": len(slots) == 2,
    }
    return {"name": contract["name"], "result": result}
