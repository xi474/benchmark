def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    # payloads[0] = calendar result (wrapped), payloads[1] = invitees result, payloads[2] = supplies result
    cal = payloads[0]
    inv = payloads[1]
    sup = payloads[2]

    # Extract business data: when input has name/result keys, use result
    if isinstance(cal, dict) and set(cal.keys()) == {"name", "result"}:
        cal_data = cal["result"]
    else:
        cal_data = cal

    if isinstance(inv, dict) and set(inv.keys()) == {"name", "result"}:
        inv_data = inv["result"]
    else:
        inv_data = inv

    if isinstance(sup, dict) and set(sup.keys()) == {"name", "result"}:
        sup_data = sup["result"]
    else:
        sup_data = sup

    slots = cal_data["slots"]
    complete = cal_data["complete"]
    members = inv_data["members"]
    group_id = inv_data["group_id"]

    events = []
    notification = None

    if complete and len(slots) == 2:
        event1_id = group_id + "-1"
        event2_id = group_id + "-2"
        events = [
            {"id": event1_id, "start": slots[0]["start"], "end": slots[0]["end"], "members": members},
            {"id": event2_id, "start": slots[1]["start"], "end": slots[1]["end"], "members": members},
        ]
        notification = {
            "group_id": group_id,
            "members": members,
            "event_ids": [event1_id, event2_id],
        }

    result = {
        "events": events,
        "notification": notification,
        "purchase": sup_data,
    }
    return {"name": contract["name"], "result": result}
