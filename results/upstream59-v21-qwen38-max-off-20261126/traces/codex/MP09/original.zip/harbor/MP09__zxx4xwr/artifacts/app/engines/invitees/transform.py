def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    groups = case["groups"]
    invite_groups = case["invite_groups"]
    exclude = case["exclude"]
    namespace = case["namespace"]

    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be non-empty string")

    # Build group lookup
    group_map = {}
    for g in groups:
        gid = g["id"]
        members = g["members"]
        if not isinstance(members, list) or len(members) == 0:
            raise ValueError(f"group {gid} has empty members")
        group_map[gid] = members

    # Validate invite_groups exist
    for ig in invite_groups:
        if ig not in group_map:
            raise ValueError(f"unknown group {ig}")

    # Union of members from invited groups, minus exclude
    member_set = set()
    for ig in invite_groups:
        for m in group_map[ig]:
            member_set.add(m)

    exclude_set = set(exclude)
    result_members = sorted(member_set - exclude_set)

    result = {
        "members": result_members,
        "group_id": namespace + "-panel",
    }
    return {"name": contract["name"], "result": result}
