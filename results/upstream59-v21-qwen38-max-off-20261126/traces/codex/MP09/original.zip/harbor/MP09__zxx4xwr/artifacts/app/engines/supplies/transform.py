def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    products = case["products"]
    requirements = case["requirements"]

    # Validate products
    for p in products:
        if not isinstance(p["stock"], int) or isinstance(p["stock"], bool) or p["stock"] < 0:
            raise ValueError(f"product {p['id']} stock must be int >= 0")
        if not isinstance(p["price_cents"], int) or isinstance(p["price_cents"], bool) or p["price_cents"] < 0:
            raise ValueError(f"product {p['id']} price_cents must be int >= 0")
        if not isinstance(p["rating"], int) or isinstance(p["rating"], bool) or p["rating"] < 0:
            raise ValueError(f"product {p['id']} rating must be int >= 0")

    # Validate requirements
    req_cats = set()
    for r in requirements:
        if not isinstance(r["quantity"], int) or isinstance(r["quantity"], bool) or r["quantity"] < 1:
            raise ValueError(f"requirement quantity must be int >= 1")
        if r["category"] in req_cats:
            raise ValueError(f"duplicate category {r['category']}")
        req_cats.add(r["category"])

    items = []
    unavailable = []

    for r in requirements:
        cat = r["category"]
        qty = r["quantity"]
        # Filter products with sufficient stock in this category
        candidates = [p for p in products if p["category"] == cat and p["stock"] >= qty]
        if not candidates:
            unavailable.append(cat)
            continue
        # Select by: highest rating, then lowest price_cents, then smallest id
        best = min(candidates, key=lambda p: (-p["rating"], p["price_cents"], p["id"]))
        items.append({
            "category": cat,
            "id": best["id"],
            "quantity": qty,
            "total_cents": best["price_cents"] * qty,
        })

    # Sort items by category
    items.sort(key=lambda x: x["category"])
    unavailable.sort()

    result = {
        "items": items,
        "unavailable": unavailable,
    }
    return {"name": contract["name"], "result": result}
