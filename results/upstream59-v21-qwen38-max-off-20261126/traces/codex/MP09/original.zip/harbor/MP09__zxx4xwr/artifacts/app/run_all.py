import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts, determine execution order based on dependencies
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding="utf-8"))
        contracts.append((cp, c))

    # Build dependency graph: component -> set of components it depends on
    output_to_component = {}
    for cp, c in contracts:
        output_to_component[c["output"]] = c["name"]

    deps = {}
    comp_to_script = {}
    for cp, c in contracts:
        name = c["name"]
        script = cp.with_name("render.py")
        comp_to_script[name] = script
        dep_names = set()
        for inp in c["inputs"]:
            if inp in output_to_component:
                dep_names.add(output_to_component[inp])
        deps[name] = dep_names

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        visiting.add(name)
        for d in sorted(deps.get(name, set())):
            visit(d)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for cp, c in contracts:
        visit(c["name"])

    # Execute in order
    for name in ordered:
        script = comp_to_script[name]
        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            sys.exit(result.returncode)

    # Run integrate
    result = subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        timeout=60,
    )
    if result.returncode != 0:
        sys.exit(result.returncode)

    # Run final_report
    result = subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        timeout=60,
    )
    if result.returncode != 0:
        sys.exit(result.returncode)


if __name__ == "__main__":
    main()
