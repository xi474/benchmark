import json
from pathlib import Path

def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    data = json.loads(text, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"non-finite JSON value: {x}")))
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    return data
