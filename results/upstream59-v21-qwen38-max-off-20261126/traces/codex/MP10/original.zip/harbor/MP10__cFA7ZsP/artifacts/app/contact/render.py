import json
import sys
from pathlib import Path

_pkg_dir = Path(__file__).resolve().parent

def _imports():
    try:
        from .model import load_payload
        from .transform import transform
        return load_payload, transform
    except ImportError:
        if str(_pkg_dir) not in sys.path:
            sys.path.insert(0, str(_pkg_dir))
        from model import load_payload
        from transform import transform
        return load_payload, transform

def build_component(root, contract_path):
    load_payload, transform = _imports()
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__ == "__main__":
    cp = Path(__file__).resolve().with_name('contract.json')
    root = cp.parent.parent
    build_component(root, cp)
