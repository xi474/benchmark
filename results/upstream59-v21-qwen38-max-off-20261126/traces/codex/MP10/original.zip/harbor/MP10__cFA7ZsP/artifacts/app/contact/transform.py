def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    inp = payloads[0]
    conversations = inp['conversations']
    topic = inp['topic']

    if not isinstance(conversations, list):
        raise ValueError("conversations must be list")
    if not isinstance(topic, str):
        raise ValueError("topic must be string")

    topic_lower = topic.casefold()
    best = None
    for conv in conversations:
        conv_topic = conv['topic']
        if not isinstance(conv_topic, str):
            continue
        if topic_lower in conv_topic.casefold():
            ts = conv['ts']
            cid = conv['id']
            contact_id = conv['contact_id']
            key = (ts, cid)
            if best is None or (ts > best[0]) or (ts == best[0] and cid < best[1]):
                best = (ts, cid, contact_id)

    if best is None:
        result = {"contact_id": None, "conversation_id": None}
    else:
        result = {"contact_id": best[2], "conversation_id": best[1]}

    return {"name": contract["name"], "result": result}
