from datetime import date, timedelta

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    inp = payloads[0]
    today_str = inp['today']
    weekday = inp['weekday']
    hour = inp['hour']
    guest_count = inp['guest_count']

    if not isinstance(today_str, str):
        raise ValueError("today must be string")
    if not isinstance(weekday, int) or isinstance(weekday, bool) or not (0 <= weekday <= 6):
        raise ValueError("weekday must be int 0..6")
    if not isinstance(hour, int) or isinstance(hour, bool) or not (0 <= hour <= 23):
        raise ValueError("hour must be int 0..23")
    if not isinstance(guest_count, int) or isinstance(guest_count, bool) or guest_count < 1:
        raise ValueError("guest_count must be int >= 1")

    today = date.fromisoformat(today_str)
    # Python weekday: Monday=0 .. Sunday=6, same as spec
    days_ahead = (weekday - today.weekday()) % 7
    if days_ahead == 0:
        days_ahead = 7
    dinner_date = today + timedelta(days=days_ahead)
    start = f"{dinner_date.isoformat()}T{hour:02d}:00"

    return {"name": contract["name"], "result": {"start": start, "guest_count": guest_count}}
