import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    # Discover all contracts, build dependency order
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts[c['name']] = {'contract': c, 'path': cp}

    if not contracts:
        raise ValueError("no contracts found")

    # Topological sort based on input dependencies
    resolved = set()
    order = []
    remaining = dict(contracts)

    while remaining:
        progress = False
        for name, info in list(remaining.items()):
            deps_met = True
            for inp in info['contract']['inputs']:
                if inp.startswith('outputs/'):
                    dep_name = inp.split('/')[1].replace('.json', '')
                    if dep_name not in resolved:
                        deps_met = False
                        break
            if deps_met:
                order.append(name)
                resolved.add(name)
                del remaining[name]
                progress = True
        if not progress:
            raise ValueError("circular dependency or unresolvable inputs")

    # Execute each component in order
    for name in order:
        info = contracts[name]
        cp = info['path']
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            raise ValueError(f"missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"component {name} failed")

    # Run integrate
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=str(ROOT),
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError("integrate failed")

    # Run final_report
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=str(ROOT),
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError("final_report failed")

if __name__ == '__main__':
    main()
