def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    snapshot = payloads[0]
    dinner_result = payloads[1]
    contact_result = payloads[2]

    # Extract from upstream results
    if isinstance(dinner_result, dict) and 'result' in dinner_result:
        dinner_data = dinner_result['result']
    else:
        dinner_data = dinner_result

    if isinstance(contact_result, dict) and 'result' in contact_result:
        contact_data = contact_result['result']
    else:
        contact_data = contact_result

    guest_count = dinner_data['guest_count']
    start = dinner_data['start']
    recipient = contact_data.get('contact_id')

    variants = snapshot['variants']
    wanted = snapshot['wanted']

    items = []
    unavailable = []

    for w in wanted:
        kind = w['kind']
        attrs = w['attributes']
        candidates = []
        for v in variants:
            if v['kind'] == kind and v['attributes'] == attrs and v['stock'] >= guest_count:
                candidates.append(v)
        if not candidates:
            unavailable.append(kind)
        else:
            candidates.sort(key=lambda x: (x['price_cents'], x['id']))
            best = candidates[0]
            items.append({"id": best['id'], "kind": kind, "quantity": guest_count})

    # Sort items by kind ascending
    items.sort(key=lambda x: x['kind'])
    unavailable.sort()

    total_cents = 0
    for item in items:
        for v in variants:
            if v['id'] == item['id']:
                total_cents += v['price_cents'] * item['quantity']
                break

    checkout = (len(unavailable) == 0 and recipient is not None and len(items) == len(wanted))

    result = {
        "items": items,
        "total_cents": total_cents,
        "checkout": checkout,
        "recipient": recipient,
        "start": start,
        "unavailable": unavailable
    }

    return {"name": contract["name"], "result": result}
