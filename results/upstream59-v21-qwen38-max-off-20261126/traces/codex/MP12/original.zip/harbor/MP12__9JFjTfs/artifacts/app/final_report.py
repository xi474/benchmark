import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    components = core['components']
    compact = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    sha = hashlib.sha256(compact).hexdigest()
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        if result.get('blocked') is True:
            triggered = True
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                triggered = True
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0 and val is not False and val is not None:
                if isinstance(val, (list, dict)) and len(val) > 0:
                    triggered = True
                elif isinstance(val, str) and len(val) > 0:
                    triggered = True
                elif isinstance(val, (int, float)) and val != 0:
                    triggered = True
        if triggered:
            attention.append(name)
    attention = sorted(set(attention))
    report = {
        'title': '下载目录归档、邮件清理与目标回复',
        'component_count': len(components),
        'sha256': sha,
        'attention': attention
    }
    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

if __name__ == '__main__':
    main()
