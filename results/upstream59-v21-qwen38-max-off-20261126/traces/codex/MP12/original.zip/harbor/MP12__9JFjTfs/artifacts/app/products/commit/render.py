import json
from pathlib import Path
import sys

def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract_text = contract_path.read_text(encoding='utf-8')
    contract = json.loads(contract_text)
    payloads = []
    for inp in contract['inputs']:
        p = root / inp
        text = p.read_text(encoding='utf-8')
        data = json.loads(text)
        if not isinstance(data, (dict, list)):
            raise ValueError('top-level must be object or array')
        payloads.append(data)
    from transform import transform
    result = transform(payloads, contract)
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__ == '__main__':
    cp = Path(__file__).resolve().with_name('contract.json')
    root = cp.parents[2]
    build_component(root, cp)
