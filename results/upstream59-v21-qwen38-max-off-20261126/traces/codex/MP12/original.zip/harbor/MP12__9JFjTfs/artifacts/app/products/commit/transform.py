def _safe_rel(path_str):
    if '\\' in path_str or ':' in path_str:
        raise ValueError('unsafe path')
    parts = path_str.split('/')
    for p in parts:
        if p == '' or p == '.' or p == '..':
            raise ValueError('unsafe path segment')
    return path_str

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    case = payloads[0]
    files_result = payloads[1]['result']
    mail_result = payloads[2]['result']
    reply_result = payloads[3]['result']
    trash_ids_set = set(mail_result['trash_ids'])
    if reply_result['email_id'] in trash_ids_set:
        raise ValueError('reply target is in trash batch')
    file_map = {}
    for f in case['files']:
        _safe_rel(f['path'])
        file_map[f['path']] = f['hex']
    moves = files_result['moves']
    for m in moves:
        src = m['from']
        dst = m['to']
        if src not in file_map:
            raise ValueError('move source not in snapshot')
        hex_val = file_map.pop(src)
        _safe_rel(dst)
        file_map[dst] = hex_val
    out_files = []
    for path in sorted(file_map.keys()):
        out_files.append({'path': path, 'hex': file_map[path]})
    emails = [dict(em) for em in case['emails']]
    for em in emails:
        if em['id'] in trash_ids_set:
            em['folder'] = 'TRASH'
    emails.sort(key=lambda e: e['id'])
    return {
        'name': contract['name'],
        'result': {
            'files': out_files,
            'emails': emails,
            'reply': reply_result
        }
    }
