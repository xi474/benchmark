def _safe_rel(path_str):
    if '\\' in path_str or ':' in path_str:
        raise ValueError('unsafe path')
    parts = path_str.split('/')
    for p in parts:
        if p == '' or p == '.' or p == '..':
            raise ValueError('unsafe path segment')
    return path_str

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    case = payloads[0]
    files = case['files']
    download_prefix = case['download_prefix']
    archive_prefix = case['archive_prefix']
    extensions = case['extensions']
    ext_lower_map = {k.lower(): v for k, v in extensions.items()}
    moves = []
    for f in files:
        fpath = f['path']
        _safe_rel(fpath)
        parts = fpath.split('/')
        if len(parts) != 2 or parts[0] != download_prefix:
            continue
        basename = parts[1]
        dot_idx = basename.rfind('.')
        if dot_idx < 0:
            continue
        ext = basename[dot_idx:]
        ext_key = ext.lower()
        if ext_key not in ext_lower_map:
            continue
        subdir = ext_lower_map[ext_key]
        dest = archive_prefix + '/' + subdir + '/' + basename
        _safe_rel(dest)
        moves.append({'from': fpath, 'to': dest})
    seen_to = set()
    for m in moves:
        if m['to'] in seen_to:
            raise ValueError('duplicate destination')
        seen_to.add(m['to'])
    moves.sort(key=lambda m: m['from'])
    return {'name': contract['name'], 'result': {'moves': moves}}
