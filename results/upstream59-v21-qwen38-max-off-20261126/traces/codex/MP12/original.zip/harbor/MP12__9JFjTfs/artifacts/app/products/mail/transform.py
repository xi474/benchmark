import calendar

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    case = payloads[0]
    emails = case['emails']
    month = case['month']
    trash_keyword = case['trash_keyword']
    trash_ids = []
    for em in emails:
        date_str = em['date']
        if not isinstance(date_str, str) or len(date_str) != 10:
            raise ValueError('invalid date format')
        parts = date_str.split('-')
        if len(parts) != 3:
            raise ValueError('invalid date')
        y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
        try:
            max_day = calendar.monthrange(y, m)[1]
        except Exception:
            raise ValueError('invalid date')
        if d < 1 or d > max_day:
            raise ValueError('invalid date day')
        email_month = parts[0] + '-' + parts[1]
        if email_month != month:
            continue
        subject = em['subject']
        if trash_keyword.casefold() not in subject.casefold():
            continue
        if em['folder'] == 'TRASH':
            continue
        trash_ids.append(em['id'])
    trash_ids.sort()
    return {'name': contract['name'], 'result': {'trash_ids': trash_ids}}
