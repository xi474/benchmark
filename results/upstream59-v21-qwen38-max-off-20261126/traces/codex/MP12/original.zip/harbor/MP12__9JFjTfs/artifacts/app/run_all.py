import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    dep_order = {'files': 0, 'mail': 0, 'reply': 0, 'commit': 1}
    contracts.sort(key=lambda cp: (dep_order.get(json.loads(cp.read_text(encoding='utf-8'))['name'], 99), str(cp)))
    for cp in contracts:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f'Missing render.py for {cp}', file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(cp.parent),
            timeout=60
        )
        if result.returncode != 0:
            print(f'render failed for {cp}', file=sys.stderr)
            sys.exit(1)
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print('integrate failed', file=sys.stderr)
            sys.exit(1)
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print('final_report failed', file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()
