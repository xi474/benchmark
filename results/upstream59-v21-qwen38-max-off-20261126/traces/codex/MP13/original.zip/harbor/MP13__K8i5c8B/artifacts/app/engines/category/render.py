def build_component(root,contract_path):
    import json
    from pathlib import Path
    root = Path(root)
    contract_path = Path(contract_path)
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    from model import load_payload
    from transform import transform
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    return result

if __name__=="__main__":
    import sys
    from pathlib import Path
    cp = Path(__file__).resolve().with_name('contract.json')
    root = Path(__file__).resolve().parents[2]
    build_component(root, cp)
