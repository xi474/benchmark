def transform(payloads,contract):
    data = payloads[0]
    records = data['records']
    vocabulary = data['vocabulary']
    groups = {}
    for rec in records:
        key = rec['key']
        cat = rec['category']
        if key not in groups:
            groups[key] = set()
        if cat is not None:
            groups[key].add(cat)
    rows = []
    for key in sorted(groups.keys()):
        cats = groups[key]
        if not cats:
            continue
        values = {}
        for v in vocabulary:
            values[v] = v in cats
        rows.append({"key": key, "values": values})
    return {"name": contract["name"], "result": {"rows": rows}}
