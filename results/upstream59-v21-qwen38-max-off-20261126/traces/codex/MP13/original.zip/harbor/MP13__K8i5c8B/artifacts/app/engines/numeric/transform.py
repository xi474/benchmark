def transform(payloads,contract):
    data = payloads[0]
    records = data['records']
    ids_seen = set()
    groups = {}
    for rec in records:
        rid = rec['id']
        if rid in ids_seen:
            raise ValueError("duplicate record id")
        ids_seen.add(rid)
        key = rec['key']
        if key not in groups:
            groups[key] = []
        val = rec['value']
        if val is not None:
            if isinstance(val, bool):
                raise ValueError("bool not allowed as value")
            if not isinstance(val, (int, float)):
                raise ValueError("value must be finite number or null")
            groups[key].append(val)
    rows = []
    for key in sorted(groups.keys()):
        vals = groups[key]
        count = len(vals)
        s = sum(vals) if count > 0 else 0
        mean = s / count if count > 0 else None
        rows.append({"key": key, "values": {"count": count, "sum": s, "mean": mean}})
    return {"name": contract["name"], "result": {"rows": rows}}
