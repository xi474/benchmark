def transform(payloads,contract):
    data = payloads[0]
    records = data['records']
    groups = {}
    for rec in records:
        key = rec['key']
        t = rec['time']
        if key not in groups:
            groups[key] = []
        if t is not None:
            if isinstance(t, bool):
                raise ValueError("bool not allowed as time")
            if not isinstance(t, int):
                raise ValueError("time must be int or null")
            groups[key].append(t)
    rows = []
    for key in sorted(groups.keys()):
        times = groups[key]
        if not times:
            continue
        first = min(times)
        last = max(times)
        span = last - first
        rows.append({"key": key, "values": {"first": first, "last": last, "span": span}})
    return {"name": contract["name"], "result": {"rows": rows}}
