def transform(payloads, contract):
    def unwrap(obj):
        if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
            return obj['result']
        return obj

    numeric_result = unwrap(payloads[0])
    category_result = unwrap(payloads[1])
    time_result = unwrap(payloads[2])

    all_keys = set()
    num_data = {}
    for row in numeric_result.get('rows', []):
        k = row['key']
        all_keys.add(k)
        num_data[k] = row['values']

    cat_data = {}
    for row in category_result.get('rows', []):
        k = row['key']
        all_keys.add(k)
        cat_data[k] = row['values']

    time_data = {}
    for row in time_result.get('rows', []):
        k = row['key']
        all_keys.add(k)
        time_data[k] = row['values']

    columns = set()
    for v in num_data.values():
        for col in v:
            columns.add('num.' + col)
    for v in cat_data.values():
        for col in v:
            columns.add('cat.' + col)
    for v in time_data.values():
        for col in v:
            columns.add('time.' + col)
    columns = sorted(columns)

    index = sorted(all_keys)
    data = []
    for key in index:
        row_vals = []
        for col in columns:
            if col.startswith('num.'):
                orig = col[4:]
                row_vals.append(num_data.get(key, {}).get(orig, None))
            elif col.startswith('cat.'):
                orig = col[4:]
                row_vals.append(cat_data.get(key, {}).get(orig, None))
            elif col.startswith('time.'):
                orig = col[5:]
                row_vals.append(time_data.get(key, {}).get(orig, None))
            else:
                row_vals.append(None)
        data.append(row_vals)

    return {"name": contract["name"], "result": {"index": index, "columns": columns, "data": data}}
