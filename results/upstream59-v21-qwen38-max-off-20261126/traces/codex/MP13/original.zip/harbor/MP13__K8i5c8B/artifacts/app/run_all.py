import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    name_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name_map[c['name']] = cp
    order = []
    done = set()
    def resolve(name):
        if name in done:
            return
        cp = name_map[name]
        c = json.loads(cp.read_text(encoding='utf-8'))
        for inp in c['inputs']:
            inp_path = ROOT / inp
            if str(inp_path).startswith(str(ROOT / 'outputs')):
                for other_name, other_cp in name_map.items():
                    other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                    if other_c['output'] == inp:
                        resolve(other_name)
        order.append(cp)
        done.add(name)
    for name in sorted(name_map.keys()):
        resolve(name)
    for cp in order:
        render_py = cp.with_name('render.py')
        subprocess.run([sys.executable, str(render_py)], cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=60)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=60)

if __name__ == '__main__':
    main()
