def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if "root" not in data or "nodes" not in data:
        raise ValueError("missing required fields")
    root_id = data["root"]
    nodes_list = data["nodes"]
    if not isinstance(root_id, str) or not isinstance(nodes_list, list):
        raise ValueError("invalid types")

    nodes_map = {}
    for node in nodes_list:
        if not isinstance(node, dict):
            raise ValueError("node must be object")
        for field in ("id", "type", "message", "suppress_context"):
            if field not in node:
                raise ValueError(f"missing field {field}")
        nid = node["id"]
        if not isinstance(nid, str):
            raise ValueError("id must be string")
        if nid in nodes_map:
            raise ValueError(f"duplicate id {nid}")
        if not isinstance(node["type"], str):
            raise ValueError("type must be string")
        if not isinstance(node["message"], str):
            raise ValueError("message must be string")
        if not isinstance(node["suppress_context"], bool):
            raise ValueError("suppress_context must be bool")
        if "cause" not in node:
            raise ValueError("missing cause")
        if "context" not in node:
            raise ValueError("missing context")
        cause = node["cause"]
        context = node["context"]
        if cause is not None and not isinstance(cause, str):
            raise ValueError("cause must be string or null")
        if context is not None and not isinstance(context, str):
            raise ValueError("context must be string or null")
        if "frames" not in node:
            raise ValueError("missing frames")
        if not isinstance(node["frames"], list):
            raise ValueError("frames must be list")
        for fr in node["frames"]:
            if not isinstance(fr, dict):
                raise ValueError("frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in fr:
                    raise ValueError(f"missing frame field {ff}")
            if not isinstance(fr["file"], str):
                raise ValueError("file must be string")
            if not isinstance(fr["function"], str):
                raise ValueError("function must be string")
            if not isinstance(fr["line"], int) or isinstance(fr["line"], bool) or fr["line"] < 1:
                raise ValueError("line must be positive integer")
            if not isinstance(fr["locals"], dict):
                raise ValueError("locals must be object")
        nodes_map[nid] = node

    if root_id not in nodes_map:
        raise ValueError("root not found")

    # Build chain from root following cause/context links
    visited = set()
    chain_ids = []
    current = root_id
    while current is not None:
        if current in visited:
            raise ValueError("cycle detected")
        if len(chain_ids) >= 8:
            raise ValueError("chain length exceeds 8")
        visited.add(current)
        chain_ids.append(current)
        node = nodes_map[current]
        cause = node["cause"]
        context = node["context"]
        suppress = node["suppress_context"]
        if cause is not None:
            if cause not in nodes_map:
                raise ValueError(f"cause {cause} not found")
            current = cause
        elif not suppress and context is not None:
            if context not in nodes_map:
                raise ValueError(f"context {context} not found")
            current = context
        else:
            current = None

    # Build result: from innermost to root
    # chain_ids is [root, next, ..., innermost]
    # We need innermost first
    chain_ids.reverse()

    chain = []
    for i, nid in enumerate(chain_ids):
        node = nodes_map[nid]
        if i == 0:
            link = None
        else:
            prev_id = chain_ids[i - 1]
            # Determine how this node links to the previous (inner) node
            # The previous node is the one that this node's cause or context points to
            if node["cause"] == prev_id:
                link = "cause"
            elif node["context"] == prev_id:
                link = "context"
            else:
                raise ValueError("link inconsistency")
        chain.append({
            "id": nid,
            "type": node["type"],
            "message": node["message"],
            "link": link,
        })

    return {"name": contract["name"], "result": {"chain": chain}}
