import json
from pathlib import PurePosixPath


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if "nodes" not in data:
        raise ValueError("missing nodes")
    nodes_list = data["nodes"]
    if not isinstance(nodes_list, list):
        raise ValueError("nodes must be list")

    frames_map = {}
    for node in nodes_list:
        if not isinstance(node, dict):
            raise ValueError("node must be object")
        nid = node.get("id")
        if not isinstance(nid, str):
            raise ValueError("id must be string")
        if "frames" not in node:
            raise ValueError("missing frames")
        raw_frames = node["frames"]
        if not isinstance(raw_frames, list):
            raise ValueError("frames must be list")
        result_frames = []
        for fr in raw_frames:
            if not isinstance(fr, dict):
                raise ValueError("frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in fr:
                    raise ValueError(f"missing frame field {ff}")
            fpath = fr["file"]
            if not isinstance(fpath, str):
                raise ValueError("file must be string")
            # Replace backslashes with forward slashes, then keep only basename
            normalized = fpath.replace("\\", "/")
            basename = PurePosixPath(normalized).name
            line = fr["line"]
            if not isinstance(line, int) or isinstance(line, bool) or line < 1:
                raise ValueError("line must be positive integer")
            func = fr["function"]
            if not isinstance(func, str):
                raise ValueError("function must be string")
            locals_obj = fr["locals"]
            if not isinstance(locals_obj, dict):
                raise ValueError("locals must be object")
            # Serialize each local value to canonical JSON string
            canon_locals = {}
            for k, v in locals_obj.items():
                canon_locals[k] = json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            result_frames.append({
                "file": basename,
                "line": line,
                "function": func,
                "locals": canon_locals,
            })
        frames_map[nid] = result_frames

    return {"name": contract["name"], "result": {"frames": frames_map}}
