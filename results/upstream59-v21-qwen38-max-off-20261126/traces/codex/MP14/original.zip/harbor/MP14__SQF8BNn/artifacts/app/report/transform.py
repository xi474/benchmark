def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    chain_data = payloads[0]
    frames_data = payloads[1]

    if not isinstance(chain_data, dict) or "result" not in chain_data:
        # If it's already unwrapped (has chain key directly)
        if isinstance(chain_data, dict) and "chain" in chain_data:
            chain_result = chain_data
        else:
            raise ValueError("invalid chain input")
    else:
        chain_result = chain_data["result"]

    if not isinstance(frames_data, dict) or "result" not in frames_data:
        if isinstance(frames_data, dict) and "frames" in frames_data:
            frames_result = frames_data
        else:
            raise ValueError("invalid frames input")
    else:
        frames_result = frames_data["result"]

    chain_list = chain_result["chain"]
    frames_map = frames_result["frames"]

    nodes = []
    lines = []
    for i, entry in enumerate(chain_list):
        nid = entry["id"]
        etype = entry["type"]
        message = entry["message"]
        link = entry["link"]
        node_frames = frames_map.get(nid, [])

        if i > 0:
            if link == "cause":
                lines.append("--- direct cause ---")
            elif link == "context":
                lines.append("--- during handling ---")

        for fr in node_frames:
            lines.append(f"  {fr['file']}:{fr['line']} in {fr['function']}")
        lines.append(f"{etype}: {message}")

        nodes.append({
            "id": nid,
            "type": etype,
            "message": message,
            "link": link,
            "frames": node_frames,
        })

    text = "\n".join(lines)
    if text:
        text += "\n"

    return {"name": contract["name"], "result": {"nodes": nodes, "text": text}}
