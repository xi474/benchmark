import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    def get_deps(cp):
        c = json.loads(cp.read_text(encoding="utf-8"))
        return [inp for inp in c["inputs"] if inp.startswith("outputs/")]

    ordered = []
    remaining = list(contracts)
    produced = set()
    while remaining:
        progress = False
        next_remaining = []
        for cp in remaining:
            deps = get_deps(cp)
            if all(d in produced for d in deps):
                ordered.append(cp)
                c = json.loads(cp.read_text(encoding="utf-8"))
                produced.add(c["output"])
                progress = True
            else:
                next_remaining.append(cp)
        if not progress:
            print("Circular or unresolvable dependencies", file=sys.stderr)
            sys.exit(1)
        remaining = next_remaining

    for cp in ordered:
        render_script = cp.with_name("render.py")
        if not render_script.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"Failed: {render_script}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    final_report = ROOT / "final_report.py"
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
