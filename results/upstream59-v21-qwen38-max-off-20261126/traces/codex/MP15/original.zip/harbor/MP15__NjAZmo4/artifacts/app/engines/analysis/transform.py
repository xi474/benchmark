import ast

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    ordinary_result = payloads[1]
    annotation_result = payloads[2]
    comment_result = payloads[3]

    if not isinstance(source_data, dict) or 'source' not in source_data:
        raise ValueError("missing source field")
    source = source_data['source']

    # Extract uses from upstream results
    ordinary_uses = ordinary_result.get('result', ordinary_result).get('uses', [])
    annotation_uses = annotation_result.get('result', annotation_result).get('uses', [])
    comment_uses = comment_result.get('result', comment_result).get('uses', [])

    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    # Parse imports
    imports = _parse_imports(tree, source)

    # Check for global/nonlocal
    for node in ast.walk(tree):
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            raise ValueError("global/nonlocal not supported")

    # Build scope info
    func_names = set()
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            func_names.add(node.name)

    # For each import binding, determine which scopes it's used in
    imports_list = []
    all_used_keys = {}  # (scope, name) -> set of use types

    for imp in imports:
        scope = imp['scope']
        name = imp['name']
        module = imp['module']
        line = imp['line']

        used_by = set()

        # Check ordinary uses
        for u in ordinary_uses:
            if _matches_import(u, scope, name, func_names, tree):
                used_by.add('ordinary')

        # Check annotation uses
        for u in annotation_uses:
            if _matches_import(u, scope, name, func_names, tree):
                used_by.add('annotation')

        # Check comment uses
        for u in comment_uses:
            if _matches_import(u, scope, name, func_names, tree):
                used_by.add('comment')

        ordered_used_by = [t for t in ['ordinary', 'annotation', 'comment'] if t in used_by]
        imports_list.append({
            "scope": scope,
            "name": name,
            "module": module,
            "line": line,
            "used_by": ordered_used_by
        })

    imports_list.sort(key=lambda x: (x['scope'], x['line'], x['name']))

    # Determine unused imports
    unused = []
    for imp in imports_list:
        if not imp['used_by']:
            unused.append(f"{imp['scope']}:{imp['name']}")
    unused.sort()

    return {"name": contract["name"], "result": {"imports": imports_list, "unused": unused}}


def _parse_imports(tree, source):
    """Parse import statements. Only absolute import/from, no star."""
    imports = []
    seen_bindings = {}  # (scope, name) -> import info

    # Module-level imports
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == '*':
                    raise ValueError("star import not supported")
                bound_name = alias.asname if alias.asname else alias.name.split('.')[0]
                key = ('module', bound_name)
                if key in seen_bindings:
                    raise ValueError(f"duplicate import binding: {bound_name} in module")
                imp = {
                    'scope': 'module',
                    'name': bound_name,
                    'module': alias.name,
                    'line': node.lineno
                }
                seen_bindings[key] = imp
                imports.append(imp)
        elif isinstance(node, ast.ImportFrom):
            if node.level > 0:
                raise ValueError("relative import not supported")
            for alias in node.names:
                if alias.name == '*':
                    raise ValueError("star import not supported")
                bound_name = alias.asname if alias.asname else alias.name
                key = ('module', bound_name)
                if key in seen_bindings:
                    raise ValueError(f"duplicate import binding: {bound_name} in module")
                imp = {
                    'scope': 'module',
                    'name': bound_name,
                    'module': f"{node.module}.{alias.name}" if node.module else alias.name,
                    'line': node.lineno
                }
                seen_bindings[key] = imp
                imports.append(imp)

    # Function-level imports
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            for stmt in ast.walk(node):
                if stmt is node:
                    continue
                if isinstance(stmt, ast.Import):
                    for alias in stmt.names:
                        if alias.name == '*':
                            raise ValueError("star import not supported")
                        bound_name = alias.asname if alias.asname else alias.name.split('.')[0]
                        key = (node.name, bound_name)
                        if key in seen_bindings:
                            raise ValueError(f"duplicate import binding: {bound_name} in {node.name}")
                        imp = {
                            'scope': node.name,
                            'name': bound_name,
                            'module': alias.name,
                            'line': stmt.lineno
                        }
                        seen_bindings[key] = imp
                        imports.append(imp)
                elif isinstance(stmt, ast.ImportFrom):
                    if stmt.level > 0:
                        raise ValueError("relative import not supported")
                    for alias in stmt.names:
                        if alias.name == '*':
                            raise ValueError("star import not supported")
                        bound_name = alias.asname if alias.asname else alias.name
                        key = (node.name, bound_name)
                        if key in seen_bindings:
                            raise ValueError(f"duplicate import binding: {bound_name} in {node.name}")
                        imp = {
                            'scope': node.name,
                            'name': bound_name,
                            'module': f"{stmt.module}.{alias.name}" if stmt.module else alias.name,
                            'line': stmt.lineno
                        }
                        seen_bindings[key] = imp
                        imports.append(imp)

    return imports


def _matches_import(use, import_scope, import_name, func_names, tree):
    """Check if a use entry matches an import binding considering shadowing rules."""
    use_scope = use['scope']
    use_name = use['name']

    if use_name != import_name:
        return False

    if import_scope == 'module':
        if use_scope == 'module':
            return True
        if use_scope in func_names:
            # Check if there's a local import in this function that shadows
            if _has_local_import(tree, use_scope, import_name):
                return False
            # Check if parameter or assignment shadows
            if _is_shadowed_in_function(tree, use_scope, import_name):
                return False
            return True
        return False
    else:
        # Function-scoped import
        if use_scope == import_scope:
            return True
        return False


def _has_local_import(tree, func_name, name):
    """Check if a function has a local import binding the given name."""
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            for stmt in ast.walk(node):
                if stmt is node:
                    continue
                if isinstance(stmt, ast.Import):
                    for alias in stmt.names:
                        bound = alias.asname if alias.asname else alias.name.split('.')[0]
                        if bound == name:
                            return True
                elif isinstance(stmt, ast.ImportFrom):
                    for alias in stmt.names:
                        bound = alias.asname if alias.asname else alias.name
                        if bound == name:
                            return True
    return False


def _is_shadowed_in_function(tree, func_name, name):
    """Check if a name is shadowed by function parameters or assignments."""
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            # Check parameters
            all_args = list(node.args.args) + list(node.args.posonlyargs) + list(node.args.kwonlyargs)
            if node.args.vararg:
                all_args.append(node.args.vararg)
            if node.args.kwarg:
                all_args.append(node.args.kwarg)
            for arg in all_args:
                if arg.arg == name:
                    return True
            # Check assignments (Store names)
            for child in ast.walk(node):
                if child is node:
                    continue
                if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                    if child.id == name:
                        return True
    return False
