import ast

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    if not isinstance(source_data, dict) or 'source' not in source_data:
        raise ValueError("missing source field")
    source = source_data['source']
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []
    _collect_annotation_uses(tree, source, uses)
    seen = set()
    deduped = []
    for u in uses:
        key = (u['scope'], u['line'], u['name'])
        if key not in seen:
            seen.add(key)
            deduped.append(u)
    deduped.sort(key=lambda u: (u['scope'], u['line'], u['name']))
    return {"name": contract["name"], "result": {"uses": deduped}}


def _collect_annotation_uses(tree, source, uses):
    """Extract Load names from annotations."""
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            # Function signature annotations belong to module scope
            # Return annotation
            if node.returns is not None:
                _extract_annotation_loads(node.returns, 'module', uses)
            # Argument annotations
            all_args = list(node.args.args) + list(node.args.posonlyargs) + list(node.args.kwonlyargs)
            if node.args.vararg:
                all_args.append(node.args.vararg)
            if node.args.kwarg:
                all_args.append(node.args.kwarg)
            for arg in all_args:
                if arg.annotation is not None:
                    _extract_annotation_loads(arg.annotation, 'module', uses)
            # Function body AnnAssign annotations belong to function scope
            _collect_body_annotations(node, node.name, uses)
        elif isinstance(node, ast.AnnAssign):
            # Module-level annotated assignment
            _extract_annotation_loads(node.annotation, 'module', uses)


def _collect_body_annotations(func_node, func_name, uses):
    """Collect annotation uses from function body."""
    for stmt in ast.walk(func_node):
        if stmt is func_node:
            continue
        if isinstance(stmt, ast.AnnAssign):
            _extract_annotation_loads(stmt.annotation, func_name, uses)


def _extract_annotation_loads(annotation_node, scope, uses):
    """Extract Load names from an annotation node.
    If the outermost node is a string (forward reference), parse it as expression.
    Do not recursively interpret strings inside type expressions.
    """
    if isinstance(annotation_node, ast.Constant) and isinstance(annotation_node.value, str):
        # Forward reference string - parse as expression
        expr_str = annotation_node.value
        try:
            parsed = ast.parse(expr_str, mode='eval')
        except SyntaxError as e:
            raise ValueError(f"bad forward reference expression: {expr_str}") from e
        line = annotation_node.lineno
        for child in ast.walk(parsed):
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
                uses.append({"scope": scope, "name": child.id, "line": line})
    else:
        # Regular annotation - extract Load names but don't recurse into string constants
        _extract_load_names_no_inner_strings(annotation_node, scope, uses)


def _extract_load_names_no_inner_strings(node, scope, uses):
    """Walk AST extracting Name(Load) but skip string constants inside type expressions."""
    if node is None:
        return
    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
        uses.append({"scope": scope, "name": node.id, "line": node.lineno})
        return
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        # Don't recurse into inner strings
        return
    for child in ast.iter_child_nodes(node):
        _extract_load_names_no_inner_strings(child, scope, uses)
