import ast
import re

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    if not isinstance(source_data, dict) or 'source' not in source_data:
        raise ValueError("missing source field")
    source = source_data['source']
    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []
    _collect_type_comment_uses(tree, source, uses)
    seen = set()
    deduped = []
    for u in uses:
        key = (u['scope'], u['line'], u['name'])
        if key not in seen:
            seen.add(key)
            deduped.append(u)
    deduped.sort(key=lambda u: (u['scope'], u['line'], u['name']))
    return {"name": contract["name"], "result": {"uses": deduped}}


def _collect_type_comment_uses(tree, source, uses):
    """Only support # type: on Assign statements. Reject function signature and for/with type comments."""
    lines = source.splitlines(True)

    # Check for unsupported type comments on function defs, for, with
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            if node.type_comment is not None:
                raise ValueError("function signature type_comment not supported")
        if isinstance(node, ast.For):
            if node.type_comment is not None:
                raise ValueError("for type_comment not supported")
        if isinstance(node, ast.With):
            if node.type_comment is not None:
                raise ValueError("with type_comment not supported")

    # Process Assign nodes with type comments
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and node.type_comment is not None:
            tc = node.type_comment.strip()
            if tc == 'ignore':
                continue
            line = node.lineno
            scope = _get_scope(tree, node)
            try:
                parsed = ast.parse(tc, mode='eval')
            except SyntaxError as e:
                raise ValueError(f"bad type comment expression: {tc}") from e
            for child in ast.walk(parsed):
                if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
                    uses.append({"scope": scope, "name": child.id, "line": line})


def _get_scope(tree, target_node):
    """Determine if a node is at module level or inside a function."""
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            for child in ast.walk(node):
                if child is target_node:
                    return node.name
    return 'module'
