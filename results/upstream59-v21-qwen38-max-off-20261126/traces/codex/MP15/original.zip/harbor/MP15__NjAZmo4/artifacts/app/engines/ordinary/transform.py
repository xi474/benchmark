import ast

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    if not isinstance(source_data, dict) or 'source' not in source_data:
        raise ValueError("missing source field")
    source = source_data['source']
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []
    _collect_ordinary_uses(tree, source, uses)
    seen = set()
    deduped = []
    for u in uses:
        key = (u['scope'], u['line'], u['name'])
        if key not in seen:
            seen.add(key)
            deduped.append(u)
    deduped.sort(key=lambda u: (u['scope'], u['line'], u['name']))
    return {"name": contract["name"], "result": {"uses": deduped}}


def _collect_ordinary_uses(tree, source, uses):
    # Validate: only module-level and direct function defs (no class, lambda, async, nested)
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if isinstance(node, ast.AsyncFunctionDef):
                raise ValueError("async functions not supported")
            # Check for nested functions/classes inside
            _validate_function_body(node)
        elif isinstance(node, ast.ClassDef):
            raise ValueError("classes not supported")
        elif isinstance(node, ast.AsyncFunctionDef):
            raise ValueError("async functions not supported")

    # Collect module-level ordinary uses
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            # Decorators and defaults are in module scope
            for dec in node.decorator_list:
                _extract_load_names(dec, 'module', uses)
            for arg_default in node.args.defaults:
                _extract_load_names(arg_default, 'module', uses)
            for arg_default in node.args.kw_defaults:
                if arg_default is not None:
                    _extract_load_names(arg_default, 'module', uses)
            # Function body is in function scope
            _extract_body_ordinary_uses(node, node.name, uses)
        elif isinstance(node, (ast.Assign, ast.AugAssign, ast.AnnAssign, ast.Expr,
                                ast.If, ast.For, ast.While, ast.With, ast.Try,
                                ast.Return, ast.Delete, ast.Assert, ast.Raise,
                                ast.Import, ast.ImportFrom, ast.Global, ast.Nonlocal,
                                ast.Pass, ast.Break, ast.Continue)):
            _extract_stmt_ordinary_uses(node, 'module', uses)


def _validate_function_body(func_node):
    """Validate no nested functions, classes, lambdas, or conditional defs."""
    for node in ast.walk(func_node):
        if node is func_node:
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError("nested functions not supported")
        if isinstance(node, ast.ClassDef):
            raise ValueError("classes not supported")
        if isinstance(node, ast.Lambda):
            raise ValueError("lambda not supported")


def _extract_body_ordinary_uses(func_node, func_name, uses):
    """Extract ordinary uses from function body statements."""
    for stmt in func_node.body:
        _extract_stmt_ordinary_uses(stmt, func_name, uses)


def _extract_stmt_ordinary_uses(stmt, scope, uses):
    """Extract Load names from a statement's ordinary expression positions."""
    if isinstance(stmt, ast.AnnAssign):
        # Only the value part is ordinary; annotation is NOT ordinary
        if stmt.value is not None:
            _extract_load_names(stmt.value, scope, uses)
    elif isinstance(stmt, ast.Assign):
        for target in stmt.targets:
            _extract_load_names(target, scope, uses)
        _extract_load_names(stmt.value, scope, uses)
    elif isinstance(stmt, ast.AugAssign):
        _extract_load_names(stmt.target, scope, uses)
        _extract_load_names(stmt.value, scope, uses)
    elif isinstance(stmt, ast.Expr):
        _extract_load_names(stmt.value, scope, uses)
    elif isinstance(stmt, ast.Return):
        if stmt.value is not None:
            _extract_load_names(stmt.value, scope, uses)
    elif isinstance(stmt, ast.If):
        _extract_load_names(stmt.test, scope, uses)
        for s in stmt.body:
            _extract_stmt_ordinary_uses(s, scope, uses)
        for s in stmt.orelse:
            _extract_stmt_ordinary_uses(s, scope, uses)
    elif isinstance(stmt, ast.For):
        _extract_load_names(stmt.target, scope, uses)
        _extract_load_names(stmt.iter, scope, uses)
        for s in stmt.body:
            _extract_stmt_ordinary_uses(s, scope, uses)
        for s in stmt.orelse:
            _extract_stmt_ordinary_uses(s, scope, uses)
    elif isinstance(stmt, ast.While):
        _extract_load_names(stmt.test, scope, uses)
        for s in stmt.body:
            _extract_stmt_ordinary_uses(s, scope, uses)
        for s in stmt.orelse:
            _extract_stmt_ordinary_uses(s, scope, uses)
    elif isinstance(stmt, ast.With):
        for item in stmt.items:
            _extract_load_names(item.context_expr, scope, uses)
            if item.optional_vars is not None:
                _extract_load_names(item.optional_vars, scope, uses)
        for s in stmt.body:
            _extract_stmt_ordinary_uses(s, scope, uses)
    elif isinstance(stmt, ast.Try):
        for s in stmt.body:
            _extract_stmt_ordinary_uses(s, scope, uses)
        for handler in stmt.handlers:
            if handler.type is not None:
                _extract_load_names(handler.type, scope, uses)
            for s in handler.body:
                _extract_stmt_ordinary_uses(s, scope, uses)
        for s in stmt.orelse:
            _extract_stmt_ordinary_uses(s, scope, uses)
        for s in stmt.finalbody:
            _extract_stmt_ordinary_uses(s, scope, uses)
    elif isinstance(stmt, ast.Assert):
        _extract_load_names(stmt.test, scope, uses)
        if stmt.msg is not None:
            _extract_load_names(stmt.msg, scope, uses)
    elif isinstance(stmt, ast.Raise):
        if stmt.exc is not None:
            _extract_load_names(stmt.exc, scope, uses)
        if stmt.cause is not None:
            _extract_load_names(stmt.cause, scope, uses)
    elif isinstance(stmt, ast.Delete):
        for target in stmt.targets:
            _extract_load_names(target, scope, uses)
    # Import/ImportFrom, Pass, Break, Continue, Global, Nonlocal have no Load names


def _extract_load_names(node, scope, uses):
    """Walk an AST node and collect all Name(id, Load) references."""
    if node is None:
        return
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            uses.append({"scope": scope, "name": child.id, "line": child.lineno})
