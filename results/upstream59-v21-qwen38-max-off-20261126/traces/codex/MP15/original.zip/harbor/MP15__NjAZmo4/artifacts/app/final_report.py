import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core['components']
    component_count = len(components)

    # SHA256 of the complete core object
    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '':
                attention.add(comp_name)

    report = {
        "title": "普通引用、注解和类型注释的导入分析",
        "component_count": component_count,
        "sha256": sha256,
        "attention": sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

if __name__ == '__main__':
    main()
