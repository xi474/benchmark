import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    # Find all component contracts (not in outputs)
    contracts = sorted(
        [cp for cp in ROOT.rglob('contract.json') if 'outputs' not in cp.relative_to(ROOT).parts],
        key=lambda p: str(p)
    )
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency order: components whose inputs reference other outputs must run after
    # Simple topological sort based on output paths
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['output']] = (cp, c)

    # Determine execution order
    executed = set()
    order = []

    def resolve(output_path):
        if output_path in executed:
            return
        if output_path not in contract_map:
            # It's an input file, not a component output
            return
        cp, c = contract_map[output_path]
        for inp in c['inputs']:
            resolve(inp)
        order.append((cp, c))
        executed.add(output_path)

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        resolve(c['output'])

    # Execute each component via its render.py
    for cp, c in order:
        render_script = cp.with_name('render.py')
        if not render_script.exists():
            print(f"Missing render.py for {c['name']}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(f"Component {c['name']} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_script = ROOT / 'integrate.py'
    result = subprocess.run(
        [sys.executable, str(integrate_script)],
        cwd=ROOT,
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print("integrate.py failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    result = subprocess.run(
        [sys.executable, str(report_script)],
        cwd=ROOT,
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print("final_report.py failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
