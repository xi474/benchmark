import json
import sys
from pathlib import Path


def _write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)

    here = Path(__file__).resolve().parent
    parent_dir = here.parent
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))

    pkg_name = here.name
    import importlib
    model_mod = importlib.import_module(f"{pkg_name}.model")
    transform_mod = importlib.import_module(f"{pkg_name}.transform")

    contract = model_mod.load_payload(contract_path)
    payloads = [model_mod.load_payload(root / p) for p in contract['inputs']]
    result = transform_mod.transform(payloads, contract)
    out_path = root / contract['output']
    _write_json(out_path, result)
    return result


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    cp = here / 'contract.json'
    build_component(root, cp)
