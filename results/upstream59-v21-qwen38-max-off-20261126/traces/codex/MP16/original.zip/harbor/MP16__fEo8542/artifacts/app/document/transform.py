import re


def _replace_aliases_in_type(type_str, aliases):
    if type_str is None or not aliases:
        return type_str

    def replacer(match):
        ident = match.group(0)
        start = match.start()
        if start > 0 and type_str[start - 1] == '.':
            return ident
        end = match.end()
        if end < len(type_str) and type_str[end] == '.':
            return ident
        if ident in aliases:
            return aliases[ident]
        return ident

    return re.sub(r'[A-Za-z_]\w*', replacer, type_str)


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    sig_result = payloads[0]
    param_result = payloads[1]
    inherit_result = payloads[2]

    if isinstance(sig_result, dict) and 'result' in sig_result:
        sig_data = sig_result['result']
    else:
        sig_data = sig_result

    if isinstance(param_result, dict) and 'result' in param_result:
        param_data = param_result['result']
    else:
        param_data = param_result

    if isinstance(inherit_result, dict) and 'result' in inherit_result:
        inherit_data = inherit_result['result']
    else:
        inherit_data = inherit_result

    overloads = sig_data.get('overloads', [])
    docs = param_data.get('docs', {})
    provider_id = inherit_data.get('provider')
    namespace = inherit_data.get('namespace')
    aliases = inherit_data.get('aliases', {})

    if provider_id is not None and provider_id in docs:
        raw_params = docs[provider_id]
        parameters = []
        for p in raw_params:
            new_type = _replace_aliases_in_type(p.get('type'), aliases)
            parameters.append({
                "name": p["name"],
                "type": new_type,
                "description": p.get("description", "")
            })
    else:
        parameters = []

    return {
        "name": contract["name"],
        "result": {
            "overloads": overloads,
            "provider": provider_id,
            "namespace": namespace,
            "parameters": parameters
        }
    }
