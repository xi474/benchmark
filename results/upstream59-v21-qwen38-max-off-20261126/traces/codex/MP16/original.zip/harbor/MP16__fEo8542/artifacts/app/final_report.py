import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core.get('components', {})

    title = 'API 文档的签名、参数与继承信息聚合'
    component_count = len(components)

    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(canonical).hexdigest()

    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        if result.get('blocked') is True:
            triggered = True
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                triggered = True
                break
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict)) and len(val) > 0:
                    triggered = True
                    break
                elif isinstance(val, str) and len(val) > 0:
                    triggered = True
                    break
        if triggered:
            attention.append(name)

    attention = sorted(set(attention))

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

if __name__ == '__main__':
    main()
