def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'objects' not in payload:
        raise ValueError("missing objects")
    if 'target' not in payload:
        raise ValueError("missing target")

    objects = payload['objects']
    target = payload['target']

    obj_map = {}
    for obj in objects:
        obj_map[obj['id']] = obj

    if target not in obj_map:
        raise ValueError(f"target {target} not found")

    target_obj = obj_map[target]
    candidate_ids = [target] + target_obj.get('mro', [])

    provider = None
    for cid in candidate_ids:
        if cid not in obj_map:
            continue
        obj = obj_map[cid]
        doc = obj.get('doc', '')
        if isinstance(doc, str) and doc.strip():
            provider = obj
            break

    if provider is None:
        return {
            "name": contract["name"],
            "result": {
                "provider": None,
                "namespace": None,
                "aliases": {}
            }
        }

    return {
        "name": contract["name"],
        "result": {
            "provider": provider['id'],
            "namespace": provider.get('namespace'),
            "aliases": provider.get('aliases', {})
        }
    }
