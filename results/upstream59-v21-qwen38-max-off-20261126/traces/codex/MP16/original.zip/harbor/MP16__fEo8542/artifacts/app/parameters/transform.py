import re


def _parse_doc(doc_str):
    params = {}
    types = {}
    param_order = []

    for line in doc_str.split('\n'):
        stripped = line.strip()
        if not stripped:
            continue

        type_match = re.match(r'^:type\s+(\w+)\s*:\s*(.+)$', stripped)
        if type_match:
            name = type_match.group(1)
            type_val = type_match.group(2).strip()
            if name in types:
                raise ValueError(f"duplicate :type for {name}")
            types[name] = type_val
            continue

        param_with_type = re.match(r'^:param\s+(.+?)\s+(\w+)\s*:\s*(.*)$', stripped)
        if param_with_type:
            type_part = param_with_type.group(1).strip()
            name = param_with_type.group(2)
            desc = param_with_type.group(3).strip()
            if name in params:
                raise ValueError(f"duplicate :param for {name}")
            params[name] = {"type": type_part, "description": desc}
            param_order.append(name)
            continue

        param_simple = re.match(r'^:param\s+(\w+)\s*:\s*(.*)$', stripped)
        if param_simple:
            name = param_simple.group(1)
            desc = param_simple.group(2).strip()
            if name in params:
                raise ValueError(f"duplicate :param for {name}")
            params[name] = {"type": None, "description": desc}
            param_order.append(name)
            continue

    all_names = set(param_order) | set(types.keys())
    result = []
    for name in sorted(all_names):
        entry = {"name": name}
        if name in params:
            inline_type = params[name]["type"]
            description = params[name]["description"]
        else:
            inline_type = None
            description = ""

        if name in types:
            final_type = types[name]
        else:
            final_type = inline_type

        entry["type"] = final_type
        entry["description"] = description
        result.append(entry)

    return result


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'objects' not in payload:
        raise ValueError("missing objects")

    objects = payload['objects']
    docs = {}
    for obj in objects:
        obj_id = obj['id']
        doc_str = obj.get('doc', '')
        parsed = _parse_doc(doc_str)
        docs[obj_id] = parsed

    return {
        "name": contract["name"],
        "result": {
            "docs": docs
        }
    }
