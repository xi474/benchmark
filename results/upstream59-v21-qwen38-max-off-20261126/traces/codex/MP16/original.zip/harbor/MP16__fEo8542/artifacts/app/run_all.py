import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def _run_component(component_dir):
    render_py = component_dir / 'render.py'
    if not render_py.exists():
        raise FileNotFoundError(f"render.py not found in {component_dir}")
    result = subprocess.run(
        [sys.executable, str(render_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: {component_dir.name}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

def main():
    out_dir = ROOT / 'outputs'
    out_dir.mkdir(parents=True, exist_ok=True)

    independent = ['signatures', 'parameters', 'inheritance']
    for name in independent:
        comp_dir = ROOT / name
        if comp_dir.is_dir() and (comp_dir / 'contract.json').exists():
            _run_component(comp_dir)

    dependent = ['document']
    for name in dependent:
        comp_dir = ROOT / name
        if comp_dir.is_dir() and (comp_dir / 'contract.json').exists():
            _run_component(comp_dir)

    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()
