import ast


def _parse_signature(sig_str):
    fake = f"def {sig_str}: pass"
    tree = ast.parse(fake)
    func_def = tree.body[0]
    name = func_def.name
    args = func_def.args

    parameters = []

    posonlyargs = getattr(args, 'posonlyargs', [])
    for a in posonlyargs:
        ann = ast.unparse(a.annotation) if a.annotation else None
        parameters.append({
            "name": a.arg,
            "kind": "posonly",
            "annotation": ann,
            "default": None
        })

    num_args = len(args.args)
    num_defaults = len(args.defaults)
    num_non_default = num_args - num_defaults

    for i, a in enumerate(args.args):
        ann = ast.unparse(a.annotation) if a.annotation else None
        default = None
        default_idx = i - num_non_default
        if default_idx >= 0:
            default = ast.unparse(args.defaults[default_idx])
        parameters.append({
            "name": a.arg,
            "kind": "positional",
            "annotation": ann,
            "default": default
        })

    if args.vararg:
        ann = ast.unparse(args.vararg.annotation) if args.vararg.annotation else None
        parameters.append({
            "name": args.vararg.arg,
            "kind": "vararg",
            "annotation": ann,
            "default": None
        })

    for i, a in enumerate(args.kwonlyargs):
        ann = ast.unparse(a.annotation) if a.annotation else None
        default = None
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            default = ast.unparse(args.kw_defaults[i])
        parameters.append({
            "name": a.arg,
            "kind": "kwonly",
            "annotation": ann,
            "default": default
        })

    if args.kwarg:
        ann = ast.unparse(args.kwarg.annotation) if args.kwarg.annotation else None
        parameters.append({
            "name": args.kwarg.arg,
            "kind": "kwarg",
            "annotation": ann,
            "default": None
        })

    returns = ast.unparse(func_def.returns) if func_def.returns else None

    return {
        "name": name,
        "parameters": parameters,
        "returns": returns
    }


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'overloads' not in payload:
        raise ValueError("missing overloads")
    overloads_raw = payload['overloads']
    if not isinstance(overloads_raw, list):
        raise ValueError("overloads must be list")

    parsed = []
    for sig in overloads_raw:
        if not isinstance(sig, str):
            raise ValueError("overload must be string")
        parsed.append(_parse_signature(sig))

    return {
        "name": contract["name"],
        "result": {
            "overloads": parsed
        }
    }
