import re


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    raw_enc = payloads[1]
    # When input object keys are exactly {name, result}, extract result
    if isinstance(raw_enc, dict) and set(raw_enc.keys()) == {'name', 'result'}:
        encoding_data = raw_enc['result']
    else:
        encoding_data = raw_enc

    boundary = case.get('boundary')
    if not isinstance(boundary, str) or not boundary or not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError("invalid boundary")

    # Check boundary bytes don't appear in any payload
    boundary_bytes = boundary.encode('ascii')
    for part in encoding_data.get('parts', []):
        payload_raw = bytes.fromhex(part['payload_hex'])
        if boundary_bytes in payload_raw:
            raise ValueError("boundary found in payload")

    body_chunks = []
    for part in encoding_data['parts']:
        name = part['name']
        filename = part.get('filename')
        mimetype = part['mimetype']
        enc = part['encoding']
        payload_raw = bytes.fromhex(part['payload_hex'])

        chunk = b''
        chunk += f'--{boundary}\r\n'.encode('ascii')
        if enc == 'base64':
            chunk += b'Content-Transfer-Encoding: base64\r\n'
        chunk += f'Content-Type: {mimetype}\r\n'.encode('ascii')
        disp = f'form-data; name="{name}"'
        if filename is not None:
            disp += f'; filename="{filename}"'
        chunk += f'Content-Disposition: {disp}\r\n'.encode('ascii')
        chunk += b'\r\n'
        chunk += payload_raw
        chunk += b'\r\n'
        body_chunks.append(chunk)

    body_chunks.append(f'--{boundary}--\r\n'.encode('ascii'))
    body = b''.join(body_chunks)
    content_type = f'multipart/form-data; boundary={boundary}'

    return {
        'name': contract['name'],
        'result': {
            'content_type': content_type,
            'body_hex': body.hex(),
        },
    }
