import base64


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    raw = payloads[0]
    # When input object keys are exactly {name, result}, extract result
    if isinstance(raw, dict) and set(raw.keys()) == {'name', 'result'}:
        parts_input = raw['result']
    else:
        parts_input = raw
    if not isinstance(parts_input, dict) or 'parts' not in parts_input:
        raise ValueError("input must have 'parts' key")

    result_parts = []
    for part in parts_input['parts']:
        enc = part.get('encoding')
        raw_bytes = bytes.fromhex(part['hex'])

        if enc == 'raw':
            payload_hex = raw_bytes.hex()
        elif enc == 'base64':
            encoded = base64.b64encode(raw_bytes).decode('ascii')
            # Fold every 76 chars with CRLF between lines, no trailing CRLF
            lines = [encoded[i:i+76] for i in range(0, len(encoded), 76)]
            folded = '\r\n'.join(lines)
            payload_hex = folded.encode('ascii').hex()
        else:
            raise ValueError(f"unknown encoding: {enc!r}")

        new_part = dict(part)
        new_part['payload_hex'] = payload_hex
        result_parts.append(new_part)

    return {'name': contract['name'], 'result': {'parts': result_parts}}
