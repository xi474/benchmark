import base64
import os
import re

_FIELD_NAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_SAFE_BASENAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_MIME_RE = re.compile(r'^[A-Za-z0-9!#$&\-.^_+]+/[A-Za-z0-9!#$&\-.^_+]+$')
_EXT_MAP = {
    '.txt': 'text/plain',
    '.json': 'application/json',
    '.jpg': 'image/jpeg',
}


def _safe_relative_path(p):
    if not p or not isinstance(p, str):
        raise ValueError(f"invalid path: {p!r}")
    if '\\' in p or ':' in p:
        raise ValueError(f"unsafe path: {p!r}")
    parts = p.split('/')
    for seg in parts:
        if seg == '' or seg == '.' or seg == '..':
            raise ValueError(f"unsafe path segment: {p!r}")
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    fields = case.get('fields')
    files_map = case.get('files')
    boundary = case.get('boundary')
    if not isinstance(fields, dict):
        raise ValueError("fields must be object")
    if not isinstance(files_map, dict):
        raise ValueError("files must be object")
    if not isinstance(boundary, str) or not boundary or not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError("invalid boundary")

    # Validate file paths
    for fp in files_map:
        _safe_relative_path(fp)

    parts_list = []
    for name, value in fields.items():
        if not _FIELD_NAME_RE.match(name):
            raise ValueError(f"invalid field name: {name!r}")

        filename = None
        mimetype = None
        encoding = 'raw'
        data_bytes = b''

        if isinstance(value, str):
            # Pure string field
            data_bytes = value.encode('utf-8')
            mimetype = 'text/plain'
            filename = None
            encoding = 'raw'
        elif isinstance(value, dict):
            if not value:
                raise ValueError(f"empty field object for {name!r}")
            content = value.get('content')
            fname = value.get('filename')
            explicit_mime = value.get('mimetype')

            if content is not None:
                if not isinstance(content, str):
                    raise ValueError(f"content must be str for {name!r}")
                data_bytes = content.encode('utf-8')
                if fname is not None:
                    if not isinstance(fname, str) or not fname:
                        raise ValueError(f"invalid filename for {name!r}")
                    basename = os.path.basename(fname.replace('\\', '/'))
                    if not _SAFE_BASENAME_RE.match(basename):
                        raise ValueError(f"unsafe basename: {basename!r}")
                    filename = basename
                encoding = 'raw'
            elif fname is not None:
                if not isinstance(fname, str) or not fname:
                    raise ValueError(f"invalid filename for {name!r}")
                _safe_relative_path(fname)
                if fname not in files_map:
                    raise ValueError(f"file not found: {fname!r}")
                hex_str = files_map[fname]
                data_bytes = bytes.fromhex(hex_str)
                basename = os.path.basename(fname.replace('\\', '/'))
                if not _SAFE_BASENAME_RE.match(basename):
                    raise ValueError(f"unsafe basename: {basename!r}")
                filename = basename
                encoding = 'base64'
            else:
                raise ValueError(f"field object must have content or filename for {name!r}")

            if explicit_mime is not None:
                if not isinstance(explicit_mime, str) or not _MIME_RE.match(explicit_mime):
                    raise ValueError(f"invalid mimetype: {explicit_mime!r}")
                mimetype = explicit_mime
            else:
                if filename is not None:
                    _, ext = os.path.splitext(filename)
                    mimetype = _EXT_MAP.get(ext.lower(), 'application/octet-stream')
                else:
                    mimetype = 'application/octet-stream'
        else:
            raise ValueError(f"invalid field value type for {name!r}")

        parts_list.append({
            'name': name,
            'filename': filename,
            'mimetype': mimetype,
            'encoding': encoding,
            'hex': data_bytes.hex(),
        })

    parts_list.sort(key=lambda p: p['name'])
    return {'name': contract['name'], 'result': {'parts': parts_list}}
