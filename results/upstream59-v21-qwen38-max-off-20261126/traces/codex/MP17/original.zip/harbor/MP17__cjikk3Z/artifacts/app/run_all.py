import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all component contracts (exclude outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency order: topological sort based on input dependencies
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = (cp, c)

    # Determine execution order via topological sort
    output_to_component = {}
    for name, (cp, c) in contract_map.items():
        output_to_component[c['output']] = name

    deps = {}
    for name, (cp, c) in contract_map.items():
        dep_set = set()
        for inp in c['inputs']:
            if inp in output_to_component:
                dep_set.add(output_to_component[inp])
        deps[name] = dep_set

    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"circular dependency detected: {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        for d in sorted(deps.get(name, set())):
            visit(d)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Execute each component's render.py in order
    for name in ordered:
        cp, c = contract_map[name]
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f"missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"component {name} failed", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)


    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
