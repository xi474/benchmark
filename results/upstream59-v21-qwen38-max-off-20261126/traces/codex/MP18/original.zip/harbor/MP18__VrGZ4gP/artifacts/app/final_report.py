import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core["components"]

    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha = hashlib.sha256(serialized).hexdigest()

    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        if result.get("blocked") is True:
            triggered = True
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict)) and len(val) > 0:
                    triggered = True
                elif isinstance(val, str) and len(val) > 0:
                    triggered = True
                elif not isinstance(val, (list, dict, str, bool, type(None))):
                    triggered = True
        if triggered:
            attention.append(name)

    attention = sorted(set(attention))

    report = {
        "attention": attention,
        "component_count": len(components),
        "sha256": sha,
        "title": "集合文件清单的指令选择与归档元数据",
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
