import hashlib


def transform(payloads, contract):
    inventory_result = payloads[0]["result"]
    selection_result = payloads[1]["result"]

    file_map = {}
    for f in inventory_result["files"]:
        file_map[f["path"]] = f["hex"]

    selected = selection_result["selected"]

    if len(selected) != len(set(selected)):
        raise ValueError("duplicate in selected")

    entries = []
    total_bytes = 0
    for path in selected:
        if path not in file_map:
            raise ValueError("selected path not in inventory regular files")
        hex_str = file_map[path]
        raw_bytes = bytes.fromhex(hex_str)
        sha = hashlib.sha256(raw_bytes).hexdigest()
        size = len(raw_bytes)
        entries.append({"path": path, "sha256": sha, "size": size})
        total_bytes += size

    return {
        "name": contract["name"],
        "result": {
            "entries": entries,
            "total_bytes": total_bytes,
        },
    }
