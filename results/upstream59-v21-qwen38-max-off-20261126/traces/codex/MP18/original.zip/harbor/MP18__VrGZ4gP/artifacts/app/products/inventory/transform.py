def _validate_safe_relative_path(p):
    if not p or not isinstance(p, str):
        raise ValueError("invalid path")
    if "\\" in p or ":" in p:
        raise ValueError("unsafe path characters")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError("unsafe path segment")
    if p.startswith("/"):
        raise ValueError("absolute path")


def transform(payloads, contract):
    case = payloads[0]
    files_list = case["files"]
    manifest_val = case.get("manifest")
    build_ignore_val = case.get("build_ignore")

    regular_files = []
    symlinks = []
    seen_paths = set()

    for entry in files_list:
        path = entry["path"]
        kind = entry["kind"]
        _validate_safe_relative_path(path)
        if path in seen_paths:
            raise ValueError("duplicate path")
        seen_paths.add(path)

        if kind == "file":
            hex_str = entry["hex"]
            bytes.fromhex(hex_str)
            target = entry.get("target")
            if target is not None:
                raise ValueError("file must have null target")
            regular_files.append({"path": path, "hex": hex_str})
        elif kind == "symlink":
            target = entry["target"]
            if target is None:
                raise ValueError("symlink must have non-null target")
            _validate_safe_relative_path(target)
            symlinks.append(path)
        else:
            raise ValueError("unknown kind")

    regular_files.sort(key=lambda x: x["path"])
    symlinks.sort()

    return {
        "name": contract["name"],
        "result": {
            "files": regular_files,
            "symlinks": symlinks,
        },
    }
