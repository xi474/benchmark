import fnmatch


def _is_under_git(path):
    parts = path.split("/")
    for part in parts:
        if part == ".git":
            return True
    return False


def _should_always_exclude(path):
    if _is_under_git(path):
        return True
    if path.endswith(".pyc"):
        basename = path.rsplit("/", 1)[-1] if "/" in path else path
        if basename.endswith(".pyc"):
            return True
    if path == "MANIFEST.in":
        return True
    return False


def _parse_manifest(manifest_text, all_regular_paths):
    selected = set()
    lines = manifest_text.split("\n")
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        tokens = stripped.split()
        cmd = tokens[0]
        if cmd == "include":
            if len(tokens) != 2:
                raise ValueError("invalid include syntax")
            pattern = tokens[1]
            for p in all_regular_paths:
                if fnmatch.fnmatchcase(p, pattern):
                    selected.add(p)
        elif cmd == "exclude":
            if len(tokens) != 2:
                raise ValueError("invalid exclude syntax")
            pattern = tokens[1]
            for p in list(selected):
                if fnmatch.fnmatchcase(p, pattern):
                    selected.discard(p)
        elif cmd == "recursive-include":
            if len(tokens) != 3:
                raise ValueError("invalid recursive-include syntax")
            dir_prefix = tokens[1]
            pattern = tokens[2]
            for p in all_regular_paths:
                if p.startswith(dir_prefix + "/"):
                    basename = p.rsplit("/", 1)[-1]
                    if fnmatch.fnmatchcase(basename, pattern):
                        selected.add(p)
        elif cmd == "global-exclude":
            if len(tokens) != 2:
                raise ValueError("invalid global-exclude syntax")
            pattern = tokens[1]
            for p in list(selected):
                basename = p.rsplit("/", 1)[-1] if "/" in p else p
                if fnmatch.fnmatchcase(basename, pattern):
                    selected.discard(p)
        else:
            raise ValueError("unknown manifest command: " + cmd)
    return selected


def transform(payloads, contract):
    case = payloads[0]
    inventory_result = payloads[1]["result"]

    manifest_val = case.get("manifest")
    build_ignore_val = case.get("build_ignore")

    if manifest_val is not None and build_ignore_val is not None:
        raise ValueError("manifest and build_ignore cannot both be non-null")

    all_regular_paths = [f["path"] for f in inventory_result["files"]]

    if manifest_val is None:
        selected = set(all_regular_paths)
        if build_ignore_val is not None:
            for pattern in build_ignore_val:
                for p in list(selected):
                    if fnmatch.fnmatchcase(p, pattern):
                        selected.discard(p)
    else:
        selected = _parse_manifest(manifest_val, all_regular_paths)

    final_selected = []
    for p in selected:
        if not _should_always_exclude(p):
            final_selected.append(p)

    final_selected.sort()

    return {
        "name": contract["name"],
        "result": {
            "selected": final_selected,
        },
    }
