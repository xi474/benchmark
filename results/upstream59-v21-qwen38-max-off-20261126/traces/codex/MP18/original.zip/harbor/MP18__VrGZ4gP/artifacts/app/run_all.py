import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    components_dir = ROOT / "products"
    contract_files = sorted(components_dir.rglob("contract.json"))

    built = set()
    pending = {}
    for cp in contract_files:
        c = json.loads(cp.read_text(encoding="utf-8"))
        pending[cp] = c

    max_iterations = len(pending) + 1
    for _ in range(max_iterations):
        if not pending:
            break
        progress = False
        for cp in list(pending.keys()):
            c = pending[cp]
            deps_met = True
            for inp in c["inputs"]:
                inp_path = ROOT / inp
                if not inp_path.exists():
                    deps_met = False
                    break
            if deps_met:
                render_py = cp.with_name("render.py")
                result = subprocess.run(
                    [sys.executable, str(render_py)],
                    cwd=ROOT,
                    capture_output=True,
                    text=True,
                )
                if result.returncode != 0:
                    print(result.stderr, file=sys.stderr)
                    sys.exit(1)
                out_path = ROOT / c["output"]
                if not out_path.exists():
                    print(f"Output not created: {c['output']}", file=sys.stderr)
                    sys.exit(1)
                built.add(c["name"])
                del pending[cp]
                progress = True
        if not progress:
            print("Unresolvable dependencies", file=sys.stderr)
            sys.exit(1)

    if pending:
        print("Could not build all components", file=sys.stderr)
        sys.exit(1)

    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
