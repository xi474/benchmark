import json
from pathlib import Path
import sys

def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    
    comp_dir = str(contract_path.parent)
    if comp_dir not in sys.path:
        sys.path.insert(0, comp_dir)
    
    from model import load_payload
    from transform import transform
    
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    return result

if __name__ == "__main__":
    cp = Path(__file__).with_name('contract.json')
    root = cp.resolve().parents[2]
    build_component(root, cp)
