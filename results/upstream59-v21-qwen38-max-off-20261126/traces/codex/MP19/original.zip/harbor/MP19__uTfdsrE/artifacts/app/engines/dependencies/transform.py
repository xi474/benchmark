from collections import deque

def transform(payloads, contract):
    case = payloads[0]
    scan_result = payloads[1]['result']
    
    entry = case['entry']
    modules = case['modules']
    
    imports_map = scan_result['imports']
    module_paths = scan_result['module_paths']
    
    visited_paths = set()
    external_set = set()
    queue = deque()
    queue.append(entry)
    
    while queue:
        current_path = queue.popleft()
        if current_path in visited_paths:
            continue
        visited_paths.add(current_path)
        
        # Add parent package __init__.py files
        parts = current_path.split('/')
        for i in range(1, len(parts)):
            init_path = '/'.join(parts[:i]) + '/__init__.py'
            if init_path in modules and init_path not in visited_paths:
                queue.append(init_path)
        
        if current_path in imports_map:
            for dep_modname in imports_map[current_path]:
                if dep_modname in module_paths:
                    dep_path = module_paths[dep_modname]
                    if dep_path not in visited_paths:
                        queue.append(dep_path)
                else:
                    external_set.add(dep_modname)
    
    result = {
        'paths': sorted(visited_paths),
        'external': sorted(external_set)
    }
    return {'name': contract['name'], 'result': result}
