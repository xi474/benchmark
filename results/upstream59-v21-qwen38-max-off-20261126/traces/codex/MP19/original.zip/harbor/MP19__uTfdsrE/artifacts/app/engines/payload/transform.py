import hashlib
import io
import zipfile

def transform(payloads, contract):
    case = payloads[0]
    dep_result = payloads[1]['result']
    
    modules = case['modules']
    paths = dep_result['paths']
    external = dep_result['external']
    
    if len(paths) != len(set(paths)):
        raise ValueError("duplicate paths in closure")
    
    buf = io.BytesIO()
    
    has_root_init = '__init__.py' in paths
    need_root_init = not has_root_init
    
    all_zip_paths = sorted(paths)
    if need_root_init:
        if '__init__.py' not in all_zip_paths:
            all_zip_paths.append('__init__.py')
            all_zip_paths.sort()
    
    fixed_date_time = (1980, 1, 1, 0, 0, 0)
    
    seen = set()
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_STORED) as zf:
        for zp in all_zip_paths:
            if zp in seen:
                raise ValueError(f"duplicate path {zp}")
            seen.add(zp)
            
            if zp == '__init__.py' and need_root_init:
                data = b''
            else:
                if zp not in modules:
                    raise ValueError(f"source path {zp} not found in modules")
                data = modules[zp].encode('utf-8')
            
            info = zipfile.ZipInfo(filename=zp, date_time=fixed_date_time)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o644 << 16
            zf.writestr(info, data)
    
    zip_bytes = buf.getvalue()
    zip_hex = zip_bytes.hex()
    sha256 = hashlib.sha256(zip_bytes).hexdigest()
    
    result = {
        'paths': all_zip_paths,
        'zip_hex': zip_hex,
        'sha256': sha256,
        'external': external
    }
    return {'name': contract['name'], 'result': result}
