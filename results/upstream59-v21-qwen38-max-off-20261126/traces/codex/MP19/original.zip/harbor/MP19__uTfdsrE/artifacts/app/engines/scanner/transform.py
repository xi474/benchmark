import ast

def _resolve_external(name, externals, aliases):
    canonical = aliases.get(name, name)
    if canonical in externals:
        return canonical
    first = canonical.split('.')[0]
    if first in externals:
        return canonical
    return None

def _resolve_import(name, modname_to_path, externals, aliases):
    if name in modname_to_path:
        return name
    parts = name.split('.')
    for i in range(len(parts), 0, -1):
        prefix = '.'.join(parts[:i])
        if prefix in modname_to_path:
            return prefix
    return _resolve_external(name, externals, aliases)

def transform(payloads, contract):
    case = payloads[0]
    modules = case['modules']
    entry = case['entry']
    externals = case.get('externals', [])
    aliases = case.get('aliases', {})

    local_paths = set(modules.keys())

    def path_to_modname(p):
        if p == '__init__.py':
            return ''
        if p.endswith('/__init__.py'):
            return p[:-len('/__init__.py')].replace('/', '.')
        if p.endswith('.py'):
            return p[:-3].replace('/', '.')
        return None

    modname_to_path = {}
    for p in local_paths:
        mn = path_to_modname(p)
        if mn is not None:
            modname_to_path[mn] = p

    imports = {}
    module_paths = {mn: p for mn, p in modname_to_path.items()}

    for path, source in modules.items():
        tree = ast.parse(source, filename=path)
        deps = set()

        # Determine current package context
        if path.endswith('/__init__.py'):
            current_package = path[:-len('/__init__.py')].replace('/', '.')
            is_package_init = True
        elif path == '__init__.py':
            current_package = ''
            is_package_init = True
        else:
            if '/' in path:
                current_package = path.rsplit('/', 1)[0].replace('/', '.')
            else:
                current_package = ''
            is_package_init = False

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias_node in node.names:
                    dep_name = alias_node.name
                    resolved = _resolve_import(dep_name, modname_to_path, externals, aliases)
                    if resolved is not None:
                        deps.add(resolved)
                    else:
                        raise ValueError(f"unknown module {dep_name} in {path}")
            elif isinstance(node, ast.ImportFrom):
                if any(a.name == '*' for a in node.names):
                    raise ValueError("from * import not allowed")
                level = node.level
                if level > 0:
                    # Relative import
                    if is_package_init:
                        pkg = current_package
                    else:
                        if '/' in path:
                            pkg = path.rsplit('/', 1)[0].replace('/', '.')
                        else:
                            pkg = ''
                    pkg_parts = pkg.split('.') if pkg else []
                    up = level - 1
                    if up > len(pkg_parts):
                        raise ValueError(f"relative import beyond root from {path}")
                    if up > 0:
                        base = '.'.join(pkg_parts[:-up])
                    else:
                        base = pkg

                    if node.module:
                        full = f"{base}.{node.module}" if base else node.module
                    else:
                        full = base

                    for imp_alias in node.names:
                        candidate = f"{full}.{imp_alias.name}" if full else imp_alias.name
                        if candidate in modname_to_path:
                            deps.add(candidate)
                        elif full in modname_to_path:
                            deps.add(full)
                        else:
                            resolved = _resolve_external(full, externals, aliases)
                            if resolved is not None:
                                deps.add(resolved)
                            else:
                                resolved2 = _resolve_external(candidate, externals, aliases)
                                if resolved2 is not None:
                                    deps.add(resolved2)
                                else:
                                    raise ValueError(f"unknown module {candidate} in {path}")
                else:
                    base = node.module
                    for imp_alias in node.names:
                        candidate = f"{base}.{imp_alias.name}"
                        if candidate in modname_to_path:
                            deps.add(candidate)
                        elif base in modname_to_path:
                            deps.add(base)
                        else:
                            resolved = _resolve_external(base, externals, aliases)
                            if resolved is not None:
                                deps.add(resolved)
                            else:
                                resolved2 = _resolve_external(candidate, externals, aliases)
                                if resolved2 is not None:
                                    deps.add(resolved2)
                                else:
                                    raise ValueError(f"unknown module {base} in {path}")

        imports[path] = sorted(deps)

    result = {
        'imports': {k: imports[k] for k in sorted(imports.keys())},
        'module_paths': {k: module_paths[k] for k in sorted(module_paths.keys())}
    }
    return {'name': contract['name'], 'result': result}
