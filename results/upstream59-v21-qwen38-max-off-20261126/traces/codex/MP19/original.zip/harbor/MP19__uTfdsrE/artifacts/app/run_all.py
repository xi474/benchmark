import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    # Find all contract.json files (not in outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    
    # Topological sort based on input dependencies
    # Build a map of output -> contract_path
    output_to_contract = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        output_to_contract[c['output']] = cp
    
    # Build dependency graph
    ordered = []
    visited = set()
    
    def visit(cp):
        cp_str = str(cp)
        if cp_str in visited:
            return
        visited.add(cp_str)
        c = json.loads(cp.read_text(encoding='utf-8'))
        for inp in c['inputs']:
            if inp in output_to_contract:
                visit(output_to_contract[inp])
        ordered.append(cp)
    
    for cp in contracts:
        visit(cp)
    
    for cp in ordered:
        render_script = cp.with_name('render.py')
        if not render_script.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        subprocess.run([sys.executable, str(render_script)], cwd=ROOT, check=True)
    
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True)

if __name__ == '__main__':
    main()
