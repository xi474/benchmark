import copy
import json


def _validate_string(val, context):
    if not isinstance(val, str):
        raise ValueError(f"{context}: expected string")
    if not val.strip():
        raise ValueError(f"{context}: empty or whitespace-only string")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    for key in ("flags", "segments", "old_snapshot"):
        if key not in data:
            raise ValueError(f"missing field: {key}")
    flags = data["flags"]
    segments = data["segments"]
    if not isinstance(flags, list):
        raise ValueError("flags must be array")
    if not isinstance(segments, list):
        raise ValueError("segments must be array")
    flag_ids = set()
    attachments = {}
    for fi, flag in enumerate(flags):
        if not isinstance(flag, dict):
            raise ValueError(f"flag[{fi}] must be object")
        if "id" not in flag:
            raise ValueError(f"flag[{fi}] missing id")
        _validate_string(flag["id"], f"flag[{fi}].id")
        if flag["id"] in flag_ids:
            raise ValueError(f"duplicate flag id: {flag['id']}")
        flag_ids.add(flag["id"])
        if "variants" not in flag:
            raise ValueError(f"flag[{fi}] missing variants")
        variants = flag["variants"]
        if not isinstance(variants, list):
            raise ValueError(f"flag[{fi}].variants must be array")
        var_ids = set()
        flag_attachments = {}
        for vi, var in enumerate(variants):
            if not isinstance(var, dict):
                raise ValueError(f"flag[{fi}].variant[{vi}] must be object")
            if "id" not in var:
                raise ValueError(f"flag[{fi}].variant[{vi}] missing id")
            _validate_string(var["id"], f"flag[{fi}].variant[{vi}].id")
            if var["id"] in var_ids:
                raise ValueError(f"duplicate variant id in flag {flag['id']}: {var['id']}")
            var_ids.add(var["id"])
            if "attachment" not in var:
                raise ValueError(f"flag[{fi}].variant[{vi}] missing attachment")
            att = var["attachment"]
            canonical = json.dumps(att, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
            flag_attachments[var["id"]] = {"value": copy.deepcopy(att), "canonical": canonical}
        attachments[flag["id"]] = flag_attachments
    return {
        "name": contract["name"],
        "result": {"attachments": attachments},
    }
