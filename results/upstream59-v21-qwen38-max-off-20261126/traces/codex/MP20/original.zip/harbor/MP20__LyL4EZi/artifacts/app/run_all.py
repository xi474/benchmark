import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

COMPONENT_ORDER = [
    "domains/schema",
    "domains/attachments",
    "views/references",
    "views/snapshot",
]


def main():
    for comp in COMPONENT_ORDER:
        render_py = ROOT / comp / "render.py"
        if not render_py.is_file():
            print(f"missing render.py for {comp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"component {comp} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    integrate_py = ROOT / "integrate.py"
    result = subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print("integrate.py failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


    final_report_py = ROOT / "final_report.py"
    result = subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print("final_report.py failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
