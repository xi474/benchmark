def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    schema_result = payloads[0]
    if not isinstance(schema_result, dict):
        raise ValueError("schema result must be object")
    if "name" not in schema_result or "result" not in schema_result:
        raise ValueError("schema result missing name/result")
    inner = schema_result["result"]
    flags = inner.get("flags", [])
    segments_list = inner.get("segments", [])
    segment_ids = set()
    for seg in segments_list:
        segment_ids.add(seg["id"])
    sorted_flags = sorted(flags, key=lambda f: f["id"])
    for flag in sorted_flags:
        flag_id = flag["id"]
        variant_ids = set(v["id"] for v in flag.get("variants", []))
        sorted_rules = sorted(flag.get("rules", []), key=lambda r: r["id"])
        for rule in sorted_rules:
            target_seg = rule["segment"]
            if target_seg not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": flag_id,
                            "rule": rule["id"],
                            "target": target_seg,
                        },
                    },
                }
            target_var = rule["variant"]
            if target_var not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": flag_id,
                            "rule": rule["id"],
                            "target": target_var,
                        },
                    },
                }
    return {
        "name": contract["name"],
        "result": {"ok": True, "error": None},
    }
