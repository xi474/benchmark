import copy
import json


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    raw_input = payloads[0]
    schema_result = payloads[1]
    attachments_result = payloads[2]
    references_result = payloads[3]
    old_snapshot = raw_input.get("old_snapshot", {})
    ref_inner = references_result["result"]
    if not ref_inner.get("ok", False):
        return {
            "name": contract["name"],
            "result": {
                "committed": False,
                "snapshot": copy.deepcopy(old_snapshot),
                "error": copy.deepcopy(ref_inner["error"]),
                "export": None,
            },
        }
    schema_inner = schema_result["result"]
    att_inner = attachments_result["result"]
    att_map = att_inner["attachments"]
    flags_in = schema_inner["flags"]
    segments_in = schema_inner["segments"]
    sorted_flags = sorted(flags_in, key=lambda f: f["id"])
    out_flags = []
    for flag in sorted_flags:
        fid = flag["id"]
        sorted_variants = sorted(flag["variants"], key=lambda v: v["id"])
        out_variants = []
        for var in sorted_variants:
            vid = var["id"]
            att_value = att_map[fid][vid]["value"]
            out_variants.append({"id": vid, "attachment": copy.deepcopy(att_value)})
        sorted_rules = sorted(flag["rules"], key=lambda r: r["id"])
        out_rules = [copy.deepcopy(r) for r in sorted_rules]
        out_flags.append({"id": fid, "variants": out_variants, "rules": out_rules})
    sorted_segments = sorted(segments_in, key=lambda s: s["id"])
    out_segments = [copy.deepcopy(s) for s in sorted_segments]
    snapshot = {"flags": out_flags, "segments": out_segments}
    export_str = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return {
        "name": contract["name"],
        "result": {
            "committed": True,
            "snapshot": snapshot,
            "error": None,
            "export": export_str,
        },
    }
