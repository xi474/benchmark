from decimal import Decimal, ROUND_HALF_UP


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    result_data = data["result"]
    playlist = result_data["playlist"]
    tracks = result_data["tracks"]

    name = playlist["name"]
    if "\r" in name or "\n" in name:
        raise ValueError("playlist name must not contain CR/LF")

    lines = ["#EXTM3U", f"#PLAYLIST:{name}"]

    for track in tracks:
        dur = track["duration"]
        d = Decimal(str(dur)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        seconds = int(d)
        artist = track["artist"]
        title = track["title"]
        path = track["path"]
        for val in [artist, title, path]:
            if "\r" in val or "\n" in val:
                raise ValueError("track fields must not contain CR/LF")
        lines.append(f"#EXTINF:{seconds},{artist} - {title}")
        lines.append(path)

    m3u = "\n".join(lines) + "\n"
    return {"name": contract["name"], "result": {"m3u": m3u}}
