def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    tracks = data["tracks"]
    playlist = data["playlist"]
    replacement = data["replacement"]

    track_map = {}
    for t in tracks:
        tid = t["id"]
        if tid in track_map:
            raise ValueError(f"duplicate track id: {tid}")
        dur = t["duration"]
        if isinstance(dur, bool):
            raise ValueError("duration must not be bool")
        if not isinstance(dur, (int, float)):
            raise ValueError("duration must be a number")
        import math
        if math.isnan(dur) or math.isinf(dur):
            raise ValueError("duration must be finite")
        if dur < 0:
            raise ValueError("duration must be non-negative")
        track_map[tid] = t

    for rid in replacement:
        if rid not in track_map:
            raise ValueError(f"unknown replacement track id: {rid}")

    new_track_ids = list(replacement)
    total_duration = sum(track_map[rid]["duration"] for rid in new_track_ids)
    result_tracks = [track_map[rid] for rid in new_track_ids]

    result_playlist = {
        "id": playlist["id"],
        "name": playlist["name"],
        "track_ids": new_track_ids,
        "track_count": len(new_track_ids),
        "duration": total_duration,
    }

    return {"name": contract["name"], "result": {"playlist": result_playlist, "tracks": result_tracks}}
