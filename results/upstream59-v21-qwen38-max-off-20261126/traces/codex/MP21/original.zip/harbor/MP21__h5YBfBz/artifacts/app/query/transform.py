import math

VALID_FIELDS = {"id", "name", "track_count", "duration"}
VALID_OPS = {"eq", "ne", "gt", "ge", "lt", "le"}
STR_FIELDS = {"id", "name"}
NUM_FIELDS = {"track_count", "duration"}
OP_MAP = {"eq": "=", "ne": "!=", "gt": ">", "ge": ">=", "lt": "<", "le": "<="}


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    criteria = data["criteria"]
    filters = criteria["filters"]
    limit = criteria["limit"]

    if not isinstance(limit, int) or isinstance(limit, bool):
        raise ValueError("limit must be int")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be 1..100")

    sql_parts = ["SELECT id FROM playlists"]
    params = []
    where_clauses = []

    for f in filters:
        field = f["field"]
        op = f["op"]
        value = f["value"]

        if field not in VALID_FIELDS:
            raise ValueError(f"invalid field: {field}")
        if op not in VALID_OPS:
            raise ValueError(f"invalid op: {op}")

        if field in STR_FIELDS:
            if not isinstance(value, str):
                raise ValueError(f"value for {field} must be str")
            if op not in ("eq", "ne"):
                raise ValueError(f"field {field} only supports eq/ne")
        elif field in NUM_FIELDS:
            if isinstance(value, bool):
                raise ValueError("numeric value must not be bool")
            if not isinstance(value, (int, float)):
                raise ValueError(f"value for {field} must be numeric")
            if math.isnan(value) or math.isinf(value):
                raise ValueError("numeric value must be finite")
            if value < 0:
                raise ValueError("numeric value must be non-negative")

        where_clauses.append(f"{field} {OP_MAP[op]} ?")
        params.append(value)

    if where_clauses:
        sql_parts.append("WHERE " + " AND ".join(where_clauses))

    sql_parts.append("ORDER BY id LIMIT ?")
    params.append(limit)

    sql = " ".join(sql_parts)

    return {"name": contract["name"], "result": {"sql": sql, "params": params}}
