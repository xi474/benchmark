import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = (cp, c)

    built = set()

    def build(name):
        if name in built:
            return
        cp, c = contract_map[name]
        for inp in c["inputs"]:
            inp_path = ROOT / inp
            if not inp_path.exists():
                for other_name, (_, other_c) in contract_map.items():
                    if other_c["output"] == inp and other_name not in built:
                        build(other_name)
                        break
        render_script = cp.with_name("render.py")
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"component {name} failed")
        built.add(name)

    for name in contract_map:
        build(name)

    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
