import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model import load_payload
from transform import transform


def _write_output(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    path.write_text(text + "\n", encoding="utf-8")


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    out_path = root / contract["output"]
    _write_output(out_path, result)
    return result


if __name__ == "__main__":
    root = Path.cwd()
    contract_path = Path(__file__).resolve().parent / "contract.json"
    build_component(root, contract_path)
