def transform(payloads, contract):
    original_input = payloads[0]
    reader_result = payloads[1]

    valid_codes = set(original_input["language_codes"])
    records_in = reader_result["result"]["records"]

    out_records = []
    for rec in records_in:
        langs = []

        # 008 field: positions 35-37
        if "008" in rec["controls"]:
            f008 = rec["controls"]["008"]
            if len(f008) >= 38:
                code = f008[35:38].strip()
                if len(code) == 3 and code.isalpha() and code.islower() and code in valid_codes:
                    langs.append(code)

        # 041 fields: $a, $d, $h - each value split into 3-char chunks
        for field in rec["fields"]:
            if field["tag"] == "041":
                for sf in field["subfields"]:
                    if sf["code"] in ("a", "d", "h"):
                        val = sf["value"].strip()
                        if not val:
                            continue
                        if len(val) % 3 != 0:
                            raise ValueError(
                                f"041 subfield value length not multiple of 3: '{val}'"
                            )
                        for i in range(0, len(val), 3):
                            chunk = val[i:i+3]
                            if chunk in valid_codes:
                                langs.append(chunk)

        # Deduplicate and sort
        seen = set()
        unique_langs = []
        for lang in langs:
            if lang not in seen:
                seen.add(lang)
                unique_langs.append(lang)
        unique_langs.sort()

        out_records.append({
            "id": rec["id"],
            "languages": unique_langs
        })

    out_records.sort(key=lambda r: r["id"])

    return {
        "name": contract["name"],
        "result": {
            "records": out_records
        }
    }
