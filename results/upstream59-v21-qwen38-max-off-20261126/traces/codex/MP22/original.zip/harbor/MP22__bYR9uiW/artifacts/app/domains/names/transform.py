import re


def _clean_text(text):
    text = re.sub(r'\s+', ' ', text).strip()
    while text and text[-1] in ('/', ',', ':', ';'):
        text = text[:-1].rstrip()
    while text and text[0] in ('/', ',', ':', ';'):
        text = text[1:].lstrip()
    return text


def _join_subfields(field, codes):
    parts = []
    for sf in field["subfields"]:
        if sf["code"] in codes:
            parts.append(sf["value"])
    return " ".join(parts)


def transform(payloads, contract):
    reader_result = payloads[0]
    records_in = reader_result["result"]["records"]

    out_records = []
    for rec in records_in:
        # Build 880 linkage map: (base_tag, nn) -> list of 880 fields
        alt_map = {}
        for field in rec["fields"]:
            if field["tag"] == "880":
                link_val = None
                for sf in field["subfields"]:
                    if sf["code"] == "6":
                        link_val = sf["value"]
                        break
                if link_val is None:
                    continue
                # Parse "100-01" or "100-01/suffix"
                base = link_val.split("/")[0]
                m = re.match(r'^(\d{3})-(\d+)$', base)
                if not m:
                    continue
                base_tag = m.group(1)
                nn = m.group(2)
                if base_tag not in ("100", "245"):
                    continue
                key = (base_tag, nn)
                alt_map.setdefault(key, []).append(field)

        authors = []
        titles = []

        for field in rec["fields"]:
            tag = field["tag"]
            if tag == "100":
                name_raw = _join_subfields(field, ("a", "b"))
                name = _clean_text(name_raw)
                alternates = []
                link_val = None
                for sf in field["subfields"]:
                    if sf["code"] == "6":
                        link_val = sf["value"]
                        break
                if link_val:
                    base = link_val.split("/")[0]
                    m = re.match(r'^880-(\d+)$', base)
                    if m:
                        nn = m.group(1)
                        key = ("100", nn)
                        for alt_field in alt_map.get(key, []):
                            alt_name = _join_subfields(alt_field, ("a", "b"))
                            alt_clean = _clean_text(alt_name)
                            if alt_clean and alt_clean not in alternates:
                                alternates.append(alt_clean)
                alternates.sort()
                authors.append({"name": name, "alternates": alternates})
            elif tag == "245":
                title_raw = _join_subfields(field, ("a", "b"))
                title = _clean_text(title_raw)
                alternates = []
                link_val = None
                for sf in field["subfields"]:
                    if sf["code"] == "6":
                        link_val = sf["value"]
                        break
                if link_val:
                    base = link_val.split("/")[0]
                    m = re.match(r'^880-(\d+)$', base)
                    if m:
                        nn = m.group(1)
                        key = ("245", nn)
                        for alt_field in alt_map.get(key, []):
                            alt_title = _join_subfields(alt_field, ("a", "b"))
                            alt_clean = _clean_text(alt_title)
                            if alt_clean and alt_clean not in alternates:
                                alternates.append(alt_clean)
                alternates.sort()
                titles.append({"title": title, "alternates": alternates})

        out_records.append({
            "id": rec["id"],
            "authors": authors,
            "titles": titles
        })

    out_records.sort(key=lambda r: r["id"])

    return {
        "name": contract["name"],
        "result": {
            "records": out_records
        }
    }
