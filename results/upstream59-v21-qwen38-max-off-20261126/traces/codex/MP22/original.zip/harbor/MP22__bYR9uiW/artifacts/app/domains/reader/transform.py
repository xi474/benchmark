import xml.etree.ElementTree as ET
import re


def transform(payloads, contract):
    payload = payloads[0]
    xml_str = payload["xml"]
    language_codes = payload["language_codes"]

    if not isinstance(xml_str, str):
        raise ValueError("xml must be a string")
    if not isinstance(language_codes, list):
        raise ValueError("language_codes must be a list")
    for lc in language_codes:
        if not isinstance(lc, str) or len(lc) != 3 or not lc.islower() or not lc.isalpha():
            raise ValueError(f"invalid language code: {lc}")
    if len(set(language_codes)) != len(language_codes):
        raise ValueError("duplicate language codes")

    # Reject DOCTYPE/ENTITY
    if re.search(r'<!\s*(DOCTYPE|ENTITY)', xml_str, re.IGNORECASE):
        raise ValueError("DOCTYPE/ENTITY not allowed")

    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError as e:
        raise ValueError(f"bad XML: {e}") from e

    ns = ""
    tag = root.tag
    if tag.startswith("{"):
        ns = tag.split("}")[0] + "}"

    local_tag = tag[len(ns):] if ns else tag
    if local_tag not in ("collection", "record"):
        raise ValueError(f"root must be collection or record, got {local_tag}")

    def find_records(element):
        rec_tag = ns + "record"
        if local_tag == "record":
            return [element]
        return element.findall(rec_tag)

    raw_records = find_records(root)
    records = []
    seen_ids = set()

    for rec in raw_records:
        controls = {}
        fields = []
        rec_id = None

        cf_tag = ns + "controlfield"
        df_tag = ns + "datafield"
        sf_tag = ns + "subfield"

        for child in rec:
            child_local = child.tag[len(ns):] if ns and child.tag.startswith(ns) else child.tag
            if child_local == "controlfield":
                ctag = child.get("tag")
                if ctag is None or not re.match(r'^\d{3}$', ctag):
                    raise ValueError(f"controlfield tag must be 3 digits, got {ctag}")
                if ctag in controls:
                    raise ValueError(f"duplicate controlfield tag {ctag}")
                text = child.text or ""
                if ctag == "001":
                    rec_id = text.strip()
                    if not rec_id:
                        raise ValueError("empty record ID in 001")
                controls[ctag] = text
            elif child_local == "datafield":
                dtag = child.get("tag")
                if dtag is None or not re.match(r'^\d{3}$', dtag):
                    raise ValueError(f"datafield tag must be 3 digits, got {dtag}")
                subfields = []
                for sf in child:
                    sf_local = sf.tag[len(ns):] if ns and sf.tag.startswith(ns) else sf.tag
                    if sf_local != "subfield":
                        raise ValueError(f"unexpected element in datafield: {sf_local}")
                    code = sf.get("code")
                    if code is None or not re.match(r'^[a-zA-Z0-9]$', code):
                        raise ValueError(f"invalid subfield code: {code}")
                    value = sf.text or ""
                    subfields.append({"code": code, "value": value})
                fields.append({"tag": dtag, "subfields": subfields})
            else:
                raise ValueError(f"unknown element in record: {child_local}")

        if rec_id is None:
            raise ValueError("record missing 001 controlfield")
        if rec_id in seen_ids:
            raise ValueError(f"duplicate record ID: {rec_id}")
        seen_ids.add(rec_id)

        records.append({
            "id": rec_id,
            "controls": controls,
            "fields": fields
        })

    records.sort(key=lambda r: r["id"])

    return {
        "name": contract["name"],
        "result": {
            "records": records
        }
    }
