import re
from collections import Counter

TAG_CATEGORY = {
    "600": "people",
    "610": "organizations",
    "611": "meetings",
    "630": "works",
    "650": "topics",
    "651": "places",
}

CATEGORIES = ["people", "organizations", "meetings", "works", "topics", "places"]


def _clean_segment(text):
    text = re.sub(r'\s+', ' ', text).strip()
    while text and text[-1] in ('/', ',', ':', ';'):
        text = text[:-1].rstrip()
    while text and text[0] in ('/', ',', ':', ';'):
        text = text[1:].lstrip()
    return text


def transform(payloads, contract):
    reader_result = payloads[0]
    records_in = reader_result["result"]["records"]

    out_records = []
    for rec in records_in:
        # Collect headings per category
        cat_counts = {cat: Counter() for cat in CATEGORIES}

        for field in rec["fields"]:
            tag = field["tag"]
            if tag not in TAG_CATEGORY:
                continue
            category = TAG_CATEGORY[tag]

            # Main heading from $a/$b
            main_parts = []
            for sf in field["subfields"]:
                if sf["code"] in ("a", "b"):
                    main_parts.append(sf["value"])
            main_heading = _clean_segment(" ".join(main_parts))

            # Subdivisions from $v/$x/$y/$z in order of appearance
            subdivisions = []
            for sf in field["subfields"]:
                if sf["code"] in ("v", "x", "y", "z"):
                    sub_text = _clean_segment(sf["value"])
                    if sub_text:
                        subdivisions.append(sub_text)

            if main_heading:
                parts = [main_heading] + subdivisions
                full_heading = " -- ".join(parts)
                cat_counts[category][full_heading] += 1

        subjects = {}
        for cat in CATEGORIES:
            items = [{"value": v, "count": c} for v, c in cat_counts[cat].items()]
            items.sort(key=lambda x: x["value"])
            subjects[cat] = items

        out_records.append({
            "id": rec["id"],
            "subjects": subjects
        })

    out_records.sort(key=lambda r: r["id"])

    return {
        "name": contract["name"],
        "result": {
            "records": out_records
        }
    }
