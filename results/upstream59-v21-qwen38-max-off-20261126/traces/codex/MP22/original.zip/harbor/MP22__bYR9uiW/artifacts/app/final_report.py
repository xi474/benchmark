import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core["components"]

    # Compute sha256 of the canonical serialization of the full core object
    canonical = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    sha256_hex = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    # Determine attention list
    attention = []
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        flagged = False
        # blocked explicitly true
        if result.get("blocked") is True:
            flagged = True
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                flagged = True
                break
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None:
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    flagged = True
                    break
                elif isinstance(val, bool):
                    pass
                elif isinstance(val, (int, float)):
                    pass
        if flagged:
            attention.append(comp_name)

    attention.sort()

    report = {
        "title": "MARC \u4f5c\u8005\u6807\u9898\u3001\u8bed\u8a00\u548c\u4e3b\u9898\u5bfc\u5165",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": attention,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
