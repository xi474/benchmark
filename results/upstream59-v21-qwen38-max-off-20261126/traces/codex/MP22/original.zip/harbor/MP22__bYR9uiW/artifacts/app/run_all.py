import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Component execution order based on dependencies
COMPONENTS = [
    "domains/reader",
    "domains/names",
    "domains/languages",
    "domains/subjects",
    "views/catalog",
]


def main():
    for comp in COMPONENTS:
        render_script = ROOT / comp / "render.py"
        if not render_script.is_file():
            print(f"Missing render.py for {comp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {comp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py to produce core_manifest.json
    integrate_script = ROOT / "integrate.py"
    result = subprocess.run(
        [sys.executable, str(integrate_script)],
        cwd=str(ROOT),
        timeout=60,
    )
    if result.returncode != 0:
        print("integrate.py failed", file=sys.stderr)
        sys.exit(result.returncode)

    # Run final_report.py
    report_script = ROOT / "final_report.py"
    result = subprocess.run(
        [sys.executable, str(report_script)],
        cwd=str(ROOT),
        timeout=60,
    )
    if result.returncode != 0:
        print("final_report.py failed", file=sys.stderr)
        sys.exit(result.returncode)


if __name__ == "__main__":
    main()
