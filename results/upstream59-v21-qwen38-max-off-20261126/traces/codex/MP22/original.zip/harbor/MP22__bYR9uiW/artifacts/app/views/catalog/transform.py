def transform(payloads, contract):
    names_result = payloads[0]
    languages_result = payloads[1]
    subjects_result = payloads[2]

    names_records = {r["id"]: r for r in names_result["result"]["records"]}
    languages_records = {r["id"]: r for r in languages_result["result"]["records"]}
    subjects_records = {r["id"]: r for r in subjects_result["result"]["records"]}

    ids_names = set(names_records.keys())
    ids_languages = set(languages_records.keys())
    ids_subjects = set(subjects_records.keys())

    if ids_names != ids_languages or ids_names != ids_subjects:
        raise ValueError("record ID sets differ across inputs")

    all_ids = sorted(ids_names)
    records = []
    for rid in all_ids:
        nr = names_records[rid]
        lr = languages_records[rid]
        sr = subjects_records[rid]
        records.append({
            "id": rid,
            "authors": nr["authors"],
            "titles": nr["titles"],
            "languages": lr["languages"],
            "subjects": sr["subjects"]
        })

    return {
        "name": contract["name"],
        "result": {
            "records": records,
            "record_count": len(records)
        }
    }
