import json, sys
from pathlib import Path

def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    payloads = []
    for inp in contract['inputs']:
        p = root / inp
        text = p.read_text(encoding='utf-8')
        payloads.append(json.loads(text))
    from transform import transform
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__ == "__main__":
    cp = Path(__file__).resolve().with_name('contract.json')
    root = cp.parents[2]
    build_component(root, cp)
