import hashlib

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    files = case['files']
    max_file_bytes = case['max_file_bytes']
    max_entries = case['max_entries']
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("invalid max_file_bytes")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("invalid max_entries")

    sorted_files = sorted(files, key=lambda f: f['path'])
    all_chunks = []
    manifest_files = []
    global_chunk_idx = 0

    for finfo in sorted_files:
        path = finfo['path']
        raw = bytes.fromhex(finfo['hex'])
        size = len(raw)
        sha = hashlib.sha256(raw).hexdigest()
        parts = []
        if size == 0:
            pass
        else:
            offset = 0
            while offset < size:
                end = min(offset + max_file_bytes, size)
                chunk_data = raw[offset:end]
                chunk_name = "d{:07d}.bin".format(global_chunk_idx)
                all_chunks.append({"name": chunk_name, "hex": chunk_data.hex()})
                parts.append(chunk_name)
                global_chunk_idx += 1
                offset = end
        manifest_files.append({
            "path": path,
            "size": size,
            "sha256": sha,
            "parts": parts
        })

    result = {
        "chunks": all_chunks,
        "manifest": {
            "files": manifest_files
        }
    }
    return {"name": contract["name"], "result": result}
