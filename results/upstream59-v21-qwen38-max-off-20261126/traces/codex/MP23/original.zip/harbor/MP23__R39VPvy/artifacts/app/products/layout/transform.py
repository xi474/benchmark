import json, math

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    chunks_result = payloads[1]['result']
    max_file_bytes = case['max_file_bytes']
    max_entries = case['max_entries']

    manifest = chunks_result['manifest']
    manifest_json = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    manifest_bytes = manifest_json.encode('utf-8')

    meta_chunks = []
    idx = 0
    offset = 0
    while offset < len(manifest_bytes):
        end = min(offset + max_file_bytes, len(manifest_bytes))
        chunk_data = manifest_bytes[offset:end]
        name = "m{:06d}.bin".format(idx)
        meta_chunks.append({"name": name, "hex": chunk_data.hex()})
        idx += 1
        offset = end

    data_chunks = chunks_result['chunks']
    all_items = data_chunks + meta_chunks
    all_items.sort(key=lambda x: x['name'])
    n = len(all_items)

    if n == 0:
        h = 1
    else:
        h = 1
        while max_entries ** h < n:
            h += 1

    tree_files = []
    for i, item in enumerate(all_items):
        digits = []
        val = i
        for _ in range(h):
            digits.append(val % max_entries)
            val //= max_entries
        dir_parts = []
        for d_idx in range(h - 1):
            digit = digits[h - 2 - d_idx]
            dir_parts.append("n{}".format(digit))
        if dir_parts:
            file_path = "/".join(dir_parts) + "/" + item['name']
        else:
            file_path = item['name']
        tree_files.append({"path": file_path, "hex": item['hex']})

    tree_files.sort(key=lambda x: x['path'])

    result = {
        "tree": tree_files,
        "max_entries": max_entries,
        "max_file_bytes": max_file_bytes
    }
    return {"name": contract["name"], "result": result}
