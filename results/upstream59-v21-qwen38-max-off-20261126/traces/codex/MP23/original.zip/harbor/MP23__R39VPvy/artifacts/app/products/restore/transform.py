import hashlib, json, re

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    layout = payloads[0]['result']
    tree = layout['tree']
    max_file_bytes = layout['max_file_bytes']
    max_entries = layout['max_entries']

    # Validate file sizes
    for entry in tree:
        raw = bytes.fromhex(entry['hex'])
        if len(raw) > max_file_bytes:
            raise ValueError("file exceeds max_file_bytes")

    # Validate directory entry counts and basenames
    dir_children = {}
    basenames_seen = set()
    for entry in tree:
        path = entry['path']
        parts = path.split('/')
        basename = parts[-1]
        if not (re.match(r'^m\d+\.bin$', basename) or re.match(r'^d\d+\.bin$', basename)):
            raise ValueError("invalid basename: " + basename)
        if basename in basenames_seen:
            raise ValueError("duplicate basename: " + basename)
        basenames_seen.add(basename)
        parent = '/'.join(parts[:-1]) if len(parts) > 1 else ''
        if parent not in dir_children:
            dir_children[parent] = set()
        dir_children[parent].add(basename)
        # Register intermediate directories as children of their parents
        for i in range(1, len(parts)):
            ancestor = '/'.join(parts[:i])
            grandparent = '/'.join(parts[:i-1]) if i > 1 else ''
            dirname = parts[i-1]
            if grandparent not in dir_children:
                dir_children[grandparent] = set()
            dir_children[grandparent].add(dirname)

    for parent, children in dir_children.items():
        if len(children) > max_entries:
            raise ValueError("directory exceeds max_entries")

    # Separate m-blocks and d-blocks
    m_blocks = {}
    d_blocks = {}
    for entry in tree:
        basename = entry['path'].split('/')[-1]
        if basename.startswith('m'):
            m_blocks[basename] = bytes.fromhex(entry['hex'])
        else:
            d_blocks[basename] = bytes.fromhex(entry['hex'])

    # Verify m-blocks are consecutive from 0
    m_names = sorted(m_blocks.keys())
    for i, name in enumerate(m_names):
        expected = "m{:06d}.bin".format(i)
        if name != expected:
            raise ValueError("non-consecutive m-block: " + name)

    # Concatenate m-blocks and parse manifest
    manifest_bytes = b''.join(m_blocks[n] for n in m_names)
    manifest = json.loads(manifest_bytes.decode('utf-8'))

    # Restore files
    referenced_d = set()
    restored_files = []
    for finfo in manifest['files']:
        path = finfo['path']
        size = finfo['size']
        sha = finfo['sha256']
        parts = finfo['parts']
        data = b''
        for part_name in parts:
            if part_name not in d_blocks:
                raise ValueError("missing d-block: " + part_name)
            if part_name in referenced_d:
                raise ValueError("duplicate d-block reference: " + part_name)
            referenced_d.add(part_name)
            data += d_blocks[part_name]
        if len(data) != size:
            raise ValueError("size mismatch for " + path)
        if hashlib.sha256(data).hexdigest() != sha:
            raise ValueError("sha256 mismatch for " + path)
        restored_files.append({"path": path, "hex": data.hex()})

    # Check no extra d-blocks
    if referenced_d != set(d_blocks.keys()):
        extra = set(d_blocks.keys()) - referenced_d
        raise ValueError("extra d-blocks: " + str(extra))

    restored_files.sort(key=lambda x: x['path'])
    total_bytes = sum(len(bytes.fromhex(f['hex'])) for f in restored_files)

    result = {
        "files": restored_files,
        "total_bytes": total_bytes
    }
    return {"name": contract["name"], "result": result}
