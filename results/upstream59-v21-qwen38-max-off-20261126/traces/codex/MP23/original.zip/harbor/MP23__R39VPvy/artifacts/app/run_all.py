import subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    components = [
        ROOT / 'products' / 'chunks',
        ROOT / 'products' / 'layout',
        ROOT / 'products' / 'restore',
    ]
    for comp_dir in components:
        render_py = comp_dir / 'render.py'
        if not render_py.exists():
            print("Missing render.py in", comp_dir, file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(comp_dir),
            timeout=60
        )
        if result.returncode != 0:
            print("Component failed:", comp_dir.name, file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate
    result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=str(ROOT),
        timeout=60
    )
    if result.returncode != 0:
        print("Integration failed", file=sys.stderr)
        sys.exit(result.returncode)

    # Run final_report
    result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=str(ROOT),
        timeout=60
    )
    if result.returncode != 0:
        print("Final report failed", file=sys.stderr)
        sys.exit(result.returncode)

if __name__ == '__main__':
    main()
