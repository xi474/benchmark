def transform(payloads, contract):
    case = payloads[0]
    departments = {d['id']: d for d in case['departments']}
    countries_map = {}
    for prof in case['professors']:
        dept_ids = set(prof['departments'])
        cset = set()
        for d in dept_ids:
            cset.add(departments[d]['country'])
        countries_map[prof['id']] = sorted(cset)
    return {"name": contract["name"], "result": {"countries": countries_map}}
