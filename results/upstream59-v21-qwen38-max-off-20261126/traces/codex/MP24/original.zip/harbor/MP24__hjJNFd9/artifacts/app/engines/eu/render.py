import json
import sys
from pathlib import Path

_here = Path(__file__).resolve().parent
_root = _here.parents[1]
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))
if str(_here) not in sys.path:
    sys.path.insert(0, str(_here))

from model import load_payload
from transform import transform

def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__ == "__main__":
    import sys
    cp = Path(__file__).resolve().with_name('contract.json')
    root = cp.resolve().parents[2]
    build_component(root, cp)
