def transform(payloads, contract):
    case = payloads[0]
    departments = {d['id']: d for d in case['departments']}
    eu_set = set(case['eu'])
    result_ids = []
    for prof in case['professors']:
        dept_ids = set(prof['departments'])
        if any(departments[d]['country'] in eu_set for d in dept_ids):
            result_ids.append(prof['id'])
    result_ids.sort()
    return {"name": contract["name"], "result": {"ids": result_ids}}
