def transform(payloads, contract):
    case = payloads[0]
    eu_result = payloads[1]['result']
    students_result = payloads[2]['result']
    countries_result = payloads[3]['result']
    eu_ids = set(eu_result['ids'])
    counts = students_result['counts']
    countries_map = countries_result['countries']
    professors = []
    for prof_id in sorted(eu_ids):
        eligible = []
        for dept in case['professors']:
            if dept['id'] == prof_id:
                for d in set(dept['departments']):
                    if counts.get(d, 0) > 10:
                        eligible.append(d)
                break
        if eligible:
            eligible.sort()
            professors.append({
                "id": prof_id,
                "countries": countries_map.get(prof_id, []),
                "eligible_departments": eligible
            })
    return {"name": contract["name"], "result": {"professors": professors}}
