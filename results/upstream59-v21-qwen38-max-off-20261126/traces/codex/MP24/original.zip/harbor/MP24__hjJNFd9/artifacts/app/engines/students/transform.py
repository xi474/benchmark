def transform(payloads, contract):
    case = payloads[0]
    as_of = case['as_of']
    counts = {}
    for dept in case['departments']:
        counts[dept['id']] = 0
    for student in case['students']:
        seen_depts = set()
        for enr in student['enrolments']:
            dept_id = enr['department']
            start = enr['start']
            end = enr['end']
            if start > as_of:
                continue
            if end is not None and as_of >= end:
                continue
            if dept_id not in seen_depts:
                seen_depts.add(dept_id)
                counts[dept_id] = counts.get(dept_id, 0) + 1
    return {"name": contract["name"], "result": {"counts": counts}}
