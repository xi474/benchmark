import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    title = '大学任职、在读人数与国家集合查询'
    component_count = len(core['components'])

    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    attention = []
    for name, result in core['components'].items():
        if not isinstance(result, dict):
            continue
        flagged = False
        if result.get('blocked') is True:
            flagged = True
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                flagged = True
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict)) and len(val) > 0:
                    flagged = True
                elif isinstance(val, str) and len(val) > 0:
                    flagged = True
        if flagged:
            attention.append(name)
    attention.sort()

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out = ROOT / 'outputs' / 'final_report.json'
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

if __name__ == '__main__':
    main()
