import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    order = []
    done = set()
    def resolve(cp):
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        if name in done:
            return
        for inp in c['inputs']:
            inp_path = ROOT / inp
            for other_cp in contracts:
                other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                if str(ROOT / other_c['output']) == str(inp_path):
                    resolve(other_cp)
        order.append(cp)
        done.add(name)

    for cp in contracts:
        resolve(cp)

    for cp in order:
        render_py = cp.with_name('render.py')
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            sys.exit(result.returncode)

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True)

if __name__ == '__main__':
    main()
