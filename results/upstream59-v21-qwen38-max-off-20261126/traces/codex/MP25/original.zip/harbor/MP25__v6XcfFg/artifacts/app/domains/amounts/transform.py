import re
from decimal import Decimal, InvalidOperation

def _parse_amount(raw):
    s = raw.strip()
    if s.upper().startswith('USD'):
        s = s[3:].strip()
    s = s.replace(',', '')
    try:
        d = Decimal(s)
    except InvalidOperation:
        return None
    if d < 0:
        return None
    parts = s.split('.')
    if len(parts) != 2 or len(parts[1]) != 2:
        return None
    return str(d.quantize(Decimal('0.01')))

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    documents = payloads[0]
    if not isinstance(documents, dict) or 'documents' not in documents:
        raise ValueError("missing documents field")
    docs = documents['documents']
    amounts = {}
    for doc in docs:
        did = doc['id']
        text = doc['text']
        total_val = None
        vat_val = None
        seen_total = False
        seen_amount_due = False
        seen_vat = False
        for line in text.splitlines():
            stripped = line.strip()
            lower = stripped.lower()
            m_total = re.match(r'^total:\s*(.+)$', stripped, re.IGNORECASE)
            m_amount = re.match(r'^amount\s+due:\s*(.+)$', stripped, re.IGNORECASE)
            m_vat = re.match(r'^vat:\s*(.+)$', stripped, re.IGNORECASE)
            if m_total:
                if seen_total:
                    raise ValueError(f"duplicate Total for {did}")
                seen_total = True
                parsed = _parse_amount(m_total.group(1))
                if parsed is None:
                    raise ValueError(f"invalid Total amount for {did}")
                total_val = parsed
            elif m_amount:
                if seen_amount_due:
                    raise ValueError(f"duplicate Amount Due for {did}")
                seen_amount_due = True
                parsed = _parse_amount(m_amount.group(1))
                if parsed is None:
                    raise ValueError(f"invalid Amount Due amount for {did}")
                if total_val is None:
                    total_val = parsed
            elif m_vat:
                if seen_vat:
                    raise ValueError(f"duplicate VAT for {did}")
                seen_vat = True
                parsed = _parse_amount(m_vat.group(1))
                if parsed is None:
                    raise ValueError(f"invalid VAT amount for {did}")
                vat_val = parsed
        if vat_val is None:
            vat_val = "0.00"
        amounts[did] = {"total": total_val, "vat": vat_val}
    return {"name": contract["name"], "result": {"amounts": amounts}}
