import re

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    documents = payloads[0]
    if not isinstance(documents, dict) or 'documents' not in documents:
        raise ValueError("missing documents field")
    docs = documents['documents']
    seen_ids = set()
    classes = {}
    for doc in docs:
        did = doc['id']
        if did in seen_ids:
            raise ValueError(f"duplicate id: {did}")
        seen_ids.add(did)
        text = doc['text']
        words = set(re.findall(r'[A-Za-z]+', text))
        words_lower = {w.lower() for w in words}
        if 'invoice' in words_lower:
            kind = 'invoice'
        elif 'receipt' in words_lower:
            kind = 'receipt'
        else:
            kind = 'other'
        classes[did] = kind
    return {"name": contract["name"], "result": {"classes": classes}}
