import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = (cp, c)
    resolved = set()
    order = []
    def resolve(name):
        if name in resolved:
            return
        cp, c = contract_map[name]
        for inp in c['inputs']:
            for other_name, (other_cp, other_c) in contract_map.items():
                if other_c['output'] == inp:
                    resolve(other_name)
        resolved.add(name)
        order.append((cp, c))
    for name in contract_map:
        resolve(name)
    for cp, c in order:
        comp_dir = cp.parent
        render_py = comp_dir / 'render.py'
        if not render_py.is_file():
            print(f"missing render.py in {comp_dir}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(comp_dir),
            timeout=60
        )
        if result.returncode != 0:
            print(f"component {c['name']} failed", file=sys.stderr)
            sys.exit(1)
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=str(ROOT), check=True, timeout=30)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=str(ROOT), check=True, timeout=30)

if __name__ == '__main__':
    main()
