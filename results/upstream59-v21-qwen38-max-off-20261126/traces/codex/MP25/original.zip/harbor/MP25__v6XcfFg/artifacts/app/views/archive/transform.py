import csv
import io
from decimal import Decimal

def _is_safe_segment(s):
    if not s or not isinstance(s, str):
        return False
    if '\\' in s or ':' in s:
        return False
    parts = s.split('/')
    for p in parts:
        if not p or p == '.' or p == '..':
            return False
    return True

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    documents_data = payloads[0]
    classification_data = payloads[1]
    amounts_data = payloads[2]
    docs = documents_data['documents']
    classes = classification_data['result']['classes']
    amounts = amounts_data['result']['amounts']
    archives = []
    rows = []
    for doc in docs:
        did = doc['id']
        filename = doc['filename']
        text = doc['text']
        kind = classes[did]
        amt = amounts[did]
        total = amt['total']
        vat = amt['vat']
        if kind in ('invoice', 'receipt') and total is None:
            raise ValueError(f"{kind} document {did} must have total")
        if not _is_safe_segment(did):
            raise ValueError(f"unsafe id segment: {did}")
        archive_path = f"classified/{kind}/{did}/{filename}"
        hex_bytes = text.encode('utf-8').hex()
        archives.append({"path": archive_path, "hex": hex_bytes})
        rows.append({"id": did, "filename": filename, "kind": kind, "total": total, "vat": vat})
    archives.sort(key=lambda x: x['path'])
    rows.sort(key=lambda x: x['id'])
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator='\n')
    writer.writerow(['id', 'filename', 'kind', 'total', 'vat'])
    for r in rows:
        writer.writerow([r['id'], r['filename'], r['kind'], r['total'] if r['total'] is not None else '', r['vat']])
    csv_str = buf.getvalue()
    totals = {}
    invoice_sum = Decimal('0.00')
    receipt_sum = Decimal('0.00')
    for r in rows:
        if r['kind'] == 'invoice' and r['total'] is not None:
            invoice_sum += Decimal(r['total'])
        elif r['kind'] == 'receipt' and r['total'] is not None:
            receipt_sum += Decimal(r['total'])
    totals['invoice'] = str(invoice_sum.quantize(Decimal('0.01')))
    totals['receipt'] = str(receipt_sum.quantize(Decimal('0.01')))
    result = {
        "archives": archives,
        "rows": rows,
        "csv": csv_str,
        "totals": totals
    }
    return {"name": contract["name"], "result": result}
