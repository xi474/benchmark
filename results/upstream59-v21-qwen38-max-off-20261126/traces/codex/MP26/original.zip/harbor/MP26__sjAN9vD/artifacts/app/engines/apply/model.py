def load_payload(path):
    import json, math
    from pathlib import Path
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    def _check(obj):
        if isinstance(obj, float):
            if math.isnan(obj) or math.isinf(obj):
                raise ValueError("non-finite number")
        elif isinstance(obj, dict):
            for v in obj.values():
                _check(v)
        elif isinstance(obj, list):
            for v in obj:
                _check(v)
    _check(data)
    return data
