def build_component(root,contract_path):
    import json
    from pathlib import Path
    root = Path(root)
    contract_path = Path(contract_path)
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    from model import load_payload
    payloads = [load_payload(root / p) for p in contract['inputs']]
    from transform import transform
    result = transform(payloads, contract)
    return result

if __name__=="__main__":
    import json, sys
    from pathlib import Path
    cp = Path(__file__).resolve().with_name('contract.json')
    root = cp.parents[2]
    result = build_component(root, cp)
    contract = json.loads(cp.read_text(encoding='utf-8'))
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')
