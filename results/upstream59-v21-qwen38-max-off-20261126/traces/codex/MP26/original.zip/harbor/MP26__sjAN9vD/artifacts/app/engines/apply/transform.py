def transform(payloads,contract):
    def _unwrap(p):
        if isinstance(p, dict) and set(p.keys()) == {'name', 'result'}:
            return p['result']
        return p
    calendar_result = _unwrap(payloads[0])
    plan_result = _unwrap(payloads[1])
    notifications_result = _unwrap(payloads[2])
    old_events = calendar_result['events']
    cancelled_set = set(plan_result['cancelled'])
    added = plan_result['added']
    # Remove cancelled events from old events
    remaining = [ev for ev in old_events if ev['id'] not in cancelled_set]
    # Add new events
    final_events = remaining + list(added)
    # Sort by id
    final_events.sort(key=lambda e: e['id'])
    return {"name": contract["name"], "result": {"events": final_events, "outbox": notifications_result['outbox']}}
