def transform(payloads,contract):
    from datetime import datetime
    case = payloads[0]
    events = case['events']
    contacts = set(case['contacts'])
    # Validate
    seen_ids = set()
    for ev in events:
        eid = ev['id']
        if eid in seen_ids:
            raise ValueError(f"duplicate event id: {eid}")
        seen_ids.add(eid)
        start = datetime.strptime(ev['start'], '%Y-%m-%dT%H:%M')
        end = datetime.strptime(ev['end'], '%Y-%m-%dT%H:%M')
        if end <= start:
            raise ValueError(f"end must be > start for event {eid}")
        if not ev['kind']:
            raise ValueError(f"empty kind for event {eid}")
        for a in ev['attendees']:
            if a not in contacts:
                raise ValueError(f"attendee {a} not in contacts")
    # Deduplicate attendees and sort
    deduped_events = []
    for ev in events:
        new_ev = dict(ev)
        # deduplicate attendees preserving order then sort
        seen = set()
        unique = []
        for a in ev['attendees']:
            if a not in seen:
                seen.add(a)
                unique.append(a)
        unique.sort()
        new_ev['attendees'] = unique
        deduped_events.append(new_ev)
    # Sort events by id
    deduped_events.sort(key=lambda e: e['id'])
    # Find existing dinners: start at 19:00, kind=dinner, end <= 20:00 same day
    existing_dinners = set()
    for ev in deduped_events:
        if ev['kind'] == 'dinner':
            start = datetime.strptime(ev['start'], '%Y-%m-%dT%H:%M')
            end = datetime.strptime(ev['end'], '%Y-%m-%dT%H:%M')
            if start.hour == 19 and start.minute == 0:
                # Must end on same day at or before 20:00
                end_limit = start.replace(hour=20, minute=0)
                if end <= end_limit:
                    existing_dinners.add(start.strftime('%Y-%m-%d'))
    existing_dinners_sorted = sorted(existing_dinners)
    return {"name": contract["name"], "result": {"events": deduped_events, "existing_dinners": existing_dinners_sorted}}
