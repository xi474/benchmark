def transform(payloads,contract):
    from datetime import datetime, timedelta
    case = payloads[0]
    today_str = case['today']
    today = datetime.strptime(today_str, '%Y-%m-%d').date()
    # Find next Friday (Monday=0 ... Sunday=6; Friday=4)
    # "from today to next natural week Friday, both inclusive"
    # Monday is week start. Next natural week Friday means the Friday of the current or next week.
    # If today is Mon-Fri, the Friday of this week. If today is Sat/Sun, next week's Friday.
    weekday = today.weekday()  # 0=Mon
    if weekday <= 4:
        # Mon-Fri: Friday of this week
        days_to_friday = 4 - weekday
    else:
        # Sat(5): next Friday is +6, Sun(6): next Friday is +5
        days_to_friday = 4 + (7 - weekday)
    end_date = today + timedelta(days=days_to_friday)
    dates = []
    d = today
    while d <= end_date:
        dates.append(d.strftime('%Y-%m-%d'))
        d += timedelta(days=1)
    return {"name": contract["name"], "result": {"dates": dates}}
