def transform(payloads,contract):
    def _unwrap(p):
        if isinstance(p, dict) and set(p.keys()) == {'name', 'result'}:
            return p['result']
        return p
    plan_result = _unwrap(payloads[0])
    snapshots = plan_result['snapshots']
    # For each cancelled event snapshot, notify each attendee
    contact_events = {}
    for ev in snapshots:
        for attendee in ev['attendees']:
            if attendee not in contact_events:
                contact_events[attendee] = set()
            contact_events[attendee].add(ev['id'])
    outbox = []
    for to_id in sorted(contact_events.keys()):
        event_ids = sorted(contact_events[to_id])
        outbox.append({"to": to_id, "event_ids": event_ids})
    return {"name": contract["name"], "result": {"outbox": outbox}}
