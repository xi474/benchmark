def transform(payloads,contract):
    from datetime import datetime
    def _unwrap(p):
        if isinstance(p, dict) and set(p.keys()) == {'name', 'result'}:
            return p['result']
        return p
    dates_result = _unwrap(payloads[0])
    calendar_result = _unwrap(payloads[1])
    all_dates = dates_result['dates']
    existing_dinners = set(calendar_result['existing_dinners'])
    old_events = calendar_result['events']
    # New dinner reminders for dates not in existing_dinners
    added = []
    new_ids = set()
    for d in all_dates:
        if d not in existing_dinners:
            new_id = f"dinner-{d}"
            # Check no conflict with old event IDs
            for ev in old_events:
                if ev['id'] == new_id:
                    raise ValueError(f"new ID {new_id} conflicts with old event")
            new_ids.add(new_id)
            added.append({
                "id": new_id,
                "start": f"{d}T19:00",
                "end": f"{d}T20:00",
                "kind": "dinner",
                "attendees": []
            })
    added.sort(key=lambda e: e['start'])
    # Cancel old events that intersect with any new reminder's half-open interval [19:00, 20:00)
    # An old event intersects if its [start, end) overlaps with any new [19:00, 20:00)
    # "恰19点结束不冲突" means ending exactly at 19:00 is not a conflict
    cancelled_ids = set()
    snapshots = []
    for ev in old_events:
        ev_start = datetime.strptime(ev['start'], '%Y-%m-%dT%H:%M')
        ev_end = datetime.strptime(ev['end'], '%Y-%m-%dT%H:%M')
        for new_ev in added:
            new_start = datetime.strptime(new_ev['start'], '%Y-%m-%dT%H:%M')
            new_end = datetime.strptime(new_ev['end'], '%Y-%m-%dT%H:%M')
            # Half-open intersection: [ev_start, ev_end) ∩ [new_start, new_end)
            if ev_start < new_end and ev_end > new_start:
                cancelled_ids.add(ev['id'])
                break
    cancelled_sorted = sorted(cancelled_ids)
    for ev in old_events:
        if ev['id'] in cancelled_ids:
            snapshots.append(dict(ev))
    snapshots.sort(key=lambda e: e['id'])
    return {"name": contract["name"], "result": {"added": added, "cancelled": cancelled_sorted, "snapshots": snapshots}}
