import json, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    components = core['components']
    # sha256 of the full core object serialized compactly
    canonical = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode('utf-8')
    sha = hashlib.sha256(canonical).hexdigest()
    # attention: components matching any condition
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get('blocked') is True:
            attention.add(name)
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            if key in result and isinstance(result[key], (list, dict)) and len(result[key]) > 0:
                attention.add(name)
            elif key in result and isinstance(result[key], str) and len(result[key]) > 0:
                attention.add(name)
    report = {
        "title": "每日晚餐提醒的去重、冲突取消与通知",
        "component_count": len(components),
        "sha256": sha,
        "attention": sorted(attention)
    }
    out = ROOT / 'outputs' / 'final_report.json'
    out.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')

if __name__ == '__main__':
    main()
