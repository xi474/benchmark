import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

ORDER = ['dates', 'calendar', 'plan', 'notifications', 'apply']

def main():
    for name in ORDER:
        render_py = ROOT / 'engines' / name / 'render.py'
        if not render_py.is_file():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed", file=sys.stderr)
            sys.exit(result.returncode)
    integrate = ROOT / 'integrate.py'
    result = subprocess.run(
        [sys.executable, str(integrate)],
        cwd=ROOT,
        timeout=60
    )
    if result.returncode != 0:
        print("integrate.py failed", file=sys.stderr)
        sys.exit(result.returncode)
    final_report = ROOT / 'final_report.py'
    result = subprocess.run(
        [sys.executable, str(final_report)],
        cwd=ROOT,
        timeout=60
    )
    if result.returncode != 0:
        print("final_report.py failed", file=sys.stderr)
        sys.exit(result.returncode)

if __name__ == '__main__':
    main()
