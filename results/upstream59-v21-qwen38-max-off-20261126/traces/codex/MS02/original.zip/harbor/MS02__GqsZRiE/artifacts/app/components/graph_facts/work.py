def compute(payload):
    """返回去重并按三元组字典序排列的已有图事实。"""
    edges = payload.get("graph", [])
    seen = set()
    unique = []
    for edge in edges:
        key = (edge[0], edge[1], edge[2])
        if key not in seen:
            seen.add(key)
            unique.append(edge)
    unique.sort(key=lambda e: (e[0], e[1], e[2]))
    return unique
