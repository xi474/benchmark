def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    topics = payload["topics"]
    scores_table = left  # list of dicts, one per topic
    existing_graph = right  # sorted deduplicated edge list

    num_topics = len(topics)
    if num_topics == 0:
        return {"review": [], "graph": existing_graph}

    # Build candidate lists per topic: (paper_id, quality)
    candidates = []
    for i, topic in enumerate(topics):
        score_map = scores_table[i]
        cands = [(pid, q) for pid, q in score_map.items()]
        if not cands:
            return None
        candidates.append(cands)

    # Solve: maximize min quality, then total quality, then lex-smallest paper ID sequence
    # Use backtracking with pruning
    best = [None]  # best[0] = (min_q, total_q, paper_ids_tuple)

    def solve(idx, used, current_min, current_total, assignment):
        if idx == num_topics:
            key = (current_min, current_total, tuple(assignment))
            if best[0] is None or _better(current_min, current_total, assignment, best[0]):
                best[0] = (current_min, current_total, tuple(assignment))
            return
        # Upper bound on remaining min: can't exceed current_min
        # Prune: if we already have a best and current path can't beat it
        if best[0] is not None:
            b_min, b_total, b_ids = best[0]
            # If current_min already < best min, prune only if no chance to recover
            # Actually current_min can only stay same or decrease, so if current_min < b_min, prune
            if current_min < b_min:
                return
            # If current_min == b_min, check if remaining topics could improve total enough
            # For simplicity, just continue

        cands = candidates[idx]
        # Sort candidates: prefer higher quality first, then lex paper id for tie-breaking
        sorted_cands = sorted(cands, key=lambda x: (-x[1], x[0]))
        for pid, q in sorted_cands:
            if pid in used:
                continue
            new_min = min(current_min, q) if current_min is not None else q
            new_total = current_total + q
            # Pruning
            if best[0] is not None:
                b_min = best[0][0]
                if new_min < b_min:
                    continue
            used.add(pid)
            assignment.append(pid)
            solve(idx + 1, used, new_min, new_total, assignment)
            assignment.pop()
            used.remove(pid)

    def _better(cur_min, cur_total, assignment, best_tuple):
        b_min, b_total, b_ids = best_tuple
        if cur_min != b_min:
            return cur_min > b_min
        if cur_total != b_total:
            return cur_total > b_total
        return tuple(assignment) < b_ids

    solve(0, set(), None, 0, [])

    if best[0] is None:
        return None

    _, _, paper_ids = best[0]
    review = []
    new_edges = list(existing_graph)
    for i, topic in enumerate(topics):
        pid = paper_ids[i]
        q = scores_table[i][pid]
        review.append([topic, pid, q])
        new_edges.append([pid, "supports", topic])

    # Deduplicate and sort graph
    seen = set()
    unique_edges = []
    for e in new_edges:
        key = (e[0], e[1], e[2])
        if key not in seen:
            seen.add(key)
            unique_edges.append(e)
    unique_edges.sort(key=lambda e: (e[0], e[1], e[2]))

    return {"review": review, "graph": unique_edges}
