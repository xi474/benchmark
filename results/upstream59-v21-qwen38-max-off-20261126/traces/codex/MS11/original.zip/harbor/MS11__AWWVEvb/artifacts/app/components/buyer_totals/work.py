def compute(payload):
    """按买家 ID 汇总属于 Cameras 或 Electronics 的行金额，每行只计一次；无购买为零。"""
    buyers = payload["buyers"]
    orders = payload["orders"]
    totals = {b: 0 for b in buyers}
    for order in orders:
        buyer = order["buyer"]
        for line in order["lines"]:
            categories, qty, unit_price = line[0], line[1], line[2]
            if "Electronics" in categories or "Cameras" in categories:
                totals[buyer] += qty * unit_price
    return totals
