def compute(payload):
    """按学生 ID 输出课程 1、2 非空成绩的百分制整型均值（sum×100 整除数量）。"""
    grades = payload["grades"]
    from collections import defaultdict
    accum = defaultdict(lambda: [0, 0])
    for row in grades:
        student, course, score = row[0], row[1], row[2]
        if course not in (1, 2) or score is None:
            continue
        accum[student][0] += score
        accum[student][1] += 1
    result = {}
    for student, (total, count) in accum.items():
        result[student] = (total * 100) // count
    return result
