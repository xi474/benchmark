def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    students = payload["students"]
    buyers = payload["buyers"]
    evidence = payload["evidence"]
    drop_list = payload["drop"]
    scores = left   # dict student -> int score X
    totals = right  # dict buyer -> int total Y

    def solve(ev_rows):
        # Build confidence map: (student, buyer) -> confidence
        # Per source, keep max; then sum across sources
        from collections import defaultdict
        source_max = {}  # (source, student, buyer) -> max strength
        for row in ev_rows:
            src, stu, buy, strength = row[0], row[1], row[2], row[3]
            key = (src, stu, buy)
            if key not in source_max or strength > source_max[key]:
                source_max[key] = strength
        conf = defaultdict(int)
        for (src, stu, buy), val in source_max.items():
            conf[(stu, buy)] += val

        # Build adjacency: student -> list of (buyer, confidence)
        adj = defaultdict(dict)
        for (stu, buy), c in conf.items():
            adj[stu][buy] = c

        # Find connected components of the bipartite graph
        all_students = set(students)
        all_buyers = set(buyers)
        visited_s = set()
        visited_b = set()
        components = []
        for s in students:
            if s in visited_s:
                continue
            comp_s = []
            comp_b = []
            queue = [s]
            visited_s.add(s)
            while queue:
                cs = queue.pop()
                comp_s.append(cs)
                for b in adj.get(cs, {}):
                    if b not in visited_b and b in all_buyers:
                        visited_b.add(b)
                        comp_b.append(b)
                        for ns in adj:
                            if ns not in visited_s and b in adj[ns] and ns in all_students:
                                visited_s.add(ns)
                                queue.append(ns)
            components.append((sorted(comp_s), sorted(comp_b)))

        # Check feasibility: each component must have equal sides
        for cs, cb in components:
            if len(cs) != len(cb):
                return None

        # For each component, enumerate all perfect matchings
        # Use backtracking; components have <= 14 per side
        def enum_matchings(comp_students, comp_buyers):
            n = len(comp_students)
            if n == 0:
                return [({}, float('inf'), 0)]
            buyer_set = set(comp_buyers)
            best_floor = [float('-inf')]
            best_total = [float('-inf')]
            results = []

            def backtrack(idx, used, mapping, min_c, sum_c):
                if idx == n:
                    if min_c >= best_floor[0]:
                        if min_c > best_floor[0]:
                            best_floor[0] = min_c
                            best_total[0] = sum_c
                            results.clear()
                        if sum_c >= best_total[0]:
                            if sum_c > best_total[0]:
                                best_total[0] = sum_c
                                results.clear()
                            results.append((dict(mapping), min_c, sum_c))
                    return
                s = comp_students[idx]
                for b in comp_buyers:
                    if b in used:
                        continue
                    c = adj[s].get(b, 0)
                    if c == 0:
                        continue
                    new_min = min(min_c, c)
                    # Pruning: if new_min < best_floor, skip
                    if new_min < best_floor[0]:
                        continue
                    used.add(b)
                    mapping[s] = b
                    backtrack(idx + 1, used, mapping, new_min, sum_c + c)
                    del mapping[s]
                    used.remove(b)

            backtrack(0, set(), {}, float('inf'), 0)
            return results

        # Combine matchings across components
        # Each component gives a list of optimal matchings
        comp_results = []
        for cs, cb in components:
            ms = enum_matchings(cs, cb)
            if not ms:
                return None
            comp_results.append(ms)

        # Cross-product: combine one matching from each component
        # All must share the same global floor and total
        # Since components are independent, global floor = min of component floors
        # and global total = sum of component totals
        # We need to find combinations where global floor is maximized, then global total maximized

        # First find the best global floor and total
        # Group each component's results by (floor, total)
        # The optimal combination picks one result per component such that
        # min(floors) is maximized, then sum(totals) is maximized

        # Since components are independent, we can:
        # 1. Find the maximum possible global floor F*
        #    F* = max over choices of min(component_floors)
        #    This means: for each component, filter to matchings with floor >= F*
        #    F* is the largest value such that every component has at least one matching with floor >= F*
        # 2. Given F*, maximize sum of totals where each component uses a matching with floor >= F*
        #    For each component, among matchings with floor >= F*, pick max total

        # Collect all distinct floor values
        all_floors = set()
        for cr in comp_results:
            for m, f, t in cr:
                all_floors.add(f)
        all_floors = sorted(all_floors, reverse=True)

        best_global_floor = None
        for f_candidate in all_floors:
            feasible = True
            for cr in comp_results:
                has = any(f >= f_candidate for _, f, _ in cr)
                if not has:
                    feasible = False
                    break
            if feasible:
                best_global_floor = f_candidate
                break

        if best_global_floor is None:
            return None

        # For each component, filter to matchings with floor >= best_global_floor
        # Among those, find the max total
        filtered = []
        for cr in comp_results:
            valid = [(m, f, t) for m, f, t in cr if f >= best_global_floor]
            max_t = max(t for _, _, t in valid)
            best_in_comp = [(m, f, t) for m, f, t in valid if t == max_t]
            filtered.append(best_in_comp)

        best_global_total = sum(max(t for _, _, t in fcomp) for fcomp in filtered)

        # Now collect ALL combinations that achieve (best_global_floor, best_global_total)
        # For each component, keep only matchings with floor >= best_global_floor AND total = max_total_for_that_component
        # Wait - we need sum of totals = best_global_total, which means each component must contribute its max
        # Actually no - different components could trade off. But since we want to maximize the SUM,
        # and components are independent, each component independently maximizes its total.
        # So yes, each component must use a matching that achieves its individual max total (among floor >= F*).

        # Count total combinations
        total_count = 1
        for fcomp in filtered:
            total_count *= len(fcomp)

        # Generate all combined matchings to compute numerators
        # For efficiency, compute per-component contributions
        # Numerator = n * sum(X_i * Y_{mapping(i)}) - sum(X) * sum(Y)
        # sum(X) and sum(Y) are constants regardless of mapping
        # So numerator varies only in sum(X_i * Y_{mapping(i)})

        sorted_students = sorted(students)
        n = len(students)
        sum_x = sum(scores[s] for s in students)
        sum_y = sum(totals[b] for b in buyers)

        # For each combined matching, compute sum_xy
        # We need to enumerate all combinations
        def gen_combinations(comp_idx, current_map):
            if comp_idx == len(filtered):
                yield dict(current_map)
                return
            for m, f, t in filtered[comp_idx]:
                current_map.update(m)
                yield from gen_combinations(comp_idx + 1, current_map)
                for k in m:
                    del current_map[k]

        min_num = float('inf')
        max_num = float('-inf')
        min_buyers_vec = None
        max_buyers_vec = None
        forced_pairs = None
        all_mappings = []

        for mapping in gen_combinations(0, {}):
            sum_xy = sum(scores[s] * totals[mapping[s]] for s in students)
            num = n * sum_xy - sum_x * sum_y
            buyers_vec = tuple(mapping[s] for s in sorted_students)
            all_mappings.append((num, buyers_vec, mapping))
            if num < min_num:
                min_num = num
                min_buyers_vec = buyers_vec
            elif num == min_num:
                if buyers_vec < min_buyers_vec:
                    min_buyers_vec = buyers_vec
            if num > max_num:
                max_num = num
                max_buyers_vec = buyers_vec
            elif num == max_num:
                if buyers_vec < max_buyers_vec:
                    max_buyers_vec = buyers_vec

        # Forced pairs: pairs that appear in ALL optimal mappings
        # "optimal" here means achieving both best floor and best total
        # (which is all of them since we already filtered)
        first_mapping = all_mappings[0][2]
        forced = []
        for s in sorted_students:
            b = first_mapping[s]
            if all(am[2][s] == b for am in all_mappings):
                forced.append([s, b])

        return {
            "floor": best_global_floor,
            "total": best_global_total,
            "count": total_count,
            "min_num": min_num,
            "max_num": max_num,
            "min_buyers": list(min_buyers_vec),
            "max_buyers": list(max_buyers_vec),
            "forced": forced
        }

    results = []
    for d in drop_list:
        if d is None:
            ev_rows = evidence
        else:
            ev_rows = [r for r in evidence if r[0] != d]
        res = solve(ev_rows)
        results.append({"drop": d, "result": res})

    return results
