def compute(payload):
    """每个到货信号映射至可供菜品 ID，保持 recipes 顺序，检查难度、原料可得性和过敏限制。"""
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]
    all_forbidden = set()
    for g in groups:
        for ing in g[2]:
            all_forbidden.add(ing)
    result = {}
    for signal, available_ingredients in delivery.items():
        avail_set = set(available_ingredients)
        eligible = []
        for r in recipes:
            if r["difficulty"] > 4:
                continue
            ingredients_needed = set(r["ingredients"])
            if not ingredients_needed.issubset(avail_set):
                continue
            if ingredients_needed & all_forbidden:
                continue
            eligible.append(r["id"])
        result[signal] = eligible
    return result
