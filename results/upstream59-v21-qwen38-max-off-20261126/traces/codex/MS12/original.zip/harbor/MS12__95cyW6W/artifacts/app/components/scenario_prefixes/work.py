def compute(payload):
    """输出 [信号历史,该完整叶的权重或 null]，去重生成所有非空前缀，按历史字典序排列。"""
    scenarios = payload["scenarios"]
    prefix_map = {}
    for sc in scenarios:
        signals = sc["signals"]
        weight = sc["weight"]
        for i in range(1, len(signals) + 1):
            prefix = tuple(signals[:i])
            if prefix not in prefix_map:
                if i == len(signals):
                    prefix_map[prefix] = weight
                else:
                    prefix_map[prefix] = None
            else:
                if i == len(signals):
                    prefix_map[prefix] = weight
    sorted_prefixes = sorted(prefix_map.keys())
    return [[list(p), prefix_map[p]] for p in sorted_prefixes]
