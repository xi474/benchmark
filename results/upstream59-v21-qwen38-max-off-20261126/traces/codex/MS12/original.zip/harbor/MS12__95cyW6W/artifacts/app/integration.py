def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    from itertools import product as iter_product

    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]
    budget = payload["budget"]
    scenarios = payload["scenarios"]

    # left = scenario_prefixes result: list of [history_list, weight_or_null]
    # right = menu_eligibility result: dict signal -> [recipe_ids]

    histories_data = left  # [[signals...], weight_or_null], ...
    eligibility = right    # signal -> [recipe_ids]

    # Build recipe lookup
    recipe_map = {r["id"]: r for r in recipes}

    # Parse histories into tuples, sorted by lex order (already sorted)
    prefixes = []
    for entry in histories_data:
        hist = tuple(entry[0])
        w = entry[1]
        prefixes.append((hist, w))

    num_prefixes = len(prefixes)

    # For each prefix, determine which day it corresponds to (length of prefix)
    # and what delivery signal applies on that day (last element of prefix)
    # A prefix of length d means day d (1-indexed), and the signal for day d is prefix[d-1]

    # For each prefix, find eligible recipes on that day
    # The signal on day d is the d-th element of the prefix
    prefix_eligible = {}
    for hist, w in prefixes:
        day_signal = hist[-1]
        eligible = eligibility.get(day_signal, [])
        prefix_eligible[hist] = eligible

    # Determine number of days
    num_days = max(len(h) for h, w in prefixes) if prefixes else 0

    # For each scenario, its full signal sequence determines a path through prefixes
    # A scenario with signals [s1, s2, ..., sD] uses prefixes:
    #   (s1,), (s1,s2), ..., (s1,s2,...,sD)
    # Each prefix maps to a recipe choice. The constraint is:
    # - Same prefix -> same recipe (by definition of policy)
    # - No repeated recipe on any actual path
    # - No adjacent same category on any actual path
    # - Total cost on any actual path <= budget

    # Build scenario paths: for each scenario, list of prefixes it traverses
    scenario_paths = []
    for sc in scenarios:
        signals = sc["signals"]
        weight = sc["weight"]
        path = []
        for i in range(1, len(signals) + 1):
            path.append(tuple(signals[:i]))
        scenario_paths.append((path, weight))

    # Compute satisfaction for a recipe given groups
    # satisfaction per group = number of people who like the recipe's category
    # Actually: "某群体喜欢该菜的品类时，该群体每人获得一分满意度"
    # So if group likes cat, each person in that group gets 1 point
    # Per-person satisfaction for a group = 1 if group likes cat, else 0
    # Service score of a scenario = sum over days of (min over groups of per-person satisfaction)
    # Wait, re-read: "一个情景的服务分是其各天满意度相加后在群体中取最小值，使用每人的满意度"
    # So: for each group, compute total per-person satisfaction across all days
    # Then take min across groups
    # Per-person satisfaction for group g on day d = 1 if g likes recipe's cat, else 0
    # Total per-person satisfaction for group g = sum over days of (1 if g likes cat_d else 0)
    # Service score = min over groups of total_per_person_satisfaction

    # Total person-score = sum over groups of (per_person_satisfaction * num_people)

    # Precompute: for each recipe, for each group, does the group like it?
    group_likes = {}
    for g in groups:
        gname = g[0]
        liked_cats = set(g[3])
        group_likes[gname] = liked_cats

    def recipe_group_score(recipe_id, group_idx):
        """Per-person satisfaction: 1 if group likes the recipe's category, else 0"""
        r = recipe_map[recipe_id]
        g = groups[group_idx]
        return 1 if r["cat"] in set(g[3]) else 0

    # Now we need to enumerate valid policies and find optimal ones
    # A policy assigns a recipe to each prefix
    # Constraints:
    # 1. Recipe must be eligible for that prefix's signal
    # 2. On each scenario path: no repeated recipe
    # 3. On each scenario path: no adjacent same category
    # 4. On each scenario path: total cost <= budget

    # With max 5 days, 12 recipes, 12 prefixes, brute force may work
    # But let's be smart about it

    # Strategy: enumerate all valid assignments using backtracking
    # Prefixes are ordered lexicographically; assign recipes one by one

    # First, let's figure out which prefixes share constraints via scenarios
    # Two prefixes are on the same path if one is a prefix of the other AND they belong to same scenario
    # Actually, constraints are per-scenario-path

    # For efficiency, let's do DFS/backtracking over prefixes in order
    # At each step, try each eligible recipe for current prefix
    # Check constraints that can be verified incrementally

    # Build: for each prefix index, which scenario paths include it and at what position
    prefix_to_scenarios = {}
    for si, (path, weight) in enumerate(scenario_paths):
        for pi_in_path, pref in enumerate(path):
            if pref not in prefix_to_scenarios:
                prefix_to_scenarios[pref] = []
            prefix_to_scenarios[pref].append((si, pi_in_path))

    # prefix index map
    prefix_index = {h: i for i, (h, w) in enumerate(prefixes)}

    best_floor = -1
    best_utility = -1
    best_cost = float('inf')
    best_menus = []  # list of menu vectors (as tuples of recipe ids)

    # For tracking allowed sets
    allowed_sets = [set() for _ in range(num_prefixes)]

    def evaluate_policy(assignment):
        """Given a complete assignment (list of recipe ids, one per prefix),
           compute (floor, utility, cost) or None if invalid."""
        # Check all scenario paths
        total_weighted_utility = 0
        total_weighted_cost = 0
        min_floor = float('inf')

        for si, (path, weight) in enumerate(scenario_paths):
            # Get recipes on this path
            path_recipes = [assignment[prefix_index[p]] for p in path]

            # Check no repeats
            if len(set(path_recipes)) != len(path_recipes):
                return None

            # Check no adjacent same category
            for k in range(len(path_recipes) - 1):
                if recipe_map[path_recipes[k]]["cat"] == recipe_map[path_recipes[k+1]]["cat"]:
                    return None

            # Check budget
            path_cost = sum(recipe_map[r]["cost"] for r in path_recipes)
            if path_cost > budget:
                return None

            # Compute per-group per-person satisfaction
            num_groups = len(groups)
            group_scores = [0] * num_groups
            for r in path_recipes:
                for gi in range(num_groups):
                    group_scores[gi] += recipe_group_score(r, gi)

            floor = min(group_scores)
            utility = sum(group_scores[gi] * groups[gi][1] for gi in range(num_groups))

            if floor < min_floor:
                min_floor = floor
            total_weighted_utility += weight * utility
            total_weighted_cost += weight * path_cost

        return (min_floor, total_weighted_utility, total_weighted_cost)

    def backtrack(idx, assignment):
        nonlocal best_floor, best_utility, best_cost, best_menus

        if idx == num_prefixes:
            result = evaluate_policy(assignment)
            if result is None:
                return
            floor, utility, cost = result
            # Compare: maximize floor, then maximize utility, then minimize cost
            menu_tuple = tuple(assignment)
            if (floor > best_floor or
                (floor == best_floor and utility > best_utility) or
                (floor == best_floor and utility == best_utility and cost < best_cost)):
                best_floor = floor
                best_utility = utility
                best_cost = cost
                best_menus = [menu_tuple]
                for i in range(num_prefixes):
                    allowed_sets[i] = {assignment[i]}
            elif floor == best_floor and utility == best_utility and cost == best_cost:
                best_menus.append(menu_tuple)
                for i in range(num_prefixes):
                    allowed_sets[i].add(assignment[i])
            return

        hist, w = prefixes[idx]
        eligible = prefix_eligible[hist]

        for rid in eligible:
            assignment.append(rid)
            backtrack(idx + 1, assignment)
            assignment.pop()

    backtrack(0, [])

    if not best_menus:
        return {"histories": [list(h) for h, w in prefixes], "optimal": None}

    # Find lexicographically smallest menu vector
    best_menus.sort()
    lex_min_menu = best_menus[0]

    # Count distinct prefix-to-recipe mappings across all optimal policies
    # "count 数不同的前缀到菜名映射" - count of distinct policies
    distinct_policies = set(best_menus)
    count = len(distinct_policies)

    # allowed: for each prefix, recipes that appear in at least one optimal policy (sorted)
    allowed = [sorted(list(s)) for s in allowed_sets]

    histories_out = [list(h) for h, w in prefixes]

    return {
        "histories": histories_out,
        "optimal": {
            "floor": best_floor,
            "utility": best_utility,
            "cost": best_cost,
            "count": count,
            "menu": list(lex_min_menu),
            "allowed": allowed
        }
    }
