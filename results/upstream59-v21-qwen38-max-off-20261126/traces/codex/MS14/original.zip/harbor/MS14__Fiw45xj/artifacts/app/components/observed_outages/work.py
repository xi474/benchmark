def compute(payload):
    """为每个查询逐时隙列出当时可见且实际为 down 的域名数组，升序；按有效时刻再按看到时刻选择最新记录。"""
    queries = payload["queries"]
    log = payload["log"]
    result = []
    for q in queries:
        as_of = q["as_of"]
        start = q["start"]
        end = q["end"]
        visible = [entry for entry in log if entry[2] <= as_of]
        slots = []
        for t in range(start, end):
            domain_latest = {}
            for domain, eff, ing, status in visible:
                if eff <= t:
                    key = domain
                    if key not in domain_latest:
                        domain_latest[key] = (eff, ing, status)
                    else:
                        cur_eff, cur_ing, _ = domain_latest[key]
                        if eff > cur_eff or (eff == cur_eff and ing > cur_ing):
                            domain_latest[key] = (eff, ing, status)
            down = sorted(d for d, (_, _, st) in domain_latest.items() if st != "up")
            slots.append(down)
        result.append(slots)
    return result
