def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    domains = payload["domains"]
    log = payload["log"]
    queries = payload["queries"]
    svc_map = right  # service_id -> [need, inputs]
    # left is observed_outages: list of per-query per-slot down-domain lists

    def get_domain_states(as_of, t, visible):
        domain_latest = {}
        for domain, eff, ing, status in visible:
            if eff <= t:
                if domain not in domain_latest:
                    domain_latest[domain] = (eff, ing, status)
                else:
                    cur_eff, cur_ing, _ = domain_latest[domain]
                    if eff > cur_eff or (eff == cur_eff and ing > cur_ing):
                        domain_latest[domain] = (eff, ing, status)
        result = {}
        for d in domains:
            result[d] = domain_latest[d][2] if d in domain_latest else "up"
        return result

    def is_available(entity, ds, memo):
        if entity in memo:
            return memo[entity]
        if entity not in svc_map:
            result = ds.get(entity, "up") == "up"
            memo[entity] = result
            return result
        need, inputs = svc_map[entity]
        count = sum(1 for inp in inputs if is_available(inp, ds, memo))
        result = count >= need
        memo[entity] = result
        return result

    def targets_ok(targets, ds):
        memo = {}
        return all(is_available(t, ds, memo) for t in targets)

    output = []
    for qi, q in enumerate(queries):
        as_of = q["as_of"]
        start = q["start"]
        end = q["end"]
        targets = q["targets"]
        visible = [entry for entry in log if entry[2] <= as_of]

        # Compute incidents per target
        incidents = []
        for target in sorted(targets):
            unavail = []
            for t in range(start, end):
                ds = get_domain_states(as_of, t, visible)
                memo = {}
                if not is_available(target, ds, memo):
                    unavail.append(t)
            if unavail:
                s = unavail[0]
                prev = s
                for slot in unavail[1:]:
                    if slot == prev + 1:
                        prev = slot
                    else:
                        incidents.append([target, s, prev + 1])
                        s = slot
                        prev = slot
                incidents.append([target, s, prev + 1])

        # Compute minimal repairs
        from itertools import combinations
        all_domains_sorted = sorted(domains)
        found_repairs = None
        for size in range(len(all_domains_sorted) + 1):
            candidates = []
            for combo in combinations(all_domains_sorted, size):
                ok = True
                for t in range(start, end):
                    ds = get_domain_states(as_of, t, visible)
                    for d in combo:
                        ds[d] = "up"
                    if not targets_ok(targets, ds):
                        ok = False
                        break
                if ok:
                    candidates.append(list(combo))
            if candidates:
                # Filter to inclusion-minimal sets
                minimal = []
                for c in candidates:
                    cs = set(c)
                    is_min = True
                    for other in candidates:
                        os = set(other)
                        if os != cs and os.issubset(cs):
                            is_min = False
                            break
                    if is_min:
                        minimal.append(c)
                minimal.sort(key=lambda x: (len(x), x))
                found_repairs = minimal
                break
        if found_repairs is None:
            found_repairs = [[]]

        output.append({"incidents": incidents, "repairs": found_repairs})
    return output
