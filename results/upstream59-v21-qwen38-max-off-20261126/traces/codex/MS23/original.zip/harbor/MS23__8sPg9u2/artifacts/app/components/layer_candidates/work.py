def _enumerate_matrices(k, row_sums, col_sums, upper_bounds, forbidden_cells):
    """Enumerate all k×k non-negative integer matrices with given row/col sums,
    upper bounds per cell, and forbidden cells forced to zero.
    Returns list of flattened vectors in lex order."""
    # Use recursive backtracking over cells in row-major order
    results = []
    n = k * k
    
    def backtrack(idx, mat, remaining_row, remaining_col):
        if idx == n:
            # Check all remaining sums are zero
            if all(r == 0 for r in remaining_row) and all(c == 0 for c in remaining_col):
                results.append(tuple(mat))
            return
        
        a = idx // k
        c = idx % k
        
        if (a, c) in forbidden_cells:
            if remaining_row[a] >= 0 and remaining_col[c] >= 0:
                mat.append(0)
                backtrack(idx + 1, mat, remaining_row, remaining_col)
                mat.pop()
            return
        
        max_val = min(remaining_row[a], remaining_col[c], upper_bounds[idx])
        min_val = 0
        
        # Pruning: check if remaining cells in this row can fill the rest
        # Simple bound: val must allow remaining_row[a]-val to be achievable
        # by remaining cells in this row
        
        for v in range(min_val, max_val + 1):
            new_remaining_row = remaining_row[:]
            new_remaining_col = remaining_col[:]
            new_remaining_row[a] -= v
            new_remaining_col[c] -= v
            
            # Quick feasibility check
            if new_remaining_row[a] < 0 or new_remaining_col[c] < 0:
                continue
            
            mat.append(v)
            backtrack(idx + 1, mat, new_remaining_row, new_remaining_col)
            mat.pop()
    
    rs = list(row_sums)
    cs = list(col_sums)
    backtrack(0, [], rs, cs)
    results.sort()
    return results


def _median_score(a, b, c, k):
    """Compute the net score contribution of a single customer at (a,b,c)."""
    vals = sorted([a, b, c])
    med = vals[1]
    if med == k - 1:
        return 1
    elif med == 0:
        return -1
    else:
        return 0


def compute(payload):
    """为每个快照按 b 生成候选层数组。每层候选为 [按 a,c 行优先的计数向量,该层的中位数净分]，满足边际、禁止格和 ac 上限；按向量字典序。"""
    all_results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)
        
        # Build forbidden set as (a, b, c) tuples
        forbidden_set = set()
        for f in forbidden:
            forbidden_set.add((f[0], f[1], f[2]))
        
        # ac upper bounds flattened row-major
        ac_flat = []
        for a in range(k):
            for c in range(k):
                ac_flat.append(ac[a][c])
        
        snapshot_result = []
        for b_val in range(k):
            # Row sums for this b: ab[a][b_val] for each a
            row_sums = [ab[a][b_val] for a in range(k)]
            # Col sums for this b: bc[b_val][c] for each c
            col_sums = [bc[b_val][c] for c in range(k)]
            
            # Forbidden cells for this b layer
            layer_forbidden = set()
            for a in range(k):
                for c in range(k):
                    if (a, b_val, c) in forbidden_set:
                        layer_forbidden.add((a, c))
            
            # Upper bounds from ac
            upper = list(ac_flat)
            
            matrices = _enumerate_matrices(k, row_sums, col_sums, upper, layer_forbidden)
            
            candidates = []
            for vec in matrices:
                # Compute net score for this layer
                net = 0
                for idx in range(k * k):
                    a = idx // k
                    c = idx % k
                    count = vec[idx]
                    if count > 0:
                        net += count * _median_score(a, b_val, c, k)
                candidates.append([list(vec), net])
            
            snapshot_result.append(candidates)
        
        all_results.append(snapshot_result)
    
    return all_results
