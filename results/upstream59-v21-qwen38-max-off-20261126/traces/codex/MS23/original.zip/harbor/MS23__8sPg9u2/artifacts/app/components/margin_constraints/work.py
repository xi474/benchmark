def compute(payload):
    """为每个快照输出 [ab 与 ac 各 a 总量是否相容,按 a,c 行优先展开的 ac 配额]。"""
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        ac = snap["ac"]
        k = len(ab)
        # Check compatibility: for each a, sum_b ab[a][b] must equal sum_c ac[a][c]
        compatible = True
        for a in range(k):
            ab_total = sum(ab[a][b] for b in range(k))
            ac_total = sum(ac[a][c] for c in range(k))
            if ab_total != ac_total:
                compatible = False
                break
        # ac quota: flatten ac table in row-major order (a outer, c inner)
        ac_quota = []
        for a in range(k):
            for c in range(k):
                ac_quota.append(ac[a][c])
        results.append([compatible, ac_quota])
    return results
