def _median_score(a, b, c, k):
    vals = sorted([a, b, c])
    med = vals[1]
    if med == k - 1:
        return 1
    elif med == 0:
        return -1
    else:
        return 0


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    results = []

    for snap_idx, snap in enumerate(payload["snapshots"]):
        ab = snap["ab"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)

        compatible = left[snap_idx][0]
        ac_quota = left[snap_idx][1]
        layer_cands = right[snap_idx]

        if not compatible:
            results.append(None)
            continue

        ac_target = tuple(ac_quota)
        n_cells = k * k

        valid_tables = []

        def combine_layers(b_idx, current_sum, current_net, current_table):
            if b_idx == k:
                if current_sum == ac_target:
                    valid_tables.append((current_net, tuple(current_table)))
                return

            candidates = layer_cands[b_idx]
            for vec, layer_net in candidates:
                feasible = True
                new_sum = list(current_sum)
                for i in range(n_cells):
                    new_sum[i] += vec[i]
                    if new_sum[i] > ac_target[i]:
                        feasible = False
                        break

                if not feasible:
                    continue

                new_table = current_table + [(b_idx, vec)]
                combine_layers(b_idx + 1, tuple(new_sum), current_net + layer_net, new_table)

        zero_sum = tuple([0] * n_cells)
        combine_layers(0, zero_sum, 0, [])

        if not valid_tables:
            results.append(None)
            continue

        num_tables = len(valid_tables)

        from collections import Counter
        net_counts = Counter()
        for net, _ in valid_tables:
            net_counts[net] += 1
        spectrum = sorted([[net, count] for net, count in net_counts.items()], key=lambda x: x[0])

        def table_to_3d(table_repr):
            cells = {}
            for b_idx, vec in table_repr:
                for idx in range(n_cells):
                    a = idx // k
                    c = idx % k
                    v = vec[idx]
                    if v > 0:
                        cells[(a, b_idx, c)] = v
            return cells

        def table_to_full_vector(table_repr):
            entries = []
            for a in range(k):
                for b in range(k):
                    for c in range(k):
                        val = 0
                        for b_idx, vec in table_repr:
                            if b_idx == b:
                                val = vec[a * k + c]
                                break
                        if val > 0:
                            entries.append([a, b, c, val])
            return entries

        all_cells = set()
        for _, tbl in valid_tables:
            cells = table_to_3d(tbl)
            all_cells.update(cells.keys())

        guaranteed = []
        for cell in sorted(all_cells):
            min_val = float('inf')
            for _, tbl in valid_tables:
                cells = table_to_3d(tbl)
                val = cells.get(cell, 0)
                min_val = min(min_val, val)
            if min_val > 0:
                guaranteed.append([cell[0], cell[1], cell[2], min_val])

        min_net = min(net for net, _ in valid_tables)
        min_net_tables = [tbl for net, tbl in valid_tables if net == min_net]

        best_witness = None
        for tbl in min_net_tables:
            fv = table_to_full_vector(tbl)
            if best_witness is None or fv < best_witness:
                best_witness = fv

        results.append({
            "tables": num_tables,
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": best_witness
        })

    return results
