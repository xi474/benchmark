def compute(payload):
    """为有截止日的作业返回 [需求,合格时段 ID 升序数组]，先按原始时段和七天半开窗口筛选。"""
    assignments = payload["assignments"]
    slots = payload["slots"]
    slot_map = {s[0]: s[1] for s in slots}
    result = {}
    for aid, due, demand, svc_slots in assignments:
        if due is None:
            continue
        lo = due - 7
        valid = sorted(
            sid for sid in svc_slots
            if sid in slot_map and lo <= slot_map[sid] < due
        )
        result[aid] = [demand, valid]
    return result
