def compute(payload):
    """每个撤回情景返回仍可用的时段映射，时段 ID 对应 [时刻,容量]。"""
    slots = payload["slots"]
    withdrawals = payload["withdrawals"]
    results = []
    for withdrawn in withdrawals:
        removed = set(withdrawn)
        remaining = {}
        for sid, day, cap in slots:
            if sid not in removed:
                remaining[sid] = [day, cap]
        results.append(remaining)
    return results
