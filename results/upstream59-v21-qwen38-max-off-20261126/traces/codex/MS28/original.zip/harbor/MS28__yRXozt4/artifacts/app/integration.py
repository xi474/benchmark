def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    from math import gcd

    # left: {assignment_id: [demand, [valid_slot_ids]]}  (only assignments with deadlines)
    # right: list of {slot_id: [day, capacity]} per withdrawal scenario

    results = []
    for scenario_remaining in right:
        # Build effective assignment data for this scenario
        eff = {}
        for aid, (demand, slot_ids) in left.items():
            valid = [sid for sid in slot_ids if sid in scenario_remaining]
            eff[aid] = (demand, valid)

        deadline_ids = sorted(eff.keys())
        if not deadline_ids:
            results.append({"empty": True})
            continue

        unserved = sorted(aid for aid in deadline_ids if not eff[aid][1])
        if unserved:
            results.append({"unserved": unserved})
            continue

        # Build connected components via union-find on assignments sharing slots
        parent = {aid: aid for aid in deadline_ids}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb

        slot_to_assignments = {}
        for aid in deadline_ids:
            for sid in eff[aid][1]:
                slot_to_assignments.setdefault(sid, []).append(aid)
        for sid, aids in slot_to_assignments.items():
            for i in range(1, len(aids)):
                union(aids[0], aids[i])

        components = {}
        for aid in deadline_ids:
            r = find(aid)
            components.setdefault(r, []).append(aid)

        # For each component, enumerate all non-empty subsets and find peak ratio + tight sets
        # Each component has <=14 assignments
        comp_results = []  # list of (peak_num, peak_den, list_of_tight_subsets_as_frozensets)

        for root, members in components.items():
            n = len(members)
            idx = {aid: i for i, aid in enumerate(members)}
            demands = [eff[aid][0] for aid in members]
            slot_lists = [eff[aid][1] for aid in members]

            best_num = 0
            best_den = 1
            tight_sets = []

            for mask in range(1, 1 << n):
                total_demand = 0
                slot_union = set()
                for i in range(n):
                    if mask & (1 << i):
                        total_demand += demands[i]
                        slot_union.update(slot_lists[i])
                total_cap = sum(scenario_remaining[sid][1] for sid in slot_union)
                # Compare total_demand/total_cap vs best_num/best_den
                # total_demand * best_den vs best_num * total_cap
                lhs = total_demand * best_den
                rhs = best_num * total_cap
                if lhs > rhs:
                    best_num = total_demand
                    best_den = total_cap
                    tight_sets = [mask]
                elif lhs == rhs:
                    tight_sets.append(mask)

            g = gcd(best_num, best_den)
            comp_results.append((best_num // g, best_den // g, tight_sets, members))

        # Global peak is max of per-component peaks
        global_peak_num = max(cr[0] for cr in comp_results)
        global_peak_den = 1
        # All components should already be reduced; find the one(s) matching global peak
        # Actually we need to compare fractions properly
        best_gn, best_gd = 0, 1
        for pn, pd, _, _ in comp_results:
            if pn * best_gd > best_gn * pd:
                best_gn, best_gd = pn, pd
        global_peak_num, global_peak_den = best_gn, best_gd

        # Collect all tight sets: unions of per-component choices where each
        # non-empty component part achieves global peak
        # For each component, find which tight subsets achieve global peak
        comp_peak_masks = []
        for pn, pd, tsets, members in comp_results:
            if pn * global_peak_den == global_peak_num * pd:
                comp_peak_masks.append((tsets, members))
            else:
                comp_peak_masks.append(([0], members))  # only empty choice (mask 0 placeholder)

        # Generate all combinations: for each component, pick one of its peak-achieving masks (or empty)
        # Then union them into a global set of assignment IDs
        all_tight_global = set()

        def collect(idx_components, current_set):
            if idx_components == len(comp_peak_masks):
                if current_set:  # non-empty
                    all_tight_global.add(frozenset(current_set))
                return
            masks, members = comp_peak_masks[idx_components]
            # Option: skip this component (empty contribution)
            collect(idx_components + 1, current_set)
            # Options: pick each peak-achieving mask
            for mask in masks:
                if mask == 0:
                    continue
                new_set = set(current_set)
                for i in range(len(members)):
                    if mask & (1 << i):
                        new_set.add(members[i])
                collect(idx_components + 1, new_set)

        collect(0, set())

        # Minimal tight sets: those minimal under inclusion
        sorted_tight = sorted(all_tight_global, key=lambda s: (len(s), sorted(s)))
        minimal = []
        for ts in sorted_tight:
            if not any(prev < ts for prev in minimal):
                minimal.append(ts)

        # implies: for each assignment appearing in any tight set,
        # list other assignments that always co-occur with it in every tight set containing it
        # Wait, re-read: "列表列出每个包含它的紧集也包含的其他作业"
        # This means: for assignment A, collect the union of (tight_set - {A}) for all tight sets containing A
        # Actually: "列出每个包含它的紧集也包含的其他作业，不含它自己"
        # So for each tight set T containing A, the "other assignments" are T - {A}.
        # The implies list for A is the union of all such others? Or the list per tight set?
        # Looking at expected output: implies for Q is ["R","S"], and the only tight set is {Q,R,S}.
        # So it seems like it's the union of all other assignments across all tight sets containing A.
        # Let me verify: tight set is {Q,R,S}. For Q: others = {R,S}. For R: others = {Q,S}. For S: others = {Q,R}.
        # Expected implies: Q->[R,S], R->[Q,S], S->[Q,R]. Yes, union interpretation works.

        appears_in = set()
        for ts in all_tight_global:
            appears_in.update(ts)

        implies_list = []
        for aid in sorted(appears_in):
            others = set()
            for ts in all_tight_global:
                if aid in ts:
                    others.update(ts - {aid})
            implies_list.append([aid, sorted(others)])

        results.append({
            "peak": [global_peak_num, global_peak_den],
            "count": len(all_tight_global),
            "minimal": [sorted(list(ts)) for ts in minimal],
            "implies": implies_list
        })

    return results
