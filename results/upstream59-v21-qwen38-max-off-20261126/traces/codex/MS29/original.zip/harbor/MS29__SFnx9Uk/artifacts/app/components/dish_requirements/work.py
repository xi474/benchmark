def compute(payload):
    """返回合格的三类菜品组合及合并需求，格式 [菜品 ID 数组,原料到数量映射]，按菜品字典序枚举。"""
    from itertools import combinations
    dishes = payload["dishes"]
    max_diff = payload["max_difficulty"]
    # Filter dishes by difficulty
    candidates = []
    for d in dishes:
        did, cat, diff, ingredients = d[0], d[1], d[2], d[3]
        if diff <= max_diff:
            candidates.append((did, cat, ingredients))
    # Group by category
    from collections import defaultdict
    by_cat = defaultdict(list)
    for did, cat, ing in candidates:
        by_cat[cat].append((did, ing))
    cats = sorted(by_cat.keys())
    results = []
    # Pick one dish from each of 3 different categories
    for c_combo in combinations(cats, 3):
        # All combos of one dish per category
        pools = [by_cat[c] for c in c_combo]
        _enumerate_combos(pools, 0, [], results)
    # Sort by sorted dish ID tuple (lexicographic)
    results.sort(key=lambda x: x[0])
    return results


def _enumerate_combos(pools, idx, current, results):
    if idx == len(pools):
        dish_ids = sorted([item[0] for item in current])
        merged = {}
        for _, ing in current:
            for k, v in ing.items():
                merged[k] = merged.get(k, 0) + v
        results.append([dish_ids, merged])
        return
    for did, ing in pools[idx]:
        _enumerate_combos(pools, idx + 1, current + [(did, ing)], results)
