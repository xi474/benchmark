def compute(payload):
    """输出所有限量采购篮 [总价,总件数,按排序后 offer 的购买数量向量]；按这三项升序排列。"""
    offers = payload["offers"]
    # Sort offers by offer ID for consistent ordering
    sorted_offers = sorted(offers, key=lambda o: o[0])
    n = len(sorted_offers)
    max_counts = [o[3] for o in sorted_offers]
    prices = [o[2] for o in sorted_offers]
    results = []
    _enum_baskets(prices, max_counts, n, 0, [], 0, 0, results)
    # Sort by (cost, total_packages, buy_vector)
    results.sort(key=lambda x: (x[0], x[1], x[2]))
    return results


def _enum_baskets(prices, max_counts, n, idx, current, cost, count, results):
    if idx == n:
        results.append([cost, count, list(current)])
        return
    for q in range(max_counts[idx] + 1):
        _enum_baskets(prices, max_counts, n, idx + 1,
                      current + [q], cost + q * prices[idx], count + q, results)
