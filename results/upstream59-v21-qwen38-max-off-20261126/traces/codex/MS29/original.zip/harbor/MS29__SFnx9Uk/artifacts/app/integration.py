def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    stock = payload.get("stock", {})
    offers_raw = payload.get("offers", [])
    prep_raw = payload.get("prep", [])

    # Sort offers by ID for consistent indexing
    sorted_offers = sorted(offers_raw, key=lambda o: o[0])
    n_offers = len(sorted_offers)

    # Build offer material map
    offer_materials = []
    for o in sorted_offers:
        offer_materials.append(o[1])  # {material: qty}

    # Parse prep steps
    prep_steps = []
    for p in prep_raw:
        prep_steps.append({
            "id": p[0],
            "consumes": p[1],
            "produces": p[2],
            "max_exec": p[3]
        })

    # left = dish_requirements result: list of [dish_ids, merged_ingredients]
    # right = purchase_baskets result: list of [cost, total_pkgs, buy_vector]

    results = []
    for dish_ids, requirements in left:
        best_plan = _find_best_plan(requirements, stock, sorted_offers, offer_materials,
                                     n_offers, prep_steps, right)
        entry = {"dishes": dish_ids, "plan": best_plan}
        results.append(entry)

    return results


def _find_best_plan(requirements, stock, sorted_offers, offer_materials,
                    n_offers, prep_steps, baskets):
    """Find the optimal plan for a given set of requirements."""
    best = None
    best_key = None

    for cost, total_pkgs, buy_vec in baskets:
        # Compute available materials after purchase
        available = dict(stock)
        for i in range(n_offers):
            if buy_vec[i] > 0:
                for mat, qty in offer_materials[i].items():
                    available[mat] = available.get(mat, 0) + qty * buy_vec[i]

        # Try to find a valid prep sequence
        prep_result = _search_prep(available, requirements, prep_steps)
        if prep_result is None:
            continue

        steps_seq, leftover = prep_result
        total_prep = len(steps_seq)
        buy_key = tuple(buy_vec)
        step_key = tuple(steps_seq)

        candidate_key = (cost, total_pkgs, buy_key, total_prep, step_key)
        if best_key is None or candidate_key < best_key:
            best_key = candidate_key
            # Filter leftover to only positive quantities
            left_filtered = {k: v for k, v in leftover.items() if v > 0}
            best = {
                "cost": cost,
                "buy": list(buy_vec),
                "steps": list(steps_seq),
                "left": left_filtered
            }

    return best


def _search_prep(available, requirements, prep_steps):
    """Find optimal prep sequence: minimize total steps, then lex order.
    Returns (steps_sequence, leftover_materials) or None.
    Uses BFS to find minimum depth, then DFS with lex ordering at that depth.
    """
    def is_satisfied(avail):
        for mat, qty in requirements.items():
            if avail.get(mat, 0) < qty:
                return False
        return True

    def compute_leftover(avail):
        leftover = dict(avail)
        for mat, qty in requirements.items():
            leftover[mat] = leftover.get(mat, 0) - qty
        return {k: v for k, v in leftover.items() if v > 0}

    if is_satisfied(available):
        return ([], compute_leftover(available))

    def state_key(avail, exec_counts):
        return (tuple(sorted(avail.items())), tuple(sorted(exec_counts.items())))

    from collections import deque

    max_total_exec = 16

    # Phase 1: BFS to find minimum number of steps
    init_exec = {p["id"]: 0 for p in prep_steps}
    queue = deque()
    queue.append((dict(available), 0, dict(init_exec)))
    visited = set()
    visited.add(state_key(available, init_exec))
    min_depth = None

    while queue:
        avail, depth, exec_counts = queue.popleft()
        if depth >= max_total_exec:
            continue
        if is_satisfied(avail):
            min_depth = depth
            break
        for ps in prep_steps:
            pid = ps["id"]
            if exec_counts[pid] >= ps["max_exec"]:
                continue
            can_do = True
            for mat, qty in ps["consumes"].items():
                if avail.get(mat, 0) < qty:
                    can_do = False
                    break
            if not can_do:
                continue
            new_avail = dict(avail)
            for mat, qty in ps["consumes"].items():
                new_avail[mat] -= qty
                if new_avail[mat] == 0:
                    del new_avail[mat]
            for mat, qty in ps["produces"].items():
                new_avail[mat] = new_avail.get(mat, 0) + qty
            new_exec = dict(exec_counts)
            new_exec[pid] += 1
            sk = state_key(new_avail, new_exec)
            if sk not in visited:
                visited.add(sk)
                queue.append((new_avail, depth + 1, new_exec))

    if min_depth is None:
        return None

    # Phase 2: DFS to find lex-smallest sequence of exactly min_depth steps
    # Sort prep steps by ID for lex ordering
    sorted_preps = sorted(prep_steps, key=lambda p: p["id"])
    best_seq = [None]

    def dfs(avail, steps, exec_counts, remaining):
        if remaining == 0:
            if is_satisfied(avail):
                if best_seq[0] is None:
                    best_seq[0] = list(steps)
                return True
            return False
        for ps in sorted_preps:
            pid = ps["id"]
            if exec_counts[pid] >= ps["max_exec"]:
                continue
            can_do = True
            for mat, qty in ps["consumes"].items():
                if avail.get(mat, 0) < qty:
                    can_do = False
                    break
            if not can_do:
                continue
            new_avail = dict(avail)
            for mat, qty in ps["consumes"].items():
                new_avail[mat] -= qty
                if new_avail[mat] == 0:
                    del new_avail[mat]
            for mat, qty in ps["produces"].items():
                new_avail[mat] = new_avail.get(mat, 0) + qty
            new_exec = dict(exec_counts)
            new_exec[pid] += 1
            steps.append(pid)
            if dfs(new_avail, steps, new_exec, remaining - 1):
                return True
            steps.pop()
        return False

    dfs(dict(available), [], dict(init_exec), min_depth)
    if best_seq[0] is None:
        return None
    return (best_seq[0], compute_leftover(_replay(available, best_seq[0], prep_steps)))


def _replay(available, steps, prep_steps):
    """Replay a step sequence to get final available materials."""
    prep_map = {p["id"]: p for p in prep_steps}
    avail = dict(available)
    for sid in steps:
        ps = prep_map[sid]
        for mat, qty in ps["consumes"].items():
            avail[mat] -= qty
            if avail[mat] == 0:
                del avail[mat]
        for mat, qty in ps["produces"].items():
            avail[mat] = avail.get(mat, 0) + qty
    return avail
