def compute(payload):
    """按最新市场日的 30 天窗口、相对绝对涨跌幅和代号打破平局，返回前 top 个房间代号（保持排名）。"""
    from fractions import Fraction
    market = payload["market"]
    top = payload["top"]
    if not market:
        return []
    last_day = max(row[1] for row in market)
    window_start = last_day - 29
    filtered = [row for row in market if window_start <= row[1] <= last_day]
    def sort_key(row):
        event_id = row[0]
        open_price = row[2]
        close_price = row[3]
        change = abs(close_price - open_price) / open_price if open_price != 0 else 0
        return (-change, event_id)
    filtered.sort(key=sort_key)
    return [row[0] for row in filtered[:top]]
