def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tiers_map = left  # student -> P/D/N
    ranked_events = right  # list of event IDs in rank order

    rooms = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]

    ranked_set = set(ranked_events)

    results = []
    for cancelled in cancel_list:
        cancelled_set = set(cancelled)
        open_events = [e for e in ranked_events if e not in cancelled_set]
        open_set = set(open_events)

        # Build acceptable pairs: student -> list of acceptable open events (in pref order)
        # and room -> tier priority list
        students = sorted(tiers_map.keys())

        # For each student, determine their preference ordering over open events
        # prefs[student] = [[group1 events], [group2 events], ...]
        student_prefs = {}
        for s in students:
            if s not in prefs:
                student_prefs[s] = []
                continue
            ordered = []
            for group in prefs[s]:
                for ev in group:
                    if ev in open_set:
                        ordered.append(ev)
            student_prefs[s] = ordered

        # For each room, determine which students it accepts (by tier priority)
        # rooms[event] = {capacity, tiers: [[tier1...], [tier2...], ...]}
        # A student is acceptable to a room if their tier appears in any tier group
        room_info = {}
        for ev in open_events:
            if ev not in rooms:
                continue
            r = rooms[ev]
            cap = r["capacity"]
            tier_groups = r["tiers"]
            # Build set of acceptable tiers
            acceptable_tiers = set()
            for tg in tier_groups:
                for t in tg:
                    acceptable_tiers.add(t)
            room_info[ev] = {"capacity": cap, "acceptable_tiers": acceptable_tiers, "tier_groups": tier_groups}

        # Determine bidirectional acceptability
        # student_acceptable[s] = list of events that s prefers AND that accept s's tier
        student_acceptable = {}
        for s in students:
            acc = []
            s_tier = tiers_map[s]
            for ev in student_prefs[s]:
                if ev in room_info and s_tier in room_info[ev]["acceptable_tiers"]:
                    acc.append(ev)
            student_acceptable[s] = acc

        # Room priority over students: use tier groups as priority levels
        # Within same tier group, we need a tiebreaker - use student ID
        # room_priority[ev] = list of (priority_level, student) sorted by priority
        room_priority = {}
        for ev in open_events:
            if ev not in room_info:
                continue
            ri = room_info[ev]
            tier_groups = ri["tier_groups"]
            prio_list = []
            for level, tg in enumerate(tier_groups):
                tg_set = set(tg)
                for s in students:
                    if tiers_map[s] in tg_set and ev in student_acceptable[s]:
                        prio_list.append((level, s))
            room_priority[ev] = prio_list

        # Now find all weakly stable matchings
        # Weak stability: no blocking pair (s, w) where:
        #   - s strictly prefers w to current assignment
        #   - w has empty seat OR w strictly prefers s to some assigned student
        # Zero-capacity rooms cannot form blocking pairs.

        # With at most 8 students per component and at most 5 options each,
        # we can enumerate all valid matchings and check stability.

        active_students = [s for s in students if len(student_acceptable[s]) > 0]
        active_events = [ev for ev in open_events if ev in room_info and room_info[ev]["capacity"] > 0]

        # Enumerate all valid assignments (each student to at most one event, respecting capacity)
        # Then filter for weak stability

        def get_room_rank(ev, s):
            """Tier level for room's preference. Lower = more preferred. None if not acceptable."""
            if ev not in room_info:
                return None
            s_tier = tiers_map[s]
            tier_groups = room_info[ev]["tier_groups"]
            for level, tg in enumerate(tier_groups):
                if s_tier in set(tg):
                    return level
            return None

        def get_student_rank(s, ev):
            """Lower rank = more preferred by student. Returns None if not acceptable."""
            if ev in student_acceptable[s]:
                return student_acceptable[s].index(ev)
            return None

        # Generate all valid matchings via backtracking
        all_matchings = []
        assignment = {}  # student -> event or None
        room_count = {ev: 0 for ev in active_events}

        def backtrack(idx):
            if idx == len(active_students):
                all_matchings.append(dict(assignment))
                return
            s = active_students[idx]
            # Option: unassigned
            assignment[s] = None
            backtrack(idx + 1)
            # Options: each acceptable event with remaining capacity
            for ev in student_acceptable[s]:
                if ev in room_count and room_count[ev] < room_info[ev]["capacity"]:
                    assignment[s] = ev
                    room_count[ev] += 1
                    backtrack(idx + 1)
                    room_count[ev] -= 1
            del assignment[s]

        backtrack(0)

        def is_weakly_stable(matching):
            """Check if matching is weakly stable."""
            # Build room assignments
            room_assigned = {ev: [] for ev in active_events}
            for s, ev in matching.items():
                if ev is not None:
                    room_assigned[ev].append(s)

            for s in active_students:
                current_ev = matching.get(s)
                current_rank = get_student_rank(s, current_ev) if current_ev else None

                for ev in student_acceptable[s]:
                    if room_info[ev]["capacity"] == 0:
                        continue
                    ev_rank = get_student_rank(s, ev)
                    # s strictly prefers ev to current
                    if current_rank is not None and ev_rank >= current_rank:
                        continue
                    if current_rank is None:
                        pass  # unassigned, any acceptable event is strictly preferred
                    # Check if ev has empty seat or prefers s to someone
                    assigned = room_assigned[ev]
                    if len(assigned) < room_info[ev]["capacity"]:
                        return False  # blocking pair
                    # Check if room prefers s to any assigned student
                    s_room_rank = get_room_rank(ev, s)
                    if s_room_rank is None:
                        continue
                    for assigned_s in assigned:
                        a_room_rank = get_room_rank(ev, assigned_s)
                        if a_room_rank is not None and s_room_rank < a_room_rank:
                            return False  # blocking pair
            return True

        stable_matchings = [m for m in all_matchings if is_weakly_stable(m)]

        # Compute sizes: [assigned_count, num_matchings] grouped by assigned_count, sorted ascending
        from collections import Counter
        size_counter = Counter()
        for m in stable_matchings:
            assigned = sum(1 for v in m.values() if v is not None)
            size_counter[assigned] += 1
        sizes = sorted([[count, num] for count, num in size_counter.items()], key=lambda x: x[0])

        # Find max-size matchings
        if sizes:
            max_size = sizes[-1][0]
        else:
            max_size = 0

        max_matchings = [m for m in stable_matchings if sum(1 for v in m.values() if v is not None) == max_size]

        # Forced: pairs present in ALL max-size stable matchings
        forced = []
        if max_matchings:
            for s in students:
                vals = set(m.get(s) for m in max_matchings)
                if len(vals) == 1:
                    ev = vals.pop()
                    if ev is not None:
                        forced.append([s, ev])
        forced.sort()

        # Example: lex-min vector of assignments among max matchings, students sorted by ID
        # Unassigned = ""
        example = None
        if max_matchings:
            def matching_to_vector(m):
                return tuple(m.get(s, "") or "" for s in students)
            vectors = [matching_to_vector(m) for m in max_matchings]
            vectors.sort()
            example = list(vectors[0])

        results.append({
            "sizes": sizes,
            "forced": forced,
            "example": example if example else []
        })

    return results
