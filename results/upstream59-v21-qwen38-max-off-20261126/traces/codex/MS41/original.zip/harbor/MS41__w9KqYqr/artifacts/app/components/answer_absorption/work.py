from fractions import Fraction


def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a


def _simplify(n, d):
    if n == 0:
        return [0, 1]
    g = _gcd(abs(n), abs(d))
    return [n // g, d // g]


def compute(payload):
    answers = payload["answers"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    num_answers = len(answers)
    answer_set = set(answers)

    result = {}
    for method in methods:
        mid = method["id"]
        start = method["start"]
        graphs = method["graphs"]
        method_result = {}

        for pname in profiles:
            graph = graphs[pname]
            # Collect all non-terminal states
            states = list(graph.keys())
            state_idx = {s: i for i, s in enumerate(states)}
            n = len(states)

            # Build linear system for absorption probabilities
            # For each state s and each answer a:
            # prob[s][a] = sum over edges (s->t, w, c):
            #   if t is an answer: (w/W) * (1 if t==a else 0)
            #   if t is a state: (w/W) * prob[t][a]
            # Rearranged: prob[s][a] - sum_{t state} (w/W)*prob[t][a] = sum_{t answer, t==a} (w/W)

            # Similarly for weighted cost (unconditional expected cost for answer a):
            # wcost[s][a] = sum over edges (s->t, w, c):
            #   if t is an answer: (w/W) * c * (1 if t==a else 0)
            #   if t is a state: (w/W) * (c * prob[t][a] + wcost[t][a])
            # But it's easier to first solve for probs, then solve for conditional costs.
            # Actually, let's solve for the "unconditional weighted cost" directly:
            # ucost[s][a] = E[cost * I(absorb at a) | start at s]
            # ucost[s][a] = sum over edges (s->t, w, c):
            #   if t is answer: (w/W) * c * (1 if t==a else 0)
            #   if t is state: (w/W) * (c * prob[t][a] + ucost[t][a])

            # First solve for absorption probabilities using Fraction for exactness
            # System: (I - Q) * x = b for each answer
            # where Q[s][t] = sum of (w/W) for edges s->t (t is state)
            # and b[s] = sum of (w/W) for edges s->answer_a

            # Build transition matrix using Fractions
            # Q[i][j] = probability of going from state i to state j
            # R[i][a] = probability of going from state i to answer a
            Q = [[Fraction(0)] * n for _ in range(n)]
            R = [[Fraction(0)] * num_answers for _ in range(n)]
            # Also store cost info for later
            # For each edge from state s: list of (target, weight, cost)
            edge_info = []
            for si, s in enumerate(states):
                edges = graph[s]
                total_w = sum(e[1] for e in edges)
                ei = []
                for target, w, c in edges:
                    p = Fraction(w, total_w)
                    if target in answer_set:
                        ai = answers.index(target)
                        R[si][ai] += p
                        ei.append((None, ai, p, c))
                    else:
                        ti = state_idx[target]
                        Q[si][ti] += p
                        ei.append((ti, None, p, c))
                edge_info.append(ei)

            # Solve (I - Q) * prob_col = R_col for each answer
            # Using Gaussian elimination with Fractions
            def solve_system(A, b_vec):
                """Solve Ax = b where A is n×n and b is length n, using Fractions."""
                nn = len(A)
                # Augmented matrix
                aug = [row[:] + [b_vec[i]] for i, row in enumerate(A)]
                for col in range(nn):
                    # Find pivot
                    pivot = None
                    for row in range(col, nn):
                        if aug[row][col] != 0:
                            pivot = row
                            break
                    if pivot is None:
                        continue
                    aug[col], aug[pivot] = aug[pivot], aug[col]
                    piv_val = aug[col][col]
                    for j in range(col, nn + 1):
                        aug[col][j] /= piv_val
                    for row in range(nn):
                        if row != col and aug[row][col] != 0:
                            factor = aug[row][col]
                            for j in range(col, nn + 1):
                                aug[row][j] -= factor * aug[col][j]
                return [aug[i][nn] for i in range(nn)]

            # For each answer, solve for absorption probability from each state
            prob_from_state = [[Fraction(0)] * num_answers for _ in range(n)]
            for ai in range(num_answers):
                # (I - Q) * x = R[:, ai]
                IminusQ = [[Fraction(int(i == j)) - Q[i][j] for j in range(n)] for i in range(n)]
                rhs = [R[i][ai] for i in range(n)]
                sol = solve_system(IminusQ, rhs)
                for si in range(n):
                    prob_from_state[si][ai] = sol[si]

            # Now solve for unconditional weighted cost ucost[s][a]
            # ucost[s][a] = sum_edges (w/W) * [if target is answer_a: c; if target is state t: c*prob[t][a] + ucost[t][a]]
            # Rearranged: ucost[s][a] - sum_{t state} (w/W)*ucost[t][a] = sum_edges (w/W) * [if answer_a: c; if state t: c*prob[t][a]]
            # So (I - Q_weighted) * ucost_col = rhs_col
            # where Q_weighted[s][t] = sum of (w/W) for edges s->t (same as Q actually)
            # and rhs[s] = sum_edges (w/W) * c * (indicator or prob)

            ucost_from_state = [[Fraction(0)] * num_answers for _ in range(n)]
            for ai in range(num_answers):
                rhs = [Fraction(0)] * n
                for si in range(n):
                    val = Fraction(0)
                    for ti, tai, p, c in edge_info[si]:
                        if ti is None:
                            # target is answer
                            if tai == ai:
                                val += p * c
                        else:
                            # target is state
                            val += p * (c * prob_from_state[ti][ai] + ucost_from_state[ti][ai])
                    rhs[si] = val

                # But ucost depends on itself! Need to solve system.
                # ucost[s][a] - sum_{edges s->t state} (w/W)*ucost[t][a] = sum_edges (w/W)*c*(indicator or prob)
                # The RHS also contains ucost terms... no wait.
                # Let me re-derive:
                # ucost[s][a] = sum_edges (w/W) * f(edge, a)
                # where f = c if target==answer_a, else c*prob[t][a] + ucost[t][a] if target is state t
                # So: ucost[s][a] = sum_{edges to answer_a} (w/W)*c + sum_{edges to state t} (w/W)*(c*prob[t][a] + ucost[t][a])
                # ucost[s][a] - sum_{edges to state t} (w/W)*ucost[t][a] = sum_{edges to answer_a} (w/W)*c + sum_{edges to state t} (w/W)*c*prob[t][a]
                # This is (I-Q)*ucost_col = rhs where rhs doesn't depend on ucost

                rhs2 = [Fraction(0)] * n
                for si in range(n):
                    val = Fraction(0)
                    for ti, tai, p, c in edge_info[si]:
                        if ti is None:
                            if tai == ai:
                                val += p * c
                        else:
                            val += p * c * prob_from_state[ti][ai]
                    rhs2[si] = val

                IminusQ = [[Fraction(int(i == j)) - Q[i][j] for j in range(n)] for i in range(n)]
                sol = solve_system(IminusQ, rhs2)
                for si in range(n):
                    ucost_from_state[si][ai] = sol[si]

            # Extract results for start state
            start_idx = state_idx[start]
            abs_probs = []
            weighted_costs = []
            for ai in range(num_answers):
                p = prob_from_state[start_idx][ai]
                abs_probs.append(_simplify(p.numerator, p.denominator))
                wc = ucost_from_state[start_idx][ai]
                weighted_costs.append(_simplify(wc.numerator, wc.denominator))

            method_result[pname] = [abs_probs, weighted_costs]

        result[mid] = method_result

    return result
