def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a


def _simplify(n, d):
    g = _gcd(abs(n), abs(d))
    return [n // g, d // g]


def compute(payload):
    answers = payload["answers"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    num_answers = len(answers)

    # Prior: map profile name -> simplified fraction [num, den]
    total_weight = sum(profiles.values())
    prior = {}
    for pname, w in profiles.items():
        prior[pname] = _simplify(w, total_weight)

    # Early decision tables for each method
    decision_tables = {}
    for method in methods:
        mid = method["id"]
        max_votes = method["votes"]
        table = {}
        initial = tuple([0] * num_answers)
        queue = [initial]
        visited = set()
        visited.add(initial)

        while queue:
            state = queue.pop(0)
            votes_so_far = sum(state)
            remaining = max_votes - votes_so_far

            winner = None
            if remaining == 0:
                best_idx = 0
                best_count = state[0]
                for i in range(1, num_answers):
                    if state[i] > best_count:
                        best_count = state[i]
                        best_idx = i
                winner = best_idx
            else:
                best_idx = 0
                best_count = state[0]
                for i in range(1, num_answers):
                    if state[i] > best_count:
                        best_count = state[i]
                        best_idx = i

                can_be_overtaken = False
                for j in range(num_answers):
                    if j == best_idx:
                        continue
                    potential_j = state[j] + remaining
                    if potential_j > best_count:
                        can_be_overtaken = True
                        break
                    elif potential_j == best_count and j < best_idx:
                        can_be_overtaken = True
                        break

                if not can_be_overtaken:
                    winner = best_idx

            key = ",".join(str(x) for x in state)
            table[key] = winner

            if winner is not None or votes_so_far >= max_votes:
                continue

            for i in range(num_answers):
                new_state = list(state)
                new_state[i] += 1
                new_state = tuple(new_state)
                if new_state not in visited:
                    visited.add(new_state)
                    queue.append(new_state)

        decision_tables[mid] = table

    return [prior, decision_tables]
