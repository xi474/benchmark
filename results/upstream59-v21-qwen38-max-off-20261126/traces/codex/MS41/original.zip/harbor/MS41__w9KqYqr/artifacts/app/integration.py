from fractions import Fraction


def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a


def _simplify(n, d):
    if n == 0:
        return [0, 1]
    g = _gcd(abs(n), abs(d))
    return [n // g, d // g]


def combine(payload, left, right):
    answers = payload["answers"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    correct = payload["correct"]
    num_answers = len(answers)
    correct_idx = answers.index(correct)

    prior_map = left[0]       # profile_name -> [num, den]
    decision_tables = left[1]  # method_id -> {state_key: winner_idx_or_null}
    absorption = right         # method_id -> profile_name -> [abs_probs, weighted_costs]

    results = []

    for method in methods:
        mid = method["id"]
        max_votes = method["votes"]
        dt = decision_tables[mid]

        # For each profile, compute the method's outcome distribution
        # Then weight by profile prior

        # Overall accumulators
        total_prob = [Fraction(0)] * num_answers
        total_unresolved = Fraction(0)
        total_launches = Fraction(0)
        total_cost_correct = Fraction(0)  # E[cost * I(correct)]
        total_prob_correct = Fraction(0)

        for pname, pw_raw in profiles.items():
            pw = Fraction(pw_raw, sum(profiles.values()))
            abs_data = absorption[mid][pname]
            abs_probs = [Fraction(p[0], p[1]) for p in abs_data[0]]
            weighted_costs = [Fraction(wc[0], wc[1]) for wc in abs_data[1]]

            # Probability that a single ballot is unresolved
            p_resolved = sum(abs_probs)
            p_unresolved_ballot = Fraction(1) - p_resolved

            # Conditional expected cost given resolved to answer i
            # weighted_costs[i] = E[cost * I(answer_i)] = P(answer_i) * E[cost | answer_i]
            # So E[cost | answer_i] = weighted_costs[i] / abs_probs[i] if abs_probs[i] > 0

            # We need to model the sequential voting process.
            # State: tuple of vote counts per answer
            # At each state, check decision table. If decided, stop.
            # Otherwise, launch next ballot.
            # Ballot outcomes: answer_0 with prob abs_probs[0], ..., answer_{n-1} with prob abs_probs[n-1],
            #                   unresolved with prob p_unresolved_ballot
            # Cost of ballot: if resolved to answer_i, expected cost = weighted_costs[i]/abs_probs[i]
            #                 (but we track total cost, so we need E[cost] unconditionally for each path)

            # We'll do DP over vote-count states.
            # For each reachable state s (before decision):
            #   P(reach s) = probability of reaching this state
            #   E[total_cost_so_far | reach s] = expected accumulated cost when reaching s
            #   P(unresolved_so_far | reach s) ... actually unresolved is absorbing

            # Let's track:
            # reach_prob[s] = P(reaching state s without prior resolution or unresolved)
            # reach_cost[s] = E[total cost accumulated up to reaching s] (unconditional, i.e., multiplied by reach_prob)
            # From state s, we launch a ballot:
            #   - With prob p_unresolved_ballot: session becomes unresolved
            #     Contribution to unresolved: reach_prob[s] * p_unresolved_ballot
            #     Contribution to cost_if_correct: none (unresolved doesn't count)
            #     Launches contribution: reach_prob[s] * p_unresolved_ballot (the ballot was launched)
            #   - With prob abs_probs[i]: move to state s + e_i
            #     Cost added: weighted_costs[i] (this is E[cost * I(answer_i)] for this ballot)
            #     New reach_prob[s+e_i] += reach_prob[s] * abs_probs[i]
            #     New reach_cost[s+e_i] += reach_cost[s] * abs_probs[i] + reach_prob[s] * weighted_costs[i]
            #       Wait, need to be more careful. reach_cost should be E[cost | reach] * P(reach) = E[cost * I(reach)]
            #       Actually let's track:
            #       rp[s] = P(reach s)
            #       rc[s] = E[total_cost * I(reach s)] = rp[s] * E[total_cost | reach s]

            # Initial state
            initial = tuple([0] * num_answers)
            rp = {initial: Fraction(1)}
            rc = {initial: Fraction(0)}

            # Process states in order of total votes
            processed = set()
            # We need to process in BFS order by total votes
            from collections import deque
            queue = deque([initial])

            profile_prob = [Fraction(0)] * num_answers
            profile_unresolved = Fraction(0)
            profile_launches = Fraction(0)
            profile_cost_correct_contrib = Fraction(0)  # E[total_cost * I(correct winner)]

            while queue:
                state = queue.popleft()
                if state in processed:
                    continue
                processed.add(state)

                cur_rp = rp[state]
                cur_rc = rc[state]
                if cur_rp == 0:
                    continue

                state_key = ",".join(str(x) for x in state)
                winner = dt.get(state_key)

                if winner is not None:
                    # Already decided at this state (no more ballots needed)
                    # But wait: the decision table includes the initial state check.
                    # If winner is decided at state with 0 votes, that means max_votes=0? No, votes >= 1.
                    # Actually the decision table marks states where the leader is guaranteed to win.
                    # When we reach such a state, we stop launching ballots.
                    # The number of launches so far = sum(state) ballots have been launched.
                    # But we didn't launch a ballot AT this state; we arrived here after the last ballot.
                    # Actually, let me reconsider. The initial state (0,0,...,0) has null (not decided).
                    # After each ballot, we update counts and check. So launches = sum(state).
                    # At a decided state, no more ballots are launched.
                    profile_prob[winner] += cur_rp
                    # Cost: cur_rc is E[total_cost * I(reach this state)]
                    # If winner == correct_idx, contribute to cost_correct
                    if winner == correct_idx:
                        profile_cost_correct_contrib += cur_rc
                    continue

                # Not decided, need to launch another ballot
                votes_so_far = sum(state)
                if votes_so_far >= max_votes:
                    # Should have been decided by decision table, but just in case
                    # Determine winner by current counts
                    best_idx = 0
                    best_count = state[0]
                    for i in range(1, num_answers):
                        if state[i] > best_count:
                            best_count = state[i]
                            best_idx = i
                    profile_prob[best_idx] += cur_rp
                    if best_idx == correct_idx:
                        profile_cost_correct_contrib += cur_rc
                    continue

                # Launch a ballot
                # This ballot counts toward launches regardless of outcome
                profile_launches += cur_rp  # P(reach this state) * 1 ballot

                # Unresolved outcome
                if p_unresolved_ballot > 0:
                    profile_unresolved += cur_rp * p_unresolved_ballot

                # Resolved outcomes
                for ai in range(num_answers):
                    if abs_probs[ai] == 0:
                        continue
                    new_state = list(state)
                    new_state[ai] += 1
                    new_state = tuple(new_state)

                    new_rp = cur_rp * abs_probs[ai]
                    # New cost contribution: existing cost + this ballot's cost
                    # rc tracks E[total_cost * I(reach)]
                    # When transitioning: new_rc = cur_rc * abs_probs[ai] + cur_rp * weighted_costs[ai]
                    # Because: E[(old_cost + ballot_cost) * I(reach new)] 
                    #        = E[old_cost * I(reach old) * I(ballot=ai)] + E[ballot_cost * I(reach old) * I(ballot=ai)]
                    #        = cur_rc * abs_probs[ai] + cur_rp * weighted_costs[ai]
                    new_rc = cur_rc * abs_probs[ai] + cur_rp * weighted_costs[ai]

                    if new_state in rp:
                        rp[new_state] += new_rp
                        rc[new_state] += new_rc
                    else:
                        rp[new_state] = new_rp
                        rc[new_state] = new_rc
                        queue.append(new_state)

            # Weight by profile prior
            for ai in range(num_answers):
                total_prob[ai] += pw * profile_prob[ai]
            total_unresolved += pw * profile_unresolved
            total_launches += pw * profile_launches
            total_cost_correct += pw * profile_cost_correct_contrib
            total_prob_correct += pw * profile_prob[correct_idx]

        # Format output
        prob_out = [_simplify(total_prob[ai].numerator, total_prob[ai].denominator) for ai in range(num_answers)]
        unresolved_out = _simplify(total_unresolved.numerator, total_unresolved.denominator)
        launches_out = _simplify(total_launches.numerator, total_launches.denominator)

        if total_prob_correct == 0:
            cost_if_correct_out = None
        else:
            cic = total_cost_correct / total_prob_correct
            cost_if_correct_out = _simplify(cic.numerator, cic.denominator)

        results.append({
            "id": mid,
            "prob": prob_out,
            "unresolved": unresolved_out,
            "launches": launches_out,
            "cost_if_correct": cost_if_correct_out,
        })

    # Sort by correct probability descending, then method id ascending
    results.sort(key=lambda r: (-Fraction(r["prob"][correct_idx][0], r["prob"][correct_idx][1]), r["id"]))

    return results
