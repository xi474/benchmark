def compute(payload):
    """为每门课生成 [项目统计,传递可达表]；统计行 [ID,标签,[成绩和分子,分母],非空数] 按 ID 排序，保留零成绩。可达表的值为有序 ID 数组。"""
    courses = payload["courses"]
    result = {}
    for course_key in sorted(courses.keys()):
        course = courses[course_key]
        items = course["items"]
        edges = course.get("edges", [])

        # Build item stats: [ID, label, [score_sum_numerator, denominator], non_null_count]
        stats = []
        item_ids = []
        for item in items:
            item_id = item[0]
            label = item[1]
            scores = item[2]
            non_null = [s for s in scores if s is not None]
            score_sum = sum(non_null)
            count = len(non_null)
            stats.append([item_id, label, [score_sum, count], count])
            item_ids.append(item_id)

        # Sort stats by ID
        stats.sort(key=lambda x: x[0])

        # Build adjacency for transitive reachability
        id_set = set(item_ids)
        adj = {iid: set() for iid in item_ids}
        for edge in edges:
            src, dst = edge[0], edge[1]
            if src in id_set and dst in id_set:
                adj[src].add(dst)

        # Compute transitive closure via BFS/DFS from each node
        reach = {}
        for start in item_ids:
            visited = set()
            stack = list(adj[start])
            while stack:
                node = stack.pop()
                if node not in visited:
                    visited.add(node)
                    stack.extend(adj[node] - visited)
            reach[start] = sorted(visited)

        result[course_key] = [stats, reach]

    return result
