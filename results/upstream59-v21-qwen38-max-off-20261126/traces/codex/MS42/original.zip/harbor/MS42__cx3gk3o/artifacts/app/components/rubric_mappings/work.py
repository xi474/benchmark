def compute(payload):
    """返回 [所有可行映射位掩码,旧标签到各新标签的掩码映射]；位序按新标签升序的排列枚举。"""
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    new_labels_set = set()
    for ol in old_labels:
        for nl in rubrics[ol]:
            new_labels_set.add(nl)
    new_labels_sorted = sorted(new_labels_set)
    new_label_to_idx = {nl: i for i, nl in enumerate(new_labels_sorted)}
    n_new = len(new_labels_sorted)
    n_old = len(old_labels)

    # Build per-old-label list of allowed new label indices
    allowed_lists = {}
    for ol in old_labels:
        allowed_lists[ol] = [new_label_to_idx[nl] for nl in rubrics[ol]]

    # Enumerate all valid bijections via backtracking
    # Each bijection is assigned a sequential index (bit position)
    bijections = []  # list of dicts: old_label -> new_label_idx

    def backtrack(idx, assignment, used_new):
        if idx == n_old:
            bijections.append(dict(assignment))
            return
        ol = old_labels[idx]
        for ni in allowed_lists[ol]:
            if ni not in used_new:
                assignment[ol] = ni
                used_new.add(ni)
                backtrack(idx + 1, assignment, used_new)
                del assignment[ol]
                used_new.remove(ni)

    backtrack(0, {}, set())

    # all_feasible_mask: bitmask of bijection indices
    all_feasible_mask = 0
    for bi in range(len(bijections)):
        all_feasible_mask |= (1 << bi)

    # per old label, per new label: bitmask of bijection indices where this mapping occurs
    label_map = {}
    for ol in old_labels:
        d = {}
        for nl in rubrics[ol]:
            ni = new_label_to_idx[nl]
            mask = 0
            for bi, bij in enumerate(bijections):
                if bij.get(ol) == ni:
                    mask |= (1 << bi)
            if mask:
                d[nl] = mask
        label_map[ol] = d

    return [all_feasible_mask, label_map]
