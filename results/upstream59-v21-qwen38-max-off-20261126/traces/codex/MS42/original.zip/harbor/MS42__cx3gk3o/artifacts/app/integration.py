from fractions import Fraction
from itertools import product


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    rubrics = payload.get("rubrics", {})
    courses = payload.get("courses", {})

    # left = [all_feasible_mask, per_old_label_masks]
    all_feasible_mask = left[0]
    per_old_label_masks = left[1]

    # right = {course_key: [stats, reachability]}
    course_data = right

    # Group courses by prefix
    prefixes = {}
    for ck in courses:
        parts = ck.rsplit("-", 1)
        if len(parts) == 2:
            prefix, suffix = parts
            if prefix not in prefixes:
                prefixes[prefix] = {}
            prefixes[prefix][suffix] = ck

    # Only consider prefixes with both 2013J and 2014J
    valid_prefixes = []
    for prefix, suffixes in sorted(prefixes.items()):
        if "2013J" in suffixes and "2014J" in suffixes:
            valid_prefixes.append(prefix)

    # Collect all old labels and new labels from rubrics
    old_labels = sorted(rubrics.keys()) if rubrics else []
    new_labels_set = set()
    for ol in old_labels:
        for nl in rubrics[ol]:
            new_labels_set.add(nl)
    new_labels_sorted = sorted(new_labels_set)

    # Enumerate all valid bijections (old_label -> new_label)
    # We need actual bijection dicts, not just bitmasks
    def enumerate_bijections():
        n = len(old_labels)
        new_to_idx = {nl: i for i, nl in enumerate(new_labels_sorted)}
        allowed = {}
        for ol in old_labels:
            allowed[ol] = [new_to_idx[nl] for nl in rubrics[ol]]
        results = []
        def bt(idx, asgn, used):
            if idx == n:
                results.append({ol: new_labels_sorted[asgn[ol]] for ol in old_labels})
                return
            ol = old_labels[idx]
            for ni in allowed[ol]:
                if ni not in used:
                    asgn[ol] = ni
                    used.add(ni)
                    bt(idx + 1, asgn, used)
                    del asgn[ol]
                    used.remove(ni)
        bt(0, {}, set())
        return results

    bijections = enumerate_bijections()

    # For each valid prefix, find candidate pairs
    # A candidate pair: (prefix, old_id, new_id) where labels are compatible via some bijection
    # and both have at least one non-null score

    # Build item info from course_data
    # course_data[ck] = [stats, reach]
    # stats = [[id, label, [sum, count], non_null_count], ...]

    def get_item_info(course_key):
        """Returns dict of id -> {label, score_sum, score_count, scores_list}"""
        if course_key not in course_data:
            return {}, {}
        stats, reach = course_data[course_key]
        items = {}
        for s in stats:
            iid, label, frac, cnt = s[0], s[1], s[2], s[3]
            items[iid] = {"label": label, "score_sum": frac[0], "score_count": frac[1], "non_null": cnt}
        return items, reach

    # For each prefix, collect old items and new items
    # Then find all valid pairings considering order constraints and bijection consistency

    # Global approach: enumerate alignments across all prefixes simultaneously
    # since bijection must be globally consistent

    # Step 1: For each prefix, enumerate candidate (old_id, new_id) pairs
    prefix_candidates = {}
    prefix_items_old = {}
    prefix_items_new = {}
    prefix_reach_old = {}
    prefix_reach_new = {}

    for prefix in valid_prefixes:
        old_ck = prefixes[prefix]["2013J"]
        new_ck = prefixes[prefix]["2014J"]
        old_items, old_reach = get_item_info(old_ck)
        new_items, new_reach = get_item_info(new_ck)
        prefix_items_old[prefix] = old_items
        prefix_items_new[prefix] = new_items
        prefix_reach_old[prefix] = old_reach
        prefix_reach_new[prefix] = new_reach

        candidates = []
        for oid, oinfo in old_items.items():
            if oinfo["non_null"] == 0:
                continue
            for nid, ninfo in new_items.items():
                if ninfo["non_null"] == 0:
                    continue
                # Check if there exists at least one bijection mapping oinfo['label'] -> ninfo['label']
                ol = oinfo["label"]
                nl = ninfo["label"]
                if ol in per_old_label_masks and nl in per_old_label_masks.get(ol, {}):
                    candidates.append((oid, nid, ol, nl))
        prefix_candidates[prefix] = candidates

    # Step 2: For each prefix, we need to select a subset of candidates such that:
    # - Each old_id used at most once, each new_id used at most once
    # - Order constraints preserved
    # - All label mappings consistent with at least one global bijection

    # Since max 3 course pairs, max 6 items per course, max 5 labels, this is small enough
    # to enumerate.

    # Strategy: enumerate all possible subsets of candidate pairs across all prefixes,
    # check constraints, track best.

    # But first, let's think about order constraints more carefully.
    # "对同一课程中任两对，旧考核之间的先后关系必须与新考核之间完全一致，原本不可比较的两项仍须不可比较。"
    # For any two pairs in the same course:
    # - If old_a reaches old_b (transitively), then new_a must reach new_b
    # - If old_b reaches old_a, then new_b must reach new_a
    # - If neither reaches the other (incomparable), then new_a and new_b must also be incomparable

    def check_order_consistency(pairs_for_course, old_reach, new_reach):
        """Check that order relations are preserved for all pairs within a course."""
        for i in range(len(pairs_for_course)):
            for j in range(i + 1, len(pairs_for_course)):
                oid_i, nid_i = pairs_for_course[i][0], pairs_for_course[i][1]
                oid_j, nid_j = pairs_for_course[j][0], pairs_for_course[j][1]
                # Old relation
                old_i_reaches_j = oid_j in old_reach.get(oid_i, [])
                old_j_reaches_i = oid_i in old_reach.get(oid_j, [])
                # New relation
                new_i_reaches_j = nid_j in new_reach.get(nid_i, [])
                new_j_reaches_i = nid_i in new_reach.get(nid_j, [])
                if old_i_reaches_j != new_i_reaches_j:
                    return False
                if old_j_reaches_i != new_j_reaches_i:
                    return False
        return True

    def check_bijection_consistency(label_pairs):
        """Check if a set of (old_label, new_label) pairs can be extended to a valid bijection."""
        # label_pairs is a set of (ol, nl) tuples
        # Must be consistent with at least one bijection in our list
        for bij in bijections:
            ok = True
            for ol, nl in label_pairs:
                if bij.get(ol) != nl:
                    ok = False
                    break
            if ok:
                return True
        return False

    # Now enumerate alignments. Since the problem is small, we can use recursive enumeration.
    # For each prefix, generate all valid matchings (subsets of candidates respecting uniqueness + order).
    # Then combine across prefixes checking global bijection consistency.

    # Generate per-prefix valid matchings
    def gen_matchings(prefix):
        cands = prefix_candidates[prefix]
        old_reach = prefix_reach_old[prefix]
        new_reach = prefix_reach_new[prefix]
        n = len(cands)
        results = []

        def bt(idx, selected, used_old, used_new):
            # Current selection is valid so far; record it
            if selected:
                # Check order consistency
                if check_order_consistency(selected, old_reach, new_reach):
                    results.append(list(selected))
            elif idx == n:
                # Empty matching is always valid
                results.append([])
            if idx == n:
                return
            # Skip this candidate
            bt(idx + 1, selected, used_old, used_new)
            # Include this candidate
            oid, nid, ol, nl = cands[idx]
            if oid not in used_old and nid not in used_new:
                used_old.add(oid)
                used_new.add(nid)
                selected.append((oid, nid, ol, nl))
                bt(idx + 1, selected, used_old, used_new)
                selected.pop()
                used_old.remove(oid)
                used_new.remove(nid)

        # Also include empty matching
        bt(0, [], set(), set())
        # Deduplicate (empty might appear multiple times)
        seen = set()
        unique = []
        for m in results:
            key = tuple(sorted((a, b) for a, b, _, _ in m))
            if key not in seen:
                seen.add(key)
                unique.append(m)
        return unique

    # For efficiency with small inputs, enumerate all combinations
    all_prefix_matchings = {}
    for prefix in valid_prefixes:
        all_prefix_matchings[prefix] = gen_matchings(prefix)

    # Now combine across prefixes
    best_pairs = 0
    best_support = 0
    best_alignments = []  # list of frozensets of (prefix, old_id, new_id)

    prefix_list = valid_prefixes

    def combine_prefixes(pi, current_alignment, current_label_pairs, current_pairs, current_support):
        nonlocal best_pairs, best_support, best_alignments
        if pi == len(prefix_list):
            # Check global bijection consistency
            if not current_label_pairs or check_bijection_consistency(current_label_pairs):
                alignment_key = frozenset(current_alignment)
                if current_pairs > best_pairs or (current_pairs == best_pairs and current_support > best_support):
                    best_pairs = current_pairs
                    best_support = current_support
                    best_alignments = [alignment_key]
                elif current_pairs == best_pairs and current_support == best_support:
                    best_alignments.append(alignment_key)
            return
        prefix = prefix_list[pi]
        for matching in all_prefix_matchings[prefix]:
            new_alignment = list(current_alignment)
            new_label_pairs = set(current_label_pairs)
            added_pairs = 0
            added_support = 0
            for oid, nid, ol, nl in matching:
                new_alignment.append((prefix, oid, nid))
                new_label_pairs.add((ol, nl))
                added_pairs += 1
                old_info = prefix_items_old[prefix][oid]
                new_info = prefix_items_new[prefix][nid]
                added_support += min(old_info["non_null"], new_info["non_null"])
            combine_prefixes(pi + 1, new_alignment, new_label_pairs,
                           current_pairs + added_pairs, current_support + added_support)

    combine_prefixes(0, [], set(), 0, 0)

    # Compute results
    ways = len(best_alignments)

    # Forced pairs: intersection of all optimal alignments
    if ways > 0:
        forced_set = best_alignments[0]
        for a in best_alignments[1:]:
            forced_set = forced_set & a
        forced = sorted(forced_set)  # lex sort on (prefix, old_id, new_id)
    else:
        forced = []

    # Drift computation
    if best_pairs == 0:
        drift = None
    else:
        drifts = []
        for alignment in best_alignments:
            old_total = Fraction(0)
            old_count = 0
            new_total = Fraction(0)
            new_count = 0
            for prefix, oid, nid in alignment:
                old_info = prefix_items_old[prefix][oid]
                new_info = prefix_items_new[prefix][nid]
                # Get actual scores from original data
                old_ck = prefixes[prefix]["2013J"]
                new_ck = prefixes[prefix]["2014J"]
                old_scores = [s for s in courses[old_ck]["items"] if s[0] == oid][0][2]
                new_scores = [s for s in courses[new_ck]["items"] if s[0] == nid][0][2]
                for s in old_scores:
                    if s is not None:
                        old_total += s
                        old_count += 1
                for s in new_scores:
                    if s is not None:
                        new_total += s
                        new_count += 1
            if old_count > 0 and new_count > 0:
                old_mean = old_total / old_count
                new_mean = new_total / new_count
                diff = new_mean - old_mean
                drifts.append(diff)
            else:
                drifts.append(Fraction(0))
        min_drift = min(drifts)
        max_drift = max(drifts)
        drift = [
            [min_drift.numerator, min_drift.denominator],
            [max_drift.numerator, max_drift.denominator]
        ]

    return {
        "pairs": best_pairs,
        "support": best_support,
        "ways": ways,
        "forced": [list(f) for f in forced],
        "drift": drift
    }
