"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    matrix = payload["matrix"]
    num_block_rows = len(matrix)
    num_block_cols = len(matrix[0])
    row_sizes = [matrix[i][0]["rows"] for i in range(num_block_rows)]
    col_sizes = [matrix[0][j]["cols"] for j in range(num_block_cols)]
    return {"row_sizes": row_sizes, "col_sizes": col_sizes}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
