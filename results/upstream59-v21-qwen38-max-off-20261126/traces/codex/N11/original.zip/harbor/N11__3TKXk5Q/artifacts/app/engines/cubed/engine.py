"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    squared = payload["squared"]
    matrix = payload["matrix"]
    layout = payload["layout"]
    sq_blocks = squared["blocks"]
    n = len(sq_blocks)
    result = []
    for i in range(n):
        row = []
        for j in range(n):
            r_rows = sq_blocks[i][0]["rows"]
            r_cols = matrix[0][j]["cols"]
            acc = [[0] * r_cols for _ in range(r_rows)]
            all_zero = True
            for k in range(n):
                a = sq_blocks[i][k]
                b = matrix[k][j]
                if a["data"] is None or b["data"] is None:
                    continue
                all_zero = False
                ad = a["data"]
                bd = b["data"]
                a_rows = len(ad)
                a_cols = len(ad[0])
                b_cols = len(bd[0])
                for ri in range(a_rows):
                    for ci in range(b_cols):
                        s = 0
                        for ki in range(a_cols):
                            s += ad[ri][ki] * bd[ki][ci]
                        acc[ri][ci] += s
            if all_zero:
                row.append({"rows": r_rows, "cols": r_cols, "data": None})
            else:
                row.append({"rows": r_rows, "cols": r_cols, "data": acc})
        result.append(row)
    return {"layout": layout, "blocks": result}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
