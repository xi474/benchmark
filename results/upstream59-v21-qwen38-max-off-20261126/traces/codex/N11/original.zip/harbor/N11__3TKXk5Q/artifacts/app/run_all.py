"""Project entry point for N11."""
import json
from pathlib import Path
from runtime import read, build, module

def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    # Load contracts
    block_layout_contract = read(root / "engines/block_layout/contract.json")
    squared_contract = read(root / "engines/squared/contract.json")
    cubed_contract = read(root / "engines/cubed/contract.json")

    # Load engine modules
    bl_mod = module(root, "engines/block_layout/engine.py")
    sq_mod = module(root, "engines/squared/engine.py")
    cu_mod = module(root, "engines/cubed/engine.py")

    # Build components in dependency order
    bl_result = build(root, block_layout_contract, bl_mod.transform)
    sq_result = build(root, squared_contract, sq_mod.transform)
    cu_result = build(root, cubed_contract, cu_mod.transform)

    # Build final report
    result_file_path = root / delivery["result_file"]
    result_value = read(result_file_path)

    report = {
        "task": "N11",
        "results": {
            "block_layout": bl_result,
            "squared": sq_result,
            "cubed": cu_result,
        },
        "result": result_value,
    }

    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")

if __name__ == '__main__':
    main()
