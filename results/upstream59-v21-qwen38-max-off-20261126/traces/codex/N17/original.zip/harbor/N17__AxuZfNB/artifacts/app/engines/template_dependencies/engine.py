"""Implement the business transform. I/O helpers are supplied and editable here."""
"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import re
from runtime import build


def _extract_conf_chains(expr):
    """Extract conf access chains from a Python-compatible expression string.
    Converts subscript ['key'] to dot notation. Returns list of dotted chains."""
    chains = []
    # Match conf as standalone identifier followed by attribute/subscript access
    pattern = r'(?<![A-Za-z0-9_])conf((?:\.[A-Za-z_]\w*|\[[\'"][^\'"]+[\'"]\])+)'
    for m in re.finditer(pattern, expr):
        chain_raw = m.group(1)
        # Convert ['key'] or ["key"] to .key
        parts = []
        i = 0
        while i < len(chain_raw):
            if chain_raw[i] == '.':
                j = i + 1
                while j < len(chain_raw) and (chain_raw[j].isalnum() or chain_raw[j] == '_'):
                    j += 1
                parts.append(chain_raw[i+1:j])
                i = j
            elif chain_raw[i] == '[':
                # Find matching ]
                j = chain_raw.index(']', i)
                inner = chain_raw[i+1:j].strip()
                # Remove quotes
                if (inner.startswith("'") and inner.endswith("'")) or \
                   (inner.startswith('"') and inner.endswith('"')):
                    parts.append(inner[1:-1])
                i = j + 1
            else:
                i += 1
        if parts:
            chains.append('.'.join(parts))
    return chains


def _match_longest_prefix(chain, options_set):
    """Find the longest prefix of chain that is in options_set."""
    parts = chain.split('.')
    best = None
    for i in range(len(parts), 0, -1):
        candidate = '.'.join(parts[:i])
        if candidate in options_set:
            best = candidate
            break
    return best


def transform(payload, contract):
    templates = payload['templates']
    options = payload['options']
    options_set = set(options)
    result = {}
    for tid, text in templates.items():
        keys = set()
        # Find all {{ ... }} expressions
        for m in re.finditer(r'\{\{(.*?)\}\}', text, re.DOTALL):
            expr = m.group(1)
            chains = _extract_conf_chains(expr)
            for chain in chains:
                matched = _match_longest_prefix(chain, options_set)
                if matched:
                    keys.add(matched)
        result[tid] = sorted(keys)
    return result


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
