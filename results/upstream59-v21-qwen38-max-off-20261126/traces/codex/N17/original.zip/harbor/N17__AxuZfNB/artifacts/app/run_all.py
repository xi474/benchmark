"""Implement the project entry point using the published business contracts."""
"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, build

ROOT = Path(__file__).resolve().parent

CONTRACTS = [
    "engines/template_dependencies/contract.json",
    "engines/reverse_index/contract.json",
    "engines/stylesheet_updates/contract.json",
]


def main():
    results = {}
    for cpath in CONTRACTS:
        contract = read(ROOT / cpath)
        engine_dir = ROOT / cpath.replace("/contract.json", "")
        mod = __import__("runtime").module(str(engine_dir), "engine.py")
        value = mod.build_component(str(ROOT), contract)
        results[contract["component"]] = value

    result_file = "outputs/stylesheet_updates.json"
    report = {
        "task": "N17",
        "results": results,
        "result": read(ROOT / result_file),
    }
    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == '__main__':
    main()
