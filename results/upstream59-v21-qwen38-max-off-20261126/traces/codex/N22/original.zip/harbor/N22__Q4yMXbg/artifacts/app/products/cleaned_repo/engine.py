"""Implement the business transform. I/O helpers are supplied and editable here."""
"""cleaned_repo: remove secret tag from repo, clean reflog/unreachable, return bundle+files+messages."""
import base64
import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path
from runtime import build


def _unpack_bundle(bundle_b64, dest):
    data = base64.b64decode(bundle_b64)
    tar_path = dest / "repo.tar.gz"
    tar_path.write_bytes(data)
    subprocess.run(["tar", "xzf", str(tar_path)], cwd=str(dest), check=True)
    tar_path.unlink()


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def transform(payload, contract):
    bundle_b64 = payload["bundle"]
    scan_result = payload["scan"]
    secret = scan_result["secret"]

    with tempfile.TemporaryDirectory(prefix="cleanrepo_") as td:
        repo_dir = Path(td) / "repo"
        repo_dir.mkdir()
        _unpack_bundle(bundle_b64, repo_dir)
        env = {**os.environ, "GIT_DIR": str(repo_dir / ".git")}
        work_env = {**env, "GIT_WORK_TREE": str(repo_dir)}

        # Expire all reflogs
        subprocess.run(
            ["git", "reflog", "expire", "--expire=now", "--all"],
            capture_output=True, text=True, env=env
        )

        # Prune unreachable objects aggressively
        subprocess.run(
            ["git", "gc", "--prune=now", "--aggressive"],
            capture_output=True, text=True, env=env
        )
        subprocess.run(
            ["git", "prune", "--expire=now"],
            capture_output=True, text=True, env=env
        )

        # Verify no secret remains in any object
        result = subprocess.run(
            ["git", "rev-list", "--all", "--objects"],
            capture_output=True, text=True, env=env
        )
        for line in result.stdout.splitlines():
            obj_hash = line.split()[0]
            cat = subprocess.run(
                ["git", "cat-file", "-p", obj_hash],
                capture_output=True, text=True, env=env
            )
            if secret in cat.stdout:
                raise RuntimeError(f"Secret still found in object {obj_hash}")

        # Also check fsck for any remaining unreachable
        fsck = subprocess.run(
            ["git", "fsck", "--unreachable", "--no-reflogs"],
            capture_output=True, text=True, env=env
        )
        for line in (fsck.stdout + fsck.stderr).splitlines():
            parts = line.split()
            if len(parts) >= 3:
                obj_hash = parts[2]
                cat = subprocess.run(
                    ["git", "cat-file", "-p", obj_hash],
                    capture_output=True, text=True, env=env
                )
                if secret in cat.stdout:
                    raise RuntimeError(f"Secret still in unreachable {obj_hash}")

        # Collect files (non-.git)
        files = {}
        for p in sorted(repo_dir.rglob("*")):
            if p.is_file() and ".git" not in p.parts:
                rel = p.relative_to(repo_dir).as_posix()
                files[rel] = _sha256_file(str(p))

        # Collect commit messages (newest first)
        log = subprocess.run(
            ["git", "log", "--format=%s"],
            capture_output=True, text=True, env=env
        )
        messages = [m for m in log.stdout.strip().split("\n") if m]

        # Create cleaned bundle
        out_tar = Path(td) / "cleaned.tar.gz"
        subprocess.run(
            ["tar", "czf", str(out_tar), "-C", str(repo_dir), "."],
            check=True
        )
        bundle_out = base64.b64encode(out_tar.read_bytes()).decode("ascii")

    return {"bundle": bundle_out, "files": files, "messages": messages}


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
