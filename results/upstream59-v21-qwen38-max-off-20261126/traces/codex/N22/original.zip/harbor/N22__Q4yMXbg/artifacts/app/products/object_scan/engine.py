"""Implement the business transform. I/O helpers are supplied and editable here."""
"""object_scan: extract secret[...] tag from unreachable git objects in bundle."""
import base64
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from runtime import build


def _unpack_bundle(bundle_b64, dest):
    data = base64.b64decode(bundle_b64)
    tar_path = dest / "repo.tar.gz"
    tar_path.write_bytes(data)
    subprocess.run(["tar", "xzf", str(tar_path)], cwd=str(dest), check=True)
    tar_path.unlink()


def transform(payload, contract):
    bundle_b64 = payload["bundle"]
    with tempfile.TemporaryDirectory(prefix="objscan_") as td:
        repo_dir = Path(td) / "repo"
        repo_dir.mkdir()
        _unpack_bundle(bundle_b64, repo_dir)
        env = {**os.environ, "GIT_DIR": str(repo_dir / ".git")}
        result = subprocess.run(
            ["git", "fsck", "--unreachable", "--no-reflogs"],
            capture_output=True, text=True, env=env
        )
        unreachable = []
        for line in (result.stdout + result.stderr).splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] in ("blob", "commit", "tree", "tag"):
                unreachable.append((parts[1], parts[2]))
        secret = None
        for obj_type, obj_hash in unreachable:
            cat = subprocess.run(
                ["git", "cat-file", "-p", obj_hash],
                capture_output=True, text=True, env=env
            )
            content = cat.stdout
            m = re.search(r'secret\[.*?\]', content)
            if m:
                secret = m.group(0)
                break
        if secret is None:
            all_objects = subprocess.run(
                ["git", "rev-list", "--all", "--objects"],
                capture_output=True, text=True, env=env
            )
            for line in all_objects.stdout.splitlines():
                obj_hash = line.split()[0]
                cat = subprocess.run(
                    ["git", "cat-file", "-p", obj_hash],
                    capture_output=True, text=True, env=env
                )
                m = re.search(r'secret\[.*?\]', cat.stdout)
                if m:
                    secret = m.group(0)
                    break
    return {"secret": secret}


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
