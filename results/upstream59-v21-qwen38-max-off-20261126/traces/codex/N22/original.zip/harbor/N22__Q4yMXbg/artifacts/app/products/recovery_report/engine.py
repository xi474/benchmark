"""Implement the business transform. I/O helpers are supplied and editable here."""
"""recovery_report: verify cleaned repo has no secret objects, report results."""
import base64
import hashlib
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from runtime import build


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def transform(payload, contract):
    scan_result = payload["scan"]
    cleaned_result = payload["cleaned"]
    secret = scan_result["secret"]
    bundle_b64 = cleaned_result["bundle"]

    with tempfile.TemporaryDirectory(prefix="recovery_") as td:
        repo_dir = Path(td) / "repo"
        repo_dir.mkdir()
        data = base64.b64decode(bundle_b64)
        tar_path = Path(td) / "cleaned.tar.gz"
        tar_path.write_bytes(data)
        subprocess.run(["tar", "xzf", str(tar_path)], cwd=str(repo_dir), check=True)
        tar_path.unlink()

        env = {**os.environ, "GIT_DIR": str(repo_dir / ".git")}

        # Enumerate ALL objects (reachable + unreachable)
        remaining = 0
        # Check reachable objects
        result = subprocess.run(
            ["git", "rev-list", "--all", "--objects"],
            capture_output=True, text=True, env=env
        )
        for line in result.stdout.splitlines():
            obj_hash = line.split()[0]
            cat = subprocess.run(
                ["git", "cat-file", "-p", obj_hash],
                capture_output=True, text=True, env=env
            )
            if re.search(r'secret\[.*?\]', cat.stdout):
                remaining += 1

        # Check unreachable too
        fsck = subprocess.run(
            ["git", "fsck", "--unreachable", "--no-reflogs"],
            capture_output=True, text=True, env=env
        )
        for line in (fsck.stdout + fsck.stderr).splitlines():
            parts = line.split()
            if len(parts) >= 3:
                obj_hash = parts[2]
                cat = subprocess.run(
                    ["git", "cat-file", "-p", obj_hash],
                    capture_output=True, text=True, env=env
                )
                if re.search(r'secret\[.*?\]', cat.stdout):
                    remaining += 1

    return {
        "secret": secret,
        "files": cleaned_result["files"],
        "messages": cleaned_result["messages"],
        "remaining_secret_objects": remaining
    }


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
