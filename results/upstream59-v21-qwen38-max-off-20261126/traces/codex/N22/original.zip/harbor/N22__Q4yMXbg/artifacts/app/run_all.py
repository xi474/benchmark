"""Implement the project entry point using the published business contracts."""
"""Project entry point: orchestrate components and produce final_report.json."""
import json
from pathlib import Path
from runtime import read, module

ROOT = Path(__file__).resolve().parent

COMPONENTS = [
    "object_scan",
    "cleaned_repo",
    "recovery_report",
]


def main():
    delivery = read(ROOT / "delivery.json")
    results = {}

    for name in COMPONENTS:
        contract_path = ROOT / "products" / name / "contract.json"
        contract = read(contract_path)
        engine = module(str(ROOT / "products" / name), "engine.py")
        result = engine.build_component(str(ROOT), contract)
        results[name] = result

    result_file = delivery["result_file"]
    result_value = read(ROOT / result_file)

    final = {
        "task": delivery["task"],
        "results": results,
        "result": result_value,
    }

    out = ROOT / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(final, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
