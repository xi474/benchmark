"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    orders_raw = payload["orders"]
    records = []
    for line in orders_raw:
        buyer = line[0:4]
        seller = line[4:8]
        book = line[8:12]
        amount = int(line[12:22])
        records.append({"buyer": buyer, "seller": seller, "book": book, "amount": amount})
    return records

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
