"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    accounts = payload["accounts"]
    books = payload["books"]
    orders = payload["orders"]
    journal = payload["journal"]

    acc_map = {a["id"]: a for a in accounts}
    book_map = {b["id"]: b for b in books}

    statuses = []
    for order in orders:
        buyer_id = order["buyer"]
        seller_id = order["seller"]
        book_id = order["book"]
        amount = order["amount"]

        buyer = acc_map.get(buyer_id)
        seller = acc_map.get(seller_id)
        book = book_map.get(book_id)

        if (buyer and seller and book
                and buyer_id != seller_id
                and amount > 0
                and buyer["balance"] >= amount
                and book["owner"] == seller_id):
            buyer["balance"] -= amount
            seller["balance"] += amount
            book["owner"] = buyer_id
            journal += book_id + str(amount).zfill(10) + seller_id + buyer_id
            statuses.append("accepted")
        else:
            statuses.append("rejected")

    def encode_account(a):
        return a["id"] + a["name"].ljust(20) + str(a["balance"]).zfill(10)

    def encode_book(b):
        return b["id"] + b["title"].ljust(20) + b["owner"]

    accounts_str = "".join(encode_account(a) for a in accounts)
    books_str = "".join(encode_book(b) for b in books)

    return {
        "accounts": accounts_str,
        "books": books_str,
        "journal": journal,
        "statuses": statuses
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
