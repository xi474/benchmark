"""Project entry point: orchestrate components and produce final_report.json."""
import json
from pathlib import Path
from runtime import read, module

ROOT = Path(__file__).resolve().parent


def main():
    (ROOT / "outputs").mkdir(exist_ok=True)

    delivery = read(ROOT / "delivery.json")
    component_outputs = delivery["component_outputs"]

    contracts = {}
    for name in component_outputs:
        contracts[name] = read(ROOT / f"products/{name}/contract.json")

    results = {}
    for name in ["accounts", "books", "orders"]:
        mod = module(ROOT, f"products/{name}/engine.py")
        results[name] = mod.build_component(str(ROOT), contracts[name])

    mod = module(ROOT, "products/settlement/engine.py")
    results["settlement"] = mod.build_component(str(ROOT), contracts["settlement"])

    report = {
        "task": "N24",
        "results": {name: results[name] for name in component_outputs},
        "result": results["settlement"]
    }
    report_path = ROOT / delivery["report"]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )


if __name__ == '__main__':
    main()
