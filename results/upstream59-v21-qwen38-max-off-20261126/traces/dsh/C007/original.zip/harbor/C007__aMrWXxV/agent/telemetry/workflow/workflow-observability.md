# Workflow 可观测性报告

- Trial：`C007__aMrWXxV__env`
- Task：`C007`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（45 节点 / 44 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：45；执行边：44（observed=0，inferred=44）
- Execution Trace Graph：`observed`；temporal_next 边 44，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_4dbb2ebb121643b2a1ccbbb1 -> tool:dsh:lead:call_bf836890e0f9464e8780dca8 -> tool:dsh:lead:call_0810f63d2a7e44b69083c267 -> tool:dsh:lead:call_d156dfbcecb84b68b8529150 -> tool:dsh:lead:call_180e05c0561e43bb871da58b -> tool:dsh:lead:call_955089ed6ba7429bad50bb0a -> tool:dsh:lead:call_59f8551537334aed9f5748d1 -> tool:dsh:lead:call_af3fae4a5ab545f69fe23e27 -> tool:dsh:lead:call_80ee9fd942fa422dadfb59cf -> tool:dsh:lead:call_98bdd298b04a473da8a9800b -> tool:dsh:lead:call_bff488f7e98f49688a147483 -> tool:dsh:lead:call_06d97a2d32ca493eaf1bd806 -> tool:dsh:lead:call_66aedbd6ee5e4c82b8557503 -> tool:dsh:lead:call_728721369e4d49a1981d957a -> tool:dsh:lead:call_681faabe28de4271a1c4cb39 -> tool:dsh:lead:call_703aed61074c42848644a092 -> tool:dsh:lead:call_5052e6e3ab9a4ce4b811922c -> tool:dsh:lead:call_236b4b09a5724afd9456fcc9 -> tool:dsh:lead:call_f89639c727314f85b3a8f7e3 -> tool:dsh:lead:call_bd0ad603cd154e4ba8615bba -> tool:dsh:lead:call_1c7fe91c660941d0b985b584 -> tool:dsh:lead:call_a474f55d6835436baf2af8a2 -> tool:dsh:lead:call_88e438a27e9f45b7b99639fb -> tool:dsh:lead:call_79c319416f654041a19647d0 -> tool:dsh:lead:call_5588b7d85b104a59a44a5e09 -> tool:dsh:lead:call_9ea71a528f1a4b748f1d5752 -> tool:dsh:lead:call_d558375560794eb38a8c8616 -> tool:dsh:lead:call_ca236ceae37d410186bf66eb -> tool:dsh:lead:call_9e9a11d43b284e90ae11add5 -> tool:dsh:lead:call_a4f921a9a1a0471480dfea6e -> tool:dsh:lead:call_27dc6065e9c84a87bc871a2c -> tool:dsh:lead:call_00ea87c0dbb345b7aac5cd20 -> tool:dsh:lead:call_e06ee3808b764f28b16b3c24 -> tool:dsh:lead:call_72a25e8394344b53a3c1e281 -> tool:dsh:lead:call_86165a88f7174cd3be68c7bd -> tool:dsh:lead:call_a0c04cf364bd4d0eae83fb2c -> tool:dsh:lead:call_6327b7ee9471470994c1f45b -> tool:dsh:lead:call_e7398b1f924a4198a486f143 -> tool:dsh:lead:call_70383eedfa7844469e6666fe -> tool:dsh:lead:call_f06c41441d4d41658c4cd2e4 -> tool:dsh:lead:call_df5100389b534ff9a34d165c -> tool:dsh:lead:call_a35df878b9974ceda4233b25 -> tool:dsh:lead:call_2a84fa6d21d64ae1be2b099b -> tool:dsh:lead:call_25e21c841d904c868d455de1
- 关键路径耗时：1.156
- Makespan：434.39
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
