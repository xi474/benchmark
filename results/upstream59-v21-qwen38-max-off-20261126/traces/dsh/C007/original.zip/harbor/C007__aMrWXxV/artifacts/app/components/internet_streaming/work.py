"""Normalize ('internet', 'streaming') channel records."""
import re


def _clean_text(s):
    """Lowercase and remove all non-alphanumeric characters."""
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    """Keep only digits."""
    if not s:
        return ""
    return re.sub(r'[^0-9]', '', s)


_MONTH_MAP = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _parse_internet_birth_date(s):
    """Parse MM/DD/YYYY to YYYY-MM-DD."""
    if not s:
        return ""
    s = s.strip()
    parts = s.split('/')
    if len(parts) == 3:
        mm, dd, yyyy = parts
        return f"{yyyy}-{mm.zfill(2)}-{dd.zfill(2)}"
    return s


def _parse_streaming_dob(s):
    """Parse 'DD Mon YYYY' to YYYY-MM-DD."""
    if not s:
        return ""
    s = s.strip()
    parts = s.split()
    if len(parts) == 3:
        dd, mon, yyyy = parts
        mm = _MONTH_MAP.get(mon.lower()[:3], '00')
        return f"{yyyy}-{mm}-{dd.zfill(2)}"
    return s


def _normalize_internet(fields):
    """Normalize an internet source record."""
    # full_name is "first last"
    full_name = fields.get("full_name", "")
    parts = full_name.split(None, 1)
    first = parts[0] if parts else ""
    last = parts[1] if len(parts) > 1 else ""

    return {
        "id": fields.get("id", ""),
        "first": _clean_text(first),
        "last": _clean_text(last),
        "dob": _parse_internet_birth_date(fields.get("birth_date", "")),
        "ssn": "",
        "mail": _clean_text(fields.get("mail", "")),
        "phone": _digits_only(fields.get("tel", "")),
        "address": _clean_text(fields.get("street", "")),
    }


def _normalize_streaming(fields):
    """Normalize a streaming source record."""
    # customer is "first last"
    customer = fields.get("customer", "")
    parts = customer.split(None, 1)
    first = parts[0] if parts else ""
    last = parts[1] if len(parts) > 1 else ""

    return {
        "id": fields.get("id", ""),
        "first": _clean_text(first),
        "last": _clean_text(last),
        "dob": _parse_streaming_dob(fields.get("date_of_birth", "")),
        "ssn": "",
        "mail": _clean_text(fields.get("email", "")),
        "phone": _digits_only(fields.get("telephone", "")),
        "address": _clean_text(fields.get("address", "")),
    }


def compute(payload):
    """Standardize ('internet', 'streaming') channel records.
    
    Returns [[original_index, field_object], ...] array.
    Field object has: id, first, last, dob, ssn, mail, phone, address.
    Dates in ISO, text lowercase stripped of non-alphanumeric, phone/ssn digits only.
    """
    records = payload.get("records", [])
    result = []
    for idx, rec in enumerate(records):
        source = rec.get("source", "")
        if source == "internet":
            norm = _normalize_internet(rec.get("fields", {}))
            norm["id"] = rec.get("id", "")
            result.append([idx, norm])
        elif source == "streaming":
            norm = _normalize_streaming(rec.get("fields", {}))
            norm["id"] = rec.get("id", "")
            result.append([idx, norm])
    return result
