"""Normalize ('mobile', 'cable') channel records."""
import re


def _clean_text(s):
    """Lowercase and remove all non-alphanumeric characters."""
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    """Keep only digits."""
    if not s:
        return ""
    return re.sub(r'[^0-9]', '', s)


def _parse_mobile_dob(s):
    """Parse YYYY-MM-DD to ISO."""
    # Already in ISO format
    if s and len(s) == 10 and s[4] == '-' and s[7] == '-':
        return s
    return s or ""


def _parse_cable_birth(s):
    """Parse YYYYMMDD to YYYY-MM-DD."""
    if not s:
        return ""
    s = s.strip()
    if len(s) == 8 and s.isdigit():
        return f"{s[:4]}-{s[4:6]}-{s[6:8]}"
    return s


def _normalize_mobile(fields):
    """Normalize a mobile source record."""
    return {
        "id": fields.get("id", ""),
        "first": _clean_text(fields.get("first", "")),
        "last": _clean_text(fields.get("last", "")),
        "dob": _parse_mobile_dob(fields.get("dob", "")),
        "ssn": _digits_only(fields.get("ssn", "")),
        "mail": _clean_text(fields.get("email", "")),
        "phone": _digits_only(fields.get("phone", "")),
        "address": _clean_text(fields.get("address", "")),
    }


def _normalize_cable(fields):
    """Normalize a cable source record."""
    # last_first is "last,first"
    last_first = fields.get("last_first", "")
    if ',' in last_first:
        parts = last_first.split(',', 1)
        last = parts[0].strip()
        first = parts[1].strip()
    else:
        last = last_first
        first = ""

    return {
        "id": fields.get("id", ""),
        "first": _clean_text(first),
        "last": _clean_text(last),
        "dob": _parse_cable_birth(fields.get("birth", "")),
        "ssn": _digits_only(fields.get("government_id", "")),
        "mail": _clean_text(fields.get("contact", "")),
        "phone": _digits_only(fields.get("phone", "")),
        "address": _clean_text(fields.get("location", "")),
    }


def compute(payload):
    """Standardize ('mobile', 'cable') channel records.
    
    Returns [[original_index, field_object], ...] array.
    Field object has: id, first, last, dob, ssn, mail, phone, address.
    Dates in ISO, text lowercase stripped of non-alphanumeric, phone/ssn digits only.
    """
    records = payload.get("records", [])
    result = []
    for idx, rec in enumerate(records):
        source = rec.get("source", "")
        if source == "mobile":
            norm = _normalize_mobile(rec.get("fields", {}))
            # Preserve original id from record level
            norm["id"] = rec.get("id", "")
            result.append([idx, norm])
        elif source == "cable":
            norm = _normalize_cable(rec.get("fields", {}))
            norm["id"] = rec.get("id", "")
            result.append([idx, norm])
    return result
