"""Entity resolution: combine normalized component outputs into clusters."""
from collections import defaultdict


def _email_edit_distance_1(a, b):
    """Check if two emails differ by exactly one character edit."""
    if not a or not b:
        return False
    la, lb = len(a), len(b)
    if la == lb:
        diffs = sum(1 for x, y in zip(a, b) if x != y)
        return diffs == 1
    if abs(la - lb) != 1:
        return False
    shorter, longer = (a, b) if la < lb else (b, a)
    i = j = 0
    skipped = False
    while i < len(shorter) and j < len(longer):
        if shorter[i] != longer[j]:
            if skipped:
                return False
            skipped = True
            j += 1
        else:
            i += 1
            j += 1
    return True


_EXPANSIONS = {
    'pat': ['patrick', 'patricia'],
    'robbie': ['robert', 'roberta'],
    'bob': ['robert'],
    'bill': ['william'],
    'jim': ['james'],
    'mike': ['michael'],
    'tom': ['thomas'],
    'dick': ['richard'],
    'harry': ['harold', 'henry'],
    'joe': ['joseph'],
    'alex': ['alexander', 'alexandra'],
    'chris': ['christopher', 'christine', 'christina'],
    'sam': ['samuel', 'samantha'],
    'tony': ['anthony'],
    'nick': ['nicholas'],
    'dan': ['daniel'],
    'matt': ['matthew'],
    'steve': ['steven', 'stephen'],
    'dave': ['david'],
    'ed': ['edward', 'edmund'],
    'ted': ['theodore', 'edward'],
    'ben': ['benjamin'],
    'charlie': ['charles'],
    'jack': ['john', 'jackson'],
    'will': ['william'],
    'liz': ['elizabeth'],
    'beth': ['elizabeth'],
    'sue': ['susan', 'susanne'],
    'kate': ['katherine', 'kathleen'],
    'jen': ['jennifer'],
    'jenny': ['jennifer'],
    'maggie': ['margaret'],
    'peggy': ['margaret'],
    'doug': ['douglas'],
    'fred': ['frederick'],
    'greg': ['gregory'],
    'jeff': ['jeffrey'],
    'jerry': ['gerald', 'jerome'],
    'larry': ['lawrence'],
    'pete': ['peter'],
    'phil': ['philip'],
    'ray': ['raymond'],
    'ron': ['ronald'],
    'russ': ['russell'],
    'walt': ['walter'],
}


def _name_compatible(first_a, first_b, ambiguous_names):
    """Returns 2=exact, 1=ambiguous-compatible, 0=incompatible."""
    if first_a == first_b:
        return 2
    ambig_set = set(ambiguous_names) if ambiguous_names else set()
    a_is_ambig = first_a in ambig_set
    b_is_ambig = first_b in ambig_set
    if a_is_ambig and b_is_ambig:
        exp_a = set(_EXPANSIONS.get(first_a, [first_a]))
        exp_b = set(_EXPANSIONS.get(first_b, [first_b]))
        return 1 if exp_a & exp_b else 0
    if a_is_ambig:
        return 1 if first_b in _EXPANSIONS.get(first_a, []) else 0
    if b_is_ambig:
        return 1 if first_a in _EXPANSIONS.get(first_b, []) else 0
    return 0


def _ssn_last4(ssn):
    """Get last 4 digits of an SSN/gov_id."""
    if not ssn or len(ssn) < 4:
        return None
    return ssn[-4:]


def _records_conflict(ra, rb, ambiguous_names):
    """Check if two records definitively belong to different people.
    
    Returns True if there's hard evidence they can't be the same person.
    """
    # Different last names
    if ra['last'] and rb['last'] and ra['last'] != rb['last']:
        return True
    
    # Different DOBs
    if ra['dob'] and rb['dob'] and ra['dob'] != rb['dob']:
        return True
    
    # Incompatible first names (not ambiguous-related)
    if ra['first'] and rb['first']:
        compat = _name_compatible(ra['first'], rb['first'], ambiguous_names)
        if compat == 0:
            return True
    
    # Conflicting full SSNs (both 9-digit and different)
    if ra['ssn'] and rb['ssn'] and len(ra['ssn']) == 9 and len(rb['ssn']) == 9:
        if ra['ssn'] != rb['ssn']:
            return True
    
    # Full SSN vs 4-digit gov_id mismatch on last4
    if ra['ssn'] and rb['ssn']:
        la, lb = len(ra['ssn']), len(rb['ssn'])
        if la == 9 and lb <= 4:
            if ra['ssn'][-lb:] != rb['ssn']:
                return True
        elif lb == 9 and la <= 4:
            if rb['ssn'][-la:] != ra['ssn']:
                return True
        elif la <= 4 and lb <= 4 and la > 0 and lb > 0:
            if ra['ssn'] != rb['ssn']:
                return True
    
    return False


def _score_pair(ra, rb, ambiguous_names):
    """Score how likely two records belong to the same person."""
    if _records_conflict(ra, rb, ambiguous_names):
        return -100
    
    score = 0.0
    score += 2.0  # Same last name
    
    name_compat = _name_compatible(ra['first'], rb['first'], ambiguous_names)
    if name_compat == 2:
        score += 5.0
    elif name_compat == 1:
        score += 1.5
    else:
        score -= 5.0
    
    if ra['dob'] and rb['dob'] and ra['dob'] == rb['dob']:
        score += 4.0
    
    # SSN matching (non-conflicting cases only since conflict returns -100 above)
    if ra['ssn'] and rb['ssn']:
        if ra['ssn'] == rb['ssn']:
            score += 15.0
        else:
            # Partial match (last4)
            a4 = _ssn_last4(ra['ssn'])
            b4 = _ssn_last4(rb['ssn'])
            if a4 and b4 and a4 == b4:
                score += 3.0
    
    if ra['mail'] and rb['mail']:
        if ra['mail'] == rb['mail']:
            score += 1.5
        elif _email_edit_distance_1(ra['mail'], rb['mail']):
            score += 5.0
    
    if ra['phone'] and rb['phone'] and ra['phone'] == rb['phone']:
        score += 0.5
    
    if ra['address'] and rb['address'] and ra['address'] == rb['address']:
        score += 0.5
    
    return score


class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n
    
    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x
    
    def union(self, x, y):
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1
        return True
    
    def connected(self, x, y):
        return self.find(x) == self.find(y)


def combine(payload, left, right):
    """Combine the two component JSON values and perform entity resolution clustering."""
    ambiguous_names = payload.get("ambiguous_names", [])
    
    all_records = []
    for idx, obj in left:
        all_records.append(obj)
    for idx, obj in right:
        all_records.append(obj)
    
    n = len(all_records)
    
    # Build blocking indices
    blocks = defaultdict(set)
    for i, rec in enumerate(all_records):
        if rec['last']:
            blocks[('last', rec['last'])].add(i)
        if rec['dob']:
            blocks[('dob', rec['dob'])].add(i)
        if rec['phone']:
            blocks[('phone', rec['phone'])].add(i)
        if rec['address']:
            blocks[('addr', rec['address'])].add(i)
        if rec['mail']:
            blocks[('mail', rec['mail'])].add(i)
        if rec['ssn'] and len(rec['ssn']) >= 4:
            blocks[('ssn4', rec['ssn'][-4:])].add(i)
    
    candidates = set()
    for key, members in blocks.items():
        member_list = sorted(members)
        for i in range(len(member_list)):
            for j in range(i + 1, len(member_list)):
                candidates.add((member_list[i], member_list[j]))
    
    # Cross-email-typo candidates
    mail_groups = defaultdict(list)
    for i, rec in enumerate(all_records):
        if rec['mail']:
            mail_groups[rec['mail']].append(i)
    mail_list = list(mail_groups.keys())
    for i in range(len(mail_list)):
        for j in range(i + 1, len(mail_list)):
            if _email_edit_distance_1(mail_list[i], mail_list[j]):
                for a in mail_groups[mail_list[i]]:
                    for b in mail_groups[mail_list[j]]:
                        candidates.add((min(a, b), max(a, b)))
    
    # Score all candidate pairs
    scored_edges = []
    for a, b in candidates:
        s = _score_pair(all_records[a], all_records[b], ambiguous_names)
        if s > 0:
            scored_edges.append((s, a, b))
    
    scored_edges.sort(reverse=True)
    
    # Agglomerative clustering with conflict checking
    uf = UnionFind(n)
    # Track cluster membership for conflict checking
    cluster_members = {i: [i] for i in range(n)}
    
    THRESHOLD = 7.0
    
    for s, a, b in scored_edges:
        if s < THRESHOLD:
            break
        ra_root = uf.find(a)
        rb_root = uf.find(b)
        if ra_root == rb_root:
            continue
        
        # Check if merging would create any internal conflict
        members_a = cluster_members[ra_root]
        members_b = cluster_members[rb_root]
        
        conflict = False
        for ma in members_a:
            for mb in members_b:
                if _records_conflict(all_records[ma], all_records[mb], ambiguous_names):
                    conflict = True
                    break
            if conflict:
                break
        
        if not conflict:
            uf.union(a, b)
            new_root = uf.find(a)
            old_root = rb_root if new_root == ra_root else ra_root
            cluster_members[new_root] = cluster_members[ra_root] + cluster_members[rb_root]
            if old_root in cluster_members:
                del cluster_members[old_root]
    
    # Build clusters
    cluster_map = defaultdict(list)
    for i in range(n):
        root = uf.find(i)
        cluster_map[root].append(all_records[i]['id'])
    
    clusters = list(cluster_map.values())
    
    return {"clusters": clusters}
