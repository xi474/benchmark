# Workflow 可观测性报告

- Trial：`C008__F6ZAwMM__env`
- Task：`C008`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_f63e30b8583b4842a392d222 -> tool:dsh:lead:call_74e3829bdf5f41619d9aba85 -> tool:dsh:lead:call_abe6d247d3cf4ac4bb4ac4d4 -> tool:dsh:lead:call_ca5c15524efb48f795231965 -> tool:dsh:lead:call_193d2348ceab462a892a8f7f -> tool:dsh:lead:call_d2df1fdc780449a6881071ba -> tool:dsh:lead:call_ae4fdb003e45444399b0f224 -> tool:dsh:lead:call_901e4f909e8a4ef39495de1e -> tool:dsh:lead:call_bdfed7f5f9934c988d86f76f -> tool:dsh:lead:call_985d2aa041a843769996ef7d -> tool:dsh:lead:call_71baaa16469b4e58947f34ac -> tool:dsh:lead:call_0744a44537794d14a14592c2 -> tool:dsh:lead:call_09dab6dbe163487d86c16dfe -> tool:dsh:lead:call_123e1fd9610744eab41e0b20 -> tool:dsh:lead:call_07ddc2d480e34d42912374e6 -> tool:dsh:lead:call_4b4149a60c7b41e4905f92c8 -> tool:dsh:lead:call_c9e4ecfdba444c5388a10e25 -> tool:dsh:lead:call_5a6aeaff74b54c2b9bcb38bf -> tool:dsh:lead:call_e676e168b9954039a92d5397 -> tool:dsh:lead:call_39fcf0dfa41145b3a92f0956 -> tool:dsh:lead:call_f3818abd64214f73a6ff3cd2 -> tool:dsh:lead:call_fdc6e238cf64408b85bea551 -> tool:dsh:lead:call_70974f3cdcfa44fa8cd2358e -> tool:dsh:lead:call_11b4b5b0cc264ea99afc5293 -> tool:dsh:lead:call_2298787e049b402bb12afabb -> tool:dsh:lead:call_69837a28be0f46608b087323 -> tool:dsh:lead:call_4e34ec95913742b39cf5a006 -> tool:dsh:lead:call_ea5b249b82da4895af3d86e6 -> tool:dsh:lead:call_22fb41dbdb6c4d7bb61fe115 -> tool:dsh:lead:call_bf23ab2095c64d689cb73d37 -> tool:dsh:lead:call_cae0d11c569b4c69b2bb2e74 -> tool:dsh:lead:call_a6a5c795af4e4d5896eb9e73 -> tool:dsh:lead:call_868d487d38904b9d97b23690
- 关键路径耗时：1.311
- Makespan：60.586
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
