def compute(payload):
    """将链接和合并登记为 [起点,终点,生效时刻,失效时刻]。保留原顺序并补齐缺省区间。"""
    INF = 10**18
    result = []
    for link in payload.get("links", []):
        a = link["a"]
        b = link["b"]
        frm = link.get("from", 0)
        to = link.get("to", INF)
        result.append([a, b, frm, to])
    for merge in payload.get("merges", []):
        a = merge["a"]
        b = merge["b"]
        frm = merge.get("from", 0)
        to = merge.get("to", INF)
        result.append([a, b, frm, to])
    return result
