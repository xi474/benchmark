import json
import hashlib


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left: list of [endpoint_a, endpoint_b, from_time, to_time] from relationship_windows
    right: list of [table, id, time, [tenant, subject]] from record_subjects
    payload: full input including seed
    """
    seed = payload["seed"]
    windows = left  # [[a, b, from, to], ...]
    records = right  # [[table, id, time, [tenant, subject]], ...]

    result_records = []

    for rec in records:
        table, rid, time_val, subject_pair = rec
        tenant, subject = subject_pair

        # Collect all nodes and active edges at this time
        # Active edge: from <= time_val < to
        active_edges = []
        nodes = set()
        nodes.add((tenant, subject))

        for w in windows:
            a, b, frm, to = w
            a_tuple = (a[0], a[1])
            b_tuple = (b[0], b[1])
            if frm <= time_val < to:
                active_edges.append((a_tuple, b_tuple))
                nodes.add(a_tuple)
                nodes.add(b_tuple)

        # Union-Find
        parent = {}
        rank = {}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            rx, ry = find(x), find(y)
            if rx == ry:
                return
            if rank[rx] < rank[ry]:
                rx, ry = ry, rx
            parent[ry] = rx
            if rank[rx] == rank[ry]:
                rank[rx] += 1

        for n in nodes:
            parent[n] = n
            rank[n] = 0

        for a, b in active_edges:
            union(a, b)

        # Find canonical subject: lex smallest (tenant, subject) in component
        root = find((tenant, subject))
        component_members = [n for n in nodes if find(n) == root]
        canonical = min(component_members)
        canonical_tenant, canonical_subject = canonical

        # Compute token
        raw_str = json.dumps(
            [str(seed), canonical_tenant, canonical_subject],
            ensure_ascii=True,
            separators=(',', ':')
        )
        raw_bytes = raw_str.encode('utf-8')
        sha = hashlib.sha256(raw_bytes).hexdigest()
        token = "ref_" + sha[:12]

        result_records.append({
            "table": table,
            "id": rid,
            "time": time_val,
            "token": token
        })

    return {"records": result_records}
