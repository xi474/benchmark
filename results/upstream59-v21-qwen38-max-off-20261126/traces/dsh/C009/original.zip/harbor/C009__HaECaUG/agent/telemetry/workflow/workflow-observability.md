# Workflow 可观测性报告

- Trial：`C009__HaECaUG__env`
- Task：`C009`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5e869139c6d2486bb5187673 -> tool:dsh:lead:call_1b849479a08d455fbe87ac70 -> tool:dsh:lead:call_fe7e1d11f0c44c2cb51e9456 -> tool:dsh:lead:call_6ac3a347548347b291697eef -> tool:dsh:lead:call_b95e1a5b640c48d8ba2b3d81 -> tool:dsh:lead:call_2c035616a03d4af19041b933 -> tool:dsh:lead:call_f902993aa846450b9726bb96 -> tool:dsh:lead:call_7680f41146d44813bffaa6dc -> tool:dsh:lead:call_352077536cb34598afb1c7eb -> tool:dsh:lead:call_45be0702cc084e158f6aad52 -> tool:dsh:lead:call_72341288655343a4a5aecda9 -> tool:dsh:lead:call_eaa3c5c0ddc144159de11a51 -> tool:dsh:lead:call_11abb61abba14d09b1b6f066 -> tool:dsh:lead:call_4d53e08a71324cbfaa107879 -> tool:dsh:lead:call_2504fd20c3a246a3ba4eb3e0 -> tool:dsh:lead:call_3197dce3366b4aab9982dc5b -> tool:dsh:lead:call_367d9868f6884b2bbc2a0def -> tool:dsh:lead:call_22f134ab95024b628ecf36a9 -> tool:dsh:lead:call_8ddab601d4964268b73c747f -> tool:dsh:lead:call_4840566e6e174a7da7d3a151 -> tool:dsh:lead:call_1c9e40166e214293a1a2e11c -> tool:dsh:lead:call_1b8669161a5b4c5fabb73761 -> tool:dsh:lead:call_0762c47b39674155a6b70d56 -> tool:dsh:lead:call_6528aa34283447a0957a1716 -> tool:dsh:lead:call_646d685f1c76432b8600938e -> tool:dsh:lead:call_db47a95bdf194a1f9123cf7a -> tool:dsh:lead:call_7bde119da0884775aae0b175 -> tool:dsh:lead:call_711d1f67ce444f82a95e7194 -> tool:dsh:lead:call_ceb9086c5a124b9392f632f3 -> tool:dsh:lead:call_3b1e31d721754feaaff84902
- 关键路径耗时：0.961
- Makespan：87.33
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
