from itertools import product


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    vehicles = payload["vehicles"]
    drivers = payload["drivers"]
    suppliers = payload["suppliers"]
    events_sorted = left  # sorted by (visible, id)
    crew_compat = right   # {vehicle_id: [driver_ids]}
    rounds = payload["rounds"]

    veh_map = {v["id"]: v for v in vehicles}
    drv_map = {d["id"]: d for d in drivers}
    sup_map = {s["id"]: s for s in suppliers}

    # State tracking across rounds
    committed = []          # list of assignment dicts (permanent)
    committed_jobs = set()  # job ids that are committed
    cancelled_set = set()   # job ids cancelled
    # Track supplier stock consumed by committed assignments
    sup_used = {s["id"]: 0 for s in suppliers}
    # Track driver work history: list of (start, end) intervals for committed tasks
    driver_history = {d["id"]: [] for d in drivers}
    # Track vehicle intervals for committed tasks
    vehicle_history = {v["id"]: [] for v in vehicles}

    result_rounds = []

    for rnd in rounds:
        cutoff = rnd["cutoff"]
        do_commit = rnd["commit"]

        # Determine visible events for this round
        visible_events = [e for e in events_sorted if e["visible"] <= cutoff]

        # Collect available jobs (requests visible so far, not yet committed or cancelled)
        available_jobs = {}
        for e in visible_events:
            if e["kind"] == "request":
                jid = e["job"]["id"]
                if jid not in committed_jobs and jid not in cancelled_set:
                    available_jobs[jid] = e["job"]

        # Process cancellations
        round_cancelled = []
        round_ignored = []
        for e in visible_events:
            if e["kind"] == "cancel":
                jid = e["job"]
                if jid in cancelled_set:
                    continue  # already cancelled
                if jid in committed_jobs:
                    # Check if the committed task has start < cutoff
                    task = None
                    for a in committed:
                        if a["job"] == jid:
                            task = a
                            break
                    if task and task["start"] < cutoff:
                        round_ignored.append(jid)
                    else:
                        # Remove from committed, release resources
                        if task:
                            committed.remove(task)
                            committed_jobs.discard(jid)
                            sup_used[task["supplier"]] -= task["quantity"]
                            d_hist = driver_history[task["driver"]]
                            d_hist[:] = [(s, en) for s, en in d_hist if not (s == task["start"] and en == task["end"])]
                            v_hist = vehicle_history[task["vehicle"]]
                            v_hist[:] = [(s, en) for s, en in v_hist if not (s == task["start"] and en == task["end"])]
                        cancelled_set.add(jid)
                        round_cancelled.append(jid)
                else:
                    # Job not yet committed; cancel it (prevent future assignment)
                    cancelled_set.add(jid)
                    round_cancelled.append(jid)
                    available_jobs.pop(jid, None)

        round_cancelled = sorted(set(round_cancelled))
        round_ignored = sorted(set(round_ignored))

        # Now optimize new assignments for available jobs
        # We need to find the best set of new assignments maximizing:
        # 1. Total profit of new assignments
        # 2. Number of new assignments
        # 3. Lexicographically smallest sorted tuple list

        new_assignments = _optimize(
            available_jobs, veh_map, drv_map, sup_map, crew_compat,
            cutoff, sup_used, driver_history, vehicle_history
        )

        if do_commit:
            for a in new_assignments:
                committed.append(a)
                committed_jobs.add(a["job"])
                sup_used[a["supplier"]] += a["quantity"]
                driver_history[a["driver"]].append((a["start"], a["end"]))
                vehicle_history[a["vehicle"]].append((a["start"], a["end"]))

        # Build assignments list: committed + new (if not committed this round, they're already in committed)
        all_assignments = list(committed)
        if not do_commit:
            all_assignments = list(committed) + list(new_assignments)

        # Sort by (job, start, vehicle, driver, supplier)
        all_assignments.sort(key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))

        total_profit = sum(a["profit"] for a in all_assignments)

        result_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments,
            "profit": total_profit,
            "cancelled": round_cancelled,
            "ignored_cancellations": round_ignored,
        })

    return {"rounds": result_rounds}


def _check_driver_constraints(driver_id, drv_map, driver_history, new_intervals):
    """Check if adding new_intervals to driver's history satisfies max_work, max_continuous, break."""
    d = drv_map[driver_id]
    max_work = d["max_work"]
    max_cont = d["max_continuous"]
    brk = d["break"]

    # Combine existing history with new intervals
    all_intervals = sorted(driver_history[driver_id] + new_intervals, key=lambda x: x[0])

    # Check total work
    total_work = sum(en - s for s, en in all_intervals)
    if total_work > max_work:
        return False

    # Check continuous work with break logic
    # Sort by start time, compute continuous accumulation
    cont = 0
    prev_end = None
    for s, en in all_intervals:
        if prev_end is not None:
            gap = s - prev_end
            if gap >= brk:
                cont = 0  # reset
            # else accumulate
        cont += (en - s)
        if cont > max_cont:
            return False
        prev_end = en
    return True


def _check_vehicle_overlap(vehicle_id, vehicle_history, new_intervals):
    """Check no time overlap between existing and new intervals for vehicle."""
    existing = vehicle_history[vehicle_id]
    for s1, e1 in existing:
        for s2, e2 in new_intervals:
            if s1 < e2 and s2 < e1:
                return False
    # Also check among new intervals themselves
    for i in range(len(new_intervals)):
        for j in range(i + 1, len(new_intervals)):
            s1, e1 = new_intervals[i]
            s2, e2 = new_intervals[j]
            if s1 < e2 and s2 < e1:
                return False
    return True


def _check_driver_overlap(driver_id, driver_history, new_intervals):
    """Check no time overlap for driver."""
    existing = driver_history[driver_id]
    for s1, e1 in existing:
        for s2, e2 in new_intervals:
            if s1 < e2 and s2 < e1:
                return False
    for i in range(len(new_intervals)):
        for j in range(i + 1, len(new_intervals)):
            s1, e1 = new_intervals[i]
            s2, e2 = new_intervals[j]
            if s1 < e2 and s2 < e1:
                return False
    return True


def _compute_profit(job, vehicle, supplier):
    return job["revenue"] - job["quantity"] * supplier["unit_cost"] - vehicle["cost"] * job["duration"]


def _optimize(available_jobs, veh_map, drv_map, sup_map, crew_compat,
              cutoff, sup_used, driver_history, vehicle_history):
    """Find optimal new assignments via brute-force enumeration (small domain)."""
    if not available_jobs:
        return []

    job_list = sorted(available_jobs.keys())
    vehicles = sorted(veh_map.keys())
    drivers_list = sorted(drv_map.keys())
    suppliers_list = sorted(sup_map.keys())

    # Generate all feasible single-job options
    # Each option: (job_id, vehicle_id, driver_id, supplier_id, start, end, profit)
    job_options = {}
    for jid in job_list:
        job = available_jobs[jid]
        options = []
        for vid in vehicles:
            v = veh_map[vid]
            if v["type"] != job["type"]:
                continue
            if v["capacity"] < job["quantity"]:
                continue
            compatible_drivers = crew_compat.get(vid, [])
            for did in compatible_drivers:
                for sid in job["suppliers"]:
                    sup = sup_map[sid]
                    # Time feasibility
                    earliest_start = max(cutoff, job["release"])
                    latest_start = job["deadline"] - job["duration"]
                    # start <= supplier close
                    latest_start = min(latest_start, sup["close"])
                    if earliest_start > latest_start:
                        continue
                    profit = _compute_profit(job, v, sup)
                    for start in range(earliest_start, latest_start + 1):
                        end = start + job["duration"]
                        options.append((jid, vid, did, sid, start, end, profit))
        job_options[jid] = options

    # Brute force: try all combinations of assigning each job to one option or skipping
    best_profit = 0
    best_count = 0
    best_tuple = None
    best_assignments = []

    def _enumerate(idx, chosen, used_sup, drv_new_intervals, veh_new_intervals):
        nonlocal best_profit, best_count, best_tuple, best_assignments

        if idx == len(job_list):
            # Evaluate this combination
            total_profit = sum(o[6] for o in chosen)
            count = len(chosen)

            # Build assignment dicts and sort
            assigns = []
            for o in chosen:
                jid, vid, did, sid, start, end, profit = o
                assigns.append({
                    "job": jid, "vehicle": vid, "driver": did,
                    "supplier": sid, "start": start, "end": end,
                    "quantity": available_jobs[jid]["quantity"],
                    "profit": profit
                })
            assigns.sort(key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))
            tup = tuple((a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]) for a in assigns)

            if (total_profit > best_profit or
                (total_profit == best_profit and count > best_count) or
                (total_profit == best_profit and count == best_count and (best_tuple is None or tup < best_tuple))):
                best_profit = total_profit
                best_count = count
                best_tuple = tup
                best_assignments = assigns
            return

        jid = job_list[idx]

        # Option: skip this job
        _enumerate(idx + 1, chosen, used_sup, drv_new_intervals, veh_new_intervals)

        # Try each option for this job
        for opt in job_options[jid]:
            jid2, vid, did, sid, start, end, profit = opt
            # Check supplier stock
            new_sup_used = used_sup.get(sid, 0) + available_jobs[jid]["quantity"]
            if new_sup_used > sup_map[sid]["stock"] - sup_used[sid]:
                continue

            # Check vehicle no overlap
            new_veh_int = dict(veh_new_intervals)
            new_veh_int.setdefault(vid, [])
            interval = (start, end)
            # Check against committed + already chosen new intervals for this vehicle
            all_veh = vehicle_history[vid] + new_veh_int[vid]
            overlap = False
            for s, e in all_veh:
                if s < end and start < e:
                    overlap = True
                    break
            if overlap:
                continue

            # Check driver no overlap
            new_drv_int = dict(drv_new_intervals)
            new_drv_int.setdefault(did, [])
            all_drv = driver_history[did] + new_drv_int[did]
            overlap = False
            for s, e in all_drv:
                if s < end and start < e:
                    overlap = True
                    break
            if overlap:
                continue

            # Check driver constraints (max_work, max_continuous, break)
            test_drv_intervals = {k: list(v) for k, v in drv_new_intervals.items()}
            test_drv_intervals.setdefault(did, []).append(interval)
            if not _check_driver_constraints(did, drv_map, driver_history, test_drv_intervals[did]):
                continue

            # All checks passed
            new_used_sup = dict(used_sup)
            new_used_sup[sid] = new_sup_used

            new_veh_intervals = dict(veh_new_intervals)
            new_veh_intervals.setdefault(vid, []).append(interval)

            new_drv_intervals = dict(drv_new_intervals)
            new_drv_intervals.setdefault(did, []).append(interval)

            _enumerate(idx + 1, chosen + [opt], new_used_sup,
                       new_drv_intervals, new_veh_intervals)

    _enumerate(0, [], {}, {}, {})
    return best_assignments
