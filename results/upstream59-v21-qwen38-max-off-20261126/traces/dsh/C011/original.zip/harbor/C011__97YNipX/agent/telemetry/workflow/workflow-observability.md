# Workflow 可观测性报告

- Trial：`C011__97YNipX__env`
- Task：`C011`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_e88d149c902d48439d8b807e -> tool:dsh:lead:call_9c78a2c5e0e74e46971a5b2b -> tool:dsh:lead:call_bbacd2cd58f54f2280868bb8 -> tool:dsh:lead:call_5736fc7e20f4436d9a810c09 -> tool:dsh:lead:call_ef7458ae8bed4eb895186d58 -> tool:dsh:lead:call_7f6564d474e94b56ad0483d4 -> tool:dsh:lead:call_19cd26b09fa94a40bc0494b5 -> tool:dsh:lead:call_714ab8a643994b4c8614f7ef -> tool:dsh:lead:call_450f7226e6314dbbaf8300dd -> tool:dsh:lead:call_0f56d0308acf46f7b4ae10bf -> tool:dsh:lead:call_4cacba28ffba42f3888bbc95 -> tool:dsh:lead:call_99a5d99026a2416eb084b67b -> tool:dsh:lead:call_a73ce03dcb37445991e5d35b -> tool:dsh:lead:call_5715bed167144961bd6e653f -> tool:dsh:lead:call_e73684ece7864420b37ff13d -> tool:dsh:lead:call_5dc93512b4d0442591b8b938 -> tool:dsh:lead:call_31203aff95b240d4a92cf111 -> tool:dsh:lead:call_5355ad61f5a54e71879e73ce -> tool:dsh:lead:call_80ceda882f874a41b52727b6 -> tool:dsh:lead:call_498eae05e44b42aaa9c40cad -> tool:dsh:lead:call_b9029dec2a504eb38598d628 -> tool:dsh:lead:call_69db780271a44eac933da062 -> tool:dsh:lead:call_a317307b2fd646be991a88a2 -> tool:dsh:lead:call_57efc1ffcac9457d813c5cc5 -> tool:dsh:lead:call_706aa2626c6e462c875d5228 -> tool:dsh:lead:call_796bda891fe34e1a9e4f4003 -> tool:dsh:lead:call_88bcb1732c504802a4e0b7ef -> tool:dsh:lead:call_66e1eb29e453417e808a5c1f -> tool:dsh:lead:call_720f4367c70343cea88612c4 -> tool:dsh:lead:call_4a7c9222b35c411e86ca5821 -> tool:dsh:lead:call_3c5d8780c8ce48dfb74b62c1 -> tool:dsh:lead:call_f50e39ef64a443db958207f8 -> tool:dsh:lead:call_5726c9d706754f12afd4ead7 -> tool:dsh:lead:call_9b5502d9782d444a81d6ccd6 -> tool:dsh:lead:call_282ec1cdf13940a187f1c2a9 -> tool:dsh:lead:call_ef0966d3ad994fb1a2da26b7 -> tool:dsh:lead:call_6366b2e312964808a3c067a1
- 关键路径耗时：1.077
- Makespan：230.924
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
