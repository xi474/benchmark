def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload["orders"]
    released = set(payload.get("released", []))
    routing = payload.get("routing", {})
    lines = payload.get("lines", [])
    wip_list = payload.get("wip", [])
    freeze = payload.get("freeze", 0)
    changeover = payload.get("changeover", 0)

    # Build map: line_id -> max wip end time on that line
    wip_end_by_line = {}
    for w in wip_list:
        lid = w["line"]
        e = w["end"]
        if lid not in wip_end_by_line or e > wip_end_by_line[lid]:
            wip_end_by_line[lid] = e

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]

        if sku not in released:
            result[oid] = []
            continue

        if sku not in routing:
            result[oid] = []
            continue

        r = routing[sku]
        duration = r["setup"] + r["per_unit"] * qty

        triples = []
        for line in lines:
            lid = line["id"]
            if sku not in line.get("qualified", []):
                continue

            # Earliest start on this line: after all WIP + changeover, and after freeze
            earliest = freeze
            if lid in wip_end_by_line:
                earliest = max(earliest, wip_end_by_line[lid] + changeover)

            for win in line.get("windows", []):
                ws, we = win[0], win[1]
                # Task interval [start, end) must fit in window [ws, we)
                # start >= ws, end <= we, end = start + duration
                # Also start >= earliest, end <= due
                lo = max(ws, earliest)
                hi = min(we, due) - duration  # start + duration <= min(we, due) => start <= min(we,due)-duration
                for s in range(lo, hi + 1):
                    e = s + duration
                    triples.append([lid, s, e])

        result[oid] = triples

    return result
