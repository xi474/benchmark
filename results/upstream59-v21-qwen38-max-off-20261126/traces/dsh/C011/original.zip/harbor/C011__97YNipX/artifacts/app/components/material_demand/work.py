def compute(payload):
    """按工单 ID 输出递归展开后的基础物料需求映射。"""
    orders = payload["orders"]
    bom = payload.get("bom", {})

    # A material is a leaf if it does NOT appear as a key in bom
    def expand(material, multiplier, result):
        if material not in bom:
            # Leaf node
            result[material] = result.get(material, 0) + multiplier
        else:
            for child, qty in bom[material].items():
                expand(child, multiplier * qty, result)

    demand = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        result = {}
        expand(sku, qty, result)
        demand[oid] = result

    return demand
