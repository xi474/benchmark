import copy
import itertools


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract."""
    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    orders = payload["orders"]
    wip_list = payload.get("wip", [])
    lots = payload.get("lots", [])
    substitutes = payload.get("substitutes", {})

    order_map = {o["id"]: o for o in orders}
    demand = left     # {oid: {comp: qty}}
    windows = right   # {oid: [[line, start, end], ...]}

    valid_lots = [lot for lot in lots if lot["status"] == "PASS"]

    def get_subs(component):
        return set(substitutes.get(component, [component]))

    def find_best_alloc(assignments):
        """Find lex-minimum feasible material allocation. Returns dict or None."""
        demands = []
        for oid, _ln, _st, end in assignments:
            if oid not in demand:
                continue
            for comp in sorted(demand[oid]):
                q = demand[oid][comp]
                if q > 0:
                    demands.append((oid, comp, q, end))
        if not demands:
            return {}

        lot_rem = {lt["id"]: lt["qty"] for lt in valid_lots}
        best = [None]  # [best_key, best_alloc]
        cur = {}

        def alloc_key(ad):
            parts = []
            for k in sorted(ad):
                es = sorted(ad[k], key=lambda e: (e[0], e[1], e[2]))
                parts.append((k, tuple(e for e in es if e[2] > 0)))
            return tuple(parts)

        def bt(idx):
            if idx == len(demands):
                k = alloc_key(cur)
                if best[0] is None or k < best[0]:
                    best[0] = k
                    if len(best) < 2:
                        best.append(copy.deepcopy(cur))
                    else:
                        best[1] = copy.deepcopy(cur)
                return
            oid, comp, qty, end = demands[idx]
            mats = get_subs(comp)
            elig = sorted(
                [lt for lt in valid_lots if lt["material"] in mats and lt["expiry"] >= end and lot_rem[lt["id"]] > 0],
                key=lambda l: l["id"]
            )
            if not elig:
                return

            def fill(li, need, chosen):
                if need == 0:
                    for lid, take in chosen:
                        lot_rem[lid] -= take
                    cur.setdefault(oid, [])
                    for lid, take in chosen:
                        cur[oid].append((comp, lid, take))
                    bt(idx + 1)
                    for lid, take in chosen:
                        lot_rem[lid] += take
                    al = cur[oid]
                    for _ in chosen:
                        al.pop()
                    if not al:
                        del cur[oid]
                    return
                if li == len(elig):
                    return
                lt = elig[li]
                lid = lt["id"]
                avail = lot_rem[lid]
                mx = min(need, avail)
                for take in range(1, mx + 1):
                    chosen.append((lid, take))
                    fill(li + 1, need - take, chosen)
                    chosen.pop()
                fill(li + 1, need, chosen)

            fill(0, qty, [])

        bt(0)
        return best[1] if best[0] is not None else None

    order_ids = [o["id"] for o in orders]
    pri = {o["id"]: o["priority"] for o in orders}
    due = {o["id"]: o["due"] for o in orders}
    qty_of = {o["id"]: o["qty"] for o in orders}
    sk = lambda oid: (pri[oid], due[oid], oid)

    best = None

    for size in range(len(order_ids), -1, -1):
        for subset in itertools.combinations(order_ids, size):
            ss = set(subset)
            opts_list = []
            ok = True
            for oid in subset:
                ws = windows.get(oid, [])
                if not ws:
                    ok = False
                    break
                opts_list.append([(oid, l, s, e) for l, s, e in ws])
            if not ok:
                continue

            for combo in itertools.product(*opts_list):
                asgn = list(combo)

                # Schedule feasibility
                lt_tasks = {}
                for oid, ln, st, en in asgn:
                    lt_tasks.setdefault(ln, []).append((st, en))
                for w in wip_list:
                    lt_tasks.setdefault(w["line"], []).append((w["start"], w["end"]))

                sok = True
                for tasks in lt_tasks.values():
                    ts = sorted(tasks)
                    for i in range(len(ts)):
                        for j in range(i + 1, len(ts)):
                            si, ei = ts[i]
                            sj, ej = ts[j]
                            if si < ej and sj < ei:
                                sok = False
                                break
                            if ei <= sj and sj - ei < changeover:
                                sok = False
                                break
                        if not sok:
                            break
                    if not sok:
                        break
                if not sok:
                    continue

                alloc = find_best_alloc(asgn)
                if alloc is None:
                    continue

                pq = {1: 0, 2: 0, 3: 0}
                for oid, _l, _s, _e in asgn:
                    pq[pri[oid]] += qty_of[oid]

                sa = sorted(order_ids, key=sk)
                cv = tuple(1 if oid in ss else 0 for oid in sa)

                sa_asgn = sorted(asgn, key=lambda x: x[0])

                def akey(aoid):
                    if aoid in alloc:
                        es = sorted(alloc[aoid], key=lambda e: (e[0], e[1], e[2]))
                        return tuple((c, l, q) for c, l, q in es if q > 0)
                    return ()

                skey = tuple((ao, al, ast, aen, akey(ao)) for ao, al, ast, aen in sa_asgn)
                cmp = (pq[1], pq[2], pq[3], cv)

                if best is None or cmp > best[0] or (cmp == best[0] and skey < best[1]):
                    best = (cmp, skey, asgn, alloc, ss)

    if best is None:
        eo = []
        for w in wip_list:
            eo.append({"wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
                        "due": w["due"], "start": w["start"], "end": w["end"],
                        "line": w["line"], "status": "WIP_CONT", "parent": None})
        eo.sort(key=lambda x: x["wo"])
        me = _mes([], wip_list, run_id, order_map)
        return {"selected": [], "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": eo},
                "mes": me, "wms": []}

    _, _, asgn, alloc, ss = best
    selected = sorted(ss)

    eo = []
    for oid, ln, st, en in asgn:
        o = order_map[oid]
        eo.append({"wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
                    "due": o["due"], "start": st, "end": en,
                    "line": ln, "status": "PLANNED", "parent": oid})
    for w in wip_list:
        eo.append({"wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
                    "due": w["due"], "start": w["start"], "end": w["end"],
                    "line": w["line"], "status": "WIP_CONT", "parent": None})
    eo.sort(key=lambda x: x["wo"])

    me = _mes(asgn, wip_list, run_id, order_map)

    wr = []
    for oid in sorted(alloc):
        for comp, lid, q in alloc[oid]:
            if q > 0:
                wr.append((oid, comp, lid, q))
    wr.sort()
    wms = []
    for i, (oid, comp, lid, q) in enumerate(wr, 1):
        wms.append({"reservation": f"r{i:04d}", "run": run_id, "wo": oid,
                     "component": comp, "lot": lid, "qty": q, "status": "RESERVED"})

    return {"selected": selected,
            "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": eo},
            "mes": me, "wms": wms}


def _mes(assignments, wip_list, run_id, order_map):
    by_line = {}
    for oid, ln, st, en in assignments:
        o = order_map[oid]
        by_line.setdefault(ln, []).append({"wo": oid, "qty": o["qty"], "start": st, "end": en, "status": "PLANNED"})
    for w in wip_list:
        by_line.setdefault(w["line"], []).append({"wo": w["id"], "qty": w["qty"], "start": w["start"], "end": w["end"], "status": "WIP_CONT"})
    result = []
    for lid in sorted(by_line):
        tasks = sorted(by_line[lid], key=lambda t: (t["start"], t["wo"]))
        for seq, t in enumerate(tasks, 1):
            result.append({"run": run_id, "line": lid, "seq": seq, "wo": t["wo"],
                           "qty": t["qty"], "start": t["start"], "end": t["end"], "status": t["status"]})
    return result
