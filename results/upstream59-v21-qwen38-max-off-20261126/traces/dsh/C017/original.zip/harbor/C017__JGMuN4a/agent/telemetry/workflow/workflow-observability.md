# Workflow 可观测性报告

- Trial：`C017__JGMuN4a__env`
- Task：`C017`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_f00951b539904013a01d6c57 -> tool:dsh:lead:call_e1e7231daab84944af1e00ca -> tool:dsh:lead:call_5691804556724e029ed2b585 -> tool:dsh:lead:call_a838df2c25564d08b1ca24bf -> tool:dsh:lead:call_6e8dd071376842c1a361873d -> tool:dsh:lead:call_d62c44f9282d4e75a3613f07 -> tool:dsh:lead:call_d81b53fe1980493d9daef69b -> tool:dsh:lead:call_0a9037efd48740f9bc9e95c5 -> tool:dsh:lead:call_ce450bf20d61443a9fa009bc -> tool:dsh:lead:call_01280c4601894f23940db28f -> tool:dsh:lead:call_5fa49e68b59741eb9f265ae8 -> tool:dsh:lead:call_888dffff20ac49098f3d4f6c -> tool:dsh:lead:call_a21663cfe89f409b902c5611 -> tool:dsh:lead:call_856d9dad54e04bbf816df895 -> tool:dsh:lead:call_7ddafdc968e94fdcb223376f -> tool:dsh:lead:call_a5e784010c874d5d890d8521 -> tool:dsh:lead:call_d28dbab8f0e1429f98204f54 -> tool:dsh:lead:call_07d7d36103294c218e69d484 -> tool:dsh:lead:call_af067bb196884384a7580545 -> tool:dsh:lead:call_96d7fec65bec4a4e9421f3c7 -> tool:dsh:lead:call_852a62a64e224f2ab1f92625 -> tool:dsh:lead:call_206330f68fcc4962989885af -> tool:dsh:lead:call_59f618efbe78419d8ef40c11 -> tool:dsh:lead:call_9108b8d22e664a8b9768e615 -> tool:dsh:lead:call_ff6a9510057f428dbf81a3a8 -> tool:dsh:lead:call_aaf73f5e688e4f2f879160fa -> tool:dsh:lead:call_103520ada1374b4d8e05c5f5 -> tool:dsh:lead:call_e28fb38241b84822abe8b04d -> tool:dsh:lead:call_876e11f3b507490fb2a83193 -> tool:dsh:lead:call_ce8d79a185c4498ebbdc7111 -> tool:dsh:lead:call_420e0978e67d4b5282631783 -> tool:dsh:lead:call_21d99901056342c7a6980503 -> tool:dsh:lead:call_c54ece73c4134f5f9091d0db -> tool:dsh:lead:call_a65275f763144bd08f836469
- 关键路径耗时：0.901
- Makespan：93.514
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
