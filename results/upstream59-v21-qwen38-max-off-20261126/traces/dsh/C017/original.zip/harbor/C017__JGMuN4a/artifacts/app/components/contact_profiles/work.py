import re

def _collapse_whitespace(s):
    """Compress consecutive whitespace to a single space."""
    return re.sub(r'\s+', ' ', s).strip() if s else s

def compute(payload):
    """保留批次和行序，返回 name,city,source,time 对象；姓名与城市的空白折叠为单个空格。"""
    result = []
    for batch in payload["batches"]:
        batch_profiles = []
        for record in batch:
            name = _collapse_whitespace(record.get("name", ""))
            city = _collapse_whitespace(record.get("city", ""))
            batch_profiles.append({
                "name": name,
                "city": city,
                "source": record["source"],
                "time": record["time"]
            })
        result.append(batch_profiles)
    return result
