import copy


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: list of lists of normalized emails (from contact_keys)
    right: list of lists of {name, city, source, time} profiles (from contact_profiles)
    
    Returns the full business result with batches, accepted, incomplete, sources.
    """
    # Records store: email -> {name, city, first_contact, sources, complete}
    # complete = True means both name and city are non-empty
    records = {}  # email -> record dict
    
    batch_results = []
    
    for batch_idx in range(len(left)):
        keys = left[batch_idx]       # list of normalized emails
        profiles = right[batch_idx]  # list of profile dicts
        
        # Build candidate updates for this batch
        # We need to check conflicts before committing
        # Work on a snapshot of current state
        snapshot = {}
        for email, rec in records.items():
            snapshot[email] = {
                "name": rec["name"],
                "city": rec["city"],
                "first_contact": rec["first_contact"],
                "sources": set(rec["sources"]),
                "complete": rec["complete"],
            }
        
        # Track what this batch would do
        batch_items = []  # status per item in batch order
        batch_new_records = {}  # email -> proposed record state after this batch
        conflict = False
        
        # First pass: build proposed state for each email touched in this batch
        # Process items within batch in order
        proposed = {}  # email -> {name, city, first_contact, sources, complete, item_status}
        
        for i, (email, profile) in enumerate(zip(keys, profiles)):
            name = profile["name"]
            city = profile["city"]
            source = profile["source"]
            time_val = profile["time"]
            
            # Start from either existing record or previous batch-item in same batch
            if email in proposed:
                base = proposed[email]
            elif email in snapshot:
                base = {
                    "name": snapshot[email]["name"],
                    "city": snapshot[email]["city"],
                    "first_contact": snapshot[email]["first_contact"],
                    "sources": set(snapshot[email]["sources"]),
                    "complete": snapshot[email]["complete"],
                }
            else:
                base = {
                    "name": "",
                    "city": "",
                    "first_contact": time_val,
                    "sources": set(),
                    "complete": False,
                }
            
            # Check conflict: new non-empty name/city contradicts existing non-empty name/city
            # Conflict happens when:
            # - existing has non-empty name AND new has non-empty name AND they differ
            # - existing has non-empty city AND new has non-empty city AND they differ
            existing_name = base["name"]
            existing_city = base["city"]
            
            if existing_name and name and existing_name != name:
                conflict = True
                break
            if existing_city and city and existing_city != city:
                conflict = True
                break
            
            # Merge: non-empty new values fill in; non-empty old values are preserved
            new_name = name if name else existing_name
            new_city = city if city else existing_city
            new_first_contact = min(base["first_contact"], time_val)
            new_sources = base["sources"] | {source}
            was_complete = base["complete"]
            new_complete = bool(new_name and new_city)
            
            # Determine item status
            if was_complete:
                # Already complete - this is a duplicate submission
                # Sources can still be merged
                item_status = "duplicate"
            elif new_complete and not was_complete:
                # Becoming complete now
                # Check if it was previously incomplete (existed before this batch or earlier in batch)
                if email in snapshot or (email in proposed and not proposed[email]["complete"]):
                    item_status = "promoted"
                else:
                    # New record that is immediately complete
                    item_status = "accepted"
            else:
                # Still incomplete
                if email in snapshot:
                    item_status = "duplicate"
                else:
                    item_status = "incomplete"
            
            proposed[email] = {
                "name": new_name,
                "city": new_city,
                "first_contact": new_first_contact,
                "sources": new_sources,
                "complete": new_complete,
            }
            batch_items.append(item_status)
        
        if conflict:
            batch_results.append({"status": "rejected", "items": []})
        else:
            # Commit: apply proposed changes to records
            for email, prop in proposed.items():
                records[email] = {
                    "name": prop["name"],
                    "city": prop["city"],
                    "first_contact": prop["first_contact"],
                    "sources": sorted(prop["sources"]),
                    "complete": prop["complete"],
                }
            batch_results.append({"status": "committed", "items": batch_items})
    
    # Build output
    accepted = []
    incomplete = []
    for email in sorted(records.keys()):
        rec = records[email]
        entry = {
            "email": email,
            "name": rec["name"],
            "city": rec["city"],
            "first_contact": rec["first_contact"],
            "sources": rec["sources"],
        }
        if rec["complete"]:
            accepted.append(entry)
        else:
            incomplete.append(entry)
    
    # Build sources view: source -> sorted list of emails that have records from that source
    sources_map = {}
    for email, rec in records.items():
        for src in rec["sources"]:
            if src not in sources_map:
                sources_map[src] = []
            sources_map[src].append(email)
    # Sort emails within each source
    for src in sources_map:
        sources_map[src] = sorted(sources_map[src])
    # Sort sources by key
    sources_out = {k: sources_map[k] for k in sorted(sources_map.keys())}
    
    return {
        "batches": batch_results,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_out,
    }
