# Workflow 可观测性报告

- Trial：`C031__yhBExsA__env`
- Task：`C031`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（67 节点 / 66 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：67；执行边：66（observed=0，inferred=66）
- Execution Trace Graph：`observed`；temporal_next 边 66，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_1a2df00bb3e94839b038cc69 -> tool:dsh:lead:call_240a55114f63411ca85aee72 -> tool:dsh:lead:call_08c4e025760944018ab48239 -> tool:dsh:lead:call_35faca6eebfb474ebfabe096 -> tool:dsh:lead:call_1353c242ae734199a7633441 -> tool:dsh:lead:call_012809142c6d43898858eedf -> tool:dsh:lead:call_ffd02668adac491db46bd61d -> tool:dsh:lead:call_bd3995611eaf4eadadcd50e7 -> tool:dsh:lead:call_a442b9ac602f4c2782c24351 -> tool:dsh:lead:call_5c891ef844764db6bffbe52c -> tool:dsh:lead:call_53ab2902823d4631b05ca1f7 -> tool:dsh:lead:call_d68d6275d2cb462783186869 -> tool:dsh:lead:call_d99d1546af084ba48cb112b9 -> tool:dsh:lead:call_9a3c73b8d4b14ddc9ef2718d -> tool:dsh:lead:call_45731f3503114c33b13ac1ee -> tool:dsh:lead:call_af7a9a5da12c4d4ca313493b -> tool:dsh:lead:call_b5f5dbae523e42a4acae366c -> tool:dsh:lead:call_d276937e61c644a28e90383b -> tool:dsh:lead:call_853adc6dc8594edf9615afa0 -> tool:dsh:lead:call_da15eda61c2d463aaa6e4eb3 -> tool:dsh:lead:call_df49066f2ac246dcaf20d6cb -> tool:dsh:lead:call_90376ca437d145b48dcd498e -> tool:dsh:lead:call_b048183e1bbb4ec19169cba1 -> tool:dsh:lead:call_f1e8b0e30060486383dcc70c -> tool:dsh:lead:call_06c4c3191e6548bdbf975c38 -> tool:dsh:lead:call_720a0e8134d14f1aa2236b52 -> tool:dsh:lead:call_28ba79b1861f4a8a8f92e2fe -> tool:dsh:lead:call_efeabeda4b27481a87837588 -> tool:dsh:lead:call_e272066a98d4425799631e32 -> tool:dsh:lead:call_79df21221dde493fb13c1c56 -> tool:dsh:lead:call_0f2df4b15b8f4299bbba32f1 -> tool:dsh:lead:call_e563a915e8bf4bebb4a8a231 -> tool:dsh:lead:call_46d6dc73775e493a822bc22f -> tool:dsh:lead:call_d96d2aa8d19f4a6098e7e288 -> tool:dsh:lead:call_2490b6606b3747acb784b844 -> tool:dsh:lead:call_fd74e64ece5d4e3199478c9c -> tool:dsh:lead:call_74dfef927fe54a5aa2c6354d -> tool:dsh:lead:call_639cc38951bb435cbb1234f4 -> tool:dsh:lead:call_fbe62a9a0d384aef83bbf330 -> tool:dsh:lead:call_fc7732437fb14a308cfb6eed -> tool:dsh:lead:call_505adc9bce2b482faefbee3d -> tool:dsh:lead:call_258bd1ceec27478bb525f9f6 -> tool:dsh:lead:call_b5ce2ccd4a614e6298eb5580 -> tool:dsh:lead:call_484f0f67c89a46c39335a440 -> tool:dsh:lead:call_d64882edbc614b6bb6351976 -> tool:dsh:lead:call_bd3fa854c72f4284b7f3990d -> tool:dsh:lead:call_c7196c379549456c83f8ee12 -> tool:dsh:lead:call_955589bd9bf24898890d9b00 -> tool:dsh:lead:call_c5a4f2a59acc460d9a949ec9 -> tool:dsh:lead:call_9714b0ddeb3b41419d8a9f03 -> tool:dsh:lead:call_fb77922589584e7c81e0ce02 -> tool:dsh:lead:call_e4f3c776ac1d41bb9d3c858d -> tool:dsh:lead:call_00d731ca442d4563a61138fe -> tool:dsh:lead:call_94ef346bbfcd44d0a1cdc756 -> tool:dsh:lead:call_8a146cff2ddd4d1db7cf29eb -> tool:dsh:lead:call_6afc818e9c284516b3e6c9e8 -> tool:dsh:lead:call_096d3c13259c4064852dc5a0 -> tool:dsh:lead:call_a66f2457db91440f9eb274d9 -> tool:dsh:lead:call_209cb491ad4f4942b716bb28 -> tool:dsh:lead:call_a5d1020fcf5649e9b868b483 -> tool:dsh:lead:call_1dc6e49c0fbe45348806d62d -> tool:dsh:lead:call_ce03e83862624acf9dedacc1 -> tool:dsh:lead:call_e05897daf602466abae4536c -> tool:dsh:lead:call_f983030d6ffb4f4a88ef8346 -> tool:dsh:lead:call_f9bd32a757614b9fa27f5430 -> tool:dsh:lead:call_ad58fa0904b9470faf4621ec
- 关键路径耗时：34.123
- Makespan：444.893
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
