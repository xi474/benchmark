def compute(payload):
    """输出 rc（固定主提示 PROMPT>、续行提示 CONT>、禁用历史、追加 startup）、timeout（缺省 4）、markers（原顺序的 until，可为 null）。"""
    startup = payload.get("startup", "")
    timeout = payload.get("timeout_seconds", 4)
    steps = payload.get("steps", [])

    # Build rc file content: PS1, PS2, HISTFILE, then startup
    rc_parts = [
        "PS1='PROMPT> '",
        "PS2='CONT> '",
        "HISTFILE=/dev/null",
        "",
    ]
    if startup:
        rc_parts.append(startup)
    rc = "\n".join(rc_parts) + "\n"

    markers = [step.get("until") for step in steps]

    return {
        "rc": rc,
        "timeout": timeout,
        "markers": markers,
    }
