import os
import select
import signal
import subprocess
import tempfile
import time


def _normalize(text):
    """Normalize CRLF/CR to LF, remove isolated CR."""
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "")
    return text


def _read_until(fd, marker, timeout, buf):
    """Read from fd until marker is found or timeout/EOF.

    Returns (chunk_text, closed).
    chunk_text includes the marker and any trailing bytes from the same burst.
    buf is a bytearray that accumulates unread data across calls.
    """
    marker_bytes = marker.encode("utf-8") if marker is not None else None
    deadline = time.monotonic() + timeout

    while True:
        # Check if marker already in buffer
        if marker_bytes is not None:
            idx = buf.find(marker_bytes)
            if idx != -1:
                end = idx + len(marker_bytes)
                # Try to grab any extra bytes from the same output burst
                remaining = max(0, deadline - time.monotonic())
                if remaining > 0:
                    try:
                        rlist, _, _ = select.select([fd], [], [], min(0.05, remaining))
                        if rlist:
                            extra = os.read(fd, 65536)
                            if extra:
                                buf.extend(extra)
                    except OSError:
                        pass
                chunk = bytes(buf[:end])
                del buf[:end]
                return _normalize(chunk.decode("utf-8", errors="replace")), False

        # Need more data
        remaining = max(0, deadline - time.monotonic())
        if remaining <= 0:
            # Timeout
            chunk = bytes(buf)
            buf.clear()
            return _normalize(chunk.decode("utf-8", errors="replace")), False

        try:
            rlist, _, _ = select.select([fd], [], [], min(remaining, 0.1))
            if rlist:
                try:
                    data = os.read(fd, 65536)
                    if not data:
                        # EOF
                        chunk = bytes(buf)
                        buf.clear()
                        return _normalize(chunk.decode("utf-8", errors="replace")), True
                    buf.extend(data)
                except OSError:
                    chunk = bytes(buf)
                    buf.clear()
                    return _normalize(chunk.decode("utf-8", errors="replace")), True
        except OSError:
            chunk = bytes(buf)
            buf.clear()
            return _normalize(chunk.decode("utf-8", errors="replace")), True


def _try_pty():
    """Check if PTY allocation works."""
    try:
        import pty as pty_mod
        m, s = pty_mod.openpty()
        os.close(m)
        os.close(s)
        return True
    except Exception:
        return False


def _run_pty(rc_path, tmpdir, key_hex_list, markers, timeout):
    """Run interactive bash with a real PTY."""
    import pty as pty_mod

    chunks = []
    closed = False
    master_fd = None
    pid = None

    try:
        pid, master_fd = pty_mod.fork()

        if pid == 0:
            # Child
            os.environ["HOME"] = tmpdir
            os.environ["TERM"] = "dumb"
            os.environ["LC_ALL"] = "C"
            os.environ["HISTFILE"] = "/dev/null"
            os.setsid()
            os.execvp("/bin/bash", ["/bin/bash", "--noprofile", "--rcfile", rc_path, "-i"])
        else:
            # Parent
            buf = bytearray()

            # Read initial prompt
            chunk, eof = _read_until(master_fd, "PROMPT> ", timeout, buf)
            chunks.append(chunk)
            if eof:
                closed = True

            for i, hex_str in enumerate(key_hex_list):
                if closed:
                    break
                raw_bytes = bytes.fromhex(hex_str)
                os.write(master_fd, raw_bytes)
                marker = markers[i] if i < len(markers) else None
                chunk, eof = _read_until(master_fd, marker, timeout, buf)
                chunks.append(chunk)
                if eof:
                    closed = True

    finally:
        if pid and pid > 0:
            try:
                os.killpg(pid, signal.SIGTERM)
            except (ProcessLookupError, PermissionError, OSError):
                pass
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass
            time.sleep(0.05)
            try:
                os.killpg(pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                pass
            try:
                os.waitpid(pid, 0)
            except ChildProcessError:
                pass
        if master_fd is not None:
            try:
                os.close(master_fd)
            except OSError:
                pass

    return chunks, closed


def _run_pipe(rc_path, tmpdir, key_hex_list, markers, timeout):
    """Fallback: run interactive bash with pipes when PTY is unavailable.

    In pipe mode bash echoes commands to stdout (merged with stderr).
    We replace CR with LF so bash can read complete lines.
    """
    chunks = []
    closed = False

    env = dict(os.environ)
    env["HOME"] = tmpdir
    env["TERM"] = "dumb"
    env["LC_ALL"] = "C"
    env["HISTFILE"] = "/dev/null"

    proc = subprocess.Popen(
        ["/bin/bash", "--noprofile", "--rcfile", rc_path, "-i"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
        preexec_fn=os.setsid,
    )

    try:
        read_fd = proc.stdout.fileno()
        buf = bytearray()

        # Read initial prompt - filter out terminal error messages
        chunk, eof = _read_until(read_fd, "PROMPT> ", timeout, buf)
        # Strip leading error lines that appear only in pipe mode
        lines = chunk.split("\n")
        filtered_lines = []
        for line in lines:
            if "cannot set terminal process group" in line:
                continue
            if "no job control" in line:
                continue
            filtered_lines.append(line)
        chunk = "\n".join(filtered_lines)
        chunks.append(chunk)
        if eof:
            closed = True

        for i, hex_str in enumerate(key_hex_list):
            if closed:
                break

            raw_bytes = bytes.fromhex(hex_str)
            # Replace CR with LF for pipe mode line reading
            pipe_bytes = raw_bytes.replace(b"\r", b"\n")

            try:
                os.write(proc.stdin.fileno(), pipe_bytes)
                proc.stdin.flush()
            except (BrokenPipeError, OSError):
                closed = True
                break

            marker = markers[i] if i < len(markers) else None
            chunk, eof = _read_until(read_fd, marker, timeout, buf)
            chunks.append(chunk)
            if eof:
                closed = True

    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                pass
            try:
                proc.wait(timeout=2)
            except Exception:
                pass

    return chunks, closed


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left = key_sequences result (list of hex strings)
    right = session_config result (dict with rc, timeout, markers)
    """
    key_hex_list = left
    rc_content = right["rc"]
    timeout = right["timeout"]
    markers = right["markers"]

    # Create temporary directory for this session
    tmpdir = tempfile.mkdtemp(prefix="c031_")

    try:
        # Create .hushlogin to suppress login messages
        with open(os.path.join(tmpdir, ".hushlogin"), "w"):
            pass

        # Write rc file
        rc_path = os.path.join(tmpdir, ".bashrc_c031")
        with open(rc_path, "w") as f:
            f.write(rc_content)

        # Try PTY first, fall back to pipes
        if _try_pty():
            chunks, closed = _run_pty(rc_path, tmpdir, key_hex_list, markers, timeout)
        else:
            chunks, closed = _run_pipe(rc_path, tmpdir, key_hex_list, markers, timeout)

    finally:
        import shutil
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass

    return {
        "chunks": chunks,
        "closed": closed,
    }
