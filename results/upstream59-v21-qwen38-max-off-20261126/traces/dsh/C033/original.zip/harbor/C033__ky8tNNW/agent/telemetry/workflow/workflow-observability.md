# Workflow 可观测性报告

- Trial：`C033__ky8tNNW__env`
- Task：`C033`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_40c5daeeb363442daeb74d7d -> tool:dsh:lead:call_e4793480ef094f5c8c29a83a -> tool:dsh:lead:call_7c765e26d2e84812a861f997 -> tool:dsh:lead:call_9f1b6e6633e04aac98ac8647 -> tool:dsh:lead:call_8005639764964a4eb9493d5f -> tool:dsh:lead:call_a6010efddbc847bd81c54812 -> tool:dsh:lead:call_091b55f744624cf29622160a -> tool:dsh:lead:call_e9029d428e1f4aa5b5d90fc2 -> tool:dsh:lead:call_55c0c4094e454fb19e9933c9 -> tool:dsh:lead:call_7b5fefa6084b47bca367a1d8 -> tool:dsh:lead:call_ee8e70da07fb4b9ea2594d8d -> tool:dsh:lead:call_141092271e5a4c48b42a4c7a -> tool:dsh:lead:call_da57d81093b14a358f700f88 -> tool:dsh:lead:call_38ef7cad3a8a4fccaa13edb4 -> tool:dsh:lead:call_164edf3848884d6f8ca44a56 -> tool:dsh:lead:call_adde04ee2eb7419da1cc01be -> tool:dsh:lead:call_879ccdf40cb24a9099e3fdff -> tool:dsh:lead:call_c0c2cea05b73478da1bd8f15 -> tool:dsh:lead:call_cc6e2ed4776f498f8965caa3 -> tool:dsh:lead:call_7951b35d34044a4fb77e834e -> tool:dsh:lead:call_ffc07f520afa41b08ba43f7b -> tool:dsh:lead:call_7b18154260734e2fb5e98000 -> tool:dsh:lead:call_6c6aa0760b454dc3b63010df -> tool:dsh:lead:call_aa018411427242588deded95 -> tool:dsh:lead:call_1ea403204b684e549f155ae4 -> tool:dsh:lead:call_209e4bc8e55a4d1e9c9664b1 -> tool:dsh:lead:call_a955d835d0c047f0acbdb2fa -> tool:dsh:lead:call_2467396f78304edeb0e53740 -> tool:dsh:lead:call_0c530d4988a1453cb049e220 -> tool:dsh:lead:call_367036d78314431b8f1b80e6 -> tool:dsh:lead:call_ccb418586d8247ddb32ab1a3 -> tool:dsh:lead:call_76be6c0460be4a0b87cf2e6a
- 关键路径耗时：1.011
- Makespan：320.515
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
