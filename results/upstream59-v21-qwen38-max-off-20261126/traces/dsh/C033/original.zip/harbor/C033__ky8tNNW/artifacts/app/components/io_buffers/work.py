def compute(payload):
    """Return [filename->bytearray mapping, stdin byte array]. Empty when not specified."""
    files_raw = payload.get("files", {}) or {}
    stdin_hex = payload.get("stdin_hex", "")

    # Convert files: each value is hex string -> list of byte values
    files_map = {}
    for name, hex_str in files_raw.items():
        if hex_str:
            raw = bytes.fromhex(hex_str)
            files_map[name] = list(raw)
        else:
            files_map[name] = []

    # Convert stdin
    if stdin_hex:
        stdin_bytes = list(bytes.fromhex(stdin_hex))
    else:
        stdin_bytes = []

    return [files_map, stdin_bytes]
