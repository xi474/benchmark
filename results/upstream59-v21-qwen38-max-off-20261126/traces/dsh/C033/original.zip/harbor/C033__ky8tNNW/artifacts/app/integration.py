"""MIPS32 little-endian interpreter with delay slots and Linux syscalls."""
import struct


def _sign_ext_16(v):
    """Sign-extend a 16-bit value to 32-bit signed."""
    if v & 0x8000:
        return v - 0x10000
    return v


def _to_u32(v):
    """Wrap to unsigned 32-bit."""
    return v & 0xFFFFFFFF


def _to_s32(v):
    """Interpret unsigned 32-bit as signed."""
    v = v & 0xFFFFFFFF
    if v >= 0x80000000:
        return v - 0x100000000
    return v


def combine(payload, elf_result, io_result):
    """
    elf_result: [entry_addr, [[addr, byte], ...]]
    io_result: [files_map, stdin_bytes]
    
    Returns the full execution result dict.
    """
    entry_addr, loaded_bytes = elf_result
    files_map, stdin_bytes = io_result

    # Build memory as dict (sparse)
    mem = {}
    for addr, byte_val in loaded_bytes:
        mem[addr] = byte_val

    # Registers
    regs = [0] * 32
    sp_default = payload.get("stack_pointer", 0x7FFF0000)
    regs[29] = sp_default  # $sp
    hi = 0
    lo = 0

    # File state
    # fd 0 = stdin, 1 = stdout, 2 = stderr
    file_contents = {}  # filename -> bytearray
    for name, byte_list in files_map.items():
        file_contents[name] = bytearray(byte_list)

    fd_table = {}  # fd -> {type, data, offset, flags}
    fd_table[0] = {"type": "stdin", "data": bytearray(stdin_bytes), "offset": 0}
    fd_table[1] = {"type": "stdout", "data": bytearray(), "offset": 0}
    fd_table[2] = {"type": "stderr", "data": bytearray(), "offset": 0}
    next_fd = 3

    # Track open files by name for close/reopen
    open_files = {}  # fd -> filename

    max_steps = payload.get("max_steps", 20000)
    inspect_list = payload.get("inspect", []) or []

    syscalls_log = []
    exit_code = None
    steps = 0

    pc = entry_addr

    def read_mem_byte(addr):
        return mem.get(addr & 0xFFFFFFFF, 0)

    def write_mem_byte(addr, val):
        mem[addr & 0xFFFFFFFF] = val & 0xFF

    def read_mem_half(addr):
        """Read 2 bytes little-endian."""
        b0 = read_mem_byte(addr)
        b1 = read_mem_byte(addr + 1)
        return (b1 << 8) | b0

    def write_mem_half(addr, val):
        write_mem_byte(addr, val & 0xFF)
        write_mem_byte(addr + 1, (val >> 8) & 0xFF)

    def read_mem_word(addr):
        """Read 4 bytes little-endian."""
        b0 = read_mem_byte(addr)
        b1 = read_mem_byte(addr + 1)
        b2 = read_mem_byte(addr + 2)
        b3 = read_mem_byte(addr + 3)
        return (b3 << 24) | (b2 << 16) | (b1 << 8) | b0

    def write_mem_word(addr, val):
        write_mem_byte(addr, val & 0xFF)
        write_mem_byte(addr + 1, (val >> 8) & 0xFF)
        write_mem_byte(addr + 2, (val >> 16) & 0xFF)
        write_mem_byte(addr + 3, (val >> 24) & 0xFF)

    def fetch(pc_addr):
        return read_mem_word(pc_addr)

    while exit_code is None and steps < max_steps:
        insn = fetch(pc)
        steps += 1

        op = (insn >> 26) & 0x3F
        rs = (insn >> 21) & 0x1F
        rt = (insn >> 16) & 0x1F
        rd = (insn >> 11) & 0x1F
        shamt = (insn >> 6) & 0x1F
        funct = insn & 0x3F
        imm16 = insn & 0xFFFF
        target26 = insn & 0x3FFFFFF

        rs_val = regs[rs]
        rt_val = regs[rt]
        se_imm = _sign_ext_16(imm16)

        next_pc = pc + 4
        delayed_jump = None  # If set, after delay slot, go here

        if op == 0:  # R-type
            if funct == 0:  # sll
                regs[rd] = _to_u32(rt_val << shamt)
            elif funct == 2:  # srl
                regs[rd] = _to_u32((rt_val & 0xFFFFFFFF) >> shamt)
            elif funct == 3:  # sra
                regs[rd] = _to_u32(_to_s32(rt_val) >> shamt)
            elif funct == 8:  # jr
                delayed_jump = rs_val & 0xFFFFFFFF
            elif funct == 9:  # jalr
                delayed_jump = rs_val & 0xFFFFFFFF
                regs[rd if rd != 0 else 31] = _to_u32(pc + 8)
            elif funct == 12:  # syscall
                # Syscall handling
                v0 = regs[2]
                a0 = regs[4]
                a1 = regs[5]
                a2 = regs[6]
                syscalls_log.append({"number": v0, "args": [a0, a1, a2]})

                if v0 == 4001:  # exit
                    exit_code = a0 & 0xFF
                elif v0 == 4003:  # read(fd, buf, n)
                    fd = a0
                    buf_addr = a1
                    count = a2
                    if fd in fd_table:
                        fdata = fd_table[fd]["data"]
                        off = fd_table[fd]["offset"]
                        available = len(fdata) - off
                        to_read = min(count, available)
                        for i in range(to_read):
                            write_mem_byte(buf_addr + i, fdata[off + i])
                        fd_table[fd]["offset"] += to_read
                        regs[2] = _to_u32(to_read)
                        regs[7] = 0
                    else:
                        regs[2] = _to_u32(-1)  # EBADF
                        regs[7] = _to_u32(-1)
                elif v0 == 4004:  # write(fd, buf, n)
                    fd = a0
                    buf_addr = a1
                    count = a2
                    if fd in fd_table:
                        written_data = bytearray()
                        for i in range(count):
                            written_data.append(read_mem_byte(buf_addr + i))
                        fd_table[fd]["data"].extend(written_data)
                        regs[2] = _to_u32(count)
                        regs[7] = 0
                    else:
                        regs[2] = _to_u32(-1)
                        regs[7] = _to_u32(-1)
                elif v0 == 4005:  # open(filename, flags, mode)
                    # Read null-terminated filename from memory
                    fname_bytes = bytearray()
                    addr = a0
                    while True:
                        b = read_mem_byte(addr)
                        if b == 0:
                            break
                        fname_bytes.append(b)
                        addr += 1
                    fname = fname_bytes.decode('utf-8')
                    flags = a1
                    # mode = a2  # not used per spec

                    fd = next_fd
                    next_fd += 1

                    if flags == 0:  # read-only existing
                        if fname in file_contents:
                            fd_table[fd] = {"type": "file", "data": bytearray(file_contents[fname]), "offset": 0}
                            open_files[fd] = fname
                            regs[2] = _to_u32(fd)
                            regs[7] = 0
                        else:
                            regs[2] = _to_u32(-1)
                            regs[7] = _to_u32(-1)
                    elif flags == 1:  # create/truncate
                        file_contents[fname] = bytearray()
                        fd_table[fd] = {"type": "file", "data": file_contents[fname], "offset": 0}
                        open_files[fd] = fname
                        regs[2] = _to_u32(fd)
                        regs[7] = 0
                    elif flags == 9:  # append/create (O_WRONLY|O_CREAT|O_APPEND)
                        if fname not in file_contents:
                            file_contents[fname] = bytearray()
                        fd_table[fd] = {"type": "file", "data": file_contents[fname], "offset": len(file_contents[fname])}
                        open_files[fd] = fname
                        regs[2] = _to_u32(fd)
                        regs[7] = 0
                    else:
                        regs[2] = _to_u32(-1)
                        regs[7] = _to_u32(-1)
                elif v0 == 4006:  # close(fd)
                    fd = a0
                    if fd in fd_table and fd > 2:
                        del fd_table[fd]
                        if fd in open_files:
                            del open_files[fd]
                        regs[2] = 0
                        regs[7] = 0
                    else:
                        regs[2] = _to_u32(-1)
                        regs[7] = _to_u32(-1)

            elif funct == 16:  # mfhi
                regs[rd] = hi
            elif funct == 17:  # mflo
                regs[rd] = lo
            elif funct == 18:  # mthi
                hi = rs_val
            elif funct == 19:  # mtlo
                lo = rs_val
            elif funct == 24:  # mult
                product = _to_s32(rs_val) * _to_s32(rt_val)
                product = product & 0xFFFFFFFFFFFFFFFF
                lo = _to_u32(product & 0xFFFFFFFF)
                hi = _to_u32((product >> 32) & 0xFFFFFFFF)
            elif funct == 25:  # multu
                product = (rs_val & 0xFFFFFFFF) * (rt_val & 0xFFFFFFFF)
                lo = _to_u32(product & 0xFFFFFFFF)
                hi = _to_u32((product >> 32) & 0xFFFFFFFF)
            elif funct == 26:  # div
                s_rs = _to_s32(rs_val)
                s_rt = _to_s32(rt_val)
                if s_rt != 0:
                    # Truncate toward zero
                    q = int(s_rs / s_rt)  # Python truncates toward zero for int division? No, use //
                    # Actually need truncation toward zero
                    if (s_rs < 0) != (s_rt < 0) and s_rs % s_rt != 0:
                        q = -(abs(s_rs) // abs(s_rt))
                    else:
                        q = abs(s_rs) // abs(s_rt)
                        if (s_rs < 0) != (s_rt < 0):
                            q = -q
                    r = s_rs - q * s_rt
                    lo = _to_u32(q)
                    hi = _to_u32(r)
            elif funct == 27:  # divu
                u_rs = rs_val & 0xFFFFFFFF
                u_rt = rt_val & 0xFFFFFFFF
                if u_rt != 0:
                    lo = _to_u32(u_rs // u_rt)
                    hi = _to_u32(u_rs % u_rt)
            elif funct == 32:  # add
                regs[rd] = _to_u32(_to_s32(rs_val) + _to_s32(rt_val))
            elif funct == 33:  # addu
                regs[rd] = _to_u32(rs_val + rt_val)
            elif funct == 34:  # sub
                regs[rd] = _to_u32(_to_s32(rs_val) - _to_s32(rt_val))
            elif funct == 35:  # subu
                regs[rd] = _to_u32(rs_val - rt_val)
            elif funct == 36:  # and
                regs[rd] = rs_val & rt_val
            elif funct == 37:  # or
                regs[rd] = rs_val | rt_val
            elif funct == 38:  # xor
                regs[rd] = rs_val ^ rt_val
            elif funct == 39:  # nor
                regs[rd] = _to_u32(~(rs_val | rt_val))
            elif funct == 42:  # slt
                regs[rd] = 1 if _to_s32(rs_val) < _to_s32(rt_val) else 0
            elif funct == 43:  # sltu
                regs[rd] = 1 if (rs_val & 0xFFFFFFFF) < (rt_val & 0xFFFFFFFF) else 0

        elif op == 2:  # j
            delayed_jump = _to_u32(((pc + 4) & 0xF0000000) | (target26 << 2))
        elif op == 3:  # jal
            delayed_jump = _to_u32(((pc + 4) & 0xF0000000) | (target26 << 2))
            regs[31] = _to_u32(pc + 8)
        elif op == 4:  # beq
            if rs_val == rt_val:
                delayed_jump = _to_u32((pc + 4) + (_sign_ext_16(imm16) << 2))
        elif op == 5:  # bne
            if rs_val != rt_val:
                delayed_jump = _to_u32((pc + 4) + (_sign_ext_16(imm16) << 2))
        elif op == 6:  # blez
            if _to_s32(rs_val) <= 0:
                delayed_jump = _to_u32((pc + 4) + (_sign_ext_16(imm16) << 2))
        elif op == 7:  # bgtz
            if _to_s32(rs_val) > 0:
                delayed_jump = _to_u32((pc + 4) + (_sign_ext_16(imm16) << 2))
        elif op == 8:  # addi
            regs[rt] = _to_u32(_to_s32(rs_val) + se_imm)
        elif op == 9:  # addiu
            regs[rt] = _to_u32(rs_val + se_imm)
        elif op == 10:  # slti
            regs[rt] = 1 if _to_s32(rs_val) < se_imm else 0
        elif op == 11:  # sltiu
            regs[rt] = 1 if (rs_val & 0xFFFFFFFF) < (_to_u32(se_imm)) else 0
        elif op == 12:  # andi
            regs[rt] = rs_val & imm16
        elif op == 13:  # ori
            regs[rt] = rs_val | imm16
        elif op == 14:  # xori
            regs[rt] = rs_val ^ imm16
        elif op == 15:  # lui
            regs[rt] = _to_u32(imm16 << 16)
        elif op == 32:  # lb
            addr = _to_u32(rs_val + se_imm)
            val = read_mem_byte(addr)
            if val & 0x80:
                val = val - 256
            regs[rt] = _to_u32(val)
        elif op == 33:  # lh
            addr = _to_u32(rs_val + se_imm)
            val = read_mem_half(addr)
            if val & 0x8000:
                val = val - 65536
            regs[rt] = _to_u32(val)
        elif op == 35:  # lw
            addr = _to_u32(rs_val + se_imm)
            regs[rt] = read_mem_word(addr)
        elif op == 36:  # lbu
            addr = _to_u32(rs_val + se_imm)
            regs[rt] = read_mem_byte(addr)
        elif op == 37:  # lhu
            addr = _to_u32(rs_val + se_imm)
            regs[rt] = read_mem_half(addr)
        elif op == 40:  # sb
            addr = _to_u32(rs_val + se_imm)
            write_mem_byte(addr, rt_val & 0xFF)
        elif op == 41:  # sh
            addr = _to_u32(rs_val + se_imm)
            write_mem_half(addr, rt_val & 0xFFFF)
        elif op == 43:  # sw
            addr = _to_u32(rs_val + se_imm)
            write_mem_word(addr, rt_val)

        # Always enforce r0 = 0
        regs[0] = 0

        # Handle delay slot
        if delayed_jump is not None:
            # Execute delay slot instruction (next instruction at pc+4)
            delay_pc = pc + 4
            delay_insn = fetch(delay_pc)
            steps += 1

            d_op = (delay_insn >> 26) & 0x3F
            d_rs = (delay_insn >> 21) & 0x1F
            d_rt = (delay_insn >> 16) & 0x1F
            d_rd = (delay_insn >> 11) & 0x1F
            d_shamt = (delay_insn >> 6) & 0x1F
            d_funct = delay_insn & 0x3F
            d_imm16 = delay_insn & 0xFFFF
            d_target26 = delay_insn & 0x3FFFFFF

            d_rs_val = regs[d_rs]
            d_rt_val = regs[d_rt]
            d_se_imm = _sign_ext_16(d_imm16)

            # Execute delay slot instruction (no further branching allowed per spec)
            if d_op == 0:  # R-type
                if d_funct == 0:  # sll
                    regs[d_rd] = _to_u32(d_rt_val << d_shamt)
                elif d_funct == 2:  # srl
                    regs[d_rd] = _to_u32((d_rt_val & 0xFFFFFFFF) >> d_shamt)
                elif d_funct == 3:  # sra
                    regs[d_rd] = _to_u32(_to_s32(d_rt_val) >> d_shamt)
                elif d_funct == 8:  # jr
                    pass  # shouldn't happen per spec
                elif d_funct == 9:  # jalr
                    pass
                elif d_funct == 12:  # syscall
                    v0 = regs[2]
                    a0 = regs[4]
                    a1 = regs[5]
                    a2 = regs[6]
                    syscalls_log.append({"number": v0, "args": [a0, a1, a2]})
                    if v0 == 4001:
                        exit_code = a0 & 0xFF
                    elif v0 == 4003:
                        fd = a0; buf_addr = a1; count = a2
                        if fd in fd_table:
                            fdata = fd_table[fd]["data"]; off = fd_table[fd]["offset"]
                            to_read = min(count, len(fdata) - off)
                            for i in range(to_read):
                                write_mem_byte(buf_addr + i, fdata[off + i])
                            fd_table[fd]["offset"] += to_read
                            regs[2] = _to_u32(to_read); regs[7] = 0
                        else:
                            regs[2] = _to_u32(-1); regs[7] = _to_u32(-1)
                    elif v0 == 4004:
                        fd = a0; buf_addr = a1; count = a2
                        if fd in fd_table:
                            wd = bytearray()
                            for i in range(count):
                                wd.append(read_mem_byte(buf_addr + i))
                            fd_table[fd]["data"].extend(wd)
                            regs[2] = _to_u32(count); regs[7] = 0
                        else:
                            regs[2] = _to_u32(-1); regs[7] = _to_u32(-1)
                    elif v0 == 4005:
                        fname_bytes = bytearray()
                        addr = a0
                        while True:
                            b = read_mem_byte(addr)
                            if b == 0: break
                            fname_bytes.append(b); addr += 1
                        fname = fname_bytes.decode('utf-8')
                        flags = a1
                        fd = next_fd; next_fd += 1
                        if flags == 0:
                            if fname in file_contents:
                                fd_table[fd] = {"type": "file", "data": bytearray(file_contents[fname]), "offset": 0}
                                open_files[fd] = fname; regs[2] = _to_u32(fd); regs[7] = 0
                            else:
                                regs[2] = _to_u32(-1); regs[7] = _to_u32(-1)
                        elif flags == 1:
                            file_contents[fname] = bytearray()
                            fd_table[fd] = {"type": "file", "data": file_contents[fname], "offset": 0}
                            open_files[fd] = fname; regs[2] = _to_u32(fd); regs[7] = 0
                        elif flags == 9:
                            if fname not in file_contents:
                                file_contents[fname] = bytearray()
                            fd_table[fd] = {"type": "file", "data": file_contents[fname], "offset": len(file_contents[fname])}
                            open_files[fd] = fname; regs[2] = _to_u32(fd); regs[7] = 0
                        else:
                            regs[2] = _to_u32(-1); regs[7] = _to_u32(-1)
                    elif v0 == 4006:
                        fd = a0
                        if fd in fd_table and fd > 2:
                            del fd_table[fd]
                            if fd in open_files: del open_files[fd]
                            regs[2] = 0; regs[7] = 0
                        else:
                            regs[2] = _to_u32(-1); regs[7] = _to_u32(-1)
                elif d_funct == 16:  # mfhi
                    regs[d_rd] = hi
                elif d_funct == 17:  # mflo
                    regs[d_rd] = lo
                elif d_funct == 18:  # mthi
                    hi = d_rs_val
                elif d_funct == 19:  # mtlo
                    lo = d_rs_val
                elif d_funct == 24:  # mult
                    product = _to_s32(d_rs_val) * _to_s32(d_rt_val)
                    product = product & 0xFFFFFFFFFFFFFFFF
                    lo = _to_u32(product & 0xFFFFFFFF)
                    hi = _to_u32((product >> 32) & 0xFFFFFFFF)
                elif d_funct == 25:  # multu
                    product = (d_rs_val & 0xFFFFFFFF) * (d_rt_val & 0xFFFFFFFF)
                    lo = _to_u32(product & 0xFFFFFFFF)
                    hi = _to_u32((product >> 32) & 0xFFFFFFFF)
                elif d_funct == 26:  # div
                    s_rs = _to_s32(d_rs_val); s_rt = _to_s32(d_rt_val)
                    if s_rt != 0:
                        if (s_rs < 0) != (s_rt < 0) and s_rs % s_rt != 0:
                            q = -(abs(s_rs) // abs(s_rt))
                        else:
                            q = abs(s_rs) // abs(s_rt)
                            if (s_rs < 0) != (s_rt < 0): q = -q
                        r = s_rs - q * s_rt
                        lo = _to_u32(q); hi = _to_u32(r)
                elif d_funct == 27:  # divu
                    u_rs = d_rs_val & 0xFFFFFFFF; u_rt = d_rt_val & 0xFFFFFFFF
                    if u_rt != 0:
                        lo = _to_u32(u_rs // u_rt); hi = _to_u32(u_rs % u_rt)
                elif d_funct == 32:  # add
                    regs[d_rd] = _to_u32(_to_s32(d_rs_val) + _to_s32(d_rt_val))
                elif d_funct == 33:  # addu
                    regs[d_rd] = _to_u32(d_rs_val + d_rt_val)
                elif d_funct == 34:  # sub
                    regs[d_rd] = _to_u32(_to_s32(d_rs_val) - _to_s32(d_rt_val))
                elif d_funct == 35:  # subu
                    regs[d_rd] = _to_u32(d_rs_val - d_rt_val)
                elif d_funct == 36:  # and
                    regs[d_rd] = d_rs_val & d_rt_val
                elif d_funct == 37:  # or
                    regs[d_rd] = d_rs_val | d_rt_val
                elif d_funct == 38:  # xor
                    regs[d_rd] = d_rs_val ^ d_rt_val
                elif d_funct == 39:  # nor
                    regs[d_rd] = _to_u32(~(d_rs_val | d_rt_val))
                elif d_funct == 42:  # slt
                    regs[d_rd] = 1 if _to_s32(d_rs_val) < _to_s32(d_rt_val) else 0
                elif d_funct == 43:  # sltu
                    regs[d_rd] = 1 if (d_rs_val & 0xFFFFFFFF) < (d_rt_val & 0xFFFFFFFF) else 0
            elif d_op == 2:  # j - shouldn't happen in delay slot per spec
                pass
            elif d_op == 3:  # jal
                pass
            elif d_op == 4:  # beq
                pass
            elif d_op == 5:  # bne
                pass
            elif d_op == 6:  # blez
                pass
            elif d_op == 7:  # bgtz
                pass
            elif d_op == 8:  # addi
                regs[d_rt] = _to_u32(_to_s32(d_rs_val) + d_se_imm)
            elif d_op == 9:  # addiu
                regs[d_rt] = _to_u32(d_rs_val + d_se_imm)
            elif d_op == 10:  # slti
                regs[d_rt] = 1 if _to_s32(d_rs_val) < d_se_imm else 0
            elif d_op == 11:  # sltiu
                regs[d_rt] = 1 if (d_rs_val & 0xFFFFFFFF) < _to_u32(d_se_imm) else 0
            elif d_op == 12:  # andi
                regs[d_rt] = d_rs_val & d_imm16
            elif d_op == 13:  # ori
                regs[d_rt] = d_rs_val | d_imm16
            elif d_op == 14:  # xori
                regs[d_rt] = d_rs_val ^ d_imm16
            elif d_op == 15:  # lui
                regs[d_rt] = _to_u32(d_imm16 << 16)
            elif d_op == 32:  # lb
                addr = _to_u32(d_rs_val + d_se_imm)
                val = read_mem_byte(addr)
                if val & 0x80: val = val - 256
                regs[d_rt] = _to_u32(val)
            elif d_op == 33:  # lh
                addr = _to_u32(d_rs_val + d_se_imm)
                val = read_mem_half(addr)
                if val & 0x8000: val = val - 65536
                regs[d_rt] = _to_u32(val)
            elif d_op == 35:  # lw
                addr = _to_u32(d_rs_val + d_se_imm)
                regs[d_rt] = read_mem_word(addr)
            elif d_op == 36:  # lbu
                addr = _to_u32(d_rs_val + d_se_imm)
                regs[d_rt] = read_mem_byte(addr)
            elif d_op == 37:  # lhu
                addr = _to_u32(d_rs_val + d_se_imm)
                regs[d_rt] = read_mem_half(addr)
            elif d_op == 40:  # sb
                addr = _to_u32(d_rs_val + d_se_imm)
                write_mem_byte(addr, d_rt_val & 0xFF)
            elif d_op == 41:  # sh
                addr = _to_u32(d_rs_val + d_se_imm)
                write_mem_half(addr, d_rt_val & 0xFFFF)
            elif d_op == 43:  # sw
                addr = _to_u32(d_rs_val + d_se_imm)
                write_mem_word(addr, d_rt_val)

            regs[0] = 0
            pc = delayed_jump
        else:
            pc = next_pc

        regs[0] = 0

    # Build output
    # stdout/stderr from fd_table
    stdout_hex = fd_table[1]["data"].hex() if 1 in fd_table else ""
    stderr_hex = fd_table[2]["data"].hex() if 2 in fd_table else ""

    # Files: convert back to hex
    out_files = {}
    for name, data in file_contents.items():
        out_files[name] = data.hex()

    # Inspect
    inspect_result = []
    for item in inspect_list:
        addr = item["address"]
        length = item["length"]
        hex_str = ""
        for i in range(length):
            hex_str += format(read_mem_byte(addr + i), '02x')
        inspect_result.append({"address": addr, "hex": hex_str})

    return {
        "exit_code": exit_code if exit_code is not None else 0,
        "registers": list(regs),
        "hi": hi,
        "lo": lo,
        "steps": steps,
        "stdout_hex": stdout_hex,
        "stderr_hex": stderr_hex,
        "files": out_files,
        "inspect": inspect_result,
        "syscalls": syscalls_log,
    }
