# Workflow 可观测性报告

- Trial：`C039__Rchqn6W__env`
- Task：`C039`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_a726325d6c024e8d934ae083 -> tool:dsh:lead:call_ed591075b6be4dfbb657bb98 -> tool:dsh:lead:call_920226cd02e64cfd8292bc53 -> tool:dsh:lead:call_9c0779e7428b42f790332919 -> tool:dsh:lead:call_1909c84f848d4b1da86ef378 -> tool:dsh:lead:call_412a2b288ce64fb4b75b9580 -> tool:dsh:lead:call_8ec18b22dae9446dbdde56ff -> tool:dsh:lead:call_69b512c2d9b24e2197cae330 -> tool:dsh:lead:call_2a6c9193df2e44609a861d76 -> tool:dsh:lead:call_d6a6084b36af4d2abaf1ad4f -> tool:dsh:lead:call_0765f78a33e341b7b1d2ab07 -> tool:dsh:lead:call_ec160e08522843bf8f14b934 -> tool:dsh:lead:call_bf40099fe7e64ba2b97faea0 -> tool:dsh:lead:call_aa2864c649dd4d09bb27ad58 -> tool:dsh:lead:call_4e125b6386ca4d2b94bf328e -> tool:dsh:lead:call_829689bf139f42e998a2a886 -> tool:dsh:lead:call_f32173b493b84971857a3307 -> tool:dsh:lead:call_8606f05cbae5436d8aebb6c4 -> tool:dsh:lead:call_537c5f46c99844dc95822af5 -> tool:dsh:lead:call_d5d1a0f023aa4a75a2813de8 -> tool:dsh:lead:call_082230f188c54fe3a2aba9d9 -> tool:dsh:lead:call_d3bcb03bd1ef49b580808950 -> tool:dsh:lead:call_9baa2ead3103426f8c3a692d -> tool:dsh:lead:call_22c1f0801d6044e2ab57e91a -> tool:dsh:lead:call_0f1ca0cd19e94cb8b8a9c0f5 -> tool:dsh:lead:call_20288b60a9f7494893404b95 -> tool:dsh:lead:call_434cc62cc161466fb2bc71f6 -> tool:dsh:lead:call_4831c4249cd94156b7e7134f -> tool:dsh:lead:call_10a78a0aa232420d8ee13e27 -> tool:dsh:lead:call_d4eeb7f105f14dceb91aee95 -> tool:dsh:lead:call_e175abbfcd574f4e9edabee1 -> tool:dsh:lead:call_c02f414393244f31a583c739 -> tool:dsh:lead:call_d084c1bf751b446392348d04 -> tool:dsh:lead:call_e482b32438b2473a8096d6b4 -> tool:dsh:lead:call_3bb13ca401bf410bb57d96e2 -> tool:dsh:lead:call_29721d1416774dfebbe0edc2 -> tool:dsh:lead:call_cfd55e77fb674e419c73326d -> tool:dsh:lead:call_6194d2d86eed40b696580234 -> tool:dsh:lead:call_8d9531617073496f9a5198f8 -> tool:dsh:lead:call_88c68e55222e4b9dbefcab8d
- 关键路径耗时：0.858
- Makespan：172.36
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
