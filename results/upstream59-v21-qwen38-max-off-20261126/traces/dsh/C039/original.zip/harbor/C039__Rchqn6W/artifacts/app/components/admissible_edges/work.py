def compute(payload):
    """排除指向根的边，按 allowed 顺序返回节点下标对。"""
    nodes = payload["nodes"]
    allowed = payload["allowed"]
    root = payload["root"]
    node_index = {n: i for i, n in enumerate(nodes)}
    root_idx = node_index[root]
    result = []
    for parent_name, child_name in allowed:
        child_idx = node_index[child_name]
        if child_idx == root_idx:
            continue
        parent_idx = node_index[parent_name]
        result.append([parent_idx, child_idx])
    return result
