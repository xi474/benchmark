def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    cov = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload["max_parents"]
    n = len(nodes)
    node_index = {nd: i for i, nd in enumerate(nodes)}
    root_idx = node_index[root]

    # Build set of allowed parent indices for each child node
    # Root cannot have parents; also edges pointing to root are excluded
    allowed_parents = [[] for _ in range(n)]
    for pname, cname in allowed:
        ci = node_index[cname]
        pi = node_index[pname]
        if ci == root_idx:
            continue
        allowed_parents[ci].append(pi)

    def solve_linear(A, b):
        """Solve Ax=b for small matrices using Gaussian elimination with partial pivoting."""
        n = len(b)
        # Augmented matrix
        M = [row[:] + [b[i]] for i, row in enumerate(A)]
        for col in range(n):
            # Partial pivoting
            max_row = col
            for row in range(col + 1, n):
                if abs(M[row][col]) > abs(M[max_row][col]):
                    max_row = row
            M[col], M[max_row] = M[max_row], M[col]
            pivot = M[col][col]
            for row in range(col + 1, n):
                factor = M[row][col] / pivot
                for j in range(col, n + 1):
                    M[row][j] -= factor * M[col][j]
        # Back substitution
        x = [0.0] * n
        for i in range(n - 1, -1, -1):
            s = M[i][n]
            for j in range(i + 1, n):
                s -= M[i][j] * x[j]
            x[i] = s / M[i][i]
        return x

    def regress(child_idx, parent_indices):
        """Return list of regression coefficients for given parent set."""
        if not parent_indices:
            return []
        k = len(parent_indices)
        # Build C_PP and C_Py
        CPP = [[cov[parent_indices[i]][parent_indices[j]] for j in range(k)] for i in range(k)]
        CPy = [cov[child_idx][pi] for pi in parent_indices]
        return solve_linear(CPP, CPy)

    result = []
    for node_i in range(n):
        table = {}
        # Empty parent set always included
        table[""] = []
        if node_i == root_idx:
            # Root has no parents allowed
            result.append(table)
            continue
        parents = sorted(allowed_parents[node_i])
        # Enumerate all subsets of parents up to max_parents
        from itertools import combinations
        for size in range(1, min(max_parents, len(parents)) + 1):
            for combo in combinations(parents, size):
                combo_sorted = tuple(sorted(combo))
                key = ",".join(str(x) for x in combo_sorted)
                coeffs = regress(node_i, list(combo_sorted))
                table[key] = coeffs
        result.append(table)
    return result
