import math
from itertools import combinations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    nodes = payload["nodes"]
    cov = payload["covariance"]
    mean_vec = payload["mean"]
    sample_size = payload["sample_size"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload["intervention"]
    n = len(nodes)

    # left = admissible_edges: list of [parent_idx, child_idx]
    # right = local_regressions: list of dicts per node

    admissible = left  # list of [pi, ci]
    reg_tables = right  # list of dicts

    # Build allowed parent sets per child from admissible edges
    allowed_parents_per_child = [[] for _ in range(n)]
    for pi, ci in admissible:
        allowed_parents_per_child[ci].append(pi)

    # For scoring: compute residual variance for a node given parent set
    def residual_variance(child_idx, parent_indices):
        if not parent_indices:
            return cov[child_idx][child_idx]
        k = len(parent_indices)
        # C_PP inverse via Gaussian elimination, then Cyy - CyP * CPP^-1 * CPy
        CPP = [[cov[parent_indices[i]][parent_indices[j]] for j in range(k)] for i in range(k)]
        CPy = [cov[child_idx][pi] for pi in parent_indices]
        # Solve CPP * x = CPy => x = CPP^-1 * CPy
        # Then residual = Cyy - CPy^T * x
        # Use Gaussian elimination
        M = [CPP[i][:] + [CPy[i]] for i in range(k)]
        for col in range(k):
            max_row = col
            for row in range(col + 1, k):
                if abs(M[row][col]) > abs(M[max_row][col]):
                    max_row = row
            M[col], M[max_row] = M[max_row], M[col]
            pivot = M[col][col]
            for row in range(col + 1, k):
                factor = M[row][col] / pivot
                for j in range(col, k + 1):
                    M[row][j] -= factor * M[col][j]
        x = [0.0] * k
        for i in range(k - 1, -1, -1):
            s = M[i][k]
            for j in range(i + 1, k):
                s -= M[i][j] * x[j]
            x[i] = s / M[i][i]
        cyy = cov[child_idx][child_idx]
        dot = sum(CPy[i] * x[i] for i in range(k))
        return cyy - dot

    def score_dag(edges_set):
        """Compute total BIC-like score for a DAG defined by edge set (set of (pi,ci))."""
        # Group parents per child
        parents_of = [[] for _ in range(n)]
        for pi, ci in edges_set:
            parents_of[ci].append(pi)
        total = 0.0
        for node_i in range(n):
            p_list = sorted(parents_of[node_i])
            rv = residual_variance(node_i, p_list)
            total += sample_size * math.log(rv) + len(p_list) * math.log(sample_size)
        return total

    def has_cycle(edges_set):
        """Check if directed graph has a cycle using DFS."""
        adj = [[] for _ in range(n)]
        for pi, ci in edges_set:
            adj[pi].append(ci)
        WHITE, GRAY, BLACK = 0, 1, 2
        color = [WHITE] * n
        def dfs(u):
            color[u] = GRAY
            for v in adj[u]:
                if color[v] == GRAY:
                    return True
                if color[v] == WHITE and dfs(v):
                    return True
            color[u] = BLACK
            return False
        for i in range(n):
            if color[i] == WHITE:
                if dfs(i):
                    return True
        return False

    # Enumerate all subsets of admissible edges of size edge_count
    # Check constraints: no cycles, in-degree <= max_parents
    best_score = None
    best_edges = None

    for combo in combinations(range(len(admissible)), edge_count):
        edge_set = tuple((admissible[i][0], admissible[i][1]) for i in combo)
        # Check in-degree constraint
        in_deg = [0] * n
        valid = True
        for pi, ci in edge_set:
            in_deg[ci] += 1
            if in_deg[ci] > max_parents:
                valid = False
                break
        if not valid:
            continue
        # Check acyclicity
        if has_cycle(edge_set):
            continue
        # Valid DAG candidate
        s = score_dag(edge_set)
        s_rounded = round(s, 9)
        # Sort edges as (parent, child) tuples for comparison
        sorted_edges = sorted(edge_set)
        if best_score is None or s_rounded < best_score or (s_rounded == best_score and sorted_edges < best_edges_sorted):
            best_score = s_rounded
            best_edges = edge_set
            best_edges_sorted = sorted_edges

    if best_edges is None:
        return {"feasible": False}

    # Build final result
    sorted_final_edges = sorted(best_edges)

    # Get coefficients from regression tables
    parents_of = [[] for _ in range(n)]
    for pi, ci in best_edges:
        parents_of[ci].append(pi)

    coefficients = []
    for pi, ci in sorted_final_edges:
        key = ",".join(str(x) for x in sorted(parents_of[ci]))
        coeffs = reg_tables[ci][key]
        # Find the coefficient for parent pi
        sorted_parents = sorted(parents_of[ci])
        idx_in_parents = sorted_parents.index(pi)
        slope = coeffs[idx_in_parents]
        coefficients.append([nodes[pi], nodes[ci], round(slope, 6)])

    # Format edges
    edges_out = [[nodes[pi], nodes[ci]] for pi, ci in sorted_final_edges]

    # Intervention
    int_node_name = intervention["node"]
    int_value = intervention["value"]
    int_idx = nodes.index(int_node_name)

    # Intervened edges: remove all incoming edges to intervention node
    intervened_edges_set = set()
    for pi, ci in best_edges:
        if ci != int_idx:
            intervened_edges_set.add((pi, ci))
    intervened_edges_sorted = sorted(intervened_edges_set)

    # Compute post-intervention means
    # For intervened node: mean = value
    # For others: mean = intercept + sum(slope_j * mean_j for parent j)
    # intercept = observed_mean - sum(slope_j * observed_mean_j for parent j)
    # Under intervention, we use structural equations with intervened node fixed

    # First compute slopes for all edges (unrounded)
    slopes = {}
    for pi, ci in best_edges:
        key = ",".join(str(x) for x in sorted(parents_of[ci]))
        coeffs = reg_tables[ci][key]
        sorted_parents = sorted(parents_of[ci])
        idx_in_parents = sorted_parents.index(pi)
        slopes[(pi, ci)] = coeffs[idx_in_parents]

    # Compute intercepts from observational data
    intercepts = [0.0] * n
    for node_i in range(n):
        if not parents_of[node_i]:
            intercepts[node_i] = mean_vec[node_i]
        else:
            pred = sum(slopes[(p, node_i)] * mean_vec[p] for p in parents_of[node_i])
            intercepts[node_i] = mean_vec[node_i] - pred

    # Post-intervention means: topological order computation
    # Build adjacency for intervened graph
    post_parents = [[] for _ in range(n)]
    for pi, ci in intervened_edges_set:
        post_parents[ci].append(pi)

    # Topological sort
    in_degree = [0] * n
    adj = [[] for _ in range(n)]
    for pi, ci in intervened_edges_set:
        adj[pi].append(ci)
        in_degree[ci] += 1
    queue = [i for i in range(n) if in_degree[i] == 0]
    topo_order = []
    while queue:
        queue.sort()
        u = queue.pop(0)
        topo_order.append(u)
        for v in adj[u]:
            in_degree[v] -= 1
            if in_degree[v] == 0:
                queue.append(v)

    post_mean = [0.0] * n
    for node_i in topo_order:
        if node_i == int_idx:
            post_mean[node_i] = int_value
        else:
            val = intercepts[node_i]
            for p in post_parents[node_i]:
                val += slopes[(p, node_i)] * post_mean[p]
            post_mean[node_i] = val

    # Format output
    intervened_edges_out = [[nodes[pi], nodes[ci]] for pi, ci in intervened_edges_sorted]
    mean_out = [round(m, 6) for m in post_mean]

    return {
        "feasible": True,
        "edges": edges_out,
        "score": round(best_score, 6),
        "coefficients": coefficients,
        "intervened_edges": intervened_edges_out,
        "mean": mean_out,
    }
