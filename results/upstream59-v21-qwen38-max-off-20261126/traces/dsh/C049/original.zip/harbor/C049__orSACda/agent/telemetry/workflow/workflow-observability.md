# Workflow 可观测性报告

- Trial：`C049__orSACda__env`
- Task：`C049`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_f6ac6df969c44222b50cef17 -> tool:dsh:lead:call_a1f9fb06d9064746a6e14f12 -> tool:dsh:lead:call_888b5d144fad4737afefad09 -> tool:dsh:lead:call_0a353a141328415ab40a0e97 -> tool:dsh:lead:call_06245b92ef2d49a0afa3bc2d -> tool:dsh:lead:call_e8b705ce672d42e681ab4677 -> tool:dsh:lead:call_4f188fcf85b047c9b9608c0b -> tool:dsh:lead:call_2a1a0bba1cc34fc1a429a750 -> tool:dsh:lead:call_dbdae7c0dd484c15ac9b016b -> tool:dsh:lead:call_5457351662b6485cbca35764 -> tool:dsh:lead:call_8fab7386b3294c7688cb6354 -> tool:dsh:lead:call_8978fa369ebc41fc999d8158 -> tool:dsh:lead:call_1a03792ed2e344cd985cd4ea -> tool:dsh:lead:call_cc444cedf1734830ad1d850f -> tool:dsh:lead:call_c1f32a16752c463091d8a7e8 -> tool:dsh:lead:call_6d633e7339dd45d189b30d27 -> tool:dsh:lead:call_465d6b26010a4893a814d324 -> tool:dsh:lead:call_9fb8d049435a4e3ab966a3eb -> tool:dsh:lead:call_80ef71abd12e45e481857eb6 -> tool:dsh:lead:call_d36716eea1fc4ad88f05ef73 -> tool:dsh:lead:call_91fb2c86568a43c0beb1bb34 -> tool:dsh:lead:call_fa551d723d3049478fc485d7 -> tool:dsh:lead:call_dd7470730c81478c8885bec1 -> tool:dsh:lead:call_4a84c2bab1a544eeb4e518ab -> tool:dsh:lead:call_2499c5969445423f98b3e504 -> tool:dsh:lead:call_d6c2d425e27e4c82b76b5fd6 -> tool:dsh:lead:call_7b73703f897e4e3396eae877 -> tool:dsh:lead:call_6720291a8f8045028f4fc930 -> tool:dsh:lead:call_40e8ba6b88ec41baaa868b46 -> tool:dsh:lead:call_ba81ba61eda541f7aaee4f6a -> tool:dsh:lead:call_d6bee3a4c9db4e5ba78f9743 -> tool:dsh:lead:call_d5bd3c86660b43899a7242f3 -> tool:dsh:lead:call_88f89d83805b43f3b329beb4 -> tool:dsh:lead:call_f2ebc0be112b4317874d152b -> tool:dsh:lead:call_60f1b65ebbb348b2a9cb6045 -> tool:dsh:lead:call_f43a2b0ac96f43bd8cc43232 -> tool:dsh:lead:call_75c54859c0694f648433312d -> tool:dsh:lead:call_a6d5a6674e50464bbfb41605 -> tool:dsh:lead:call_364e3016a44a4a828a5fd183
- 关键路径耗时：1.489
- Makespan：144.425
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
