import numpy as np


def compute(payload):
    """
    Forward/backward pass for a fully-connected network with pipeline parallelism.
    Returns loss and gradients[{weight, bias}] per layer.
    
    - All layers except last use tanh activation; last layer outputs logits.
    - Cross-entropy loss: per-microbatch mean, then equal-weight average across microbatches.
    - AFAB schedule: all microbatches forward through all stages, then backward in
      reverse microbatch order, reverse stage order.
    - Activations are stored per (microbatch, stage) — no reuse across microbatches.
    """
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]
    
    L = len(layers)
    num_microbatches = len(microbatches)
    
    # Compute stage partitions: rank r owns layers [floor(L*r/W), floor(L*(r+1)/W))
    partitions = []
    for r in range(world_size):
        start = (L * r) // world_size
        stop = (L * (r + 1)) // world_size
        partitions.append((start, stop))
    
    # Convert weights/biases to numpy float64
    weights = [np.array(layer["weight"], dtype=np.float64) for layer in layers]
    biases = [np.array(layer["bias"], dtype=np.float64) for layer in layers]
    
    # Initialize gradient accumulators
    grad_weights = [np.zeros_like(w) for w in weights]
    grad_biases = [np.zeros_like(b) for b in biases]
    
    total_loss = 0.0
    
    # Storage for activations per (microbatch, stage)
    # activations[mb][stage] = list of (input_to_stage, pre_activations_per_layer_in_stage, post_activations_per_layer_in_stage)
    # For each stage, we store the input to that stage and intermediate values
    
    # Forward pass: for each microbatch, go through all stages in order
    # Store activations needed for backward
    all_activations = []  # [mb] -> list of stage data
    
    for mb_idx in range(num_microbatches):
        inputs = np.array(microbatches[mb_idx]["inputs"], dtype=np.float64)  # [batch, in_dim]
        targets = microbatches[mb_idx]["targets"]  # list of class indices
        batch_size = inputs.shape[0]
        
        mb_stage_data = []
        current_input = inputs
        
        for stage_idx in range(world_size):
            start, stop = partitions[stage_idx]
            
            # Store input to this stage
            stage_input = current_input.copy()
            
            layer_pre_acts = []  # pre-activation (before tanh) for each layer in stage
            layer_post_acts = []  # post-activation for each layer in stage
            
            x = current_input
            for l in range(start, stop):
                z = x @ weights[l].T + biases[l]  # [batch, out_dim]
                layer_pre_acts.append(z)
                
                if l < L - 1:
                    # tanh activation
                    a = np.tanh(z)
                else:
                    # last layer: logits (no activation)
                    a = z
                
                layer_post_acts.append(a)
                x = a
            
            mb_stage_data.append({
                "stage_input": stage_input,
                "layer_pre_acts": layer_pre_acts,
                "layer_post_acts": layer_post_acts,
                "start": start,
                "stop": stop,
            })
            
            current_input = x
        
        # After all stages, current_input is the logits for this microbatch
        logits = current_input  # [batch, num_classes]
        
        # Compute cross-entropy loss for this microbatch
        # softmax
        log_probs = _log_softmax(logits)
        mb_loss = 0.0
        for i in range(batch_size):
            mb_loss -= log_probs[i, targets[i]]
        mb_loss /= batch_size
        
        total_loss += mb_loss
        
        all_activations.append({
            "stages": mb_stage_data,
            "logits": logits,
            "targets": targets,
            "batch_size": batch_size,
        })
    
    # Normalize loss: equal weight average across microbatches
    total_loss /= num_microbatches
    
    # Backward pass: reverse microbatch order, reverse stage order
    for mb_idx in reversed(range(num_microbatches)):
        mb_data = all_activations[mb_idx]
        stages = mb_data["stages"]
        logits = mb_data["logits"]
        targets = mb_data["targets"]
        batch_size = mb_data["batch_size"]
        
        # Gradient of loss w.r.t. logits
        # d(loss)/d(logits) = (softmax - one_hot) / (batch_size * num_microbatches)
        probs = _softmax(logits)
        d_logits = probs.copy()
        for i in range(batch_size):
            d_logits[i, targets[i]] -= 1.0
        d_logits /= (batch_size * num_microbatches)
        
        # Backward through stages in reverse order
        d_output = d_logits  # gradient flowing back
        
        for stage_idx in reversed(range(world_size)):
            stage_data = stages[stage_idx]
            start = stage_data["start"]
            stop = stage_data["stop"]
            layer_pre_acts = stage_data["layer_pre_acts"]
            layer_post_acts = stage_data["layer_post_acts"]
            stage_input = stage_data["stage_input"]
            
            # Backward through layers in this stage in reverse order
            d_x = d_output
            for li, l in enumerate(reversed(range(start, stop))):
                idx_in_stage = (stop - start - 1) - li  # index into layer_pre_acts / layer_post_acts
                z = layer_pre_acts[idx_in_stage]
                a = layer_post_acts[idx_in_stage]
                
                if l == L - 1:
                    # Last layer: no activation derivative
                    d_z = d_x
                else:
                    # tanh derivative: d_tanh = 1 - tanh^2
                    d_z = d_x * (1.0 - a ** 2)
                
                # Get input to this layer
                if idx_in_stage == 0:
                    layer_input = stage_input
                else:
                    layer_input = layer_post_acts[idx_in_stage - 1]
                
                # Accumulate gradients
                grad_weights[l] += d_z.T @ layer_input
                grad_biases[l] += d_z.sum(axis=0)
                
                # Propagate gradient to previous layer
                d_x = d_z @ weights[l]
            
            d_output = d_x
    
    # Build result
    gradients = []
    for l in range(L):
        gradients.append({
            "weight": grad_weights[l].tolist(),
            "bias": grad_biases[l].tolist(),
        })
    
    return {
        "loss": total_loss,
        "gradients": gradients,
    }


def _softmax(x):
    """Numerically stable softmax."""
    shifted = x - x.max(axis=1, keepdims=True)
    exp_x = np.exp(shifted)
    return exp_x / exp_x.sum(axis=1, keepdims=True)


def _log_softmax(x):
    """Numerically stable log-softmax."""
    shifted = x - x.max(axis=1, keepdims=True)
    log_sum_exp = np.log(np.exp(shifted).sum(axis=1, keepdims=True))
    return shifted - log_sum_exp
