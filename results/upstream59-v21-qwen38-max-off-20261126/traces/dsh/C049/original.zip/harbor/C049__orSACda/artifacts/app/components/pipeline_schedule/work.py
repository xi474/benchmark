def compute(payload):
    """
    Output partitions and AFAB events for pipeline parallelism.
    
    Partitions: rank r owns layers [floor(L*r/W), floor(L*(r+1)/W)).
    Events follow AFAB (All-Forward-All-Backward) schedule:
      - Forward: microbatches in order, stages in order.
        Each forward event; non-last stage followed by send_activation(source, target).
      - Backward: microbatches in reverse order, stages in reverse order.
        Each backward event; non-first stage followed by send_gradient(source, target).
    """
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]
    
    L = len(layers)
    num_microbatches = len(microbatches)
    
    # Compute partitions
    partitions = []
    for r in range(world_size):
        start = (L * r) // world_size
        stop = (L * (r + 1)) // world_size
        partitions.append({
            "stage": r,
            "start": start,
            "stop": stop,
        })
    
    # Build events
    events = []
    
    # Forward phase: each microbatch goes through all stages in order
    for mb_idx in range(num_microbatches):
        for stage_idx in range(world_size):
            events.append({
                "kind": "forward",
                "microbatch": mb_idx,
                "stage": stage_idx,
            })
            # Non-last stage sends activation to next stage
            if stage_idx < world_size - 1:
                events.append({
                    "kind": "send_activation",
                    "source": stage_idx,
                    "target": stage_idx + 1,
                })
    
    # Backward phase: reverse microbatch order, reverse stage order
    for mb_idx in reversed(range(num_microbatches)):
        for stage_idx in reversed(range(world_size)):
            events.append({
                "kind": "backward",
                "microbatch": mb_idx,
                "stage": stage_idx,
            })
            # Non-first stage sends gradient to previous stage
            if stage_idx > 0:
                events.append({
                    "kind": "send_gradient",
                    "source": stage_idx,
                    "target": stage_idx - 1,
                })
    
    return {
        "partitions": partitions,
        "events": events,
    }
