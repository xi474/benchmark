# Workflow 可观测性报告

- Trial：`C055__y6yBjy5__env`
- Task：`C055`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_855b88a0e6ab44dbac934ca3 -> tool:dsh:lead:call_8681d953cf374e1d885aff7d -> tool:dsh:lead:call_11976c07d385478aa58ad6db -> tool:dsh:lead:call_528863f66bcc4d2093f24251 -> tool:dsh:lead:call_bef3cfd96a104d1285558e77 -> tool:dsh:lead:call_45454e0cfa674dd5bdec955a -> tool:dsh:lead:call_82a25f999bc14d668fe6bb7d -> tool:dsh:lead:call_5db0505a8d4f4574af4054de -> tool:dsh:lead:call_88ae14452dae476fa0a14cec -> tool:dsh:lead:call_bb8472d2e332423ba7147566 -> tool:dsh:lead:call_2b796bb9619640cba7bdfcd6 -> tool:dsh:lead:call_5d69a31ed1c14bfe969c44ce -> tool:dsh:lead:call_94c264f3794d45fda3b1fe0f -> tool:dsh:lead:call_284717e950ca49d9ac944490 -> tool:dsh:lead:call_b3f3c9a93c7c4a23a93fd2ae -> tool:dsh:lead:call_2e757ab217e24dc7a0bc291a -> tool:dsh:lead:call_d2a77f0492fd479dacde5ff8 -> tool:dsh:lead:call_d491296b20e141ada01997ee -> tool:dsh:lead:call_6f11aa43d1114bb89e6321f5 -> tool:dsh:lead:call_f768a585364d4ef48ba63df2 -> tool:dsh:lead:call_65d6084231ec44f3a300db29 -> tool:dsh:lead:call_836b1ff1dfa44e1cb3e2c2b5 -> tool:dsh:lead:call_600665a13901409c9d41ae02 -> tool:dsh:lead:call_b7f8a338a9e34307b19b084d -> tool:dsh:lead:call_f42e39eb28a643839f27d65e -> tool:dsh:lead:call_cf0b6d1fe2704df2b94165e2 -> tool:dsh:lead:call_f2bb05c488944447b0e9d3d1 -> tool:dsh:lead:call_4d4be524406f4f25a3b65d3f -> tool:dsh:lead:call_f7487b59e7ea4e07af04ec17 -> tool:dsh:lead:call_a89352429ac340bd9387fa7b -> tool:dsh:lead:call_12b70336420f43b381c4bc0c -> tool:dsh:lead:call_03e42477280545e18ca7b16b -> tool:dsh:lead:call_8ab3dbb67ff0458fb9a6c9b3 -> tool:dsh:lead:call_114dca349d8b404788ca2453
- 关键路径耗时：0.752
- Makespan：158.199
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
