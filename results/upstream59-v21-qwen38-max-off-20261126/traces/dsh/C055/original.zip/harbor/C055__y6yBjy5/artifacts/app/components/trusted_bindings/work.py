import sys
from pathlib import Path

# Add project root to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from yaml_parser import parse_yaml


def compute(payload):
    """Parse trusted documents' overrides and in-document anchors.

    For each effective key, outputs:
      [original_source_index, decl_position, [val_position, text, is_vault, source_trusted]]
    where positions are [source_name, line, col].
    """
    sources = payload.get("sources", [])
    combined = {}  # key -> (source_index, decl_pos, val_info)

    for idx, src in enumerate(sources):
        if not src.get("trusted", False):
            continue
        name = src["name"]
        yaml_text = src.get("yaml", "")
        parsed = parse_yaml(yaml_text, name, idx, True)
        for key, (decl_pos, val_info) in parsed.items():
            combined[key] = (idx, decl_pos, val_info)

    # Convert to output format: dict of key -> [source_index, decl_pos, [val_pos, text, is_vault, trusted]]
    result = {}
    for key, (src_idx, decl_pos, val_info) in combined.items():
        result[key] = [src_idx, decl_pos, val_info]

    return result
