import json
import re


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left = trusted_bindings result: dict of key -> [src_idx, decl_pos, [val_pos, text, is_vault, trusted]]
    right = external_bindings result: same format
    """
    tags = payload.get("tags", True)
    keys = payload.get("keys", {})

    # Merge all bindings: higher source_index wins (later sources override earlier)
    all_bindings = {}
    for key, binding in left.items():
        all_bindings[key] = binding
    for key, binding in right.items():
        src_idx = binding[0]
        if key not in all_bindings or src_idx >= all_bindings[key][0]:
            all_bindings[key] = binding

    # Check if any vault without key mapping when tags=false
    if not tags:
        for key, binding in all_bindings.items():
            val_info = binding[2]
            is_vault = val_info[2]
            if is_vault and key not in keys:
                return {"status": "sealed"}

    # Build entries and compute renders
    # First pass: determine effective trusted and raw text for each key
    effective = {}
    for key, binding in all_bindings.items():
        src_idx, decl_pos, val_info = binding
        val_pos, text, is_vault, source_trusted = val_info

        if is_vault:
            if tags:
                eff_trusted = False
                eff_text = text  # vault ID
                sealed = True
            else:
                eff_trusted = True
                eff_text = keys[key]
                sealed = False
        else:
            eff_trusted = source_trusted
            eff_text = text
            sealed = False

        effective[key] = {
            "decl_pos": decl_pos,
            "val_pos": val_pos,
            "text": text,          # original text (for dump)
            "eff_text": eff_text,  # effective text (vault resolved if applicable)
            "trusted": eff_trusted,
            "is_vault": is_vault,
            "sealed": sealed,
        }

    # Compute render: recursive template expansion
    # For trusted values (plain trusted or unsealed vault), expand ${key} references
    # using the final render of the referenced key. Untrusted plain values stay raw.
    render_cache = {}

    def get_render(key):
        if key in render_cache:
            return render_cache[key]
        info = effective[key]
        if not info["trusted"]:
            # Untrusted plain value: keep raw text
            render_cache[key] = info["eff_text"]
            return info["eff_text"]
        # Trusted: expand templates
        result = _expand_template(info["eff_text"], get_render)
        render_cache[key] = result
        return result

    for key in sorted(all_bindings.keys()):
        get_render(key)

    # Build entries sorted by key
    entries = []
    for key in sorted(all_bindings.keys()):
        info = effective[key]
        entry = [
            key,
            info["decl_pos"],
            info["val_pos"],
            info["trusted"],
            render_cache[key],
        ]
        entries.append(entry)

    # Build dump sorted by key
    dump_lines = []
    for key in sorted(all_bindings.keys()):
        info = effective[key]
        if info["is_vault"] and tags:
            # Vault preserved: key: !vault "id"
            dump_val = "!vault " + json.dumps(info["text"], ensure_ascii=False)
        else:
            # Plain or unsealed vault: key: "text"
            dump_val = json.dumps(info["text"], ensure_ascii=False)
        dump_lines.append(f"{key}: {dump_val}")

    dump = "\n".join(dump_lines) + "\n" if dump_lines else ""

    return {
        "status": "ok",
        "entries": entries,
        "dump": dump,
    }


def _expand_template(text, get_render):
    """Recursively expand ${key} references in text."""
    pattern = re.compile(r'\$\{([a-z]+)\}')

    def replacer(match):
        ref_key = match.group(1)
        try:
            return get_render(ref_key)
        except KeyError:
            return match.group(0)  # leave unresolved refs as-is

    return pattern.sub(replacer, text)
