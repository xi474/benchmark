"""Parse the flat YAML subset used in this task."""


def parse_yaml(yaml_text, source_name, source_index, trusted):
    """Parse a YAML document sequence from a single source.

    Returns a list of (key, decl_pos, val_info) tuples where:
      - decl_pos = [source_name, line, col]  (1-based)
      - val_info = [val_pos, text, is_vault, trusted]
        val_pos = [source_name, line, col] of value start (1-based)

    Anchors (&name) and aliases (*name) are resolved within each document.
    Later documents in the same source override earlier ones for the same key.
    """
    lines = yaml_text.split('\n')
    # Remove trailing empty element from split if text ends with \n
    # But keep track of actual line count

    results = {}  # key -> (decl_pos, val_info)

    # Process documents separated by ---
    doc_lines = []  # list of (line_number_1based, line_text)
    current_doc = []

    for i, line in enumerate(lines):
        lineno = i + 1
        stripped = line.strip()
        if stripped == '---':
            # End current document, process it
            if current_doc:
                _process_document(current_doc, source_name, source_index, trusted, results)
            current_doc = []
        else:
            if stripped:  # skip blank lines
                current_doc.append((lineno, line))

    # Process last document
    if current_doc:
        _process_document(current_doc, source_name, source_index, trusted, results)

    return results


def _process_document(doc_lines, source_name, source_index, trusted, results):
    """Process a single YAML document's lines, updating results dict."""
    anchors = {}  # anchor_name -> (val_pos, text, is_vault)

    for lineno, line in doc_lines:
        # Find the colon-space separator
        colon_pos = line.find(': ')
        if colon_pos == -1:
            continue

        key = line[:colon_pos]
        # Validate key is lowercase letters only
        if not key or not all(c.islower() for c in key):
            continue

        value_part = line[colon_pos + 2:]  # after ": "
        val_col = colon_pos + 2 + 1  # 1-based column of first char of value_part

        decl_pos = [source_name, lineno, 1]  # key starts at column 1

        # Parse value: could have &anchor prefix, *alias, !vault, or plain
        anchor_name = None
        is_alias = False
        is_vault = False
        alias_target = None
        text = value_part
        actual_val_col = val_col

        if value_part.startswith('&'):
            # &name value
            space_idx = value_part.find(' ')
            if space_idx == -1:
                continue  # malformed
            anchor_name = value_part[1:space_idx]
            text = value_part[space_idx + 1:]
            actual_val_col = val_col  # value position includes the &
        elif value_part.startswith('*'):
            # *alias - rest of line is the alias name
            alias_target = value_part[1:].strip()
            is_alias = True
            actual_val_col = val_col
        elif value_part.startswith('!vault '):
            is_vault = True
            text = value_part[7:]  # after "!vault "
            actual_val_col = val_col  # includes !vault

        if is_alias:
            if alias_target in anchors:
                ref_val_pos, ref_text, ref_is_vault = anchors[alias_target]
                val_info = [ref_val_pos, ref_text, ref_is_vault, trusted]
            else:
                continue  # undefined alias, skip
        else:
            val_pos = [source_name, lineno, actual_val_col]
            val_info = [val_pos, text, is_vault, trusted]

            if anchor_name:
                anchors[anchor_name] = (val_pos, text, is_vault)

        results[key] = (decl_pos, val_info)
