# Workflow 可观测性报告

- Trial：`C056__JPEQSmC__env`
- Task：`C056`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（30 节点 / 29 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：30；执行边：29（observed=0，inferred=29）
- Execution Trace Graph：`observed`；temporal_next 边 29，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_9fae148f741e4831816bbafb -> tool:dsh:lead:call_c8a9d31e410a4cd8b370691b -> tool:dsh:lead:call_f720bd0655b84c90bb57ffa5 -> tool:dsh:lead:call_9e1b79094462459b880105ca -> tool:dsh:lead:call_82ade8ce90af4af5861ec130 -> tool:dsh:lead:call_6f3fe892034b4e1da1dafcce -> tool:dsh:lead:call_64a5486256a849f79892edda -> tool:dsh:lead:call_f293613a999b4e31a8d915ce -> tool:dsh:lead:call_dee22ea72b2442a682c60890 -> tool:dsh:lead:call_5939b7a3ddd54df698c8f464 -> tool:dsh:lead:call_c0592cf4a7ad4d069427106c -> tool:dsh:lead:call_fdd080ec2f7a4963b6023ea7 -> tool:dsh:lead:call_1333c8aae7ee44dcaa45cb8a -> tool:dsh:lead:call_0ffaaf8da4be4e03b652adae -> tool:dsh:lead:call_b685402149f24aea8c2ff9b4 -> tool:dsh:lead:call_e7d18f185d7a455084ff4b14 -> tool:dsh:lead:call_6173a750be754e28b0c76efd -> tool:dsh:lead:call_4cf6f900b43545bb997fb539 -> tool:dsh:lead:call_78db581787bc495083d40d5e -> tool:dsh:lead:call_9bcdd6d2af9940a6adc3271a -> tool:dsh:lead:call_f518f510ee88487da752e8b7 -> tool:dsh:lead:call_dc7c707ba40040f994c6963f -> tool:dsh:lead:call_17a61a4b4e4c4d3ba773645a -> tool:dsh:lead:call_1ad9902d3a3c4a638c81f9a2 -> tool:dsh:lead:call_0f32d478f4c84f3f9ef58072 -> tool:dsh:lead:call_89182a3590794ce18288ddff -> tool:dsh:lead:call_498a8ca7e0524d3eac18dceb -> tool:dsh:lead:call_8af686bafc37465292d39668 -> tool:dsh:lead:call_3c7dc9b507874ee890ce9afd
- 关键路径耗时：0.57
- Makespan：91.652
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
