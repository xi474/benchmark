def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = dependency_waves result: list of waves, each wave is sorted task ids
    right = feed_statistics result: {host: {stream: [[items, count, sum], ...]}} 
    """
    tasks_list = payload["tasks"]
    task_map = {t["id"]: t for t in tasks_list}
    pools = payload["pools"]
    initial = dict(payload["initial"])
    
    # Current fact values per host
    facts = dict(initial)
    
    # Round-robin counters for pools and feeds
    pool_counters = {pname: 0 for pname in pools}
    feed_counters = {}  # (host, stream) -> counter
    
    # Track reads
    pool_reads = {pname: 0 for pname in pools}
    feed_reads = {h: {s: 0 for s in payload["feeds"].get(h, {})} for h in payload.get("feeds", {})}
    
    # Result per task
    task_results = {}
    
    # Process waves (left = dependency waves)
    for wave in left:
        # All tasks in this wave share the same fact snapshot at wave start
        wave_facts = dict(facts)
        
        # Collect deltas per host for this wave
        host_deltas = {}
        
        # Process tasks in id-sorted order (already sorted by dependency_waves)
        for tid in wave:
            task = task_map[tid]
            pool_name = task["pool"]
            stream = task["stream"]
            attempts = task["attempts"]
            
            # Select host from pool (round-robin)
            pool_hosts = pools[pool_name]
            host_idx = pool_counters[pool_name] % len(pool_hosts)
            host = pool_hosts[host_idx]
            pool_counters[pool_name] += 1
            pool_reads[pool_name] += 1
            
            # Select batch from feed (round-robin on this host/stream)
            key = (host, stream)
            if key not in feed_counters:
                feed_counters[key] = 0
            
            # Get feed batches for this host/stream from the original feeds data
            feed_batches = payload["feeds"][host][stream]
            batch_idx = feed_counters[key] % len(feed_batches)
            items = list(feed_batches[batch_idx])
            feed_counters[key] += 1
            
            # Track feed reads
            if host in feed_reads and stream in feed_reads[host]:
                feed_reads[host][stream] += 1
            
            # base = fact value of host at wave start
            base = wave_facts[host]
            
            # parent = sum of committed deltas of direct parent tasks
            parent = sum(task_results[dep]["delta"] for dep in task["needs"])
            
            # Compute delta: sum of (base + item) * (1 + parent) for each item
            delta = sum((base + item) * (1 + parent) for item in items)
            
            task_results[tid] = {
                "host": host,
                "items": items,
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": attempts
            }
            
            # Accumulate delta for host (only committed after wave completes)
            host_deltas[host] = host_deltas.get(host, 0) + delta
        
        # After all tasks in wave succeed, update facts
        for host, d in host_deltas.items():
            facts[host] = facts.get(host, 0) + d
    
    return {
        "tasks": task_results,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads
    }
