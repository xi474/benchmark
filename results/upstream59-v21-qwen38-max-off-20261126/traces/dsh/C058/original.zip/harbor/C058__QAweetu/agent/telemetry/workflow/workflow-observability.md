# Workflow 可观测性报告

- Trial：`C058__QAweetu__env`
- Task：`C058`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（77 节点 / 76 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：77；执行边：76（observed=0，inferred=76）
- Execution Trace Graph：`observed`；temporal_next 边 76，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_31f00f42b2c346ffb0c2786b -> tool:dsh:lead:call_87e98788dfd6471a80efea8d -> tool:dsh:lead:call_6cc5537dbbc640baba5704fd -> tool:dsh:lead:call_6b165f2a138245fd9d109bb7 -> tool:dsh:lead:call_04df0a87449a4fec84e77638 -> tool:dsh:lead:call_26665486d8d0475c880c3725 -> tool:dsh:lead:call_7ab4956179b54144b811ff6b -> tool:dsh:lead:call_20f3ed8f327e41939cc2be5a -> tool:dsh:lead:call_065ca2312a404526ad5a71a5 -> tool:dsh:lead:call_af32e65a6a8e48d78f3e8179 -> tool:dsh:lead:call_da5b645aa0cc4012b015af1b -> tool:dsh:lead:call_f3d7a7eb9f294985bae4d819 -> tool:dsh:lead:call_dee8b5f1eecc422ebcc71467 -> tool:dsh:lead:call_c0ff288bf89f4a6bae86421e -> tool:dsh:lead:call_c12c070a220f49239a6ce2f8 -> tool:dsh:lead:call_4766aa661bce4bf8ad364e4c -> tool:dsh:lead:call_3411f06eb5a1405c93e1ff0e -> tool:dsh:lead:call_66d42202013a4890b5d35ff2 -> tool:dsh:lead:call_7505e8f5d73d4709baa3701d -> tool:dsh:lead:call_cc1bf9bec4b34b19845f293a -> tool:dsh:lead:call_e9b93b63806a4d13b973c761 -> tool:dsh:lead:call_3a7ddc847d014134883bbc76 -> tool:dsh:lead:call_e147441282ec4cffa01b4fa1 -> tool:dsh:lead:call_d5d583dc8ce4451cab842326 -> tool:dsh:lead:call_503890edb1db4c2384cc2a36 -> tool:dsh:lead:call_6617ae6dead74a54a08403fd -> tool:dsh:lead:call_7e0e22f5f0674bcb96dd6128 -> tool:dsh:lead:call_02e487b5ac734067940f4572 -> tool:dsh:lead:call_75648d8323d3476d8eae14d6 -> tool:dsh:lead:call_182fb549463d4842b13730c3 -> tool:dsh:lead:call_6d161b6bdc1f452a8f8eba2f -> tool:dsh:lead:call_e00313a2479b428994171043 -> tool:dsh:lead:call_7ba09563fc1342329368a309 -> tool:dsh:lead:call_4c4086120f3447d49cd6fabd -> tool:dsh:lead:call_4eb10dc39e4c4bbe97a487f8 -> tool:dsh:lead:call_5ed6143d80824d4fb4fd624f -> tool:dsh:lead:call_3de7390f32414e7fb238ace1 -> tool:dsh:lead:call_e2365fee4e444d2a803c29c1 -> tool:dsh:lead:call_e61ea8d312ef4b0495472c31 -> tool:dsh:lead:call_db7e9077dce745f19f425400 -> tool:dsh:lead:call_dc5b2936a5ee46729d6dd4a9 -> tool:dsh:lead:call_b5662c76f0a949ba93ae39ce -> tool:dsh:lead:call_8b83bd6e40a141e6af36a3d3 -> tool:dsh:lead:call_e1e39c57625b4e8cb3602fe2 -> tool:dsh:lead:call_5752b47023b348748f86e48d -> tool:dsh:lead:call_4033ace6d949404eae568f45 -> tool:dsh:lead:call_f40ae9489a98404495187697 -> tool:dsh:lead:call_24835ca9c76f4f489e66562e -> tool:dsh:lead:call_1aaf810ff6b34484b684e3f7 -> tool:dsh:lead:call_bfc830e594d4435487c7c0c8 -> tool:dsh:lead:call_78e64f1117f149d0a6b63194 -> tool:dsh:lead:call_83268f454c584c79bab70f39 -> tool:dsh:lead:call_80eba3d2f0df40658f126267 -> tool:dsh:lead:call_b24fea8f25724587ab39e9df -> tool:dsh:lead:call_9af4e881f5a243c3b0a5f463 -> tool:dsh:lead:call_947ac4c767b446318ba58050 -> tool:dsh:lead:call_7251850f46a04f1cbabd3b6f -> tool:dsh:lead:call_2db0414852604125a3c6dbb7 -> tool:dsh:lead:call_236d15a4b6e84dee97ce8e3b -> tool:dsh:lead:call_da49127a86914629bb8b56e8 -> tool:dsh:lead:call_02ec1c3463ea4c2e8aaff97b -> tool:dsh:lead:call_4aa2105d100648938db1c04b -> tool:dsh:lead:call_6badec35ca6f4cd6a937ba90 -> tool:dsh:lead:call_b6c0fddd4f904d6bb57925ae -> tool:dsh:lead:call_ae6e91c8d27f4b8c9d5fdbfc -> tool:dsh:lead:call_5f79fa524068433288e9f786 -> tool:dsh:lead:call_7c390fa51fcc4db688090853 -> tool:dsh:lead:call_49d5f7e7b8d24040b97f82bf -> tool:dsh:lead:call_5f3c91774d0448b6a434e28f -> tool:dsh:lead:call_7772b3255d4044a0b33880e5 -> tool:dsh:lead:call_f75eb14c73df41ab98126c9d -> tool:dsh:lead:call_9fc68259343140a78c6e212f -> tool:dsh:lead:call_e7e6d60765754a0986da67a3 -> tool:dsh:lead:call_59377aeadda040d98d7ea387 -> tool:dsh:lead:call_bf84fabdd9df4e9988bfda1f -> tool:dsh:lead:call_2d851dfc18f7482f9488bf16
- 关键路径耗时：2.478
- Makespan：757.51
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
