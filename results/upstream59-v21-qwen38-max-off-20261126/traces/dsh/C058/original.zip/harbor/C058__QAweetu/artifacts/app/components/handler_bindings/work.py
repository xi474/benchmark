def compute(payload):
    """输出 [处理器声明顺序映射,叶节点到通知清单的映射]。叶节点按同一树位置编码；通知名去重并按声明顺序排列，含 rescue、always。"""
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    PHASE_ORDER = ["pre", "roles", "includes", "tasks", "post"]

    # Handler declaration order mapping: handler_name -> index
    handler_order = {}
    for i, h in enumerate(handlers):
        if isinstance(h, str):
            handler_order[h] = i
        elif isinstance(h, dict) and "name" in h:
            handler_order[h["name"]] = i

    # Leaf node to notification list mapping
    notify_map = {}
    _walk_program(program, PHASE_ORDER, [], handler_order, notify_map)

    return [handler_order, notify_map]


def _walk_program(program, phase_order, prefix, handler_order, notify_map):
    """Walk the program tree and collect notify bindings for leaf tasks."""
    for phase_idx, phase_name in enumerate(phase_order):
        phase_items = program.get(phase_name, [])
        if not isinstance(phase_items, list):
            continue
        for item_idx, item in enumerate(phase_items):
            pos = prefix + [phase_idx, item_idx]
            _walk_item(item, pos, handler_order, notify_map)


def _walk_item(item, pos, handler_order, notify_map):
    """Walk a single item (task or block) and record notify bindings."""
    pos_key = "/".join(str(p) for p in pos)

    if isinstance(item, dict) and "block" in item:
        block_body = item["block"]
        # tasks branch = 0, rescue branch = 1, always branch = 2
        for branch_idx, branch_name in enumerate(["tasks", "rescue", "always"]):
            branch_items = block_body.get(branch_name, [])
            if not isinstance(branch_items, list):
                continue
            for sub_idx, sub_item in enumerate(branch_items):
                sub_pos = pos + [branch_idx, sub_idx]
                _walk_item(sub_item, sub_pos, handler_order, notify_map)
    else:
        # It's a task - collect notify list
        notify_list = item.get("notify", [])
        if not isinstance(notify_list, list):
            notify_list = [notify_list] if notify_list else []

        # Deduplicate and sort by handler declaration order
        seen = set()
        ordered_notifies = []
        for n in notify_list:
            if n not in seen and n in handler_order:
                seen.add(n)
                ordered_notifies.append(n)

        # Sort by declaration order
        ordered_notifies.sort(key=lambda x: handler_order[x])

        if ordered_notifies:
            notify_map[pos_key] = ordered_notifies

