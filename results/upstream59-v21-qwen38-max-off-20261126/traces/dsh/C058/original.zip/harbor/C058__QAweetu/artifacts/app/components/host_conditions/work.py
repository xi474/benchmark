def compute(payload):
    """每个 host 对应一张节点表，按树位置（各级整数以 / 分隔）记录 [可执行,会失败]；包含块节点。"""
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})

    PHASE_ORDER = ["pre", "roles", "includes", "tasks", "post"]

    result = {}
    for host in hosts:
        node_table = {}
        _walk_program(program, host, PHASE_ORDER, [], node_table)
        result[host] = node_table
    return result


def _walk_program(program, host, phase_order, prefix, node_table):
    """Walk the program tree and populate node_table for a given host."""
    for phase_idx, phase_name in enumerate(phase_order):
        phase_items = program.get(phase_name, [])
        if not isinstance(phase_items, list):
            continue
        for item_idx, item in enumerate(phase_items):
            pos = prefix + [phase_idx, item_idx]
            _walk_item(item, host, pos, node_table)


def _walk_item(item, host, pos, node_table):
    """Walk a single item (task or block) and record its conditions."""
    pos_key = "/".join(str(p) for p in pos)

    if isinstance(item, dict) and "block" in item:
        # It's a block
        block_only = item.get("only")
        block_executable = _check_only(block_only, host)
        # Blocks themselves don't have fail_hosts; they are executable based on 'only'
        # Block node: executable if only passes, never fails directly
        node_table[pos_key] = [block_executable, False]

        block_body = item["block"]
        # tasks branch = 0, rescue branch = 1, always branch = 2
        for branch_idx, branch_name in enumerate(["tasks", "rescue", "always"]):
            branch_items = block_body.get(branch_name, [])
            if not isinstance(branch_items, list):
                continue
            for sub_idx, sub_item in enumerate(branch_items):
                sub_pos = pos + [branch_idx, sub_idx]
                _walk_item(sub_item, host, sub_pos, node_table)
    else:
        # It's a task
        task_only = item.get("only")
        task_fail_hosts = item.get("fail_hosts", [])
        executable = _check_only(task_only, host)
        will_fail = host in task_fail_hosts if isinstance(task_fail_hosts, list) else False
        node_table[pos_key] = [executable, will_fail]


def _check_only(only_set, host):
    """Check if host satisfies the 'only' constraint."""
    if only_set is None:
        return True
    if isinstance(only_set, list):
        return host in only_set
    if isinstance(only_set, str):
        return host == only_set
    return True
