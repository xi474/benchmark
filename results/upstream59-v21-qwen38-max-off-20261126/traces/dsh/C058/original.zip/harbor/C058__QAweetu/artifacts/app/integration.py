def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})

    PHASE_ORDER = ["pre", "roles", "includes", "tasks", "post"]

    handler_order_map = right[0]
    notify_map = right[1]

    handler_names_ordered = sorted(handler_order_map.keys(),
                                   key=lambda h: handler_order_map[h])

    task_ids = {}
    _index_task_ids(program, PHASE_ORDER, task_ids)

    leaf_nodes = _build_leaf_node_list(program, PHASE_ORDER)

    batches = []

    host_states = {}
    for host in hosts:
        host_states[host] = {
            "failed": False,
            "node_results": {},
            "phase_notifications": {},
        }

    for phase_idx, phase_name in enumerate(PHASE_ORDER):
        phase_items = program.get(phase_name, [])
        if not isinstance(phase_items, list):
            continue

        for host in hosts:
            if host_states[host]["failed"]:
                continue
            conditions = left.get(host, {})
            for item_idx, item in enumerate(phase_items):
                if host_states[host]["failed"]:
                    break
                failed = _exec_item(item, [phase_idx, item_idx], host, conditions,
                                    notify_map, host_states[host], phase_idx)
                if failed:
                    host_states[host]["failed"] = True

        flush_pos = tuple([phase_idx, len(phase_items)])

        host_event_queues = {}
        for host in hosts:
            events = _get_phase_events(host, phase_idx, flush_pos,
                                       notify_map, host_states[host],
                                       handler_names_ordered, task_ids,
                                       leaf_nodes)
            host_event_queues[host] = events

        _generate_batches(batches, hosts, host_event_queues, leaf_nodes)

    final = {}
    for host in hosts:
        final[host] = "failed" if host_states[host]["failed"] else "ok"

    return {"batches": batches, "final": final}


PHASE_ORDER = ["pre", "roles", "includes", "tasks", "post"]


def _index_task_ids(program, phase_order, task_ids):
    for pi, pn in enumerate(phase_order):
        items = program.get(pn, [])
        if not isinstance(items, list):
            continue
        for ii, item in enumerate(items):
            _idx_item(item, [pi, ii], task_ids)


def _idx_item(item, pos, task_ids):
    if isinstance(item, dict) and "block" in item:
        bb = item["block"]
        for bi, bn in enumerate(["tasks", "rescue", "always"]):
            for si, sub in enumerate(bb.get(bn, []) or []):
                _idx_item(sub, pos + [bi, si], task_ids)
    else:
        tid = item.get("id", "") if isinstance(item, dict) else ""
        task_ids[tuple(pos)] = tid


def _build_leaf_node_list(program, phase_order):
    nodes = []
    for pi, pn in enumerate(phase_order):
        items = program.get(pn, [])
        if not isinstance(items, list):
            continue
        for ii, item in enumerate(items):
            _collect_leaves(item, [pi, ii], nodes)
    return nodes


def _collect_leaves(item, pos, nodes):
    if isinstance(item, dict) and "block" in item:
        bb = item["block"]
        for bi, bn in enumerate(["tasks", "rescue", "always"]):
            for si, sub in enumerate(bb.get(bn, []) or []):
                _collect_leaves(sub, pos + [bi, si], nodes)
    else:
        nodes.append(tuple(pos))


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------

def _exec_item(item, pos, host, conditions, notify_map, state, phase_idx):
    """Execute an item. Returns True if this item resulted in a failure
    that the CALLER needs to handle (task fail or block uncaught fail).
    Respects state['failed'] guard - skips if already failed."""
    if state["failed"]:
        return True
    return _exec_item_inner(item, pos, host, conditions, notify_map, state, phase_idx)


def _exec_item_inner(item, pos, host, conditions, notify_map, state, phase_idx):
    """Execute an item without checking state['failed'] guard.
    Used for always sections that must run regardless."""
    if isinstance(item, dict) and "block" in item:
        return _exec_block(item, pos, host, conditions, notify_map, state, phase_idx)
    else:
        return _exec_task(item, pos, host, conditions, notify_map, state, phase_idx)


def _exec_task(item, pos, host, conditions, notify_map, state, phase_idx):
    """Returns True if task failed."""
    pos_key = "/".join(str(p) for p in pos)
    cond = conditions.get(pos_key, [True, False])
    executable, will_fail = cond[0], cond[1]

    if not executable:
        state["node_results"][pos_key] = "skipped"
        return False

    if will_fail:
        state["node_results"][pos_key] = "failed"
        return True

    state["node_results"][pos_key] = "ok"
    _record_notify(pos_key, host, phase_idx, notify_map, state)
    return False


def _exec_block(item, pos, host, conditions, notify_map, state, phase_idx):
    """Execute a block. Returns True if uncaught failure propagated out."""
    block_only = item.get("only")
    if not _check_only(block_only, host):
        _skip_all(item, pos, state)
        return False

    bb = item["block"]

    # --- Normal tasks ---
    tasks_list = bb.get("tasks", []) or []
    block_failed = False
    fail_idx = -1
    for ti, t in enumerate(tasks_list):
        tpos = pos + [0, ti]
        child_failed = _exec_item(t, tpos, host, conditions, notify_map, state, phase_idx)
        if child_failed:
            block_failed = True
            fail_idx = ti
            break

    # Skip remaining normal tasks
    if block_failed:
        for ti in range(fail_idx + 1, len(tasks_list)):
            tpos = pos + [0, ti]
            _skip_all(tasks_list[ti], tpos, state)

    # --- Rescue ---
    rescue_list = bb.get("rescue", []) or []
    rescue_ok = False
    if block_failed and rescue_list:
        for ri, r in enumerate(rescue_list):
            rpos = pos + [1, ri]
            child_failed = _exec_item(r, rpos, host, conditions, notify_map, state, phase_idx)
            if child_failed:
                break
            rpk = "/".join(str(p) for p in rpos)
            if state["node_results"].get(rpk) == "ok":
                rescue_ok = True

    uncaught = block_failed and not rescue_ok
    if uncaught:
        state["failed"] = True
    
    # --- Always (runs regardless of prior failure) ---
    always_list = bb.get("always", []) or []
    for ai, a in enumerate(always_list):
        apos = pos + [2, ai]
        # Execute always items directly, bypassing the state["failed"] guard
        child_failed = _exec_item_inner(a, apos, host, conditions, notify_map, state, phase_idx)
        if child_failed:
            state["failed"] = True

    return state["failed"]


def _skip_all(item, pos, state):
    """Mark all leaf nodes under this item as skipped."""
    pk = "/".join(str(p) for p in pos)
    if isinstance(item, dict) and "block" in item:
        bb = item["block"]
        for bi, bn in enumerate(["tasks", "rescue", "always"]):
            for si, sub in enumerate(bb.get(bn, []) or []):
                _skip_all(sub, pos + [bi, si], state)
    else:
        if pk not in state["node_results"]:
            state["node_results"][pk] = "skipped"


def _check_only(only_set, host):
    if only_set is None:
        return True
    if isinstance(only_set, list):
        return host in only_set
    if isinstance(only_set, str):
        return host == only_set
    return True


def _record_notify(pos_key, host, phase_idx, notify_map, state):
    notifies = notify_map.get(pos_key, [])
    if not notifies:
        return
    pn = state["phase_notifications"]
    if phase_idx not in pn:
        pn[phase_idx] = {}
    if host not in pn[phase_idx]:
        pn[phase_idx][host] = set()
    for n in notifies:
        pn[phase_idx][host].add(n)


# ---------------------------------------------------------------------------
# Events & batches
# ---------------------------------------------------------------------------

def _get_phase_events(host, phase_idx, flush_pos,
                      notify_map, state, handler_names_ordered, task_ids,
                      leaf_nodes):
    events = []
    for np_ in leaf_nodes:
        if np_[0] != phase_idx:
            continue
        pk = "/".join(str(p) for p in np_)
        res = state["node_results"].get(pk, "skipped")
        if res == "skipped":
            continue
        tid = task_ids.get(np_)
        events.append((np_, "task", tid, res))

    pn = state["phase_notifications"].get(phase_idx, {})
    hh = pn.get(host)
    if hh:
        ordered = sorted(hh, key=lambda h: handler_names_ordered.index(h)
                         if h in handler_names_ordered else float('inf'))
        events.append((flush_pos, "flush", None, "ok", ordered))
        for h in ordered:
            events.append((flush_pos, "handler", h, "ok"))

    return events


def _generate_batches(batches, hosts, host_event_queues, leaf_nodes):
    pos_rank = {p: i for i, p in enumerate(leaf_nodes)}
    max_rank = len(leaf_nodes)

    queues = {h: list(evs) for h, evs in host_event_queues.items()}
    ptrs = {h: 0 for h in hosts}

    while True:
        best_rank = None
        best_hosts = []
        for h in hosts:
            p = ptrs[h]
            if p >= len(queues[h]):
                continue
            ev = queues[h][p]
            r = pos_rank.get(ev[0], max_rank)
            if best_rank is None or r < best_rank:
                best_rank = r
                best_hosts = [h]
            elif r == best_rank:
                best_hosts.append(h)

        if not best_hosts:
            break

        for h in best_hosts:
            ev = queues[h][ptrs[h]]
            ptrs[h] += 1
            kind = ev[1]
            entry = {"host": h, "kind": kind, "status": ev[3]}
            if kind == "task":
                entry["task"] = ev[2]
            elif kind == "flush":
                entry["handlers"] = ev[4]
            elif kind == "handler":
                entry["task"] = ev[2]
            batches.append(entry)
