# Workflow 可观测性报告

- Trial：`C062__r9J4qXp__env`
- Task：`C062`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_fc3a555a75f04b7594603622 -> tool:dsh:lead:call_632941eb08e749e2b5c515dd -> tool:dsh:lead:call_2d2227f9264748c0aed5b9ed -> tool:dsh:lead:call_41832775a8d8408499e37bae -> tool:dsh:lead:call_da348a86e0104fbc9c03ed5e -> tool:dsh:lead:call_8c235470fae84f6bb4bb9712 -> tool:dsh:lead:call_1cce2bea708841108c1b5ccd -> tool:dsh:lead:call_de11efa6cbb343bc93d099df -> tool:dsh:lead:call_c23b158405434761a4b86bac -> tool:dsh:lead:call_dfecc451ecda48faba6f30c4 -> tool:dsh:lead:call_68aed0f763a94ac2b0352c23 -> tool:dsh:lead:call_8be9da36e9d0425ab1d2c545 -> tool:dsh:lead:call_99fc917fef0448db91cc2d89 -> tool:dsh:lead:call_f4c0087e975a43cc9e4103ca -> tool:dsh:lead:call_3457fe2d088841a3994151dd -> tool:dsh:lead:call_d04e9e9961cc4f9081cc5059 -> tool:dsh:lead:call_f3ce546b607346b088d3852f -> tool:dsh:lead:call_90af9a2a49a84f2fbdc2b95a -> tool:dsh:lead:call_da65819ee74442c2a32a3580 -> tool:dsh:lead:call_ea4b32bbd2004d0ebbd02a3a -> tool:dsh:lead:call_16ff8ae2120e479996dcb475 -> tool:dsh:lead:call_e31c265d47ba4122be072235 -> tool:dsh:lead:call_e600bb5fb66b46ad8e5ec78d -> tool:dsh:lead:call_4b88bbe874434562b86a635c -> tool:dsh:lead:call_f21e5d93ee974af49e9c919c -> tool:dsh:lead:call_0d3ad08778b84496a7026614 -> tool:dsh:lead:call_2a2073b79c244a99a486792e -> tool:dsh:lead:call_d2300e8685d54f3f98c06fad -> tool:dsh:lead:call_72c9ae0f958c491ea352bc86 -> tool:dsh:lead:call_adbc4058ae75436f97fdd424 -> tool:dsh:lead:call_fe28445d1f874823916a87b7 -> tool:dsh:lead:call_bec0a9585ad541769610667e -> tool:dsh:lead:call_074ea0087eda4123b630724e -> tool:dsh:lead:call_424bdb14ee404480b3e78b98 -> tool:dsh:lead:call_c509b088f59242d7a260a63a -> tool:dsh:lead:call_30cb6cbed04d422aa49bb263 -> tool:dsh:lead:call_2c697a9d476a475c8f7b5fb6
- 关键路径耗时：0.728
- Makespan：234.14
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
