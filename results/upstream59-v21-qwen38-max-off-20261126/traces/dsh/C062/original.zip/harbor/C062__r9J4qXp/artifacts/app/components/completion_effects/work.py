def compute(payload):
    """对每个 complete 事件按原始位置记录 [正常完成事件名,新 revision 或 null]。取消与关闭优先级由整合逻辑决定。"""
    result = {}
    for i, ev in enumerate(payload.get("events", [])):
        if ev.get("op") == "complete":
            changed = ev.get("changed", False)
            if changed:
                new_rev = ev.get("revision")
            else:
                new_rev = None
            # event_name: snapshot_updated if changed, poll_unchanged if not
            event_name = "snapshot_updated" if changed else "poll_unchanged"
            result[str(i)] = [event_name, new_rev]
    return result
