def compute(payload):
    """对每个 open 事件按其原始位置（十进制字符串）建立初始状态，字段同最终 stores 项。"""
    result = {}
    for i, ev in enumerate(payload.get("events", [])):
        if ev.get("op") == "open":
            result[str(i)] = {
                "backend": ev["backend"],
                "state": "open",
                "job": None,
                "revision": ev.get("revision", 0),
                "closed_at": None,
                "updates": 0,
            }
    return result
