def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = store_initializers result: {str(index): initial_store_state}
    right = completion_effects result: {str(index): [event_name, new_revision_or_null]}

    Simulate full event processing to produce audit events and final stores.
    """
    events = payload.get("events", [])

    # Build initial stores from left (store_initializers)
    stores = {}
    for idx_str, init_state in left.items():
        idx = int(idx_str)
        ev = events[idx]
        store_name = ev["store"]
        stores[store_name] = {
            "backend": init_state["backend"],
            "state": init_state["state"],
            "job": init_state["job"],
            "revision": init_state["revision"],
            "closed_at": init_state["closed_at"],
            "updates": init_state["updates"],
        }

    # Pre-process completion_effects (right) into a lookup by event index
    completion_info = {}
    for idx_str, val in right.items():
        completion_info[int(idx_str)] = val

    # Track cancelled job ids that were consumed during close lookahead
    consumed_indices = set()

    audit_events = []

    i = 0
    while i < len(events):
        if i in consumed_indices:
            i += 1
            continue

        ev = events[i]
        op = ev["op"]
        store_name = ev["store"]
        time_val = ev["time"]

        if op == "open":
            audit_events.append({"time": time_val, "store": store_name, "event": "opened"})
            i += 1

        elif op == "poll":
            job_id = ev["job"]
            st = stores[store_name]

            if st["state"] in ("closing", "closed"):
                audit_events.append({"time": time_val, "store": store_name, "event": "poll_rejected"})
            elif st["job"] is not None:
                audit_events.append({"time": time_val, "store": store_name, "event": "poll_coalesced"})
            else:
                st["job"] = job_id
                audit_events.append({"time": time_val, "store": store_name, "event": "poll_started", "job": job_id})
            i += 1

        elif op == "complete":
            job_id = ev["job"]
            st = stores[store_name]

            comp = completion_info.get(i)
            if comp is None:
                i += 1
                continue

            event_name, new_rev = comp

            if event_name == "snapshot_updated":
                st["revision"] = new_rev
                st["updates"] += 1
                audit_events.append({"time": time_val, "store": store_name, "event": "snapshot_updated", "job": job_id})
            else:
                audit_events.append({"time": time_val, "store": store_name, "event": "poll_unchanged", "job": job_id})

            st["job"] = None
            i += 1

        elif op == "close":
            st = stores[store_name]

            if st["state"] == "closed":
                audit_events.append({"time": time_val, "store": store_name, "event": "close_returned"})
                i += 1
            elif st["state"] == "closing":
                # Re-close during closing: wait on same barrier
                # In sequential simulation, the barrier resolves when the
                # matching complete is found. Since we already emitted
                # cancel_sent/close_waiting for the first close, a second
                # close on the same barrier just returns when it resolves.
                # We emit close_returned here (the barrier will resolve at
                # the same point).
                audit_events.append({"time": time_val, "store": store_name, "event": "close_returned"})
                i += 1
            else:
                # state == "open"
                if st["job"] is None:
                    st["state"] = "closed"
                    st["closed_at"] = time_val
                    audit_events.append({"time": time_val, "store": store_name, "event": "close_returned"})
                    i += 1
                else:
                    # Has in-flight job: cancel and wait for complete
                    job_id = st["job"]
                    st["state"] = "closing"
                    audit_events.append({"time": time_val, "store": store_name, "event": "cancel_sent", "job": job_id})
                    audit_events.append({"time": time_val, "store": store_name, "event": "close_waiting"})

                    # Scan forward for the matching complete
                    j = i + 1
                    found = False
                    while j < len(events):
                        if j in consumed_indices:
                            j += 1
                            continue
                        cev = events[j]
                        if cev["op"] == "complete" and cev["store"] == store_name and cev["job"] == job_id:
                            # Cancelled complete: emit callback_cancelled then close_returned
                            audit_events.append({"time": cev["time"], "store": store_name, "event": "callback_cancelled", "job": job_id})
                            # Do NOT publish snapshot update
                            st["job"] = None
                            st["state"] = "closed"
                            st["closed_at"] = time_val
                            audit_events.append({"time": cev["time"], "store": store_name, "event": "close_returned"})
                            consumed_indices.add(j)
                            found = True
                            break
                        j += 1

                    if not found:
                        st["job"] = None
                        st["state"] = "closed"
                        st["closed_at"] = time_val
                        audit_events.append({"time": time_val, "store": store_name, "event": "close_returned"})

                    i += 1
        else:
            i += 1

    # Build final stores output
    final_stores = {}
    for sname, st in stores.items():
        final_stores[sname] = {
            "backend": st["backend"],
            "state": st["state"],
            "job": st["job"],
            "revision": st["revision"],
            "closed_at": st["closed_at"],
            "updates": st["updates"],
        }

    return {
        "events": audit_events,
        "stores": final_stores,
    }
