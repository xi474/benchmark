# Workflow 可观测性报告

- Trial：`C066__c5aNZ6P__env`
- Task：`C066`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（37 节点 / 36 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：37；执行边：36（observed=0，inferred=36）
- Execution Trace Graph：`observed`；temporal_next 边 36，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_9e1bd32382d5479cbb541eba -> tool:dsh:lead:call_0cea09e3097140b9a50e7170 -> tool:dsh:lead:call_4116f9cc34c9496a9aefc7d9 -> tool:dsh:lead:call_5ba13d7f9f1949d089cbd990 -> tool:dsh:lead:call_4cd62b42d8ff4eb08068a38d -> tool:dsh:lead:call_f88c184b348f4bf7bc2aadb2 -> tool:dsh:lead:call_121b2a79752f4c36b4911a0d -> tool:dsh:lead:call_788623ef67204efd8e5907c6 -> tool:dsh:lead:call_2974470fc6874b7eaa1c9d9f -> tool:dsh:lead:call_ee8079ab07bc481882eb615e -> tool:dsh:lead:call_00dfbc995a1a40d992e9e3c4 -> tool:dsh:lead:call_a961d3063d1949e3a6d0b40d -> tool:dsh:lead:call_0860572d223e4e64a5f884fc -> tool:dsh:lead:call_2b9a88b4886741b8aa879bef -> tool:dsh:lead:call_c7c72610312540e6ae185d88 -> tool:dsh:lead:call_9eef63f657fc408fbee2f46f -> tool:dsh:lead:call_9c04de700fea4987880c307a -> tool:dsh:lead:call_d40169afafd44bdeb3ad734c -> tool:dsh:lead:call_a3faaf12604f4a96bab6a84e -> tool:dsh:lead:call_3a3017ab48834fe8a92c8a03 -> tool:dsh:lead:call_ce2ac9326b9c4f8492f102e2 -> tool:dsh:lead:call_e1611178118b406d9134bf49 -> tool:dsh:lead:call_492e860553b44fb5abeb8981 -> tool:dsh:lead:call_78ed9b1bd9974155924d3f33 -> tool:dsh:lead:call_964346ef119c464d9f7211e1 -> tool:dsh:lead:call_2c4e20e7c15448068547796f -> tool:dsh:lead:call_492c79bde220431686e32312 -> tool:dsh:lead:call_c2b53865584b4413a3d23f87 -> tool:dsh:lead:call_e366b62f3d064ad7933fd01f -> tool:dsh:lead:call_8125490ae41e43139c48f2f5 -> tool:dsh:lead:call_d8d00a79ef0e4fb6bc67e244 -> tool:dsh:lead:call_8907b6504e544f30b35fd998 -> tool:dsh:lead:call_d694070b1cb347b48883c279 -> tool:dsh:lead:call_33945d5cafcc40b8ad99ddcd -> tool:dsh:lead:call_27279101c2a44505a14ba7ee -> tool:dsh:lead:call_319c177a3f5640c2805ae2fc
- 关键路径耗时：0.742
- Makespan：113.097
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
