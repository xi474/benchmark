def _validate_col(col):
    """Validate a single column's type annotation against its value.
    Returns (name, decoded_value) or None if type error."""
    name = col.get("name")
    ctype = col.get("type")
    value = col.get("value")

    if name == "key" and ctype == "text":
        # key must be non-null string
        if not isinstance(value, str):
            return None
        return (name, value)
    elif name == "body" and ctype == "text":
        # body can be string or null
        if value is not None and not isinstance(value, str):
            return None
        return (name, value)
    elif name == "rank" and ctype == "int":
        # rank can be integer-string or null
        if value is None:
            return (name, None)
        if isinstance(value, str):
            try:
                int(value)
                return (name, value)
            except (ValueError, TypeError):
                return None
        return None
    else:
        # Unknown column name/type combination - treat as type error
        return None


def compute(payload):
    """按事务、语句、行变更生成已解码的列映射。D 用空对象；类型错误用 null，使整合端按事务回滚。"""
    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        tx_changes = []
        for stmt in tx.get("statements", []):
            stmt_changes = []
            for change in stmt:
                op = change.get("op")
                if op == "D":
                    stmt_changes.append({})
                elif op in ("I", "U"):
                    cols = change.get("cols", [])
                    decoded = {}
                    type_error = False
                    for col in cols:
                        validated = _validate_col(col)
                        if validated is None:
                            type_error = True
                            break
                        decoded[validated[0]] = validated[1]
                    if type_error:
                        stmt_changes.append(None)
                    else:
                        stmt_changes.append(decoded)
                else:
                    stmt_changes.append(None)
            tx_changes.append(stmt_changes)
        result.append(tx_changes)
    return result
