def compute(payload):
    """按事务、语句生成被消费旧主键的去重有序数组，I 不消耗旧主键。"""
    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        tx_old_keys = []
        for stmt in tx.get("statements", []):
            seen = set()
            stmt_old_keys = []
            for change in stmt:
                op = change.get("op")
                if op in ("U", "D"):
                    old_key = change.get("old")
                    if old_key is not None and old_key not in seen:
                        seen.add(old_key)
                        stmt_old_keys.append(old_key)
            tx_old_keys.append(stmt_old_keys)
        result.append(tx_old_keys)
    return result
