def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = row_identities: [tx][stmt] -> list of old keys consumed
    right = column_decoding: [tx][stmt][change] -> decoded col map or null
    
    Executes full logical replication replay with PK swap support.
    """
    import copy

    initial = payload.get("initial", {})
    txs = payload.get("txs", [])

    # Current table state: {pk: {"body": ..., "rank": ...}}
    rows = {}
    for pk, vals in initial.items():
        rows[pk] = {"body": vals.get("body"), "rank": vals.get("rank")}

    log = []
    committed_lsns = set()

    for tx_idx, tx in enumerate(txs):
        lsn = tx["lsn"]

        # REPLAY check
        if lsn in committed_lsns:
            log.append([lsn, "REPLAY"])
            continue

        # Save snapshot for rollback
        saved_rows = copy.deepcopy(rows)
        abort = False

        statements = tx.get("statements", [])
        tx_old_keys = left[tx_idx] if tx_idx < len(left) else []
        tx_decoded = right[tx_idx] if tx_idx < len(right) else []

        for stmt_idx, stmt in enumerate(statements):
            if abort:
                break

            old_keys = tx_old_keys[stmt_idx] if stmt_idx < len(tx_old_keys) else []
            decoded_changes = tx_decoded[stmt_idx] if stmt_idx < len(tx_decoded) else []

            # Check for type errors (null in decoded changes means type error)
            for dc in decoded_changes:
                if dc is None:
                    abort = True
                    break
            if abort:
                break

            # Validate: all old keys must exist in current rows
            for ok in old_keys:
                if ok not in rows:
                    abort = True
                    break
            if abort:
                break

            # Build the statement operations
            # Phase 1: Remove all U/D old identities
            # Phase 2: Place I/U new rows
            
            # Collect new rows to insert/update
            new_entries = []  # list of (new_key, row_data)
            
            for change_idx, change in enumerate(stmt):
                op = change.get("op")
                decoded = decoded_changes[change_idx] if change_idx < len(decoded_changes) else {}

                if op == "D":
                    # Already handled by removal phase
                    pass
                elif op == "U":
                    old_key = change.get("old")
                    # Start from old row's data
                    old_row = rows[old_key]
                    new_body = decoded.get("body", old_row["body"]) if "body" in decoded else old_row["body"]
                    new_rank_raw = decoded.get("rank", old_row["rank"]) if "rank" in decoded else old_row["rank"]
                    new_key = decoded.get("key", old_key) if "key" in decoded else old_key
                    
                    # Decode rank: string -> int or null
                    if new_rank_raw is not None and isinstance(new_rank_raw, str):
                        new_rank = int(new_rank_raw)
                    else:
                        new_rank = new_rank_raw
                    
                    new_entries.append((new_key, {"body": new_body, "rank": new_rank}))
                elif op == "I":
                    # Must have key, body, rank in decoded
                    new_key = decoded.get("key")
                    new_body = decoded.get("body")
                    new_rank_raw = decoded.get("rank")
                    
                    if new_key is None:
                        abort = True
                        break
                    
                    # Decode rank
                    if new_rank_raw is not None and isinstance(new_rank_raw, str):
                        new_rank = int(new_rank_raw)
                    else:
                        new_rank = new_rank_raw
                    
                    new_entries.append((new_key, {"body": new_body, "rank": new_rank}))

            if abort:
                break

            # Execute: remove old keys first
            for ok in old_keys:
                if ok in rows:
                    del rows[ok]

            # Place new entries, checking for collisions
            # Among new entries themselves and with remaining rows
            new_keys_set = set()
            for new_key, row_data in new_entries:
                if new_key in rows or new_key in new_keys_set:
                    abort = True
                    break
                new_keys_set.add(new_key)
            
            if abort:
                break

            for new_key, row_data in new_entries:
                rows[new_key] = row_data

        if abort:
            rows = saved_rows
            log.append([lsn, "ABORT"])
        else:
            committed_lsns.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": rows}
