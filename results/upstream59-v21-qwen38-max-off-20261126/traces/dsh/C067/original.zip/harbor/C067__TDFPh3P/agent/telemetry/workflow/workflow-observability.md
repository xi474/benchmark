# Workflow 可观测性报告

- Trial：`C067__TDFPh3P__env`
- Task：`C067`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_af3b1a29bc704bd2b4b24f1d -> tool:dsh:lead:call_ef5dee8ec1c84bb6b7083018 -> tool:dsh:lead:call_acc885be88354c85934b3db7 -> tool:dsh:lead:call_5059cf4000d9400081614289 -> tool:dsh:lead:call_52a5fb62839749dda568ef0e -> tool:dsh:lead:call_e529a7cc8911462f8ee9bf58 -> tool:dsh:lead:call_fc76aaca309d4b1d9abd2ebe -> tool:dsh:lead:call_698741259123498a94fbcb22 -> tool:dsh:lead:call_753902d0aabe4355881c4ca8 -> tool:dsh:lead:call_da605e76cfb548ff978f7c82 -> tool:dsh:lead:call_654bc5d7a10b44d99a64df75 -> tool:dsh:lead:call_7f1d950325ce454e8176ced9 -> tool:dsh:lead:call_32ef3aaee419492990fe678e -> tool:dsh:lead:call_149ea7e4e63f49aeada2416f -> tool:dsh:lead:call_7ebe06d3c2054cc8a5b22f3a -> tool:dsh:lead:call_4a5154f8a33e42c8968d5819 -> tool:dsh:lead:call_933c35a90911409d93ba0d17 -> tool:dsh:lead:call_091641689c3741e5bbe12f72 -> tool:dsh:lead:call_7f0895a76ade46769cb0d946 -> tool:dsh:lead:call_c247888f51c34bd88d95004b -> tool:dsh:lead:call_9e61abc2b8404d47bf91804a -> tool:dsh:lead:call_2f5471331f984cec897972a3 -> tool:dsh:lead:call_28f5c379e6a5441288cde9d2 -> tool:dsh:lead:call_8c6d0570443c4244ba512a19 -> tool:dsh:lead:call_02c2e9fcc26346a5b0da1348 -> tool:dsh:lead:call_49e8ffe0575f4f2c9efb1fc7 -> tool:dsh:lead:call_1d358930e29c4393972f1a4e -> tool:dsh:lead:call_61c22e60f8564324b9822d0d -> tool:dsh:lead:call_3ec7b38508e64034ae446b33 -> tool:dsh:lead:call_42ea4492f68a472b920cc6f6 -> tool:dsh:lead:call_2331780736e642518d6e0005 -> tool:dsh:lead:call_fc9690b1ddc64519be707762 -> tool:dsh:lead:call_03d861fbbae44c8c9530680d -> tool:dsh:lead:call_d0999844864f484da12f31ca -> tool:dsh:lead:call_9a96fc3c7eaf4f65b4d73709 -> tool:dsh:lead:call_c42a701b4fa04c0b81f87ff8 -> tool:dsh:lead:call_acd22ac6157b4a7aa6a169c5 -> tool:dsh:lead:call_f1ca325805a84fbb84c0f0f3 -> tool:dsh:lead:call_0d725fe9db554cb389b04534 -> tool:dsh:lead:call_d43cd2150c5747fea4920abc
- 关键路径耗时：1.021
- Makespan：103.666
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
