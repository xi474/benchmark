def compute(payload):
    """按输入顺序重放策略变更，为每个 request 原位置生成授权布尔值。"""
    policies = {user: list(rules) for user, rules in payload.get("policies", {}).items()}
    events = payload.get("events", [])
    result = {}
    req_index = 0
    for ev in events:
        op = ev.get("op")
        if op == "policy":
            user = ev["user"]
            policies[user] = list(ev.get("allow", []))
        elif op == "request":
            user = ev.get("user", "")
            cluster = ev.get("cluster", "")
            verb = ev.get("verb", "")
            service = ev.get("service", "")
            allowed = False
            user_rules = policies.get(user, [])
            for rule in user_rules:
                if rule.get("cluster") != cluster:
                    continue
                if rule.get("verb") != verb:
                    continue
                rule_service = rule.get("service")
                if rule_service is None or rule_service == "*":
                    allowed = True
                    break
                if rule_service == service:
                    allowed = True
                    break
            result[str(req_index)] = allowed
            req_index += 1
    return result
