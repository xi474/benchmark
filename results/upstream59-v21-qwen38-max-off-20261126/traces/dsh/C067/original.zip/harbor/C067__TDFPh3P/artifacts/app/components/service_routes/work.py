def compute(payload):
    """按事件位置返回请求当时的 [集群模式,服务是否可用]；合并端负责授权优先和实际计数。"""
    import copy
    clusters = copy.deepcopy(payload.get("clusters", {}))
    events = payload.get("events", [])
    result = {}
    req_index = 0
    for ev in events:
        op = ev.get("op")
        if op == "service":
            cluster = ev["cluster"]
            service = ev["service"]
            available = ev.get("available", True)
            if cluster in clusters:
                clusters[cluster].setdefault("services", {})[service] = available
        elif op == "request":
            cluster = ev.get("cluster", "")
            service = ev.get("service", "")
            cluster_info = clusters.get(cluster, {})
            mode = cluster_info.get("mode", "unknown")
            services = cluster_info.get("services", {})
            svc_available = services.get(service, False)
            result[str(req_index)] = [mode, svc_available]
            req_index += 1
    return result
