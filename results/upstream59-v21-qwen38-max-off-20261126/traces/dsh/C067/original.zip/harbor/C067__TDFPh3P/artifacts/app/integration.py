def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload.get("events", [])

    # left = policy_decisions result: {"0": true/false, "1": true/false, ...}
    # right = service_routes result: {"0": [mode, available], "1": [mode, available], ...}

    replies = []
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0
    cert_counter = 0
    # cache keyed by (user, cluster, service) -> {"credential": ..., "expires": ...}
    cache = {}

    req_index = 0
    for ev in events:
        if ev.get("op") != "request":
            continue

        now = ev.get("time", 0)
        user = ev.get("user", "")
        cluster = ev.get("cluster", "")
        service = ev.get("service", "")
        req_id = ev.get("id", "")

        # Authorization check
        authorized = left.get(str(req_index), False)
        authorizer_calls += 1

        if not authorized:
            replies.append({"id": req_id, "status": "denied"})
            req_index += 1
            continue

        # Service lookup
        svc_info = right.get(str(req_index), ["unknown", False])
        mode = svc_info[0]
        available = svc_info[1]
        service_lookups += 1

        if not available:
            replies.append({"id": req_id, "status": "not_found"})
            req_index += 1
            continue

        if mode == "local":
            replies.append({
                "id": req_id,
                "status": "ok",
                "credential": "local",
                "route": "local"
            })
        elif mode == "remote":
            # Resolve reverse_tunnel route
            remote_routes += 1

            # Clean expired entries from cache before access
            keys_to_remove = []
            for key, entry in cache.items():
                if entry["expires"] <= now:
                    keys_to_remove.append(key)
            for key in keys_to_remove:
                del cache[key]

            cache_key = (user, cluster, service)
            if cache_key in cache:
                credential = cache[cache_key]["credential"]
            else:
                cert_counter += 1
                credential = f"cert-{cert_counter}"
                certificates_issued += 1
                cache[cache_key] = {
                    "credential": credential,
                    "expires": now + ttl
                }

            replies.append({
                "id": req_id,
                "status": "ok",
                "credential": credential,
                "route": "reverse_tunnel"
            })

        req_index += 1

    # Build final cache sorted by user/cluster/service
    final_cache = []
    for key in sorted(cache.keys()):
        user, cluster, service = key
        entry = cache[key]
        final_cache.append({
            "user": user,
            "cluster": cluster,
            "service": service,
            "credential": entry["credential"],
            "expires": entry["expires"]
        })

    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": final_cache
    }
