# Workflow 可观测性报告

- Trial：`C068__RnwZ7We__env`
- Task：`C068`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_f64a37f6d18e4d44bc687214 -> tool:dsh:lead:call_a99eb3e8a49846fc82401717 -> tool:dsh:lead:call_d214d3163ef4461eb8c5c2bc -> tool:dsh:lead:call_1e18e951729f45c6b002ca3a -> tool:dsh:lead:call_b061f38fd1754ebf98266dee -> tool:dsh:lead:call_876e80eaf5c54d759b77900f -> tool:dsh:lead:call_9f55b5735fb341b7826470b7 -> tool:dsh:lead:call_573e3456de104be3928aa017 -> tool:dsh:lead:call_f3f766abe8cf43d6b0954c53 -> tool:dsh:lead:call_faa2e9f7f47d42a586a8fe52 -> tool:dsh:lead:call_f53d8c0ec86240f48c54d01c -> tool:dsh:lead:call_8f25b73a434c4b518014c220 -> tool:dsh:lead:call_4a410d173f264dd2b0891ff7 -> tool:dsh:lead:call_a6c9f1b3c48942ad837dbd35 -> tool:dsh:lead:call_d293f0a37c804c3d8fae4adc -> tool:dsh:lead:call_39bc1344ab4c4d0b91467544 -> tool:dsh:lead:call_a723d89054c042fb9acaf3d8 -> tool:dsh:lead:call_0462c012f0dd482a9311663b -> tool:dsh:lead:call_3c1e89768be3427999434469 -> tool:dsh:lead:call_51863efcaf8a4fc5a67c2a20 -> tool:dsh:lead:call_a698cca1bd07475a8726690b -> tool:dsh:lead:call_50c59085551e46d892ebd726 -> tool:dsh:lead:call_0184eb721216478ba6fd5f8c -> tool:dsh:lead:call_825634fd781644e2b1599154 -> tool:dsh:lead:call_74fff46f5adc43e0a4d63eab -> tool:dsh:lead:call_0a0ae3cd549d4c25bdea9d13 -> tool:dsh:lead:call_b95b9eaf8af7451c8e00035a -> tool:dsh:lead:call_d142845511084d3cbc35124e -> tool:dsh:lead:call_c05a0246f81844628442689a -> tool:dsh:lead:call_cee9ad2653244421a3734a28 -> tool:dsh:lead:call_93f31376b1294087bec62f7a -> tool:dsh:lead:call_b1680b90044b4b3d87ba627f -> tool:dsh:lead:call_ab6e5fb7732b4ffdb9a0d55e -> tool:dsh:lead:call_8a9c22005e4e4dd49b88f809 -> tool:dsh:lead:call_73b2478a3abc41458da66935 -> tool:dsh:lead:call_cad5f4d6297940f887e9fff3 -> tool:dsh:lead:call_dc489b6f445c4e5a8a5fcb4a -> tool:dsh:lead:call_d8232daebe4042b7a3ca8571 -> tool:dsh:lead:call_8c1cdb8eb1114c569cc2cd7c -> tool:dsh:lead:call_37591e4fa60a4d5d83b0af7e -> tool:dsh:lead:call_8eac6ea0a8a94b5c8af2f83e
- 关键路径耗时：1.004
- Makespan：172.713
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
