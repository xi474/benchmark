def compute(payload):
    """为每个 get 的原始位置生成 [若启动时的完成时刻,value,error]；只有命中未复用时才实际启动。"""
    events = payload["events"]
    result = {}
    for idx, ev in enumerate(events):
        if ev["op"] != "get":
            continue
        finished_at = ev["time"] + ev["delay"]
        result[str(idx)] = [finished_at, ev["value"], ev.get("error")]
    return result
