def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # Parse component outputs
    # left: cleanup_clock - map of get-index-string -> new next_cleanup after cleanup trigger
    cleanup_triggers = left  # dict str(idx) -> new_next_cleanup
    # right: load_proposals - map of get-index-string -> [finished_at, value, error]
    proposals = right  # dict str(idx) -> [finished_at, value, error]

    # Simulation state
    cache = {}  # key -> {"value": ..., "error": ..., "expires": ...}
    next_cleanup = 16 * ttl
    in_flight = {}  # key -> {"finished_at": int, "value": ..., "error": ..., "waiters": [...], "started_at": int}
    results = []  # list of result dicts in get order
    loads_output = []  # list of actually started loads
    get_index = 0  # tracks original position among all events for indexing into proposals/cleanup

    # We need to process events in order, completing due loads before each event
    # Collect all events with their indices
    event_list = list(enumerate(events))

    for ev_idx, ev in event_list:
        op = ev["op"]
        now = ev["time"]

        # Before processing this event, complete all due loads (finished_at <= now)
        # Order: by load start order (which is insertion order of in_flight)
        # "cancel和已完成load同刻时完成优先" - completions happen before cancels at same time
        # Since we process completions before the event, and cancel is an event, this is handled.
        due_keys = []
        for key, load_info in list(in_flight.items()):
            if load_info["finished_at"] <= now:
                due_keys.append(key)
        # Complete in start order (dict preserves insertion order in Python 3.7+)
        for key in due_keys:
            load_info = in_flight.pop(key)
            finished_at = load_info["finished_at"]
            value = load_info["value"]
            error = load_info["error"]
            # Stamp cache
            cache[key] = {
                "value": value if error is None else None,
                "error": error,
                "expires": finished_at + ttl
            }
            # Resolve waiters
            for waiter in load_info["waiters"]:
                if waiter["cancelled"]:
                    continue
                waiter["resolved"] = True
                waiter["status"] = "ok" if error is None else "error"
                waiter["value"] = value if error is None else None
                waiter["error"] = error
                waiter["finished_at"] = finished_at

        if op == "get":
            gid = ev["id"]
            key = ev["key"]
            delay = ev["delay"]
            value = ev["value"]
            error = ev.get("error")

            # Check cleanup trigger from cleanup_clock component
            pos_str = str(ev_idx)
            if pos_str in cleanup_triggers:
                # Perform cleanup: remove all expired entries
                expired_keys = [k for k, v in cache.items() if v["expires"] <= now]
                for k in expired_keys:
                    del cache[k]
                next_cleanup = cleanup_triggers[pos_str]

            # Remove expired entry for the specific key being accessed
            if key in cache and cache[key]["expires"] <= now:
                del cache[key]

            # Create waiter entry
            waiter = {
                "id": gid,
                "cancelled": False,
                "resolved": False,
                "status": None,
                "value": None,
                "error": None,
                "finished_at": None,
            }

            # Check cache hit
            if key in cache:
                entry = cache[key]
                waiter["resolved"] = True
                if entry["error"] is not None:
                    waiter["status"] = "error"
                    waiter["value"] = None
                    waiter["error"] = entry["error"]
                else:
                    waiter["status"] = "ok"
                    waiter["value"] = entry["value"]
                    waiter["error"] = None
                waiter["finished_at"] = now
            elif key in in_flight:
                # Join existing in-flight load
                in_flight[key]["waiters"].append(waiter)
            else:
                # Start new load
                proposal = proposals[pos_str]
                finished_at = proposal[0]  # time + delay
                p_value = proposal[1]
                p_error = proposal[2]

                load_info = {
                    "finished_at": finished_at,
                    "value": p_value,
                    "error": p_error,
                    "waiters": [waiter],
                    "started_at": now,
                }
                in_flight[key] = load_info
                loads_output.append({
                    "key": key,
                    "started_at": now,
                    "finished_at": finished_at,
                })

                # If delay == 0, complete immediately within this get
                if delay == 0:
                    # Complete the load now
                    del in_flight[key]
                    cache[key] = {
                        "value": p_value if p_error is None else None,
                        "error": p_error,
                        "expires": finished_at + ttl,
                    }
                    for w in load_info["waiters"]:
                        if w["cancelled"]:
                            continue
                        w["resolved"] = True
                        w["status"] = "ok" if p_error is None else "error"
                        w["value"] = p_value if p_error is None else None
                        w["error"] = p_error
                        w["finished_at"] = finished_at

            results.append(waiter)

        elif op == "cancel":
            cancel_id = ev["id"]
            # Find the waiter with this id that hasn't been resolved or cancelled
            for w in results:
                if w["id"] == cancel_id and not w["resolved"] and not w["cancelled"]:
                    w["cancelled"] = True
                    w["status"] = "cancelled"
                    w["error"] = "cancelled"
                    w["value"] = None
                    w["finished_at"] = now
                    break

        # advance: nothing special to do beyond load completions above

    # Build final output
    results_output = []
    for w in results:
        results_output.append({
            "id": w["id"],
            "status": w["status"],
            "value": w["value"],
            "error": w["error"],
            "finished_at": w["finished_at"],
        })

    # Cache: sorted by key
    cache_output = []
    for key in sorted(cache.keys()):
        entry = cache[key]
        cache_output.append({
            "key": key,
            "value": entry["value"],
            "error": entry["error"],
            "expires": entry["expires"],
        })

    return {
        "results": results_output,
        "loads": loads_output,
        "cache": cache_output,
        "next_cleanup": next_cleanup,
    }
