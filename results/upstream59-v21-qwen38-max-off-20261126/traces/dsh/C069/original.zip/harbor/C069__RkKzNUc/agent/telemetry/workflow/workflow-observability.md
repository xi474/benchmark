# Workflow 可观测性报告

- Trial：`C069__RkKzNUc__env`
- Task：`C069`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_8cdb56f8e3a64272854789ff -> tool:dsh:lead:call_c8afc115c8df4e40830c7cac -> tool:dsh:lead:call_4dd6d10c6a5545d6b6f39d22 -> tool:dsh:lead:call_9466f380ec2d493e80bac2dc -> tool:dsh:lead:call_6c37d85a85f04892b3c2fbe3 -> tool:dsh:lead:call_5363646c71ce434a928a0e38 -> tool:dsh:lead:call_86c4ff64a9d94e37b7c28514 -> tool:dsh:lead:call_09e3c3023ce446daa0c3eea5 -> tool:dsh:lead:call_26de768e890d468eaa3f81ff -> tool:dsh:lead:call_ce412f15d9d5451e9e34f1c4 -> tool:dsh:lead:call_da5cb44e34b741c4be1f237d -> tool:dsh:lead:call_6735cfc60d2a43eebe50995f -> tool:dsh:lead:call_750531ab9856451cb962cb59 -> tool:dsh:lead:call_5cd09dc15237401783898eec -> tool:dsh:lead:call_5aa25e44a488449ab4887788 -> tool:dsh:lead:call_0a6c37c4a2bb4d8ba913b323 -> tool:dsh:lead:call_efdeab38ed6d42c493c85215 -> tool:dsh:lead:call_a9af0743d025480f97b305ef -> tool:dsh:lead:call_c1347aa515d1443d9b607740 -> tool:dsh:lead:call_4ed4154c70804283a032e2a1 -> tool:dsh:lead:call_0d6da81cfc904f7194631aa4 -> tool:dsh:lead:call_a20bcb44b51f480eaba1762f -> tool:dsh:lead:call_b5d13eb4836647b7aecdbbb0 -> tool:dsh:lead:call_b7c71e61a5bf45b8a4f1b332 -> tool:dsh:lead:call_0f81a8c3d4dc4ab2b1f54e04 -> tool:dsh:lead:call_178a25b91bae418caee33db7 -> tool:dsh:lead:call_a9962d373f9540b09f08ce0c -> tool:dsh:lead:call_8c80b271d0f74614b2befaef -> tool:dsh:lead:call_216fa29eb981433c85e3dbab -> tool:dsh:lead:call_1f545864084f4c52bcd9c023 -> tool:dsh:lead:call_6fb471ac2ffb415f8d5e1470 -> tool:dsh:lead:call_d7f92a043022423d864fd6d9 -> tool:dsh:lead:call_b5ab9e0777d240b29250e1be -> tool:dsh:lead:call_cae4bece13664c75a474cf17 -> tool:dsh:lead:call_67b5af3ce02147dcb6f19f7e -> tool:dsh:lead:call_a6d7069316244356b7d016d1 -> tool:dsh:lead:call_58f572050e3d4dd5af4ec6aa
- 关键路径耗时：0.813
- Makespan：132.326
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
