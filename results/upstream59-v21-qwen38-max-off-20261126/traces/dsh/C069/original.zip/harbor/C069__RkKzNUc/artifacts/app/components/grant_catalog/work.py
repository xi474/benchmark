def compute(payload):
    """生成授权条目的有效条件和有序角色/资源集合。以原授权 ID 为键，每项含 approved、expiry、roles、resources。"""
    access_requests = payload.get("access_requests", {})
    result = {}
    for req_id, req in access_requests.items():
        entry = {
            "approved": req.get("approved", False),
            "expiry": req.get("expiry"),
            "roles": sorted(req.get("roles", [])),
            "resources": sorted(req.get("resources", [])),
        }
        result[req_id] = entry
    return result
