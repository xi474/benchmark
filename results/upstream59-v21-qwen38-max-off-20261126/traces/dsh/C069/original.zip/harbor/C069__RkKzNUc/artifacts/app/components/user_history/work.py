import copy


def compute(payload):
    """记录各续期事件发生时的用户快照，重放 update_user 的 roles、traits；以原位置字符串为键。"""
    events = payload.get("events", [])
    user = payload.get("user", {})

    # Current user state - start with a deep copy of the initial user
    current_user = copy.deepcopy(user)

    result = {}
    for idx, event in enumerate(events):
        op = event.get("op")
        if op == "update_user":
            # Apply partial update: only replace given roles/traits
            if "roles" in event:
                current_user["roles"] = list(event["roles"])
            if "traits" in event:
                current_user["traits"] = copy.deepcopy(event["traits"])
        elif op == "renew":
            # Record snapshot at this renew event position
            result[str(idx)] = copy.deepcopy(current_user)

    return result
