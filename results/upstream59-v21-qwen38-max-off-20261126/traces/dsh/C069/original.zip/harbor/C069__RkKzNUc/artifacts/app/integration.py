import base64
import copy
import json


def _encode_cert(model_prefix, obj):
    """Encode an object as base64url JSON with the given model prefix."""
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    raw = base64.urlsafe_b64encode(text.encode("utf-8")).decode("ascii")
    # Strip trailing '=' padding
    raw = raw.rstrip("=")
    return model_prefix + raw


def combine(payload, user_history, grant_catalog):
    """Combine the two component JSON values under the business contract in TASK.md."""
    user = payload.get("user", {})
    start_time = payload.get("start_time", 0)
    session_ttl = payload.get("session_ttl", 0)
    events = payload.get("events", [])
    initial_id = payload.get("initial_id", "s0")

    # Backend user state (mutable via update_user)
    backend_user = copy.deepcopy(user)

    # Sessions store: id -> session_info
    # session_info: {login_time, expiry, cached_user, active_requests: {req_id: req_info}}
    # active_requests tracks requests assumed by this session chain
    sessions = {}

    # Create initial session s0
    init_expiry = start_time + session_ttl
    sessions[initial_id] = {
        "login_time": start_time,
        "expiry": init_expiry,
        "cached_user": copy.deepcopy(backend_user),
        "active_requests": {},  # req_id -> {roles, resources, expiry}
    }

    replies = []
    session_ids = [initial_id]

    # Process events in order (already sorted by time, same time by array order)
    for event in events:
        op = event.get("op")

        if op == "update_user":
            # Update backend user: only replace given roles/traits
            if "roles" in event:
                backend_user["roles"] = list(event["roles"])
            if "traits" in event:
                backend_user["traits"] = copy.deepcopy(event["traits"])

        elif op == "renew":
            new_id = event["id"]
            prev_id = event["prev"]
            now = event["time"]
            reload_user = event.get("reload_user", False)
            switchback = event.get("switchback", False)
            access_request = event.get("access_request", None)

            # prev must be a successfully created session
            if prev_id not in sessions:
                replies.append({"id": new_id, "status": "expired"})
                continue

            prev_session = sessions[prev_id]

            # Check if prev session is expired
            if prev_session["expiry"] <= now:
                replies.append({"id": new_id, "status": "expired"})
                continue

            # Determine cached user for new session
            if reload_user:
                cached_user = copy.deepcopy(backend_user)
            else:
                cached_user = copy.deepcopy(prev_session["cached_user"])

            # Determine active requests for new session
            if switchback:
                # Clear all temporary requests and resources
                active_requests = {}
            else:
                # Inherit active requests from prev, but check expiry
                active_requests = {}
                fail_reason = None
                for req_id, req_info in prev_session["active_requests"].items():
                    if req_info["expiry"] <= now:
                        # Active request expired without explicit switchback → failure
                        fail_reason = "request_unavailable"
                        break
                    active_requests[req_id] = copy.deepcopy(req_info)

                if fail_reason:
                    replies.append({"id": new_id, "status": fail_reason})
                    continue

            # Handle assume (access_request)
            if access_request is not None:
                req_id = access_request
                # Look up in grant_catalog
                if req_id not in grant_catalog:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue

                req_data = grant_catalog[req_id]

                # Must be approved
                if not req_data["approved"]:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue

                # Must not be expired
                if req_data["expiry"] <= now:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue

                # Check resource_already_active: if this is a resource request
                req_roles = req_data.get("roles", [])
                req_resources = req_data.get("resources", [])
                is_resource_request = len(req_resources) > 0

                if is_resource_request:
                    # Check if any active request already has resources
                    for existing_req_id, existing_req in active_requests.items():
                        if len(existing_req.get("resources", [])) > 0:
                            replies.append({"id": new_id, "status": "resource_already_active"})
                            break
                    else:
                        # No existing resource request, add this one
                        active_requests[req_id] = {
                            "roles": list(req_roles),
                            "resources": list(req_resources),
                            "expiry": req_data["expiry"],
                        }
                else:
                    # Role request: accumulate and deduplicate
                    if req_id in active_requests:
                        # Already active, merge roles
                        existing = active_requests[req_id]
                        merged_roles = sorted(set(existing["roles"]) | set(req_roles))
                        existing["roles"] = merged_roles
                    else:
                        active_requests[req_id] = {
                            "roles": list(req_roles),
                            "resources": list(req_resources),
                            "expiry": req_data["expiry"],
                        }

            # Compute session properties
            # Roles = union of cached_user.roles and all active request roles, sorted
            all_roles = set(cached_user.get("roles", []))
            all_resources = set()
            for req_info in active_requests.values():
                all_roles.update(req_info.get("roles", []))
                all_resources.update(req_info.get("resources", []))

            sorted_roles = sorted(all_roles)
            sorted_resources = sorted(all_resources)

            # Expiry = min(now + ttl, all active request expiries); no requests → now + ttl
            new_expiry = now + session_ttl
            for req_info in active_requests.values():
                new_expiry = min(new_expiry, req_info["expiry"])

            # login_time inherited from prev
            login_time = prev_session["login_time"]

            # Create the new session
            new_session = {
                "login_time": login_time,
                "expiry": new_expiry,
                "cached_user": cached_user,
                "active_requests": active_requests,
            }
            sessions[new_id] = new_session
            session_ids.append(new_id)

            # Build certificates
            traits = cached_user.get("traits", {})
            ssh_obj = {
                "roles": sorted_roles,
                "allowed_resources": sorted_resources,
                "extensions": {
                    "logins": traits.get("logins", []),
                    "db_users": traits.get("db_users", []),
                },
                "login_time": login_time,
                "expires": new_expiry,
            }
            ssh_cert = _encode_cert("SSH-MODEL1.", ssh_obj)

            # TLS: active_requests sorted by request id
            tls_active = sorted(active_requests.keys())
            tls_obj = {
                "user": cached_user.get("name", ""),
                "active_requests": tls_active,
                "login_time": login_time,
                "expires": new_expiry,
            }
            tls_cert = _encode_cert("TLS-MODEL1.", tls_obj)

            replies.append({
                "id": new_id,
                "status": "ok",
                "ssh_certificate": ssh_cert,
                "tls_certificate": tls_cert,
            })

    return {
        "replies": replies,
        "session_ids": session_ids,
    }
