# Workflow 可观测性报告

- Trial：`C074__RriiFuJ__env`
- Task：`C074`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_d6bc822e2c01433aad538913 -> tool:dsh:lead:call_10567a0cee8c400597f774a2 -> tool:dsh:lead:call_09f2924196364cd1ad4d973e -> tool:dsh:lead:call_c273cc8e11344ca6a8ef36a8 -> tool:dsh:lead:call_c939cef247544219b33965a9 -> tool:dsh:lead:call_b6b36f3a932e4fa2a466b431 -> tool:dsh:lead:call_553b28c8e4794d688b5bfe9e -> tool:dsh:lead:call_bdaaabaad5c64df7903813e9 -> tool:dsh:lead:call_53be09d2b58c40e0be99caec -> tool:dsh:lead:call_1be8d0123a3547cfb6a46ef8 -> tool:dsh:lead:call_c8723d67334e43e1b13258f4 -> tool:dsh:lead:call_75c836f3611d4a20aea3600f -> tool:dsh:lead:call_4ea9bc529ebc48f383cbc98e -> tool:dsh:lead:call_395897fad08e45b6a8236d04 -> tool:dsh:lead:call_41ba10bdc9a144c490fd0d82 -> tool:dsh:lead:call_bd4184b53be24a18b4e9e861 -> tool:dsh:lead:call_6d164b35bf234e5e9bebe58d -> tool:dsh:lead:call_4d57b52d8dce471180bfa2ca -> tool:dsh:lead:call_90486d88ffb7474fbabffecb -> tool:dsh:lead:call_fdc613edef8e4ce3907f93d5 -> tool:dsh:lead:call_e38fc833790847e1aab5a87b -> tool:dsh:lead:call_8a2e07f3d8214bc0b28d5da2 -> tool:dsh:lead:call_ac2bec2af2c84a27ada235fb -> tool:dsh:lead:call_de0cf0e7b176458fb7a64bfb -> tool:dsh:lead:call_6860487cd6f04d869960219d -> tool:dsh:lead:call_895f5f3813bc4ba7b12d6607 -> tool:dsh:lead:call_721ba6e3a9864c0b82a5b4b7 -> tool:dsh:lead:call_baf2e5b57e9a46e9b407e60a -> tool:dsh:lead:call_0c1f0ca5a3b04d548dcdc2e8 -> tool:dsh:lead:call_4bf322f48c0c47ccb581645e -> tool:dsh:lead:call_88e915ec4e674f07a5040873 -> tool:dsh:lead:call_c6d1caa418794ca58a5ae1df
- 关键路径耗时：0.701
- Makespan：152.624
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
