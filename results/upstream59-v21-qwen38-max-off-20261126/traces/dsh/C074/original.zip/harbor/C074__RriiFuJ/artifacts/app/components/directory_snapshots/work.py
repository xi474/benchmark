import copy


def compute(payload):
    """按扫描轮次生成映射，从每个完成目录的逻辑路径映射至 [保留文件映射,可见子目录名升序数组]。按轮累计替换节点。"""
    nodes = copy.deepcopy(payload.get("nodes", {}))
    mounts = payload.get("mounts", {})
    scans = payload.get("scans", [])

    results = []
    for scan in scans:
        # Apply replacements cumulatively
        replace = scan.get("replace", {})
        for node_id, node_def in replace.items():
            nodes[node_id] = copy.deepcopy(node_def)

        finish = scan.get("finish", [])
        round_result = {}
        for path in finish:
            parts = path.split("/")
            mount_name = parts[0]
            node_id = mounts[mount_name]
            # Walk remaining path segments through dirs
            for seg in parts[1:]:
                node = nodes[node_id]
                node_id = node["dirs"][seg]
            # Now node_id is the target node
            node = nodes[node_id]
            ignored = set(node.get("ignore", []))
            # Visible files: those not in ignore
            visible_files = {k: v for k, v in node.get("files", {}).items() if k not in ignored}
            # Visible subdirs: those not in ignore, sorted
            visible_dirs = sorted([k for k in node.get("dirs", {}).keys() if k not in ignored])
            round_result[path] = [visible_files, visible_dirs]
        results.append(round_result)
    return results
