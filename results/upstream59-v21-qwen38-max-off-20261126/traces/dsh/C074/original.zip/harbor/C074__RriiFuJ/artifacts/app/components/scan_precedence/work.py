def compute(payload):
    """每轮返回完成的逻辑路径，按深度先父后子，同深度维持输入顺序。"""
    scans = payload.get("scans", [])
    results = []
    for scan in scans:
        finish = scan.get("finish", [])
        # Sort by depth (number of '/' separators = depth), stable sort preserves input order at same depth
        ordered = sorted(finish, key=lambda p: p.count("/"))
        results.append(ordered)
    return results
