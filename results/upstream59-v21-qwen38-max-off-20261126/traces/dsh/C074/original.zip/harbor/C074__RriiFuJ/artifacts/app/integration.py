def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = directory_snapshots result: list of {path: [files_map, sorted_dirs]} per scan
    right = scan_precedence result: list of ordered path lists per scan
    
    Returns list of {index, changed} per scan.
    """
    initial = dict(payload.get("initial", {}))
    index = dict(initial)
    
    results = []
    for scan_idx in range(len(left)):
        snapshots = left[scan_idx]       # {path: [files_map, visible_dirs]}
        ordered_paths = right[scan_idx]  # finished paths in precedence order
        
        old_index = dict(index)
        
        for path in ordered_paths:
            files_map, visible_dirs = snapshots[path]
            visible_dir_set = set(visible_dirs)
            visible_file_set = set(files_map.keys())
            known_children = visible_file_set | visible_dir_set
            
            prefix = path + "/"
            
            # Collect all current index entries under this path
            sub_entries = {k: v for k, v in index.items() if k.startswith(prefix)}
            
            # Group sub-entries by their immediate child segment
            # For entry "P/a/b/c", the immediate child segment is "a"
            segments_seen = set()
            for key in sub_entries:
                remainder = key[len(prefix):]
                seg = remainder.split("/", 1)[0]
                segments_seen.add(seg)
            
            # Process each segment
            for seg in segments_seen:
                if seg in visible_file_set:
                    # seg is now a file: remove any old entries under P/seg/...
                    # (handles dir->file swap and stale children)
                    seg_prefix = prefix + seg + "/"
                    keys_to_remove = [k for k in index if k.startswith(seg_prefix)]
                    for k in keys_to_remove:
                        del index[k]
                    # Also remove old entry at P/seg if it existed with different value
                    # (will be overwritten below anyway)
                    exact_key = prefix + seg
                    if exact_key in index:
                        del index[exact_key]
                elif seg in visible_dir_set:
                    # seg is still a visible dir: preserve old entries inside
                    pass
                else:
                    # seg disappeared or was ignored: remove all under P/seg/...
                    seg_prefix = prefix + seg + "/"
                    keys_to_remove = [k for k in index if k.startswith(seg_prefix)]
                    for k in keys_to_remove:
                        del index[k]
                    # Also remove exact P/seg if it was a file entry
                    exact_key = prefix + seg
                    if exact_key in index:
                        del index[exact_key]
            
            # Now set/update direct file entries from snapshot
            for fname, track_id in files_map.items():
                index[prefix + fname] = track_id
        
        # Compute changed
        changed = {}
        all_keys = set(old_index.keys()) | set(index.keys())
        # Group by track_id
        old_by_track = {}
        for p, tid in old_index.items():
            old_by_track.setdefault(tid, []).append(p)
        new_by_track = {}
        for p, tid in index.items():
            new_by_track.setdefault(tid, []).append(p)
        
        all_tracks = set(old_by_track.keys()) | set(new_by_track.keys())
        for tid in all_tracks:
            old_paths = sorted(old_by_track.get(tid, []))
            new_paths = sorted(new_by_track.get(tid, []))
            if old_paths != new_paths:
                changed[tid] = [old_paths, new_paths]
        
        results.append({"index": dict(index), "changed": changed})
    
    return results
