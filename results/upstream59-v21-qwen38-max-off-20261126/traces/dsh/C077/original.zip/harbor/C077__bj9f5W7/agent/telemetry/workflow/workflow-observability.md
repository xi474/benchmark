# Workflow 可观测性报告

- Trial：`C077__bj9f5W7__env`
- Task：`C077`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_43854830be2b41428e708094 -> tool:dsh:lead:call_2011f97d9c504187a1669ee9 -> tool:dsh:lead:call_2a8a242b99f841efaca27241 -> tool:dsh:lead:call_4118f1995af44e56b16d8dbf -> tool:dsh:lead:call_dac8b5ddc5ba436181042da3 -> tool:dsh:lead:call_83514126412f4237817f143a -> tool:dsh:lead:call_308c2cd04e174e6cac59aabb -> tool:dsh:lead:call_10b3437e9acb4d37b16f59d1 -> tool:dsh:lead:call_d50ceaf19061425dab1c55d3 -> tool:dsh:lead:call_88564bda6b294eb5831619f8 -> tool:dsh:lead:call_07a0a14293264c6e9dc8a485 -> tool:dsh:lead:call_606d336947564442b6c4b81d -> tool:dsh:lead:call_5adfaea231db4675854aed59 -> tool:dsh:lead:call_2d4c100ebcc74b7b81f46bcc -> tool:dsh:lead:call_95416629eb8c4c689ec97eba -> tool:dsh:lead:call_a724de5d0cfd4bad8ccf964d -> tool:dsh:lead:call_0eb3398129a84c4cb9168842 -> tool:dsh:lead:call_a0381a4d08d547b3a78e5035 -> tool:dsh:lead:call_43a9878ed99a48a4865d9a26 -> tool:dsh:lead:call_03c327c9781e48f685d509d9 -> tool:dsh:lead:call_b9bc2219fff34185a71ec4f5 -> tool:dsh:lead:call_198592d8602a4d6aa6f36849 -> tool:dsh:lead:call_93028942fa8043e4a183c0b3 -> tool:dsh:lead:call_4ca8fe81224248e78ad809d9 -> tool:dsh:lead:call_274ba233023c4228b0b13ff3 -> tool:dsh:lead:call_78dc51057cea4c50853129ef -> tool:dsh:lead:call_7d89380ec0e74752a2c94e1a -> tool:dsh:lead:call_2456d2f622e24421b5bae4df -> tool:dsh:lead:call_68f0feb140a7434088698831 -> tool:dsh:lead:call_5860e21559cf445aa61edf66 -> tool:dsh:lead:call_35b1c8f3a4344a168b675c86 -> tool:dsh:lead:call_5b9b3dcb7a464cd79a08bf60 -> tool:dsh:lead:call_20beac6744e042b19b410815 -> tool:dsh:lead:call_48dbb71ed760414e99e511ca -> tool:dsh:lead:call_0945a9b1bb9d439a93525216 -> tool:dsh:lead:call_d324a8c3c93c4a9988c4672b -> tool:dsh:lead:call_fb034b37e2b3459da37f346b
- 关键路径耗时：0.761
- Makespan：142.791
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
