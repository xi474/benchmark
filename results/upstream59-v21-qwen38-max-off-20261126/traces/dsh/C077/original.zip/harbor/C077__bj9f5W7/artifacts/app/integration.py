def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    events = payload.get("events", [])

    # State
    active = []          # ordered list of active modification IDs
    owed = False         # pending refresh obligation
    in_flight = None     # current fetch id in flight (or None)
    retry_at = None      # scheduled retry time (or None)
    items = []           # committed items
    fetch_counter = 0    # next fetch number

    # Outputs
    fetches = []
    commits = []
    audit = []

    def is_loading():
        """loading is true when there's a pending request, retry, or owed refresh."""
        return in_flight is not None or retry_at is not None or owed

    def do_fetch(time):
        """Issue a new fetch at the given time. Consumes owed obligation."""
        nonlocal fetch_counter, in_flight, owed
        fetch_counter += 1
        fid = f"fetch-{fetch_counter}"
        in_flight = fid
        owed = False
        fetches.append({"id": fid, "time": time})
        audit.append({"time": time, "event": "fetch", "id": fid})

    # Build a timeline: collect all event times plus any retry timers.
    # We process events in time order; at each time, timers fire before external events.
    # We'll use an event-driven simulation.

    # Group events by time, preserving order within same time
    # Also track retry timers as synthetic events
    import heapq

    # We'll process step by step through the events, but also handle timer firings.
    # Timers can fire between events or at the same time as events.
    # "计时器在同刻外部事件之前触发" — timers fire before external events at the same time.

    # Approach: iterate through events, but before processing events at each time,
    # check if any timer fires at or before that time.

    # Collect unique times from events
    # We need to interleave timer firings with events.

    # Let's build a combined timeline
    # External events grouped by time
    time_groups = []
    i = 0
    while i < len(events):
        t = events[i]["time"]
        group = []
        while i < len(events) and events[i]["time"] == t:
            group.append((i, events[i]))
            i += 1
        time_groups.append((t, group))

    # Simulation
    retry_timer_id = None  # track if we have a retry timer set

    for gi, (t, group) in enumerate(time_groups):
        # Before processing events at time t, fire any retry timer at or before t
        while retry_at is not None and retry_at <= t:
            rt = retry_at
            retry_at = None
            retry_timer_id = None
            # Clear old request mark
            in_flight = None
            # Retry: if modification still in-flight, keep obligation, will retry at last finish
            if len(active) > 0:
                owed = True
                # Don't fetch now; will fetch when last modification finishes
            else:
                # Fetch immediately
                do_fetch(rt)

        # Process events at this time in order
        for idx, ev in group:
            op = ev.get("op")

            if op == "start":
                mid = ev["id"]
                if mid not in active:
                    active.append(mid)
                audit.append({"time": t, "event": "modification_started", "id": mid})

            elif op == "finish":
                mid = ev["id"]
                if mid in active:
                    active.remove(mid)
                audit.append({"time": t, "event": "modification_finished", "id": mid})
                # finish produces owed refresh
                owed = True
                # If this is the last active modification finishing (active now empty),
                # and no in_flight or retry, fetch now
                if len(active) == 0 and in_flight is None and retry_at is None:
                    do_fetch(t)

            elif op == "refresh":
                owed = True
                # If no in_flight and no retry and no active modifications, fetch now
                if in_flight is None and retry_at is None and len(active) == 0:
                    do_fetch(t)

            elif op == "response":
                fid = ev["id"]
                failed = ev.get("failed", False)
                stale_val = ev.get("stale", 0)
                resp_items = ev.get("items", None)

                if failed:
                    # Don't commit
                    audit.append({"time": t, "event": "retry_scheduled", "due": t + 2000, "reason": "failure"})
                    # Set unique retry timer (only if not already set)
                    if retry_at is None:
                        retry_at = t + 2000
                    # in_flight stays until timer fires? No — for failed, the spec says
                    # "设置唯一now+2000计时器" — just set timer. The in_flight is cleared
                    # when timer fires. But wait, let me re-read...
                    # Actually for failed: "failed不提交，设置唯一now+2000计时器"
                    # For stale: "stale=1不提交，设置唯一now+1000计时器，并保持原request标记为in_flight直至到点"
                    # So for failed, in_flight is NOT kept? Let me think...
                    # The spec says for stale specifically "保持原request标记为in_flight直至到点"
                    # implying for failed it's different. But then what happens to in_flight for failed?
                    # I think for failed, in_flight is also kept until timer fires because
                    # "计时器到点清除旧请求标记并立即重试" — timer clears old request mark.
                    # So both failed and stale keep in_flight until timer fires.
                    # The difference is stale explicitly mentions it; failed implicitly does too
                    # since the timer clears it.
                    pass  # in_flight remains

                elif stale_val == 1:
                    # Don't commit, keep in_flight
                    audit.append({"time": t, "event": "retry_scheduled", "due": t + 1000, "reason": "stale"})
                    if retry_at is None:
                        retry_at = t + 1000
                    # in_flight remains

                else:
                    # Success: commit items
                    if resp_items is not None:
                        items = list(resp_items)
                        commits.append({"time": t, "items": list(resp_items)})
                    audit.append({"time": t, "event": "committed", "id": fid})
                    # Clear in_flight
                    in_flight = None
                    # If still owed and no modification blocking, fetch again
                    if owed and len(active) == 0:
                        owed = False
                        do_fetch(t)

            elif op == "advance":
                pass  # no special handling mentioned

    # After all events, check for remaining retry timer
    # (No more events to process, but if retry_at is set, it would fire eventually.
    #  However, since there are no more events, we just report final state.)

    state = {
        "active": sorted(active),
        "owed": owed,
        "loading": is_loading(),
        "placeholders": is_loading(),
        "in_flight": in_flight,
        "retry_at": retry_at,
        "items": items,
    }

    return {
        "fetches": fetches,
        "commits": commits,
        "events": audit,
        "state": state,
    }
