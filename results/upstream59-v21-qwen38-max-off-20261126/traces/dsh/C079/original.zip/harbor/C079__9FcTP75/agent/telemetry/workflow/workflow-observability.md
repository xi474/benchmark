# Workflow 可观测性报告

- Trial：`C079__9FcTP75__env`
- Task：`C079`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5cee1be4d87c4bcebee77b98 -> tool:dsh:lead:call_ba47227842254ab1a9d91960 -> tool:dsh:lead:call_f3342cdbae864516935dcc87 -> tool:dsh:lead:call_46459c2101fb4f5e821f783b -> tool:dsh:lead:call_3c9b87ac154d4c9793ba2b2e -> tool:dsh:lead:call_367a338b7b4b47299f0b9649 -> tool:dsh:lead:call_4c04454130d841b9b91f893c -> tool:dsh:lead:call_af4799e106e444a5afdeec6b -> tool:dsh:lead:call_3d07d3c0e05346a5ac1f714d -> tool:dsh:lead:call_74206678f5ed41938e3402a9 -> tool:dsh:lead:call_2f6eebcc0f0645cf96294e29 -> tool:dsh:lead:call_52b1998a561c4b4e832ed043 -> tool:dsh:lead:call_a0bd77a63b7d42f4af2a5b58 -> tool:dsh:lead:call_88a6cc1133ba48a09a39b0e3 -> tool:dsh:lead:call_a76ddfc30d8a447f91777e5a -> tool:dsh:lead:call_93e00ff84e034168a2699d7b -> tool:dsh:lead:call_73ac2e760eac460ba2561a48 -> tool:dsh:lead:call_ec542f059f7a4dcc90ece022 -> tool:dsh:lead:call_fdff84e6ff6b4a32945a43e5 -> tool:dsh:lead:call_66d378befb664dfd901b0bed -> tool:dsh:lead:call_2d2c0892768f4c36904a6c6c -> tool:dsh:lead:call_9ae5b8c5d9434b3f9367b3fb -> tool:dsh:lead:call_b10d8d1229b34b40b954febd -> tool:dsh:lead:call_c248f72b55d942649c703e8e -> tool:dsh:lead:call_fdbf1bf977754eabb579b61d -> tool:dsh:lead:call_51a77a73316b4637aa949496 -> tool:dsh:lead:call_dcac71afe3d24c158afac079 -> tool:dsh:lead:call_08cf6d7f951f4f938526f580 -> tool:dsh:lead:call_1734a68672ee4af7991596e0 -> tool:dsh:lead:call_747c85a6da38490e9bc6bf16 -> tool:dsh:lead:call_70cd862ad3384d7f9da7dfd5 -> tool:dsh:lead:call_5cf5503fcb1747b4bdccc858 -> tool:dsh:lead:call_d854f7776e804793903ba8c8 -> tool:dsh:lead:call_c509a6c2bab14d528e5dcd3d -> tool:dsh:lead:call_ec046237c5984ec1898d3856 -> tool:dsh:lead:call_56208cf15b8b41918fd2f52b -> tool:dsh:lead:call_f9aa8b0930da407fb1c6f819
- 关键路径耗时：0.914
- Makespan：95.18
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
