def compute(payload):
    """返回 [kind,index,hex] 列表；若有缩略图则排首，再按块大小顺序切出文件块。"""
    result = []
    file_hex = payload.get("file_hex", "")
    chunk_size = payload.get("chunk_size", 1)
    thumbnail_hex = payload.get("thumbnail_hex")

    # Thumbnail block first if present (even if empty)
    if thumbnail_hex is not None:
        result.append(["thumbnail", 0, thumbnail_hex])

    # File blocks in byte order
    file_bytes_len = len(file_hex) // 2  # number of bytes
    if file_bytes_len > 0:
        idx = 0
        pos = 0
        while pos < len(file_hex):
            end = min(pos + chunk_size * 2, len(file_hex))
            chunk_hex = file_hex[pos:end]
            result.append(["file", idx, chunk_hex])
            idx += 1
            pos = end

    return result
