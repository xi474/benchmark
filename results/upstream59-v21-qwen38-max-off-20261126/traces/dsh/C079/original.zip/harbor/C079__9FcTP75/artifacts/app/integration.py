import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = block_manifest result: list of [kind, index, hex]
    right = retry_faults result: dict mapping block label -> sorted list of corrupt attempt indices
    """
    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce_int = int(payload["base_nonce_hex"], 16)
    max_retries = payload.get("max_retries", 0)

    aesgcm = AESGCM(session_key)

    blocks_out = []
    attempts_out = []
    notifications = []
    failed_block = None
    file_sha = hashlib.sha256()

    global_seq = 0  # global attempt sequence counter for nonce derivation

    for kind, index, chunk_hex in left:
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(chunk_hex)
        aad = label.encode("utf-8")

        corrupt_set = set(right.get(label, []))

        verified = False
        local_attempt = 0
        max_attempts = 1 + max_retries

        while local_attempt < max_attempts:
            nonce_int = base_nonce_int + global_seq
            nonce = nonce_int.to_bytes(12, "big")

            ct_with_tag = aesgcm.encrypt(nonce, plaintext, aad)

            # Apply corruption if this attempt index is in the corrupt set
            if local_attempt in corrupt_set:
                # Flip the lowest bit of the last byte of the encrypted result
                ba = bytearray(ct_with_tag)
                ba[-1] ^= 0x01
                ct_with_tag = bytes(ba)

            # Verify by decrypting
            try:
                decrypted = aesgcm.decrypt(nonce, ct_with_tag, aad)
                if decrypted == plaintext:
                    verified = True
                else:
                    verified = False
            except Exception:
                verified = False

            attempts_out.append({
                "block": label,
                "attempt": local_attempt,
                "verified": verified
            })

            global_seq += 1

            if verified:
                break

            # On first failure for this block, emit notification
            if local_attempt == 0:
                notifications.append({
                    "block": label,
                    "error": "verification_failed"
                })

            local_attempt += 1

        if not verified:
            # Exhausted retries for this block
            failed_block = label
            break

        # Publish block
        blocks_out.append({
            "kind": kind,
            "index": index,
            "nonce_hex": nonce.hex(),
            "ciphertext_hex": ct_with_tag.hex(),
            "plaintext_sha256": hashlib.sha256(plaintext).hexdigest()
        })

        # Update file SHA256 only for file blocks (not thumbnail)
        if kind == "file":
            file_sha.update(plaintext)

    status = "ok" if failed_block is None else "verification_failed"

    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks_out,
        "attempts": attempts_out,
        "notifications": notifications,
        "file_sha256": file_sha.hexdigest()
    }
