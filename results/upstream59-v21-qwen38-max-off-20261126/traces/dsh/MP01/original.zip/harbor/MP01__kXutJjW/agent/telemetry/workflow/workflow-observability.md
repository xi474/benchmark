# Workflow 可观测性报告

- Trial：`MP01__kXutJjW__env`
- Task：`MP01`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（59 节点 / 58 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：59；执行边：58（observed=0，inferred=58）
- Execution Trace Graph：`observed`；temporal_next 边 58，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_02516475efaa4196bfadaee2 -> tool:dsh:lead:call_1210bad835e9497b94b7e5c7 -> tool:dsh:lead:call_a0f31eacbfc247ebadc55d23 -> tool:dsh:lead:call_dac077e732d24e82aa904fd8 -> tool:dsh:lead:call_e7fbd3beade447ecaf06e3d8 -> tool:dsh:lead:call_7a1aedc0984347419f16b07a -> tool:dsh:lead:call_5f147dd546294dc89bb6b77f -> tool:dsh:lead:call_a5a445b1f03a475992cef51f -> tool:dsh:lead:call_22daeee6868e4581acb5b842 -> tool:dsh:lead:call_6cb31d72463643fda4124a8a -> tool:dsh:lead:call_c8cab33e1fbb498e8ff2cf79 -> tool:dsh:lead:call_00f3dd2db7ea4e428e699c9d -> tool:dsh:lead:call_87c462498da24abf9d476252 -> tool:dsh:lead:call_e938797172694ef1a1a96baa -> tool:dsh:lead:call_b78305a37ada49d0a6976a9b -> tool:dsh:lead:call_c8c9d5bf84e54430b1c65a14 -> tool:dsh:lead:call_17704c8c8c5c4ab79397da3d -> tool:dsh:lead:call_326afd8cfb294fca998ccf22 -> tool:dsh:lead:call_e0530289f76643fba87daaf4 -> tool:dsh:lead:call_2d063a9850a5489cbe5005eb -> tool:dsh:lead:call_8d45ea2bfa804c5cb850f1e3 -> tool:dsh:lead:call_e36d851f33ef40f19280641d -> tool:dsh:lead:call_3a20d4a423414f2c810d7157 -> tool:dsh:lead:call_44b2769cf5a749f89acff4ad -> tool:dsh:lead:call_d4d8c455d23346c98d37d1ac -> tool:dsh:lead:call_a73274faac604dbe8c5e2607 -> tool:dsh:lead:call_afa20ab78c6849b2a5ceb609 -> tool:dsh:lead:call_b22022c84f83441f90904dda -> tool:dsh:lead:call_5a2c896a7f4947e69804853b -> tool:dsh:lead:call_fade0d6909d94991a4ead96d -> tool:dsh:lead:call_1435bb3f1fd345ee9b807c1b -> tool:dsh:lead:call_24f5a8bd224846cfa7a479ea -> tool:dsh:lead:call_92d50037ee914ee2bb65fc91 -> tool:dsh:lead:call_0909157dbb5b40e3ba0be79a -> tool:dsh:lead:call_67fe15a0e8e24fbb8fdddbcc -> tool:dsh:lead:call_dd26846a6c9040f5adcfc63c -> tool:dsh:lead:call_06f96b66237845a9a1b81f42 -> tool:dsh:lead:call_bc77e3ea701947f3b11408d3 -> tool:dsh:lead:call_6bbe720529304409aa7a262a -> tool:dsh:lead:call_3e4db1116c194f02b5c32942 -> tool:dsh:lead:call_8e80ea05fe994c8dbe471b7c -> tool:dsh:lead:call_e32cbc82cf3b4ef3a4a92d8f -> tool:dsh:lead:call_2f3d43b05e6e4ea1bdb7efc7 -> tool:dsh:lead:call_dbf0e2cea9d04e2daf309c1a -> tool:dsh:lead:call_fe1664986edd4e6bb8cf75d8 -> tool:dsh:lead:call_f5ddcb94890e4657843dfe32 -> tool:dsh:lead:call_2b7f62490b16487ca723d246 -> tool:dsh:lead:call_87e91e5963204b88b2248dc6 -> tool:dsh:lead:call_b81035ff730843b1a622ffee -> tool:dsh:lead:call_989f045558da49a6aa41596b -> tool:dsh:lead:call_18a67776ec8a4d91a204c2f1 -> tool:dsh:lead:call_afe2bd1b5de74494ac15f069 -> tool:dsh:lead:call_4805d451d8ac4660943d6c1f -> tool:dsh:lead:call_c9ebee4d52764cee9fa40232 -> tool:dsh:lead:call_465f6ad55bd74fe985c76be9 -> tool:dsh:lead:call_2f043494791145fc902288a4 -> tool:dsh:lead:call_13eae112e0ac4382b41ab314 -> tool:dsh:lead:call_6800e326107444d8925d21bc
- 关键路径耗时：0.988
- Makespan：166.489
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
