import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON from path. Only object/array top-level allowed.
    Raises ValueError on invalid JSON, non-object/array top-level, or nested NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data)
    return data


def _check_finite(obj):
    """Recursively check for NaN/Infinity in floats."""
    if isinstance(obj, float):
        import math
        if not math.isfinite(obj):
            raise ValueError("non-finite number found")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
