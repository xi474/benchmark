import copy
import math


def transform(payloads, contract):
    """fit_members operation.
    
    Input: {classes, sample_weight, members:[{id, active, weight, predictions, classes, probabilities}]}
    Returns: {name, result: {classes, sample_count, members:[active members with fit_weight]}}
    """
    if len(payloads) != 1:
        raise ValueError("fit_members expects exactly 1 input")
    
    data = payloads[0]
    
    # Validate required fields
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    
    for field in ('classes', 'sample_weight', 'members'):
        if field not in data:
            raise ValueError(f"missing required field: {field}")
    
    global_classes = data['classes']
    sample_weight = data['sample_weight']
    members = data['members']
    
    # Validate classes: unique non-empty strings
    if not isinstance(global_classes, list) or len(global_classes) == 0:
        raise ValueError("classes must be a non-empty list")
    seen_classes = set()
    for c in global_classes:
        if not isinstance(c, str) or not c.strip():
            raise ValueError("class must be a non-empty string after strip")
        if c in seen_classes:
            raise ValueError(f"duplicate class: {c}")
        seen_classes.add(c)
    
    # Validate sample_weight: list of non-negative numbers
    if not isinstance(sample_weight, list):
        raise ValueError("sample_weight must be a list")
    sample_count = len(sample_weight)
    for sw in sample_weight:
        if isinstance(sw, bool):
            raise ValueError("sample_weight entries must not be bool")
        if not isinstance(sw, (int, float)):
            raise ValueError("sample_weight entries must be numbers")
        if not math.isfinite(sw) or sw < 0:
            raise ValueError("sample_weight entries must be non-negative finite numbers")
    
    # Validate members
    if not isinstance(members, list):
        raise ValueError("members must be a list")
    
    seen_ids = set()
    active_members = []
    
    for m in members:
        if not isinstance(m, dict):
            raise ValueError("member must be an object")
        
        # id and active are always required
        if 'id' not in m:
            raise ValueError("member missing id")
        if 'active' not in m:
            raise ValueError("member missing active")
        
        mid = m['id']
        active = m['active']
        
        if not isinstance(mid, str):
            raise ValueError("member id must be string")
        if not isinstance(active, bool):
            raise ValueError("member active must be bool")
        if mid in seen_ids:
            raise ValueError(f"duplicate member id: {mid}")
        seen_ids.add(mid)
        
        if not active:
            # Closed member: only validate id/active, skip rest
            continue
        
        # Active member: validate all fields
        if 'weight' not in m:
            raise ValueError("active member missing weight")
        if 'predictions' not in m:
            raise ValueError("active member missing predictions")
        if 'classes' not in m:
            raise ValueError("active member missing classes")
        if 'probabilities' not in m:
            raise ValueError("active member missing probabilities")
        
        w = m['weight']
        if isinstance(w, bool):
            raise ValueError("member weight must not be bool")
        if not isinstance(w, (int, float)):
            raise ValueError("member weight must be a number")
        if not math.isfinite(w) or w < 0:
            raise ValueError("member weight must be non-negative finite")
        
        preds = m['predictions']
        if not isinstance(preds, list):
            raise ValueError("predictions must be a list")
        if len(preds) != sample_count:
            raise ValueError(f"predictions length {len(preds)} != sample_count {sample_count}")
        for p in preds:
            if not isinstance(p, str):
                raise ValueError("prediction must be string")
            if p not in seen_classes:
                raise ValueError(f"prediction '{p}' not in global classes")
        
        member_classes = m['classes']
        if not isinstance(member_classes, list):
            raise ValueError("member classes must be a list")
        if set(member_classes) != seen_classes:
            raise ValueError("member classes must be a permutation of global classes")
        if len(member_classes) != len(global_classes):
            raise ValueError("member classes length mismatch")
        mc_seen = set()
        for mc in member_classes:
            if not isinstance(mc, str):
                raise ValueError("member class must be string")
            if mc in mc_seen:
                raise ValueError(f"duplicate in member classes: {mc}")
            mc_seen.add(mc)
        
        probs = m['probabilities']
        if not isinstance(probs, list):
            raise ValueError("probabilities must be a list")
        if len(probs) != sample_count:
            raise ValueError(f"probabilities rows {len(probs)} != sample_count {sample_count}")
        
        num_classes = len(global_classes)
        for row in probs:
            if not isinstance(row, list):
                raise ValueError("probability row must be a list")
            if len(row) != len(member_classes):
                raise ValueError(f"probability row length {len(row)} != member classes {len(member_classes)}")
            row_sum = 0.0
            for val in row:
                if isinstance(val, bool):
                    raise ValueError("probability value must not be bool")
                if not isinstance(val, (int, float)):
                    raise ValueError("probability value must be a number")
                if not math.isfinite(val) or val < 0:
                    raise ValueError("probability value must be non-negative finite")
                row_sum += val
            if abs(row_sum - 1.0) > 1e-9:
                raise ValueError(f"probability row sum {row_sum} not close to 1")
        
        # Deep copy and add fit_weight = sample_weight
        member_copy = copy.deepcopy(m)
        member_copy['fit_weight'] = list(sample_weight)
        active_members.append(member_copy)
    
    # At least one active member with weight sum > 0
    if len(active_members) == 0:
        raise ValueError("no active members")
    
    total_weight = sum(m['weight'] for m in active_members)
    if total_weight <= 0:
        raise ValueError("active member weight sum must be > 0")
    
    result = {
        'classes': list(global_classes),
        'sample_count': sample_count,
        'members': active_members
    }
    
    return {'name': contract['name'], 'result': result}
