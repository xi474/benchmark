"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core['components']
    component_count = len(components)

    # SHA256 of the complete core object serialized compactly
    core_bytes = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(core_bytes).hexdigest()

    # Attention: components with any of these conditions
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False

        # result.blocked explicitly true
        if result.get('blocked') is True:
            triggered = True

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                triggered = True

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # "non-empty" - check if it's a container with length > 0 or a truthy value
                if isinstance(val, (list, dict, str)):
                    if len(val) > 0:
                        triggered = True
                elif val is not None and val is not False and val != 0:
                    # For other types, non-empty means truthy but we need to be careful
                    # The spec says "non-empty", which for lists/dicts/strings means len > 0
                    # For other types, just being present and not null/false/0 might count
                    # But let's stick to the container interpretation
                    pass

        if triggered:
            attention.append(name)

    attention.sort()

    report = {
        'title': '可关闭成员的硬/软加权投票',
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
