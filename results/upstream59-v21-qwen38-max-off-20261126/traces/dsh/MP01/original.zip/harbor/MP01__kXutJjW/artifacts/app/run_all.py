"""Orchestrate all components based on contract.json files.

Discovers all contract.json files, resolves dependencies via input/output paths,
topologically sorts them, and runs each component's render.py in order.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph: output -> contract_path, and contract -> depends on outputs
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        output = c['output']
        inputs = c['inputs']
        output_to_contract[output] = cp
        contract_info[cp] = {'name': name, 'output': output, 'inputs': inputs}

    # Topological sort based on input/output dependencies
    # A component depends on another if any of its inputs is another component's output
    visited = set()
    order = []
    visiting = set()

    def visit(cp):
        if cp in visited:
            return
        if cp in visiting:
            raise ValueError(f"circular dependency detected involving {cp}")
        visiting.add(cp)
        info = contract_info[cp]
        for inp in info['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                visit(dep_cp)
        visiting.remove(cp)
        visited.add(cp)
        order.append(cp)

    for cp in contracts:
        visit(cp)

    # Run each component in topological order
    for cp in order:
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {cp}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {render_py}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
