def transform(payloads, contract):
    """vote_comparison operation.
    
    Inputs: [hard_vote result envelope, soft_vote result envelope]
    Returns: {name, result: {hard, soft, disagreements}}
    """
    if len(payloads) != 2:
        raise ValueError("vote_comparison expects exactly 2 inputs")
    
    hard_envelope = payloads[0]
    soft_envelope = payloads[1]
    
    # Extract result from envelopes
    if 'name' in hard_envelope and 'result' in hard_envelope:
        hard_data = hard_envelope['result']
    else:
        hard_data = hard_envelope
    
    if 'name' in soft_envelope and 'result' in soft_envelope:
        soft_data = soft_envelope['result']
    else:
        soft_data = soft_envelope
    
    hard_preds = hard_data['predictions']
    soft_preds = soft_data['predictions']
    
    if len(hard_preds) != len(soft_preds):
        raise ValueError(f"sample count mismatch: hard={len(hard_preds)}, soft={len(soft_preds)}")
    
    disagreements = []
    for i in range(len(hard_preds)):
        if hard_preds[i] != soft_preds[i]:
            disagreements.append(i)
    
    result = {
        'hard': list(hard_preds),
        'soft': list(soft_preds),
        'disagreements': disagreements
    }
    
    return {'name': contract['name'], 'result': result}
