def transform(payloads, contract):
    """hard_vote operation.
    
    Input: fit_members result envelope {name, result: {classes, sample_count, members}}
    Returns: {name, result: {predictions, scores}}
    
    Per sample, accumulate votes by member weight for each predicted class.
    Tie-break by global classes order.
    """
    if len(payloads) != 1:
        raise ValueError("hard_vote expects exactly 1 input")
    
    envelope = payloads[0]
    
    # The input is the fit result envelope with name/result
    if not isinstance(envelope, dict):
        raise ValueError("input must be an object")
    
    # When input has name/result keys, use result as business input
    if set(envelope.keys()) == {'name', 'result'} or ('name' in envelope and 'result' in envelope):
        data = envelope['result']
    else:
        data = envelope
    
    global_classes = data['classes']
    sample_count = data['sample_count']
    members = data['members']
    
    num_samples = sample_count
    num_classes = len(global_classes)
    class_index = {c: i for i, c in enumerate(global_classes)}
    
    # Initialize scores: [sample][class] = accumulated weight
    scores = [[0.0] * num_classes for _ in range(num_samples)]
    
    for m in members:
        w = m['weight']
        preds = m['predictions']
        for s in range(num_samples):
            cls = preds[s]
            idx = class_index[cls]
            scores[s][idx] += w
    
    # Predictions: argmax per sample, tie-break by global classes order (first in list wins)
    predictions = []
    for s in range(num_samples):
        max_score = -1.0
        best_idx = 0
        for ci in range(num_classes):
            if scores[s][ci] > max_score:
                max_score = scores[s][ci]
                best_idx = ci
        predictions.append(global_classes[best_idx])
    
    result = {
        'predictions': predictions,
        'scores': scores
    }
    
    return {'name': contract['name'], 'result': result}
