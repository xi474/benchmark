def transform(payloads, contract):
    """soft_vote operation.
    
    Input: fit_members result envelope {name, result: {classes, sample_count, members}}
    Returns: {name, result: {predictions, probabilities}}
    
    Map each member's probability columns to global classes, then weighted average by weight.
    Tie-break predictions by global classes order.
    """
    if len(payloads) != 1:
        raise ValueError("soft_vote expects exactly 1 input")
    
    envelope = payloads[0]
    
    if not isinstance(envelope, dict):
        raise ValueError("input must be an object")
    
    # When input has name/result keys, use result as business input
    if 'name' in envelope and 'result' in envelope:
        data = envelope['result']
    else:
        data = envelope
    
    global_classes = data['classes']
    sample_count = data['sample_count']
    members = data['members']
    
    num_samples = sample_count
    num_classes = len(global_classes)
    class_index = {c: i for i, c in enumerate(global_classes)}
    
    # Accumulate weighted probabilities
    total_weight = sum(m['weight'] for m in members)
    if total_weight <= 0:
        raise ValueError("total active weight must be > 0")
    
    # Initialize accumulated probabilities
    acc_probs = [[0.0] * num_classes for _ in range(num_samples)]
    
    for m in members:
        w = m['weight']
        member_classes = m['classes']
        probs = m['probabilities']
        
        # Build mapping from member class index to global class index
        member_to_global = []
        for mc in member_classes:
            member_to_global.append(class_index[mc])
        
        for s in range(num_samples):
            row = probs[s]
            for mi, gi in enumerate(member_to_global):
                acc_probs[s][gi] += w * row[mi]
    
    # Normalize by total weight
    probabilities = []
    for s in range(num_samples):
        row = [acc_probs[s][ci] / total_weight for ci in range(num_classes)]
        probabilities.append(row)
    
    # Predictions: argmax per sample, tie-break by global classes order
    predictions = []
    for s in range(num_samples):
        max_prob = -1.0
        best_idx = 0
        for ci in range(num_classes):
            if probabilities[s][ci] > max_prob:
                max_prob = probabilities[s][ci]
                best_idx = ci
        predictions.append(global_classes[best_idx])
    
    result = {
        'predictions': predictions,
        'probabilities': probabilities
    }
    
    return {'name': contract['name'], 'result': result}
