# Workflow 可观测性报告

- Trial：`MP02__26w2wDA__env`
- Task：`MP02`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（52 节点 / 51 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：52；执行边：51（observed=0，inferred=51）
- Execution Trace Graph：`observed`；temporal_next 边 51，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_4c73775b44d64405b51e4780 -> tool:dsh:lead:call_91e96c90b0784adc98ea8c50 -> tool:dsh:lead:call_735057697a5b417fbdcc977f -> tool:dsh:lead:call_4623cdf5d1a64c399ddda01a -> tool:dsh:lead:call_4b166d2fdd9c4024865eeddb -> tool:dsh:lead:call_25e68219a3534e9b8193e290 -> tool:dsh:lead:call_247782b6894341c98a071759 -> tool:dsh:lead:call_c1f9d6a9677c4ca4b91be066 -> tool:dsh:lead:call_ca9c4eef33064441bf245d61 -> tool:dsh:lead:call_c6c782dd970c486195ae19da -> tool:dsh:lead:call_72a2e7e649f548619ce2e4db -> tool:dsh:lead:call_3c81dcb176f345f8a1fbc136 -> tool:dsh:lead:call_af425ef4e48f49e88ce08f98 -> tool:dsh:lead:call_6664f3a54cec4ee8ba12f5f1 -> tool:dsh:lead:call_2046505e575644e6ae643b85 -> tool:dsh:lead:call_78e9ba43fd954ed688035832 -> tool:dsh:lead:call_eb539970d3654f3bb6cc523e -> tool:dsh:lead:call_070d6c310b7a45f6b879f656 -> tool:dsh:lead:call_e7ac29794a044237a60b4c74 -> tool:dsh:lead:call_d5933d9bf55d4fd581557c29 -> tool:dsh:lead:call_e90c1039fa7c44ebb9fe59b9 -> tool:dsh:lead:call_b8df3dba61134d03bac194cf -> tool:dsh:lead:call_457f571090284e55a44e1869 -> tool:dsh:lead:call_490058df23154a1098559a50 -> tool:dsh:lead:call_6e60554555434df5a3ea424e -> tool:dsh:lead:call_c84fd0f1269e4cb9bb8605a8 -> tool:dsh:lead:call_651c72a1fdb44cc0b8410546 -> tool:dsh:lead:call_29e84af09a7b4ad7b44106d7 -> tool:dsh:lead:call_6f81bf0d76cf4125a85da555 -> tool:dsh:lead:call_23d1e6ede7714f7283fe539e -> tool:dsh:lead:call_8facaf0b91064ed9848e9b92 -> tool:dsh:lead:call_ea251b38011e4d629bba02e4 -> tool:dsh:lead:call_b5a3caef03184bad8c748712 -> tool:dsh:lead:call_fed5c51f11a741cbaa0bdd07 -> tool:dsh:lead:call_7f76b1d403d8422ebd9b2b60 -> tool:dsh:lead:call_00bf6a4356664e1d89f17ef9 -> tool:dsh:lead:call_403efa6f38cb4a8f97f36194 -> tool:dsh:lead:call_7bf8c433e6324caeb9b3e23b -> tool:dsh:lead:call_1da289f14c5948dcb3aa0431 -> tool:dsh:lead:call_c5fdeca7dcc140fe9ba322b0 -> tool:dsh:lead:call_21ea1c0bb0d84a4da504c05c -> tool:dsh:lead:call_dbd01099397c4ea78b6acab6 -> tool:dsh:lead:call_59f618f7cd114bd0bb154594 -> tool:dsh:lead:call_96b2058946304692b82b1106 -> tool:dsh:lead:call_d2069902b3184c5f809c4af6 -> tool:dsh:lead:call_8e61413d14624911a69dc18d -> tool:dsh:lead:call_023a1cf73e2445f1b55162a4 -> tool:dsh:lead:call_fd60f49fc5b641299c1f233c -> tool:dsh:lead:call_37711600a00640d4a50dd149 -> tool:dsh:lead:call_a7c1949a18cb476dad5c2c29 -> tool:dsh:lead:call_864a5fce27e2400082671718
- 关键路径耗时：1.276
- Makespan：191.097
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
