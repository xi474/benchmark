import json
import math


def _is_finite_number(v):
    """Check if v is a finite number (int or float, not bool)."""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _deep_equal(a, b):
    """JSON deep equality comparison."""
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == \
           json.dumps(b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def transform(payloads, contract):
    """segment_attributes: merge piece attributes according to policy."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]

    # Validate required fields
    if 'columns' not in inp:
        raise ValueError("missing columns")
    if 'pieces' not in inp:
        raise ValueError("missing pieces")
    if 'attribute_policy' not in inp:
        raise ValueError("missing attribute_policy")

    pieces = inp['pieces']
    policy = inp['attribute_policy']

    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if policy not in ('drop_conflicts', 'first'):
        raise ValueError("invalid attribute_policy")

    if policy == 'first':
        # For each key, pick the first value seen in original pieces order
        merged = {}
        for piece in pieces:
            if not isinstance(piece, dict):
                raise ValueError("piece must be object")
            if 'attrs' not in piece:
                raise ValueError("piece missing attrs")
            attrs = piece['attrs']
            if not isinstance(attrs, dict):
                raise ValueError("attrs must be object")
            for k, v in attrs.items():
                if k not in merged:
                    merged[k] = v
        result = {
            'attrs': merged,
            'conflicts': []
        }
    elif policy == 'drop_conflicts':
        # Collect all values per key across pieces
        key_values = {}  # key -> list of values
        for piece in pieces:
            if not isinstance(piece, dict):
                raise ValueError("piece must be object")
            if 'attrs' not in piece:
                raise ValueError("piece missing attrs")
            attrs = piece['attrs']
            if not isinstance(attrs, dict):
                raise ValueError("attrs must be object")
            for k, v in attrs.items():
                if k not in key_values:
                    key_values[k] = []
                key_values[k].append(v)

        merged = {}
        conflicts = []
        for k, vals in key_values.items():
            # Check if all values are the same (deep equality)
            all_same = all(_deep_equal(vals[0], v) for v in vals[1:])
            if all_same:
                merged[k] = vals[0]
            else:
                conflicts.append(k)

        conflicts.sort()
        result = {
            'attrs': merged,
            'conflicts': conflicts
        }

    return {'name': contract['name'], 'result': result}
