import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check for non-finite floats (NaN, Infinity) in parsed JSON."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read UTF-8 JSON file; only object/array top-level allowed; reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    # Use parse_constant to catch NaN/Infinity at parse time
    def _reject_constant(s):
        raise ValueError(f"non-finite constant in JSON: {s}")
    data = json.loads(text, parse_constant=_reject_constant)
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be object or array")
    # Double-check for any float NaN/Inf that slipped through
    _check_finite(data)
    return data
