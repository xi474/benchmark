import json
import sys
from pathlib import Path

# Import from sibling modules in same directory
_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(_dir))
from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, write output, return result."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    
    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    
    return result


if __name__ == '__main__':
    # Determine root and contract path relative to this file
    here = Path(__file__).resolve()
    component_dir = here.parent
    root = component_dir.parents[1]  # /app
    contract_path = component_dir / 'contract.json'
    build_component(root, contract_path)
