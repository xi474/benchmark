import math


def _is_finite_number(v):
    """Check if v is a finite number (int or float, not bool)."""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    """segment_index: build sorted coordinate index from pieces."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]

    # Validate required fields
    if 'columns' not in inp:
        raise ValueError("missing columns")
    if 'pieces' not in inp:
        raise ValueError("missing pieces")
    if 'attribute_policy' not in inp:
        raise ValueError("missing attribute_policy")

    columns = inp['columns']
    pieces = inp['pieces']
    policy = inp['attribute_policy']

    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if policy not in ('drop_conflicts', 'first'):
        raise ValueError("invalid attribute_policy")

    # Validate column names are unique strings
    col_names = set()
    for c in columns:
        if not isinstance(c, str):
            raise ValueError("column name must be string")
        if c in col_names:
            raise ValueError("duplicate column name")
        col_names.add(c)

    # Validate pieces
    seen_ids = set()
    seen_coords = set()
    order = []

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be object")
        for field in ('id', 'coordinates', 'data', 'attrs'):
            if field not in piece:
                raise ValueError(f"piece missing {field}")

        pid = piece['id']
        if not isinstance(pid, str):
            raise ValueError("piece id must be string")
        if pid in seen_ids:
            raise ValueError(f"duplicate piece id: {pid}")
        seen_ids.add(pid)

        coords = piece['coordinates']
        data = piece['data']
        attrs = piece['attrs']

        if not isinstance(coords, list):
            raise ValueError("coordinates must be list")
        if not isinstance(data, list):
            raise ValueError("data must be list")
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be object")

        # Validate coordinates are unique finite numbers
        for coord in coords:
            if not _is_finite_number(coord):
                raise ValueError("coordinate must be finite number")
            if coord in seen_coords:
                raise ValueError(f"duplicate coordinate: {coord}")
            seen_coords.add(coord)

        # Validate data rows
        if len(data) != len(coords):
            raise ValueError("data length must match coordinates length")
        for row in data:
            if not isinstance(row, list):
                raise ValueError("data row must be list")
            if len(row) != len(columns):
                raise ValueError("data row width must match columns length")
            for val in row:
                if not _is_finite_number(val):
                    raise ValueError("data value must be finite number")

        # Build order entries
        for i, coord in enumerate(coords):
            order.append({
                'coordinate': coord,
                'piece': pid,
                'row': i
            })

    # Sort by coordinate ascending
    order.sort(key=lambda x: x['coordinate'])

    result = {
        'columns': columns,
        'order': order
    }

    return {'name': contract['name'], 'result': result}
