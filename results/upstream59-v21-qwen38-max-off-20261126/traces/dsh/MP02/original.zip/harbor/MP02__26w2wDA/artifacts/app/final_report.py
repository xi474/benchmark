"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.is_file():
        raise FileNotFoundError("core_manifest.json not found")

    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core['components']
    component_count = len(components)

    # Compute SHA256 of the canonical serialization of the full core object
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # Check blocked explicitly true
        if result.get('blocked') is True:
            attention.add(name)
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {}:
                # Non-empty check: for lists/dicts/strings, check truthiness
                # But we need "non-empty" specifically
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, (int, float, bool)):
                    # These are not "non-empty" containers; skip
                    pass

    attention_list = sorted(attention)

    report = {
        'title': '单变化轴的数据分片拼接',
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention_list
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
