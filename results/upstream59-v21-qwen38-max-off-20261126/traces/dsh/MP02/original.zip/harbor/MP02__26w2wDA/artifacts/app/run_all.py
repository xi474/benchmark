"""Orchestrate all components based on contract dependencies."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    return json.loads(path.read_text(encoding='utf-8'))


def topological_sort(contracts):
    """Sort contracts by dependency order based on input paths."""
    # Build name -> contract_path mapping
    name_to_path = {}
    name_to_contract = {}
    for cp in contracts:
        c = load_contract(cp)
        name_to_path[c['name']] = cp
        name_to_contract[c['name']] = c

    # Build dependency graph: which component outputs are needed as inputs
    output_to_name = {}
    for cp in contracts:
        c = load_contract(cp)
        output_to_name[c['output']] = c['name']

    deps = {}  # name -> set of dependency names
    for cp in contracts:
        c = load_contract(cp)
        dep_names = set()
        for inp in c['inputs']:
            if inp in output_to_name:
                dep_names.add(output_to_name[inp])
        deps[c['name']] = dep_names

    # Topological sort (Kahn's algorithm)
    in_degree = {n: len(d) for n, d in deps.items()}
    queue = [n for n in deps if in_degree[n] == 0]
    queue.sort()  # deterministic order
    result = []
    while queue:
        node = queue.pop(0)
        result.append(node)
        for other, other_deps in deps.items():
            if node in other_deps:
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)
                    queue.sort()

    if len(result) != len(deps):
        raise ValueError("dependency cycle detected")

    return [name_to_path[n] for n in result]


def main():
    contracts = discover_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    ordered = topological_sort(contracts)

    for cp in ordered:
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        proc = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if proc.returncode != 0:
            print(f"Component {cp} failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)

    # Run integrate.py to produce core_manifest.json
    integrate = ROOT / 'integrate.py'
    if integrate.is_file():
        proc = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=str(ROOT),
            timeout=60
        )
        if proc.returncode != 0:
            print(f"integrate.py failed", file=sys.stderr)
            sys.exit(proc.returncode)

    # Run final_report.py
    report = ROOT / 'final_report.py'
    if report.is_file():
        proc = subprocess.run(
            [sys.executable, str(report)],
            cwd=str(ROOT),
            timeout=60
        )
        if proc.returncode != 0:
            print(f"final_report.py failed", file=sys.stderr)
            sys.exit(proc.returncode)


if __name__ == '__main__':
    main()
