import math


def _is_finite_number(v):
    """Check if v is a finite number (int or float, not bool)."""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    """segment_assemble: combine index and attributes into final table."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    original_input = payloads[0]
    index_result = payloads[1]
    attrs_result = payloads[2]

    # Extract data from upstream results
    # index_result has {name, result} where result = {columns, order}
    # But payloads come from load_payload which reads the output file directly
    # The output file contains {name, result}, so we need to extract result
    
    # Check if payloads have name/result wrapper (from output files)
    if isinstance(index_result, dict) and 'result' in index_result and 'name' in index_result:
        idx = index_result['result']
    else:
        idx = index_result

    if isinstance(attrs_result, dict) and 'result' in attrs_result and 'name' in attrs_result:
        att = attrs_result['result']
    else:
        att = attrs_result

    # Validate original input
    if 'pieces' not in original_input:
        raise ValueError("missing pieces in original input")
    
    pieces = original_input['pieces']
    columns = idx['columns']
    order = idx['order']

    # Build piece lookup: id -> piece data
    piece_map = {}
    for piece in pieces:
        piece_map[piece['id']] = piece

    # Assemble coordinates and data using order
    coordinates = []
    data = []
    for entry in order:
        coord = entry['coordinate']
        pid = entry['piece']
        row_idx = entry['row']
        
        coordinates.append(coord)
        data.append(piece_map[pid]['data'][row_idx])

    result = {
        'coordinates': coordinates,
        'columns': columns,
        'data': data,
        'attrs': att['attrs'],
        'attribute_conflicts': att['conflicts']
    }

    return {'name': contract['name'], 'result': result}
