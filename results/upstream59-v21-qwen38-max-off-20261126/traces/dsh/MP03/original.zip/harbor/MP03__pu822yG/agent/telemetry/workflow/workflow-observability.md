# Workflow 可观测性报告

- Trial：`MP03__pu822yG__env`
- Task：`MP03`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（52 节点 / 51 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：52；执行边：51（observed=0，inferred=51）
- Execution Trace Graph：`observed`；temporal_next 边 51，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_7427aa8fdb6f48c3b2786e8d -> tool:dsh:lead:call_7deb7fc73c524774a42956df -> tool:dsh:lead:call_6057bdb89bbb418c98ee1a60 -> tool:dsh:lead:call_0aa5cbbf79ef443e83de09f0 -> tool:dsh:lead:call_be1e2e9ba2fa41be8657a196 -> tool:dsh:lead:call_4929b23bbb3340298f112c39 -> tool:dsh:lead:call_655c9195d45347dfa7629a24 -> tool:dsh:lead:call_c522e7721dbe4b14b28bffb6 -> tool:dsh:lead:call_9ebc47d460d84e8aaf7a3632 -> tool:dsh:lead:call_cb33b0b2e09f4e45be428f76 -> tool:dsh:lead:call_12928cf3255d41dc922ec467 -> tool:dsh:lead:call_447d95209e2a4d1a8c233d6e -> tool:dsh:lead:call_172f1556f22440d9a80f0769 -> tool:dsh:lead:call_eac71a1846fc41efbf07d979 -> tool:dsh:lead:call_69923c8c4a8642bc90366471 -> tool:dsh:lead:call_647c33bac4aa4a489b3b956c -> tool:dsh:lead:call_ccac84e946bb4513ab6b436c -> tool:dsh:lead:call_059e999da2c6469cbb1abbfb -> tool:dsh:lead:call_d050530db5434fb8b3c397b4 -> tool:dsh:lead:call_00989d39a3de4493aca4149f -> tool:dsh:lead:call_1d69d9f7089e4608aee8c5e3 -> tool:dsh:lead:call_49dea5e193d3465baf70d14e -> tool:dsh:lead:call_a31b9b68168e4d93bef1dd6d -> tool:dsh:lead:call_9f1bd566a8ae4aafbdfa481e -> tool:dsh:lead:call_c564534f561e42e48e457ae3 -> tool:dsh:lead:call_610664dfef4b4b6895a9c495 -> tool:dsh:lead:call_edc6c5544df140a3ac9bdc78 -> tool:dsh:lead:call_ee78a552ef2d4e80bb2b7354 -> tool:dsh:lead:call_39fbbe321b574121bb0e5d81 -> tool:dsh:lead:call_5092b060cc3644fe843314e6 -> tool:dsh:lead:call_4e7b9a5391f24930b56574d0 -> tool:dsh:lead:call_d6f3c457881741bab204e66b -> tool:dsh:lead:call_17eaa29d77bc496ea7c2bde6 -> tool:dsh:lead:call_bc7f642e4a1440aaa75eac26 -> tool:dsh:lead:call_5560336f6eb746f2860ff7e6 -> tool:dsh:lead:call_2aed7ea0bb7d49818f51f0d4 -> tool:dsh:lead:call_fcc497dc8c654d4d85adffba -> tool:dsh:lead:call_df8d25fc14e3454b84a412d0 -> tool:dsh:lead:call_dfaf61a8cf9d4b53a2fd1944 -> tool:dsh:lead:call_e4289b86040e490bbc26b1a0 -> tool:dsh:lead:call_4fe111a530564440bda9fb77 -> tool:dsh:lead:call_3f0c438b91a04eb69543d8b3 -> tool:dsh:lead:call_83b745509c6e46d3a09cab74 -> tool:dsh:lead:call_a7c0dbdce600472bb2c4aa33 -> tool:dsh:lead:call_d673a57955ac4dd8ad0ec916 -> tool:dsh:lead:call_ce184109400c49fd9d357ef9 -> tool:dsh:lead:call_8033111dff9d4f71b1b08a4d -> tool:dsh:lead:call_c7ef6cc3788641b5b931414c -> tool:dsh:lead:call_2d5cb787295d40e29979495c -> tool:dsh:lead:call_bb93b191097d4756a7ce12ad -> tool:dsh:lead:call_3f0f2700b5a842b7a6359074
- 关键路径耗时：1.406
- Makespan：191.067
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
