import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON from path. Only object/array top-level allowed.
    Raises ValueError for illegal JSON, non-object/array top-level, or NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"invalid JSON in {path}: {e}") from e

    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")

    _check_finite(data)

    # If object with exactly keys 'name' and 'result', extract result
    if isinstance(data, dict) and set(data.keys()) == {'name', 'result'}:
        return data['result']
    return data


def _check_finite(obj):
    """Recursively check for NaN/Infinity in numeric values."""
    if isinstance(obj, float):
        import math
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number found")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
