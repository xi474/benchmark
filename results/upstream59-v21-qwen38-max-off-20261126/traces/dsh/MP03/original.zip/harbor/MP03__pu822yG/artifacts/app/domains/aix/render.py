import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs per contract, run transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    # Load contract
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    
    # Add component dir to path so we can import local modules
    comp_dir = contract_path.parent
    if str(comp_dir) not in sys.path:
        sys.path.insert(0, str(comp_dir))
    
    from model import load_payload
    from transform import transform
    
    # Load payloads in contract.inputs order
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    # Run transform
    result = transform(payloads, contract)
    
    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    
    return result


if __name__ == '__main__':
    # When run as script, determine root and contract path
    # Contract is in same directory as this script
    script_dir = Path(__file__).resolve().parent
    contract_path = script_dir / 'contract.json'
    # Root is workspace root (parent of domains/)
    root = script_dir.parents[1]
    build_component(root, contract_path)
