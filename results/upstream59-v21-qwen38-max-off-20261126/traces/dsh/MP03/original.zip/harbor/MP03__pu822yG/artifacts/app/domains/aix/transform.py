def transform(payloads, contract):
    """aix_parse: parse AIX mount configuration text into records.
    
    Input: payloads[0] is an object with key 'aix' containing the AIX config string.
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} inputs, got {len(payloads)}")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if 'aix' not in data:
        raise ValueError("missing required field 'aix'")
    
    aix_text = data['aix']
    if not isinstance(aix_text, str):
        raise ValueError("'aix' must be a string")

    records = []
    current_mount = None
    current_attrs = {}
    
    for line in aix_text.split('\n'):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        
        # Check if this is a non-indented mount point header (ends with ':')
        # Non-indented means the original line doesn't start with whitespace
        if not line[0:1].isspace() and stripped.endswith(':'):
            # Save previous segment if any
            if current_mount is not None:
                records.append(_build_record(current_mount, current_attrs))
            
            current_mount = stripped[:-1]  # Remove trailing ':'
            current_attrs = {}
        elif ':' in stripped and not line[0:1].isspace():
            # Could be "mountpoint:" without stripping check - already handled above
            # This handles edge case where line has no leading space but has colon
            if stripped.endswith(':'):
                if current_mount is not None:
                    records.append(_build_record(current_mount, current_attrs))
                current_mount = stripped[:-1]
                current_attrs = {}
            else:
                # It's a key=value on a non-indented line? Treat as attribute if we have a mount
                if current_mount is not None:
                    _parse_attr(stripped, current_attrs)
        else:
            # Indented line - attribute within current segment
            if current_mount is None:
                raise ValueError("attribute found before any mount point header")
            _parse_attr(stripped, current_attrs)
    
    # Don't forget last segment
    if current_mount is not None:
        records.append(_build_record(current_mount, current_attrs))

    return {'name': contract['name'], 'result': {'records': records}}


def _parse_attr(line, attrs):
    """Parse key=value attribute line."""
    if '=' not in line:
        raise ValueError(f"invalid attribute line (no '='): {line!r}")
    
    key, _, value = line.partition('=')
    key = key.strip()
    value = value.strip()
    
    allowed_keys = {'dev', 'vfs', 'options'}
    if key not in allowed_keys:
        raise ValueError(f"unknown key '{key}' in AIX config")
    if key in attrs:
        raise ValueError(f"duplicate key '{key}' in AIX config")
    
    attrs[key] = value


def _build_record(mount, attrs):
    """Build a record from mount point and attributes."""
    if 'dev' not in attrs:
        raise ValueError(f"missing required 'dev' for mount '{mount}'")
    
    device = attrs['dev']
    fstype = attrs.get('vfs', 'jfs2')
    options_raw = attrs.get('options', 'rw')
    
    # Options: comma-split, deduplicate, sort
    opts = [o for o in options_raw.split(',') if o]
    seen = set()
    unique_opts = []
    for o in opts:
        if o not in seen:
            seen.add(o)
            unique_opts.append(o)
    unique_opts.sort()
    
    return {
        'device': device,
        'mount': mount,
        'fstype': fstype,
        'options': ','.join(unique_opts)
    }
