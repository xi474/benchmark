def transform(payloads, contract):
    """fstab_parse: parse fstab text into records.
    
    Input: payloads[0] is an object with key 'fstab' containing the fstab string.
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} inputs, got {len(payloads)}")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if 'fstab' not in data:
        raise ValueError("missing required field 'fstab'")
    
    fstab_text = data['fstab']
    if not isinstance(fstab_text, str):
        raise ValueError("'fstab' must be a string")

    records = []
    for line in fstab_text.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        
        parts = line.split()
        if len(parts) < 4 or len(parts) > 6:
            raise ValueError(f"fstab line must have 4-6 fields, got {len(parts)}: {line!r}")
        
        device = _unescape(parts[0])
        mount = _unescape(parts[1])
        fstype = _unescape(parts[2])
        options_raw = _unescape(parts[3])
        
        # Options: comma-split, deduplicate, sort
        opts = [o for o in options_raw.split(',') if o]
        seen = set()
        unique_opts = []
        for o in opts:
            if o not in seen:
                seen.add(o)
                unique_opts.append(o)
        unique_opts.sort()
        
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': ','.join(unique_opts)
        })

    return {'name': contract['name'], 'result': {'records': records}}


def _unescape(s):
    """Decode \\040 (space), \\011 (tab), \\134 (backslash)."""
    result = []
    i = 0
    while i < len(s):
        if s[i] == '\\' and i + 3 < len(s):
            seq = s[i+1:i+4]
            if seq == '040':
                result.append(' ')
                i += 4
                continue
            elif seq == '011':
                result.append('\t')
                i += 4
                continue
            elif seq == '134':
                result.append('\\')
                i += 4
                continue
        result.append(s[i])
        i += 1
    return ''.join(result)
