import re


def transform(payloads, contract):
    """mount_parse: parse Linux mount output text into records.
    
    Input: payloads[0] is an object with key 'mount' containing the mount string.
    Format: "device on mountpoint type fstype (option1,option2)"
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} inputs, got {len(payloads)}")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if 'mount' not in data:
        raise ValueError("missing required field 'mount'")
    
    mount_text = data['mount']
    if not isinstance(mount_text, str):
        raise ValueError("'mount' must be a string")

    # Pattern: device on mountpoint type fstype (options)
    # device and mountpoint can contain \040 but no bare whitespace
    # We need to handle \040 in device/mountpoint
    pattern = re.compile(
        r'^(\S+)\s+on\s+(\S+)\s+type\s+(\S+)\s+\(([^)]+)\)$'
    )

    records = []
    for line in mount_text.split('\n'):
        line = line.strip()
        if not line:
            continue
        
        m = pattern.match(line)
        if not m:
            raise ValueError(f"invalid mount line: {line!r}")
        
        device_raw = m.group(1)
        mount_raw = m.group(2)
        fstype = m.group(3)
        options_raw = m.group(4).strip()
        
        if not options_raw:
            raise ValueError(f"empty options in mount line: {line!r}")
        
        # Unescape \040 in device and mountpoint
        device = _unescape(device_raw)
        mount = _unescape(mount_raw)
        
        # Options: comma-split, deduplicate, sort
        opts = [o.strip() for o in options_raw.split(',') if o.strip()]
        seen = set()
        unique_opts = []
        for o in opts:
            if o not in seen:
                seen.add(o)
                unique_opts.append(o)
        unique_opts.sort()
        
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': ','.join(unique_opts)
        })

    return {'name': contract['name'], 'result': {'records': records}}


def _unescape(s):
    """Decode \\040 (space), \\011 (tab), \\134 (backslash)."""
    result = []
    i = 0
    while i < len(s):
        if s[i] == '\\' and i + 3 < len(s):
            seq = s[i+1:i+4]
            if seq == '040':
                result.append(' ')
                i += 4
                continue
            elif seq == '011':
                result.append('\t')
                i += 4
                continue
            elif seq == '134':
                result.append('\\')
                i += 4
                continue
        result.append(s[i])
        i += 1
    return ''.join(result)
