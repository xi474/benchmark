"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.exists():
        raise FileNotFoundError(f"Missing {core_path}")

    # Read the raw text to compute sha256 on the canonical serialization
    core = json.loads(core_path.read_text(encoding='utf-8'))

    # Canonical serialization for sha256
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256_hex = hashlib.sha256(canonical).hexdigest()

    components = core.get('components', {})
    component_count = len(components)

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
            continue

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)
                break

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0:
                # Non-empty check: for lists/dicts/strings, check truthiness
                # But we need "non-empty" specifically
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                    break
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)
                    break

    attention_sorted = sorted(attention)

    report = {
        'title': '三种挂载格式的离线事实归并',
        'component_count': component_count,
        'sha256': sha256_hex,
        'attention': attention_sorted
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
