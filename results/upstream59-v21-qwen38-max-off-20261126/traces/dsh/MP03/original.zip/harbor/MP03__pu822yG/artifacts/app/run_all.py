"""Orchestrate all components based on their contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: a component depends on another if its input
    # references an output file produced by that component
    # Map output path -> contract path
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_info[cp] = c
        output_to_contract[c['output']] = cp

    # Topological sort based on dependencies
    # A component depends on another if any of its inputs is an output of another
    deps = {}  # cp -> set of cp it depends on
    for cp in contracts:
        c = contract_info[cp]
        deps[cp] = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                if dep_cp != cp:
                    deps[cp].add(dep_cp)

    # Detect cycles
    ordered = []
    visited = set()
    temp_visited = set()

    def visit(cp):
        if cp in temp_visited:
            print(f"Circular dependency detected involving {cp}", file=sys.stderr)
            sys.exit(1)
        if cp in visited:
            return
        temp_visited.add(cp)
        for dep in sorted(deps[cp]):
            visit(dep)
        temp_visited.remove(cp)
        visited.add(cp)
        ordered.append(cp)

    for cp in sorted(contracts):
        visit(cp)

    # Execute each component in order
    for cp in ordered:
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"integrate.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"final_report.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
