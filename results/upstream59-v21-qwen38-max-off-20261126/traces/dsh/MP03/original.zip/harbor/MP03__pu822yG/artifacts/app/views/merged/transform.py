def transform(payloads, contract):
    """mount_merge: merge records from fstab, aix, mount by source priority.
    
    Input: payloads[0]=fstab result, payloads[1]=aix result, payloads[2]=mount result.
    Each is {"records": [...]}.
    
    Priority order: fstab > aix > mount (first source wins per mount point).
    Output: {"name": contract["name"], "result": {"records": [...], "conflicts": [...]}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} inputs, got {len(payloads)}")

    sources = ['fstab', 'aix', 'mount']
    
    # Collect all records with their source tag
    all_records_by_mount = {}  # mount -> list of (source, record)
    for src_name, payload in zip(sources, payloads):
        if not isinstance(payload, dict) or 'records' not in payload:
            raise ValueError(f"invalid input from {src_name}")
        for rec in payload['records']:
            mount = rec['mount']
            tagged = {
                'device': rec['device'],
                'mount': rec['mount'],
                'fstype': rec['fstype'],
                'options': rec['options'],
                'source': src_name
            }
            if mount not in all_records_by_mount:
                all_records_by_mount[mount] = []
            all_records_by_mount[mount].append(tagged)
    
    # For each mount point, pick first by source priority (already in order)
    winners = {}
    conflicts = []
    
    for mount, entries in all_records_by_mount.items():
        # First entry wins (sources are already in priority order)
        winner = entries[0]
        winners[mount] = winner
        
        # Check for conflicts: any difference in device/fstype/options among all entries
        has_conflict = False
        for e in entries[1:]:
            if (e['device'] != winner['device'] or 
                e['fstype'] != winner['fstype'] or 
                e['options'] != winner['options']):
                has_conflict = True
                break
        
        if has_conflict:
            conflicts.append({
                'mount': mount,
                'evidence': entries  # All records including duplicates
            })
    
    # Records sorted by mount; conflicts also need to be handled
    sorted_records = [winners[m] for m in sorted(winners.keys())]
    
    # Sort conflicts by mount
    conflicts.sort(key=lambda c: c['mount'])
    
    return {
        'name': contract['name'],
        'result': {
            'records': sorted_records,
            'conflicts': conflicts
        }
    }
