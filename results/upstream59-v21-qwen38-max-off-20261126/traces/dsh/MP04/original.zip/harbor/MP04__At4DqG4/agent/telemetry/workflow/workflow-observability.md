# Workflow 可观测性报告

- Trial：`MP04__At4DqG4__env`
- Task：`MP04`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（56 节点 / 55 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：56；执行边：55（observed=0，inferred=55）
- Execution Trace Graph：`observed`；temporal_next 边 55，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_69270c0f1c274c37b4c43291 -> tool:dsh:lead:call_d702eb40e72d46858813ba81 -> tool:dsh:lead:call_a6315ccb55394c4fab1991e6 -> tool:dsh:lead:call_5ab697bff0064e998ee93579 -> tool:dsh:lead:call_59e735f9307e4552b2295891 -> tool:dsh:lead:call_852f6485fc0d4debbbdcc1a9 -> tool:dsh:lead:call_0268efbd6a634ba9b8127197 -> tool:dsh:lead:call_05d2edccc5ae4d4ea2b70d94 -> tool:dsh:lead:call_f8fc9bf09c4742fa8379ae20 -> tool:dsh:lead:call_b60143e3558c4293a2a67f40 -> tool:dsh:lead:call_f44ff17dd2ae4e038b20eb51 -> tool:dsh:lead:call_22d67bbee79c4af0bdfe66a0 -> tool:dsh:lead:call_43e627fdcdbc4d19ba5a59dd -> tool:dsh:lead:call_6674980fb41944bd93e51fd7 -> tool:dsh:lead:call_d48de7c358744eb39d72e4c1 -> tool:dsh:lead:call_386d5a15d29746e8a7115368 -> tool:dsh:lead:call_9aee6eb560b74524a6aafc33 -> tool:dsh:lead:call_dc739a8c0a75499d99d3352c -> tool:dsh:lead:call_35bf1ca267dd4ed0a1b4a2ea -> tool:dsh:lead:call_e09558a8d1ab4407868db9f2 -> tool:dsh:lead:call_69b57354a8bd404c8bfc7631 -> tool:dsh:lead:call_f72829b860f2441dae30fa25 -> tool:dsh:lead:call_5e692a9c7abe4025843780b6 -> tool:dsh:lead:call_b99c58508cc546319d7a7d5c -> tool:dsh:lead:call_2be49329f29a4db8b108ca2f -> tool:dsh:lead:call_a6b8338df5054eb1880866fa -> tool:dsh:lead:call_c0e386409e9740eead04b631 -> tool:dsh:lead:call_a8f3b390c77e4ad6b6bd7f1c -> tool:dsh:lead:call_bc56079719224d22a57326e8 -> tool:dsh:lead:call_1e1d75f3bb0f41f3baee592d -> tool:dsh:lead:call_9884b1be0708416e847d0d46 -> tool:dsh:lead:call_68e75184301d45a883f4c1df -> tool:dsh:lead:call_63c7259295e24d91a6605f09 -> tool:dsh:lead:call_536b769ab7e644ed808d67a0 -> tool:dsh:lead:call_1e0babbbe6b44ea19f850c8f -> tool:dsh:lead:call_31d80c2f8c924ce993bf72e2 -> tool:dsh:lead:call_7ad10321da1545bc8b9c532c -> tool:dsh:lead:call_d64ff86f54cc4969b3c99412 -> tool:dsh:lead:call_d980f56b27a14c87beecbad1 -> tool:dsh:lead:call_f7e0eafc697c4452ba2f9552 -> tool:dsh:lead:call_43f00f5c0d22409e92ec2d66 -> tool:dsh:lead:call_352e6327e4ca457cbfcd4eb1 -> tool:dsh:lead:call_373d895a1c3f4edaa865bbba -> tool:dsh:lead:call_765312c3fbd045fea144923b -> tool:dsh:lead:call_ce22f011a01f4e7da3305e4e -> tool:dsh:lead:call_48777c6b73a149fba544d940 -> tool:dsh:lead:call_9c40073027d24bb7afec19c4 -> tool:dsh:lead:call_7f7a2a0b9dd64773b2718171 -> tool:dsh:lead:call_2451096e53fc487b8b8c452b -> tool:dsh:lead:call_111e229fe8f9439595205e33 -> tool:dsh:lead:call_7e30866a757a474f85fb3868 -> tool:dsh:lead:call_07d644be0e1745c983d7e295 -> tool:dsh:lead:call_33f8dd7e1e804dc09bc16df2 -> tool:dsh:lead:call_faac658d79334f61b8f87c04 -> tool:dsh:lead:call_8ee93bd56c214f6f9b1ef11b
- 关键路径耗时：1.619
- Makespan：251.674
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
