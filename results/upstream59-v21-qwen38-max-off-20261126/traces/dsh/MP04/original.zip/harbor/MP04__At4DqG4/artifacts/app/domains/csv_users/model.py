import json
import math
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON file. Top-level must be object or array. Reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        payload = json.loads(text, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"Non-standard JSON constant: {x}")))
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    if not isinstance(payload, (dict, list)):
        raise ValueError("Top-level must be object or array")
    return payload
