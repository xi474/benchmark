import csv
import io
import re


def _parse_date(s):
    """Parse YYYY-MM-DD or DD/MM/YYYY to ISO date string YYYY-MM-DD."""
    s = s.strip()
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        _validate_date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        _validate_date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    raise ValueError(f"Invalid date format: {s}")


def _validate_date(y, m, d):
    if m < 1 or m > 12:
        raise ValueError(f"Invalid month: {m}")
    days_in_month = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if d < 1 or d > days_in_month[m]:
        raise ValueError(f"Invalid day: {d}")


def _normalize_id(raw_id):
    """Normalize user ID from CSV string value."""
    if isinstance(raw_id, bool):
        raise ValueError("Boolean ID is illegal")
    if isinstance(raw_id, str):
        result = raw_id.strip()
        if not result:
            raise ValueError("Empty ID after strip")
        try:
            val = int(result)
            return str(val)
        except ValueError:
            return result
    raise ValueError(f"Invalid ID type: {type(raw_id)}")


def transform(payloads, contract):
    """Process CSV users from csv_text field in the input payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    payload = payloads[0]

    if not isinstance(payload, dict):
        raise ValueError("Expected object payload")
    if 'csv_text' not in payload:
        raise ValueError("Missing csv_text field")

    csv_text = payload['csv_text']
    if not isinstance(csv_text, str):
        raise ValueError("csv_text must be a string")

    # Empty text -> empty records
    if not csv_text.strip():
        return {"name": contract["name"], "result": {"records": []}}

    # Parse CSV with standard library
    reader = csv.DictReader(io.StringIO(csv_text))

    if reader.fieldnames is None:
        return {"name": contract["name"], "result": {"records": []}}

    headers = list(reader.fieldnames)
    if len(headers) != len(set(headers)):
        raise ValueError("Duplicate column names")

    has_id = 'id' in headers
    has_user_id = 'user_id' in headers
    if not has_id and not has_user_id:
        raise ValueError("CSV must have id or user_id column")

    id_col = 'user_id' if has_user_id else 'id'
    has_full_name = 'full_name' in headers
    has_name = 'name' in headers
    has_mail = 'mail' in headers
    has_email = 'email' in headers
    has_joined_at = 'joined_at' in headers
    has_joined = 'joined' in headers

    # Process rows
    # CSV empty cells are treated as missing (don't overwrite existing values)
    # Same-source duplicate IDs: last existing value per field wins
    users = {}  # id -> {field: value}
    for row in reader:
        raw_id = row.get(id_col)
        if raw_id is None or raw_id.strip() == '':
            continue

        uid = _normalize_id(raw_id)

        if uid not in users:
            users[uid] = {}

        # Name: full_name preferred over name when both columns exist
        # Last existing (non-empty) value wins for same ID
        if has_full_name:
            val = row.get('full_name')
            if val is not None and val != '':
                users[uid]['name'] = val
        elif has_name:
            val = row.get('name')
            if val is not None and val != '':
                users[uid]['name'] = val

        # Email: mail preferred over email
        if has_mail:
            val = row.get('mail')
            if val is not None and val != '':
                users[uid]['email'] = val
        elif has_email:
            val = row.get('email')
            if val is not None and val != '':
                users[uid]['email'] = val

        # Joined: joined_at preferred over joined
        if has_joined_at:
            val = row.get('joined_at')
            if val is not None and val.strip() != '':
                users[uid]['joined'] = _parse_date(val)
        elif has_joined:
            val = row.get('joined')
            if val is not None and val.strip() != '':
                users[uid]['joined'] = _parse_date(val)

    # Build output records sorted by id (string lexicographic)
    records = []
    for uid in sorted(users.keys()):
        rec = {'id': uid}
        u = users[uid]
        if 'name' in u:
            rec['name'] = u['name']
        if 'email' in u:
            rec['email'] = u['email']
        if 'joined' in u:
            rec['joined'] = u['joined']
        records.append(rec)

    return {"name": contract["name"], "result": {"records": records}}
