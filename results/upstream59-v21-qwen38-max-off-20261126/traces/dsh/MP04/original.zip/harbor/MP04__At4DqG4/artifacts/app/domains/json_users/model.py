import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check for NaN/Infinity in JSON-parsed objects."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("Non-finite number found")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read UTF-8 JSON file. Top-level must be object or array. Reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    # Use strict parse to reject NaN/Infinity tokens
    try:
        payload = json.loads(text, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"Non-standard JSON constant: {x}")))
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    if not isinstance(payload, (dict, list)):
        raise ValueError("Top-level must be object or array")
    return payload
