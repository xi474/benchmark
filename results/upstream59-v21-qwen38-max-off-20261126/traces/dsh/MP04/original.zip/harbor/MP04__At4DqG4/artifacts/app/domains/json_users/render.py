import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs per contract, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)

    # Load contract
    with open(contract_path, 'r', encoding='utf-8') as f:
        contract = json.load(f)

    # Import model and transform from the same directory
    comp_dir = contract_path.parent
    sys.path.insert(0, str(comp_dir))
    try:
        from model import load_payload
        from transform import transform
    finally:
        sys.path.pop(0)

    # Load payloads in contract.inputs order
    payloads = [load_payload(root / p) for p in contract['inputs']]

    # Run transform
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

    return result


if __name__ == "__main__":
    # Determine workspace root and contract path
    # When run as `python3 domains/json_users/render.py`, we need to find root
    script_dir = Path(__file__).resolve().parent
    contract_path = script_dir / 'contract.json'
    # Root is two levels up from component dir (domains/json_users -> workspace)
    root = script_dir.parents[1]
    build_component(root, contract_path)
