import json
import re


def _parse_date(s):
    """Parse YYYY-MM-DD or DD/MM/YYYY to ISO date string YYYY-MM-DD."""
    s = s.strip()
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        _validate_date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        _validate_date(y, mo, d)
        return f"{y:04d}-{mo:02d}-{d:02d}"
    raise ValueError(f"Invalid date format: {s}")


def _validate_date(y, m, d):
    if m < 1 or m > 12:
        raise ValueError(f"Invalid month: {m}")
    days_in_month = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if d < 1 or d > days_in_month[m]:
        raise ValueError(f"Invalid day: {d}")


def _normalize_id(raw_id):
    """Normalize user ID: must be non-empty str or int (bool illegal). Returns stripped string."""
    if isinstance(raw_id, bool):
        raise ValueError("Boolean ID is illegal")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        result = raw_id.strip()
        if not result:
            raise ValueError("Empty ID after strip")
        return result
    raise ValueError(f"Invalid ID type: {type(raw_id)}")


def transform(payloads, contract):
    """Process JSONL users from jsonl_text field in the input payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    payload = payloads[0]

    if not isinstance(payload, dict):
        raise ValueError("Expected object payload")
    if 'jsonl_text' not in payload:
        raise ValueError("Missing jsonl_text field")

    jsonl_text = payload['jsonl_text']
    if not isinstance(jsonl_text, str):
        raise ValueError("jsonl_text must be a string")

    # Parse JSONL: ignore blank lines, each other line must be valid JSON object
    records_raw = []
    for line in jsonl_text.split('\n'):
        if line.strip() == '':
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSONL line: {e}") from e
        if not isinstance(obj, dict):
            raise ValueError("Each JSONL line must be an object")
        records_raw.append(obj)

    # Process records - same logic as json_users
    users = {}  # id -> {field: value}
    for obj in records_raw:
        # Determine ID
        raw_id = None
        if 'id' in obj:
            raw_id = obj['id']
        elif 'user_id' in obj:
            raw_id = obj['user_id']
        else:
            raise ValueError("Record missing id/user_id")

        uid = _normalize_id(raw_id)

        if uid not in users:
            users[uid] = {}

        # name / full_name - new field preferred; null/missing don't assign; empty string is valid
        if 'full_name' in obj and obj['full_name'] is not None:
            users[uid]['name'] = obj['full_name']
        elif 'name' in obj and obj['name'] is not None:
            users[uid]['name'] = obj['name']

        # email / mail
        if 'mail' in obj and obj['mail'] is not None:
            users[uid]['email'] = obj['mail']
        elif 'email' in obj and obj['email'] is not None:
            users[uid]['email'] = obj['email']

        # joined / joined_at
        if 'joined_at' in obj and obj['joined_at'] is not None:
            val = obj['joined_at']
            if isinstance(val, str) and val.strip():
                users[uid]['joined'] = _parse_date(val)
        elif 'joined' in obj and obj['joined'] is not None:
            val = obj['joined']
            if isinstance(val, str) and val.strip():
                users[uid]['joined'] = _parse_date(val)

    # Build output records sorted by id
    records = []
    for uid in sorted(users.keys()):
        rec = {'id': uid}
        u = users[uid]
        if 'name' in u:
            rec['name'] = u['name']
        if 'email' in u:
            rec['email'] = u['email']
        if 'joined' in u:
            rec['joined'] = u['joined']
        records.append(rec)

    return {"name": contract["name"], "result": {"records": records}}
