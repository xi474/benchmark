"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.exists():
        raise FileNotFoundError("core_manifest.json not found")

    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core.get('components', {})
    component_count = len(components)

    # Compute SHA256 of the full core object
    # Serialized as: json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)
    # No trailing newline
    canonical = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    sha256_hex = hashlib.sha256(canonical.encode('utf-8')).hexdigest()

    # Determine attention list
    # Conditions for a component to be in attention:
    # - result.blocked explicitly true
    # - complete/checkout/committed/ok any explicitly false
    # - unavailable/missing/conflicts/unreachable any non-empty
    # Field absence doesn't trigger; false vs 0/null distinction matters
    attention = set()
    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue

        # Check blocked
        if 'blocked' in comp_result and comp_result['blocked'] is True:
            attention.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false
        for key in ['complete', 'checkout', 'committed', 'ok']:
            if key in comp_result and comp_result[key] is False:
                attention.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ['unavailable', 'missing', 'conflicts', 'unreachable']:
            if key in comp_result:
                val = comp_result[key]
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)

    attention_sorted = sorted(attention)

    report = {
        "title": "多格式用户合并与完整冲突报告",
        "component_count": component_count,
        "sha256": sha256_hex,
        "attention": attention_sorted
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
