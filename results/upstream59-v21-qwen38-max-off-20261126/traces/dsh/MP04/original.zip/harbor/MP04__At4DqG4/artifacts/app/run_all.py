"""Orchestrate all components: run domain components first, then views."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (excluding outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: a component depends on components whose outputs it consumes
    contract_map = {}  # contract_path -> contract dict
    output_to_contract = {}  # output path -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[cp] = c
        output_to_contract[c['output']] = cp

    # Determine execution order via topological sort
    # Dependencies: if a contract's input matches another contract's output
    deps = {}  # cp -> set of cp it depends on
    for cp, c in contract_map.items():
        deps[cp] = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                deps[cp].add(output_to_contract[inp])

    # Topological sort
    ordered = []
    visited = set()
    temp = set()

    def visit(cp):
        if cp in temp:
            print(f"Circular dependency detected", file=sys.stderr)
            sys.exit(1)
        if cp in visited:
            return
        temp.add(cp)
        for dep in deps[cp]:
            visit(dep)
        temp.remove(cp)
        visited.add(cp)
        ordered.append(cp)

    for cp in contracts:
        visit(cp)

    # Execute each component in order
    for cp in ordered:
        render_script = cp.with_name('render.py')
        if not render_script.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.exists():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
