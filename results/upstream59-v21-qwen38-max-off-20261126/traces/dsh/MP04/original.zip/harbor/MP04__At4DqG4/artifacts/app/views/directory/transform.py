def transform(payloads, contract):
    """Merge users from JSON, CSV, JSONL sources with conflict tracking."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    # Source names in priority order (matching contract.inputs order)
    source_names = ['json', 'csv', 'jsonl']

    # Extract records from each source
    # Each payload is {"name": ..., "result": {"records": [...]}}
    source_records = {}  # source_name -> {id -> record}
    for i, payload in enumerate(payloads):
        src = source_names[i]
        if not isinstance(payload, dict) or 'result' not in payload:
            raise ValueError(f"Invalid payload structure for {src}")
        result = payload['result']
        if not isinstance(result, dict) or 'records' not in result:
            raise ValueError(f"Invalid result structure for {src}")
        records = result['records']
        if not isinstance(records, list):
            raise ValueError(f"Records must be a list for {src}")

        rec_map = {}
        for rec in records:
            if not isinstance(rec, dict) or 'id' not in rec:
                raise ValueError(f"Invalid record in {src}")
            uid = rec['id']
            rec_map[uid] = rec
        source_records[src] = rec_map

    # Collect all user IDs
    all_ids = set()
    for src in source_names:
        all_ids.update(source_records[src].keys())

    # Merge fields and track conflicts
    fields = ['name', 'email', 'joined']
    users = []
    conflicts = []

    for uid in sorted(all_ids):
        merged = {'id': uid}
        for field in fields:
            # Find first existing value by priority
            chosen_value = None
            chosen_source = None
            field_values = []  # (source, value) pairs for conflict detection

            for src in source_names:
                rec = source_records[src].get(uid)
                if rec is not None and field in rec:
                    val = rec[field]
                    field_values.append((src, val))
                    if chosen_value is None:
                        chosen_value = val
                        chosen_source = src

            if chosen_value is not None:
                merged[field] = chosen_value

            # Check for conflicts: 2+ different values from different sources
            if len(field_values) >= 2:
                unique_values = set()
                for _, v in field_values:
                    unique_values.add(v)
                if len(unique_values) > 1:
                    conflict_entry = {
                        'id': uid,
                        'field': field,
                        'values': [{'source': s, 'value': v} for s, v in field_values]
                    }
                    conflicts.append(conflict_entry)

        users.append(merged)

    # Sort conflicts by (id, field)
    conflicts.sort(key=lambda c: (c['id'], c['field']))

    return {"name": contract["name"], "result": {"users": users, "conflicts": conflicts}}
