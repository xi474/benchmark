# Workflow 可观测性报告

- Trial：`MP05__RbBCuMQ__env`
- Task：`MP05`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（60 节点 / 59 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：60；执行边：59（observed=0，inferred=59）
- Execution Trace Graph：`observed`；temporal_next 边 59，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_7bb0fa64a30a424690a2649b -> tool:dsh:lead:call_52347d4a7a264599a20892df -> tool:dsh:lead:call_eedbf0fa72534343ba9e2d30 -> tool:dsh:lead:call_001dc3d18f094a089c3b4b11 -> tool:dsh:lead:call_ac3b293f399844dd91a01fba -> tool:dsh:lead:call_b0ec9c1746e442978080e01e -> tool:dsh:lead:call_808073a12dcb4d7d9db131d2 -> tool:dsh:lead:call_187ca8bb13b547f7b02d7d74 -> tool:dsh:lead:call_af9b2c86402e4e21a1ddb05b -> tool:dsh:lead:call_690701a3a516470db2b9abaf -> tool:dsh:lead:call_a9be95c18e9e44958d737445 -> tool:dsh:lead:call_c15df0ab3b034770b9aa0dce -> tool:dsh:lead:call_232d5153f4414facac92ceda -> tool:dsh:lead:call_427a55f039ff4941b3550953 -> tool:dsh:lead:call_2953a542bd9142d2afeca5d7 -> tool:dsh:lead:call_c6559093e9de4551a9e477a3 -> tool:dsh:lead:call_c1db51288cf647d48a9d83d3 -> tool:dsh:lead:call_7232303f0b3e43c594e47b08 -> tool:dsh:lead:call_4a431faf303f4af4b677df47 -> tool:dsh:lead:call_a22f3d5ed27d47c09d0a1714 -> tool:dsh:lead:call_92e2d84b0cc84972afafd57b -> tool:dsh:lead:call_79f581a0d4994c7fa62690a1 -> tool:dsh:lead:call_8b78a185917046d4b9c7494b -> tool:dsh:lead:call_a950a382b0414295833ce03b -> tool:dsh:lead:call_5723f8690bb74cf184982b52 -> tool:dsh:lead:call_bc20634fbb054af39567c9ce -> tool:dsh:lead:call_8725f8111cc34aa3b6f51a42 -> tool:dsh:lead:call_b5da5474cc3a4c1982c4d6a2 -> tool:dsh:lead:call_e66b2b35b64c4a35b337733c -> tool:dsh:lead:call_0379d6d629414ccda41c9540 -> tool:dsh:lead:call_bb962d02ed244da5957b650c -> tool:dsh:lead:call_18c830c73b7b4d87a78edfea -> tool:dsh:lead:call_dcf41b2b5c7849a38122234c -> tool:dsh:lead:call_4d7836e525c547a78d201d82 -> tool:dsh:lead:call_4800a9cdf6e840079fcbfcc5 -> tool:dsh:lead:call_84850d8e22574234b0dd90d1 -> tool:dsh:lead:call_3a7612c38f4247fab34b7c6f -> tool:dsh:lead:call_fe436cad2be3489b81bba985 -> tool:dsh:lead:call_7c5c70692c9d4903a16c5e61 -> tool:dsh:lead:call_2a5a992724304e85b308e043 -> tool:dsh:lead:call_6dd97428cb334ad9861bc9c7 -> tool:dsh:lead:call_354dafc86b404520b1d031ca -> tool:dsh:lead:call_141390da28994e0aa58b8074 -> tool:dsh:lead:call_975deb27091041e0aa17a2a6 -> tool:dsh:lead:call_0d17c21503044c02a7a3851c -> tool:dsh:lead:call_3d8d110973bd49cebb6b58a3 -> tool:dsh:lead:call_6780c0c491e942c0a5a1ae3a -> tool:dsh:lead:call_6aa6bd2b32be4db48de86625 -> tool:dsh:lead:call_312f4641b72a401eb521d3ac -> tool:dsh:lead:call_3a2c20010b924929a215b3d9 -> tool:dsh:lead:call_ae9c2197741842b7a579e2e3 -> tool:dsh:lead:call_e0510d8d91e144a6851e88f4 -> tool:dsh:lead:call_3e4eaea6b7f347c29803fe8f -> tool:dsh:lead:call_6b24c14ba1094e789246e579 -> tool:dsh:lead:call_f9a11d8f98ea4123b550e93a -> tool:dsh:lead:call_089e771e4b5742ee8ff7ca0f -> tool:dsh:lead:call_3448a72e0e764031a9df32f5 -> tool:dsh:lead:call_9727cdd027964b21aba7f8d8 -> tool:dsh:lead:call_2150c818bbe94722a506674d
- 关键路径耗时：1.264
- Makespan：208.779
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
