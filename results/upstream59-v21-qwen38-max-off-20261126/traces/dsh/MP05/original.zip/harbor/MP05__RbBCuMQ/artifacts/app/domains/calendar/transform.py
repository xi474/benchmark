def _extract_business(obj):
    """If obj is a dict with exactly keys {name, result}, return result; else return obj."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = _extract_business(payloads[0])

    if not isinstance(case, dict):
        raise ValueError("case must be object")

    contacts = case.get('contacts')
    self_id = case.get('self_id')
    window = case.get('window')
    events = case.get('events')

    if contacts is None or self_id is None or window is None or events is None:
        raise ValueError("missing required field")

    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")

    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")

    if not isinstance(window, list) or len(window) != 2:
        raise ValueError("window must be [start, end]")

    w_start, w_end = window
    if isinstance(w_start, bool) or isinstance(w_end, bool):
        raise ValueError("window values must be numbers")
    if not isinstance(w_start, (int, float)) or not isinstance(w_end, (int, float)):
        raise ValueError("window values must be numbers")

    if not isinstance(events, list):
        raise ValueError("events must be list")

    # Build contact map
    contact_map = {}
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        cid = c.get('id')
        age = c.get('age')
        if cid is None or age is None:
            raise ValueError("contact missing id or age")
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if isinstance(age, bool) or not isinstance(age, int) or age < 0:
            raise ValueError("contact age must be non-negative integer")
        contact_map[cid] = age

    # Initialize minutes for all non-self contacts
    minutes = {}
    for cid in contact_map:
        if cid != self_id:
            minutes[cid] = 0

    # Process events
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be object")
        eid = ev.get('id')
        start = ev.get('start')
        end = ev.get('end')
        attendees = ev.get('attendees')
        if eid is None or start is None or end is None or attendees is None:
            raise ValueError("event missing required field")

        if isinstance(start, bool) or isinstance(end, bool):
            raise ValueError("event times must be numbers")
        if not isinstance(start, (int, float)) or not isinstance(end, (int, float)):
            raise ValueError("event times must be numbers")
        if end <= start:
            raise ValueError("event end must be > start")

        if not isinstance(attendees, list):
            raise ValueError("attendees must be list")

        # Check if self_id is in attendees
        has_self = False
        unique_attendees = set()
        for a in attendees:
            if not isinstance(a, str):
                raise ValueError("attendee must be string")
            if a not in contact_map:
                raise ValueError(f"unknown attendee {a}")
            if a == self_id:
                has_self = True
            unique_attendees.add(a)

        if not has_self:
            continue

        # Clip to window [w_start, w_end) - half-open
        clipped_start = max(start, w_start)
        clipped_end = min(end, w_end)
        duration = clipped_end - clipped_start
        if duration <= 0:
            continue

        # Add duration to each non-self attendee (deduplicated)
        for a in unique_attendees:
            if a != self_id:
                minutes[a] += duration

    # Convert to int if whole numbers, keep as number type
    # The spec says "累计分钟数" - these are sums of integer differences, should be numeric
    # Keep as-is (int or float depending on input)
    result_minutes = {}
    for cid in sorted(minutes.keys()):
        val = minutes[cid]
        # If it's a whole float, convert to int
        if isinstance(val, float) and val == int(val):
            val = int(val)
        result_minutes[cid] = val

    return {"name": contract["name"], "result": {"minutes": result_minutes}}
