def _extract_business(obj):
    """If obj is a dict with exactly keys {name, result}, return result; else return obj."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = _extract_business(payloads[0])

    # Validate required fields
    if not isinstance(case, dict):
        raise ValueError("case must be object")

    contacts = case.get('contacts')
    self_id = case.get('self_id')
    keyword = case.get('keyword')
    groups = case.get('groups')

    if contacts is None or self_id is None or keyword is None or groups is None:
        raise ValueError("missing required field")

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")

    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")

    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")

    if not isinstance(groups, list):
        raise ValueError("groups must be list")

    # Build contact map for validation
    contact_ids = set()
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        cid = c.get('id')
        age = c.get('age')
        if cid is None or age is None:
            raise ValueError("contact missing id or age")
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if isinstance(age, bool) or not isinstance(age, int) or age < 0:
            raise ValueError("contact age must be non-negative integer")
        contact_ids.add(cid)

    # Process groups
    candidates = set()
    kw_lower = keyword.casefold()

    for g in groups:
        if not isinstance(g, dict):
            raise ValueError("group must be object")
        gid = g.get('id')
        members = g.get('members')
        messages = g.get('messages')
        if gid is None or members is None or messages is None:
            raise ValueError("group missing required field")
        if not isinstance(members, list):
            raise ValueError("members must be list")
        if not isinstance(messages, list):
            raise ValueError("messages must be list")

        # Validate all members exist
        for m in members:
            if not isinstance(m, str):
                raise ValueError("member must be string")
            if m not in contact_ids:
                raise ValueError(f"unknown member {m}")

        # Check if any message contains keyword (case-insensitive)
        matched = False
        for msg in messages:
            if not isinstance(msg, str):
                raise ValueError("message must be string")
            if kw_lower in msg.casefold():
                matched = True
                break

        if matched:
            for m in members:
                if m != self_id:
                    candidates.add(m)

    result_ids = sorted(candidates)
    return {"name": contract["name"], "result": {"ids": result_ids}}
