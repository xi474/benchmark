def _extract_business(obj):
    """If obj is a dict with exactly keys {name, result}, return result; else return obj."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = _extract_business(payloads[0])

    if not isinstance(case, dict):
        raise ValueError("case must be object")

    contacts = case.get('contacts')
    self_id = case.get('self_id')
    keyword = case.get('keyword')
    emails = case.get('emails')

    if contacts is None or self_id is None or keyword is None or emails is None:
        raise ValueError("missing required field")

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")

    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")

    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")

    if not isinstance(emails, list):
        raise ValueError("emails must be list")

    # Build contact set for validation
    contact_ids = set()
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        cid = c.get('id')
        age = c.get('age')
        if cid is None or age is None:
            raise ValueError("contact missing id or age")
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if isinstance(age, bool) or not isinstance(age, int) or age < 0:
            raise ValueError("contact age must be non-negative integer")
        contact_ids.add(cid)

    # Process emails
    candidates = set()
    kw_lower = keyword.casefold()

    for e in emails:
        if not isinstance(e, dict):
            raise ValueError("email must be object")
        eid = e.get('id')
        sender = e.get('sender')
        subject = e.get('subject')
        if eid is None or sender is None or subject is None:
            raise ValueError("email missing required field")
        if not isinstance(sender, str):
            raise ValueError("sender must be string")
        if not isinstance(subject, str):
            raise ValueError("subject must be string")

        # Validate sender exists
        if sender not in contact_ids:
            raise ValueError(f"unknown sender {sender}")

        # Check if subject contains keyword (case-insensitive)
        if kw_lower in subject.casefold():
            if sender != self_id:
                candidates.add(sender)

    result_ids = sorted(candidates)
    return {"name": contract["name"], "result": {"ids": result_ids}}
