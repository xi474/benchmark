#!/usr/bin/env python3
"""Generate final report from core manifest."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core['components']
    component_count = len(components)

    # Compute sha256
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # Check result.blocked explicitly true
        blocked = result.get('blocked')
        if blocked is True:
            attention.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            val = result.get(key)
            if val is False:
                attention.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None:
                # Non-empty check: list/dict/set must have len > 0, string must be non-empty
                if isinstance(val, (list, dict, set)):
                    if len(val) > 0:
                        attention.add(comp_name)
                elif isinstance(val, str):
                    if len(val) > 0:
                        attention.add(comp_name)
                # Other truthy types (int, bool, etc.) - only trigger if non-empty
                # The spec says "non-empty" which applies to collections/strings
                # For other types, they don't match "non-empty" semantics

    attention_sorted = sorted(attention)

    report = {
        "title": "跨应用候选并集与相处时长排名",
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_sorted,
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )


if __name__ == '__main__':
    main()
