#!/usr/bin/env python3
"""Orchestrate all components based on contract.json file interfaces."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph
    # Each contract has inputs; if an input starts with "outputs/", it depends on
    # the component that produces that output.
    contract_map = {}  # name -> {contract_path, output, deps}
    output_to_name = {}  # output_path -> component_name

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        output = c['output']
        contract_map[name] = {
            'contract_path': cp,
            'output': output,
            'deps': set(),
            'inputs': c['inputs'],
        }
        output_to_name[output] = name

    # Resolve dependencies
    for name, info in contract_map.items():
        for inp in info['inputs']:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                if dep_name != name:
                    info['deps'].add(dep_name)

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"Circular dependency detected involving {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        for dep in sorted(contract_map[name]['deps']):
            if dep not in contract_map:
                print(f"Unknown dependency {dep} for {name}", file=sys.stderr)
                sys.exit(1)
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Execute each component's render.py in order
    for name in ordered:
        info = contract_map[name]
        comp_dir = info['contract_path'].parent
        render_py = comp_dir / 'render.py'
        if not render_py.is_file():
            print(f"Missing render.py for {name}: {render_py}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"integrate.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"final_report.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
