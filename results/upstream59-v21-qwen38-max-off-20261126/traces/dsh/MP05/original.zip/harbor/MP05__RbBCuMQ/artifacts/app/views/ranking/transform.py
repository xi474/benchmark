def _extract_business(obj):
    """If obj is a dict with exactly keys {name, result}, return result; else return obj."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    # payloads[0] = original case snapshot
    # payloads[1] = groups output {name, result: {ids}}
    # payloads[2] = mail output {name, result: {ids}}
    # payloads[3] = calendar output {name, result: {minutes}}

    case = _extract_business(payloads[0])
    groups_result = _extract_business(payloads[1])
    mail_result = _extract_business(payloads[2])
    calendar_result = _extract_business(payloads[3])

    if not isinstance(case, dict):
        raise ValueError("case must be object")

    contacts = case.get('contacts')
    self_id = case.get('self_id')

    if contacts is None or self_id is None:
        raise ValueError("missing required field")

    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")

    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")

    # Build contact map
    contact_map = {}
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        cid = c.get('id')
        age = c.get('age')
        if cid is None or age is None:
            raise ValueError("contact missing id or age")
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if isinstance(age, bool) or not isinstance(age, int) or age < 0:
            raise ValueError("contact age must be non-negative integer")
        contact_map[cid] = age

    # Extract candidate sets
    if not isinstance(groups_result, dict):
        raise ValueError("groups result must be object")
    group_ids = groups_result.get('ids')
    if not isinstance(group_ids, list):
        raise ValueError("group ids must be list")

    if not isinstance(mail_result, dict):
        raise ValueError("mail result must be object")
    mail_ids = mail_result.get('ids')
    if not isinstance(mail_ids, list):
        raise ValueError("mail ids must be list")

    if not isinstance(calendar_result, dict):
        raise ValueError("calendar result must be object")
    cal_minutes = calendar_result.get('minutes')
    if not isinstance(cal_minutes, dict):
        raise ValueError("calendar minutes must be object")

    # Union of candidates
    all_candidates = set()
    for cid in group_ids:
        if not isinstance(cid, str):
            raise ValueError("candidate id must be string")
        all_candidates.add(cid)
    for cid in mail_ids:
        if not isinstance(cid, str):
            raise ValueError("candidate id must be string")
        all_candidates.add(cid)

    # Build ranking entries
    ranking_entries = []
    for cid in all_candidates:
        if cid not in contact_map:
            raise ValueError(f"unknown candidate {cid}")
        age = contact_map[cid]
        mins = cal_minutes.get(cid, 0)
        if isinstance(mins, bool):
            raise ValueError("minutes must be number")
        if not isinstance(mins, (int, float)):
            raise ValueError("minutes must be number")
        # Convert to int if whole
        if isinstance(mins, float) and mins == int(mins):
            mins = int(mins)
        ranking_entries.append({"id": cid, "minutes": mins, "age": age})

    # Sort: minutes desc, age desc, id asc
    ranking_entries.sort(key=lambda x: (-x["minutes"], -x["age"], x["id"]))

    winner = ranking_entries[0]["id"] if ranking_entries else None

    return {"name": contract["name"], "result": {"ranking": ranking_entries, "winner": winner}}
