# Workflow 可观测性报告

- Trial：`MP06__kNjNwwn__env`
- Task：`MP06`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（52 节点 / 51 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：52；执行边：51（observed=0，inferred=51）
- Execution Trace Graph：`observed`；temporal_next 边 51，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_9dcaf6a38a28433f993c7dd5 -> tool:dsh:lead:call_f99cea2c59c54036bc43418f -> tool:dsh:lead:call_3e19afb004194fb8a18062b1 -> tool:dsh:lead:call_cf08d5cd5ce3478aa9e8d97b -> tool:dsh:lead:call_1c2f0a546641435591dcd322 -> tool:dsh:lead:call_16e4215b38da4801afa03eed -> tool:dsh:lead:call_0fdf84bffd1a4ea289550c2f -> tool:dsh:lead:call_8607424773254ddebea61d33 -> tool:dsh:lead:call_2a0b9af8761e446fb4a889d8 -> tool:dsh:lead:call_d4741ac2bbb64e81878aa110 -> tool:dsh:lead:call_facaa958a73f4dfda45833c7 -> tool:dsh:lead:call_8eaaefefe3ee4f5eb8a312b1 -> tool:dsh:lead:call_7bcaa0f398174b2fb49fafe4 -> tool:dsh:lead:call_03c5c9c4f9524ebabe3e1529 -> tool:dsh:lead:call_36eabad467f141ffb80d7fcf -> tool:dsh:lead:call_becf247fa1c0419795fc6d22 -> tool:dsh:lead:call_6498344541764bf7be064a6e -> tool:dsh:lead:call_9fe3fb13c4154be1aedc5827 -> tool:dsh:lead:call_f807456cd8994e6bafebf5d3 -> tool:dsh:lead:call_f0a537838a8342ada4849829 -> tool:dsh:lead:call_af1351b84b8146ceba7f82db -> tool:dsh:lead:call_8e20d9fd7cf44778a50d0b14 -> tool:dsh:lead:call_f5d530bfcb8a4b7e8bc3bbc1 -> tool:dsh:lead:call_0b665a39ffdb46abbed76e56 -> tool:dsh:lead:call_315ed4cce48e49419c1dc3b0 -> tool:dsh:lead:call_e399a3ae0a294b799d0b237e -> tool:dsh:lead:call_2f65f926995d4cd1b36eb56a -> tool:dsh:lead:call_42bdb69635ca4c339d6e7633 -> tool:dsh:lead:call_9bb1a48da69d4e31adaac08a -> tool:dsh:lead:call_f1cce21c1dda446689b04dc2 -> tool:dsh:lead:call_c1bcf4a5368b4a6d9f9ec2f8 -> tool:dsh:lead:call_033c37ae06474e04be74a8de -> tool:dsh:lead:call_791f9d3400d64aff8238d6e9 -> tool:dsh:lead:call_8110a83e13cd49c18ad16493 -> tool:dsh:lead:call_cb4e1e328e67432db5a03ecd -> tool:dsh:lead:call_deb86be400e441038ad1b205 -> tool:dsh:lead:call_1fe542bf56a54105a60639a1 -> tool:dsh:lead:call_e08a2e3893f64f92889777f5 -> tool:dsh:lead:call_18caa1e7f21148bc9b53687e -> tool:dsh:lead:call_ca1e5db3c76243a0afadfe4e -> tool:dsh:lead:call_b048f117d39f447e99df61cc -> tool:dsh:lead:call_fac376ee197844668d3f7282 -> tool:dsh:lead:call_4c3cb05b7e1c4dd1b731c7fe -> tool:dsh:lead:call_59b486fab6734e51bda19f25 -> tool:dsh:lead:call_1774eea2d37a4688afd73f11 -> tool:dsh:lead:call_59c185b90d694777978618f4 -> tool:dsh:lead:call_54ac531ee97b45e6b7248f62 -> tool:dsh:lead:call_a1f17d1d7d934293b2d145c1 -> tool:dsh:lead:call_67cf4cc93c1848cb9ab7edff -> tool:dsh:lead:call_7e38825deeaa410e83534af5 -> tool:dsh:lead:call_c44460d2373f4ab9b38075fd
- 关键路径耗时：1.177
- Makespan：288.874
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
