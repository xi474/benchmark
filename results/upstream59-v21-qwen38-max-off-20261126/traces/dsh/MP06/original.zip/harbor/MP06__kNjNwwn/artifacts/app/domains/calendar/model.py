import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON file; only object/array top-level allowed.
    
    Raises ValueError for invalid JSON, non-object/array top-level,
    or nested NaN/Infinity values.
    """
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")
    
    _check_finite(data)
    return data


def _check_finite(obj):
    """Recursively check for NaN/Infinity in nested structures."""
    if isinstance(obj, float):
        import math
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError(f"non-finite number: {obj}")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
