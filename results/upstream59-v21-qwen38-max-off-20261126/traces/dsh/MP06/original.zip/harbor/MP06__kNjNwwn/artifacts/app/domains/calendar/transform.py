def transform(payloads, contract):
    """cancel_morning operation.
    
    Input: {events:[{id,start,end,social,cancelled,attendees}], day:int>=0, 
            contacts:[{id,email,message,chat}]}
    
    Select events where start in [day*1440, day*1440+720), social=true, 
    cancelled=false, end>start.
    
    Return {cancelled: sorted target ids, snapshots: target original records by id,
            remaining: other original records by id}.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    data = payloads[0]
    
    # Validate required fields
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    for key in ('events', 'day', 'contacts'):
        if key not in data:
            raise ValueError(f"missing required field: {key}")
    
    events = data['events']
    day = data['day']
    
    if not isinstance(day, int) or isinstance(day, bool):
        raise ValueError("day must be an integer")
    if day < 0:
        raise ValueError("day must be >= 0")
    if not isinstance(events, list):
        raise ValueError("events must be a list")
    
    day_start = day * 1440
    day_morning_end = day_start + 720
    
    cancelled_ids = []
    snapshots = {}
    remaining = {}
    
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("each event must be an object")
        for k in ('id', 'start', 'end', 'social', 'cancelled', 'attendees'):
            if k not in ev:
                raise ValueError(f"event missing field: {k}")
        
        eid = ev['id']
        start = ev['start']
        end = ev['end']
        social = ev['social']
        cancelled = ev['cancelled']
        
        if not isinstance(start, int) or isinstance(start, bool):
            raise ValueError("start must be int")
        if not isinstance(end, int) or isinstance(end, bool):
            raise ValueError("end must be int")
        if not isinstance(social, bool):
            raise ValueError("social must be bool")
        if not isinstance(cancelled, bool):
            raise ValueError("cancelled must be bool")
        
        is_target = (
            day_start <= start < day_morning_end
            and social
            and not cancelled
            and end > start
        )
        
        if is_target:
            cancelled_ids.append(eid)
            snapshots[eid] = ev
        else:
            remaining[eid] = ev
    
    cancelled_ids.sort()
    
    return {
        "name": contract["name"],
        "result": {
            "cancelled": cancelled_ids,
            "snapshots": snapshots,
            "remaining": remaining
        }
    }
