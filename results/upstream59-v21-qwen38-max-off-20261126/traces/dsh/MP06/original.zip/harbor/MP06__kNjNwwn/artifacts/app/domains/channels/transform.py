def transform(payloads, contract):
    """channel_directory operation.
    
    Input: same as cancel_morning input {events, day, contacts}.
    Contact IDs must be unique. email/message/chat must be null or non-empty str.
    Each person: prefer message, then chat; email is independent.
    
    Return {contacts: {id: {email, primary, address}}}
    - email: the email address or null
    - primary: "message" if message field is non-null, "chat" if chat field is non-null 
      (and message is null), else null
    - address: the value of the chosen primary channel, or null
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if 'contacts' not in data:
        raise ValueError("missing required field: contacts")
    
    contacts_list = data['contacts']
    if not isinstance(contacts_list, list):
        raise ValueError("contacts must be a list")
    
    seen_ids = set()
    result_contacts = {}
    
    for c in contacts_list:
        if not isinstance(c, dict):
            raise ValueError("each contact must be an object")
        for k in ('id', 'email', 'message', 'chat'):
            if k not in c:
                raise ValueError(f"contact missing field: {k}")
        
        cid = c['id']
        email = c['email']
        message = c['message']
        chat = c['chat']
        
        if cid in seen_ids:
            raise ValueError(f"duplicate contact id: {cid}")
        seen_ids.add(cid)
        
        # Validate types: must be null or non-empty str
        for field_name, val in [('email', email), ('message', message), ('chat', chat)]:
            if val is not None:
                if not isinstance(val, str):
                    raise ValueError(f"{field_name} must be null or string")
                if val.strip() == '':
                    raise ValueError(f"{field_name} must be non-empty when present")
        
        # Primary channel: prefer message, then chat
        if message is not None:
            primary = "message"
            address = message
        elif chat is not None:
            primary = "chat"
            address = chat
        else:
            primary = None
            address = None
        
        result_contacts[cid] = {
            "email": email,
            "primary": primary,
            "address": address
        }
    
    return {
        "name": contract["name"],
        "result": {
            "contacts": result_contacts
        }
    }
