"""Generate final report from core manifest.

Reads outputs/core_manifest.json, computes SHA256 of the full core object,
determines attention components, and writes outputs/final_report.json.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))
    
    # SHA256 of the full core object serialized compactly
    core_bytes = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(core_bytes).hexdigest()
    
    # Determine attention components
    components = core.get('components', {})
    attention = []
    
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        needs_attention = False
        
        # result.blocked explicitly true
        if result.get('blocked') is True:
            needs_attention = True
        
        # complete/checkout/committed/ok any explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                needs_attention = True
                break
        
        # unavailable/missing/conflicts/unreachable any non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                # Non-empty check: list/dict with items, or non-empty string
                if isinstance(val, (list, dict)) and len(val) > 0:
                    needs_attention = True
                    break
                elif isinstance(val, str) and len(val) > 0:
                    needs_attention = True
                    break
        
        if needs_attention:
            attention.append(comp_name)
    
    attention.sort()
    
    report = {
        "title": "取消日程后多渠道通知",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": attention
    }
    
    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
