"""Orchestrate all components based on file contracts.

Discovers all contract.json files, determines execution order from dependencies,
runs each component's render.py, then runs integrate.py and final_report.py.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    """Load a contract JSON file."""
    return json.loads(path.read_text(encoding='utf-8'))


def topological_sort(contracts):
    """Sort contracts by dependency order (inputs that are outputs of other components)."""
    # Map output paths to contract paths
    output_to_contract = {}
    for cp in contracts:
        c = load_contract(cp)
        output_to_contract[c['output']] = cp
    
    # Build dependency graph
    deps = {}  # contract_path -> set of contract_paths it depends on
    for cp in contracts:
        c = load_contract(cp)
        deps[cp] = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                deps[cp].add(output_to_contract[inp])
    
    # Topological sort (Kahn's algorithm)
    in_degree = {cp: len(d) for cp, d in deps.items()}
    queue = [cp for cp, deg in in_degree.items() if deg == 0]
    result = []
    
    while queue:
        queue.sort()  # deterministic order
        cp = queue.pop(0)
        result.append(cp)
        for other_cp, other_deps in deps.items():
            if cp in other_deps:
                other_deps.remove(cp)
                in_degree[other_cp] -= 1
                if in_degree[other_cp] == 0:
                    queue.append(other_cp)
    
    if len(result) != len(contracts):
        raise ValueError("circular dependency detected")
    
    return result


def run_component(contract_path):
    """Run a component's render.py as a subprocess."""
    render_py = contract_path.parent / 'render.py'
    if not render_py.exists():
        raise FileNotFoundError(f"render.py not found for {contract_path}")
    
    subprocess.run(
        [sys.executable, str(render_py)],
        cwd=ROOT,
        check=True,
        timeout=60
    )


def main():
    contracts = discover_contracts()
    if not contracts:
        raise ValueError("no contracts found")
    
    ordered = topological_sort(contracts)
    
    for cp in ordered:
        run_component(cp)
    
    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            check=True,
            timeout=60
        )
    
    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            check=True,
            timeout=60
        )


if __name__ == '__main__':
    main()
