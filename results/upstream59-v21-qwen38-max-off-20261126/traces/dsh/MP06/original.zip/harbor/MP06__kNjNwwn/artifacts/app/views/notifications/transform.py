def transform(payloads, contract):
    """cancel_notifications operation.
    
    Inputs (in order): cancel_morning result envelope, channel_directory result envelope.
    
    Union attendees from target snapshots, deduplicate. Unknown contact IDs raise error.
    
    Return {outbox: [{channel, to, recipients, requires}], 
            unreachable: [id], 
            group: null or {id:"cancelled-social", members, requires}}.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    cal_envelope = payloads[0]
    chan_envelope = payloads[1]
    
    # Extract business data: when keys are exactly {name, result}, use result
    if isinstance(cal_envelope, dict) and set(cal_envelope.keys()) == {'name', 'result'}:
        cal_data = cal_envelope['result']
    else:
        cal_data = cal_envelope
    
    if isinstance(chan_envelope, dict) and set(chan_envelope.keys()) == {'name', 'result'}:
        chan_data = chan_envelope['result']
    else:
        chan_data = chan_envelope
    
    cancelled_ids = cal_data['cancelled']  # sorted list of cancelled event ids
    snapshots = cal_data['snapshots']  # dict: event_id -> event record
    contacts_dir = chan_data['contacts']  # dict: contact_id -> {email, primary, address}
    
    # Collect all unique attendees from target (cancelled) event snapshots
    attendee_set = set()
    for eid in cancelled_ids:
        ev = snapshots[eid]
        for aid in ev['attendees']:
            attendee_set.add(aid)
    
    # Validate all attendees exist in contacts directory
    for aid in sorted(attendee_set):
        if aid not in contacts_dir:
            raise ValueError(f"unknown contact id in attendees: {aid}")
    
    requires = sorted(cancelled_ids)
    
    outbox = []
    unreachable = []
    message_group_members = []
    
    for cid in sorted(attendee_set):
        cinfo = contacts_dir[cid]
        email_addr = cinfo['email']
        primary_type = cinfo['primary']  # "message", "chat", or null
        address = cinfo['address']
        
        sent_something = False
        
        # Email: each contact with email gets independent email entry
        if email_addr is not None:
            outbox.append({
                "channel": "email",
                "to": cid,
                "recipients": [cid],
                "requires": requires
            })
            sent_something = True
        
        # Primary channel handling
        if primary_type == "message":
            # Message-preferring contacts join the group
            message_group_members.append(cid)
            sent_something = True
        elif primary_type == "chat":
            # Chat fallback: individual chat message
            outbox.append({
                "channel": "chat",
                "to": cid,
                "recipients": [cid],
                "requires": requires
            })
            sent_something = True
        
        if not sent_something:
            unreachable.append(cid)
    
    # Build group if there are message-preferring members
    if message_group_members:
        message_group_members.sort()
        group = {
            "id": "cancelled-social",
            "members": message_group_members,
            "requires": requires
        }
        # Add group message to outbox
        outbox.append({
            "channel": "message_group",
            "to": "cancelled-social",
            "recipients": message_group_members,
            "requires": requires
        })
    else:
        group = None
    
    # Sort outbox by (channel, to)
    outbox.sort(key=lambda x: (x['channel'], x['to']))
    
    # Sort unreachable
    unreachable.sort()
    
    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox,
            "unreachable": unreachable,
            "group": group
        }
    }
