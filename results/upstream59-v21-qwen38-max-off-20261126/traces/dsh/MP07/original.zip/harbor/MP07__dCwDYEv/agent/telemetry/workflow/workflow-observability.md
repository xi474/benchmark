# Workflow 可观测性报告

- Trial：`MP07__dCwDYEv__env`
- Task：`MP07`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（49 节点 / 48 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：49；执行边：48（observed=0，inferred=48）
- Execution Trace Graph：`observed`；temporal_next 边 48，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_33b2ad1fef87445fa4700d63 -> tool:dsh:lead:call_3dd0f683f1bf402381b2589d -> tool:dsh:lead:call_0febdf9c57584adb92dacd57 -> tool:dsh:lead:call_468f9882149343ae85dcbc16 -> tool:dsh:lead:call_ee3284821da9432684560d01 -> tool:dsh:lead:call_b7d6b35666004a949aa796b1 -> tool:dsh:lead:call_8a25d266975948d880c88b78 -> tool:dsh:lead:call_08e406ae890a4c03b202634b -> tool:dsh:lead:call_603e7f72982947e186551814 -> tool:dsh:lead:call_c27adf919fff4296968d56ac -> tool:dsh:lead:call_858d6e7497544268b0329cbc -> tool:dsh:lead:call_2205d66bb15a400ab9b68375 -> tool:dsh:lead:call_5540672637014827bded9a7e -> tool:dsh:lead:call_9a9115ddb37a4536911af214 -> tool:dsh:lead:call_62364e9ab35e44289cf70378 -> tool:dsh:lead:call_e34025d96cdc435ab79a3e46 -> tool:dsh:lead:call_8b9d6f38ec2a4484b3be96ac -> tool:dsh:lead:call_0b920e45735f4b0b85b0b099 -> tool:dsh:lead:call_88b10f9c628d425492413e56 -> tool:dsh:lead:call_47f47ba14687450cb6f19d78 -> tool:dsh:lead:call_8ffc71faf9244a458a0fb2f2 -> tool:dsh:lead:call_687233368d4c440a8c9eb192 -> tool:dsh:lead:call_ee0aa120aa4149909990ed1b -> tool:dsh:lead:call_5345dd4cadb542bd83a733ed -> tool:dsh:lead:call_b9a68bc36fc94493a615a8f7 -> tool:dsh:lead:call_bb7c69aae859484f9a6a9275 -> tool:dsh:lead:call_51db4dcacebc490c8bd58269 -> tool:dsh:lead:call_80c9f59092dd4ecc966b230b -> tool:dsh:lead:call_5b7a1e65aafe4915b191017e -> tool:dsh:lead:call_4c32bf74dcee48ab8478c17d -> tool:dsh:lead:call_da69d64be76d4994adf21c28 -> tool:dsh:lead:call_28fd0a55140242e58324f540 -> tool:dsh:lead:call_7769727155bb4aa19f21e1eb -> tool:dsh:lead:call_dc36c53bd05b46c58049b5f8 -> tool:dsh:lead:call_4bffc525d1d145ba95aa81d9 -> tool:dsh:lead:call_f3ecaf5a261f4f44a50a5549 -> tool:dsh:lead:call_f845835f894549af8c9d1ab6 -> tool:dsh:lead:call_de3370bfa1b44d5ca9077cd7 -> tool:dsh:lead:call_931eea6b902b460a815bbbb4 -> tool:dsh:lead:call_d8a2fbbb195a48a69d2bbc82 -> tool:dsh:lead:call_a69366c50e384818b2a2226f -> tool:dsh:lead:call_290a039b5e5540ed8d006caa -> tool:dsh:lead:call_f005c98d616a4e62a2893c32 -> tool:dsh:lead:call_720a2917b2b147a2901db0d2 -> tool:dsh:lead:call_66b0c0feef9148a8bbb48f5c -> tool:dsh:lead:call_16b7dafad7bb458896c17693 -> tool:dsh:lead:call_5af281886f924e77949150ec -> tool:dsh:lead:call_efd380d43fd847769bf697b2
- 关键路径耗时：0.905
- Makespan：182.697
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
