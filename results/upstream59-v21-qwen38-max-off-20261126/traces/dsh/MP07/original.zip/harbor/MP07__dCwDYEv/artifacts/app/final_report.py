#!/usr/bin/env python3
"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    if not core_path.exists():
        raise FileNotFoundError("core_manifest.json not found")
    
    core = json.loads(core_path.read_text(encoding="utf-8"))
    
    # title
    title = "附件发送后归档与独立清理"
    
    # component_count
    components = core.get("components", {})
    component_count = len(components)
    
    # sha256 of the full core object
    core_bytes = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(core_bytes).hexdigest()
    
    # attention: component names matching certain conditions
    attention = set()
    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue
        
        # result.blocked explicitly true
        if comp_result.get("blocked") is True:
            attention.add(comp_name)
        
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in comp_result and comp_result[key] is False:
                attention.add(comp_name)
        
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = comp_result.get(key)
            if val is not None and val != [] and val != "" and val != {}:
                # Non-empty check: lists with items, non-empty strings, non-empty dicts
                if isinstance(val, (list, str, dict)) and len(val) > 0:
                    attention.add(comp_name)
    
    attention_sorted = sorted(attention)
    
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_sorted
    }
    
    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )
    print("FINAL_REPORT_DONE")


if __name__ == "__main__":
    main()
