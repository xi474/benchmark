def transform(payloads, contract):
    """archive_after_send operation.
    
    payloads[0] = original case snapshot
    payloads[1] = receipts result envelope {"name":..., "result":{...}}
    payloads[2] = cleanup result envelope {"name":..., "result":{...}}
    
    Returns {"name": contract["name"], "result": {...}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    case = payloads[0]
    receipts_envelope = payloads[1]
    cleanup_envelope = payloads[2]
    
    # Extract results from envelopes (they have name/result structure)
    if isinstance(receipts_envelope, dict) and "result" in receipts_envelope:
        receipts_result = receipts_envelope["result"]
    else:
        receipts_result = receipts_envelope
    
    if isinstance(cleanup_envelope, dict) and "result" in cleanup_envelope:
        cleanup_result = cleanup_envelope["result"]
    else:
        cleanup_result = cleanup_envelope
    
    # Get required fields from case
    if "archive_prefix" not in case:
        raise ValueError("missing archive_prefix")
    if "files" not in case:
        raise ValueError("missing files")
    
    archive_prefix = case["archive_prefix"]
    files = case["files"]
    
    # Get receipts data
    receipts_list = receipts_result.get("receipts", [])
    att_list = receipts_result.get("attachments", [])
    
    # Get cleanup data
    delete_paths = cleanup_result.get("delete", [])
    
    # Determine if blocked: blocked if NOT all ok OR no recipients
    all_ok = len(receipts_list) > 0 and all(r.get("ok", False) for r in receipts_list)
    blocked = not all_ok
    
    # Build file map for lookups
    file_map = {}
    for f in files:
        file_map[f["path"]] = f["hex"]
    
    # Process deletions - always execute
    deleted_sorted = sorted(delete_paths)
    
    # Check for overlaps between cleanup sources and move sources
    # Move sources are attachment paths
    att_paths = set(a["path"] for a in att_list)
    delete_set = set(delete_paths)
    
    # Overlap between cleanup delete sources and move sources is ValueError
    if att_paths & delete_set:
        raise ValueError("cleanup and move sources overlap")
    
    # Compute moves
    moves = []
    if not blocked:
        # Move each attachment to archive_prefix/<original_path>
        seen_targets = set()
        for att in att_list:
            src = att["path"]
            dst = archive_prefix + "/" + src
            
            # Check duplicate target
            if dst in seen_targets:
                raise ValueError(f"duplicate move target: {dst}")
            seen_targets.add(dst)
            
            # Target must not already exist in original files
            if dst in file_map:
                raise ValueError(f"move target already exists: {dst}")
            
            moves.append({"from": src, "to": dst})
        
        # Sort moves by from
        moves.sort(key=lambda m: m["from"])
    
    # Build final files list
    # Start with original files
    # Remove deleted files
    # For moved files: remove original path, add new path with same hex
    final_files = {}
    for f in files:
        final_files[f["path"]] = f["hex"]
    
    # Apply deletions
    for dp in delete_paths:
        if dp in final_files:
            del final_files[dp]
    
    # Apply moves (only if not blocked)
    if not blocked:
        for m in moves:
            src = m["from"]
            dst = m["to"]
            if src in final_files:
                hex_val = final_files[src]
                del final_files[src]
                final_files[dst] = hex_val
    
    # Build sorted files list
    files_result = [{"path": p, "hex": h} for p, h in sorted(final_files.items())]
    
    result = {
        "blocked": blocked,
        "deleted": deleted_sorted,
        "files": files_result,
        "moves": moves
    }
    
    return {"name": contract["name"], "result": result}
