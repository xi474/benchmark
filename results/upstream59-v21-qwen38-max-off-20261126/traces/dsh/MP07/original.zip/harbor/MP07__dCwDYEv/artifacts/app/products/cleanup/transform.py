def transform(payloads, contract):
    """independent_cleanup operation.
    
    payloads[0] = case input with files, cleanup_prefix, etc.
    Returns {"name": contract["name"], "result": {"delete": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    case = payloads[0]
    
    if "files" not in case:
        raise ValueError("missing required field: files")
    if "cleanup_prefix" not in case:
        raise ValueError("missing required field: cleanup_prefix")
    
    files = case["files"]
    cleanup_prefix = case["cleanup_prefix"]
    
    # cleanup_prefix must be a safe directory name without trailing slash
    if not isinstance(cleanup_prefix, str) or not cleanup_prefix:
        raise ValueError("invalid cleanup_prefix")
    
    # Select files under cleanup_prefix that end with .tmp
    # Must match by path segment boundary: home/tmp should not match home/tmp-old
    # A file is "under" cleanup_prefix if its path starts with cleanup_prefix + "/"
    delete_list = []
    prefix_with_sep = cleanup_prefix + "/"
    
    for f in files:
        if "path" not in f:
            raise ValueError("file entry missing path")
        fpath = f["path"]
        
        # Check if file is under the cleanup_prefix directory
        if fpath.startswith(prefix_with_sep) and fpath.endswith(".tmp"):
            delete_list.append(fpath)
    
    # Sort the delete list
    delete_list.sort()
    
    result = {
        "delete": delete_list
    }
    
    return {"name": contract["name"], "result": result}
