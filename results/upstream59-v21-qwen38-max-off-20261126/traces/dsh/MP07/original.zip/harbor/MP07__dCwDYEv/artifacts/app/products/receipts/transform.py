import hashlib


def transform(payloads, contract):
    """attachment_receipts operation.
    
    payloads[0] = case input with files, attachments, recipients, send_ok, etc.
    Returns {"name": contract["name"], "result": {...}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    case = payloads[0]
    
    # Validate required fields
    for field in ("files", "attachments", "recipients", "send_ok"):
        if field not in case:
            raise ValueError(f"missing required field: {field}")
    
    files = case["files"]
    attachments = case["attachments"]
    recipients = case["recipients"]
    send_ok = case["send_ok"]
    
    # Build file lookup: path -> hex
    file_map = {}
    for f in files:
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path or hex")
        file_map[f["path"]] = f["hex"]
    
    # Deduplicate and sort attachments
    unique_attachments = sorted(set(attachments))
    
    # Each attachment must exist in files
    for att in unique_attachments:
        if att not in file_map:
            raise ValueError(f"attachment not found in files: {att}")
    
    # Compute sha256 for each attachment from its hex bytes
    att_results = []
    for att_path in unique_attachments:
        hex_str = file_map[att_path]
        raw_bytes = bytes.fromhex(hex_str)
        sha = hashlib.sha256(raw_bytes).hexdigest()
        att_results.append({"path": att_path, "sha256": sha})
    
    # Validate recipients are unique and non-empty
    if len(recipients) != len(set(recipients)):
        raise ValueError("duplicate recipients")
    for r in recipients:
        if not isinstance(r, str) or not r.strip():
            raise ValueError("invalid recipient")
    
    # Validate send_ok keys match recipients
    for r in recipients:
        if r not in send_ok:
            raise ValueError(f"missing send_ok for recipient: {r}")
        if not isinstance(send_ok[r], bool):
            raise ValueError(f"send_ok value must be bool for: {r}")
    
    # Build receipts sorted by recipient id
    receipt_list = []
    for r in sorted(recipients):
        receipt_list.append({"recipient": r, "ok": send_ok[r]})
    
    result = {
        "attachments": att_results,
        "receipts": receipt_list
    }
    
    return {"name": contract["name"], "result": result}
