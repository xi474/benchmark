#!/usr/bin/env python3
"""Run all components in dependency order, then integrate."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_component(component_dir):
    """Run a component's render.py to generate its output."""
    render_script = component_dir / "render.py"
    if not render_script.exists():
        print(f"ERROR: {render_script} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run(
        [sys.executable, str(render_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"ERROR running {render_script}:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    print(f"OK: {component_dir.name}")


def main():
    # Ensure outputs directory exists
    (ROOT / "outputs").mkdir(parents=True, exist_ok=True)

    # Phase 1: receipts and cleanup (independent, both depend only on inputs/case.json)
    run_component(ROOT / "products" / "receipts")
    run_component(ROOT / "products" / "cleanup")

    # Phase 2: archive (depends on receipts and cleanup outputs)
    run_component(ROOT / "products" / "archive")

    # Phase 3: integrate all component outputs into core_manifest.json
    integrate_script = ROOT / "integrate.py"
    if not integrate_script.exists():
        print("ERROR: integrate.py not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run(
        [sys.executable, str(integrate_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print("ERROR running integrate.py:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    print("OK: integrate")

    # Phase 4: final report
    final_report_script = ROOT / "final_report.py"
    if not final_report_script.exists():
        print("ERROR: final_report.py not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run(
        [sys.executable, str(final_report_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print("ERROR running final_report.py:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    print("OK: final_report")

    print("ALL_COMPONENTS_DONE")


if __name__ == "__main__":
    main()
