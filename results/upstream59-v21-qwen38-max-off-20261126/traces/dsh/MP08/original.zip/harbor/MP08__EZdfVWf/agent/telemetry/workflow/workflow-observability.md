# Workflow 可观测性报告

- Trial：`MP08__EZdfVWf__env`
- Task：`MP08`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（49 节点 / 48 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：49；执行边：48（observed=0，inferred=48）
- Execution Trace Graph：`observed`；temporal_next 边 48，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_3c80044483de4a039eb5ebb4 -> tool:dsh:lead:call_0ce1d3ec908c4d7fbb0e0d25 -> tool:dsh:lead:call_aa98c7a61e6145ec95f7cdd8 -> tool:dsh:lead:call_b3fae60a1dda4013867f3ae9 -> tool:dsh:lead:call_0a237dc01a864549a390c87d -> tool:dsh:lead:call_81e8ed0333da43bb853a7a8b -> tool:dsh:lead:call_fcd4085cc07e4b46931f8ddf -> tool:dsh:lead:call_12802a9907e3417ab77ec8a3 -> tool:dsh:lead:call_cad989e99919426baa0a2185 -> tool:dsh:lead:call_7a654410fc4c4bfbb0af47b9 -> tool:dsh:lead:call_27b6fe415f964745aa00f1f5 -> tool:dsh:lead:call_061352c7e7ad41d9818c62c3 -> tool:dsh:lead:call_4f3e15b93caa4a7492ac4ac4 -> tool:dsh:lead:call_cae815f33c5c4bd68dd473a8 -> tool:dsh:lead:call_64f6d555355847f7b0c0d735 -> tool:dsh:lead:call_5fd1a44b450e44efaf4b4a73 -> tool:dsh:lead:call_a57a6af4d6bf404cbff5123f -> tool:dsh:lead:call_bdc7db571400496ea6386eb6 -> tool:dsh:lead:call_394cd383119b4afb81cecb9e -> tool:dsh:lead:call_23e1d45c91bb482c8d8a988b -> tool:dsh:lead:call_0485bf5480474499a8731e07 -> tool:dsh:lead:call_651ea67d627a401e9aa8318a -> tool:dsh:lead:call_4280f96242be40108f035cf1 -> tool:dsh:lead:call_75fc2c37d1504741990c5224 -> tool:dsh:lead:call_3d747992f9a0460192ed0dbe -> tool:dsh:lead:call_5d0f3eca2c8942edb93d8f63 -> tool:dsh:lead:call_f842426dfa714672b5abfde0 -> tool:dsh:lead:call_238cdcbf6bb448acae42d8c8 -> tool:dsh:lead:call_502fdac322aa418393ec28db -> tool:dsh:lead:call_ba4a96eb9f0b4aadb4a675f6 -> tool:dsh:lead:call_359eebd6564f4a628572a6ae -> tool:dsh:lead:call_543fe05d331c458faf83c4dd -> tool:dsh:lead:call_b939a86a0c374d72931bab11 -> tool:dsh:lead:call_762e401735ca42198c9c58a5 -> tool:dsh:lead:call_b03489067be74004932327e5 -> tool:dsh:lead:call_020e35e4733f453ea1d10fc1 -> tool:dsh:lead:call_9c9bfcdce18949849430b084 -> tool:dsh:lead:call_a2d3596a6e604c188ebd4a7d -> tool:dsh:lead:call_e28c79bc7a784cd983416d93 -> tool:dsh:lead:call_cb1b0b7d755740758623e102 -> tool:dsh:lead:call_5c2195e5c3a84af9bf2d646d -> tool:dsh:lead:call_31ac5a7ee53549f9a24f89d7 -> tool:dsh:lead:call_1c0fac04e2c04b0898375206 -> tool:dsh:lead:call_69ab6dcb94b1481798cab638 -> tool:dsh:lead:call_c47a234dc5df4280b9ce295b -> tool:dsh:lead:call_d18a5ca0d5824e439fb7112f -> tool:dsh:lead:call_e8b97ded7b5743b7969f0a92 -> tool:dsh:lead:call_02c315fd294f47ccaa80a28a
- 关键路径耗时：1.306
- Makespan：177.934
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
