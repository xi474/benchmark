#!/usr/bin/env python3
"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _needs_attention(result):
    """Check if a component result needs attention."""
    if not isinstance(result, dict):
        return False

    # result.blocked explicitly true
    if result.get("blocked") is True:
        return True

    # complete/checkout/committed/ok explicitly false
    for key in ("complete", "checkout", "committed", "ok"):
        val = result.get(key)
        if val is False:
            return True

    # unavailable/missing/conflicts/unreachable non-empty
    for key in ("unavailable", "missing", "conflicts", "unreachable"):
        val = result.get(key)
        if val is not None and val != [] and val != "" and val != {} and val != 0 and val is not False:
            # Non-empty check: lists/dicts/strings that are non-empty
            if isinstance(val, (list, dict, str)) and len(val) > 0:
                return True
            # For other types, if present and not None/empty, consider non-empty
            if not isinstance(val, (list, dict, str, type(None))) and val:
                return True

    return False


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core["components"]
    component_count = len(components)

    # SHA256 of compact JSON serialization of entire core object
    core_bytes = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(core_bytes).hexdigest()

    # Attention list
    attention = sorted([name for name, result in components.items() if _needs_attention(result)])

    report = {
        "title": "节日照片迁移后发送与缺失报告",
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
