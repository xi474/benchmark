import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_output(root, contract_path):
    """CLI entry: compute and write output to contract.output."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    result = build_component(root, contract_path)
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    # Determine root and contract path
    # When run as `python3 products/classify/render.py`, cwd is workspace root
    # contract.json is in the same directory as render.py
    script_dir = Path(__file__).resolve().parent
    contract_path = script_dir / "contract.json"
    # root is the workspace root (parent of products/)
    root = script_dir.parents[1]
    _write_output(root, contract_path)
