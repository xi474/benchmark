def _extract_business(payload):
    """If payload is {name, result} exactly, return result; else return payload as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = _extract_business(payloads[0])

    # Validate required fields
    for field in ("files", "photos", "festivals", "destination", "recipient"):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    files = case["files"]
    photos = case["photos"]
    festivals = case["festivals"]
    destination = case["destination"]
    recipient = case["recipient"]

    # Validate types
    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(photos, list):
        raise ValueError("photos must be list")
    if not isinstance(festivals, list):
        raise ValueError("festivals must be list")
    if not isinstance(destination, str) or not destination.strip():
        raise ValueError("destination must be non-empty string")
    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be non-empty string")

    # Validate festivals are unique non-empty strings
    seen_festivals = set()
    for f in festivals:
        if not isinstance(f, str) or not f.strip():
            raise ValueError("festival must be non-empty string")
        if f in seen_festivals:
            raise ValueError(f"duplicate festival: {f}")
        seen_festivals.add(f)

    # Validate files
    file_paths = set()
    for fi in files:
        if not isinstance(fi, dict):
            raise ValueError("file entry must be object")
        if "path" not in fi or "hex" not in fi:
            raise ValueError("file entry missing path or hex")
        if not isinstance(fi["path"], str):
            raise ValueError("file path must be string")
        if not isinstance(fi["hex"], str):
            raise ValueError("file hex must be string")
        file_paths.add(fi["path"])

    # Validate photos
    photo_paths = set()
    for ph in photos:
        if not isinstance(ph, dict):
            raise ValueError("photo entry must be object")
        if "path" not in ph or "festival" not in ph:
            raise ValueError("photo entry missing path or festival")
        if not isinstance(ph["path"], str):
            raise ValueError("photo path must be string")
        if not isinstance(ph["festival"], str) or not ph["festival"].strip():
            raise ValueError("photo festival must be non-empty string")
        if ph["path"] in photo_paths:
            raise ValueError(f"duplicate photo path: {ph['path']}")
        photo_paths.add(ph["path"])
        if ph["path"] not in file_paths:
            raise ValueError(f"photo path not in files: {ph['path']}")

    # Select photos whose festival is in festivals list
    festival_set = set(festivals)
    selected = []
    for ph in photos:
        if ph["festival"] in festival_set:
            selected.append({"path": ph["path"], "festival": ph["festival"]})

    # Sort by (festival, path)
    selected.sort(key=lambda x: (x["festival"], x["path"]))

    # Find missing festivals (those with no selected photos)
    used_festivals = {s["festival"] for s in selected}
    missing = sorted([f for f in festivals if f not in used_festivals])

    result = {"selected": selected, "missing": missing}
    return {"name": contract["name"], "result": result}
