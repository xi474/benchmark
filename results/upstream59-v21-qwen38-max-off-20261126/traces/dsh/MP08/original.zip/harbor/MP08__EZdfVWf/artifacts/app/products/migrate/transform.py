def _extract_business(payload):
    """If payload is {name, result} exactly, return result; else return payload as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = _extract_business(payloads[0])
    classify_result = _extract_business(payloads[1])

    # Validate required fields in case
    for field in ("files", "destination"):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    files = case["files"]
    destination = case["destination"]
    selected = classify_result["selected"]

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(destination, str):
        raise ValueError("destination must be string")
    if not isinstance(selected, list):
        raise ValueError("selected must be list")

    # Build file map: path -> hex
    file_map = {}
    for fi in files:
        file_map[fi["path"]] = fi["hex"]

    # Build moves
    moves = []
    moved_paths = set()
    for sel in selected:
        src = sel["path"]
        dst = destination + "/" + src  # preserve sub-path
        if dst in moved_paths:
            raise ValueError(f"duplicate target path: {dst}")
        moves.append({"from": src, "to": dst, "festival": sel["festival"]})
        moved_paths.add(dst)

    # Sort moves by (from, to)
    moves.sort(key=lambda x: (x["from"], x["to"]))

    # Build files list - all original files with their hex, sorted by path
    result_files = [{"path": fi["path"], "hex": fi["hex"]} for fi in files]
    result_files.sort(key=lambda x: x["path"])

    result = {"moves": moves, "files": result_files}
    return {"name": contract["name"], "result": result}
