def _extract_business(payload):
    """If payload is {name, result} exactly, return result; else return payload as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = _extract_business(payloads[0])
    classify_result = _extract_business(payloads[1])
    migrate_result = _extract_business(payloads[2])

    # Validate required fields
    if "recipient" not in case:
        raise ValueError("missing field: recipient")

    recipient = case["recipient"]
    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be non-empty string")

    missing = classify_result.get("missing", [])
    moves = migrate_result.get("moves", [])

    if not isinstance(missing, list):
        raise ValueError("missing must be list")
    if not isinstance(moves, list):
        raise ValueError("moves must be list")

    # Attachments are the migrated (to) paths, sorted
    attachments = sorted([m["to"] for m in moves])

    # Message
    if not missing:
        message = "Photos ready"
    else:
        message = "Missing: " + ", ".join(missing)

    result = {
        "to": recipient,
        "attachments": attachments,
        "missing": missing,
        "message": message,
    }
    return {"name": contract["name"], "result": result}
