#!/usr/bin/env python3
"""Orchestrate all components in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs
    # Each contract's inputs may reference other contract outputs
    contract_map = {}  # name -> contract_path
    output_to_contract = {}  # output_rel -> contract_name
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = cp
        output_to_contract[c["output"]] = c["name"]

    # Build adjacency: for each contract, find which other contracts it depends on
    deps = {}  # name -> set of dependency names
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        dep_names = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep_names.add(output_to_contract[inp])
        deps[c["name"]] = dep_names

    # Topological sort
    ordered = []
    visited = set()
    temp = set()

    def visit(name):
        if name in temp:
            print(f"Cycle detected involving {name}", file=sys.stderr)
            sys.exit(1)
        if name in visited:
            return
        temp.add(name)
        for dep in sorted(deps.get(name, set())):
            visit(dep)
        temp.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Execute each component in order
    for name in ordered:
        cp = contract_map[name]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            print(f"Missing render.py for {name}: {render_py}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Integration failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report
    final_report = ROOT / "final_report.py"
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Final report failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == "__main__":
    main()
