# Workflow 可观测性报告

- Trial：`MP09__MPXTRxk__env`
- Task：`MP09`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（66 节点 / 65 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：66；执行边：65（observed=0，inferred=65）
- Execution Trace Graph：`observed`；temporal_next 边 65，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_fdf45430b93047bf9c4694dc -> tool:dsh:lead:call_daf0adece81a470eac146ba3 -> tool:dsh:lead:call_092aaad585fc462ea48c7b1b -> tool:dsh:lead:call_44b169c43a1d4fedbbf8c067 -> tool:dsh:lead:call_8b0e55d01f3b4f6bb5480e0d -> tool:dsh:lead:call_86ed30fb775642b6b7ec5aa1 -> tool:dsh:lead:call_5ed9da899e28453da8550485 -> tool:dsh:lead:call_620341ecb59a494a9c532f63 -> tool:dsh:lead:call_5f186d3ed3034d6ea5d5755c -> tool:dsh:lead:call_b22a37b095a9400297bc24ec -> tool:dsh:lead:call_abfe75e429484daa87c2a876 -> tool:dsh:lead:call_e3057ddac05a4b32bc8c022a -> tool:dsh:lead:call_e829d8391cf74d50b0ebc11b -> tool:dsh:lead:call_71425445d6ce46208faaef86 -> tool:dsh:lead:call_aaf010c366c34263889326db -> tool:dsh:lead:call_617d52ee32ab4683934d4364 -> tool:dsh:lead:call_a0793cd4a3344287aeda9d46 -> tool:dsh:lead:call_814ebfa9935b485b979d1697 -> tool:dsh:lead:call_e85e6ea4303a4f69b60fa6d6 -> tool:dsh:lead:call_a95eed745d3b46c4b44d8b57 -> tool:dsh:lead:call_3bf87d03d7a94e90ac360c83 -> tool:dsh:lead:call_90b0316adfcf4f35bb5337d1 -> tool:dsh:lead:call_602fefdb381c423da315e8e6 -> tool:dsh:lead:call_b576296b76ba40b8bda99c24 -> tool:dsh:lead:call_84a593a85dbb4972a638142e -> tool:dsh:lead:call_ffff95b1ca3f450e91ec362d -> tool:dsh:lead:call_531e881e87c34bca8b7f3f81 -> tool:dsh:lead:call_41d0694380b54373b7401909 -> tool:dsh:lead:call_24aa089ae4ec4b9e8876cd22 -> tool:dsh:lead:call_87e91061e2e846239d4ea1f5 -> tool:dsh:lead:call_0be70b27b4bd433ab0e30241 -> tool:dsh:lead:call_b1ca5c31d3e9430e857ba201 -> tool:dsh:lead:call_b7473a224c144a128c9df81a -> tool:dsh:lead:call_de6ba6cc70914ca2b0d5efc7 -> tool:dsh:lead:call_8526cfdf07c64dd7bc0cc0bd -> tool:dsh:lead:call_5b17a7ada2cd4e739120f855 -> tool:dsh:lead:call_c503124b0a8f4a20a69d4a7e -> tool:dsh:lead:call_80e12ad4a9124a3c8c7a961e -> tool:dsh:lead:call_2a066ab530dc46198b37484f -> tool:dsh:lead:call_52e6045ea72948bdad6db5e6 -> tool:dsh:lead:call_84954bac498a4ba29d2936f2 -> tool:dsh:lead:call_7766e57cf866413fbf512e69 -> tool:dsh:lead:call_226c52aaedeb4eebb87677f5 -> tool:dsh:lead:call_83c6b27a158e490bbc8bda1f -> tool:dsh:lead:call_bcf39105008348afafa9f4f0 -> tool:dsh:lead:call_edd8f7951938445aa1f3fb22 -> tool:dsh:lead:call_15bb3cd33a5a4466b2490d58 -> tool:dsh:lead:call_e97725a3c86d446d97303ef4 -> tool:dsh:lead:call_c201e5e3f9364c8b8753ae25 -> tool:dsh:lead:call_ea3ae0294ce346f896faef8b -> tool:dsh:lead:call_3684c4d219764132836000f3 -> tool:dsh:lead:call_99cfdf80636e4b43895de7c8 -> tool:dsh:lead:call_35944cc235d44d97a1dede97 -> tool:dsh:lead:call_94fcabe9ab814395a81558e5 -> tool:dsh:lead:call_f8f7be40df294f688ee1fe7f -> tool:dsh:lead:call_147ab7fd173d427b8dc2aa6d -> tool:dsh:lead:call_19017b34929f4bbba03d7c7e -> tool:dsh:lead:call_28a6160d95b5495db305982e -> tool:dsh:lead:call_018f556657d942c589c582d2 -> tool:dsh:lead:call_c7c63858d1ff435087501285 -> tool:dsh:lead:call_ef20b172764c4d08a11526f0 -> tool:dsh:lead:call_aafed5912555429996473e14 -> tool:dsh:lead:call_26d49cb5a78849e0851c0dcb -> tool:dsh:lead:call_41e88dc56e254230850fc0f2 -> tool:dsh:lead:call_74a63a3e86fc49b6b6273b92
- 关键路径耗时：1.808
- Makespan：245.316
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
