def transform(payloads, contract):
    """panel_slots: select earliest two available time slots."""
    if len(payloads) != 1:
        raise ValueError("calendar expects exactly 1 input payload")

    case = payloads[0]

    # Validate required fields
    for field in ('now', 'windows', 'busy', 'duration', 'gap'):
        if field not in case:
            raise ValueError(f"missing required field: {field}")

    now = case['now']
    windows = case['windows']
    busy = case['busy']
    duration = case['duration']
    gap = case['gap']

    if not isinstance(now, int) or isinstance(now, bool):
        raise ValueError("now must be int")
    if not isinstance(duration, int) or isinstance(duration, bool) or duration < 1:
        raise ValueError("duration must be int >= 1")
    if not isinstance(gap, int) or isinstance(gap, bool) or gap < 0:
        raise ValueError("gap must be int >= 0")
    if not isinstance(windows, list):
        raise ValueError("windows must be list")
    if not isinstance(busy, list):
        raise ValueError("busy must be list")

    # Validate windows
    for w in windows:
        if not isinstance(w, dict):
            raise ValueError("window must be object")
        for f in ('id', 'start', 'end'):
            if f not in w:
                raise ValueError(f"window missing field: {f}")
        if not isinstance(w['start'], int) or isinstance(w['start'], bool):
            raise ValueError("window start must be int")
        if not isinstance(w['end'], int) or isinstance(w['end'], bool):
            raise ValueError("window end must be int")
        if w['end'] <= w['start']:
            raise ValueError("window end must be > start")

    # Validate busy
    for b in busy:
        if not isinstance(b, dict):
            raise ValueError("busy must be object")
        for f in ('id', 'start', 'end'):
            if f not in b:
                raise ValueError(f"busy missing field: {f}")
        if not isinstance(b['start'], int) or isinstance(b['start'], bool):
            raise ValueError("busy start must be int")
        if not isinstance(b['end'], int) or isinstance(b['end'], bool):
            raise ValueError("busy end must be int")
        if b['end'] <= b['start']:
            raise ValueError("busy end must be > start")

    # Build free intervals from windows union minus busy minus before-now
    # First, merge overlapping windows
    sorted_windows = sorted(windows, key=lambda w: (w['start'], w['end']))
    merged = []
    for w in sorted_windows:
        s, e = w['start'], w['end']
        # Clip to now
        s = max(s, now)
        if s >= e:
            continue
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    # Subtract busy intervals
    sorted_busy = sorted(busy, key=lambda b: (b['start'], b['end']))
    free = []
    for interval in merged:
        fs, fe = interval
        cuts = []
        for b in sorted_busy:
            bs, be = b['start'], b['end']
            if be <= fs or bs >= fe:
                continue
            cuts.append((max(bs, fs), min(be, fe)))
        # Sort cuts and subtract
        cuts.sort()
        cur = fs
        for cs, ce in cuts:
            if cs > cur:
                free.append((cur, cs))
            cur = max(cur, ce)
        if cur < fe:
            free.append((cur, fe))

    # Merge adjacent free intervals (windows touching at boundary are continuous)
    merged_free = []
    for interval in free:
        if merged_free and interval[0] <= merged_free[-1][1]:
            merged_free[-1] = (merged_free[-1][0], max(merged_free[-1][1], interval[1]))
        else:
            merged_free.append(interval)
    free = merged_free

    # Greedy: find earliest slot that fits duration
    slots = []
    for fs, fe in free:
        if fe - fs >= duration:
            slots.append({'start': fs, 'end': fs + duration})
            break

    # Find second slot: start >= first_end + gap
    if len(slots) == 1:
        min_start = slots[0]['end'] + gap
        for fs, fe in free:
            candidate_start = max(fs, min_start)
            if fe - candidate_start >= duration:
                slots.append({'start': candidate_start, 'end': candidate_start + duration})
                break

    complete = len(slots) == 2

    return {
        "name": contract["name"],
        "result": {
            "slots": slots,
            "complete": complete
        }
    }
