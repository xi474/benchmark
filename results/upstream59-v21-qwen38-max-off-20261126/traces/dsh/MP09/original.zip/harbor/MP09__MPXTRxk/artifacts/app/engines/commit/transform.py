def transform(payloads, contract):
    """panel_commit: combine slots, invitees, supplies into events + notification + purchase."""
    if len(payloads) != 3:
        raise ValueError("commit expects exactly 3 input payloads")

    # Inputs are the result envelopes from upstream components
    # Each payload is {"name": ..., "result": ...}
    calendar_result = payloads[0]
    invitees_result = payloads[1]
    supplies_result = payloads[2]

    # Extract business results (handle both envelope and raw formats)
    if isinstance(calendar_result, dict) and 'result' in calendar_result:
        cal = calendar_result['result']
    else:
        cal = calendar_result

    if isinstance(invitees_result, dict) and 'result' in invitees_result:
        inv = invitees_result['result']
    else:
        inv = invitees_result

    if isinstance(supplies_result, dict) and 'result' in supplies_result:
        sup = supplies_result['result']
    else:
        sup = supplies_result

    # Validate calendar result
    if not isinstance(cal, dict):
        raise ValueError("calendar result must be object")
    if 'slots' not in cal or 'complete' not in cal:
        raise ValueError("calendar result missing slots or complete")

    slots = cal['slots']
    complete = cal['complete']

    if not isinstance(complete, bool):
        raise ValueError("complete must be bool")
    if not isinstance(slots, list):
        raise ValueError("slots must be list")

    # Validate invitees result
    if not isinstance(inv, dict):
        raise ValueError("invitees result must be object")
    if 'members' not in inv or 'group_id' not in inv:
        raise ValueError("invitees result missing members or group_id")

    members = inv['members']
    group_id = inv['group_id']

    if not isinstance(members, list):
        raise ValueError("members must be list")
    if not isinstance(group_id, str):
        raise ValueError("group_id must be string")

    # Build events and notification
    events = []
    notification = None

    if complete and len(slots) == 2:
        for i, slot in enumerate(slots):
            event_id = f"{group_id}-{i + 1}"
            events.append({
                "id": event_id,
                "start": slot['start'],
                "end": slot['end'],
                "members": members
            })

        event_ids = [e['id'] for e in events]
        notification = {
            "group_id": group_id,
            "members": members,
            "event_ids": event_ids
        }

    return {
        "name": contract["name"],
        "result": {
            "events": events,
            "notification": notification,
            "purchase": sup
        }
    }
