def transform(payloads, contract):
    """panel_invitees: merge group members, exclude, return sorted list."""
    if len(payloads) != 1:
        raise ValueError("invitees expects exactly 1 input payload")

    case = payloads[0]

    # Validate required fields
    for field in ('groups', 'invite_groups', 'exclude', 'namespace'):
        if field not in case:
            raise ValueError(f"missing required field: {field}")

    groups = case['groups']
    invite_groups = case['invite_groups']
    exclude = case['exclude']
    namespace = case['namespace']

    if not isinstance(groups, list):
        raise ValueError("groups must be list")
    if not isinstance(invite_groups, list):
        raise ValueError("invite_groups must be list")
    if not isinstance(exclude, list):
        raise ValueError("exclude must be list")
    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be non-empty string")

    # Build group lookup
    group_map = {}
    for g in groups:
        if not isinstance(g, dict):
            raise ValueError("group must be object")
        if 'id' not in g or 'members' not in g:
            raise ValueError("group missing id or members")
        gid = g['id']
        members = g['members']
        if not isinstance(members, list) or len(members) == 0:
            raise ValueError("members must be non-empty list")
        for m in members:
            if not isinstance(m, str):
                raise ValueError("member id must be string")
        group_map[gid] = members

    # Validate invite_groups references exist
    for gid in invite_groups:
        if gid not in group_map:
            raise ValueError(f"unknown group: {gid}")

    # Union of members from invited groups, minus exclude
    member_set = set()
    for gid in invite_groups:
        for m in group_map[gid]:
            member_set.add(m)

    exclude_set = set(exclude)
    result_members = sorted(member_set - exclude_set)

    group_id = namespace + "-panel"

    return {
        "name": contract["name"],
        "result": {
            "members": result_members,
            "group_id": group_id
        }
    }
