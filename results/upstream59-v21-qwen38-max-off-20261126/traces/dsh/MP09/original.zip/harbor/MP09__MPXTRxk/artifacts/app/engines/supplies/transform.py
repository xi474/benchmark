def transform(payloads, contract):
    """supply_selection: select best product per category by rating desc, price asc, id asc."""
    if len(payloads) != 1:
        raise ValueError("supplies expects exactly 1 input payload")

    case = payloads[0]

    for field in ('products', 'requirements'):
        if field not in case:
            raise ValueError(f"missing required field: {field}")

    products = case['products']
    requirements = case['requirements']

    if not isinstance(products, list):
        raise ValueError("products must be list")
    if not isinstance(requirements, list):
        raise ValueError("requirements must be list")

    # Validate products
    for p in products:
        if not isinstance(p, dict):
            raise ValueError("product must be object")
        for f in ('id', 'category', 'stock', 'price_cents', 'rating'):
            if f not in p:
                raise ValueError(f"product missing field: {f}")
        if not isinstance(p['id'], str):
            raise ValueError("product id must be string")
        if not isinstance(p['category'], str):
            raise ValueError("product category must be string")
        if not isinstance(p['stock'], int) or isinstance(p['stock'], bool) or p['stock'] < 0:
            raise ValueError("stock must be int >= 0")
        if not isinstance(p['price_cents'], int) or isinstance(p['price_cents'], bool) or p['price_cents'] < 0:
            raise ValueError("price_cents must be int >= 0")
        if not isinstance(p['rating'], int) or isinstance(p['rating'], bool) or p['rating'] < 0:
            raise ValueError("rating must be int >= 0")

    # Validate requirements
    seen_categories = set()
    for r in requirements:
        if not isinstance(r, dict):
            raise ValueError("requirement must be object")
        for f in ('category', 'quantity'):
            if f not in r:
                raise ValueError(f"requirement missing field: {f}")
        if not isinstance(r['category'], str):
            raise ValueError("requirement category must be string")
        if not isinstance(r['quantity'], int) or isinstance(r['quantity'], bool) or r['quantity'] < 1:
            raise ValueError("quantity must be int >= 1")
        if r['category'] in seen_categories:
            raise ValueError(f"duplicate category in requirements: {r['category']}")
        seen_categories.add(r['category'])

    # Group products by category
    by_category = {}
    for p in products:
        cat = p['category']
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(p)

    items = []
    unavailable = []

    for req in requirements:
        cat = req['category']
        qty = req['quantity']

        if cat not in by_category:
            unavailable.append(cat)
            continue

        # Filter products with sufficient stock
        candidates = [p for p in by_category[cat] if p['stock'] >= qty]

        if not candidates:
            unavailable.append(cat)
            continue

        # Select best: rating max, then price_cents min, then id min
        best = min(candidates, key=lambda p: (-p['rating'], p['price_cents'], p['id']))

        items.append({
            "category": cat,
            "id": best['id'],
            "quantity": qty,
            "total_cents": best['price_cents'] * qty
        })

    # Sort items by category
    items.sort(key=lambda x: x['category'])
    unavailable.sort()

    return {
        "name": contract["name"],
        "result": {
            "items": items,
            "unavailable": unavailable
        }
    }
