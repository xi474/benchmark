"""Orchestrate all component renders in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph from contract inputs
    # A component depends on another if its input path matches another component's output
    contract_map = {}  # name -> {contract_path, contract_data}
    output_to_name = {}  # output_path -> component_name

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        contract_map[name] = {'path': cp, 'data': c}
        output_to_name[c['output']] = name

    # Build adjacency: component -> set of dependencies
    deps = {}
    for name, info in contract_map.items():
        d = set()
        for inp in info['data']['inputs']:
            if inp in output_to_name:
                d.add(output_to_name[inp])
        deps[name] = d

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        if name in visited:
            return
        visiting.add(name)
        for dep in sorted(deps.get(name, set())):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Execute each component's render.py
    for name in ordered:
        cp = contract_map[name]['path']
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {name}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
