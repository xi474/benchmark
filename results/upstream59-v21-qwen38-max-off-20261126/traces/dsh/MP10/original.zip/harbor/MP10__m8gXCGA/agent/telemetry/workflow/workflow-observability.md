# Workflow 可观测性报告

- Trial：`MP10__m8gXCGA__env`
- Task：`MP10`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（58 节点 / 57 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：58；执行边：57（observed=0，inferred=57）
- Execution Trace Graph：`observed`；temporal_next 边 57，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_220ce31f0e6245c2ad0a2932 -> tool:dsh:lead:call_11ee8541660b44d4bf3bd482 -> tool:dsh:lead:call_301225935c634ecbb5d45c9a -> tool:dsh:lead:call_74a7bec61bed47e4955f68fd -> tool:dsh:lead:call_1abb7f52df7449cc85500977 -> tool:dsh:lead:call_377dafcf4ae74b2d875c7a69 -> tool:dsh:lead:call_9ea8d5035f5d4192a5e954af -> tool:dsh:lead:call_a3c2358c52b0409f99b5b7a9 -> tool:dsh:lead:call_21383e959a524d43b51fcbad -> tool:dsh:lead:call_3b36c89ff1b5443a87378fde -> tool:dsh:lead:call_2ca16c09b92a4e72bfadf966 -> tool:dsh:lead:call_2805c0c06fa14fef84793ace -> tool:dsh:lead:call_9f4de8424813438f8764f668 -> tool:dsh:lead:call_7042a841dc3442659bfad203 -> tool:dsh:lead:call_d638cb82ed7c4936899f9f73 -> tool:dsh:lead:call_10804f018d1a407dbc47c120 -> tool:dsh:lead:call_ef1807b974c84fd787465cea -> tool:dsh:lead:call_9fa497869a8a4841a616a671 -> tool:dsh:lead:call_0969268dc8e648b58b6da3f9 -> tool:dsh:lead:call_ef137a06ed0b4351a3540129 -> tool:dsh:lead:call_4559205e3620448e9b02d707 -> tool:dsh:lead:call_1b92a20f80f94ffa9d0e8df9 -> tool:dsh:lead:call_953d813955534bf7a294007e -> tool:dsh:lead:call_ba09f1a1ccad47aaaa6eb565 -> tool:dsh:lead:call_78b0b4619c49430793254ee9 -> tool:dsh:lead:call_690fe49192a149958172a27c -> tool:dsh:lead:call_500b753863dc4ee0a2f3c606 -> tool:dsh:lead:call_f058f8b21ed6487ab9424bed -> tool:dsh:lead:call_e9e1dae465b247599204bb87 -> tool:dsh:lead:call_90f4660ef5c545648b9715d1 -> tool:dsh:lead:call_f8a16b38a3034db79b81c9f7 -> tool:dsh:lead:call_c0154fccef1c42f9bc666897 -> tool:dsh:lead:call_ae596635ea70458484df8172 -> tool:dsh:lead:call_c7c183a8ec674dbcafc4fa2f -> tool:dsh:lead:call_77100c986cd2469aa76de5aa -> tool:dsh:lead:call_a75008db5b4543438e5f0c8c -> tool:dsh:lead:call_23128d4b22364fd19c66057f -> tool:dsh:lead:call_4e7bd4f78255427c9c1bf2f8 -> tool:dsh:lead:call_c16b2da516484a659e45de35 -> tool:dsh:lead:call_257250d962e5497ea92f40b1 -> tool:dsh:lead:call_7f3b5479b8cc45d28e2ee847 -> tool:dsh:lead:call_014447e3d51442a3901e1a01 -> tool:dsh:lead:call_b4ce83bceda84ade9faef869 -> tool:dsh:lead:call_a101df55c9fc4440851cc22c -> tool:dsh:lead:call_fe6c45ec44684e15a484d4d9 -> tool:dsh:lead:call_595538a44f2c480db636b5f6 -> tool:dsh:lead:call_6119a39d3f7b4c89950c328c -> tool:dsh:lead:call_1d3d5e700d1f467e93571a9f -> tool:dsh:lead:call_d510afaab504458899969878 -> tool:dsh:lead:call_a02ef3aebb444eddb03ba128 -> tool:dsh:lead:call_b3e7ed26d68f4f14b779be3c -> tool:dsh:lead:call_585064936d87470a965c303c -> tool:dsh:lead:call_ff6d418a7d4b4951bc8e5ceb -> tool:dsh:lead:call_c6fbea74ae734ccb9707f560 -> tool:dsh:lead:call_fdfecb6e9aa14da4af98777b -> tool:dsh:lead:call_bd6abe9424ec4a6798c530fe -> tool:dsh:lead:call_ecee2a1f2477418a951f5960
- 关键路径耗时：1.429
- Makespan：184.626
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
