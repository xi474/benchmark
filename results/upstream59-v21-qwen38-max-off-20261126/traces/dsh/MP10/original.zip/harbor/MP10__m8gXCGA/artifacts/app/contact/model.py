import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check for non-finite float values (NaN, Infinity)."""
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read UTF-8 JSON file; only object/array top-level allowed; reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level JSON must be object or array")
    _check_finite(data)
    return data
