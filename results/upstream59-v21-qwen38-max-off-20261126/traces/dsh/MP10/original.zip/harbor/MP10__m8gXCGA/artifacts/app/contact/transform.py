def _validate_int(val, name, min_val=None, max_val=None):
    """Validate that val is an int (not bool) within optional bounds."""
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be an integer")
    if min_val is not None and val < min_val:
        raise ValueError(f"{name} must be >= {min_val}")
    if max_val is not None and val > max_val:
        raise ValueError(f"{name} must be <= {max_val}")
    return val


def transform(payloads, contract):
    """Find the most recent conversation matching the topic substring."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    if "conversations" not in case:
        raise ValueError("missing 'conversations'")
    if "topic" not in case:
        raise ValueError("missing 'topic'")

    conversations = case["conversations"]
    if not isinstance(conversations, list):
        raise ValueError("'conversations' must be a list")

    topic = case["topic"]
    if not isinstance(topic, str):
        raise ValueError("'topic' must be a string")

    topic_lower = topic.casefold()

    best = None  # (ts, conversation_id, contact_id)

    for conv in conversations:
        if not isinstance(conv, dict):
            raise ValueError("each conversation must be an object")
        for field in ("id", "contact_id", "ts", "topic"):
            if field not in conv:
                raise ValueError(f"conversation missing '{field}'")

        conv_topic = conv["topic"]
        if not isinstance(conv_topic, str):
            raise ValueError("conversation topic must be a string")

        # Substring match using casefold
        if topic_lower not in conv_topic.casefold():
            continue

        ts = conv["ts"]
        _validate_int(ts, "ts")

        conv_id = conv["id"]
        if not isinstance(conv_id, str):
            raise ValueError("conversation id must be a string")

        contact_id = conv["contact_id"]
        if not isinstance(contact_id, str):
            raise ValueError("contact_id must be a string")

        # Select: max ts, then min conversation id (lexicographic)
        candidate = (ts, conv_id, contact_id)
        if best is None:
            best = candidate
        else:
            # Compare: higher ts wins; same ts => lower conv_id wins
            if ts > best[0]:
                best = candidate
            elif ts == best[0] and conv_id < best[1]:
                best = candidate

    if best is None:
        result = {"contact_id": None, "conversation_id": None}
    else:
        result = {"contact_id": best[2], "conversation_id": best[1]}

    return {"name": contract["name"], "result": result}
