import json
import sys
from pathlib import Path


def _setup_imports():
    """Ensure package imports work both as module and as script."""
    here = Path(__file__).resolve().parent
    root = here.parent
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))


_setup_imports()

from dinner.model import load_payload
from dinner.transform import transform


def build_component(root, contract_path):
    """Read inputs from root, run transform, write output, return result."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    return result


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    contract_path = here / "contract.json"
    build_component(root, contract_path)
