import datetime


def _validate_int(val, name, min_val=None, max_val=None):
    """Validate that val is an int (not bool) within optional bounds."""
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be an integer")
    if min_val is not None and val < min_val:
        raise ValueError(f"{name} must be >= {min_val}")
    if max_val is not None and val > max_val:
        raise ValueError(f"{name} must be <= {max_val}")
    return val


def transform(payloads, contract):
    """Compute the next dinner date strictly after today on the given weekday."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    # Validate required fields
    if "today" not in case:
        raise ValueError("missing 'today'")
    if "weekday" not in case:
        raise ValueError("missing 'weekday'")
    if "hour" not in case:
        raise ValueError("missing 'hour'")
    if "guest_count" not in case:
        raise ValueError("missing 'guest_count'")

    today_str = case["today"]
    if not isinstance(today_str, str):
        raise ValueError("'today' must be a string")

    try:
        today = datetime.date.fromisoformat(today_str)
    except ValueError as e:
        raise ValueError(f"invalid 'today' date: {e}") from e

    weekday = _validate_int(case["weekday"], "weekday", 0, 6)
    hour = _validate_int(case["hour"], "hour", 0, 23)
    guest_count = _validate_int(case["guest_count"], "guest_count", 1)

    # Python weekday: Monday=0 .. Sunday=6, same as our convention
    today_wd = today.weekday()  # 0=Mon .. 6=Sun
    days_ahead = weekday - today_wd
    if days_ahead <= 0:
        days_ahead += 7
    dinner_date = today + datetime.timedelta(days=days_ahead)

    start = f"{dinner_date.isoformat()}T{hour:02d}:00"

    result = {
        "start": start,
        "guest_count": guest_count,
    }

    return {"name": contract["name"], "result": result}
