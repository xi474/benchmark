"""Generate the final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core["components"]

    # title is fixed
    title = "晚宴计划、联系人定位与餐具采购"

    # component_count is number of keys in components
    component_count = len(components)

    # sha256: serialize the full core object (with outer "components" wrapper)
    # using compact separators, no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: component names where any trigger condition is met
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if isinstance(val, list) and len(val) > 0:
                attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
