"""Orchestrate all components based on their contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: a component depends on another if its inputs
    # reference that component's output path
    comp_info = {}  # name -> {contract_path, output, deps}
    output_to_name = {}

    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        output = c["output"]
        output_to_name[output] = name
        comp_info[name] = {
            "contract_path": cp,
            "output": output,
            "inputs": c["inputs"],
            "deps": set(),
        }

    # Determine dependencies
    for name, info in comp_info.items():
        for inp in info["inputs"]:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                if dep_name != name:
                    info["deps"].add(dep_name)

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"Circular dependency detected involving {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        for dep in sorted(comp_info[name]["deps"]):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(comp_info.keys()):
        visit(name)

    # Execute each component in order
    for name in ordered:
        info = comp_info[name]
        cp = info["contract_path"]
        render_script = cp.with_name("render.py")
        if not render_script.exists():
            print(f"No render.py for component {name}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_script = ROOT / "integrate.py"
    if integrate_script.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_script = ROOT / "final_report.py"
    if report_script.exists():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
