def _validate_int(val, name, min_val=None, max_val=None):
    """Validate that val is an int (not bool) within optional bounds."""
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be an integer")
    if min_val is not None and val < min_val:
        raise ValueError(f"{name} must be >= {min_val}")
    if max_val is not None and val > max_val:
        raise ValueError(f"{name} must be <= {max_val}")
    return val


def transform(payloads, contract):
    """Match tableware variants to wanted kinds for dinner checkout."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]       # original snapshot with variants, wanted
    dinner_result = payloads[1]  # dinner component output {"name":..., "result":{...}}
    contact_result = payloads[2]  # contact component output {"name":..., "result":{...}}

    # Extract business data from upstream results
    # When input object keys are exactly name/result, only result is business input
    if isinstance(dinner_result, dict) and set(dinner_result.keys()) == {"name", "result"}:
        dinner_data = dinner_result["result"]
    else:
        dinner_data = dinner_result

    if isinstance(contact_result, dict) and set(contact_result.keys()) == {"name", "result"}:
        contact_data = contact_result["result"]
    else:
        contact_data = contact_result

    # Validate case fields
    if "variants" not in case:
        raise ValueError("missing 'variants'")
    if "wanted" not in case:
        raise ValueError("missing 'wanted'")

    variants = case["variants"]
    wanted = case["wanted"]

    if not isinstance(variants, list):
        raise ValueError("'variants' must be a list")
    if not isinstance(wanted, list):
        raise ValueError("'wanted' must be a list")

    guest_count = dinner_data["guest_count"]
    _validate_int(guest_count, "guest_count", 1)

    start = dinner_data["start"]
    recipient = contact_data.get("contact_id")  # may be None

    # Build index of variants by kind
    # Each variant: {id, kind, attributes, stock, price_cents}
    variant_map = {}  # kind -> list of variants
    for v in variants:
        if not isinstance(v, dict):
            raise ValueError("each variant must be an object")
        for field in ("id", "kind", "attributes", "stock", "price_cents"):
            if field not in v:
                raise ValueError(f"variant missing '{field}'")
        kind = v["kind"]
        if not isinstance(kind, str):
            raise ValueError("variant kind must be a string")
        _validate_int(v["stock"], "stock", 0)
        _validate_int(v["price_cents"], "price_cents", 0)
        if kind not in variant_map:
            variant_map[kind] = []
        variant_map[kind].append(v)

    items = []
    unavailable = []

    for w in wanted:
        if not isinstance(w, dict):
            raise ValueError("each wanted must be an object")
        if "kind" not in w:
            raise ValueError("wanted missing 'kind'")
        if "attributes" not in w:
            raise ValueError("wanted missing 'attributes'")

        w_kind = w["kind"]
        w_attrs = w["attributes"]

        if not isinstance(w_kind, str):
            raise ValueError("wanted kind must be a string")
        if not isinstance(w_attrs, dict):
            raise ValueError("wanted attributes must be an object")

        # Find candidates: same kind, exact attribute match, sufficient stock
        candidates = []
        for v in variant_map.get(w_kind, []):
            if v["attributes"] == w_attrs and v["stock"] >= guest_count:
                candidates.append(v)

        if not candidates:
            unavailable.append(w_kind)
            continue

        # Select: lowest price_cents, then lowest id (lexicographic)
        best = min(candidates, key=lambda v: (v["price_cents"], v["id"]))
        items.append({
            "id": best["id"],
            "kind": w_kind,
            "quantity": guest_count,
        })

    # Sort items by kind (lexicographic)
    items.sort(key=lambda x: x["kind"])
    # Sort unavailable by kind (lexicographic)
    unavailable.sort()

    total_cents = sum(item["quantity"] * next(
        v["price_cents"] for v in variants if v["id"] == item["id"]
    ) for item in items)

    # checkout requires all categories available and recipient non-null
    checkout = len(unavailable) == 0 and recipient is not None

    result = {
        "items": items,
        "total_cents": total_cents,
        "checkout": checkout,
        "recipient": recipient,
        "start": start,
        "unavailable": unavailable,
    }

    return {"name": contract["name"], "result": result}
