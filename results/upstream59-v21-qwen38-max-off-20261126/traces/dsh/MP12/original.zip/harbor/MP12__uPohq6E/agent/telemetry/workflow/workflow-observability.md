# Workflow 可观测性报告

- Trial：`MP12__uPohq6E__env`
- Task：`MP12`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（50 节点 / 49 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：50；执行边：49（observed=0，inferred=49）
- Execution Trace Graph：`observed`；temporal_next 边 49，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_d1dafc0d0c4344778acad8dd -> tool:dsh:lead:call_74a1f900d62240609a6bbe3a -> tool:dsh:lead:call_e7d026c5676840d1aa787a00 -> tool:dsh:lead:call_fd15b2e4b8cf4e02a47a00dc -> tool:dsh:lead:call_1df49c92104243d6a47e6918 -> tool:dsh:lead:call_8c5efb6016f04f87948f94e1 -> tool:dsh:lead:call_9c8c1abf904847859db63017 -> tool:dsh:lead:call_097ec8c6eda24a929663cd80 -> tool:dsh:lead:call_9a7d8ae770f54e26b0dee7a6 -> tool:dsh:lead:call_eb7bb4a6a2ef41df90cb5507 -> tool:dsh:lead:call_ce0f9e9ff6f74af89ea24630 -> tool:dsh:lead:call_bb467dc14c4f476a92045725 -> tool:dsh:lead:call_ebfa0a85439940e6900b19cb -> tool:dsh:lead:call_47a098979f75456dab3de579 -> tool:dsh:lead:call_af250c82f4374dbcb3c7d02a -> tool:dsh:lead:call_dd32c5bb8c6144a68cc1d10f -> tool:dsh:lead:call_9fd41243c0824b369e8e0409 -> tool:dsh:lead:call_536e71a402644e379a58470e -> tool:dsh:lead:call_7fbcda95070d44a2923fd5dd -> tool:dsh:lead:call_2bab7a00eed44441a9204d2a -> tool:dsh:lead:call_76a8fe6904154592aa2f019b -> tool:dsh:lead:call_5ae4bda733a14a8195aec8c0 -> tool:dsh:lead:call_1963e4d4a430459a8f8f86d0 -> tool:dsh:lead:call_7d917ce1d108406eb8b47d06 -> tool:dsh:lead:call_38a0df6b139a4e918c2708fa -> tool:dsh:lead:call_4c4707abc17b4204a463ede6 -> tool:dsh:lead:call_809f33904b894a41b82bba86 -> tool:dsh:lead:call_126e9e9acbe347c7a341ed89 -> tool:dsh:lead:call_a962a80c601044b8906582fd -> tool:dsh:lead:call_2943326d2e044d09bea7ceed -> tool:dsh:lead:call_93f2d995620f429994ba52b3 -> tool:dsh:lead:call_9351a6ca35d149e08ffd21fb -> tool:dsh:lead:call_3b3ad32d30654577824a7b2a -> tool:dsh:lead:call_f5d1a5602b154e0eb4ac24a3 -> tool:dsh:lead:call_fdf6455dc9b24903a7e049d4 -> tool:dsh:lead:call_c22d595a68b54ecbb817f9b9 -> tool:dsh:lead:call_95b866bc7fd044aa99f3efcd -> tool:dsh:lead:call_19d80071cd66440ab7f25b1e -> tool:dsh:lead:call_77f9310313564e1cb8bec8c5 -> tool:dsh:lead:call_473bdb83f6084ad09b344f99 -> tool:dsh:lead:call_359cb95febd6466cac882f2e -> tool:dsh:lead:call_a1763451bfc14d58a2c7b372 -> tool:dsh:lead:call_75709e9eb7984cfc932f9bb3 -> tool:dsh:lead:call_f82476f447074f94a891f115 -> tool:dsh:lead:call_dcdfcbc3e9b4433492807558 -> tool:dsh:lead:call_7658ab90c964403ea12b1ea7 -> tool:dsh:lead:call_8eb1d774ef9f4e39ba65ea9c -> tool:dsh:lead:call_6dfdc8cbb19f499eb7aacf30 -> tool:dsh:lead:call_ad0efffe155e45edb2c1e048
- 关键路径耗时：0.877
- Makespan：226.697
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
