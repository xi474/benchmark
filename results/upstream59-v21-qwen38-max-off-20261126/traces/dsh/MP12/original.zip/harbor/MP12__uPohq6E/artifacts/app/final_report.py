"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    
    components = core['components']
    
    # title is fixed
    title = '下载目录归档、邮件清理与目标回复'
    
    # component_count is number of component keys
    component_count = len(components)
    
    # sha256: serialize the full core object (with outer "components" key)
    # using json.dumps with ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False
    # no trailing newline, then SHA256 lowercase hex
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()
    
    # attention: component names where any of these conditions hold:
    # - result.blocked is explicitly true
    # - complete/checkout/committed/ok is explicitly false
    # - unavailable/missing/conflicts/unreachable is non-empty
    # Non-existent fields don't trigger; false vs 0/null distinction matters
    attention = []
    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue
        
        triggered = False
        
        # Check blocked === true (must be bool True, not truthy)
        if 'blocked' in comp_result and comp_result['blocked'] is True:
            triggered = True
        
        # Check complete/checkout/committed/ok === false (must be bool False)
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in comp_result and comp_result[key] is False:
                triggered = True
        
        # Check unavailable/missing/conflicts/unreachable is non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            if key in comp_result:
                val = comp_result[key]
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    triggered = True
        
        if triggered:
            attention.append(comp_name)
    
    attention.sort()
    
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }
    
    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
