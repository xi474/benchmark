def transform(payloads, contract):
    """workspace_commit operation.
    
    Inputs in order: original snapshot (case.json), download_archive result, mail_trash result, manager_reply result.
    
    If the reply target email is also in trash_ids, raise ValueError (conflict before commit).
    Replay file moves from download_archive result.
    Set folder to TRASH for emails in trash_ids.
    Output: {files:[{path,hex}] sorted by path, emails: sorted by id, reply: upstream reply result}.
    Must not touch other files/emails.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    original = payloads[0]       # case.json - the original snapshot
    files_result = payloads[1]   # download_archive result envelope {name, result:{moves:...}}
    mail_result = payloads[2]    # mail_trash result envelope {name, result:{trash_ids:...}}
    reply_result = payloads[3]   # manager_reply result envelope {name, result:{email_id,...}}
    
    # Extract results - when input has name/result keys, only result is business input
    files_data = files_result['result'] if isinstance(files_result, dict) and set(files_result.keys()) >= {'name', 'result'} else files_result
    mail_data = mail_result['result'] if isinstance(mail_result, dict) and set(mail_result.keys()) >= {'name', 'result'} else mail_result
    reply_data = reply_result['result'] if isinstance(reply_result, dict) and set(reply_result.keys()) >= {'name', 'result'} else reply_result
    
    trash_ids = set(mail_data['trash_ids'])
    reply_email_id = reply_data['email_id']
    
    # Check conflict: if reply target is in trash_ids
    if reply_email_id in trash_ids:
        raise ValueError(f"reply target {reply_email_id} is in trash_ids - conflict before commit")
    
    # Start with original files and emails
    files = list(original['files'])
    emails = [dict(e) for e in original['emails']]  # deep copy
    
    # Build move map from download_archive result
    moves = files_data.get('moves', [])
    move_map = {}
    for m in moves:
        move_map[m['from']] = m['to']
    
    # Apply file moves
    new_files = []
    for f in files:
        if f['path'] in move_map:
            new_files.append({'path': move_map[f['path']], 'hex': f['hex']})
        else:
            new_files.append(dict(f))
    
    # Sort files by path
    new_files.sort(key=lambda f: f['path'])
    
    # Apply trash to emails
    new_emails = []
    for e in emails:
        if e['id'] in trash_ids:
            new_e = dict(e)
            new_e['folder'] = 'TRASH'
            new_emails.append(new_e)
        else:
            new_emails.append(dict(e))
    
    # Sort emails by id
    new_emails.sort(key=lambda e: e['id'])
    
    return {
        "name": contract['name'],
        "result": {
            "files": new_files,
            "emails": new_emails,
            "reply": reply_data
        }
    }
