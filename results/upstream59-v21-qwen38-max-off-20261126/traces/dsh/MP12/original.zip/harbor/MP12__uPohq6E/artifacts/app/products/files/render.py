import json
import sys
from pathlib import Path

# Add parent dir to path so we can import sibling modules
sys.path.insert(0, str(Path(__file__).resolve().parent))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with required formatting."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    path.write_text(text + '\n', encoding='utf-8')


if __name__ == "__main__":
    # When run as script: write output to contract's output path
    contract_path = Path(__file__).resolve().with_name('contract.json')
    root = Path(__file__).resolve().parents[2]
    
    result = build_component(root, contract_path)
    
    contract = load_payload(contract_path)
    output_path = root / contract['output']
    _write_json(output_path, result)
