import os


def transform(payloads, contract):
    """download_archive operation.
    
    Input: single payload with files:[{path,hex}], download_prefix, archive_prefix, extensions:{ext:subdir}
    Only process direct children of download_prefix. Extension matching is case-insensitive.
    Move matched files to archive_prefix/subdir/original_basename.
    Unmatched/deep files are kept. Target must not already exist.
    Returns {moves:[{from,to}]} sorted by from.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    files = data['files']
    download_prefix = data['download_prefix']
    archive_prefix = data['archive_prefix']
    extensions = data['extensions']
    
    # Build lowercase extension map
    ext_map = {}
    for ext, subdir in extensions.items():
        ext_map[ext.lower()] = subdir
    
    moves = []
    
    for f in files:
        fpath = f['path']
        
        # Check if file is a direct child of download_prefix
        # Use forward slash as separator
        parts = fpath.split('/')
        if len(parts) != 2 or parts[0] != download_prefix:
            # Not a direct child of download_prefix - skip (keep in place)
            continue
        
        basename = parts[1]
        
        # Get extension (case-insensitive)
        _, ext = os.path.splitext(basename)
        ext_lower = ext.lower()
        
        if ext_lower not in ext_map:
            # No matching extension - keep in place
            continue
        
        subdir = ext_map[ext_lower]
        new_path = f"{archive_prefix}/{subdir}/{basename}"
        
        moves.append({"from": fpath, "to": new_path})
    
    # Sort by 'from'
    moves.sort(key=lambda m: m['from'])
    
    return {"name": contract['name'], "result": {"moves": moves}}
