def transform(payloads, contract):
    """mail_trash operation.
    
    Input: single payload with emails:[{id,date,subject,folder,sender,thread_id}], month:YYYY-MM, trash_keyword:str
    Select emails where date belongs to month AND subject casefold contains trash_keyword casefold AND folder != "TRASH".
    Returns {trash_ids: sorted list of IDs}.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    emails = data['emails']
    month = data['month']  # YYYY-MM
    trash_keyword = data['trash_keyword']
    
    keyword_lower = trash_keyword.casefold()
    
    trash_ids = []
    
    for email in emails:
        eid = email['id']
        date = email['date']  # YYYY-MM-DD
        subject = email['subject']
        folder = email['folder']
        
        # Check date belongs to month
        # date is YYYY-MM-DD, month is YYYY-MM
        if not date.startswith(month + '-'):
            continue
        
        # Validate date format (basic check)
        parts = date.split('-')
        if len(parts) != 3:
            raise ValueError(f"invalid date format: {date}")
        year, mon, day = int(parts[0]), int(parts[1]), int(parts[2])
        if mon < 1 or mon > 12 or day < 1 or day > 31:
            raise ValueError(f"invalid date: {date}")
        
        # Check subject contains keyword (casefold)
        if keyword_lower not in subject.casefold():
            continue
        
        # Check folder is not TRASH
        if folder == "TRASH":
            continue
        
        trash_ids.append(eid)
    
    trash_ids.sort()
    
    return {"name": contract['name'], "result": {"trash_ids": trash_ids}}
