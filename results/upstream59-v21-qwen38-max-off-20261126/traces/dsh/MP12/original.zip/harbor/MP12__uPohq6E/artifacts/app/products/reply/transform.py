def transform(payloads, contract):
    """manager_reply operation.
    
    Input: single payload with emails, reply_email_id, manager, reply_text.
    Target email must exist and sender == manager.
    Reply directly to target by ID (not by subject/latest).
    Returns {email_id, thread_id, to: manager, text: reply_text}.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    emails = data['emails']
    reply_email_id = data['reply_email_id']
    manager = data['manager']
    reply_text = data['reply_text']
    
    # Find target email
    target = None
    for email in emails:
        if email['id'] == reply_email_id:
            target = email
            break
    
    if target is None:
        raise ValueError(f"reply_email_id {reply_email_id} not found")
    
    if target['sender'] != manager:
        raise ValueError(f"target sender {target['sender']} != manager {manager}")
    
    return {
        "name": contract['name'],
        "result": {
            "email_id": reply_email_id,
            "thread_id": target['thread_id'],
            "to": manager,
            "text": reply_text
        }
    }
