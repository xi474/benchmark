"""Run all components in dependency order, then integrate."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_component(component_dir):
    """Run a component's render.py script."""
    render_py = component_dir / 'render.py'
    if not render_py.exists():
        raise FileNotFoundError(f"render.py not found in {component_dir}")
    result = subprocess.run(
        [sys.executable, str(render_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: {render_py}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


def main():
    # Components that have no dependencies on other outputs
    independent = ['files', 'mail', 'reply']
    
    for name in independent:
        comp_dir = ROOT / 'products' / name
        if comp_dir.is_dir() and (comp_dir / 'contract.json').exists():
            run_component(comp_dir)
    
    # Commit depends on files, mail, reply outputs
    commit_dir = ROOT / 'products' / 'commit'
    if commit_dir.is_dir() and (commit_dir / 'contract.json').exists():
        run_component(commit_dir)
    
    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
