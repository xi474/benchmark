# Workflow 可观测性报告

- Trial：`MP13__4eLvdwL__env`
- Task：`MP13`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（55 节点 / 54 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：55；执行边：54（observed=0，inferred=54）
- Execution Trace Graph：`observed`；temporal_next 边 54，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_d9f1908aa09140fda51d4574 -> tool:dsh:lead:call_010e41399e2a418a96e90bd7 -> tool:dsh:lead:call_9b4596ca78664339aae962fe -> tool:dsh:lead:call_f67014adee7b4d449a79a1b5 -> tool:dsh:lead:call_9392b8f8b0d7436e8d908095 -> tool:dsh:lead:call_a3fd3169cc1e4229b11c101e -> tool:dsh:lead:call_4708e5ffe2564b47843c3cca -> tool:dsh:lead:call_f14bb89022eb4982a160dc97 -> tool:dsh:lead:call_ea2d28cff10440f097e597d6 -> tool:dsh:lead:call_0cf82d8146fc4faa95b5a171 -> tool:dsh:lead:call_8ac4885e6b6e410bafb7f2cf -> tool:dsh:lead:call_12f1f6e0f23c4c84ae42927a -> tool:dsh:lead:call_d9ab518b6c73462096e1ac72 -> tool:dsh:lead:call_20eb3f98946846d599c325fd -> tool:dsh:lead:call_98470521730f4db1a3520fb0 -> tool:dsh:lead:call_9e7e892b39cf474283c1927a -> tool:dsh:lead:call_edb8fed2bd34473e857fa737 -> tool:dsh:lead:call_8a9240b83a91459bb04e1aaf -> tool:dsh:lead:call_528fa4262896452280ae509c -> tool:dsh:lead:call_8ae6c104f17749589400bd00 -> tool:dsh:lead:call_4950963bf38e4e4c8e2fbc32 -> tool:dsh:lead:call_370d2834847b40cc89c39a2d -> tool:dsh:lead:call_ec63e8b5198143e098321001 -> tool:dsh:lead:call_3654caa6973746399f71c6a9 -> tool:dsh:lead:call_7c6b468906b74ff485bfbe12 -> tool:dsh:lead:call_5a1a4c1b3dba4d0b853ccb3d -> tool:dsh:lead:call_1e908ee0168a4915b83656b3 -> tool:dsh:lead:call_4fb9e2093c80453f8805cf9c -> tool:dsh:lead:call_a3e4be0d2296460d93942d52 -> tool:dsh:lead:call_f5d75f8e74d7471a8b2c99df -> tool:dsh:lead:call_4a4aeb22d5ae47cfa4731b39 -> tool:dsh:lead:call_01c2333536eb45b0862054ca -> tool:dsh:lead:call_dfa090e6236442f199fee5b1 -> tool:dsh:lead:call_6d96cd9d17e34ec49ec07b0f -> tool:dsh:lead:call_30dd51a643c44ef5b82ac6d1 -> tool:dsh:lead:call_b4d8f1c446444798aa345880 -> tool:dsh:lead:call_8a85ea35137e466e8787c9d2 -> tool:dsh:lead:call_298b1c00f1b74bc396820a6b -> tool:dsh:lead:call_b7e61b60f722440cb57c6005 -> tool:dsh:lead:call_372a5de4e74d4f4bbb449815 -> tool:dsh:lead:call_30251600ceb44f5394eb4338 -> tool:dsh:lead:call_1b7db1df4488499ea1f8f41c -> tool:dsh:lead:call_a86d767949394bdcb924b79d -> tool:dsh:lead:call_70b58606aa5b404f8f304e68 -> tool:dsh:lead:call_03ac511cd45344d6a7870dea -> tool:dsh:lead:call_ea7b3f0476074227a0a17955 -> tool:dsh:lead:call_3cf132c43a53461ba3954a73 -> tool:dsh:lead:call_c0093d14c8ee41538f9d676b -> tool:dsh:lead:call_334de08e3449437cbd22f927 -> tool:dsh:lead:call_da9452db80e44c1c9ab7b633 -> tool:dsh:lead:call_f88c6faf2cbb45619fb70a1b -> tool:dsh:lead:call_97fa38c2d697461faac8ca67 -> tool:dsh:lead:call_12e29f8edda94333a918c4ec -> tool:dsh:lead:call_25380c37db3f444f91604c67
- 关键路径耗时：0.979
- Makespan：240.997
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
