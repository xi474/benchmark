def transform(payloads, contract):
    """
    category_features: for each key group, check which vocabulary terms appear
    among non-null categories. Output boolean columns per vocabulary term.
    Groups with all-null categories are omitted.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    records = data.get('records')
    vocabulary = data.get('vocabulary')

    if not isinstance(records, list):
        raise ValueError("records must be a list")
    if not isinstance(vocabulary, list):
        raise ValueError("vocabulary must be a list")

    # Validate vocabulary: unique non-empty strings
    seen_vocab = set()
    for v in vocabulary:
        if not isinstance(v, str) or not v.strip():
            raise ValueError("vocabulary items must be non-empty strings")
        if v in seen_vocab:
            raise ValueError(f"duplicate vocabulary item: {v}")
        seen_vocab.add(v)

    # Group by key
    groups = {}
    for rec in records:
        key = rec.get('key')
        if key is None:
            raise ValueError("record missing key")
        if key not in groups:
            groups[key] = []
        groups[key].append(rec)

    rows = []
    for key in sorted(groups.keys()):
        recs = groups[key]
        cats = [r.get('category') for r in recs if r.get('category') is not None]

        # If all null, skip this key
        if not cats:
            continue

        # Validate categories are strings
        for c in cats:
            if not isinstance(c, str):
                raise ValueError("category must be string or null")

        cat_set = set(cats)
        values = {}
        for term in vocabulary:
            values[term] = term in cat_set

        rows.append({
            'key': key,
            'values': values
        })

    return {'name': contract['name'], 'result': {'rows': rows}}
