import json
import math
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON, only object/array top-level; reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    # Parse with strict float handling to catch NaN/Infinity
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e

    if not isinstance(obj, (dict, list)):
        raise ValueError("top-level must be object or array")

    _check_finite(obj)
    return obj


def _check_finite(obj):
    """Recursively check for non-finite floats and nested NaN/Infinity."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
