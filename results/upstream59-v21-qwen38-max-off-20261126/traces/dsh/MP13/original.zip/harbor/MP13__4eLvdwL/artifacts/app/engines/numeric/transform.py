import math


def transform(payloads, contract):
    """
    numeric_features: group by key, compute count/sum/mean of non-null values.
    Input: {records:[{id,key,value,category,time}], vocabulary:[str]}
    Output: {rows:[{key, values:{count,sum,mean}}]} sorted by key.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    records = data.get('records')
    if not isinstance(records, list):
        raise ValueError("records must be a list")

    # Validate unique IDs
    seen_ids = set()
    for rec in records:
        rid = rec.get('id')
        if rid in seen_ids:
            raise ValueError(f"duplicate record id: {rid}")
        seen_ids.add(rid)

    # Group by key
    groups = {}
    for rec in records:
        key = rec.get('key')
        if key is None:
            raise ValueError("record missing key")
        if key not in groups:
            groups[key] = []
        groups[key].append(rec)

    rows = []
    for key in sorted(groups.keys()):
        recs = groups[key]
        values = [r['value'] for r in recs if r.get('value') is not None]

        # Validate that non-null values are finite numbers (not bool)
        for v in values:
            if isinstance(v, bool):
                raise ValueError("value must not be bool")
            if not isinstance(v, (int, float)):
                raise ValueError("value must be a number")
            if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
                raise ValueError("non-finite value")

        count = len(values)
        s = sum(values) if count > 0 else 0
        mean = s / count if count > 0 else None

        rows.append({
            'key': key,
            'values': {
                'count': count,
                'sum': s,
                'mean': mean
            }
        })

    return {'name': contract['name'], 'result': {'rows': rows}}
