def transform(payloads, contract):
    """
    time_features: for each key group, collect non-null integer times.
    Output first (min), last (max), span (last - first).
    Groups with all-null times are omitted.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    records = data.get('records')

    if not isinstance(records, list):
        raise ValueError("records must be a list")

    # Group by key
    groups = {}
    for rec in records:
        key = rec.get('key')
        if key is None:
            raise ValueError("record missing key")
        if key not in groups:
            groups[key] = []
        groups[key].append(rec)

    rows = []
    for key in sorted(groups.keys()):
        recs = groups[key]
        times = [r.get('time') for r in recs if r.get('time') is not None]

        # If all null, skip this key
        if not times:
            continue

        # Validate times are integers (not bool)
        for t in times:
            if isinstance(t, bool):
                raise ValueError("time must be integer, not bool")
            if not isinstance(t, int):
                raise ValueError("time must be integer or null")

        first = min(times)
        last = max(times)
        span = last - first

        rows.append({
            'key': key,
            'values': {
                'first': first,
                'last': last,
                'span': span
            }
        })

    return {'name': contract['name'], 'result': {'rows': rows}}
