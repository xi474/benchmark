def transform(payloads, contract):
    """
    feature_union: outer-join numeric, category, time features by key.
    Prefix columns with num./cat./time., collect sorted union of all columns.
    Missing branches fill null (not 0).
    Output: {index:[key], columns:[col_names_sorted], data:[[values]]}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    numeric_result = payloads[0]  # {name, result: {rows:[{key, values:{count,sum,mean}}]}}
    category_result = payloads[1]  # {name, result: {rows:[{key, values:{vocab:bool}}]}}
    time_result = payloads[2]  # {name, result: {rows:[{key, values:{first,last,span}}]}}

    # Extract the result objects - handle both raw result and envelope
    def get_result(obj):
        if isinstance(obj, dict) and 'result' in obj:
            return obj['result']
        return obj

    num_data = get_result(numeric_result)
    cat_data = get_result(category_result)
    time_data = get_result(time_result)

    # Build per-key dictionaries
    num_by_key = {}
    for row in num_data.get('rows', []):
        num_by_key[row['key']] = row['values']

    cat_by_key = {}
    for row in cat_data.get('rows', []):
        cat_by_key[row['key']] = row['values']

    time_by_key = {}
    for row in time_data.get('rows', []):
        time_by_key[row['key']] = row['values']

    # Collect all keys (outer join)
    all_keys = set()
    all_keys.update(num_by_key.keys())
    all_keys.update(cat_by_key.keys())
    all_keys.update(time_by_key.keys())

    sorted_keys = sorted(all_keys)

    # Collect all column names with prefixes
    all_columns = set()

    # Numeric columns
    num_cols = set()
    for vals in num_by_key.values():
        num_cols.update(vals.keys())
    for c in num_cols:
        all_columns.add(f'num.{c}')

    # Category columns
    cat_cols = set()
    for vals in cat_by_key.values():
        cat_cols.update(vals.keys())
    for c in cat_cols:
        all_columns.add(f'cat.{c}')

    # Time columns
    time_cols = set()
    for vals in time_by_key.values():
        time_cols.update(vals.keys())
    for c in time_cols:
        all_columns.add(f'time.{c}')

    sorted_columns = sorted(all_columns)

    # Build data rows
    data = []
    for key in sorted_keys:
        row_values = []
        num_vals = num_by_key.get(key, {})
        cat_vals = cat_by_key.get(key, {})
        time_vals = time_by_key.get(key, {})

        for col in sorted_columns:
            if col.startswith('num.'):
                field = col[4:]
                row_values.append(num_vals.get(field, None))
            elif col.startswith('cat.'):
                field = col[4:]
                row_values.append(cat_vals.get(field, None))
            elif col.startswith('time.'):
                field = col[5:]
                row_values.append(time_vals.get(field, None))
            else:
                row_values.append(None)

        data.append(row_values)

    return {
        'name': contract['name'],
        'result': {
            'index': sorted_keys,
            'columns': sorted_columns,
            'data': data
        }
    }
