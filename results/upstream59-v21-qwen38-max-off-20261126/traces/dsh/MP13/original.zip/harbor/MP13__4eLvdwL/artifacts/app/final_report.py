"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core.get('components', {})
    component_count = len(components)

    # SHA256 of the full core object serialized compactly
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(canonical).hexdigest()

    # Attention: components with specific conditions
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue

        # result.blocked explicitly true
        if result.get('blocked') is True:
            attention.add(name)

        # complete/checkout/committed/ok explicitly false
        for field in ('complete', 'checkout', 'committed', 'ok'):
            if field in result and result[field] is False:
                attention.add(name)

        # unavailable/missing/conflicts/unreachable non-empty
        for field in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(field)
            if val is not None and val != [] and val != {} and val != '' and val != 0 and val is not False:
                # "non-empty" - check if it's a collection with items or truthy
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, (int, float, bool)) and val:
                    attention.add(name)

    report = {
        'title': '聚合特征的行键保真与特征合并',
        'component_count': component_count,
        'sha256': sha256,
        'attention': sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
