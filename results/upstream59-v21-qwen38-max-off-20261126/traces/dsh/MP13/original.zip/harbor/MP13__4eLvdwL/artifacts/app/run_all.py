"""Orchestrate all components based on contract.json file interfaces."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contracts (excluding outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph: contract output -> render.py path
    # We need to execute in topological order based on input dependencies
    contract_map = {}  # output_path -> (contract_path, render_py_path)
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        output = c['output']
        render_py = cp.with_name('render.py')
        contract_map[output] = (cp, render_py)

    # Topological sort based on input dependencies
    executed = set()
    order = []

    def resolve(output_path):
        if output_path in executed:
            return
        if output_path not in contract_map:
            # It's an input file, not a generated output - skip
            return
        cp, render_py = contract_map[output_path]
        c = json.loads(cp.read_text(encoding='utf-8'))
        # First resolve all inputs that are themselves outputs
        for inp in c['inputs']:
            resolve(inp)
        order.append((cp, render_py))
        executed.add(output_path)

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        resolve(c['output'])

    # Execute each component in order
    for cp, render_py in order:
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {render_py}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
