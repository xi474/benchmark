# Workflow 可观测性报告

- Trial：`MP14__AukDt7U__env`
- Task：`MP14`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（66 节点 / 65 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：66；执行边：65（observed=0，inferred=65）
- Execution Trace Graph：`observed`；temporal_next 边 65，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_7c61ac4541a0437d92c20f42 -> tool:dsh:lead:call_f17c9845028d48bd92a3c9cc -> tool:dsh:lead:call_9a65226f0c2f4e99bc6ba4ef -> tool:dsh:lead:call_1d7387cbd71541939e99f4a1 -> tool:dsh:lead:call_19650544221f47d19c2ac71d -> tool:dsh:lead:call_c594db0bbf7549338d3a8bee -> tool:dsh:lead:call_c6c7c440caaf4399b6e19d83 -> tool:dsh:lead:call_bee444bba81a49c990b439d4 -> tool:dsh:lead:call_1a98647d573746c8a9ea63be -> tool:dsh:lead:call_3db32883fe0e4c15a3669dbd -> tool:dsh:lead:call_ead47c56538646608e434b56 -> tool:dsh:lead:call_2d4215e39a3f4203addbdf49 -> tool:dsh:lead:call_b35dd656fc4c4a4bbed933ec -> tool:dsh:lead:call_6a177838e63546f5b6631ed5 -> tool:dsh:lead:call_feccf9188f704a348f7e24f6 -> tool:dsh:lead:call_ca28668a94f04f4cae927846 -> tool:dsh:lead:call_48a2dd08c4f94799a9b185b7 -> tool:dsh:lead:call_eeb6d4f6e0fd480284d061fe -> tool:dsh:lead:call_47b15e7213144ff98d96bef7 -> tool:dsh:lead:call_184aefb72c6f4bd9b77fda73 -> tool:dsh:lead:call_65c8bca5051a4c0589ba0ff0 -> tool:dsh:lead:call_273f32e2edf84b98bc086710 -> tool:dsh:lead:call_1a6d309e00fa4271971c6ca9 -> tool:dsh:lead:call_537d25c0a4a84b02a91f55d6 -> tool:dsh:lead:call_e7999dbed0a644db9ebe1af2 -> tool:dsh:lead:call_4f0614cd64c5429083a2dca7 -> tool:dsh:lead:call_306663080d004586940979e8 -> tool:dsh:lead:call_933d554b4ed64fad9065b5aa -> tool:dsh:lead:call_79a29d93773c4bdc87b40101 -> tool:dsh:lead:call_ab047fdf4b9c445ea70aa6e4 -> tool:dsh:lead:call_4b650e7acfc24ce880e41a7c -> tool:dsh:lead:call_6e7dbd3403a04923a0703a40 -> tool:dsh:lead:call_2cf2954298024689808c7e94 -> tool:dsh:lead:call_de35f5d2f3e44d50b08f4543 -> tool:dsh:lead:call_0446e5ace391478ca575f0bc -> tool:dsh:lead:call_0f17cea794c14d7ba8213cba -> tool:dsh:lead:call_09010ea6e51c46439e43ca71 -> tool:dsh:lead:call_9aba7afed96b4983a631b7f6 -> tool:dsh:lead:call_1b106ac5b43a4bb8b77dd065 -> tool:dsh:lead:call_e37bc10f4234409d935126c2 -> tool:dsh:lead:call_bcad887b04744b9cb7f3c738 -> tool:dsh:lead:call_00425c7e6f994f96960743a7 -> tool:dsh:lead:call_d35919fdb385426ca74b50a3 -> tool:dsh:lead:call_f6a1893443ba492fb9688a15 -> tool:dsh:lead:call_7e92ea701851460e86cba51e -> tool:dsh:lead:call_8e291d5caa38475f835fe620 -> tool:dsh:lead:call_ff177c7444f7486c9538497c -> tool:dsh:lead:call_15df980fe61b419b942db98b -> tool:dsh:lead:call_ca8c3dc5cb0143d88ed8b0c8 -> tool:dsh:lead:call_7b1159d793eb4830b00f0823 -> tool:dsh:lead:call_cf275a370ea645cfb46d739a -> tool:dsh:lead:call_106c3faedf7a49aa9c848e5f -> tool:dsh:lead:call_1eb9ebe6d9a94200b8204db8 -> tool:dsh:lead:call_52d9fa32d3ef4236bf882b34 -> tool:dsh:lead:call_6f1df422bced418e84dd7dff -> tool:dsh:lead:call_7b14d2e148eb4c569036bd66 -> tool:dsh:lead:call_e118cd67e9d041e99862d1c0 -> tool:dsh:lead:call_5ba066e4508f46e98b70653b -> tool:dsh:lead:call_74c21365eb8b4565989f3752 -> tool:dsh:lead:call_7c3bb2b817ac4b65ae0b3501 -> tool:dsh:lead:call_101dadd5f8134d4cb8fb7129 -> tool:dsh:lead:call_e1b6cdb8eb2e4e99a53f51e2 -> tool:dsh:lead:call_f6504d38d51a4f829d89eeaa -> tool:dsh:lead:call_66e001c608fa4d6cb9a2ab2a -> tool:dsh:lead:call_5fd05de9d8b646019be2f760
- 关键路径耗时：1.442
- Makespan：311.692
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
