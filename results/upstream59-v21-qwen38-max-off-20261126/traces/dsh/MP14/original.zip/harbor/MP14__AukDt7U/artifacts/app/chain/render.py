import json
import sys
from pathlib import Path


def _ensure_ws_in_path():
    """Ensure workspace root is on sys.path for absolute imports."""
    here = Path(__file__).resolve().parent
    ws = here.parent
    ws_str = str(ws)
    if ws_str not in sys.path:
        sys.path.insert(0, ws_str)


def build_component(root, contract_path):
    """Read all inputs from root per contract, call transform, return encapsulated result."""
    _ensure_ws_in_path()
    from chain.model import load_payload
    from chain.transform import transform
    
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _json_dump(result, path):
    """Write JSON with standard formatting."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    p.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    _ensure_ws_in_path()
    from chain.model import load_payload
    
    here = Path(__file__).resolve().parent
    root = here.parent
    contract_path = here / "contract.json"
    
    result = build_component(root, contract_path)
    contract = load_payload(contract_path)
    output_path = root / contract["output"]
    _json_dump(result, output_path)
