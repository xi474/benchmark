def transform(payloads, contract):
    """exception_chain operation.
    
    Input: {root, nodes: [{id, type, message, cause, context, suppress_context, frames}]}
    Returns: {"name": contract["name"], "result": {"chain": [...]}}
    Chain goes from innermost to root. Each entry has link indicating how it connects
    to the previous (more inner) entry: null for first, "cause" or "context" for others.
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    # Validate top-level structure
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if "root" not in data:
        raise ValueError("missing 'root' field")
    if "nodes" not in data:
        raise ValueError("missing 'nodes' field")
    
    root_id = data["root"]
    nodes_list = data["nodes"]
    
    if not isinstance(nodes_list, list):
        raise ValueError("'nodes' must be array")
    
    # Build node map and validate each node
    node_map = {}
    seen_ids = set()
    for node in nodes_list:
        if not isinstance(node, dict):
            raise ValueError("each node must be object")
        for field in ("id", "type", "message", "cause", "context", "suppress_context", "frames"):
            if field not in node:
                raise ValueError(f"missing field '{field}' in node")
        
        nid = node["id"]
        if not isinstance(nid, str):
            raise ValueError("'id' must be string")
        if nid in seen_ids:
            raise ValueError(f"duplicate node id: {nid}")
        seen_ids.add(nid)
        
        if not isinstance(node["type"], str):
            raise ValueError("'type' must be string")
        if not isinstance(node["message"], str):
            raise ValueError("'message' must be string")
        if node["cause"] is not None and not isinstance(node["cause"], str):
            raise ValueError("'cause' must be string or null")
        if node["context"] is not None and not isinstance(node["context"], str):
            raise ValueError("'context' must be string or null")
        if not isinstance(node["suppress_context"], bool):
            raise ValueError("'suppress_context' must be bool")
        if not isinstance(node["frames"], list):
            raise ValueError("'frames' must be array")
        
        # Validate frames basic fields
        for frame in node["frames"]:
            if not isinstance(frame, dict):
                raise ValueError("each frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in frame:
                    raise ValueError(f"missing field '{ff}' in frame")
            if not isinstance(frame["line"], int) or isinstance(frame["line"], bool):
                raise ValueError("'line' must be integer")
            if frame["line"] < 1:
                raise ValueError("'line' must be >= 1")
        
        node_map[nid] = node
    
    if root_id not in node_map:
        raise ValueError(f"root id '{root_id}' not found in nodes")
    
    # Walk chain from root toward innermost
    MAX_CHAIN_LEN = 8
    visited = set()
    walk_nodes = []   # nodes in root-to-innermost order
    walk_links = []   # link type from walk_nodes[i] to walk_nodes[i+1]
    current_id = root_id
    
    while current_id is not None:
        if current_id in visited:
            raise ValueError(f"cycle detected at node '{current_id}'")
        if len(walk_nodes) >= MAX_CHAIN_LEN:
            raise ValueError("chain length exceeds limit of 8")
        
        visited.add(current_id)
        node = node_map[current_id]
        walk_nodes.append(node)
        
        # Determine next: prefer cause, else context if not suppressed
        next_id = None
        link_type = None
        if node["cause"] is not None:
            next_id = node["cause"]
            link_type = "cause"
        elif not node["suppress_context"] and node["context"] is not None:
            next_id = node["context"]
            link_type = "context"
        
        if next_id is not None:
            if next_id not in node_map:
                raise ValueError(f"referenced node '{next_id}' not found")
            walk_links.append(link_type)
            current_id = next_id
        else:
            current_id = None
    
    # Build output: reverse to get innermost-first
    # For output position j (0-indexed, j=0 is innermost):
    #   j==0: link=null
    #   j>0:  link = walk_links[n-1-j] where n=len(walk_nodes)
    n = len(walk_nodes)
    chain = []
    for j in range(n):
        node = walk_nodes[n - 1 - j]
        if j == 0:
            link = None
        else:
            link = walk_links[n - 1 - j]
        chain.append({
            "id": node["id"],
            "type": node["type"],
            "message": node["message"],
            "link": link
        })
    
    return {"name": contract["name"], "result": {"chain": chain}}
