"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))
    
    components = core.get("components", {})
    
    # title
    title = "异常链的可移植序列化与报告"
    
    # component_count
    component_count = len(components)
    
    # sha256: serialize the full core object (including outer "components" wrapper)
    core_str = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    )
    sha256 = hashlib.sha256(core_str.encode("utf-8")).hexdigest()
    
    # attention: component names where any of these conditions hold:
    # - result.blocked is explicitly true
    # - complete/checkout/committed/ok is explicitly false
    # - unavailable/missing/conflicts/unreachable is non-empty
    attention_set = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        # blocked explicitly true
        if result.get("blocked") is True:
            attention_set.add(name)
        
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention_set.add(name)
        
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None:
                # Non-empty check: for lists/dicts/strings, check truthiness
                # But spec says "非空" meaning non-empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention_set.add(name)
                elif isinstance(val, (int, float, bool)):
                    # Numbers/bools are not "non-empty" in the collection sense
                    pass
    
    attention = sorted(attention_set)
    
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }
    
    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    out_path.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    main()
