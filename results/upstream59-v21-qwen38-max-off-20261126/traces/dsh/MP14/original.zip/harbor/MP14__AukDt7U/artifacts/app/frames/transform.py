import json
import os


def transform(payloads, contract):
    """portable_frames operation.
    
    Input: same as exception_chain {root, nodes: [{id, ..., frames: [...]}]}
    Returns: {"name": contract["name"], "result": {"frames": {exception_id: [frame...]}}}
    
    For each node's frames:
    - file: replace backslashes with /, then keep only basename
    - line: must be positive integer (already validated)
    - function: must be non-empty string
    - locals: serialize each value as JSON string with ensure_ascii=False, sort_keys=True, compact separators
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if "nodes" not in data:
        raise ValueError("missing 'nodes' field")
    
    nodes_list = data["nodes"]
    if not isinstance(nodes_list, list):
        raise ValueError("'nodes' must be array")
    
    result_frames = {}
    
    for node in nodes_list:
        if not isinstance(node, dict):
            raise ValueError("each node must be object")
        
        nid = node.get("id")
        if not isinstance(nid, str):
            raise ValueError("'id' must be string")
        
        frames_in = node.get("frames")
        if frames_in is None:
            raise ValueError("missing 'frames' field")
        if not isinstance(frames_in, list):
            raise ValueError("'frames' must be array")
        
        processed_frames = []
        for frame in frames_in:
            if not isinstance(frame, dict):
                raise ValueError("each frame must be object")
            
            # file: replace backslash with /, then basename only
            raw_file = frame.get("file")
            if not isinstance(raw_file, str):
                raise ValueError("'file' must be string")
            normalized = raw_file.replace("\\", "/")
            basename = os.path.basename(normalized)
            
            # line: strict positive integer
            line = frame.get("line")
            if not isinstance(line, int) or isinstance(line, bool):
                raise ValueError("'line' must be integer")
            if line < 1:
                raise ValueError("'line' must be >= 1")
            
            # function: non-empty string
            func = frame.get("function")
            if not isinstance(func, str) or not func.strip():
                raise ValueError("'function' must be non-empty string")
            
            # locals: serialize each value to canonical JSON string
            locals_in = frame.get("locals")
            if locals_in is None:
                raise ValueError("missing 'locals' field")
            if not isinstance(locals_in, dict):
                raise ValueError("'locals' must be object")
            
            locals_out = {}
            for k, v in locals_in.items():
                locals_out[k] = json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            
            processed_frames.append({
                "file": basename,
                "line": line,
                "function": func,
                "locals": locals_out
            })
        
        result_frames[nid] = processed_frames
    
    return {"name": contract["name"], "result": {"frames": result_frames}}
