def transform(payloads, contract):
    """exception_report operation.
    
    Inputs (in order): exception_chain result, portable_frames result.
    Returns: {"name": contract["name"], "result": {"nodes": [...], "text": "..."}}
    
    Output nodes follow chain order. For non-first entries, prepend separator line
    based on link type. Then frames as "  file:line in function", then "Type: message".
    Text is lines joined by newline with trailing newline if non-empty.
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    chain_result = payloads[0]
    frames_result = payloads[1]
    
    # Extract chain and frames data
    # Inputs are the full component outputs: {"name": ..., "result": {...}}
    # Per README: "当输入对象键恰为name/result时，仅其result为业务输入"
    if isinstance(chain_result, dict) and set(chain_result.keys()) >= {"name", "result"}:
        chain_data = chain_result["result"]
    else:
        chain_data = chain_result
    
    if isinstance(frames_result, dict) and set(frames_result.keys()) >= {"name", "result"}:
        frames_data = frames_result["result"]
    else:
        frames_data = frames_result
    
    chain_list = chain_data.get("chain", [])
    frames_map = frames_data.get("frames", {})
    
    lines = []
    nodes_out = []
    
    for i, entry in enumerate(chain_list):
        eid = entry["id"]
        etype = entry["type"]
        emsg = entry["message"]
        elink = entry.get("link")
        
        # Separator for non-first entries
        if i > 0:
            if elink == "cause":
                lines.append("--- direct cause ---")
            elif elink == "context":
                lines.append("--- during handling ---")
        
        # Get frames for this exception from frames_map
        node_frames = frames_map.get(eid, [])
        
        # Add frame lines
        for fr in node_frames:
            lines.append(f"  {fr['file']}:{fr['line']} in {fr['function']}")
        
        # Type: message line
        lines.append(f"{etype}: {emsg}")
        
        # Build node output with frames preserved
        nodes_out.append({
            "id": eid,
            "type": etype,
            "message": emsg,
            "link": elink,
            "frames": node_frames
        })
    
    # Build text
    if lines:
        text = "\n".join(lines) + "\n"
    else:
        text = ""
    
    return {"name": contract["name"], "result": {"nodes": nodes_out, "text": text}}
