"""Orchestrate all component builds based on contract dependencies."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    
    if not contracts:
        raise ValueError("no contracts found")
    
    # Build dependency graph: a contract depends on another if its inputs
    # reference that contract's output
    contract_map = {}  # name -> contract_path
    output_to_name = {}  # output path -> contract name
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = cp
        output_to_name[c["output"]] = c["name"]
    
    # Build adjacency: name -> set of names it depends on
    deps = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        dep_names = set()
        for inp in c.get("inputs", []):
            if inp in output_to_name:
                dep_names.add(output_to_name[inp])
        deps[name] = dep_names
    
    # Topological sort
    ordered = []
    visited = set()
    temp = set()
    
    def visit(name):
        if name in temp:
            raise ValueError(f"cycle detected involving {name}")
        if name in visited:
            return
        temp.add(name)
        for d in deps.get(name, set()):
            visit(d)
        temp.remove(name)
        visited.add(name)
        ordered.append(name)
    
    for name in sorted(deps.keys()):
        visit(name)
    
    # Execute each component in order
    for name in ordered:
        cp = contract_map[name]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            raise FileNotFoundError(f"render.py not found for {name}")
        
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {name}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py to produce final_report.json
    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
