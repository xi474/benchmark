# Workflow 可观测性报告

- Trial：`MP15__VAeNGUC__env`
- Task：`MP15`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（54 节点 / 53 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：54；执行边：53（observed=0，inferred=53）
- Execution Trace Graph：`observed`；temporal_next 边 53，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_09e9595038014007a0ddc541 -> tool:dsh:lead:call_26838823324e4d22873bec96 -> tool:dsh:lead:call_731aba7b08264947b91ad530 -> tool:dsh:lead:call_d23f28a28632491ca60ef5ae -> tool:dsh:lead:call_8e4776909b264b918f9dfee4 -> tool:dsh:lead:call_531e212ee5114a8ab4cb67df -> tool:dsh:lead:call_2a57ea834df142649f999937 -> tool:dsh:lead:call_2a35dec3a5374ecaa474d849 -> tool:dsh:lead:call_69e08567360343e1be736a16 -> tool:dsh:lead:call_73ca864d4fbb4e5dbc112c79 -> tool:dsh:lead:call_02dca35189a7450486152add -> tool:dsh:lead:call_c06e7941857543b893fe2a34 -> tool:dsh:lead:call_b7fec159756748ae82017603 -> tool:dsh:lead:call_b47076980b1e46b296f3eca5 -> tool:dsh:lead:call_5da01687df064549a73a9a75 -> tool:dsh:lead:call_b2127d0ca46649f48169d7f1 -> tool:dsh:lead:call_f4ae878d48974082a3c91937 -> tool:dsh:lead:call_c5b70455527c4050867c6cf4 -> tool:dsh:lead:call_3a71afd95323464c836e0b97 -> tool:dsh:lead:call_6e0bc1077c614006aaaa40a2 -> tool:dsh:lead:call_ebc6ce3a5dcb444fa33c922b -> tool:dsh:lead:call_9d31ee0130a244d7b783a843 -> tool:dsh:lead:call_c16c31f6ad934888afdc95ad -> tool:dsh:lead:call_892827e622984e1285411b47 -> tool:dsh:lead:call_4073b040272d47b0940420c5 -> tool:dsh:lead:call_f260fb45a5de43199c943512 -> tool:dsh:lead:call_8529c4eec36e4c7fa25700ee -> tool:dsh:lead:call_27734edfa11e439d9907527d -> tool:dsh:lead:call_49080153131c4ddda5737ab0 -> tool:dsh:lead:call_7f18f61e5d434b0da9e78232 -> tool:dsh:lead:call_5d3fad4fc46f47c8952fef5a -> tool:dsh:lead:call_95286eb6285443e396833e55 -> tool:dsh:lead:call_0ea45d9fc10148598a0f226c -> tool:dsh:lead:call_a57f606a91c24e80a5ef7c3c -> tool:dsh:lead:call_6b982e683b2345819298b2b6 -> tool:dsh:lead:call_38a0920024924637a550b5e0 -> tool:dsh:lead:call_cc84af0da3034570972b33d0 -> tool:dsh:lead:call_91d74082563d46bc9a44aa59 -> tool:dsh:lead:call_14ad29d792a648b2b89367fd -> tool:dsh:lead:call_6f711a65f0444989a93fe24f -> tool:dsh:lead:call_ddf436ccc20642ec9896ad59 -> tool:dsh:lead:call_07fb964167d7431591832cae -> tool:dsh:lead:call_f1b2b7a1da6243d3bcbe7630 -> tool:dsh:lead:call_fb3769e229604c85ac6a3d6d -> tool:dsh:lead:call_624e078d57dc46a48decd8f2 -> tool:dsh:lead:call_fbf40a683828476293962d0f -> tool:dsh:lead:call_8cc01de2f1714b9399f761a3 -> tool:dsh:lead:call_b87ec70df40945ee99732353 -> tool:dsh:lead:call_466452bff7f041aca14c8ab2 -> tool:dsh:lead:call_ef26e299ba0b48119a141dc1 -> tool:dsh:lead:call_c6be99beb2e34152b386fcaa -> tool:dsh:lead:call_c6fefdd853df4e649f8cef00 -> tool:dsh:lead:call_c4d5b8d8779541dab65a01d7
- 关键路径耗时：1.277
- Makespan：304.338
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
