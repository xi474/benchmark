import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Build component result from root and contract path."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    
    output_path = root / contract["output"]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )
    
    return result


if __name__ == "__main__":
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parents[1]
    contract_path = script_dir / "contract.json"
    build_component(root, contract_path)
