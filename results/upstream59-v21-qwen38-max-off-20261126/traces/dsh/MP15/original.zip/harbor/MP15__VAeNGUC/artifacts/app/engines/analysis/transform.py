import ast


def transform(payloads, contract):
    """Join import definitions with usage data from ordinary, annotation, and comment analyses.
    
    Inputs: source, ordinary_uses, annotation_uses, type_comment_uses
    """
    if len(payloads) != 4:
        raise ValueError("expected 4 payloads")
    
    source_payload = payloads[0]
    ordinary_result = payloads[1]
    annotation_result = payloads[2]
    comment_result = payloads[3]
    
    if not isinstance(source_payload, dict) or "source" not in source_payload:
        raise ValueError("missing source field")
    
    source = source_payload["source"]
    
    # Extract result objects - handle both raw result and wrapped format
    ordinary_uses = _get_uses(ordinary_result)
    annotation_uses = _get_uses(annotation_result)
    comment_uses = _get_uses(comment_result)
    
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e
    
    # Validate: no classes, async functions, nested functions, lambdas
    _validate_tree(tree)
    
    # Check for global/nonlocal
    _check_global_nonlocal(tree)
    
    # Collect imports per scope
    module_imports = {}  # bound_name -> {module, line}
    func_imports = {}    # func_name -> {bound_name -> {module, line}}
    
    _collect_imports(tree, module_imports, func_imports)
    
    # Collect local stores (parameters and assignments) per function
    func_local_stores = {}  # func_name -> set of names
    _collect_local_stores(tree, func_local_stores)
    
    # Build usage maps: for each use, determine which import it refers to
    # uses_by_import: (scope, bound_name) -> set of usage types
    uses_by_import = {}  # key: (scope, bound_name) -> {"ordinary": bool, "annotation": bool, "comment": bool}
    
    # Process ordinary uses
    for use in ordinary_uses:
        scope = use["scope"]
        name = use["name"]
        imp_key = _resolve_import(name, scope, module_imports, func_imports, func_local_stores)
        if imp_key is not None:
            if imp_key not in uses_by_import:
                uses_by_import[imp_key] = {"ordinary": False, "annotation": False, "comment": False}
            uses_by_import[imp_key]["ordinary"] = True
    
    # Process annotation uses
    for use in annotation_uses:
        scope = use["scope"]
        name = use["name"]
        imp_key = _resolve_import(name, scope, module_imports, func_imports, func_local_stores)
        if imp_key is not None:
            if imp_key not in uses_by_import:
                uses_by_import[imp_key] = {"ordinary": False, "annotation": False, "comment": False}
            uses_by_import[imp_key]["annotation"] = True
    
    # Process comment uses
    for use in comment_uses:
        scope = use["scope"]
        name = use["name"]
        imp_key = _resolve_import(name, scope, module_imports, func_imports, func_local_stores)
        if imp_key is not None:
            if imp_key not in uses_by_import:
                uses_by_import[imp_key] = {"ordinary": False, "annotation": False, "comment": False}
            uses_by_import[imp_key]["comment"] = True
    
    # Build imports list
    imports_list = []
    all_import_keys = set()
    
    # Add all defined imports
    for bound_name, info in module_imports.items():
        key = ("module", bound_name)
        all_import_keys.add(key)
    
    for func_name, imps in func_imports.items():
        for bound_name, info in imps.items():
            key = (func_name, bound_name)
            all_import_keys.add(key)
    
    for key in all_import_keys:
        scope, bound_name = key
        if scope == "module":
            info = module_imports[bound_name]
        else:
            info = func_imports[scope][bound_name]
        
        usage = uses_by_import.get(key, {"ordinary": False, "annotation": False, "comment": False})
        used_by = []
        if usage["ordinary"]:
            used_by.append("ordinary")
        if usage["annotation"]:
            used_by.append("annotation")
        if usage["comment"]:
            used_by.append("comment")
        
        imports_list.append({
            "scope": scope,
            "name": bound_name,
            "module": info["module"],
            "line": info["line"],
            "used_by": used_by
        })
    
    # Sort imports by (scope, line, name)
    imports_list.sort(key=lambda i: (i["scope"], i["line"], i["name"]))
    
    # Build unused list
    unused = []
    for imp in imports_list:
        if not imp["used_by"]:
            unused.append(f"{imp['scope']}:{imp['name']}")
    
    unused.sort()
    
    return {
        "name": contract["name"],
        "result": {
            "imports": imports_list,
            "unused": unused
        }
    }


def _get_uses(result_payload):
    """Extract uses list from a result payload (may be wrapped or raw)."""
    if isinstance(result_payload, dict):
        if "result" in result_payload and isinstance(result_payload["result"], dict):
            return result_payload["result"].get("uses", [])
        if "uses" in result_payload:
            return result_payload["uses"]
    return []


def _validate_tree(tree):
    """Validate no classes, async functions, nested functions, lambdas."""
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            raise ValueError("classes not supported")
        if isinstance(node, ast.AsyncFunctionDef):
            raise ValueError("async functions not supported")
        if isinstance(node, ast.Lambda):
            raise ValueError("lambdas not supported")
    
    # Check for nested functions
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            for child in ast.walk(node):
                if child is node:
                    continue
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    raise ValueError("nested functions not supported")


def _check_global_nonlocal(tree):
    """Check for global/nonlocal statements - raise ValueError if found."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Global):
            raise ValueError("global statement not supported")
        if isinstance(node, ast.Nonlocal):
            raise ValueError("nonlocal statement not supported")


def _collect_imports(tree, module_imports, func_imports):
    """Collect all import bindings per scope."""
    for stmt in tree.body:
        if isinstance(stmt, ast.Import):
            for alias in stmt.names:
                if alias.name == "*":
                    raise ValueError("star import not supported")
                bound_name = alias.asname if alias.asname else alias.name.split(".")[0]
                if bound_name in module_imports:
                    raise ValueError(f"duplicate import binding: {bound_name}")
                module_imports[bound_name] = {"module": alias.name, "line": stmt.lineno}
        
        elif isinstance(stmt, ast.ImportFrom):
            if stmt.level > 0:
                raise ValueError("relative import not supported")
            if stmt.module is None:
                raise ValueError("invalid from import")
            for alias in stmt.names:
                if alias.name == "*":
                    raise ValueError("star import not supported")
                bound_name = alias.asname if alias.asname else alias.name
                if bound_name in module_imports:
                    raise ValueError(f"duplicate import binding: {bound_name}")
                module_imports[bound_name] = {"module": stmt.module, "line": stmt.lineno}
        
        elif isinstance(stmt, ast.FunctionDef):
            func_name = stmt.name
            func_imports[func_name] = {}
            for body_stmt in stmt.body:
                if isinstance(body_stmt, ast.Import):
                    for alias in body_stmt.names:
                        if alias.name == "*":
                            raise ValueError("star import not supported")
                        bound_name = alias.asname if alias.asname else alias.name.split(".")[0]
                        if bound_name in func_imports[func_name]:
                            raise ValueError(f"duplicate import binding in {func_name}: {bound_name}")
                        func_imports[func_name][bound_name] = {"module": alias.name, "line": body_stmt.lineno}
                
                elif isinstance(body_stmt, ast.ImportFrom):
                    if body_stmt.level > 0:
                        raise ValueError("relative import not supported")
                    if body_stmt.module is None:
                        raise ValueError("invalid from import")
                    for alias in body_stmt.names:
                        if alias.name == "*":
                            raise ValueError("star import not supported")
                        bound_name = alias.asname if alias.asname else alias.name
                        if bound_name in func_imports[func_name]:
                            raise ValueError(f"duplicate import binding in {func_name}: {bound_name}")
                        func_imports[func_name][bound_name] = {"module": body_stmt.module, "line": body_stmt.lineno}


def _collect_local_stores(tree, func_local_stores):
    """Collect parameter names and assignment targets per function."""
    for stmt in tree.body:
        if isinstance(stmt, ast.FunctionDef):
            func_name = stmt.name
            stores = set()
            
            # Parameters
            all_args = list(stmt.args.args) + list(stmt.args.posonlyargs) + list(stmt.args.kwonlyargs)
            if stmt.args.vararg:
                all_args.append(stmt.args.vararg)
            if stmt.args.kwarg:
                all_args.append(stmt.args.kwarg)
            
            for arg in all_args:
                stores.add(arg.arg)
            
            # Assignment targets in function body
            for body_stmt in ast.walk(stmt):
                if body_stmt is stmt:
                    continue
                if isinstance(body_stmt, ast.Assign):
                    for target in body_stmt.targets:
                        if isinstance(target, ast.Name):
                            stores.add(target.id)
                elif isinstance(body_stmt, ast.AnnAssign):
                    if isinstance(body_stmt.target, ast.Name):
                        stores.add(body_stmt.target.id)
                elif isinstance(body_stmt, ast.For):
                    if isinstance(body_stmt.target, ast.Name):
                        stores.add(body_stmt.target.id)
                elif isinstance(body_stmt, ast.With):
                    for item in body_stmt.items:
                        if item.optional_vars and isinstance(item.optional_vars, ast.Name):
                            stores.add(item.optional_vars.id)
            
            func_local_stores[func_name] = stores


def _resolve_import(name, scope, module_imports, func_imports, func_local_stores):
    """Resolve a name usage to an import binding.
    
    Returns (scope, bound_name) tuple or None if not an import reference.
    """
    if scope == "module":
        # Module-level usage - only matches module imports
        if name in module_imports:
            return ("module", name)
        return None
    else:
        # Function scope usage
        func_name = scope
        
        # First check function-local imports
        if func_name in func_imports and name in func_imports[func_name]:
            return (func_name, name)
        
        # Check if locally shadowed (parameter or assignment store)
        if func_name in func_local_stores and name in func_local_stores[func_name]:
            # Shadowed by local variable - not an import reference
            return None
        
        # Fall back to module import
        if name in module_imports:
            return ("module", name)
        
        return None
