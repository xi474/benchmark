import ast


def transform(payloads, contract):
    """Extract annotation Load names from Python source.
    
    Extracts from AnnAssign.annotation and function parameter/return annotations.
    Top-level string forward annotations are re-parsed as expressions.
    Function signature annotations belong to module scope.
    Function body assignment annotations belong to that function.
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    payload = payloads[0]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source field")
    
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e
    
    uses = []
    seen = set()
    
    for stmt in tree.body:
        if isinstance(stmt, ast.AsyncFunctionDef):
            raise ValueError("async functions not supported")
        if isinstance(stmt, ast.ClassDef):
            raise ValueError("classes not supported")
        
        if isinstance(stmt, ast.FunctionDef):
            _validate_function(stmt)
            func_name = stmt.name
            
            # Function signature annotations belong to module scope
            # Return annotation
            if stmt.returns is not None:
                for name, line in _extract_annotation_loads(stmt.returns, source):
                    key = ("module", line, name)
                    if key not in seen:
                        seen.add(key)
                        uses.append({"scope": "module", "name": name, "line": line})
            
            # Argument annotations
            all_args = list(stmt.args.args) + list(stmt.args.posonlyargs) + list(stmt.args.kwonlyargs)
            if stmt.args.vararg:
                all_args.append(stmt.args.vararg)
            if stmt.args.kwarg:
                all_args.append(stmt.args.kwarg)
            
            for arg in all_args:
                if arg.annotation is not None:
                    for name, line in _extract_annotation_loads(arg.annotation, source):
                        key = ("module", line, name)
                        if key not in seen:
                            seen.add(key)
                            uses.append({"scope": "module", "name": name, "line": line})
            
            # Function body AnnAssign annotations belong to function scope
            for body_stmt in ast.walk(stmt):
                if body_stmt is stmt:
                    continue
                if isinstance(body_stmt, ast.AnnAssign):
                    for name, line in _extract_annotation_loads(body_stmt.annotation, source):
                        key = (func_name, line, name)
                        if key not in seen:
                            seen.add(key)
                            uses.append({"scope": func_name, "name": name, "line": line})
        
        elif isinstance(stmt, ast.AnnAssign):
            # Module-level annotated assignment - annotation belongs to module scope
            for name, line in _extract_annotation_loads(stmt.annotation, source):
                key = ("module", line, name)
                if key not in seen:
                    seen.add(key)
                    uses.append({"scope": "module", "name": name, "line": line})
    
    # Sort by (scope, line, name)
    uses.sort(key=lambda u: (u["scope"], u["line"], u["name"]))
    
    return {"name": contract["name"], "result": {"uses": uses}}


def _validate_function(func_node):
    """Validate function: no nested functions/classes/lambdas."""
    for node in ast.walk(func_node):
        if node is func_node:
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError("nested functions not supported")
        if isinstance(node, ast.ClassDef):
            raise ValueError("classes not supported")
        if isinstance(node, ast.Lambda):
            raise ValueError("lambdas not supported")


def _extract_annotation_loads(annotation_node, source):
    """Extract Load names from an annotation node.
    
    If the annotation is a string constant (forward reference), parse it as expression.
    """
    results = []
    
    if isinstance(annotation_node, ast.Constant) and isinstance(annotation_node.value, str):
        # Forward reference string - parse as expression
        fwd_str = annotation_node.value
        try:
            expr_tree = ast.parse(fwd_str, mode="eval")
        except SyntaxError as e:
            raise ValueError(f"bad forward annotation expression: {e}") from e
        
        for node in ast.walk(expr_tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                # Use the line of the original annotation node
                results.append((node.id, annotation_node.lineno))
        return results
    
    # Regular annotation - walk for Load names
    for node in ast.walk(annotation_node):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            results.append((node.id, node.lineno))
    
    return results
