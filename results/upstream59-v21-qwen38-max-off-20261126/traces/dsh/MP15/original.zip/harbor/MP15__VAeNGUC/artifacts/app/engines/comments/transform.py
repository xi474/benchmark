import ast
import re


def transform(payloads, contract):
    """Extract type comment Load names from Python source.
    
    Only supports # type: expressions on Assign statements.
    Function signature type_comment or for/with type comments raise ValueError.
    # type: ignore does not produce references.
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    payload = payloads[0]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source field")
    
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    
    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e
    
    uses = []
    seen = set()
    
    # Check for function signature type comments and for/with type comments
    _check_forbidden_type_comments(tree, source)
    
    # Process Assign statements with type comments
    for stmt in ast.walk(tree):
        if isinstance(stmt, ast.Assign) and stmt.type_comment is not None:
            tc = stmt.type_comment.strip()
            # Skip # type: ignore
            if tc == "ignore":
                continue
            
            # Parse the type comment as an expression
            try:
                expr_tree = ast.parse(tc, mode="eval")
            except SyntaxError as e:
                raise ValueError(f"bad type comment expression: {e}") from e
            
            line = stmt.lineno
            for node in ast.walk(expr_tree):
                if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                    key = (line, node.id)
                    if key not in seen:
                        seen.add(key)
                        uses.append({"scope": "module", "name": node.id, "line": line})
    
    # Sort by (scope, line, name)
    uses.sort(key=lambda u: (u["scope"], u["line"], u["name"]))
    
    return {"name": contract["name"], "result": {"uses": uses}}


def _check_forbidden_type_comments(tree, source):
    """Check for forbidden type comments (function signatures, for/with)."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.type_comment is not None:
                raise ValueError("function signature type_comment not supported")
        if isinstance(node, ast.For):
            if node.type_comment is not None:
                raise ValueError("for type comment not supported")
        if isinstance(node, ast.With):
            if node.type_comment is not None:
                raise ValueError("with type comment not supported")
