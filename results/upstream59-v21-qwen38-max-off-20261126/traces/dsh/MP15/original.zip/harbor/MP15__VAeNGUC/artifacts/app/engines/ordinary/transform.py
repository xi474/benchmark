import ast


def _collect_load_names(node):
    """Collect all Name(id, Load) from a node, excluding annotations and type comments."""
    names = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            names.append((child.id, child.lineno))
    return names


def _is_annotation_node(node):
    """Check if a node is an annotation (AnnAssign.annotation or function arg/return annotation)."""
    return False  # We handle this by not walking into annotations


def transform(payloads, contract):
    """Extract ordinary expression Load names from Python source.
    
    Only module-level and top-level function bodies (no classes, lambdas, async, nested).
    Excludes annotations, type comments, and string contents.
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    payload = payloads[0]
    if not isinstance(payload, dict) or "source" not in payload:
        raise ValueError("missing source field")
    
    source = payload["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e
    
    uses = []
    seen = set()
    
    # Process module-level statements
    for stmt in tree.body:
        if isinstance(stmt, ast.FunctionDef):
            # Validate: no async, no nested functions/classes
            if isinstance(stmt, ast.AsyncFunctionDef):
                raise ValueError("async functions not supported")
            _validate_function(stmt)
            # Collect Load names from function body only (not decorators/defaults at module scope)
            # Decorators and defaults are at module scope
            for dec in stmt.decorator_list:
                for name, line in _collect_ordinary_loads(dec):
                    key = ("module", line, name)
                    if key not in seen:
                        seen.add(key)
                        uses.append({"scope": "module", "name": name, "line": line})
            for default in stmt.args.defaults + stmt.args.kw_defaults:
                if default is not None:
                    for name, line in _collect_ordinary_loads(default):
                        key = ("module", line, name)
                        if key not in seen:
                            seen.add(key)
                            uses.append({"scope": "module", "name": name, "line": line})
            # Function body - collect loads excluding annotations
            func_name = stmt.name
            for body_stmt in stmt.body:
                for name, line in _collect_body_ordinary_loads(body_stmt):
                    key = (func_name, line, name)
                    if key not in seen:
                        seen.add(key)
                        uses.append({"scope": func_name, "name": name, "line": line})
        elif isinstance(stmt, ast.AsyncFunctionDef):
            raise ValueError("async functions not supported")
        elif isinstance(stmt, ast.ClassDef):
            raise ValueError("classes not supported")
        else:
            # Module-level statement - collect ordinary loads (exclude annotations)
            for name, line in _collect_module_level_ordinary_loads(stmt):
                key = ("module", line, name)
                if key not in seen:
                    seen.add(key)
                    uses.append({"scope": "module", "name": name, "line": line})
    
    # Sort by (scope, line, name)
    uses.sort(key=lambda u: (u["scope"], u["line"], u["name"]))
    
    return {"name": contract["name"], "result": {"uses": uses}}


def _validate_function(func_node):
    """Validate function: no nested functions/classes/lambdas, no async."""
    for node in ast.walk(func_node):
        if node is func_node:
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError("nested functions not supported")
        if isinstance(node, ast.ClassDef):
            raise ValueError("classes not supported")
        if isinstance(node, ast.Lambda):
            raise ValueError("lambdas not supported")


def _collect_ordinary_loads(node):
    """Collect Load names from a node, treating it as ordinary expression context."""
    results = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            results.append((child.id, child.lineno))
    return results


def _collect_module_level_ordinary_loads(stmt):
    """Collect ordinary loads from a module-level statement, excluding annotations and type comments."""
    results = []
    
    if isinstance(stmt, ast.AnnAssign):
        # AnnAssign: exclude the annotation, only process value
        if stmt.value is not None:
            results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    if isinstance(stmt, ast.Assign):
        # Regular assignment - collect all loads from value
        results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    if isinstance(stmt, ast.Import):
        # Import statements don't produce Load references
        return results
    
    if isinstance(stmt, ast.ImportFrom):
        # ImportFrom doesn't produce Load references
        return results
    
    if isinstance(stmt, ast.Expr):
        # Expression statement (could be docstring etc.)
        # But we need to check if it's a string (docstring) - strings don't count
        if isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str):
            return results
        results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    # For other statements, walk but skip annotation nodes
    for child in ast.iter_child_nodes(stmt):
        if isinstance(child, ast.AnnAssign):
            if child.value is not None:
                results.extend(_collect_ordinary_loads(child.value))
        else:
            results.extend(_collect_ordinary_loads(child))
    
    return results


def _collect_body_ordinary_loads(stmt):
    """Collect ordinary loads from a function body statement, excluding annotations."""
    results = []
    
    if isinstance(stmt, ast.AnnAssign):
        # Skip annotation, only process value
        if stmt.value is not None:
            results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    if isinstance(stmt, ast.Assign):
        results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    if isinstance(stmt, ast.Return):
        if stmt.value is not None:
            results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    if isinstance(stmt, ast.Expr):
        if isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str):
            return results
        results.extend(_collect_ordinary_loads(stmt.value))
        return results
    
    if isinstance(stmt, ast.Import):
        return results
    
    if isinstance(stmt, ast.ImportFrom):
        return results
    
    # Generic: walk children but skip annotations
    for child in ast.iter_child_nodes(stmt):
        if isinstance(child, ast.AnnAssign):
            if child.value is not None:
                results.extend(_collect_ordinary_loads(child.value))
        else:
            results.extend(_collect_ordinary_loads(child))
    
    return results
