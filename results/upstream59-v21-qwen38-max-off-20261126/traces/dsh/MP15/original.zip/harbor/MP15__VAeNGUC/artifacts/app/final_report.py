"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    if not core_path.is_file():
        raise ValueError("core_manifest.json not found")
    
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)
    
    # title
    title = "普通引用、注解和类型注释的导入分析"
    
    # component_count
    components = core.get("components", {})
    component_count = len(components)
    
    # sha256: serialize core with specific format, no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()
    
    # attention: components meeting any condition
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        # result.blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)
        
        # complete/checkout/committed/ok any explicitly false
        for field in ("complete", "checkout", "committed", "ok"):
            if field in result and result[field] is False:
                attention.add(comp_name)
                break
        
        # unavailable/missing/conflicts/unreachable any non-empty
        for field in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(field)
            if val is not None and val != [] and val != "" and val != {}:
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                    break
    
    attention_list = sorted(attention)
    
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list
    }
    
    output_path = ROOT / "outputs" / "final_report.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )


if __name__ == "__main__":
    main()
