"""Orchestrate all component builds based on contract dependencies."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    
    if not contracts:
        raise ValueError("no contracts found")
    
    # Build dependency graph from contract inputs
    # Each contract may depend on outputs of other contracts
    contract_map = {}  # name -> contract_path
    output_to_contract = {}  # output_path -> contract_name
    
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        contract_map[name] = cp
        output_to_contract[c["output"]] = name
    
    # Topological sort based on dependencies
    deps = {}  # name -> set of dependency names
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        dep_names = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep_names.add(output_to_contract[inp])
        deps[name] = dep_names
    
    # Kahn's algorithm for topological sort
    in_degree = {name: len(d) for name, d in deps.items()}
    queue = [name for name, deg in in_degree.items() if deg == 0]
    order = []
    
    while queue:
        queue.sort()  # deterministic order
        name = queue.pop(0)
        order.append(name)
        for other, dep_set in deps.items():
            if name in dep_set:
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)
    
    if len(order) != len(contracts):
        raise ValueError("dependency cycle detected")
    
    # Execute components in order
    for name in order:
        cp = contract_map[name]
        render_script = cp.with_name("render.py")
        if not render_script.is_file():
            raise ValueError(f"missing render.py for {name}")
        
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {name}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py
    integrate_script = ROOT / "integrate.py"
    if integrate_script.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py
    report_script = ROOT / "final_report.py"
    if report_script.is_file():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
