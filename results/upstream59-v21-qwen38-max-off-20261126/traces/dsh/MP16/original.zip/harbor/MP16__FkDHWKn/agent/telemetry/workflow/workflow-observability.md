# Workflow 可观测性报告

- Trial：`MP16__FkDHWKn__env`
- Task：`MP16`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（70 节点 / 69 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：70；执行边：69（observed=0，inferred=69）
- Execution Trace Graph：`observed`；temporal_next 边 69，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_b425e0ca7791411b9288cf37 -> tool:dsh:lead:call_54ab0eb2935146919c147cd8 -> tool:dsh:lead:call_26075eb2be454ce4a65b3b90 -> tool:dsh:lead:call_a23cf01835b04163bdcd56d2 -> tool:dsh:lead:call_a0d882ef4a0247c0bcad6760 -> tool:dsh:lead:call_4e1452e204414e5da26f724e -> tool:dsh:lead:call_4f71c08cf6074ec192922975 -> tool:dsh:lead:call_0596bb84972d4a2388a95e19 -> tool:dsh:lead:call_f920ee49f34a4c61b4b87b54 -> tool:dsh:lead:call_4871ee656ad44af1af392127 -> tool:dsh:lead:call_300a9c775b61412489666158 -> tool:dsh:lead:call_9761269c31cb4eed86182d99 -> tool:dsh:lead:call_e27d3ef676c2467990d66380 -> tool:dsh:lead:call_88666d9cc08a4cf98a135845 -> tool:dsh:lead:call_f51d56a02c7c4a8695f77c43 -> tool:dsh:lead:call_b09d2b409f8b4b308f7a6eb9 -> tool:dsh:lead:call_f10f6fa479e84f789a8144d8 -> tool:dsh:lead:call_6a141f51a9044ffdb8fb7137 -> tool:dsh:lead:call_a562aa371df14827b2a6623d -> tool:dsh:lead:call_e6914b425bd44c54ac5e506a -> tool:dsh:lead:call_53856a0cfbb849aea393e7f3 -> tool:dsh:lead:call_e7a401f6f1c248208478ad38 -> tool:dsh:lead:call_12d5b2b8ea404e38ad251755 -> tool:dsh:lead:call_480d1fb941fe49dc9540ae49 -> tool:dsh:lead:call_92563ceed0384da4bb5f790b -> tool:dsh:lead:call_451597198faa458b9143be15 -> tool:dsh:lead:call_b9419458234146d9bad5f3ae -> tool:dsh:lead:call_41aafd59a2084c16a5a17b67 -> tool:dsh:lead:call_0f4edfaa65534d0eabc77005 -> tool:dsh:lead:call_2517c9d99549497cba64a00f -> tool:dsh:lead:call_2234e6cc4336450c81dba4b2 -> tool:dsh:lead:call_0a218beb93dd45e1a7858df2 -> tool:dsh:lead:call_6cfb468e13904736b6f98069 -> tool:dsh:lead:call_106e4d93c72c4df9a09a67fb -> tool:dsh:lead:call_9f7815cf4b3b4c26a5c938ea -> tool:dsh:lead:call_81aa2e47b8b5435daced8ed5 -> tool:dsh:lead:call_35a8c6a27ec448709685b931 -> tool:dsh:lead:call_125713f91cce49668c2050cb -> tool:dsh:lead:call_f0868e60904a479d9bbacf99 -> tool:dsh:lead:call_6a41070b2b604cd7a34f2b24 -> tool:dsh:lead:call_ab230b07ac5e476681ea122a -> tool:dsh:lead:call_ff02d4347bcd402c9158a69b -> tool:dsh:lead:call_35ab2deb5acd43adb6f2794a -> tool:dsh:lead:call_82d351dd20ff4ae388ef404b -> tool:dsh:lead:call_30105af62fce4cd8998b8dd7 -> tool:dsh:lead:call_97ab2798e0844181b6c3dbdb -> tool:dsh:lead:call_8bd5fd559b7943f2b1244174 -> tool:dsh:lead:call_3f7d00ac12e14127a5068dee -> tool:dsh:lead:call_04c35d62a4fb49bf9521ac37 -> tool:dsh:lead:call_44ce8e008d254a4db02d3079 -> tool:dsh:lead:call_98d752b0322140368f34db13 -> tool:dsh:lead:call_500a33fab4fa4b60a965cc7c -> tool:dsh:lead:call_fb8ee28115a44001a9269d71 -> tool:dsh:lead:call_4a0da64c9a8d43bda1ecf7a8 -> tool:dsh:lead:call_38efeea7fd2845308ce4f32e -> tool:dsh:lead:call_27484d8eb1cf42408131e3e7 -> tool:dsh:lead:call_ca8aea1ea2874c96af49d770 -> tool:dsh:lead:call_d2156e162f144dcb9587c96f -> tool:dsh:lead:call_717ad8b9f964494b8dc6bc9a -> tool:dsh:lead:call_d32f3f2bedc342c2ab37ecac -> tool:dsh:lead:call_e9f181775ccd4324a5178ee1 -> tool:dsh:lead:call_c232795e501c4ed3bd5f2c87 -> tool:dsh:lead:call_7201906632ee47b7b0c84cda -> tool:dsh:lead:call_c2dc997d54004753a0807643 -> tool:dsh:lead:call_8b2d44bd5997453a92aec787 -> tool:dsh:lead:call_17cc0febb320487ea83e24c3 -> tool:dsh:lead:call_502160c8aba643848945f585 -> tool:dsh:lead:call_4196355f666f47e0bc611462 -> tool:dsh:lead:call_a6a77523d048427185cecb31
- 关键路径耗时：1.132
- Makespan：308.336
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
