import json
import sys
from pathlib import Path


def _get_loaders():
    """Get load_payload and transform, handling both package and script contexts."""
    try:
        from .model import load_payload
        from .transform import transform
    except ImportError:
        from model import load_payload
        from transform import transform
    return load_payload, transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    load_payload, transform = _get_loaders()
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    
    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    
    return result


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    sys.path.insert(0, str(here))
    contract_path = here / 'contract.json'
    build_component(root, contract_path)
