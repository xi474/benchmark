import re


def _replace_aliases_in_type(type_str, aliases):
    """Replace standalone identifiers in type string with alias qualified names.
    
    Only replace identifiers that are NOT immediately adjacent to a dot (i.e., not already qualified).
    An identifier is 'standalone' if it's not preceded by '.' and not followed by '.'.
    """
    if type_str is None:
        return None
    
    # Find all identifiers in the type string
    # We need to replace only those that are not part of a dotted path
    # Strategy: use regex to find identifiers and check context
    
    def replacer(match):
        start = match.start()
        end = match.end()
        ident = match.group(0)
        
        # Check if preceded by '.' (part of qualified name like base.Item)
        if start > 0 and type_str[start - 1] == '.':
            return ident
        
        # Check if followed by '.' (this is a module/package prefix, not a bare type)
        if end < len(type_str) and type_str[end] == '.':
            return ident
        
        # This is a standalone identifier - check aliases
        if ident in aliases:
            return aliases[ident]
        return ident
    
    # Match Python identifiers
    result = re.sub(r'[A-Za-z_]\w*', replacer, type_str)
    return result


def transform(payloads, contract):
    """Process api_documentation operation.
    
    Inputs in order: overload_signatures result, parameter_docs result, inherited_doc result.
    Each input is the full {name, result} envelope from upstream.
    
    Select provider's parameter docs, replace standalone identifiers in type
    using provider's aliases, return combined document.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    sig_payload = payloads[0]
    param_payload = payloads[1]
    inherit_payload = payloads[2]
    
    # Extract results from envelopes
    if isinstance(sig_payload, dict) and 'result' in sig_payload and 'name' in sig_payload:
        sig_result = sig_payload['result']
    else:
        sig_result = sig_payload
    
    if isinstance(param_payload, dict) and 'result' in param_payload and 'name' in param_payload:
        param_result = param_payload['result']
    else:
        param_result = param_payload
    
    if isinstance(inherit_payload, dict) and 'result' in inherit_payload and 'name' in inherit_payload:
        inherit_result = inherit_payload['result']
    else:
        inherit_result = inherit_payload
    
    overloads = sig_result.get('overloads', [])
    docs = param_result.get('docs', {})
    provider = inherit_result.get('provider')
    namespace = inherit_result.get('namespace')
    aliases = inherit_result.get('aliases', {})
    
    # Get provider's parameter docs
    parameters = []
    if provider is not None and provider in docs:
        provider_params = docs[provider]
        for p in provider_params:
            new_type = _replace_aliases_in_type(p.get('type'), aliases)
            parameters.append({
                "name": p["name"],
                "type": new_type,
                "description": p.get("description", "")
            })
    
    result = {
        "overloads": overloads,
        "provider": provider,
        "namespace": namespace,
        "parameters": parameters
    }
    return {"name": contract["name"], "result": result}
