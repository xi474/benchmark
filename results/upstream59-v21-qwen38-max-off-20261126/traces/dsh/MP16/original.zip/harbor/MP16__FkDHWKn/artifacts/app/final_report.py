"""Generate final_report.json from core_manifest.json.

Fields:
- title: exact string 'API 文档的签名、参数与继承信息聚合'
- component_count: number of keys in components
- sha256: SHA256 hex of the compact JSON serialization of the full core object
- attention: sorted list of component names meeting any attention condition
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    
    components = core.get('components', {})
    
    # Title
    title = 'API 文档的签名、参数与继承信息聚合'
    
    # Component count
    component_count = len(components)
    
    # SHA256 of compact JSON (no trailing newline)
    compact = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    )
    sha256 = hashlib.sha256(compact.encode('utf-8')).hexdigest()
    
    # Attention: components meeting any condition
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        # result.blocked explicitly true
        if result.get('blocked') is True:
            attention.add(name)
        
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0:
                # Non-empty check: for lists/dicts/strings, check truthiness
                # But 0/null should not trigger per spec ("false与0/null不混同")
                # Actually spec says these fields being "non-empty" triggers
                # For lists: non-empty list; for dicts: non-empty dict; for strings: non-empty string
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, bool) and val:
                    # bool true is non-empty? Spec says "非空" which typically means
                    # non-empty collection. But let's be safe - bool is not a collection
                    pass
    
    attention = sorted(attention)
    
    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention
    }
    
    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
