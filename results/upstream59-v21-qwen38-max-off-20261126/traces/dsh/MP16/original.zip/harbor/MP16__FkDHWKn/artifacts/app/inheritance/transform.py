def transform(payloads, contract):
    """Process inherited_doc operation.
    
    Input has objects with id, doc, namespace, aliases, mro and a target.
    Candidate order: target first, then its mro (already linearized).
    Take the first object whose doc.strip() is non-empty.
    Return {provider: id or null, namespace: str or null, aliases: alias map}.
    If no doc found, provider=null, namespace=null, aliases={}.
    Cannot use subclass namespace to resolve parent docs.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    payload = payloads[0]
    
    if 'objects' not in payload:
        raise ValueError("missing 'objects' field")
    if 'target' not in payload:
        raise ValueError("missing 'target' field")
    
    objects = payload['objects']
    target = payload['target']
    
    if not isinstance(objects, list):
        raise ValueError("'objects' must be a list")
    if not isinstance(target, str):
        raise ValueError("'target' must be a string")
    
    # Build lookup by id
    obj_map = {}
    for obj in objects:
        if 'id' not in obj:
            raise ValueError("missing 'id' in object")
        obj_map[obj['id']] = obj
    
    if target not in obj_map:
        raise ValueError(f"target '{target}' not found in objects")
    
    target_obj = obj_map[target]
    
    # Build candidate list: target first, then mro
    candidates = [target]
    mro = target_obj.get('mro', [])
    if not isinstance(mro, list):
        raise ValueError("'mro' must be a list")
    candidates.extend(mro)
    
    # Find first candidate with non-empty doc
    provider_id = None
    provider_namespace = None
    provider_aliases = {}
    
    for cand_id in candidates:
        if cand_id not in obj_map:
            raise ValueError(f"MRO reference '{cand_id}' not found in objects")
        cand = obj_map[cand_id]
        doc = cand.get('doc', '')
        if not isinstance(doc, str):
            raise ValueError("'doc' must be a string")
        if doc.strip():
            provider_id = cand_id
            provider_namespace = cand.get('namespace')
            aliases = cand.get('aliases', {})
            if not isinstance(aliases, dict):
                raise ValueError("'aliases' must be an object")
            provider_aliases = aliases
            break
    
    result = {
        "provider": provider_id,
        "namespace": provider_namespace,
        "aliases": provider_aliases
    }
    return {"name": contract["name"], "result": result}
