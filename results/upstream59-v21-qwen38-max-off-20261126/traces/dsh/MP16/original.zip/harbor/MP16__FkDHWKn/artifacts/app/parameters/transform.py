import re


def _parse_doc(doc_str):
    """Parse a docstring for :param and :type directives.
    
    Supports:
      :param name: description
      :param TYPE name: description
      :type name: TYPE
    
    Returns list of {name, type, description} sorted by name.
    """
    params = {}  # name -> {type, description}
    types = {}   # name -> type

    lines = doc_str.split('\n')
    for line in lines:
        stripped = line.strip()
        
        # Try :type name: TYPE
        type_match = re.match(r'^:type\s+(\w+)\s*:\s*(.*)', stripped)
        if type_match:
            name = type_match.group(1)
            type_val = type_match.group(2).strip()
            if name in types:
                raise ValueError(f"duplicate :type for '{name}'")
            types[name] = type_val
            continue
        
        # Try :param [TYPE] name: description
        param_match = re.match(r'^:param\s+(.+?):\s*(.*)', stripped)
        if param_match:
            param_part = param_match.group(1).strip()
            description = param_match.group(2).strip()
            
            # Determine if there's a TYPE before the name
            # The name is always the last token (Python identifier)
            # TYPE can contain spaces and balanced parentheses
            # We need to find the last identifier as the name
            
            # Strategy: find the rightmost valid Python identifier
            # that is preceded by either start or whitespace
            tokens = _split_param_tokens(param_part)
            if len(tokens) == 1:
                # Just name, no type
                name = tokens[0]
                inline_type = None
            elif len(tokens) == 2:
                # TYPE name
                inline_type = tokens[0]
                name = tokens[1]
            else:
                raise ValueError(f"invalid :param directive: {stripped}")
            
            if not re.match(r'^[A-Za-z_]\w*$', name):
                raise ValueError(f"invalid parameter name: {name}")
            
            if name in params:
                raise ValueError(f"duplicate :param for '{name}'")
            
            params[name] = {"type": inline_type, "description": description}
            continue
        
        # Non-matching lines are ignored (unless they look like bad directives)
        # Check for malformed :param or :type
        if stripped.startswith(':param') or stripped.startswith(':type'):
            # It started with :param or :type but didn't match - could be malformed
            # Actually per spec: "坏指令ValueError"
            # But we need to be careful - only if it looks like an attempt at a directive
            # Let's check more carefully
            if stripped.startswith(':param ') or stripped.startswith(':type '):
                # It has the prefix but didn't match our patterns - bad directive
                raise ValueError(f"bad directive: {stripped}")

    # Merge types into params; type-only entries get description=""
    all_names = set(params.keys()) | set(types.keys())
    result = []
    for name in sorted(all_names):
        p = params.get(name, {})
        t = types.get(name)
        
        # Explicit :type overrides inline TYPE
        final_type = t if t is not None else p.get("type")
        description = p.get("description", "")
        
        result.append({
            "name": name,
            "type": final_type,
            "description": description
        })
    
    return result


def _split_param_tokens(param_part):
    """Split ':param TYPE name' or ':param name' into tokens.
    
    TYPE can contain parentheses and dots, e.g. 'dict(str, str)'.
    Name is always the last simple identifier.
    """
    # We need to handle types like "dict(str, str)" which contain spaces
    # Strategy: find the last whitespace-separated token that is a valid identifier
    # Everything before it is the type
    
    # First, try simple split
    parts = param_part.split()
    if len(parts) == 1:
        return parts
    
    # The last part should be the name (simple identifier)
    # But the type might have spaces inside parentheses
    # Walk backwards to find where the name starts
    
    # Rebuild: scan from the end, the last identifier is the name
    # Everything before is the type
    
    # Simple approach: the name is the last word that matches identifier pattern
    # and is NOT inside parentheses
    
    # Track parenthesis depth from right to left
    depth = 0
    i = len(param_part) - 1
    
    # Skip trailing whitespace
    while i >= 0 and param_part[i] == ' ':
        i -= 1
    
    # Now find the end of the name (last identifier)
    name_end = i + 1
    while i >= 0 and (param_part[i].isalnum() or param_part[i] == '_'):
        i -= 1
    name_start = i + 1
    
    name = param_part[name_start:name_end]
    
    if not name or not re.match(r'^[A-Za-z_]\w*$', name):
        raise ValueError(f"cannot extract parameter name from: {param_part}")
    
    # Everything before name_start (stripped) is the type
    type_part = param_part[:name_start].strip()
    
    if type_part:
        # Validate balanced parentheses in type
        depth = 0
        for ch in type_part:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth < 0:
                    raise ValueError(f"unbalanced parentheses in type: {type_part}")
        if depth != 0:
            raise ValueError(f"unbalanced parentheses in type: {type_part}")
        return [type_part, name]
    else:
        return [name]


def transform(payloads, contract):
    """Process parameter_docs operation."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    payload = payloads[0]
    
    if 'objects' not in payload:
        raise ValueError("missing 'objects' field")
    
    objects = payload['objects']
    if not isinstance(objects, list):
        raise ValueError("'objects' must be a list")
    
    docs = {}
    for obj in objects:
        if 'id' not in obj:
            raise ValueError("missing 'id' in object")
        if 'doc' not in obj:
            raise ValueError("missing 'doc' in object")
        
        obj_id = obj['id']
        doc_str = obj['doc']
        
        if not isinstance(doc_str, str):
            raise ValueError("'doc' must be a string")
        
        parsed = _parse_doc(doc_str)
        docs[obj_id] = parsed
    
    result = {"docs": docs}
    return {"name": contract["name"], "result": result}
