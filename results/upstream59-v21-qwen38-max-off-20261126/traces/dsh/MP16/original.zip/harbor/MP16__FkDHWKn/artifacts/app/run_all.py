"""Orchestrate all component builds based on contract.json files.

Discovers all contract.json files (excluding outputs/), resolves dependencies
by checking if inputs reference other component outputs, and executes in
topological order. Then runs integrate.py to produce core_manifest.json.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def resolve_order(contracts):
    """Topological sort of contracts based on input dependencies.
    
    Each contract's inputs may reference outputs of other contracts.
    We need to build those first.
    """
    # Map output paths to contract paths
    output_to_contract = {}
    contract_map = {}
    for cp in contracts:
        c = load_contract(cp)
        contract_map[cp] = c
        output_to_contract[c['output']] = cp
    
    # Build dependency graph
    deps = {}  # cp -> set of cp it depends on
    for cp in contracts:
        c = contract_map[cp]
        deps[cp] = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                if dep_cp != cp:
                    deps[cp].add(dep_cp)
    
    # Topological sort (Kahn's algorithm)
    in_degree = {cp: 0 for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            in_degree[cp] += 1  # This is wrong, let me fix
    
    # Recompute properly
    in_degree = {cp: 0 for cp in contracts}
    reverse_deps = {cp: set() for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            reverse_deps[d].add(cp)
            in_degree[cp] += 1
    
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    order = []
    while queue:
        queue.sort()  # deterministic ordering
        cp = queue.pop(0)
        order.append(cp)
        for dependent in reverse_deps[cp]:
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
    
    if len(order) != len(contracts):
        raise ValueError("circular dependency detected among contracts")
    
    return order


def main():
    contracts = discover_contracts()
    if not contracts:
        raise ValueError("no contracts found")
    
    order = resolve_order(contracts)
    
    for cp in order:
        # Run the component's render.py as a subprocess
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            raise FileNotFoundError(f"render.py not found for {cp}")
        
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {render_py}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    result = subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: integrate.py", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    
    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    result = subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: final_report.py", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
