import ast


def _parse_signature(sig_str):
    """Parse a Python function signature string (without def keyword) into structured form."""
    # Wrap in a dummy function definition so ast can parse it
    wrapped = f"def {sig_str}: pass"
    try:
        tree = ast.parse(wrapped)
    except SyntaxError as e:
        raise ValueError(f"invalid signature: {sig_str}") from e

    func_def = tree.body[0]
    if not isinstance(func_def, ast.FunctionDef):
        raise ValueError(f"not a function definition: {sig_str}")

    name = func_def.name

    args = func_def.args
    parameters = []

    # Positional-only args (before /)
    for i, arg in enumerate(args.posonlyargs):
        annotation = ast.unparse(arg.annotation) if arg.annotation else None
        # Check for default value
        # posonlyargs defaults are in args.defaults, aligned to the end of (posonlyargs + args.args)
        default = None
        # defaults apply to the last N of (posonlyargs + args)
        total_pos = len(args.posonlyargs) + len(args.args)
        num_defaults = len(args.defaults)
        idx_in_total = i  # index in posonlyargs
        default_idx = idx_in_total - (total_pos - num_defaults)
        if default_idx >= 0 and default_idx < num_defaults:
            default = ast.unparse(args.defaults[default_idx])
        parameters.append({
            "name": arg.arg,
            "kind": "posonly",
            "annotation": annotation,
            "default": default
        })

    # Regular positional args
    offset = len(args.posonlyargs)
    for i, arg in enumerate(args.args):
        annotation = ast.unparse(arg.annotation) if arg.annotation else None
        default = None
        total_pos = len(args.posonlyargs) + len(args.args)
        num_defaults = len(args.defaults)
        idx_in_total = offset + i
        default_idx = idx_in_total - (total_pos - num_defaults)
        if default_idx >= 0 and default_idx < num_defaults:
            default = ast.unparse(args.defaults[default_idx])
        parameters.append({
            "name": arg.arg,
            "kind": "positional",
            "annotation": annotation,
            "default": default
        })

    # *args (vararg)
    if args.vararg:
        annotation = ast.unparse(args.vararg.annotation) if args.vararg.annotation else None
        parameters.append({
            "name": args.vararg.arg,
            "kind": "vararg",
            "annotation": annotation,
            "default": None
        })

    # Keyword-only args
    for i, arg in enumerate(args.kwonlyargs):
        annotation = ast.unparse(arg.annotation) if arg.annotation else None
        default = None
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            default = ast.unparse(args.kw_defaults[i])
        parameters.append({
            "name": arg.arg,
            "kind": "kwonly",
            "annotation": annotation,
            "default": default
        })

    # **kwargs (kwarg)
    if args.kwarg:
        annotation = ast.unparse(args.kwarg.annotation) if args.kwarg.annotation else None
        parameters.append({
            "name": args.kwarg.arg,
            "kind": "kwarg",
            "annotation": annotation,
            "default": None
        })

    # Return annotation
    returns = ast.unparse(func_def.returns) if func_def.returns else None

    return {
        "name": name,
        "parameters": parameters,
        "returns": returns
    }


def transform(payloads, contract):
    """Process overload_signatures operation."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    payload = payloads[0]

    if 'overloads' not in payload:
        raise ValueError("missing 'overloads' field")

    overloads_raw = payload['overloads']
    if not isinstance(overloads_raw, list):
        raise ValueError("'overloads' must be a list")

    overloads = []
    for sig_str in overloads_raw:
        if not isinstance(sig_str, str):
            raise ValueError("each overload must be a string")
        parsed = _parse_signature(sig_str)
        overloads.append(parsed)

    result = {"overloads": overloads}
    return {"name": contract["name"], "result": result}
