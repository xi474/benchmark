# Workflow 可观测性报告

- Trial：`MP17__ZqVAUBA__env`
- Task：`MP17`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（63 节点 / 62 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：63；执行边：62（observed=0，inferred=62）
- Execution Trace Graph：`observed`；temporal_next 边 62，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_4b0a039d86094d388fbc348a -> tool:dsh:lead:call_a9c677fff2e848b78e55f149 -> tool:dsh:lead:call_f604490f2fd647ebb6c6c977 -> tool:dsh:lead:call_89f91b9b6226462caa7c8d92 -> tool:dsh:lead:call_02b876b4641b49f3907f8441 -> tool:dsh:lead:call_c17b9182d4dd43a1b4da70e9 -> tool:dsh:lead:call_2ce0b93e31c041dfb1c02651 -> tool:dsh:lead:call_1b8f7be0cf2e490face71270 -> tool:dsh:lead:call_1bb79eaf092e41feac3e8dd8 -> tool:dsh:lead:call_6873bb33a1a84620a9d7a8cb -> tool:dsh:lead:call_8a7ada901cf1415a8d7d6bc1 -> tool:dsh:lead:call_fbae3250c6be4fc185de15fa -> tool:dsh:lead:call_7ee180023c3e4944a932f4e3 -> tool:dsh:lead:call_d91d814e6e7b4c0e9b6bab77 -> tool:dsh:lead:call_48f5cc943ebb488d97ee74c4 -> tool:dsh:lead:call_24fe8782fd6d478ca4520c4a -> tool:dsh:lead:call_f26f7b4e8aa74906b2d244ad -> tool:dsh:lead:call_9b1fc7e0f1e14ecabcbe2957 -> tool:dsh:lead:call_9297446c8fbc45079f90eb74 -> tool:dsh:lead:call_21841aba73944cca98e21763 -> tool:dsh:lead:call_b1ad78a21a8a443abcfe4120 -> tool:dsh:lead:call_349a43f4e1fc45ff9ae306fd -> tool:dsh:lead:call_40900bdacacd4029ba410f1f -> tool:dsh:lead:call_3808841ec09141fb9d729534 -> tool:dsh:lead:call_54661594ef1b489bbb8898dd -> tool:dsh:lead:call_0ed2df583b734d129cf02f17 -> tool:dsh:lead:call_860f9335aa754ebfba3d9073 -> tool:dsh:lead:call_5e83f073901a40349303b3ac -> tool:dsh:lead:call_f6e61ad36ad54cc79337cd8b -> tool:dsh:lead:call_4cfaea5ca149415c9d3f13a8 -> tool:dsh:lead:call_7d80c70b4036451ea9594362 -> tool:dsh:lead:call_cd4dfb0c2b754c53808b3c7b -> tool:dsh:lead:call_cd0b6b8c238b4ed49a12ab38 -> tool:dsh:lead:call_b4f68ebab34b4f3fa7a41cd8 -> tool:dsh:lead:call_c125c1ec93ca4926ab7eff54 -> tool:dsh:lead:call_0c1738e813ac41e9901ca6d8 -> tool:dsh:lead:call_9ed2443cb39c43b88aabfce2 -> tool:dsh:lead:call_17104a02280345178cee8460 -> tool:dsh:lead:call_cbed030cb97a4bc58aab9132 -> tool:dsh:lead:call_d6c1c7e138ef4bf2a13f9414 -> tool:dsh:lead:call_218b849864124d89b1f91a0c -> tool:dsh:lead:call_075ab5032f2d420f98a46c4d -> tool:dsh:lead:call_7d502720d2964a2fa32c6d47 -> tool:dsh:lead:call_673e2480d34843be930994bb -> tool:dsh:lead:call_09b64beca0cd46f7967f1720 -> tool:dsh:lead:call_dd183d5064ed45ac9368de1a -> tool:dsh:lead:call_23ebaa62fb844228bad1176b -> tool:dsh:lead:call_18985cda60ad44ed9c8a5047 -> tool:dsh:lead:call_6d0d82ba39fe47e987750f38 -> tool:dsh:lead:call_2894db27991a407680f608c9 -> tool:dsh:lead:call_fe18106537c74f0e83893ba9 -> tool:dsh:lead:call_410a09ed51ac4fb49afb77cc -> tool:dsh:lead:call_3788c6120c75406cbf7b314e -> tool:dsh:lead:call_9376c6408db044b9b0c5bc4f -> tool:dsh:lead:call_b20ab56c86c0468e83680542 -> tool:dsh:lead:call_6b286a0d02824140bfc6f5d0 -> tool:dsh:lead:call_152d9af607a5483eb6e4388f -> tool:dsh:lead:call_a1f4be23056f4325a12ada0e -> tool:dsh:lead:call_9f99a85469264b43812f6079 -> tool:dsh:lead:call_ec33725afe5e4302a61d5087 -> tool:dsh:lead:call_ad107f8f4c8e454db23e06d8 -> tool:dsh:lead:call_976d8732509541cf93f85d27
- 关键路径耗时：1.447
- Makespan：229.741
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
