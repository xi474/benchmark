import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs from root per contract, run transform, write output."""
    root = Path(root)
    contract_path = Path(contract_path)

    # Ensure the component directory is on sys.path for local imports
    pkg_dir = str(contract_path.resolve().parent)
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)
    root_str = str(root.resolve())
    if root_str not in sys.path:
        sys.path.insert(0, root_str)

    from model import load_payload
    from transform import transform

    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )
    return result


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    contract_path = Path(__file__).resolve().parent / 'contract.json'
    build_component(root, contract_path)
