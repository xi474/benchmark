import re


def transform(payloads, contract):
    """multipart_body: assemble multipart/form-data body from snapshot + encoding."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    # payloads[0] = original snapshot (case.json) - used for boundary validation
    snapshot = payloads[0]
    # payloads[1] = multipart_encoding result
    enc_data = payloads[1]

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be object")
    if not isinstance(enc_data, dict):
        raise ValueError("encoding data must be object")

    # Get boundary from snapshot
    boundary = snapshot.get('boundary')
    if boundary is None:
        raise ValueError("missing boundary in snapshot")
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("boundary must be non-empty string")
    if not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError("boundary must be alphanumeric and hyphens only")

    # Unwrap encoding result
    if 'result' in enc_data and 'name' in enc_data:
        enc_result = enc_data['result']
    else:
        enc_result = enc_data

    if 'parts' not in enc_result:
        raise ValueError("missing 'parts' in encoding data")

    parts = enc_result['parts']
    boundary_bytes = boundary.encode('ascii')

    # Check that boundary bytes don't appear in any payload
    for part in parts:
        payload_hex = part.get('payload_hex', '')
        payload_bytes = bytes.fromhex(payload_hex)
        if boundary_bytes in payload_bytes:
            raise ValueError("boundary found in payload data")

    # Build body
    chunks = []
    for part in parts:
        name = part['name']
        filename = part.get('filename')
        mimetype = part['mimetype']
        encoding = part['encoding']
        payload_hex = part['payload_hex']
        payload_bytes = bytes.fromhex(payload_hex)

        # --boundary\r\n
        chunks.append(b'--' + boundary_bytes + b'\r\n')

        # Content-Transfer-Encoding header for base64
        if encoding == 'base64':
            chunks.append(b'Content-Transfer-Encoding: base64\r\n')

        # Content-Type header
        chunks.append(b'Content-Type: ' + mimetype.encode('ascii') + b'\r\n')

        # Content-Disposition header
        disp = b'Content-Disposition: form-data; name="' + name.encode('utf-8') + b'"'
        if filename is not None:
            disp += b'; filename="' + filename.encode('utf-8') + b'"'
        chunks.append(disp + b'\r\n')

        # Empty line separator
        chunks.append(b'\r\n')

        # Payload
        chunks.append(payload_bytes)

        # CRLF after payload
        chunks.append(b'\r\n')

    # Closing boundary
    chunks.append(b'--' + boundary_bytes + b'--\r\n')

    body = b''.join(chunks)
    content_type = f'multipart/form-data; boundary={boundary}'

    return {
        'name': contract['name'],
        'result': {
            'content_type': content_type,
            'body_hex': body.hex(),
        },
    }
