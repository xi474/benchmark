import base64


def _base64_fold(data_bytes):
    """Base64 encode bytes and fold at 76 ASCII chars per line with CRLF between lines.
    No trailing CRLF after the last line."""
    encoded = base64.b64encode(data_bytes).decode('ascii')
    lines = []
    for i in range(0, len(encoded), 76):
        lines.append(encoded[i:i+76])
    return '\r\n'.join(lines)


def transform(payloads, contract):
    """multipart_encoding: add payload_hex to each part based on encoding."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("input must be object")
    if 'result' in inp and 'name' in inp:
        # Unwrap from component envelope
        parts_data = inp['result']
    else:
        parts_data = inp

    if 'parts' not in parts_data:
        raise ValueError("missing 'parts' key")

    parts_in = parts_data['parts']
    parts_out = []

    for part in parts_in:
        encoding = part.get('encoding')
        hex_str = part.get('hex')
        if encoding is None:
            raise ValueError("missing encoding in part")
        if hex_str is None:
            raise ValueError("missing hex in part")

        raw_bytes = bytes.fromhex(hex_str)

        if encoding == 'raw':
            payload_hex = raw_bytes.hex()
        elif encoding == 'base64':
            folded = _base64_fold(raw_bytes)
            payload_hex = folded.encode('ascii').hex()
        else:
            raise ValueError(f"unknown encoding: {encoding!r}")

        out_part = dict(part)
        out_part['payload_hex'] = payload_hex
        parts_out.append(out_part)

    return {'name': contract['name'], 'result': {'parts': parts_out}}
