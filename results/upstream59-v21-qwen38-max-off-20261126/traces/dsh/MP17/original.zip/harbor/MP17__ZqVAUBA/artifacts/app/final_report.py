"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.is_file():
        raise FileNotFoundError("core_manifest.json not found")

    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core.get('components', {})
    component_count = len(components)

    # sha256 of the full core object serialized compactly
    canonical = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(canonical).hexdigest()

    # attention: components with specific flags
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        # result.blocked explicitly true
        if result.get('blocked') is True:
            triggered = True
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                triggered = True
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # "non-empty" - check if it's a collection or truthy value
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    triggered = True
                elif isinstance(val, (int, float)) and val != 0:
                    triggered = True
                elif isinstance(val, bool) and val:
                    triggered = True
        if triggered:
            attention.append(name)

    attention.sort()

    report = {
        'title': '文本、内联内容和文件的 multipart 组装',
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention,
    }

    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )


if __name__ == '__main__':
    main()
