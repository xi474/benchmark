import re
from pathlib import PurePosixPath

_FIELD_NAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_SAFE_BASENAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_MIME_RE = re.compile(r'^[A-Za-z0-9!#$&\-.^_+]+/[A-Za-z0-9!#$&\-.^_+]+$')

_EXT_MIME = {
    '.txt': 'text/plain',
    '.json': 'application/json',
    '.jpg': 'image/jpeg',
}


def _validate_safe_relative_path(p):
    """Validate a safe relative path: no absolute, no backslash, no colon, no empty segments, no . or .."""
    if not p or not isinstance(p, str):
        raise ValueError(f"invalid path: {p!r}")
    if '\\' in p or ':' in p:
        raise ValueError(f"unsafe path characters: {p!r}")
    parts = p.split('/')
    for seg in parts:
        if seg == '' or seg == '.' or seg == '..':
            raise ValueError(f"unsafe path segment in: {p!r}")
    return p


def _resolve_mime(filename, explicit_mime):
    """Resolve MIME type from explicit value or filename extension."""
    if explicit_mime is not None:
        if not _MIME_RE.match(explicit_mime):
            raise ValueError(f"invalid MIME type: {explicit_mime!r}")
        return explicit_mime
    if filename is not None:
        ext = PurePosixPath(filename).suffix.lower()
        return _EXT_MIME.get(ext, 'application/octet-stream')
    return 'application/octet-stream'


def transform(payloads, contract):
    """multipart_parts: parse fields/files/boundary into sorted parts list."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("input must be object")

    # Validate required fields
    for key in ('fields', 'files', 'boundary'):
        if key not in inp:
            raise ValueError(f"missing required field: {key}")

    fields = inp['fields']
    files = inp['files']
    boundary = inp['boundary']

    if not isinstance(fields, dict):
        raise ValueError("fields must be object")
    if not isinstance(files, dict):
        raise ValueError("files must be object")
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("boundary must be non-empty string")
    if not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError("boundary must be alphanumeric and hyphens only")

    # Validate file paths
    file_bytes = {}
    for fpath, hex_str in files.items():
        _validate_safe_relative_path(fpath)
        if not isinstance(hex_str, str):
            raise ValueError(f"file hex must be string: {fpath}")
        try:
            file_bytes[fpath] = bytes.fromhex(hex_str)
        except ValueError as e:
            raise ValueError(f"invalid hex for {fpath}: {e}") from e

    parts = []
    for name, value in fields.items():
        if not _FIELD_NAME_RE.match(name):
            raise ValueError(f"invalid field name: {name!r}")

        if isinstance(value, str):
            # Plain text field
            content_bytes = value.encode('utf-8')
            parts.append({
                'name': name,
                'filename': None,
                'mimetype': 'text/plain',
                'encoding': 'raw',
                'hex': content_bytes.hex(),
            })
        elif isinstance(value, dict):
            if not value:
                raise ValueError(f"empty field object: {name}")

            filename = value.get('filename')
            content = value.get('content')
            mimetype = value.get('mimetype')

            if content is not None:
                # Inline content takes priority
                if not isinstance(content, str):
                    raise ValueError(f"content must be string for field: {name}")
                content_bytes = content.encode('utf-8')
                encoding = 'raw'
                if filename is not None:
                    if not isinstance(filename, str):
                        raise ValueError(f"filename must be string: {name}")
                    basename = PurePosixPath(filename).name
                    if not _SAFE_BASENAME_RE.match(basename):
                        raise ValueError(f"unsafe filename: {basename!r}")
                    resolved_filename = basename
                else:
                    resolved_filename = None
            elif filename is not None:
                # Read from files map
                if not isinstance(filename, str):
                    raise ValueError(f"filename must be string: {name}")
                _validate_safe_relative_path(filename)
                if filename not in file_bytes:
                    raise ValueError(f"file not found: {filename}")
                content_bytes = file_bytes[filename]
                encoding = 'base64'
                basename = PurePosixPath(filename).name
                if not _SAFE_BASENAME_RE.match(basename):
                    raise ValueError(f"unsafe filename: {basename!r}")
                resolved_filename = basename
            else:
                raise ValueError(f"field object must have content or filename: {name}")

            resolved_mime = _resolve_mime(resolved_filename, mimetype)
            parts.append({
                'name': name,
                'filename': resolved_filename,
                'mimetype': resolved_mime,
                'encoding': encoding,
                'hex': content_bytes.hex(),
            })
        else:
            raise ValueError(f"field value must be string or object: {name}")

    # Sort by name
    parts.sort(key=lambda p: p['name'])

    return {'name': contract['name'], 'result': {'parts': parts}}
