"""Orchestrate all components in dependency order, then run integrate and final_report."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs/)
    contracts = sorted(
        cp for cp in ROOT.rglob('contract.json')
        if 'outputs' not in cp.relative_to(ROOT).parts
    )
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs
    # Each contract's inputs may reference outputs of other contracts
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = {'path': cp, 'contract': c}

    # Topological sort based on input dependencies
    def get_deps(contract_data):
        deps = set()
        for inp in contract_data['inputs']:
            if inp.startswith('outputs/'):
                # Find which contract produces this output
                for name, info in contract_map.items():
                    if info['contract']['output'] == inp:
                        deps.add(name)
        return deps

    order = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"Circular dependency detected: {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        for dep in get_deps(contract_map[name]['contract']):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Execute each component in order via its render.py
    for name in order:
        info = contract_map[name]
        render_py = info['path'].parent / 'render.py'
        if not render_py.is_file():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.is_file():
        result = subprocess.run([sys.executable, str(integrate)], cwd=ROOT, timeout=30)
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.is_file():
        result = subprocess.run([sys.executable, str(final_report)], cwd=ROOT, timeout=30)
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
