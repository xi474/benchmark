# Workflow 可观测性报告

- Trial：`MP18__aMHz5jK__env`
- Task：`MP18`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（50 节点 / 49 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：50；执行边：49（observed=0，inferred=49）
- Execution Trace Graph：`observed`；temporal_next 边 49，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_4f107bfd963d48949cf63f19 -> tool:dsh:lead:call_8efacecd85be4148857341fa -> tool:dsh:lead:call_bd29ac0808d047efad16130a -> tool:dsh:lead:call_7a5304c41ba24e3785701626 -> tool:dsh:lead:call_e2ebecc8bbcd470bb7769d58 -> tool:dsh:lead:call_1ad94192de5c4e5895fabbfa -> tool:dsh:lead:call_216a9b963a374a0db48b7eac -> tool:dsh:lead:call_90353dac0d2542aeb55ccf26 -> tool:dsh:lead:call_c7db40809b7c4700a7ef95ad -> tool:dsh:lead:call_1e068efa3d294ea69a1110e1 -> tool:dsh:lead:call_d469ccc303f146cb9e340dcd -> tool:dsh:lead:call_dfb95f9e890c4a50818672b3 -> tool:dsh:lead:call_1fb95a5008b64a65baedc035 -> tool:dsh:lead:call_bd0d9b48fbcc49b393ffe174 -> tool:dsh:lead:call_e3d7675ab1694226be1ce193 -> tool:dsh:lead:call_16c28d2e871049ac92a0a486 -> tool:dsh:lead:call_494842231a0d4de3afd7dec7 -> tool:dsh:lead:call_ce13b60b64cc4cd68fc28f25 -> tool:dsh:lead:call_98700c4a90144716a126449e -> tool:dsh:lead:call_3c28a565d74b4d4dbcef1746 -> tool:dsh:lead:call_584c694e6e484a89b0acf5be -> tool:dsh:lead:call_93107184ede143adbacd973b -> tool:dsh:lead:call_2950bf737f504e1598be4d79 -> tool:dsh:lead:call_5069be3f6e8a40ada8785833 -> tool:dsh:lead:call_ab2f17c4c0054b0e94465436 -> tool:dsh:lead:call_5dd26eabdf504ea98faa6065 -> tool:dsh:lead:call_8563e5870d404847ae37698e -> tool:dsh:lead:call_89d75842cf70465e9471d2aa -> tool:dsh:lead:call_9c2c9f58fa32433a8d969b7a -> tool:dsh:lead:call_01a9c0131c82408399280935 -> tool:dsh:lead:call_001f79806fc64422913920c6 -> tool:dsh:lead:call_0313353a1d044d1a8a4b236c -> tool:dsh:lead:call_22f96ec3e05b4ef59dfae999 -> tool:dsh:lead:call_65a7668ed0694e35a055ed71 -> tool:dsh:lead:call_d61befd819254a6ab3140506 -> tool:dsh:lead:call_f27fad571deb43b496c217f3 -> tool:dsh:lead:call_215b26a278bb4e72b9517f2a -> tool:dsh:lead:call_c20a193213e249d3acd43850 -> tool:dsh:lead:call_ae1dca2ad4fc465e80a9ff64 -> tool:dsh:lead:call_f3fefd5ccd63412d8444a8b7 -> tool:dsh:lead:call_5fe8083867984ef7b5f1f5ab -> tool:dsh:lead:call_0cea52d3068a43e3bf3b7a79 -> tool:dsh:lead:call_72d0120f8e6b4f7f9ae98e84 -> tool:dsh:lead:call_01cda3ce57814cc8a50a1333 -> tool:dsh:lead:call_30491f79764d45058d37fbdf -> tool:dsh:lead:call_0809e4fe94634838b37043ba -> tool:dsh:lead:call_e6af5978a4e94cedab8efdc6 -> tool:dsh:lead:call_f666d9b5c9e34d8a92d877bf -> tool:dsh:lead:call_27ad9404c5b542f2adfaf907
- 关键路径耗时：1.368
- Makespan：201.293
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
