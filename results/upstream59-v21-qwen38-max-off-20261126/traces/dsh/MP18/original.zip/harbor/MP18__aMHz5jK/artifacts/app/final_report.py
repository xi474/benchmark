#!/usr/bin/env python3
"""Generate final_report.json from core_manifest.json."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    # Compute sha256 of the core object
    core_bytes = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(core_bytes).hexdigest()

    # Determine attention list
    attention = set()
    components = core.get('components', {})

    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # Check result.blocked explicitly true (must be bool True, not truthy)
        if 'blocked' in result and result['blocked'] is True:
            attention.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false (must be bool False)
        for field in ('complete', 'checkout', 'committed', 'ok'):
            if field in result and result[field] is False:
                attention.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for field in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            if field in result:
                val = result[field]
                # Non-empty: for lists/dicts/strings, check len > 0
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float, bool)):
                    # Numbers/bools: non-empty doesn't apply in the same way
                    # But spec says "非空" which typically means non-empty collection
                    pass

    report = {
        'title': '集合文件清单的指令选择与归档元数据',
        'component_count': len(components),
        'sha256': sha256_hex,
        'attention': sorted(attention)
    }

    output_path = ROOT / 'outputs' / 'final_report.json'
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    output_path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
