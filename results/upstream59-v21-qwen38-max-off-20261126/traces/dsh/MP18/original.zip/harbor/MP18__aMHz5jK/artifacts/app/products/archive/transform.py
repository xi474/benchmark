import hashlib


def transform(payloads, contract):
    """manifest_archive: compute entries with size and sha256 for selected files."""
    if len(payloads) != 2:
        raise ValueError(f"expected 2 payloads, got {len(payloads)}")

    inventory_payload = payloads[0]
    selection_payload = payloads[1]

    # Extract result from wrapped payloads if needed
    if isinstance(inventory_payload, dict) and 'name' in inventory_payload and 'result' in inventory_payload:
        inv_data = inventory_payload['result']
    else:
        inv_data = inventory_payload

    if isinstance(selection_payload, dict) and 'name' in selection_payload and 'result' in selection_payload:
        sel_data = selection_payload['result']
    else:
        sel_data = selection_payload

    # Build lookup of regular files by path
    file_lookup = {}
    for f in inv_data['files']:
        file_lookup[f['path']] = f['hex']

    selected = sel_data['selected']

    # Validate: no duplicates
    if len(selected) != len(set(selected)):
        raise ValueError("selected contains duplicates")

    entries = []
    total_bytes = 0

    for path in selected:
        if path not in file_lookup:
            raise ValueError(f"selected file '{path}' not in inventory regular files")

        hex_str = file_lookup[path]
        raw_bytes = bytes.fromhex(hex_str)
        size = len(raw_bytes)
        sha256_hash = hashlib.sha256(raw_bytes).hexdigest()

        entries.append({
            'path': path,
            'size': size,
            'sha256': sha256_hash
        })
        total_bytes += size

    result = {
        'entries': entries,
        'total_bytes': total_bytes
    }

    return {'name': contract['name'], 'result': result}
