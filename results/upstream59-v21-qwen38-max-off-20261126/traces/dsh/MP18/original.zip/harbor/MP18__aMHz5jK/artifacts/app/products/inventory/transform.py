import re


def _is_safe_relative_path(p):
    """Check that p is a safe relative path: uses /, no absolute, no backslash,
    no colon, no empty segments, no . or .. segments."""
    if not isinstance(p, str):
        raise ValueError(f"path must be string, got {type(p)}")
    if not p:
        raise ValueError("empty path")
    if '\\' in p:
        raise ValueError(f"backslash in path: {p}")
    if ':' in p:
        raise ValueError(f"colon in path: {p}")
    if p.startswith('/'):
        raise ValueError(f"absolute path: {p}")
    parts = p.split('/')
    for part in parts:
        if part == '':
            raise ValueError(f"empty segment in path: {p}")
        if part == '.' or part == '..':
            raise ValueError(f"illegal segment '{part}' in path: {p}")
    return True


def _validate_hex(h):
    """Validate that h is a valid hex string (even length, valid hex chars)."""
    if not isinstance(h, str):
        raise ValueError(f"hex must be string, got {type(h)}")
    if len(h) % 2 != 0:
        raise ValueError(f"hex string has odd length: {h}")
    try:
        bytes.fromhex(h)
    except ValueError as e:
        raise ValueError(f"invalid hex: {e}") from e
    return h


def transform(payloads, contract):
    """manifest_inventory: process input case and produce inventory result."""
    if len(payloads) != 1:
        raise ValueError(f"expected 1 payload, got {len(payloads)}")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    # Validate required fields
    if 'files' not in data:
        raise ValueError("missing 'files' field")
    files = data['files']
    if not isinstance(files, list):
        raise ValueError("'files' must be array")

    # manifest and build_ignore are optional but validate types if present
    # They may or may not be present; unknown extra fields can be ignored

    seen_paths = set()
    regular_files = []
    symlinks = []

    for entry in files:
        if not isinstance(entry, dict):
            raise ValueError("each file entry must be object")

        # Required fields
        for field in ('path', 'kind', 'hex', 'target'):
            if field not in entry:
                raise ValueError(f"missing '{field}' in file entry")

        path = entry['path']
        kind = entry['kind']
        hex_val = entry['hex']
        target = entry['target']

        if not isinstance(path, str):
            raise ValueError(f"path must be string")
        if kind not in ('file', 'symlink'):
            raise ValueError(f"kind must be 'file' or 'symlink', got '{kind}'")

        # Validate path safety
        _is_safe_relative_path(path)

        # Check uniqueness
        if path in seen_paths:
            raise ValueError(f"duplicate path: {path}")
        seen_paths.add(path)

        if kind == 'file':
            # hex must be valid for regular files
            _validate_hex(hex_val)
            if target is not None:
                raise ValueError(f"regular file must have null target, got {target}")
            regular_files.append({'path': path, 'hex': hex_val})
        elif kind == 'symlink':
            # symlink: target must be safe relative path, hex should be empty string
            if target is None:
                raise ValueError("symlink must have non-null target")
            if not isinstance(target, str):
                raise ValueError(f"symlink target must be string")
            _is_safe_relative_path(target)
            symlinks.append(path)

    # Sort regular files by path
    regular_files.sort(key=lambda x: x['path'])
    # Sort symlinks by path
    symlinks.sort()

    result = {
        'files': regular_files,
        'symlinks': symlinks
    }

    return {'name': contract['name'], 'result': result}
