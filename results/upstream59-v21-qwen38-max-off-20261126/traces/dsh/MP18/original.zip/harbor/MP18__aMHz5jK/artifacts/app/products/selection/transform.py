import fnmatch


def _is_under_git(path):
    """Check if path is .git itself or under any .git directory at any level."""
    parts = path.split('/')
    for part in parts:
        if part == '.git':
            return True
    return False


def transform(payloads, contract):
    """manifest_selection: select files based on manifest instructions or build_ignore."""
    if len(payloads) != 2:
        raise ValueError(f"expected 2 payloads, got {len(payloads)}")

    case_data = payloads[0]
    inventory_result = payloads[1]

    # Extract from case_data
    manifest = case_data.get('manifest')
    build_ignore = case_data.get('build_ignore')

    # manifest and build_ignore cannot both be non-null
    if manifest is not None and build_ignore is not None:
        raise ValueError("manifest and build_ignore cannot both be non-null")

    # Get all regular file paths from inventory result
    # inventory_result is the 'result' field from inventory transform output
    # But payloads[1] is the full wrapped result {"name":..., "result":...}
    # According to README: "当输入对象键恰为name/result时，仅其result为业务输入"
    if isinstance(inventory_result, dict) and set(inventory_result.keys()) >= {'name', 'result'}:
        inv_data = inventory_result['result']
    else:
        inv_data = inventory_result

    all_files = [f['path'] for f in inv_data['files']]

    if manifest is None:
        # Default: select all regular files, then exclude with build_ignore
        selected = set(all_files)
        if build_ignore is not None:
            if not isinstance(build_ignore, list):
                raise ValueError("build_ignore must be array")
            for pattern in build_ignore:
                if not isinstance(pattern, str):
                    raise ValueError("build_ignore patterns must be strings")
                selected = {p for p in selected if not fnmatch.fnmatchcase(p, pattern)}
    else:
        # Parse manifest instructions
        if not isinstance(manifest, str):
            raise ValueError("manifest must be string")
        selected = set()
        lines = manifest.split('\n')
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue
            parts = stripped.split(None, 2)
            cmd = parts[0]

            if cmd == 'include':
                if len(parts) < 2:
                    raise ValueError(f"include requires a pattern: {stripped}")
                pattern = parts[1]
                for p in all_files:
                    if fnmatch.fnmatchcase(p, pattern):
                        selected.add(p)

            elif cmd == 'exclude':
                if len(parts) < 2:
                    raise ValueError(f"exclude requires a pattern: {stripped}")
                pattern = parts[1]
                selected = {p for p in selected if not fnmatch.fnmatchcase(p, pattern)}

            elif cmd == 'recursive-include':
                if len(parts) < 3:
                    raise ValueError(f"recursive-include requires DIR and PATTERN: {stripped}")
                dir_prefix = parts[1]
                pattern = parts[2]
                for p in all_files:
                    # Match DIR/ at any depth, then basename matches pattern
                    # Check if path starts with dir_prefix/ or has /dir_prefix/ in it
                    path_parts = p.split('/')
                    for i in range(len(path_parts)):
                        if path_parts[i] == dir_prefix:
                            # Everything after this directory
                            remaining = '/'.join(path_parts[i+1:])
                            if remaining and fnmatch.fnmatchcase(path_parts[-1], pattern):
                                # The file must be under this dir_prefix
                                # Actually: recursive-include DIR PATTERN matches
                                # DIR/下任意深度basename - basename of files under DIR
                                pass
                    # Simpler approach: check if any prefix component matches dir_prefix
                    # and the basename matches pattern
                    found_dir = False
                    for i in range(len(path_parts) - 1):  # exclude last (filename)
                        if path_parts[i] == dir_prefix:
                            found_dir = True
                            break
                    if found_dir and fnmatch.fnmatchcase(path_parts[-1], pattern):
                        selected.add(p)

            elif cmd == 'global-exclude':
                if len(parts) < 2:
                    raise ValueError(f"global-exclude requires a pattern: {stripped}")
                pattern = parts[1]
                selected = {p for p in selected if not fnmatch.fnmatchcase(p.split('/')[-1], pattern)}

            else:
                raise ValueError(f"unknown manifest instruction: {cmd}")

    # Unconditionally exclude .git directory and any .git subdirectory, *.pyc, MANIFEST.in
    final_selected = set()
    for p in selected:
        if _is_under_git(p):
            continue
        if fnmatch.fnmatchcase(p.split('/')[-1], '*.pyc'):
            continue
        if p == 'MANIFEST.in':
            continue
        final_selected.add(p)

    result = {
        'selected': sorted(final_selected)
    }

    return {'name': contract['name'], 'result': result}
