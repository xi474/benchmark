#!/usr/bin/env python3
"""Run all components in dependency order, then integrate and generate final report."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_json(path):
    """Load JSON file."""
    return json.loads(Path(path).read_text(encoding='utf-8'))


def run_component(component_dir):
    """Run a component's render.py as a subprocess."""
    render_script = component_dir / 'render.py'
    if not render_script.exists():
        print(f"ERROR: {render_script} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run(
        [sys.executable, str(render_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"ERROR running {render_script}:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    return result


def main():
    # Clean outputs directory
    outputs_dir = ROOT / 'outputs'
    if outputs_dir.exists():
        import shutil
        shutil.rmtree(outputs_dir)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    # Discover all contracts and build dependency graph
    contracts = {}
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        c = load_json(cp)
        contracts[c['name']] = {
            'contract': c,
            'dir': cp.parent,
            'deps': []
        }

    # Build dependency graph based on input references to other outputs
    for name, info in contracts.items():
        for inp in info['contract']['inputs']:
            # Check if this input is an output of another component
            for other_name, other_info in contracts.items():
                if other_name == name:
                    continue
                if inp == other_info['contract']['output']:
                    info['deps'].append(other_name)

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            print(f"ERROR: circular dependency involving {name}", file=sys.stderr)
            sys.exit(1)
        if name in visited:
            return
        visiting.add(name)
        for dep in contracts[name]['deps']:
            if dep not in contracts:
                print(f"ERROR: missing dependency {dep} for {name}", file=sys.stderr)
                sys.exit(1)
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(contracts.keys()):
        visit(name)

    # Run components in order
    for name in ordered:
        info = contracts[name]
        print(f"Running component: {name}")
        run_component(info['dir'])

    # Run integrate.py
    print("Running integrate.py")
    result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"ERROR running integrate.py:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    print("Running final_report.py")
    result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"ERROR running final_report.py:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    print("All components completed successfully.")


if __name__ == '__main__':
    main()
