# Workflow 可观测性报告

- Trial：`MP19__sds8V3g__env`
- Task：`MP19`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（53 节点 / 52 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：53；执行边：52（observed=0，inferred=52）
- Execution Trace Graph：`observed`；temporal_next 边 52，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_3db566cedeba484b85bac09f -> tool:dsh:lead:call_81fc35f179ba4b078cb74f84 -> tool:dsh:lead:call_24bd5fac223a4d94857eca36 -> tool:dsh:lead:call_eabd588a84184c7a8aba6ff0 -> tool:dsh:lead:call_1a7a3146dd0243a2832b03d3 -> tool:dsh:lead:call_1abf49cd2dce4909b5d5da10 -> tool:dsh:lead:call_9c9cc27b95dd41a59b071ba5 -> tool:dsh:lead:call_04f207ad3eab4cc1abf99f53 -> tool:dsh:lead:call_d67efbd7500d4097a3c5fdd4 -> tool:dsh:lead:call_1e0f92c9ee024ae08db0f1dd -> tool:dsh:lead:call_945b599092c4400c8298b283 -> tool:dsh:lead:call_355ed13756874e37bcf5fa9a -> tool:dsh:lead:call_a99c525f41534fccb5b93658 -> tool:dsh:lead:call_0dbe89c0c45c4b0788cafa6c -> tool:dsh:lead:call_3b1334fde28048b79d855019 -> tool:dsh:lead:call_1f32dcc06d0c481dac62068f -> tool:dsh:lead:call_1fdef8f32045497f8073f058 -> tool:dsh:lead:call_462d6ba655e64db39b0af055 -> tool:dsh:lead:call_388c8e0f69c544a79b7ec9de -> tool:dsh:lead:call_023419059eed40dabad5522f -> tool:dsh:lead:call_0267fbeb02da4400a80f80c3 -> tool:dsh:lead:call_e6256e315342473782b6687b -> tool:dsh:lead:call_adfb2eb6b21943ea8e39de3e -> tool:dsh:lead:call_4d3c704b5022407da065af61 -> tool:dsh:lead:call_31401b9057d341d3a90ec85f -> tool:dsh:lead:call_e42073ade57e4397b5da1731 -> tool:dsh:lead:call_0c86fa686d054c7386625a21 -> tool:dsh:lead:call_de0c6227ceb44093a3080fab -> tool:dsh:lead:call_93c2c229e0a747f4ad369268 -> tool:dsh:lead:call_ad090c38a45c49b88405b810 -> tool:dsh:lead:call_fc072ee9bb444a82a17d9f37 -> tool:dsh:lead:call_7f55ebb806164914a4e754b8 -> tool:dsh:lead:call_4e394798e15f47a1b06422f8 -> tool:dsh:lead:call_a2858c07bbc847b38188bf37 -> tool:dsh:lead:call_1969cac562354dda94c5a675 -> tool:dsh:lead:call_5d1be17053a043b288181df3 -> tool:dsh:lead:call_8f1b1202d1fd4fc79baa8110 -> tool:dsh:lead:call_d8dbd970ecd74367a263b45f -> tool:dsh:lead:call_774a2edb10bf4d948220c076 -> tool:dsh:lead:call_5fa76779c8ac46d48ed03d37 -> tool:dsh:lead:call_2b64dd6f6b1a458c9a3e685f -> tool:dsh:lead:call_a16017f2a7104323871b34ce -> tool:dsh:lead:call_f9c706c67eeb43b7a0a630cd -> tool:dsh:lead:call_6fcee28949d5482ba6670b6a -> tool:dsh:lead:call_6f83ca8323ce4edcb1120713 -> tool:dsh:lead:call_6e8f838986bd41e5a1502e1f -> tool:dsh:lead:call_6fc1b64cba144f69a5642433 -> tool:dsh:lead:call_b9c0604078414885b36f4451 -> tool:dsh:lead:call_621021abfed84c909b85c577 -> tool:dsh:lead:call_8e6fad5030e1496499e99059 -> tool:dsh:lead:call_30906a4172114aabaaf42c5c -> tool:dsh:lead:call_b8d7f6354fc34b93a903ddc4
- 关键路径耗时：1.47
- Makespan：266.283
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
