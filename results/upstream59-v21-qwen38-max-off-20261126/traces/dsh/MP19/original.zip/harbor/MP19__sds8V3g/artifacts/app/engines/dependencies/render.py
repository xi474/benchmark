import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs per contract, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    comp_dir = contract_path.parent
    sys.path.insert(0, str(comp_dir))
    try:
        from model import load_payload
        from transform import transform
    finally:
        sys.path.pop(0)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    
    return result


if __name__ == "__main__":
    contract_path = Path(__file__).resolve().with_name('contract.json')
    root = contract_path.parents[2]
    build_component(root, contract_path)
