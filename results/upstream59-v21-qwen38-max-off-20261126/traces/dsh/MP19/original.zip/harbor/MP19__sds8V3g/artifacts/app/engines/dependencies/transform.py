from collections import deque


def transform(payloads, contract):
    """Perform module_dependency_closure operation.
    
    Inputs: [original_case_input, scanner_result]
    Scanner result has {imports: {path: [module_names]}, module_paths: {module_name: path}}
    
    BFS from entry, collecting all needed local paths and external modules.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    
    case_data = payloads[0]
    scanner_result = payloads[1]
    
    # Extract from scanner result (it's the envelope with name/result)
    if isinstance(scanner_result, dict) and 'result' in scanner_result:
        scan = scanner_result['result']
    else:
        scan = scanner_result
    
    imports_map = scan['imports']      # {path: [canonical_module_names]}
    module_paths = scan['module_paths']  # {module_name: path}
    
    entry = case_data['entry']
    externals = set(case_data.get('externals', []))
    aliases = case_data.get('aliases', {})
    
    # Build reverse lookup: for each path, what modules does it depend on?
    # imports_map already gives us this: path -> [dep_module_names]
    
    # We need to resolve each dependency module name to either a local path or external
    # For local deps, we also need to include parent package __init__.py files
    
    visited_paths = set()
    external_deps = set()
    queue = deque()
    
    # Start from entry
    queue.append(entry)
    
    while queue:
        current_path = queue.popleft()
        if current_path in visited_paths:
            continue
        visited_paths.add(current_path)
        
        # Get dependencies of this file
        deps = imports_map.get(current_path, [])
        
        for dep_mod in deps:
            # First check aliases - exact match
            resolved_name = aliases.get(dep_mod, dep_mod)
            
            # Check if it's a known local module
            if resolved_name in module_paths:
                dep_path = module_paths[resolved_name]
                if dep_path not in visited_paths:
                    queue.append(dep_path)
            else:
                # Check if top-level segment matches an external
                top_segment = resolved_name.split(".")[0]
                if resolved_name in externals or top_segment in externals:
                    external_deps.add(resolved_name)
                else:
                    raise ValueError(f"Unknown module: {resolved_name} (from {current_path})")
        
        # Add parent package __init__.py files for this path
        parts = current_path.replace("\\", "/").split("/")
        if len(parts) > 1:
            # This file is inside a package; ensure all parent __init__.py are included
            for i in range(1, len(parts)):
                init_path = "/".join(parts[:i]) + "/__init__.py"
                if init_path in set(module_paths.values()) and init_path not in visited_paths:
                    queue.append(init_path)
    
    # Sort paths and externals
    sorted_paths = sorted(visited_paths)
    sorted_external = sorted(external_deps)
    
    return {
        "name": contract["name"],
        "result": {
            "paths": sorted_paths,
            "external": sorted_external
        }
    }
