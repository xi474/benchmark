import hashlib
import io
import struct
import time
import zipfile


def transform(payloads, contract):
    """Perform module_zip operation.
    
    Inputs: [original_case_input, dependency_closure_result]
    Creates a deterministic ZIP with the source files listed in paths.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    
    case_data = payloads[0]
    dep_result = payloads[1]
    
    # Extract from envelope if needed
    if isinstance(dep_result, dict) and 'result' in dep_result:
        deps = dep_result['result']
    else:
        deps = dep_result
    
    paths = deps['paths']
    external = deps['external']
    modules = case_data['modules']
    
    # Validate no duplicate paths
    if len(paths) != len(set(paths)):
        raise ValueError("Duplicate paths in closure")
    
    # Build ZIP content
    zip_paths = list(paths)
    
    # If root __init__.py is missing from paths but needed, add empty one
    # "如果根__init__.py缺失则增加空根__init__.py"
    if "__init__.py" not in zip_paths:
        zip_paths.append("__init__.py")
    
    # Sort ZIP entries by path
    zip_paths_sorted = sorted(zip_paths)
    
    # Check all source paths exist (except synthetic root __init__.py)
    for p in zip_paths_sorted:
        if p == "__init__.py" and p not in modules:
            continue  # synthetic empty root __init__.py
        if p not in modules:
            raise ValueError(f"Source path not found: {p}")
    
    # Create deterministic ZIP
    buf = io.BytesIO()
    
    # Fixed timestamp: 1980-01-01 00:00:00
    fixed_date_time = (1980, 1, 1, 0, 0, 0)
    
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_STORED) as zf:
        for p in zip_paths_sorted:
            if p == "__init__.py" and p not in modules:
                data = b""
            else:
                data = modules[p].encode('utf-8')
            
            info = zipfile.ZipInfo(filename=p, date_time=fixed_date_time)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3  # Unix
            info.external_attr = 0o644 << 16
            info.comment = b""
            
            zf.writestr(info, data)
    
    zip_bytes = buf.getvalue()
    zip_hex = zip_bytes.hex()
    sha256 = hashlib.sha256(zip_bytes).hexdigest()
    
    return {
        "name": contract["name"],
        "result": {
            "paths": zip_paths_sorted,
            "zip_hex": zip_hex,
            "sha256": sha256,
            "external": external
        }
    }
