import ast
from pathlib import PurePosixPath


def _path_to_module(path_str):
    """Convert a relative .py path to a module name.
    e.g. 'pkg/a.py' -> 'pkg.a', 'pkg/__init__.py' -> 'pkg', '__init__.py' -> ''
    """
    p = PurePosixPath(path_str)
    parts = list(p.parts)
    if parts[-1] == '__init__.py':
        parts = parts[:-1]
        if not parts:
            return ""
        return ".".join(parts)
    else:
        # Remove .py extension
        name = parts[-1][:-3]  # strip .py
        if len(parts) > 1:
            return ".".join(parts[:-1]) + "." + name
        return name


def _module_to_possible_paths(module_name, all_paths):
    """Given a module name, find possible local file paths."""
    results = []
    if module_name == "":
        if "__init__.py" in all_paths:
            results.append("__init__.py")
    else:
        parts = module_name.split(".")
        # Could be pkg/sub/module.py or pkg/sub/__init__.py
        py_path = "/".join(parts) + ".py"
        init_path = "/".join(parts) + "/__init__.py"
        if py_path in all_paths:
            results.append(py_path)
        if init_path in all_paths:
            results.append(init_path)
    return results


def _resolve_relative_import(current_path, level, module_str, all_paths):
    """Resolve a relative import (from . import x, from ..pkg import y).
    Returns the fully qualified module name or raises ValueError.
    """
    current_parts = PurePosixPath(current_path).parts
    # Determine the current package
    if current_parts[-1] == '__init__.py':
        # This file IS the package __init__.py
        pkg_parts = list(current_parts[:-1])
    else:
        # This file is a module within a package
        pkg_parts = list(current_parts[:-1])

    # Go up 'level' levels (level=1 means current package, level=2 means parent, etc.)
    # For level=1 from a non-init module, we stay in same package
    # For level=1 from an __init__.py, we stay in same package (the one this init defines)
    up = level - 1
    if current_parts[-1] != '__init__.py':
        up = level - 1  # already accounted for by removing filename
    else:
        up = level - 1  # __init__.py defines the package itself

    if up > len(pkg_parts):
        raise ValueError(f"Relative import goes beyond root from {current_path}")

    if up > 0:
        base_parts = pkg_parts[:-up]
    else:
        base_parts = pkg_parts

    if module_str:
        full_parts = base_parts + module_str.split(".")
    else:
        full_parts = base_parts

    return ".".join(full_parts)


def transform(payloads, contract):
    """Perform module_import_scan operation.
    
    Input: {modules: {rel_path: source}, entry: str, externals: [str], aliases: {full_import: external}}
    Output: {imports: {path: [canonical_module_names sorted]}, module_paths: {module_name: path}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    
    data = payloads[0]
    
    modules = data.get('modules')
    entry = data.get('entry')
    externals = data.get('externals', [])
    aliases = data.get('aliases', {})
    
    if not isinstance(modules, dict):
        raise ValueError("modules must be a dict")
    if not isinstance(entry, str):
        raise ValueError("entry must be a string")
    if not isinstance(externals, list):
        raise ValueError("externals must be a list")
    if not isinstance(aliases, dict):
        raise ValueError("aliases must be a dict")
    if entry not in modules:
        raise ValueError(f"entry {entry} not in modules")
    
    all_paths = set(modules.keys())
    
    # Build module_paths: module_name -> path
    module_paths = {}
    for path in all_paths:
        mod_name = _path_to_module(path)
        module_paths[mod_name] = path
    
    # For each file, parse AST and extract imports
    imports = {}
    for path, source in modules.items():
        try:
            tree = ast.parse(source, filename=path)
        except SyntaxError:
            imports[path] = []
            continue
        
        deps = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    dep_name = alias.name
                    # Check if it's a local module
                    local_paths = _module_to_possible_paths(dep_name, all_paths)
                    if local_paths:
                        deps.add(dep_name)
                    else:
                        # Check aliases first
                        if dep_name in aliases:
                            deps.add(dep_name)
                        else:
                            # It's an external - check if top-level matches externals
                            top = dep_name.split(".")[0]
                            if top in externals or dep_name in externals:
                                deps.add(dep_name)
                            # If not in externals, still record as dependency
                            # (will be caught by dependencies component)
                            else:
                                deps.add(dep_name)
            
            elif isinstance(node, ast.ImportFrom):
                if node.level == 0:
                    # Absolute import: from X import y
                    if node.module is None:
                        raise ValueError(f"from * import not allowed in {path}")
                    
                    base_module = node.module
                    
                    # Check aliases first - exact match on full import name
                    # For "from X import y", the full import could be X.y
                    found_alias = False
                    for imp_alias in node.names:
                        full_name = base_module + "." + imp_alias.name
                        if full_name in aliases:
                            deps.add(full_name)
                            found_alias = True
                    
                    if not found_alias:
                        # Try X.y as local module first
                        for imp_alias in node.names:
                            candidate = base_module + "." + imp_alias.name
                            local_paths = _module_to_possible_paths(candidate, all_paths)
                            if local_paths:
                                deps.add(candidate)
                            else:
                                # Depend on X
                                local_base = _module_to_possible_paths(base_module, all_paths)
                                if local_base:
                                    deps.add(base_module)
                                else:
                                    # Check aliases for base_module
                                    if base_module in aliases:
                                        deps.add(base_module)
                                    else:
                                        deps.add(base_module)
                else:
                    # Relative import
                    module_str = node.module if node.module else ""
                    resolved = _resolve_relative_import(path, node.level, module_str, all_paths)
                    
                    if resolved:
                        # Check if resolved.X exists locally for each imported name
                        for imp_alias in node.names:
                            candidate = resolved + "." + imp_alias.name if resolved else imp_alias.name
                            local_paths = _module_to_possible_paths(candidate, all_paths)
                            if local_paths:
                                deps.add(candidate)
                            else:
                                # Depend on the resolved base
                                local_base = _module_to_possible_paths(resolved, all_paths)
                                if local_base:
                                    deps.add(resolved)
                                else:
                                    deps.add(resolved)
                    else:
                        # resolved is empty string - root package
                        for imp_alias in node.names:
                            candidate = imp_alias.name
                            local_paths = _module_to_possible_paths(candidate, all_paths)
                            if local_paths:
                                deps.add(candidate)
        
        # Convert deps to canonical module names, deduplicate and sort
        canonical = set()
        for dep in deps:
            # Apply alias mapping
            if dep in aliases:
                canonical.add(aliases[dep])
            else:
                canonical.add(dep)
        
        imports[path] = sorted(canonical)
    
    return {
        "name": contract["name"],
        "result": {
            "imports": imports,
            "module_paths": module_paths
        }
    }
