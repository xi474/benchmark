"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    
    components = core['components']
    
    # title is fixed
    title = 'Python 支持模块发现与可重复 ZIP 载荷'
    
    # component_count is number of keys in components
    component_count = len(components)
    
    # sha256: serialize the full core object (with outer "components" key)
    # using compact JSON (no spaces, no trailing newline)
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()
    
    # attention: list of component names where any of these conditions hold:
    # - result.blocked is explicitly true
    # - complete/checkout/committed/ok is explicitly false
    # - unavailable/missing/conflicts/unreachable is non-empty
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        # Check blocked
        if result.get('blocked') is True:
            attention.add(name)
        
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                # Non-empty collection or non-empty string
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(name)
    
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": sorted(attention)
    }
    
    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
