"""Orchestrate all components based on their contract.json files.

Discovers all contracts, resolves dependencies between them based on
input file references, and executes each component in topological order.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def resolve_order(contracts):
    """Topologically sort contracts based on input dependencies.
    
    A contract depends on another if any of its inputs references
    an output file produced by that other contract.
    """
    # Map output path -> contract path
    output_to_contract = {}
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_data[cp] = c
        output_to_contract[c['output']] = cp
    
    # Build dependency graph
    deps = {cp: set() for cp in contracts}
    for cp in contracts:
        c = contract_data[cp]
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                deps[cp].add(dep_cp)
    
    # Topological sort (Kahn's algorithm)
    in_degree = {cp: 0 for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            pass  # we need reverse mapping
    # Recompute
    in_degree = {cp: 0 for cp in contracts}
    reverse_deps = {cp: set() for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            reverse_deps[d].add(cp)
            in_degree[cp] += 1
    
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    queue.sort()  # deterministic
    order = []
    while queue:
        cp = queue.pop(0)
        order.append(cp)
        for dependent in sorted(reverse_deps[cp]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
        queue.sort()
    
    if len(order) != len(contracts):
        raise ValueError("Circular dependency detected among contracts")
    
    return order


def main():
    contracts = discover_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)
    
    order = resolve_order(contracts)
    
    for cp in order:
        render_script = cp.with_name('render.py')
        if not render_script.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)
    
    # Run integrate.py to produce core_manifest.json
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"integrate.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)
    
    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.exists():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"final_report.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
