# Workflow 可观测性报告

- Trial：`MP20__wdFDbGN__env`
- Task：`MP20`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（60 节点 / 59 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：60；执行边：59（observed=0，inferred=59）
- Execution Trace Graph：`observed`；temporal_next 边 59，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_8e743f603d434abb8586a251 -> tool:dsh:lead:call_573e6afcb48e46e0b7ab76e6 -> tool:dsh:lead:call_39f62e8d59aa4144bb6bf43b -> tool:dsh:lead:call_7ab0fe96237c407c964edcbc -> tool:dsh:lead:call_dd9cce24d8d04df6b94241fe -> tool:dsh:lead:call_4c717a8ff59f4091b9295136 -> tool:dsh:lead:call_8ef6c62d098c4159b06dd3c8 -> tool:dsh:lead:call_3d844751009d4b01a98608f7 -> tool:dsh:lead:call_2bceee24c3294ed1857ce1d2 -> tool:dsh:lead:call_2187ee16a03d4fda8dc7fdc4 -> tool:dsh:lead:call_d7e7e1ff16f744189bcde63d -> tool:dsh:lead:call_78da6de224174e0fa83eb420 -> tool:dsh:lead:call_16e14b30a60943fa981b4973 -> tool:dsh:lead:call_e4f56acf4ef04687bed86d19 -> tool:dsh:lead:call_0ff5f041d6fd4bb58048a5c6 -> tool:dsh:lead:call_acb6bf70740d4d5fb94c78cf -> tool:dsh:lead:call_8553b5daae8d4163b17539b7 -> tool:dsh:lead:call_9fcf77872b254169bc48b03c -> tool:dsh:lead:call_e111a8cdf3784cb9acfd8c47 -> tool:dsh:lead:call_90aa8e380b7c4f53a6fab76b -> tool:dsh:lead:call_85300a5dec3141998b3a5497 -> tool:dsh:lead:call_0311bc3fbfe742268db18e87 -> tool:dsh:lead:call_b0b1b0551cd844979d02a973 -> tool:dsh:lead:call_6e934ba3c8ce4851b138af52 -> tool:dsh:lead:call_28185b1d09c143dbb04952c0 -> tool:dsh:lead:call_4f2ae67a21d74c5e805d7478 -> tool:dsh:lead:call_c32b731464cb4f4499024b0a -> tool:dsh:lead:call_2312f134c7544243b8ce9539 -> tool:dsh:lead:call_1fdd2afdf5194d0d9a13e993 -> tool:dsh:lead:call_f4045b9a26c84ee2bb6cf828 -> tool:dsh:lead:call_b320b3952def4d2a90ebfcb3 -> tool:dsh:lead:call_7b751f2ac768474d808e0e14 -> tool:dsh:lead:call_c8edabd3e43c4fa99b7ea442 -> tool:dsh:lead:call_fb5eafb9ee2a4deaa91e8dc7 -> tool:dsh:lead:call_c906e9deaf294af39a6531d7 -> tool:dsh:lead:call_dbea5a3838f94e7e8adec0b8 -> tool:dsh:lead:call_9977b0aa9197444d8262139d -> tool:dsh:lead:call_c317fa402eec419da52019c8 -> tool:dsh:lead:call_450e0f738dd94540ba1f3e8f -> tool:dsh:lead:call_ec742c52c9b047a0a61dd065 -> tool:dsh:lead:call_634f9ecad5c14794ab93611c -> tool:dsh:lead:call_09ee24b8bc8d4d4988dda7ed -> tool:dsh:lead:call_73b70ecf728140c5b298b4b1 -> tool:dsh:lead:call_5a990af38ae5443094109ec4 -> tool:dsh:lead:call_af0d4fc7617c4c23901fb596 -> tool:dsh:lead:call_e68b38b35c6c4f51aa294cac -> tool:dsh:lead:call_bfddf1b2eb0444ca84ccc3b4 -> tool:dsh:lead:call_90357a3d689045839990705e -> tool:dsh:lead:call_fd5b8196f8b64ae9b90fa68b -> tool:dsh:lead:call_30e633905b954e9bb5264770 -> tool:dsh:lead:call_63af628afb3b4bc2ab1046db -> tool:dsh:lead:call_36ddf36ad4c3446ea2387364 -> tool:dsh:lead:call_3ef66496d9cb477585114935 -> tool:dsh:lead:call_14611846bc89485abd570305 -> tool:dsh:lead:call_b003d7fea97641f79bec459e -> tool:dsh:lead:call_5029bd3015ac4a9893d627a4 -> tool:dsh:lead:call_0d36cdfe2c4b405bb6ee8785 -> tool:dsh:lead:call_ce39fbad9d0b4d4bbcc82990 -> tool:dsh:lead:call_0e84dc85dfe2458bb35a5dbc
- 关键路径耗时：1.635
- Makespan：208.953
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
