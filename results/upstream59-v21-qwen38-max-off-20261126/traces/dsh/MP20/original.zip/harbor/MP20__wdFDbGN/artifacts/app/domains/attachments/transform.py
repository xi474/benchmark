import json


def _canonical_json(obj):
    """Produce compact canonical JSON string: sort_keys, no spaces, ensure_ascii=False."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def transform(payloads, contract):
    """feature_attachments: extract attachments from each flag's variants.
    
    Input is same as feature_schema (case.json).
    Returns {attachments: {flag_id: {variant_id: {value: attachment, canonical: compact_json}}}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("input must be object")

    flags = payload.get('flags', [])
    attachments = {}

    for flag in flags:
        flag_id = flag['id']
        flag_attachments = {}
        for variant in flag.get('variants', []):
            variant_id = variant['id']
            attachment_value = variant['attachment']
            flag_attachments[variant_id] = {
                "value": attachment_value,
                "canonical": _canonical_json(attachment_value)
            }
        attachments[flag_id] = flag_attachments

    result = {"attachments": attachments}
    return {"name": contract["name"], "result": result}
