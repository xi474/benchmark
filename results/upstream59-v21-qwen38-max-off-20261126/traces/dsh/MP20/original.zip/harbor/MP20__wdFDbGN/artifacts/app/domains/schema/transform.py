import copy


def _validate_string(val, context):
    """Validate non-empty string (strip must be non-empty)."""
    if not isinstance(val, str):
        raise ValueError(f"{context}: expected string, got {type(val).__name__}")
    if not val or not val.strip():
        raise ValueError(f"{context}: empty or blank string")


def transform(payloads, contract):
    """feature_schema: validate input shape and return deep copy of flags/segments."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("input must be object")

    # Validate required fields
    if 'flags' not in payload:
        raise ValueError("missing 'flags'")
    if 'segments' not in payload:
        raise ValueError("missing 'segments'")
    if 'old_snapshot' not in payload:
        raise ValueError("missing 'old_snapshot'")

    flags = payload['flags']
    segments = payload['segments']
    old_snapshot = payload['old_snapshot']

    if not isinstance(flags, list):
        raise ValueError("'flags' must be array")
    if not isinstance(segments, list):
        raise ValueError("'segments' must be array")
    if not isinstance(old_snapshot, dict):
        raise ValueError("'old_snapshot' must be object")

    # Validate flag IDs unique
    flag_ids = set()
    for fi, flag in enumerate(flags):
        if not isinstance(flag, dict):
            raise ValueError(f"flag[{fi}] must be object")
        if 'id' not in flag:
            raise ValueError(f"flag[{fi}] missing 'id'")
        _validate_string(flag['id'], f"flag[{fi}].id")
        if flag['id'] in flag_ids:
            raise ValueError(f"duplicate flag id: {flag['id']}")
        flag_ids.add(flag['id'])

        # Validate variants
        if 'variants' not in flag:
            raise ValueError(f"flag[{fi}] missing 'variants'")
        variants = flag['variants']
        if not isinstance(variants, list):
            raise ValueError(f"flag[{fi}].variants must be array")
        variant_ids = set()
        for vi, variant in enumerate(variants):
            if not isinstance(variant, dict):
                raise ValueError(f"flag[{fi}].variant[{vi}] must be object")
            if 'id' not in variant:
                raise ValueError(f"flag[{fi}].variant[{vi}] missing 'id'")
            _validate_string(variant['id'], f"flag[{fi}].variant[{vi}].id")
            if variant['id'] in variant_ids:
                raise ValueError(f"duplicate variant id '{variant['id']}' in flag '{flag['id']}'")
            variant_ids.add(variant['id'])
            if 'attachment' not in variant:
                raise ValueError(f"flag[{fi}].variant[{vi}] missing 'attachment'")

        # Validate rules
        if 'rules' not in flag:
            raise ValueError(f"flag[{fi}] missing 'rules'")
        rules = flag['rules']
        if not isinstance(rules, list):
            raise ValueError(f"flag[{fi}].rules must be array")
        rule_ids = set()
        for ri, rule in enumerate(rules):
            if not isinstance(rule, dict):
                raise ValueError(f"flag[{fi}].rule[{ri}] must be object")
            if 'id' not in rule:
                raise ValueError(f"flag[{fi}].rule[{ri}] missing 'id'")
            _validate_string(rule['id'], f"flag[{fi}].rule[{ri}].id")
            if rule['id'] in rule_ids:
                raise ValueError(f"duplicate rule id '{rule['id']}' in flag '{flag['id']}'")
            rule_ids.add(rule['id'])
            if 'segment' not in rule:
                raise ValueError(f"flag[{fi}].rule[{ri}] missing 'segment'")
            _validate_string(rule['segment'], f"flag[{fi}].rule[{ri}].segment")
            if 'variant' not in rule:
                raise ValueError(f"flag[{fi}].rule[{ri}] missing 'variant'")
            _validate_string(rule['variant'], f"flag[{fi}].rule[{ri}].variant")

    # Validate segment IDs unique
    segment_ids = set()
    for si, seg in enumerate(segments):
        if not isinstance(seg, dict):
            raise ValueError(f"segment[{si}] must be object")
        if 'id' not in seg:
            raise ValueError(f"segment[{si}] missing 'id'")
        _validate_string(seg['id'], f"segment[{si}].id")
        if seg['id'] in segment_ids:
            raise ValueError(f"duplicate segment id: {seg['id']}")
        segment_ids.add(seg['id'])

    result = {
        "flags": copy.deepcopy(flags),
        "segments": copy.deepcopy(segments)
    }

    return {"name": contract["name"], "result": result}
