"""Generate final report from core_manifest.json.

Reads outputs/core_manifest.json, computes sha256 of the full core object,
determines attention components, and writes outputs/final_report.json.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def compute_sha256(core):
    """Compute SHA256 of the canonical JSON serialization of core."""
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    return hashlib.sha256(serialized).hexdigest()


def check_attention(result):
    """Check if a component result triggers attention.
    
    Conditions:
    - result.blocked is explicitly True
    - complete/checkout/committed/ok is explicitly False
    - unavailable/missing/conflicts/unreachable is non-empty
    """
    if not isinstance(result, dict):
        return False

    # Check blocked explicitly true
    if result.get('blocked') is True:
        return True

    # Check complete/checkout/committed/ok explicitly false
    for key in ('complete', 'checkout', 'committed', 'ok'):
        if key in result and result[key] is False:
            return True

    # Check unavailable/missing/conflicts/unreachable non-empty
    for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
        val = result.get(key)
        if val is not None and val != [] and val != {} and val != '':
            # Non-empty means truthy for lists/dicts/strings
            if isinstance(val, (list, dict, str)) and len(val) > 0:
                return True

    return False


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.exists():
        raise FileNotFoundError("core_manifest.json not found")

    core = json.loads(core_path.read_text(encoding='utf-8'))
    components = core.get('components', {})

    title = '特性配置的模式、附件与引用一致性'
    component_count = len(components)
    sha256 = compute_sha256(core)

    # Determine attention components
    attention = []
    for name, result in components.items():
        if check_attention(result):
            attention.append(name)
    attention = sorted(set(attention))

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == "__main__":
    main()
