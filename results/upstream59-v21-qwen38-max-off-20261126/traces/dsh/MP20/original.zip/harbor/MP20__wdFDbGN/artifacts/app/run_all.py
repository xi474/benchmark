"""Orchestrate all components based on contract.json files.

Discovers all contract.json files, determines execution order from dependencies,
and runs each component's render.py via subprocess.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def build_dependency_graph(contracts):
    """Build a dependency graph from contract inputs.
    
    Returns dict mapping contract_path -> set of contract_paths it depends on.
    Also returns mapping from output path to contract_path.
    """
    output_to_contract = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        output_to_contract[c['output']] = cp

    deps = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        dep_set = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_set.add(output_to_contract[inp])
        deps[cp] = dep_set

    return deps


def topological_sort(deps):
    """Topological sort of contract paths based on dependencies."""
    visited = set()
    order = []
    visiting = set()

    def visit(node):
        if node in visiting:
            raise ValueError("circular dependency detected")
        if node in visited:
            return
        visiting.add(node)
        for dep in deps.get(node, set()):
            visit(dep)
        visiting.remove(node)
        visited.add(node)
        order.append(node)

    for node in deps:
        visit(node)

    return order


def main():
    contracts = discover_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    deps = build_dependency_graph(contracts)
    order = topological_sort(deps)

    for cp in order:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"integrate.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py to produce final_report.json
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"final_report.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == "__main__":
    main()
