def transform(payloads, contract):
    """feature_references: validate segment and variant references.
    
    Input is feature_schema result (outputs/schema.json).
    First check all segment references (sorted by flag id, then rule id).
    Then check all variant references (within each flag only).
    Returns {ok: bool, error: null or {kind, flag, rule, target}}.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    schema_result = payloads[0]
    # The input is the schema output which has {name, result} wrapper
    # But per README: "当输入对象键恰为name/result时，仅其result为业务输入"
    if isinstance(schema_result, dict) and set(schema_result.keys()) == {'name', 'result'}:
        schema_data = schema_result['result']
    else:
        schema_data = schema_result

    flags = schema_data.get('flags', [])
    segments = schema_data.get('segments', [])

    # Build segment ID set
    segment_ids = {seg['id'] for seg in segments}

    # Sort flags by id for deterministic checking
    sorted_flags = sorted(flags, key=lambda f: f['id'])

    # Check segment references first
    for flag in sorted_flags:
        flag_id = flag['id']
        rules = flag.get('rules', [])
        sorted_rules = sorted(rules, key=lambda r: r['id'])
        for rule in sorted_rules:
            rule_id = rule['id']
            target_segment = rule['segment']
            if target_segment not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": flag_id,
                            "rule": rule_id,
                            "target": target_segment
                        }
                    }
                }

    # All segments valid, now check variant references
    for flag in sorted_flags:
        flag_id = flag['id']
        variant_ids = {v['id'] for v in flag.get('variants', [])}
        rules = flag.get('rules', [])
        sorted_rules = sorted(rules, key=lambda r: r['id'])
        for rule in sorted_rules:
            rule_id = rule['id']
            target_variant = rule['variant']
            if target_variant not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": flag_id,
                            "rule": rule_id,
                            "target": target_variant
                        }
                    }
                }

    return {
        "name": contract["name"],
        "result": {
            "ok": True,
            "error": None
        }
    }
