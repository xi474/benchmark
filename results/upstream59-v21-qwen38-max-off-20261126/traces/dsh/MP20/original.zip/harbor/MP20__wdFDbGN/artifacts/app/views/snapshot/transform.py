import copy
import json


def _canonical_json(obj):
    """Produce compact canonical JSON string."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _unwrap(payload):
    """If payload has exactly {name, result} keys, return result; otherwise return as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    """feature_snapshot: build exportable snapshot if references are valid.
    
    Inputs in order: case.json (original), schema result, attachments result, references result.
    On reference failure: atomic rollback returning old_snapshot.
    On success: construct snapshot with sorted flags/variants/rules/segments.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    original_input = payloads[0]
    schema_result = _unwrap(payloads[1])
    attachments_result = _unwrap(payloads[2])
    references_result = _unwrap(payloads[3])

    # Get old_snapshot from original input
    old_snapshot = original_input.get('old_snapshot', {})

    # Check if references failed
    if not references_result.get('ok', False):
        error = references_result.get('error')
        return {
            "name": contract["name"],
            "result": {
                "committed": False,
                "snapshot": copy.deepcopy(old_snapshot),
                "error": copy.deepcopy(error),
                "export": None
            }
        }

    # References OK - build snapshot
    flags_data = schema_result.get('flags', [])
    segments_data = schema_result.get('segments', [])
    attachments_data = attachments_result.get('attachments', {})

    # Build snapshot flags sorted by id
    snapshot_flags = []
    for flag in sorted(flags_data, key=lambda f: f['id']):
        flag_id = flag['id']
        flag_attachments = attachments_data.get(flag_id, {})

        # Variants sorted by id, with attachment value from attachments component
        snapshot_variants = []
        for variant in sorted(flag.get('variants', []), key=lambda v: v['id']):
            variant_id = variant['id']
            att_info = flag_attachments.get(variant_id, {})
            snapshot_variants.append({
                "id": variant_id,
                "attachment": copy.deepcopy(att_info.get('value', variant.get('attachment')))
            })

        # Rules sorted by id
        snapshot_rules = []
        for rule in sorted(flag.get('rules', []), key=lambda r: r['id']):
            snapshot_rules.append(copy.deepcopy(rule))

        snapshot_flags.append({
            "id": flag_id,
            "variants": snapshot_variants,
            "rules": snapshot_rules
        })

    # Segments sorted by id
    snapshot_segments = [copy.deepcopy(s) for s in sorted(segments_data, key=lambda s: s['id'])]

    snapshot = {
        "flags": snapshot_flags,
        "segments": snapshot_segments
    }

    export_str = _canonical_json(snapshot)

    return {
        "name": contract["name"],
        "result": {
            "committed": True,
            "snapshot": snapshot,
            "error": None,
            "export": export_str
        }
    }
