# Workflow 可观测性报告

- Trial：`MP21__jmM46CP__env`
- Task：`MP21`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（63 节点 / 62 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：63；执行边：62（observed=0，inferred=62）
- Execution Trace Graph：`observed`；temporal_next 边 62，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_cdc4d2b8fa7047889b3b8aed -> tool:dsh:lead:call_f491ae3340004abeb8bb0c09 -> tool:dsh:lead:call_529c87ca4ef54cee9561bc3e -> tool:dsh:lead:call_c157c0793a334de4877dfbf0 -> tool:dsh:lead:call_f12ec73231864145b6e16a35 -> tool:dsh:lead:call_5ccacaa29f4944398868ccc8 -> tool:dsh:lead:call_c6dd49a2993549d28244a28c -> tool:dsh:lead:call_d49a8a51945e41e2a074eb73 -> tool:dsh:lead:call_2e93dd94c52f4401af15531d -> tool:dsh:lead:call_ebcf1d7d45c44f4d83868c44 -> tool:dsh:lead:call_6bdd3e4c4e364765856de3cc -> tool:dsh:lead:call_cb09489aea2b4c04b431f405 -> tool:dsh:lead:call_c3e09fbe217d4e4a908074bc -> tool:dsh:lead:call_5fd27bf94c154696af9483a7 -> tool:dsh:lead:call_fb294fe147824f41aa6b4bc3 -> tool:dsh:lead:call_18935589365d4b16a87e8323 -> tool:dsh:lead:call_9e63a15c34444dab9c0bfde3 -> tool:dsh:lead:call_a785729ec0c944e0805f2326 -> tool:dsh:lead:call_7fc3a8ee982a4c0595ceb77e -> tool:dsh:lead:call_1e9a9598cb9f4c4c8cd9248f -> tool:dsh:lead:call_5887878640994e2096a087c1 -> tool:dsh:lead:call_f48121da5c9542f9a73921ab -> tool:dsh:lead:call_ee3fda23e0e64c1bb38819be -> tool:dsh:lead:call_b74d0a01037042f096de4308 -> tool:dsh:lead:call_d808a5588a9049ca968b6a0a -> tool:dsh:lead:call_6cb4c7c33c304b2287e6b47c -> tool:dsh:lead:call_5e604af1f7874962903afc69 -> tool:dsh:lead:call_702db5514ba14e91b01c8b16 -> tool:dsh:lead:call_2e3ece7d3a2241928f15f7df -> tool:dsh:lead:call_96c6d554f4fc41faa7ab3217 -> tool:dsh:lead:call_cd94db8eb95c4dd790e5755c -> tool:dsh:lead:call_3d52b780f06748daa8cc3519 -> tool:dsh:lead:call_241ae3aee5c24a71b7381e87 -> tool:dsh:lead:call_74b13096fab44cfabf6ac18b -> tool:dsh:lead:call_d45e0d59951046ae9d69857c -> tool:dsh:lead:call_dd3c196ff72f4c54a90d2c8c -> tool:dsh:lead:call_429d34d2af2b49579ffcb5d7 -> tool:dsh:lead:call_9fe357863dd449ccbc9426a8 -> tool:dsh:lead:call_df7f07c9fd6d4652a6a64d11 -> tool:dsh:lead:call_24e017c077fa4bfaa933756b -> tool:dsh:lead:call_e0c190d3e85c45e79ca35ca9 -> tool:dsh:lead:call_6a88d2172b7c4f74a8340f0a -> tool:dsh:lead:call_6347fd1bff8a4f27b4d3f535 -> tool:dsh:lead:call_859e55b8b2084dafa626dfcb -> tool:dsh:lead:call_511f2bef41b54483bf2729b8 -> tool:dsh:lead:call_4f6cb3e47f114646b6da7ca4 -> tool:dsh:lead:call_b5d5af5b88ae4bedb0067508 -> tool:dsh:lead:call_acdac380f970407f9b0fca96 -> tool:dsh:lead:call_c4de3e7aa55c427897b98b4b -> tool:dsh:lead:call_124b276d2b734c98864a1696 -> tool:dsh:lead:call_5a42919ab08c4254b1ca3b30 -> tool:dsh:lead:call_7730b431c85342c386a54f91 -> tool:dsh:lead:call_2efc897985254d4594669670 -> tool:dsh:lead:call_774fa1a16d2f4713a5618372 -> tool:dsh:lead:call_6c930e6669dc408083d11b55 -> tool:dsh:lead:call_78dafd5ddac1422796543e37 -> tool:dsh:lead:call_2991f444f88741be85f23f44 -> tool:dsh:lead:call_60a49661dba74930a28975c0 -> tool:dsh:lead:call_300ea5889165407c9f92cad6 -> tool:dsh:lead:call_8bce8a1d9db048cfb32a3010 -> tool:dsh:lead:call_29800b5e41454956aa423fb8 -> tool:dsh:lead:call_dfc92a335d444c9dbcf25fd2
- 关键路径耗时：1.713
- Makespan：258.703
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
