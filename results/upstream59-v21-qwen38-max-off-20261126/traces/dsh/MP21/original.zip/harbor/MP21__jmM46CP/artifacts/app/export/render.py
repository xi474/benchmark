import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """
    Read all inputs specified in contract, call transform, return the envelope.
    root: workspace root Path
    contract_path: path to this component's contract.json
    """
    try:
        from .model import load_payload
        from .transform import transform
    except ImportError:
        component_dir = Path(__file__).resolve().parent
        sys.path.insert(0, str(component_dir))
        from model import load_payload
        from transform import transform
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with standard formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    component_dir = Path(__file__).resolve().parent
    root = component_dir.parent
    contract_path = component_dir / "contract.json"
    
    result = build_component(root, contract_path)
    
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    output_path = root / contract["output"]
    _write_json(output_path, result)
