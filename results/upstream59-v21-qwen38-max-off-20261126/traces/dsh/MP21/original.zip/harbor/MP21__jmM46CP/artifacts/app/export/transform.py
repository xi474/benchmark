from decimal import Decimal, ROUND_HALF_UP


def _unwrap(payload):
    """
    If payload is an object with exactly keys {name, result}, return result.
    Otherwise return payload as-is.
    """
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    """
    playlist_m3u operation.
    
    Input: playlist_replace result {playlist:{id,name,...}, tracks:[...]}.
    When wrapped in {name, result} envelope, unwrap to get the business data.
    
    Returns: {"name": contract["name"], "result": {m3u: str}}
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    data = _unwrap(payloads[0])
    
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if "playlist" not in data or "tracks" not in data:
        raise ValueError("missing required fields")
    
    playlist = data["playlist"]
    tracks = data["tracks"]
    
    if not isinstance(playlist, dict):
        raise ValueError("playlist must be an object")
    if not isinstance(tracks, list):
        raise ValueError("tracks must be a list")
    
    name = playlist.get("name", "")
    if not isinstance(name, str):
        raise ValueError("playlist name must be a string")
    
    # Check for CR/LF injection in name
    if "\r" in name or "\n" in name:
        raise ValueError("playlist name contains CR/LF")
    
    lines = []
    lines.append("#EXTM3U")
    lines.append(f"#PLAYLIST:{name}")
    
    for t in tracks:
        if not isinstance(t, dict):
            raise ValueError("each track must be an object")
        
        duration = t.get("duration")
        artist = t.get("artist", "")
        title = t.get("title", "")
        path = t.get("path", "")
        
        if not isinstance(artist, str):
            raise ValueError("artist must be a string")
        if not isinstance(title, str):
            raise ValueError("title must be a string")
        if not isinstance(path, str):
            raise ValueError("path must be a string")
        
        # Check CR/LF in artist/title/path
        for field_name, field_val in [("artist", artist), ("title", title), ("path", path)]:
            if "\r" in field_val or "\n" in field_val:
                raise ValueError(f"{field_name} contains CR/LF")
        
        # Round duration using Decimal ROUND_HALF_UP
        d = Decimal(str(duration))
        int_seconds = int(d.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        
        lines.append(f"#EXTINF:{int_seconds},{artist} - {title}")
        lines.append(path)
    
    m3u = "\n".join(lines) + "\n"
    
    return {
        "name": contract["name"],
        "result": {
            "m3u": m3u,
        },
    }
