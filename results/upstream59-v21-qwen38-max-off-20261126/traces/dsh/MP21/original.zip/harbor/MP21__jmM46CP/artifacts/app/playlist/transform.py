def transform(payloads, contract):
    """
    playlist_replace operation.
    
    Input: single payload with {tracks, playlist, replacement, criteria}.
    - tracks: [{id, title, artist, path, duration}]  (duration: non-negative finite seconds)
    - playlist: {id, name, track_ids, track_count, duration}
    - replacement: [track_id] - IDs to replace the playlist with (duplicates allowed, order preserved)
    - criteria: object (unused by this component but present in input)
    
    Returns: {"name": contract["name"], "result": {playlist: {...}, tracks: [...]}}
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    # Validate required fields
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    
    for key in ("tracks", "playlist", "replacement"):
        if key not in data:
            raise ValueError(f"missing required field: {key}")
    
    tracks_list = data["tracks"]
    playlist = data["playlist"]
    replacement = data["replacement"]
    
    if not isinstance(tracks_list, list):
        raise ValueError("tracks must be a list")
    if not isinstance(playlist, dict):
        raise ValueError("playlist must be an object")
    if not isinstance(replacement, list):
        raise ValueError("replacement must be a list")
    
    # Build track lookup by id; validate uniqueness
    track_map = {}
    for t in tracks_list:
        if not isinstance(t, dict):
            raise ValueError("each track must be an object")
        tid = t.get("id")
        if tid is None:
            raise ValueError("track missing id")
        if tid in track_map:
            raise ValueError(f"duplicate track id: {tid}")
        
        # Validate duration: non-negative finite number (not bool)
        dur = t.get("duration")
        if isinstance(dur, bool):
            raise ValueError("duration must not be bool")
        if not isinstance(dur, (int, float)):
            raise ValueError("duration must be a number")
        import math
        if math.isnan(dur) or math.isinf(dur):
            raise ValueError("duration must be finite")
        if dur < 0:
            raise ValueError("duration must be non-negative")
        
        track_map[tid] = t
    
    # Validate replacement IDs exist
    for rid in replacement:
        if rid not in track_map:
            raise ValueError(f"unknown track id in replacement: {rid}")
    
    # Build new playlist
    new_track_ids = list(replacement)  # preserve order and duplicates
    new_track_count = len(new_track_ids)
    
    # Duration: sum of durations counting each occurrence
    new_duration = 0.0
    for rid in new_track_ids:
        new_duration += track_map[rid]["duration"]
    
    # Build result tracks list (in replacement order, with duplicates)
    result_tracks = []
    for rid in new_track_ids:
        orig = track_map[rid]
        result_tracks.append({
            "id": orig["id"],
            "title": orig["title"],
            "artist": orig["artist"],
            "path": orig["path"],
            "duration": orig["duration"],
        })
    
    new_playlist = {
        "id": playlist["id"],
        "name": playlist["name"],
        "track_ids": new_track_ids,
        "track_count": new_track_count,
        "duration": new_duration,
    }
    
    return {
        "name": contract["name"],
        "result": {
            "playlist": new_playlist,
            "tracks": result_tracks,
        },
    }
