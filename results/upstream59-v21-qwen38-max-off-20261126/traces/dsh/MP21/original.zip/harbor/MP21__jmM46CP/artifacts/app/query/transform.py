import math


def transform(payloads, contract):
    """
    playlist_query operation.
    
    Input: single payload with criteria:{filters:[{field,op,value}], limit:int 1..100}.
    Fields: id/name (str value, eq/ne only), track_count/duration (non-negative finite number, any op).
    All conditions AND-connected, order preserved, values use SQL placeholders.
    
    Returns: {"name": contract["name"], "result": {sql: str, params: list}}
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if "criteria" not in data:
        raise ValueError("missing required field: criteria")
    
    criteria = data["criteria"]
    if not isinstance(criteria, dict):
        raise ValueError("criteria must be an object")
    if "filters" not in criteria:
        raise ValueError("missing required field: filters")
    if "limit" not in criteria:
        raise ValueError("missing required field: limit")
    
    filters = criteria["filters"]
    limit = criteria["limit"]
    
    if not isinstance(filters, list):
        raise ValueError("filters must be a list")
    
    # Validate limit: int 1..100, not bool
    if isinstance(limit, bool):
        raise ValueError("limit must not be bool")
    if not isinstance(limit, int):
        raise ValueError("limit must be an integer")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be 1..100")
    
    valid_fields = {"id", "name", "track_count", "duration"}
    valid_ops = {"eq", "ne", "gt", "ge", "lt", "le"}
    str_fields = {"id", "name"}
    num_fields = {"track_count", "duration"}
    
    op_map = {
        "eq": "=",
        "ne": "!=",
        "gt": ">",
        "ge": ">=",
        "lt": "<",
        "le": "<=",
    }
    
    conditions = []
    params = []
    
    for f in filters:
        if not isinstance(f, dict):
            raise ValueError("each filter must be an object")
        if "field" not in f or "op" not in f or "value" not in f:
            raise ValueError("filter missing required fields")
        
        field = f["field"]
        op = f["op"]
        value = f["value"]
        
        if field not in valid_fields:
            raise ValueError(f"invalid field: {field}")
        if op not in valid_ops:
            raise ValueError(f"invalid op: {op}")
        
        # String fields: value must be str, only eq/ne
        if field in str_fields:
            if not isinstance(value, str):
                raise ValueError(f"value for {field} must be string")
            if op not in ("eq", "ne"):
                raise ValueError(f"field {field} only supports eq/ne")
        elif field in num_fields:
            # Numeric fields: value must be non-negative finite number, not bool
            if isinstance(value, bool):
                raise ValueError(f"value for {field} must not be bool")
            if not isinstance(value, (int, float)):
                raise ValueError(f"value for {field} must be a number")
            if math.isnan(value) or math.isinf(value):
                raise ValueError(f"value for {field} must be finite")
            if value < 0:
                raise ValueError(f"value for {field} must be non-negative")
        
        conditions.append(f"{field} {op_map[op]} ?")
        params.append(value)
    
    sql = "SELECT id FROM playlists"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)
    
    return {
        "name": contract["name"],
        "result": {
            "sql": sql,
            "params": params,
        },
    }
