"""
Orchestrate all components based on their contract.json files.

Execution order is determined by dependency analysis:
- Components whose inputs reference other components' outputs must run after those components.
- Within the same level, components are sorted alphabetically by directory name.

Each component is executed via: python3 <component_dir>/render.py
Then integrate.py is run to produce core_manifest.json.
Finally final_report.py is run to produce final_report.json.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def find_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_execution_order(contracts):
    """
    Topological sort of components based on input dependencies.
    A component depends on another if any of its inputs references an output path
    that matches another component's output.
    """
    # Map output paths to component names
    output_to_component = {}
    component_info = {}
    
    for cp in contracts:
        c = load_contract(cp)
        name = c["name"]
        output = c["output"]
        component_info[name] = {
            "contract_path": cp,
            "render_path": cp.with_name("render.py"),
            "inputs": c["inputs"],
            "output": output,
        }
        output_to_component[output] = name
    
    # Build dependency graph
    deps = {name: set() for name in component_info}
    for name, info in component_info.items():
        for inp in info["inputs"]:
            if inp in output_to_component:
                dep_name = output_to_component[inp]
                if dep_name != name:
                    deps[name].add(dep_name)
    
    # Topological sort (Kahn's algorithm)
    in_degree = {name: len(d) for name, d in deps.items()}
    queue = sorted([n for n, d in in_degree.items() if d == 0])
    order = []
    
    while queue:
        node = queue.pop(0)
        order.append(node)
        for name in sorted(deps.keys()):
            if node in deps[name]:
                deps[name].discard(node)
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)
        queue.sort()
    
    if len(order) != len(component_info):
        raise ValueError("circular dependency detected")
    
    return order, component_info


def main():
    contracts = find_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)
    
    order, component_info = resolve_execution_order(contracts)
    
    # Execute each component in order
    for name in order:
        info = component_info[name]
        render_path = info["render_path"]
        
        if not render_path.exists():
            print(f"Missing render.py for component {name}", file=sys.stderr)
            sys.exit(1)
        
        result = subprocess.run(
            [sys.executable, str(render_path)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py
    integrate_path = ROOT / "integrate.py"
    if integrate_path.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_path)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py
    report_path = ROOT / "final_report.py"
    if report_path.exists():
        result = subprocess.run(
            [sys.executable, str(report_path)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
