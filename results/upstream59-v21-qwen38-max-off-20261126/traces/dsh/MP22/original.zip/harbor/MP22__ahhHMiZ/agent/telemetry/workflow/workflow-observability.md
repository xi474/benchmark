# Workflow 可观测性报告

- Trial：`MP22__ahhHMiZ__env`
- Task：`MP22`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（65 节点 / 64 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：65；执行边：64（observed=0，inferred=64）
- Execution Trace Graph：`observed`；temporal_next 边 64，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_13f0a8b2c28b4ae29382939d -> tool:dsh:lead:call_bcebc917e47d44619713154b -> tool:dsh:lead:call_fb9f0c84ba85434b9da8f3e6 -> tool:dsh:lead:call_ebee1054d82a4a249dedfdd1 -> tool:dsh:lead:call_5162baa70642419b85a2aec2 -> tool:dsh:lead:call_14a7477a93004d5893219654 -> tool:dsh:lead:call_9689ea940a7e45d9a3fde125 -> tool:dsh:lead:call_f816e636b94f40eba341717e -> tool:dsh:lead:call_77fefaf62efe42d6af7b2221 -> tool:dsh:lead:call_b1e69f8da5f440db9e20d090 -> tool:dsh:lead:call_4bd6e63b8d5444958c617ce6 -> tool:dsh:lead:call_5291e607f998412c9eadafe0 -> tool:dsh:lead:call_987251730f1847cd832952d4 -> tool:dsh:lead:call_33294e684d224e23ae304aa1 -> tool:dsh:lead:call_cdb2f8b093c2465cb7fc2d9e -> tool:dsh:lead:call_4b636c1a59ca4642bd99344d -> tool:dsh:lead:call_025bc0ff641b474db5d2c879 -> tool:dsh:lead:call_49a81d81af9347e6bba0b043 -> tool:dsh:lead:call_b138f92413fe45cea987029c -> tool:dsh:lead:call_8a3637c3c24443eebf8016a2 -> tool:dsh:lead:call_b8526edab4d249adb9e6f2c7 -> tool:dsh:lead:call_c01d1bb8e7364d72ae85aed5 -> tool:dsh:lead:call_56c61e12dc5e4bd08fb29120 -> tool:dsh:lead:call_4f1479c3d774446aa8db6186 -> tool:dsh:lead:call_13af42435ef24f83a3175fbb -> tool:dsh:lead:call_47ef56379ef24e0ea4dfc43b -> tool:dsh:lead:call_c0f6334b1e2f4f67bbbbced2 -> tool:dsh:lead:call_f57715b557414ab0bf0a48a9 -> tool:dsh:lead:call_7f0247c32b044839b0d6c68f -> tool:dsh:lead:call_0bd61c33119246f7b2f0adb7 -> tool:dsh:lead:call_91fd932d023348618f216b26 -> tool:dsh:lead:call_5ba54cc61545477ca6f96f74 -> tool:dsh:lead:call_075e326df26d4345b4df7399 -> tool:dsh:lead:call_557d467c28234e6b8f000ad3 -> tool:dsh:lead:call_a753de0df0da4e99b0a7b327 -> tool:dsh:lead:call_3d183b6b6110415f93596dd2 -> tool:dsh:lead:call_89db389717c44c2ba3993853 -> tool:dsh:lead:call_89bc29a4ce4243278307d496 -> tool:dsh:lead:call_2700da793a1d40a49154d982 -> tool:dsh:lead:call_e61dc8540cb4483681c2940e -> tool:dsh:lead:call_1842ac5eef494e0a8ba80e92 -> tool:dsh:lead:call_cf15edba644845ab96e7c229 -> tool:dsh:lead:call_e602edef3a5946eda9ef24f0 -> tool:dsh:lead:call_fa3c303b92824c2e8fe28426 -> tool:dsh:lead:call_766b91067f3c405f8a6d312f -> tool:dsh:lead:call_acb9524b925e48b3a9bcf5e7 -> tool:dsh:lead:call_f698579b82464df99b08046d -> tool:dsh:lead:call_45c722d648f14ce5837a4f8b -> tool:dsh:lead:call_d412393760334168894f3f89 -> tool:dsh:lead:call_c4dce99960a744859c234060 -> tool:dsh:lead:call_4b91921c1e3844c28ef1534a -> tool:dsh:lead:call_550078fd17e7403092fe2304 -> tool:dsh:lead:call_81dfee08e85b44de8fd9eb22 -> tool:dsh:lead:call_585f6c6503814d1ebce53a63 -> tool:dsh:lead:call_ce39d336682b47f6b16476a6 -> tool:dsh:lead:call_9a724b068fa342359a220351 -> tool:dsh:lead:call_c48b0be206e04fb5b6472089 -> tool:dsh:lead:call_ae2a3f2101b74890909f16c2 -> tool:dsh:lead:call_e271aad877594344acf705a9 -> tool:dsh:lead:call_f4416b22094e4416991aa723 -> tool:dsh:lead:call_fda4f3b4eb274a36b9b78208 -> tool:dsh:lead:call_c75a90108a3f4f9092b6ea31 -> tool:dsh:lead:call_b251cdadf36648caa7a23e9b -> tool:dsh:lead:call_212ee95b942d4bd1b1dd832f
- 关键路径耗时：1.879
- Makespan：257.243
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
