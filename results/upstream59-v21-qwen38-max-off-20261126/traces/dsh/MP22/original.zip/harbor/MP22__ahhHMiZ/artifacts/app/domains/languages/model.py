import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON file; only object/array top-level allowed.
    Raises ValueError for invalid JSON, non-object/array top-level,
    or any nested NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    # Reject NaN/Infinity by using a strict parse
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    # Check for NaN/Infinity in nested structures
    _check_finite(data)
    return data


def _check_finite(obj):
    """Recursively check that no float NaN/Infinity exists."""
    if isinstance(obj, float):
        import math
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number found")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
