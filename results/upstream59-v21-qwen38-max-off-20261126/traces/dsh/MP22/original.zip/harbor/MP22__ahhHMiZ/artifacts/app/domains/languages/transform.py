def transform(payloads, contract):
    """Extract language codes from MARC records.
    
    Input: [original input (case.json), marc_xml_records result]
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    original_input = payloads[0]
    reader_result = payloads[1]
    
    # Get valid language codes from original input
    if not isinstance(original_input, dict):
        raise ValueError("original input must be object")
    if "language_codes" not in original_input:
        raise ValueError("missing language_codes")
    
    valid_codes = original_input["language_codes"]
    if not isinstance(valid_codes, list):
        raise ValueError("language_codes must be array")
    for code in valid_codes:
        if not isinstance(code, str) or len(code) != 3 or not code.islower() or not code.isalpha():
            raise ValueError(f"invalid language code: {code}")
    valid_set = set(valid_codes)
    
    # Get records from reader result
    if isinstance(reader_result, dict) and "result" in reader_result:
        records_data = reader_result["result"]["records"]
    elif isinstance(reader_result, dict) and "records" in reader_result:
        records_data = reader_result["records"]
    else:
        raise ValueError("invalid reader result")
    
    out_records = []
    for rec in records_data:
        rec_id = rec["id"]
        controls = rec.get("controls", {})
        fields = rec.get("fields", [])
        
        languages = set()
        
        # Extract from 008 controlfield (positions 35-37)
        if "008" in controls:
            field_008 = controls["008"]
            if len(field_008) >= 38:
                lang_code = field_008[35:38]
                if lang_code in valid_set:
                    languages.add(lang_code)
        
        # Extract from 041 datafields
        for field in fields:
            if field["tag"] == "041":
                for sf in field["subfields"]:
                    if sf["code"] in ("a", "d", "h"):
                        val = sf["value"].strip()
                        if len(val) % 3 != 0:
                            raise ValueError(f"041 subfield length not multiple of 3: '{val}'")
                        for i in range(0, len(val), 3):
                            code = val[i:i+3]
                            if code in valid_set:
                                languages.add(code)
        
        sorted_langs = sorted(languages)
        out_records.append({"id": rec_id, "languages": sorted_langs})
    
    return {"name": contract["name"], "result": {"records": out_records}}
