import re


def transform(payloads, contract):
    """Extract author/title names and alternate script links from MARC records.
    
    Input: [marc_xml_records result]
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    reader_result = payloads[0]
    if not isinstance(reader_result, dict) or "result" not in reader_result:
        # If it's already the inner result (from output file), handle that
        if isinstance(reader_result, dict) and "records" in reader_result:
            records_data = reader_result["records"]
        else:
            raise ValueError("invalid reader input")
    else:
        records_data = reader_result["result"]["records"]
    
    out_records = []
    for rec in records_data:
        rec_id = rec["id"]
        fields = rec["fields"]
        
        # Build 880 linkage map: key=(base_tag, nn) -> list of 880 subfields
        link_880 = {}  # (target_tag, nn) -> list of subfield lists
        base_links = {}  # (tag, field_index) -> (target_tag, nn) for 100/245 $6
        
        # First pass: collect all 880 fields and their $6 links
        for fi, field in enumerate(fields):
            tag = field["tag"]
            subfields = field["subfields"]
            
            if tag == "880":
                # Find $6
                s6_val = None
                for sf in subfields:
                    if sf["code"] == "6":
                        s6_val = sf["value"]
                        break
                if s6_val is None:
                    continue
                # Parse: should be like "100-01" or "245-01" (possibly with /suffix)
                parsed = _parse_link(s6_val)
                if parsed is None:
                    continue
                target_tag, nn = parsed
                if target_tag not in ("100", "245"):
                    continue
                key = (target_tag, nn)
                if key not in link_880:
                    link_880[key] = []
                link_880[key].append(subfields)
            
            elif tag in ("100", "245"):
                # Check for $6
                s6_val = None
                for sf in subfields:
                    if sf["code"] == "6":
                        s6_val = sf["value"]
                        break
                if s6_val is not None:
                    parsed = _parse_link(s6_val)
                    if parsed is not None:
                        target_tag, nn = parsed
                        if target_tag == "880":
                            base_links[(tag, fi)] = ("880", nn)
        
        # Now process 100 and 245 fields in order
        authors = []
        titles = []
        
        for fi, field in enumerate(fields):
            tag = field["tag"]
            subfields = field["subfields"]
            
            if tag == "100":
                name = _extract_ab(subfields)
                alternates = []
                # Check if this 100 has a $6 linking to 880
                link_key = base_links.get((tag, fi))
                if link_key:
                    _, nn = link_key
                    alt_key = ("100", nn)
                    if alt_key in link_880:
                        for alt_sfs in link_880[alt_key]:
                            alt_name = _extract_ab(alt_sfs)
                            if alt_name and alt_name not in alternates:
                                alternates.append(alt_name)
                alternates.sort()
                authors.append({"name": name, "alternates": alternates})
            
            elif tag == "245":
                title = _extract_ab(subfields)
                alternates = []
                link_key = base_links.get((tag, fi))
                if link_key:
                    _, nn = link_key
                    alt_key = ("245", nn)
                    if alt_key in link_880:
                        for alt_sfs in link_880[alt_key]:
                            alt_title = _extract_ab(alt_sfs)
                            if alt_title and alt_title not in alternates:
                                alternates.append(alt_title)
                alternates.sort()
                titles.append({"title": title, "alternates": alternates})
        
        out_records.append({
            "id": rec_id,
            "authors": authors,
            "titles": titles
        })
    
    return {"name": contract["name"], "result": {"records": out_records}}


def _parse_link(val):
    """Parse a $6 link value like '880-01' or '100-01' or '100-01/suffix'.
    Returns (tag, nn) or None."""
    val = val.strip()
    # Remove /suffix if present
    if "/" in val:
        val = val[:val.index("/")]
    parts = val.split("-")
    if len(parts) != 2:
        return None
    tag_part = parts[0]
    nn_part = parts[1]
    if not tag_part.isdigit() or len(tag_part) != 3:
        return None
    if not nn_part.isdigit():
        return None
    return (tag_part, nn_part)


def _extract_ab(subfields):
    """Extract $a and $b from subfields, join them, clean up."""
    parts = []
    for sf in subfields:
        if sf["code"] in ("a", "b"):
            parts.append(sf["value"])
    text = " ".join(parts)
    # Collapse internal whitespace
    text = re.sub(r'\s+', ' ', text)
    # Strip leading/trailing whitespace
    text = text.strip()
    # Strip trailing slash, comma, colon, semicolon (but keep period)
    while text and text[-1] in ('/', ',', ':', ';'):
        text = text[:-1].rstrip()
    # Strip leading slash, comma, colon, semicolon
    while text and text[0] in ('/', ',', ':', ';'):
        text = text[1:].lstrip()
    return text
