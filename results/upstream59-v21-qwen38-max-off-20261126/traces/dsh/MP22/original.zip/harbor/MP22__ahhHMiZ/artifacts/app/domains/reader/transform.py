import xml.etree.ElementTree as ET


def transform(payloads, contract):
    """Parse MARC XML and extract records.
    
    Input: [{xml: str, language_codes: [...]}]
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("input must be object")
    if "xml" not in payload:
        raise ValueError("missing 'xml' field")
    
    xml_str = payload["xml"]
    if not isinstance(xml_str, str):
        raise ValueError("'xml' must be string")
    
    # Reject DOCTYPE/ENTITY
    upper = xml_str.upper()
    if "<!DOCTYPE" in upper or "<!ENTITY" in upper:
        raise ValueError("DOCTYPE/ENTITY not allowed")
    
    # Parse XML
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError as e:
        raise ValueError(f"invalid XML: {e}") from e
    
    # Handle namespace
    ns = ""
    tag = root.tag
    if tag.startswith("{"):
        ns = tag[:tag.index("}") + 1]
    
    local_tag = tag[len(ns):] if ns else tag
    
    # Accept collection or record root
    if local_tag == "collection":
        record_elements = _find_children(root, ns, "record")
    elif local_tag == "record":
        record_elements = [root]
    else:
        raise ValueError(f"root must be collection or record, got {local_tag}")
    
    records = []
    seen_ids = set()
    
    for rec_el in record_elements:
        rec = _parse_record(rec_el, ns)
        if rec["id"] in seen_ids:
            raise ValueError(f"duplicate record id: {rec['id']}")
        seen_ids.add(rec["id"])
        records.append(rec)
    
    # Sort by id
    records.sort(key=lambda r: r["id"])
    
    return {"name": contract["name"], "result": {"records": records}}


def _find_children(parent, ns, local_name):
    """Find direct children with given local name, respecting namespace."""
    result = []
    full_tag = ns + local_name if ns else local_name
    for child in parent:
        if child.tag == full_tag:
            result.append(child)
    return result


def _parse_record(rec_el, ns):
    """Parse a single MARC record element."""
    controls = {}
    fields = []
    record_id = None
    
    for child in rec_el:
        ctag = child.tag
        local = ctag[len(ns):] if ns and ctag.startswith(ns) else ctag
        
        if local == "controlfield":
            tag_attr = child.attrib.get("tag", "")
            if not tag_attr or len(tag_attr) != 3 or not tag_attr.isdigit():
                raise ValueError(f"invalid controlfield tag: {tag_attr}")
            if tag_attr in controls:
                raise ValueError(f"duplicate controlfield tag: {tag_attr}")
            text = child.text or ""
            if tag_attr == "001":
                if not text.strip():
                    raise ValueError("001 controlfield must be non-empty")
                record_id = text
            controls[tag_attr] = text
            
        elif local == "datafield":
            tag_attr = child.attrib.get("tag", "")
            if not tag_attr or len(tag_attr) != 3 or not tag_attr.isdigit():
                raise ValueError(f"invalid datafield tag: {tag_attr}")
            subfields = []
            for sf in child:
                sf_local = sf.tag[len(ns):] if ns and sf.tag.startswith(ns) else sf.tag
                if sf_local != "subfield":
                    raise ValueError(f"unexpected element in datafield: {sf_local}")
                code = sf.attrib.get("code", "")
                if not code or len(code) != 1 or not (code.isalpha() or code.isdigit()):
                    raise ValueError(f"invalid subfield code: {code}")
                value = sf.text or ""
                subfields.append({"code": code, "value": value})
            fields.append({"tag": tag_attr, "subfields": subfields})
        else:
            raise ValueError(f"unknown element in record: {local}")
    
    if record_id is None:
        raise ValueError("record missing 001 controlfield")
    
    return {"id": record_id, "controls": controls, "fields": fields}
