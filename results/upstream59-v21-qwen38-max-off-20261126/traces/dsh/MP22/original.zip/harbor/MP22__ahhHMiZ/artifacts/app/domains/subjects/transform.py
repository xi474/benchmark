import re


# Mapping from MARC tag to subject category
TAG_CATEGORY = {
    "600": "people",
    "610": "organizations",
    "611": "meetings",
    "630": "works",
    "650": "topics",
    "651": "places",
}

ALL_CATEGORIES = ["people", "organizations", "meetings", "works", "topics", "places"]


def transform(payloads, contract):
    """Extract and count subject headings from MARC records.
    
    Input: [marc_xml_records result]
    Output: {"name": contract["name"], "result": {"records": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    reader_result = payloads[0]
    
    if isinstance(reader_result, dict) and "result" in reader_result:
        records_data = reader_result["result"]["records"]
    elif isinstance(reader_result, dict) and "records" in reader_result:
        records_data = reader_result["records"]
    else:
        raise ValueError("invalid reader result")
    
    out_records = []
    for rec in records_data:
        rec_id = rec["id"]
        fields = rec.get("fields", [])
        
        # Count subjects by category
        counts = {cat: {} for cat in ALL_CATEGORIES}
        
        for field in fields:
            tag = field["tag"]
            if tag not in TAG_CATEGORY:
                continue
            
            category = TAG_CATEGORY[tag]
            subfields = field["subfields"]
            
            # Build main heading from $a/$b
            main_parts = []
            subdivision_parts = []
            
            for sf in subfields:
                code = sf["code"]
                value = sf["value"]
                if code in ("a", "b"):
                    main_parts.append(value)
                elif code in ("v", "x", "y", "z"):
                    subdivision_parts.append(value)
            
            # Join main parts
            main_heading = " ".join(main_parts)
            main_heading = _clean_segment(main_heading)
            
            # Build full heading with subdivisions
            segments = [main_heading]
            for sp in subdivision_parts:
                segments.append(_clean_segment(sp))
            
            full_heading = " -- ".join(segments)
            
            # Count occurrences
            if full_heading in counts[category]:
                counts[category][full_heading] += 1
            else:
                counts[category][full_heading] = 1
        
        # Format output: each category has list of {value, count} sorted by value
        subjects = {}
        for cat in ALL_CATEGORIES:
            items = [{"value": v, "count": c} for v, c in counts[cat].items()]
            items.sort(key=lambda x: x["value"])
            subjects[cat] = items
        
        out_records.append({"id": rec_id, "subjects": subjects})
    
    return {"name": contract["name"], "result": {"records": out_records}}


def _clean_segment(text):
    """Clean a subject segment: collapse whitespace, strip edges."""
    # Collapse internal whitespace
    text = re.sub(r'\s+', ' ', text)
    # Strip leading/trailing whitespace
    text = text.strip()
    # Strip trailing slash, comma, colon, semicolon (but keep period)
    while text and text[-1] in ('/', ',', ':', ';'):
        text = text[:-1].rstrip()
    # Strip leading slash, comma, colon, semicolon
    while text and text[0] in ('/', ',', ':', ';'):
        text = text[1:].lstrip()
    return text
