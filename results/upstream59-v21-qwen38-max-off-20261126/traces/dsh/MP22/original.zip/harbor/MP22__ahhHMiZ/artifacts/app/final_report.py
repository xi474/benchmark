"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    if not core_path.is_file():
        raise ValueError("core_manifest.json not found")
    
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)
    
    components = core.get("components", {})
    
    # Compute SHA256 of the canonical serialization of the full core object
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(canonical).hexdigest()
    
    # Determine attention list
    attention = set()
    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue
        
        # Check result.blocked explicitly true
        if comp_result.get("blocked") is True:
            attention.add(comp_name)
        
        # Check complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in comp_result and comp_result[key] is False:
                attention.add(comp_name)
        
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = comp_result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0 and val is not False:
                # Non-empty means truthy for lists/dicts/strings
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, bool) and val:
                    attention.add(comp_name)
    
    report = {
        "title": "MARC 作者标题、语言和主题导入",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": sorted(attention)
    }
    
    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )


if __name__ == "__main__":
    main()
