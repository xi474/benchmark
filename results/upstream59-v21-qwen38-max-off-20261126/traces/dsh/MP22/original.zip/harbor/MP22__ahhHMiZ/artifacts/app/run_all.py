"""Orchestrate all component builds in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    
    if not contracts:
        raise ValueError("no contracts found")
    
    # Build dependency graph from contract inputs
    # Each contract's inputs may reference outputs of other contracts
    contract_map = {}  # output_path -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        out = c["output"]
        contract_map[out] = cp
    
    # Topological sort
    # Build adjacency: for each contract, find which other contracts it depends on
    deps = {}  # contract_path -> set of contract_paths it depends on
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        dep_set = set()
        for inp in c["inputs"]:
            if inp in contract_map:
                dep_set.add(contract_map[inp])
        deps[cp] = dep_set
    
    # Kahn's algorithm
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    order = []
    
    while queue:
        queue.sort()  # deterministic order
        cp = queue.pop(0)
        order.append(cp)
        for other in contracts:
            if cp in deps[other]:
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)
    
    if len(order) != len(contracts):
        raise ValueError("dependency cycle detected")
    
    # Execute each component via its render.py
    for cp in order:
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {cp}")
        
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {render_py}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
