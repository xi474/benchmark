def transform(payloads, contract):
    """Join names, languages, and subjects into unified catalog records.
    
    Input: [marc_names_titles result, marc_languages result, marc_subjects result]
    Output: {"name": contract["name"], "result": {"records": [...], "record_count": N}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    names_result = payloads[0]
    langs_result = payloads[1]
    subjects_result = payloads[2]
    
    # Extract records from each component result
    def get_records(res):
        if isinstance(res, dict) and "result" in res:
            return res["result"]["records"]
        elif isinstance(res, dict) and "records" in res:
            return res["records"]
        raise ValueError("invalid component result")
    
    names_records = get_records(names_result)
    langs_records = get_records(langs_result)
    subjects_records = get_records(subjects_result)
    
    # Build maps by id
    names_map = {}
    for r in names_records:
        rid = r["id"]
        if rid in names_map:
            raise ValueError(f"duplicate id in names: {rid}")
        names_map[rid] = r
    
    langs_map = {}
    for r in langs_records:
        rid = r["id"]
        if rid in langs_map:
            raise ValueError(f"duplicate id in languages: {rid}")
        langs_map[rid] = r
    
    subjects_map = {}
    for r in subjects_records:
        rid = r["id"]
        if rid in subjects_map:
            raise ValueError(f"duplicate id in subjects: {rid}")
        subjects_map[rid] = r
    
    # Verify all ID sets are identical
    names_ids = set(names_map.keys())
    langs_ids = set(langs_map.keys())
    subjects_ids = set(subjects_map.keys())
    
    if names_ids != langs_ids or names_ids != subjects_ids:
        raise ValueError("record ID sets differ across components")
    
    # Join records sorted by id
    out_records = []
    for rid in sorted(names_ids):
        nr = names_map[rid]
        lr = langs_map[rid]
        sr = subjects_map[rid]
        
        out_records.append({
            "id": rid,
            "authors": nr.get("authors", []),
            "titles": nr.get("titles", []),
            "languages": lr.get("languages", []),
            "subjects": sr.get("subjects", {})
        })
    
    return {
        "name": contract["name"],
        "result": {
            "records": out_records,
            "record_count": len(out_records)
        }
    }
