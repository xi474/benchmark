# Workflow 可观测性报告

- Trial：`MP23__gaUQ5oB__env`
- Task：`MP23`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（66 节点 / 65 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：66；执行边：65（observed=0，inferred=65）
- Execution Trace Graph：`observed`；temporal_next 边 65，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_d143e51d721347a6a3087c4d -> tool:dsh:lead:call_6ceb90e43c7143089a695bb4 -> tool:dsh:lead:call_1e95978407ef409c87d4a644 -> tool:dsh:lead:call_feb609dab4944be5873e9f9d -> tool:dsh:lead:call_c6f424ea09034cfea4f42d6c -> tool:dsh:lead:call_ffd441e9303b4a5ba679c4fb -> tool:dsh:lead:call_8702c7af1e6443a3a4171141 -> tool:dsh:lead:call_b3ecc8e9c6e34e74b5262c45 -> tool:dsh:lead:call_7b7ac518212143cd8aa5e5b5 -> tool:dsh:lead:call_229d537b139b4af38fe65a9d -> tool:dsh:lead:call_11e97a6efa344f8c8dd1e190 -> tool:dsh:lead:call_b5db7c6141dc41e7b38e82fd -> tool:dsh:lead:call_8537b24e6aa4446e9cea6001 -> tool:dsh:lead:call_0cddbe582a8548f8836556e7 -> tool:dsh:lead:call_064e7138f84f45ceb188f08c -> tool:dsh:lead:call_8cf08340ea9244ce8580dc4c -> tool:dsh:lead:call_4d72e31a4e8b4fad8534035f -> tool:dsh:lead:call_6a72f545dcf0406c8239f713 -> tool:dsh:lead:call_58b9f11c8381494c8e46bea8 -> tool:dsh:lead:call_cdc97fa128f14d0187579590 -> tool:dsh:lead:call_edd4daeef1cb48cf995ea0a8 -> tool:dsh:lead:call_2ed8bf4caa5a423a8d34dbdd -> tool:dsh:lead:call_c471edbbd3954c6a8d742cd6 -> tool:dsh:lead:call_6bc530bb560c47f89eede0d2 -> tool:dsh:lead:call_2885ca62065d4ddbbea5645d -> tool:dsh:lead:call_72848387678e49f4a9c42d8b -> tool:dsh:lead:call_e4165bd7f1464bbe8ca6f59c -> tool:dsh:lead:call_d732d129abdb4723af2128f3 -> tool:dsh:lead:call_2a2749b535d74a898243e001 -> tool:dsh:lead:call_2ac95d5b226a4ffd8e36a661 -> tool:dsh:lead:call_18b616faaf354c90887b56d4 -> tool:dsh:lead:call_d1bac2c617b74bc3ad1a12e3 -> tool:dsh:lead:call_178987cadf704d82afcbe855 -> tool:dsh:lead:call_23e81270251e4141915831c0 -> tool:dsh:lead:call_87dc60a473b34d68b2f8c88c -> tool:dsh:lead:call_ca95bb1226f2464abc65ed52 -> tool:dsh:lead:call_7fa88850eb7c4fcabaab25d4 -> tool:dsh:lead:call_25a2bba5be9b4203b4da6a28 -> tool:dsh:lead:call_4248c33def56485ca2b0e55d -> tool:dsh:lead:call_bc358c6eb6f441d3b1ed547a -> tool:dsh:lead:call_8fbbf66efda846ac840d225f -> tool:dsh:lead:call_2f51ab1b3a594e61b0fa56e5 -> tool:dsh:lead:call_297f0656d9674ecca4fead76 -> tool:dsh:lead:call_bacf7554ce30453d9375f13d -> tool:dsh:lead:call_b97a8bd160b042aaa4554cc0 -> tool:dsh:lead:call_5242724ddb1147e29e4de970 -> tool:dsh:lead:call_1290831710464674b97539f7 -> tool:dsh:lead:call_7d04b6c0abe847d99dbbf762 -> tool:dsh:lead:call_1137061d0c9c490bacb217d0 -> tool:dsh:lead:call_1f87c0465b0b4b44a25bd3ff -> tool:dsh:lead:call_38d363dcdc7a4b7eba898e99 -> tool:dsh:lead:call_feaf74a420ad44748cfdc1a3 -> tool:dsh:lead:call_14c5cef3970c406c9cf9c1de -> tool:dsh:lead:call_9639bab2611c44439a34ff99 -> tool:dsh:lead:call_3a90e5fc36be4abbbfbfeba1 -> tool:dsh:lead:call_746628cb6d284a268ae7e57b -> tool:dsh:lead:call_c0d40ca9f2ed44dcad0b8e41 -> tool:dsh:lead:call_fddc6ecc67284e6fbcd3d23f -> tool:dsh:lead:call_8307a6e55f744b8f9f10a563 -> tool:dsh:lead:call_6470553617b34474a913b923 -> tool:dsh:lead:call_b7f1dd272f654d6ca9576058 -> tool:dsh:lead:call_bafa1a52f18d4261868332c0 -> tool:dsh:lead:call_49a07f1cce084c8ab7b48884 -> tool:dsh:lead:call_057056da0b894f61b16847bf -> tool:dsh:lead:call_53e55d0ece7c4a2a838c3000
- 关键路径耗时：2.158
- Makespan：320.614
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
