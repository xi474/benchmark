#!/usr/bin/env python3
"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.is_file():
        raise FileNotFoundError("core_manifest.json not found")

    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    if 'components' not in core:
        raise ValueError("core_manifest missing 'components'")

    components = core['components']
    component_count = len(components)

    # Compute sha256 of the complete core object
    # Serialized with specific formatting: no indent, compact separators, sorted keys
    core_serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256_hex = hashlib.sha256(core_serialized).hexdigest()

    # Determine attention list
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        needs_attention = False

        # result.blocked explicitly true
        if result.get('blocked') is True:
            needs_attention = True

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                needs_attention = True

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0:
                # Non-empty check: lists/dicts/strings that are non-empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    needs_attention = True
                elif isinstance(val, (int, float)) and not isinstance(val, bool) and val != 0:
                    needs_attention = True

        if needs_attention:
            attention.append(name)

    attention.sort()

    report = {
        "title": "受目录容量限制的可逆文件重分片",
        "component_count": component_count,
        "sha256": sha256_hex,
        "attention": attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    out_path.write_text(text, encoding='utf-8')
    print(f"Wrote final_report.json")


if __name__ == '__main__':
    main()
