import hashlib


def _validate_safe_path(path):
    """Validate that path is a safe relative path."""
    if not isinstance(path, str):
        raise ValueError("path must be string")
    if not path or path != path.strip():
        raise ValueError("path must be non-empty and stripped")
    if '\\' in path or ':' in path:
        raise ValueError("unsafe characters in path")
    parts = path.split('/')
    for part in parts:
        if not part or part == '.' or part == '..':
            raise ValueError(f"unsafe path segment in {path}")
    return path


def transform(payloads, contract):
    """reshard_chunks: split files into chunks respecting max_file_bytes."""
    if len(payloads) != 1:
        raise ValueError("chunks expects exactly 1 input")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    # Validate required fields
    for key in ('files', 'max_file_bytes', 'max_entries'):
        if key not in data:
            raise ValueError(f"missing field: {key}")

    files = data['files']
    max_file_bytes = data['max_file_bytes']
    max_entries = data['max_entries']

    if not isinstance(files, list):
        raise ValueError("files must be array")
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    # Validate files entries
    seen_paths = set()
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if 'path' not in f or 'hex' not in f:
            raise ValueError("file entry missing path or hex")
        path = _validate_safe_path(f['path'])
        if path in seen_paths:
            raise ValueError(f"duplicate path: {path}")
        seen_paths.add(path)
        if not isinstance(f['hex'], str):
            raise ValueError("hex must be string")
        # Validate hex
        try:
            bytes.fromhex(f['hex'])
        except ValueError:
            raise ValueError(f"invalid hex for {path}")

    # Sort files by path
    sorted_files = sorted(files, key=lambda f: f['path'])

    # First pass: count total chunks to determine digit width
    total_chunks = 0
    for f in sorted_files:
        raw_bytes = bytes.fromhex(f['hex'])
        size = len(raw_bytes)
        if size > 0:
            total_chunks += (size + max_file_bytes - 1) // max_file_bytes

    # Minimum 6 digits, expand if needed
    import math
    if total_chunks == 0:
        d_width = 6
    else:
        d_width = max(6, len(str(total_chunks - 1)))

    # Second pass: generate chunks
    all_chunks = []
    manifest_files = []
    chunk_counter = 0

    for f in sorted_files:
        raw_bytes = bytes.fromhex(f['hex'])
        path = f['path']
        size = len(raw_bytes)
        sha256 = hashlib.sha256(raw_bytes).hexdigest()

        parts = []
        if size == 0:
            # Empty file has no chunks
            pass
        else:
            offset = 0
            while offset < size:
                end = min(offset + max_file_bytes, size)
                chunk_data = raw_bytes[offset:end]
                chunk_name = f"d{chunk_counter:0{d_width}d}.bin"
                chunk_hex = chunk_data.hex()
                all_chunks.append({"name": chunk_name, "hex": chunk_hex})
                parts.append(chunk_name)
                chunk_counter += 1
                offset = end

        manifest_files.append({
            "path": path,
            "size": size,
            "sha256": sha256,
            "parts": parts
        })

    result = {
        "chunks": all_chunks,
        "manifest": {
            "files": manifest_files
        }
    }

    return {"name": contract["name"], "result": result}
