import json


def transform(payloads, contract):
    """reshard_layout: organize chunks into a directory tree respecting max_entries."""
    if len(payloads) != 2:
        raise ValueError("layout expects exactly 2 inputs")

    original_input = payloads[0]
    chunks_result = payloads[1]

    # Extract parameters from original input
    if not isinstance(original_input, dict):
        raise ValueError("original input must be object")
    for key in ('max_file_bytes', 'max_entries'):
        if key not in original_input:
            raise ValueError(f"missing field: {key}")

    max_file_bytes = original_input['max_file_bytes']
    max_entries = original_input['max_entries']

    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    # Extract chunks result
    if not isinstance(chunks_result, dict):
        raise ValueError("chunks result must be object")
    if 'result' not in chunks_result:
        raise ValueError("chunks result missing 'result'")

    cr = chunks_result['result']
    if not isinstance(cr, dict):
        raise ValueError("chunks result.result must be object")

    data_chunks = cr.get('chunks', [])
    manifest = cr.get('manifest', {})

    if not isinstance(data_chunks, list):
        raise ValueError("chunks must be array")
    if not isinstance(manifest, dict):
        raise ValueError("manifest must be object")

    # Create compact canonical JSON of manifest and split into m-chunks
    manifest_json = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    manifest_bytes = manifest_json.encode('utf-8')

    meta_chunks = []
    if len(manifest_bytes) > 0:
        # Count total m-chunks for width calculation
        total_m = (len(manifest_bytes) + max_file_bytes - 1) // max_file_bytes
        m_width = max(6, len(str(total_m - 1)))

        offset = 0
        m_counter = 0
        while offset < len(manifest_bytes):
            end = min(offset + max_file_bytes, len(manifest_bytes))
            chunk_data = manifest_bytes[offset:end]
            chunk_name = f"m{m_counter:0{m_width}d}.bin"
            meta_chunks.append({"name": chunk_name, "hex": chunk_data.hex()})
            m_counter += 1
            offset = end

    # Combine all items: data chunks + meta chunks, sorted by name
    all_items = []
    for c in data_chunks:
        all_items.append((c['name'], c['hex']))
    for c in meta_chunks:
        all_items.append((c['name'], c['hex']))

    # Sort by name (lexicographic)
    all_items.sort(key=lambda x: x[0])

    N = len(all_items)

    if N == 0:
        return {"name": contract["name"], "result": {"tree": [], "max_entries": max_entries, "max_file_bytes": max_file_bytes}}

    # Find minimum h >= 1 such that max_entries^h >= N
    h = 1
    while max_entries ** h < N:
        h += 1

    # Build tree entries
    tree = []
    for i, (name, hex_data) in enumerate(all_items):
        # Convert index i to h digits in base max_entries
        digits = []
        val = i
        for _ in range(h):
            digits.append(val % max_entries)
            val //= max_entries
        digits.reverse()  # most significant first

        # First h-1 digits are directory names, last digit not in path
        parts = []
        for d in range(h - 1):
            parts.append(f"n{digits[d]}")
        parts.append(name)

        path = '/'.join(parts)
        tree.append({"path": path, "hex": hex_data})

    # Sort by path
    tree.sort(key=lambda x: x['path'])

    result = {
        "tree": tree,
        "max_entries": max_entries,
        "max_file_bytes": max_file_bytes
    }

    return {"name": contract["name"], "result": result}
