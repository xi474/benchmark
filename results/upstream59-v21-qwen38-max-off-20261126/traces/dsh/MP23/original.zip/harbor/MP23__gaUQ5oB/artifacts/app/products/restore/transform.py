import hashlib
import json
import re


def _validate_safe_path(path):
    """Validate that path is a safe relative path."""
    if not isinstance(path, str):
        raise ValueError("path must be string")
    if not path or path != path.strip():
        raise ValueError("path must be non-empty and stripped")
    if '\\' in path or ':' in path:
        raise ValueError("unsafe characters in path")
    parts = path.split('/')
    for part in parts:
        if not part or part == '.' or part == '..':
            raise ValueError(f"unsafe path segment in {path}")
    return path


def transform(payloads, contract):
    """reshard_restore: restore original files from layout tree."""
    if len(payloads) != 1:
        raise ValueError("restore expects exactly 1 input")

    layout_data = payloads[0]
    if not isinstance(layout_data, dict):
        raise ValueError("layout input must be object")
    if 'result' not in layout_data:
        raise ValueError("layout input missing 'result'")

    lr = layout_data['result']
    if not isinstance(lr, dict):
        raise ValueError("layout result must be object")

    for key in ('tree', 'max_entries', 'max_file_bytes'):
        if key not in lr:
            raise ValueError(f"missing field: {key}")

    tree = lr['tree']
    max_entries = lr['max_entries']
    max_file_bytes = lr['max_file_bytes']

    if not isinstance(tree, list):
        raise ValueError("tree must be array")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")

    # Validate each tree entry
    seen_paths = set()
    seen_basenames = set()
    d_chunks = {}  # name -> hex
    m_chunks = {}  # name -> hex (ordered by name)
    m_names_ordered = []

    for entry in tree:
        if not isinstance(entry, dict):
            raise ValueError("tree entry must be object")
        if 'path' not in entry or 'hex' not in entry:
            raise ValueError("tree entry missing path or hex")

        path = _validate_safe_path(entry['path'])
        if path in seen_paths:
            raise ValueError(f"duplicate path: {path}")
        seen_paths.add(path)

        basename = path.split('/')[-1]
        if basename in seen_basenames:
            raise ValueError(f"duplicate basename: {basename}")
        seen_basenames.add(basename)

        # Validate basename format: m<digits>.bin or d<digits>.bin
        if not (re.match(r'^m\d+\.bin$', basename) or re.match(r'^d\d+\.bin$', basename)):
            raise ValueError(f"invalid basename format: {basename}")

        hex_data = entry['hex']
        if not isinstance(hex_data, str):
            raise ValueError("hex must be string")

        # Check file size
        raw = bytes.fromhex(hex_data)
        if len(raw) > max_file_bytes:
            raise ValueError(f"file {path} exceeds max_file_bytes")

        if basename.startswith('d'):
            d_chunks[basename] = hex_data
        else:
            m_chunks[basename] = hex_data
            m_names_ordered.append(basename)

    # Validate directory constraints
    from collections import defaultdict
    dir_children = defaultdict(set)
    for entry in tree:
        parts = entry['path'].split('/')
        parent = '/'.join(parts[:-1])
        dir_children[parent].add(parts[-1])
        for i in range(len(parts) - 1):
            ancestor = '/'.join(parts[:i])
            dir_children[ancestor].add(parts[i])

    for d, children in dir_children.items():
        if len(children) > max_entries:
            raise ValueError(f"directory {repr(d)} has {len(children)} entries > max_entries={max_entries}")

    # Reassemble manifest from m-chunks (sorted by name)
    m_names_ordered.sort()
    manifest_bytes = b''
    for name in m_names_ordered:
        manifest_bytes += bytes.fromhex(m_chunks[name])

    # Parse manifest
    try:
        manifest = json.loads(manifest_bytes.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise ValueError(f"invalid manifest JSON: {e}") from e

    if not isinstance(manifest, dict) or 'files' not in manifest:
        raise ValueError("manifest must have 'files' field")

    manifest_files = manifest['files']
    if not isinstance(manifest_files, list):
        raise ValueError("manifest.files must be array")

    # Track which d-chunks are referenced
    referenced_d = set()
    restored_files = []

    for mf in manifest_files:
        if not isinstance(mf, dict):
            raise ValueError("manifest file entry must be object")
        for key in ('path', 'size', 'sha256', 'parts'):
            if key not in mf:
                raise ValueError(f"manifest file entry missing {key}")

        orig_path = _validate_safe_path(mf['path'])
        expected_size = mf['size']
        expected_sha256 = mf['sha256']
        parts = mf['parts']

        if not isinstance(expected_size, int) or isinstance(expected_size, bool):
            raise ValueError("size must be int")
        if not isinstance(expected_sha256, str):
            raise ValueError("sha256 must be string")
        if not isinstance(parts, list):
            raise ValueError("parts must be array")

        # Reassemble file from d-chunks
        file_bytes = b''
        for part_name in parts:
            if not isinstance(part_name, str):
                raise ValueError("part name must be string")
            if part_name not in d_chunks:
                raise ValueError(f"missing chunk: {part_name}")
            if part_name in referenced_d:
                raise ValueError(f"chunk {part_name} referenced more than once")
            referenced_d.add(part_name)
            file_bytes += bytes.fromhex(d_chunks[part_name])

        # Verify size
        if len(file_bytes) != expected_size:
            raise ValueError(f"size mismatch for {orig_path}: got {len(file_bytes)}, expected {expected_size}")

        # Verify sha256
        actual_sha256 = hashlib.sha256(file_bytes).hexdigest()
        if actual_sha256 != expected_sha256:
            raise ValueError(f"sha256 mismatch for {orig_path}")

        restored_files.append({
            "path": orig_path,
            "hex": file_bytes.hex()
        })

    # Check no unreferenced d-chunks
    unreferenced = set(d_chunks.keys()) - referenced_d
    if unreferenced:
        raise ValueError(f"unreferenced data chunks: {sorted(unreferenced)}")

    # Sort by path
    restored_files.sort(key=lambda f: f['path'])

    total_bytes = sum(len(bytes.fromhex(f['hex'])) for f in restored_files)

    result = {
        "files": restored_files,
        "total_bytes": total_bytes
    }

    return {"name": contract["name"], "result": result}
