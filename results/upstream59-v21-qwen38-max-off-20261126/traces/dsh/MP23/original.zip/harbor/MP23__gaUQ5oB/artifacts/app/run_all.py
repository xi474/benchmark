#!/usr/bin/env python3
"""Run all components in dependency order, then integrate and generate final report."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_component(component_dir):
    """Run a component's render.py script."""
    render_script = ROOT / 'products' / component_dir / 'render.py'
    if not render_script.is_file():
        print(f"ERROR: {render_script} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run(
        [sys.executable, str(render_script)],
        cwd=ROOT,
        timeout=60
    )
    if result.returncode != 0:
        print(f"ERROR: {component_dir} render.py failed with code {result.returncode}", file=sys.stderr)
        sys.exit(1)


def main():
    # Run components in dependency order:
    # 1. chunks (depends on inputs/case.json)
    # 2. layout (depends on inputs/case.json + outputs/chunks.json)
    # 3. restore (depends on outputs/layout.json)
    run_component('chunks')
    run_component('layout')
    run_component('restore')

    # Run integrator
    integrate_script = ROOT / 'integrate.py'
    result = subprocess.run(
        [sys.executable, str(integrate_script)],
        cwd=ROOT,
        timeout=60
    )
    if result.returncode != 0:
        print("ERROR: integrate.py failed", file=sys.stderr)
        sys.exit(1)

    # Run final report
    report_script = ROOT / 'final_report.py'
    result = subprocess.run(
        [sys.executable, str(report_script)],
        cwd=ROOT,
        timeout=60
    )
    if result.returncode != 0:
        print("ERROR: final_report.py failed", file=sys.stderr)
        sys.exit(1)

    print("ALL_COMPONENTS_COMPLETE")


if __name__ == '__main__':
    main()
