# Workflow 可观测性报告

- Trial：`MP24__yTomUpb__env`
- Task：`MP24`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（46 节点 / 45 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：46；执行边：45（observed=0，inferred=45）
- Execution Trace Graph：`observed`；temporal_next 边 45，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_663b675daf7540b1848238f2 -> tool:dsh:lead:call_720d61225e634efeb2d2dc07 -> tool:dsh:lead:call_9b64f32ae9d04ee682a61ee9 -> tool:dsh:lead:call_7be23b234475445e974272bc -> tool:dsh:lead:call_59855479eadd4d9886098a99 -> tool:dsh:lead:call_81b803264e834ac4ac942c58 -> tool:dsh:lead:call_b8589dd86c4543b99dd6c8c6 -> tool:dsh:lead:call_05ab0a1b191d48e7a4231ca1 -> tool:dsh:lead:call_771e21258342495ab7552650 -> tool:dsh:lead:call_6f9eba517b7e4701a3884cb1 -> tool:dsh:lead:call_f3dfd500184a48b988f7b35c -> tool:dsh:lead:call_7fe711e28ad44027894323dc -> tool:dsh:lead:call_e3e690c425be4408bc6ac6f7 -> tool:dsh:lead:call_9b9276542ea74cb7a2abb881 -> tool:dsh:lead:call_10585d461b9e4c3dadd16801 -> tool:dsh:lead:call_e6cf956a857c46ef97f404fe -> tool:dsh:lead:call_f5f72f9286874e0896f5897d -> tool:dsh:lead:call_e1fd8354bc564e65806009d5 -> tool:dsh:lead:call_048b57af81e24d4a949773b2 -> tool:dsh:lead:call_9e28005c0ad34914947bb03c -> tool:dsh:lead:call_9734d5d6a9a043f9a7d54883 -> tool:dsh:lead:call_b7d110ee6e7d44f3950bc13c -> tool:dsh:lead:call_0c04cb65d35e418193a07cfe -> tool:dsh:lead:call_8f3deb8c90924ae3b4565a15 -> tool:dsh:lead:call_f1ab8fe40a4d4edb8092d605 -> tool:dsh:lead:call_4d3a7293821d4ea59327f74f -> tool:dsh:lead:call_1ed7520184e64d16b7c0195b -> tool:dsh:lead:call_d8b188ecc7d245d78d7721af -> tool:dsh:lead:call_61d8c7b1653a48f48eeaa732 -> tool:dsh:lead:call_7796caed94c74a2e970dcdeb -> tool:dsh:lead:call_029a34b3905742a1be1b7a65 -> tool:dsh:lead:call_a52076720d644b74b911b10f -> tool:dsh:lead:call_8ae8dc49d2da408ba9e48609 -> tool:dsh:lead:call_852f3bae2c8b47ef9404cdf5 -> tool:dsh:lead:call_97d4428f33bb4ecbb23c4252 -> tool:dsh:lead:call_f3a59d785ce5489fb19e1eb8 -> tool:dsh:lead:call_3cb704159e7c4db28ca51e9b -> tool:dsh:lead:call_4c095d695dcd47ea8a810172 -> tool:dsh:lead:call_8fee97372e78497f90efee9d -> tool:dsh:lead:call_0d09da032367458d9d9b3a03 -> tool:dsh:lead:call_b7f0187a29c64b7e87af7f76 -> tool:dsh:lead:call_3ffdef2b08ad4069ac31186d -> tool:dsh:lead:call_3b628fa6d72b488e8b67b19f -> tool:dsh:lead:call_4296ea069db649e59bcea85f -> tool:dsh:lead:call_21cc4f49bce74d9e9a87a3ee
- 关键路径耗时：1.22
- Makespan：168.974
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
