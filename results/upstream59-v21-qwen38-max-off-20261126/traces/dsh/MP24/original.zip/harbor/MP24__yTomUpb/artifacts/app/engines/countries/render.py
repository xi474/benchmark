import json
import sys
from pathlib import Path

# Add engine directory to path for imports
_engine_dir = Path(__file__).resolve().parent
if str(_engine_dir) not in sys.path:
    sys.path.insert(0, str(_engine_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs, run transform, write output, return result envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )

    return result


if __name__ == "__main__":
    # When run as script, determine root and contract path
    # Contract is in the same directory as this script
    script_dir = Path(__file__).resolve().parent
    contract_path = script_dir / "contract.json"
    # Root is the workspace root (parent of engines/)
    root = script_dir.parents[1]
    build_component(root, contract_path)
