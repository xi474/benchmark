def transform(payloads, contract):
    """employment_countries: return all employment countries per professor."""
    case = payloads[0]

    departments = case["departments"]
    professors = case["professors"]

    # Build department -> country mapping
    dept_country = {}
    for d in departments:
        dept_country[d["id"]] = d["country"]

    countries_map = {}
    for prof in professors:
        prof_countries = set()
        for dept_id in prof["departments"]:
            country = dept_country.get(dept_id)
            if country is not None:
                prof_countries.add(country)
        countries_map[prof["id"]] = sorted(prof_countries)

    return {
        "name": contract["name"],
        "result": {"countries": countries_map}
    }
