def transform(payloads, contract):
    """eu_professors: filter professors who have at least one department in EU countries."""
    case = payloads[0]

    departments = case["departments"]
    professors = case["professors"]
    eu_countries = set(case["eu"])

    # Build department -> country mapping
    dept_country = {}
    for d in departments:
        dept_country[d["id"]] = d["country"]

    # Filter professors: at least one department's country is in EU
    eligible_ids = []
    for prof in professors:
        prof_depts = set(prof["departments"])  # deduplicate
        for dept_id in prof_depts:
            if dept_country.get(dept_id) in eu_countries:
                eligible_ids.append(prof["id"])
                break

    eligible_ids.sort()

    return {
        "name": contract["name"],
        "result": {"ids": eligible_ids}
    }
