def transform(payloads, contract):
    """university_query: EU-eligible professors with at least one department having >10 students."""
    case = payloads[0]          # original input
    eu_result = payloads[1]     # eu_professors result
    students_result = payloads[2]  # department_students result
    countries_result = payloads[3] # employment_countries result

    # Extract data from upstream results
    # eu_result has {"name": ..., "result": {"ids": [...]}}
    # But payloads are loaded from output files which have {name, result} wrapper
    # The check_module loads them via load_payload, so they come as dicts with name/result
    
    eu_ids = set(eu_result["result"]["ids"])
    dept_counts = students_result["result"]["counts"]
    prof_countries = countries_result["result"]["countries"]

    departments = case["departments"]
    professors = case["professors"]

    # Build department -> country mapping
    dept_country = {}
    for d in departments:
        dept_country[d["id"]] = d["country"]

    result_professors = []
    for prof in professors:
        pid = prof["id"]
        if pid not in eu_ids:
            continue

        # Check if at least one individual department has >10 students
        eligible_depts = []
        for dept_id in set(prof["departments"]):
            count = dept_counts.get(dept_id, 0)
            if count > 10:
                eligible_depts.append(dept_id)

        if eligible_depts:
            eligible_depts.sort()
            all_countries = prof_countries.get(pid, [])
            result_professors.append({
                "id": pid,
                "countries": all_countries,
                "eligible_departments": eligible_depts
            })

    result_professors.sort(key=lambda x: x["id"])

    return {
        "name": contract["name"],
        "result": {"professors": result_professors}
    }
