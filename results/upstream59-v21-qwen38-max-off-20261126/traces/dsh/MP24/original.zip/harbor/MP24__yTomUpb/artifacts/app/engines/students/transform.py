def transform(payloads, contract):
    """department_students: count active students per department as of as_of date."""
    case = payloads[0]

    departments = case["departments"]
    students = case["students"]
    as_of = case["as_of"]

    # Collect all department IDs
    all_dept_ids = set()
    for d in departments:
        all_dept_ids.add(d["id"])

    # Count active students per department
    # Active: start <= as_of AND (end is null OR as_of < end)
    # Per department, use student.id as DISTINCT key
    dept_students = {}  # dept_id -> set of student ids
    for dept_id in all_dept_ids:
        dept_students[dept_id] = set()

    for student in students:
        sid = student["id"]
        seen_depts = {}  # track which departments this student has been counted for
        for enrolment in student["enrolments"]:
            dept_id = enrolment["department"]
            start = enrolment["start"]
            end = enrolment["end"]

            # Validate: end non-null must be > start
            if end is not None and end <= start:
                raise ValueError(f"end must be > start for student {sid}")

            # Check active: start <= as_of AND (end is null OR as_of < end)
            if start <= as_of and (end is None or as_of < end):
                if dept_id not in dept_students:
                    dept_students[dept_id] = set()
                dept_students[dept_id].add(sid)

    counts = {}
    for dept_id in sorted(dept_students.keys()):
        counts[dept_id] = len(dept_students[dept_id])

    return {
        "name": contract["name"],
        "result": {"counts": counts}
    }
