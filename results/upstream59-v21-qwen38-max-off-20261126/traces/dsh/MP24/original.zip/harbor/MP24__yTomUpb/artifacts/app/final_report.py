"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core["components"]

    # Compute sha256 of the complete core object
    # Serialized with specific settings, no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(serialized).hexdigest()

    # Determine attention list
    attention = set()
    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue
        # blocked explicitly true
        if comp_result.get("blocked") is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in comp_result and comp_result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = comp_result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0:
                # Non-empty check: lists/dicts/strings that are non-empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)

    report = {
        "title": "大学任职、在读人数与国家集合查询",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": sorted(attention)
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )


if __name__ == "__main__":
    main()
