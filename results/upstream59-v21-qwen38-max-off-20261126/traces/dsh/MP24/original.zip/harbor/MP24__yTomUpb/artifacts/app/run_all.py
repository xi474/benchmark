"""Orchestrate all component builds based on contract dependencies."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs
    # Each contract's output may be another contract's input
    contract_by_output = {}
    contract_info = []
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_info.append((cp, c))
        out_rel = c["output"]
        contract_by_output[out_rel] = cp

    # Topological sort based on input dependencies
    # A contract depends on another if any of its inputs is an output of another contract
    deps = {}  # cp -> set of cp it depends on
    for cp, c in contract_info:
        deps[cp] = set()
        for inp in c["inputs"]:
            if inp in contract_by_output:
                dep_cp = contract_by_output[inp]
                if dep_cp != cp:
                    deps[cp].add(dep_cp)

    # Kahn's algorithm for topological sort
    in_degree = {cp: 0 for cp, _ in contract_info}
    for cp in deps:
        for dep in deps[cp]:
            in_degree[cp] += 1  # This is wrong; fix below

    # Recompute properly
    in_degree = {cp: 0 for cp, _ in contract_info}
    reverse_deps = {cp: set() for cp, _ in contract_info}
    for cp in deps:
        for dep in deps[cp]:
            reverse_deps[dep].add(cp)
            in_degree[cp] += 1

    queue = [cp for cp, deg in in_degree.items() if deg == 0]
    order = []
    while queue:
        queue.sort(key=lambda p: str(p))  # deterministic
        node = queue.pop(0)
        order.append(node)
        for dependent in reverse_deps[node]:
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    if len(order) != len(contract_info):
        print("Circular dependency detected", file=sys.stderr)
        sys.exit(1)

    # Execute each component in order via subprocess
    for cp in order:
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            timeout=30
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            timeout=30
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
