# Workflow 可观测性报告

- Trial：`MP25__9nsia4L__env`
- Task：`MP25`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（47 节点 / 46 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：47；执行边：46（observed=0，inferred=46）
- Execution Trace Graph：`observed`；temporal_next 边 46，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_733816296c834a4fa450da9a -> tool:dsh:lead:call_1f91c254cd054580a658fdbd -> tool:dsh:lead:call_7c26a7572c314866bf86f12b -> tool:dsh:lead:call_bfc3133c5c224acbb26c0f58 -> tool:dsh:lead:call_dc41120197784996833f16f4 -> tool:dsh:lead:call_8b607a33e7714d2ca24bfba8 -> tool:dsh:lead:call_56c2ed1310e74ad4998bf4d2 -> tool:dsh:lead:call_7f2d74f1b8af4d8789621fe1 -> tool:dsh:lead:call_aadcede57f764a0ea64199ed -> tool:dsh:lead:call_a9840d64cd214f0aae807086 -> tool:dsh:lead:call_5f0a18409cda4d92adb256e0 -> tool:dsh:lead:call_efebbe1193b941c3bc15f971 -> tool:dsh:lead:call_a11be86df41f4889a2379021 -> tool:dsh:lead:call_2c440b99a1e0495696c4619c -> tool:dsh:lead:call_94f79621fe1442f495881cda -> tool:dsh:lead:call_761917890dc8491992583550 -> tool:dsh:lead:call_6cbe256a5d1b4555a80477fa -> tool:dsh:lead:call_a43dd6587f414c3fa622641e -> tool:dsh:lead:call_67a82593f117444ea64adbf8 -> tool:dsh:lead:call_0f36a0153ccd4b4aa5737a63 -> tool:dsh:lead:call_d3fa7dd53fec4855bea6e876 -> tool:dsh:lead:call_e8de42eca881490fa36b0d6c -> tool:dsh:lead:call_e3c049a7ece04b9eae846e87 -> tool:dsh:lead:call_2adcd0de3f274e22877da769 -> tool:dsh:lead:call_b00002d62fad49ff99366cd1 -> tool:dsh:lead:call_4d7ea5b001584ca081565909 -> tool:dsh:lead:call_78501831e529421682bcfbb3 -> tool:dsh:lead:call_fe83e9922cbf40118bc1f036 -> tool:dsh:lead:call_e1929328aa5e49539c2c5acf -> tool:dsh:lead:call_245c931abac64dc884d6daf9 -> tool:dsh:lead:call_94c6298360a34c1cbad037a3 -> tool:dsh:lead:call_eb882ae5d52642cebb7443b8 -> tool:dsh:lead:call_f743680ea0f74a8aa3aed34b -> tool:dsh:lead:call_b4d058e475e044f8bbf110f0 -> tool:dsh:lead:call_9bbea11a39aa466196b8452d -> tool:dsh:lead:call_5dd8f7cf394b4b088d0a5816 -> tool:dsh:lead:call_89a9b1f2622d4dacaa5a5c95 -> tool:dsh:lead:call_1da1bab881c7441ab0f5f647 -> tool:dsh:lead:call_35cfb3f4ce0647e4bd5270b1 -> tool:dsh:lead:call_2a60432558db44b38e9ff033 -> tool:dsh:lead:call_fe13460dbc3841a691778f03 -> tool:dsh:lead:call_214376c84f484d4dad016950 -> tool:dsh:lead:call_d3ed5f9a4d434a6cbd79346c -> tool:dsh:lead:call_9eff3e652af146529a33bd81 -> tool:dsh:lead:call_dd2f348a8f15493a911c389f -> tool:dsh:lead:call_6a73ba756ff341d7ad2262ec
- 关键路径耗时：1.129
- Makespan：175.646
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
