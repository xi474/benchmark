import re


def _parse_amount(s):
    """Parse a monetary amount string. Returns string with exactly 2 decimals or raises ValueError.

    Accepts optional 'USD' prefix, optional thousands separators (commas), must have exactly 2 decimal places.
    Non-negative only.
    """
    s = s.strip()
    # Remove optional USD prefix
    if s.upper().startswith("USD"):
        s = s[3:].strip()

    # Validate format: digits with optional commas as thousands separators, exactly 2 decimal places
    # Pattern: optional comma-separated groups, then .XX
    m = re.match(r'^(\d{1,3}(?:,\d{3})*|\d+)(\.\d{2})$', s)
    if not m:
        raise ValueError(f"invalid amount format: {s}")

    integer_part = m.group(1).replace(",", "")
    decimal_part = m.group(2)  # includes the dot

    # Reconstruct clean number string
    result = integer_part + decimal_part
    return result


def transform(payloads, contract):
    """Extract invoice amounts from document text.

    Input: {documents: [{id, filename, text}]}
    Parse lines matching "Total: <amount>", "Amount Due: <amount>", "VAT: <amount>"
    Total takes priority over Amount Due. If neither present, total=null.
    VAT defaults to "0.00" if not present.
    Duplicate labels in same document -> ValueError.
    Invalid amount format -> ValueError.

    Returns: {"name": contract["name"], "result": {"amounts": {id: {total, vat}}}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]

    # Handle the name/result wrapper
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        data = payload["result"]
    else:
        data = payload

    if not isinstance(data, dict) or "documents" not in data:
        raise ValueError("missing 'documents' field")

    documents = data["documents"]
    if not isinstance(documents, list):
        raise ValueError("'documents' must be a list")

    # Patterns for label matching (case-insensitive, whole line after strip)
    total_re = re.compile(r'^total:\s*(.+)$', re.IGNORECASE)
    amount_due_re = re.compile(r'^amount\s+due:\s*(.+)$', re.IGNORECASE)
    vat_re = re.compile(r'^vat:\s*(.+)$', re.IGNORECASE)

    amounts = {}
    seen_ids = set()

    for doc in documents:
        if not isinstance(doc, dict):
            raise ValueError("document must be object")
        for field in ("id", "filename", "text"):
            if field not in doc:
                raise ValueError(f"missing field '{field}' in document")
        did = doc["id"]
        if not isinstance(did, str):
            raise ValueError("id must be string")
        if did in seen_ids:
            raise ValueError(f"duplicate id: {did}")
        seen_ids.add(did)
        if not isinstance(doc["text"], str):
            raise ValueError("text must be string")

        text = doc["text"]
        found_total = None
        found_amount_due = None
        found_vat = None

        for line in text.split("\n"):
            stripped = line.strip()

            tm = total_re.match(stripped)
            if tm:
                if found_total is not None:
                    raise ValueError(f"duplicate Total in document {did}")
                found_total = _parse_amount(tm.group(1))

            am = amount_due_re.match(stripped)
            if am:
                if found_amount_due is not None:
                    raise ValueError(f"duplicate Amount Due in document {did}")
                found_amount_due = _parse_amount(am.group(1))

            vm = vat_re.match(stripped)
            if vm:
                if found_vat is not None:
                    raise ValueError(f"duplicate VAT in document {did}")
                found_vat = _parse_amount(vm.group(1))

        # Total priority over Amount Due
        if found_total is not None:
            total_val = found_total
        elif found_amount_due is not None:
            total_val = found_amount_due
        else:
            total_val = None

        vat_val = found_vat if found_vat is not None else "0.00"

        amounts[did] = {"total": total_val, "vat": vat_val}

    return {"name": contract["name"], "result": {"amounts": amounts}}
