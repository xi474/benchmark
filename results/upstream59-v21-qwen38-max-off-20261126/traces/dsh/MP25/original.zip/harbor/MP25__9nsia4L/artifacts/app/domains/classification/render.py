import json
import sys
from pathlib import Path

# Add component dir to path for local imports
_COMPONENT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_COMPONENT_DIR))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Load inputs from root using contract, run transform, return result envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    return result


if __name__ == "__main__":
    # Determine workspace root: parent of domains/classification
    here = Path(__file__).resolve()
    root = here.parents[2]  # /app
    contract_path = here.parent / "contract.json"
    build_component(root, contract_path)
