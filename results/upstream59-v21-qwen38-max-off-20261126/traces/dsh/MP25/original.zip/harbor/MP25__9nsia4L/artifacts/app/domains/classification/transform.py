import re


def transform(payloads, contract):
    """Classify documents by text content.

    Input: {documents: [{id, filename, text}]}
    Rules: case-insensitive whole-word match on text lines.
      - If word 'invoice' appears -> 'invoice'
      - Else if word 'receipt' appears -> 'receipt'
      - Else -> 'other'
    Returns: {"name": contract["name"], "result": {"classes": {id: category}}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]

    # Handle the name/result wrapper: if payload has exactly keys name/result, unwrap
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        data = payload["result"]
    else:
        data = payload

    if not isinstance(data, dict) or "documents" not in data:
        raise ValueError("missing 'documents' field")

    documents = data["documents"]
    if not isinstance(documents, list):
        raise ValueError("'documents' must be a list")

    # Validate unique IDs
    seen_ids = set()
    for doc in documents:
        if not isinstance(doc, dict):
            raise ValueError("document must be object")
        for field in ("id", "filename", "text"):
            if field not in doc:
                raise ValueError(f"missing field '{field}' in document")
        did = doc["id"]
        if not isinstance(did, str):
            raise ValueError("id must be string")
        if did in seen_ids:
            raise ValueError(f"duplicate id: {did}")
        seen_ids.add(did)
        if not isinstance(doc["filename"], str):
            raise ValueError("filename must be string")
        if not isinstance(doc["text"], str):
            raise ValueError("text must be string")

    classes = {}
    invoice_re = re.compile(r'\binvoice\b', re.IGNORECASE)
    receipt_re = re.compile(r'\breceipt\b', re.IGNORECASE)

    for doc in documents:
        text = doc["text"]
        if invoice_re.search(text):
            classes[doc["id"]] = "invoice"
        elif receipt_re.search(text):
            classes[doc["id"]] = "receipt"
        else:
            classes[doc["id"]] = "other"

    return {"name": contract["name"], "result": {"classes": classes}}
