"""Generate the final report from core_manifest.json.

Reads outputs/core_manifest.json, computes SHA256 of the canonical JSON serialization,
and writes outputs/final_report.json.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    if not core_path.is_file():
        raise FileNotFoundError(f"Missing {core_path}")

    # Read raw text and parse to get the core object
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # Compute SHA256 of canonical serialization (no trailing newline)
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    components = core.get("components", {})
    attention = set()

    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue

        # Check blocked explicitly true
        if comp_result.get("blocked") is True:
            attention.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            val = comp_result.get(key)
            if val is False:
                attention.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = comp_result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0 and val is not False:
                # Non-empty means truthy for lists/dicts/strings; but spec says "non-empty"
                # For lists: non-empty list; for dicts: non-empty dict; for strings: non-empty string
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        "title": "文本票据分类、金额提取与归档汇总",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": attention_list,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
