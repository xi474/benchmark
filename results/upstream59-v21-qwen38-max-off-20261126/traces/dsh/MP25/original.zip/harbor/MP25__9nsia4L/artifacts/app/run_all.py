"""Orchestrate all components based on their contract.json files.

Discovers all contract.json files (excluding outputs/), resolves dependencies
by topological order, and runs each component's render.py as a subprocess.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    """Load a contract JSON file."""
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_order(contracts):
    """Topologically sort contracts by their input dependencies.

    A contract that depends on another contract's output must run after it.
    """
    # Map output paths to contract paths
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        c = load_contract(cp)
        contract_info[cp] = c
        output_to_contract[c["output"]] = cp

    # Build dependency graph
    deps = {}  # cp -> set of cp it depends on
    for cp in contracts:
        c = contract_info[cp]
        dep_set = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep_set.add(output_to_contract[inp])
        deps[cp] = dep_set

    # Topological sort (Kahn's algorithm)
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    result = []

    while queue:
        queue.sort()  # deterministic ordering
        cp = queue.pop(0)
        result.append(cp)
        for other in contracts:
            if cp in deps[other]:
                deps[other].discard(cp)
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)

    if len(result) != len(contracts):
        raise ValueError("circular dependency detected among contracts")

    return result


def main():
    contracts = discover_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    ordered = resolve_order(contracts)

    for cp in ordered:
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)

        proc = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            timeout=60,
        )
        if proc.returncode != 0:
            print(f"Component {cp} failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        proc = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            timeout=30,
        )
        if proc.returncode != 0:
            print(f"integrate.py failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)

    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.is_file():
        proc = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=str(ROOT),
            timeout=30,
        )
        if proc.returncode != 0:
            print(f"final_report.py failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)


if __name__ == "__main__":
    main()
