import csv
import io


def _is_safe_path_segment(s):
    """Check if string is a safe single path segment."""
    if not s or not isinstance(s, str):
        return False
    # No absolute paths, backslashes, colons, empty segments, . or ..
    if "\\" in s or ":" in s:
        return False
    if s in (".", ".."):
        return False
    if "/" in s:
        return False
    return True


def transform(payloads, contract):
    """Build archive summary from documents, classification, and amounts.

    Inputs (in order): documents payload, classification result, amounts result.
    Each input may be wrapped in {name, result} - extract result for business data.

    Returns: {"name": contract["name"], "result": {archives, rows, csv, totals}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    def unwrap(p):
        if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
            return p["result"]
        return p

    docs_data = unwrap(payloads[0])
    class_data = unwrap(payloads[1])
    amounts_data = unwrap(payloads[2])

    # Extract documents list
    if isinstance(docs_data, dict) and "documents" in docs_data:
        documents = docs_data["documents"]
    else:
        raise ValueError("missing 'documents' field")

    classes = class_data.get("classes", {})
    amounts = amounts_data.get("amounts", {})

    archives = []
    rows = []

    for doc in documents:
        did = doc["id"]
        filename = doc["filename"]
        text = doc["text"]

        kind = classes.get(did, "other")
        amt_info = amounts.get(did, {})
        total = amt_info.get("total")
        vat = amt_info.get("vat", "0.00")

        # Validate: invoice/receipt must have total
        if kind in ("invoice", "receipt") and total is None:
            raise ValueError(f"document {did} classified as {kind} but has no total")

        # id must be safe single path segment
        if not _is_safe_path_segment(did):
            raise ValueError(f"id '{did}' is not a safe path segment")

        # Archive path: classified/<kind>/<id>/<original_filename>
        archive_path = f"classified/{kind}/{did}/{filename}"

        # Hex of text UTF-8 bytes
        text_hex = text.encode("utf-8").hex()

        archives.append({"path": archive_path, "hex": text_hex})

        rows.append({
            "id": did,
            "filename": filename,
            "kind": kind,
            "total": total,
            "vat": vat,
        })

    # Sort archives by path
    archives.sort(key=lambda x: x["path"])

    # Sort rows by id
    rows.sort(key=lambda x: x["id"])

    # Generate CSV
    csv_buf = io.StringIO()
    writer = csv.writer(csv_buf, lineterminator="\n")
    writer.writerow(["id", "filename", "kind", "total", "vat"])
    for row in rows:
        writer.writerow([
            row["id"],
            row["filename"],
            row["kind"],
            row["total"] if row["total"] is not None else "",
            row["vat"],
        ])
    csv_str = csv_buf.getvalue()

    # Compute totals: sum of total for invoice category and receipt category separately
    invoice_total = 0
    receipt_total = 0
    for row in rows:
        if row["total"] is not None:
            # Parse the string amount to Decimal-like integer cents for precision
            t_str = row["total"]
            # Convert to cents to avoid float issues
            parts = t_str.split(".")
            integer_part = int(parts[0])
            decimal_part = int(parts[1])
            cents = integer_part * 100 + decimal_part
            if row["kind"] == "invoice":
                invoice_total += cents
            elif row["kind"] == "receipt":
                receipt_total += cents

    def cents_to_str(cents):
        sign = ""
        if cents < 0:
            sign = "-"
            cents = -cents
        dollars = cents // 100
        remainder = cents % 100
        return f"{sign}{dollars}.{remainder:02d}"

    totals = {
        "invoice": cents_to_str(invoice_total),
        "receipt": cents_to_str(receipt_total),
    }

    result = {
        "archives": archives,
        "rows": rows,
        "csv": csv_str,
        "totals": totals,
    }

    return {"name": contract["name"], "result": result}
