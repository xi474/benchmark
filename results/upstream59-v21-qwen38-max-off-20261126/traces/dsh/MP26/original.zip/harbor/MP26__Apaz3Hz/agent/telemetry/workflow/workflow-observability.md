# Workflow 可观测性报告

- Trial：`MP26__Apaz3Hz__env`
- Task：`MP26`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（67 节点 / 66 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：67；执行边：66（observed=0，inferred=66）
- Execution Trace Graph：`observed`；temporal_next 边 66，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_c8585101a4d644e1badbc54b -> tool:dsh:lead:call_7bf72eae9b0242038156eaca -> tool:dsh:lead:call_8cbc2a5dc3eb48df901f89f9 -> tool:dsh:lead:call_d7ea8cb910584cf09b5446cc -> tool:dsh:lead:call_58c0603a4288442f82351a27 -> tool:dsh:lead:call_a2cae8572f2c4ad68907f679 -> tool:dsh:lead:call_5b8a47301aeb441d84bd055b -> tool:dsh:lead:call_164d102e5df04fcbb69ce7da -> tool:dsh:lead:call_e3cabe60d85843e59754786e -> tool:dsh:lead:call_b6721f039d1942afa84372c0 -> tool:dsh:lead:call_a62a112b55e74e9b814966ec -> tool:dsh:lead:call_5d1d84f5f8b24cde94aeebc7 -> tool:dsh:lead:call_751a5d27d67f4179a5f2d409 -> tool:dsh:lead:call_8d3cda69dc67445fa7f93ccf -> tool:dsh:lead:call_d1ef977fa91f4e74a114f8c7 -> tool:dsh:lead:call_c535bce034874975b9f7cda6 -> tool:dsh:lead:call_7929634540374303a8373dfd -> tool:dsh:lead:call_adc6b26f962f4199a2e8b8e4 -> tool:dsh:lead:call_9173ca5d9ef54cd08950b8b1 -> tool:dsh:lead:call_612809b35a804a488adfe82f -> tool:dsh:lead:call_5ab837475faf4e9baa4a1e24 -> tool:dsh:lead:call_0fc9e13f1fd94b98a5d308be -> tool:dsh:lead:call_1a34f264b3ef43eb8afb8783 -> tool:dsh:lead:call_383427cd1b024eb2b21de206 -> tool:dsh:lead:call_9fd2308d11434b64b3e3d76d -> tool:dsh:lead:call_445f4f06362443d98a7c0c7f -> tool:dsh:lead:call_71658a8f5a9c497589fedd5e -> tool:dsh:lead:call_9705d64cd1bb46aeace0349c -> tool:dsh:lead:call_10c4173dc5934a688763af54 -> tool:dsh:lead:call_42b6a07f52ee4afd83ef0fac -> tool:dsh:lead:call_4f2edee538bf46d59647fd0b -> tool:dsh:lead:call_b39c173b1e1d47b1aee95d3a -> tool:dsh:lead:call_8af3a0bcfcb143a8865517d2 -> tool:dsh:lead:call_02267eb777d8401b9740db1c -> tool:dsh:lead:call_a6f3ea2e70374ff18ff00cfc -> tool:dsh:lead:call_9c019aa369294b149ea1070e -> tool:dsh:lead:call_e771b6129045464eabfd7342 -> tool:dsh:lead:call_5321430d13a94373a0eceb51 -> tool:dsh:lead:call_442fa0f042b4413bb387daaf -> tool:dsh:lead:call_4837facf9ad140acb159119a -> tool:dsh:lead:call_c57bdb966ce74b4ea96be7cc -> tool:dsh:lead:call_163e7b12903e4dca983df53b -> tool:dsh:lead:call_dfe5e21006dd40e6b49a72c8 -> tool:dsh:lead:call_db67c45f04cb45d79776aa8e -> tool:dsh:lead:call_f1d0b6b6dc61442aaf5cbf18 -> tool:dsh:lead:call_c3e0f03d6a2742958f33e90d -> tool:dsh:lead:call_7104c385859741268380241b -> tool:dsh:lead:call_a1f4983d90894dad819bfdfb -> tool:dsh:lead:call_c10185d3f9b143f0bf624bb8 -> tool:dsh:lead:call_6bf6a9a379024cb99d363c1f -> tool:dsh:lead:call_76f4de911f474f02a660904c -> tool:dsh:lead:call_e1f84a14fe924741b6d30209 -> tool:dsh:lead:call_59a53735287b4ab48e1e3982 -> tool:dsh:lead:call_5b09918b62bd4bc3ace61710 -> tool:dsh:lead:call_646823bb8dc0444bae75779f -> tool:dsh:lead:call_302fa27ddb8941dc971a8c2c -> tool:dsh:lead:call_114f041b2fe646e58e785486 -> tool:dsh:lead:call_6e6a2c2e6d424e5bbd05f989 -> tool:dsh:lead:call_dce4c4a2f61e47d695e58acb -> tool:dsh:lead:call_b97242d824b844ec86b18bb3 -> tool:dsh:lead:call_c2f3bdb5e1af4fde9f0ce3ae -> tool:dsh:lead:call_6250dbeea9194868b3c6cf82 -> tool:dsh:lead:call_ef1420f2ee4f4250b4a0f260 -> tool:dsh:lead:call_fbc384d6aa0b41b093b62c74 -> tool:dsh:lead:call_7e516e92ac0f48848750ec1a -> tool:dsh:lead:call_c0665be1fbdb460889fe2ba8
- 关键路径耗时：1.557
- Makespan：254.778
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
