import json
import sys
from pathlib import Path

# Add component dir to path so we can import sibling modules
_component_dir = Path(__file__).resolve().parent
if str(_component_dir) not in sys.path:
    sys.path.insert(0, str(_component_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs per contract, call transform, write output, return envelope."""
    root = Path(root).resolve()
    contract_path = Path(contract_path).resolve()
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

    return result


if __name__ == "__main__":
    # CLI: determine root and contract path relative to this script
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parents[1]  # workspace root
    contract_path = script_dir / 'contract.json'
    build_component(root, contract_path)
