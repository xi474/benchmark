def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    calendar_result = _unwrap(payloads[0])
    plan_result = _unwrap(payloads[1])
    notifications_result = _unwrap(payloads[2])

    old_events = calendar_result['events']
    cancelled_ids = set(plan_result['cancelled'])
    added = plan_result['added']
    outbox = notifications_result['outbox']

    # Remove cancelled events from old events
    remaining = [ev for ev in old_events if ev['id'] not in cancelled_ids]

    # Add new dinner events
    final_events = remaining + list(added)

    # Sort by id
    final_events.sort(key=lambda e: e['id'])

    return {
        "name": contract["name"],
        "result": {
            "events": final_events,
            "outbox": outbox
        }
    }
