from datetime import datetime


def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def _parse_dt(s):
    """Parse YYYY-MM-DDTHH:MM string to datetime."""
    if not isinstance(s, str):
        raise ValueError(f"datetime must be string, got {type(s).__name__}")
    try:
        return datetime.fromisoformat(s)
    except (ValueError, TypeError) as e:
        raise ValueError(f"invalid datetime: {s}") from e


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = _unwrap(payloads[0])

    if not isinstance(case, dict):
        raise ValueError("case must be an object")
    for key in ('today', 'events', 'contacts'):
        if key not in case:
            raise ValueError(f"missing required field: {key}")

    events = case['events']
    contacts = case['contacts']

    if not isinstance(events, list):
        raise ValueError("events must be an array")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be an array")

    contacts_set = set()
    for c in contacts:
        if not isinstance(c, str):
            raise ValueError("contact id must be string")
        if c in contacts_set:
            raise ValueError(f"duplicate contact: {c}")
        contacts_set.add(c)

    # Validate and process events
    seen_ids = set()
    processed_events = []
    existing_dinner_dates = set()

    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be an object")
        for key in ('id', 'start', 'end', 'kind', 'attendees'):
            if key not in ev:
                raise ValueError(f"event missing required field: {key}")

        eid = ev['id']
        if not isinstance(eid, str) or not eid.strip():
            raise ValueError("event id must be non-empty string")
        if eid in seen_ids:
            raise ValueError(f"duplicate event id: {eid}")
        seen_ids.add(eid)

        kind = ev['kind']
        if not isinstance(kind, str) or not kind.strip():
            raise ValueError("kind must be non-empty string")

        start = _parse_dt(ev['start'])
        end = _parse_dt(ev['end'])

        if end <= start:
            raise ValueError(f"event {eid}: end must be after start")

        attendees = ev['attendees']
        if not isinstance(attendees, list):
            raise ValueError("attendees must be an array")

        # Deduplicate attendees while preserving order, validate against contacts
        seen_att = set()
        deduped_attendees = []
        for att in attendees:
            if not isinstance(att, str):
                raise ValueError("attendee id must be string")
            if att not in contacts_set:
                raise ValueError(f"attendee {att} not in contacts")
            if att not in seen_att:
                seen_att.add(att)
                deduped_attendees.append(att)

        # Check dinner constraint: 19:00 start, kind=dinner must end by 20:00 same day
        if kind == 'dinner' and start.hour == 19 and start.minute == 0:
            if end.date() != start.date() or end.hour > 20 or (end.hour == 20 and end.minute > 0):
                raise ValueError(f"dinner event {eid} at 19:00 must end by 20:00 same day")
            existing_dinner_dates.add(start.strftime('%Y-%m-%d'))

        processed_events.append({
            'id': eid,
            'start': ev['start'],
            'end': ev['end'],
            'kind': kind,
            'attendees': deduped_attendees
        })

    # Sort events by id, then attendees
    processed_events.sort(key=lambda e: (e['id'], e['attendees']))

    existing_dinners = sorted(existing_dinner_dates)

    return {
        "name": contract["name"],
        "result": {
            "events": processed_events,
            "existing_dinners": existing_dinners
        }
    }
