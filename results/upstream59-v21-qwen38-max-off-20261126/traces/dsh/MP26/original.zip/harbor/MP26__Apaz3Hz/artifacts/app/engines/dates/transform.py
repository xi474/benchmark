from datetime import date, timedelta


def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def _validate_case(case):
    """Validate the input case structure."""
    if not isinstance(case, dict):
        raise ValueError("case must be an object")
    for key in ('today', 'events', 'contacts'):
        if key not in case:
            raise ValueError(f"missing required field: {key}")
    today_str = case['today']
    if not isinstance(today_str, str):
        raise ValueError("today must be a string")
    events = case['events']
    if not isinstance(events, list):
        raise ValueError("events must be an array")
    contacts = case['contacts']
    if not isinstance(contacts, list):
        raise ValueError("contacts must be an array")
    # Validate today parses
    try:
        today = date.fromisoformat(today_str)
    except (ValueError, TypeError):
        raise ValueError(f"invalid date format for today: {today_str}")
    return today, events, contacts


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = _unwrap(payloads[0])
    today, events, contacts = _validate_case(case)

    # Find next natural week Friday (Monday is week start)
    # today's weekday: Monday=0 ... Sunday=6
    weekday = today.weekday()  # 0=Mon, 6=Sun
    # Days until end of current week (Sunday)
    days_to_next_monday = (7 - weekday) % 7
    if days_to_next_monday == 0:
        # Today is Monday; next week starts in 7 days
        days_to_next_monday = 7
    next_monday = today + timedelta(days=days_to_next_monday)
    next_friday = next_monday + timedelta(days=4)

    # Generate all dates from today to next_friday inclusive
    dates = []
    d = today
    while d <= next_friday:
        dates.append(d.isoformat())
        d += timedelta(days=1)

    return {"name": contract["name"], "result": {"dates": sorted(dates)}}
