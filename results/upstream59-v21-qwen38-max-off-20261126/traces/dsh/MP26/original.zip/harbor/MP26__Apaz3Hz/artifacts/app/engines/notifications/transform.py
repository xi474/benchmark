def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    plan_result = _unwrap(payloads[0])
    snapshots = plan_result['snapshots']  # cancelled event snapshots

    # For each affected contact, collect the event IDs they were part of
    contact_events = {}  # contact_id -> set of event_ids

    for ev in snapshots:
        eid = ev['id']
        attendees = ev['attendees']
        for att in attendees:
            if att not in contact_events:
                contact_events[att] = set()
            contact_events[att].add(eid)

    # Build outbox: one entry per affected contact, sorted by to
    outbox = []
    for contact_id in sorted(contact_events.keys()):
        event_ids = sorted(contact_events[contact_id])
        outbox.append({
            'to': contact_id,
            'event_ids': event_ids
        })

    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox
        }
    }
