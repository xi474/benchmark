from datetime import datetime


def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def _parse_dt(s):
    """Parse YYYY-MM-DDTHH:MM string to datetime."""
    return datetime.fromisoformat(s)


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    dates_result = _unwrap(payloads[0])
    calendar_result = _unwrap(payloads[1])

    all_dates = dates_result['dates']  # list of YYYY-MM-DD strings
    events = calendar_result['events']  # list of event objects
    existing_dinners = set(calendar_result['existing_dinners'])  # set of date strings

    # Determine which dates need new dinner reminders (skip existing dinner dates)
    new_dinner_dates = [d for d in all_dates if d not in existing_dinners]

    # Create new dinner events
    added = []
    new_ids = set()
    for d in new_dinner_dates:
        eid = f"dinner-{d}"
        # Check no conflict with existing event IDs
        for ev in events:
            if ev['id'] == eid:
                raise ValueError(f"new dinner ID {eid} conflicts with existing event")
        new_ids.add(eid)
        added.append({
            'id': eid,
            'start': f"{d}T19:00",
            'end': f"{d}T20:00",
            'kind': 'dinner',
            'attendees': []
        })

    # Sort added by start time
    added.sort(key=lambda e: e['start'])

    # Find cancelled events: any old event whose half-open interval intersects
    # with any new dinner's half-open interval on non-skipped dates.
    # Half-open intersection: [s1, e1) ∩ [s2, e2) ≠ ∅ iff s1 < e2 and s2 < e1
    # "恰19点结束不冲突" means ending exactly at 19:00 doesn't conflict with
    # a new event starting at 19:00 (half-open intervals handle this naturally).

    cancelled_ids = set()
    snapshots = []

    for ev in events:
        ev_start = _parse_dt(ev['start'])
        ev_end = _parse_dt(ev['end'])

        # Check intersection with any new dinner
        for nd in new_dinner_dates:
            dinner_start = _parse_dt(f"{nd}T19:00")
            dinner_end = _parse_dt(f"{nd}T20:00")

            # Half-open intersection: ev_start < dinner_end AND dinner_start < ev_end
            if ev_start < dinner_end and dinner_start < ev_end:
                cancelled_ids.add(ev['id'])
                break  # Only cancel once even if spans multiple dinner dates

    # Build snapshots of cancelled events (original events)
    for ev in events:
        if ev['id'] in cancelled_ids:
            snapshots.append(dict(ev))  # copy

    # Sort snapshots by id
    snapshots.sort(key=lambda e: e['id'])

    # Cancelled list: sorted original event IDs
    cancelled = sorted(cancelled_ids)

    return {
        "name": contract["name"],
        "result": {
            "added": added,
            "cancelled": cancelled,
            "snapshots": snapshots
        }
    }
