#!/usr/bin/env python3
"""Orchestrate all engine components based on file contracts."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (exclude outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs
    # Each contract's output is a file path; inputs reference other outputs or input files
    contract_map = {}  # name -> {contract_path, output, inputs}
    output_to_name = {}  # output path -> component name

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        contract_map[name] = {
            'contract_path': cp,
            'output': c['output'],
            'inputs': c['inputs']
        }
        output_to_name[c['output']] = name

    # Topological sort based on dependencies
    # A component depends on another if any of its inputs is an output of that component
    deps = {}  # name -> set of dependency names
    for name, info in contract_map.items():
        deps[name] = set()
        for inp in info['inputs']:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                if dep_name != name:
                    deps[name].add(dep_name)

    # Kahn's algorithm for topological sort
    in_degree = {name: 0 for name in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            pass  # we need reverse mapping
    # Recompute in-degree properly
    in_degree = {name: 0 for name in contract_map}
    adj = {name: set() for name in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            adj[d].add(name)
            in_degree[name] += 1

    queue = sorted([n for n in contract_map if in_degree[n] == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for neighbor in sorted(adj[node]):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
        queue.sort()

    if len(order) != len(contract_map):
        print("Dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute components in topological order
    for name in order:
        info = contract_map[name]
        render_py = info['contract_path'].parent / 'render.py'
        if not render_py.exists():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
