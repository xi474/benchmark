# Workflow 可观测性报告

- Trial：`MS02__K8K6Wu5__env`
- Task：`MS02`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（28 节点 / 27 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：28；执行边：27（observed=0，inferred=27）
- Execution Trace Graph：`observed`；temporal_next 边 27，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_6eb2803a806a4c5fab94476d -> tool:dsh:lead:call_27a03dfbbd3e4bf59793268a -> tool:dsh:lead:call_8c568ae1abd74f00a2802562 -> tool:dsh:lead:call_b8bdcf3992d74cb4890ccf4d -> tool:dsh:lead:call_887d774bfd0840c6bbfa174a -> tool:dsh:lead:call_63d4e4d4f03e485eaf754809 -> tool:dsh:lead:call_4fa9f9d2367c48b8aa0231e6 -> tool:dsh:lead:call_a9304fb1671f4c8f9c6ba9b4 -> tool:dsh:lead:call_192487249f22483aa94ba9d2 -> tool:dsh:lead:call_312d03cb469744bab1f2850a -> tool:dsh:lead:call_cc014f085dc14b15ba47511a -> tool:dsh:lead:call_8b29b55fa0f54fbe96d7212b -> tool:dsh:lead:call_51bac126da72443db79cdba6 -> tool:dsh:lead:call_44743bdcd3f947e59562184f -> tool:dsh:lead:call_9f415657b134430982c91b63 -> tool:dsh:lead:call_a90aaffb08ab4c8995851b25 -> tool:dsh:lead:call_348820f0252d456fb2249054 -> tool:dsh:lead:call_fea4bf50c6da41dd8d11f56b -> tool:dsh:lead:call_2aea5b0df70f435bb383b6b0 -> tool:dsh:lead:call_75b4dabd40c84df2b95d18ff -> tool:dsh:lead:call_b1ac7318eff747b3831c174a -> tool:dsh:lead:call_975d2f33df5f4a2cb4e9d5d7 -> tool:dsh:lead:call_930091b97b5b4698a7f1781b -> tool:dsh:lead:call_3a41cf339d414dd88614b678 -> tool:dsh:lead:call_2e708562a71e44509092b998 -> tool:dsh:lead:call_80e6f84939ad41c396caa4ba -> tool:dsh:lead:call_0f73060c05e14472aad25e49
- 关键路径耗时：0.836
- Makespan：67.16
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
