def compute(payload):
    """按主题输入顺序生成评分表；每行把具有效章节证据的论文 ID 映射到该主题最高质量分。"""
    topics = payload["topics"]
    papers = payload["papers"]
    result = []
    for topic in topics:
        scores = {}
        for paper in papers:
            pid = paper["id"]
            methods_set = set(paper["methods"])
            best = None
            for claim in paper["claims"]:
                t, section, quality = claim[0], claim[1], claim[2]
                if t == topic and section in methods_set:
                    if best is None or quality > best:
                        best = quality
            if best is not None:
                scores[pid] = best
        result.append(scores)
    return result
