def compute(payload):
    """返回去重并按三元组字典序排列的已有图事实。"""
    graph = payload.get("graph", [])
    # Deduplicate and sort by triple lexicographic order
    seen = set()
    unique = []
    for edge in graph:
        key = (edge[0], edge[1], edge[2])
        if key not in seen:
            seen.add(key)
            unique.append(list(edge))
    unique.sort()
    return unique
