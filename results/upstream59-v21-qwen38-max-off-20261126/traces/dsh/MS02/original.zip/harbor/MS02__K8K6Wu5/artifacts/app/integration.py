from itertools import product as iter_product


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = evidence_scores result: list of dicts (one per topic), mapping paper_id -> max_quality
    right = graph_facts result: sorted deduplicated list of [src, rel, dst] triples
    
    Algorithm:
    - For each topic, find eligible papers (those with valid evidence).
    - Must assign exactly one paper per topic, no paper reused.
    - Maximize minimum quality across all topics, then maximize total quality,
      then minimize lexicographic order of paper ID sequence (in topic order).
    - If no complete assignment exists, return null.
    - Build review as [[topic, paper_id, quality], ...] in topic order.
    - Build graph as union of existing edges + [paper_id, "supports", topic] for each assignment,
      deduplicated and sorted by triple.
    """
    topics = payload["topics"]
    n_topics = len(topics)
    
    # left is a list of dicts, one per topic
    # Each dict maps paper_id -> best quality for that topic
    score_tables = left  # list of dicts
    
    # Build candidate lists per topic: list of (paper_id, quality) sorted for determinism
    candidates = []
    for i in range(n_topics):
        table = score_tables[i]
        cands = [(pid, q) for pid, q in table.items()]
        # Sort by paper_id for deterministic enumeration
        cands.sort(key=lambda x: x[0])
        candidates.append(cands)
    
    # Check if any topic has no candidates
    for c in candidates:
        if not c:
            return None
    
    # We need to find an assignment that:
    # 1. Maximizes min quality
    # 2. Then maximizes total quality  
    # 3. Then minimizes lex order of paper ID sequence
    
    # Use backtracking with pruning
    best_assignment = None
    best_min_q = -1
    best_total_q = -1
    best_pid_seq = None
    
    def backtrack(topic_idx, used_papers, current_assignment, current_min, current_total):
        nonlocal best_assignment, best_min_q, best_total_q, best_pid_seq
        
        if topic_idx == n_topics:
            # Complete assignment found
            pid_seq = tuple(a[0] for a in current_assignment)
            if (current_min > best_min_q or
                (current_min == best_min_q and current_total > best_total_q) or
                (current_min == best_min_q and current_total == best_total_q and
                 (best_pid_seq is None or pid_seq < best_pid_seq))):
                best_min_q = current_min
                best_total_q = current_total
                best_pid_seq = pid_seq
                best_assignment = list(current_assignment)
            return
        
        # Pruning: if current_min already <= best_min_q and we can't improve
        # Actually we want to maximize min, so prune only if impossible to beat
        # For efficiency with small inputs (max 8 topics, 12 papers), simple backtracking is fine
        
        for pid, quality in candidates[topic_idx]:
            if pid in used_papers:
                continue
            new_min = min(current_min, quality)
            # Prune: if new_min < best_min_q, skip (can't improve min)
            if new_min < best_min_q:
                continue
            # If new_min == best_min_q, we might still improve total or lex
            # but only if remaining topics could maintain this min
            used_papers.add(pid)
            current_assignment.append((pid, quality))
            backtrack(topic_idx + 1, used_papers, current_assignment, new_min, current_total + quality)
            current_assignment.pop()
            used_papers.remove(pid)
    
    backtrack(0, set(), [], float('inf'), 0)
    
    if best_assignment is None:
        return None
    
    # Build review
    review = []
    for i, (pid, quality) in enumerate(best_assignment):
        review.append([topics[i], pid, quality])
    
    # Build graph: union of existing edges + new supports edges
    existing_edges = set()
    for edge in right:
        existing_edges.add((edge[0], edge[1], edge[2]))
    
    for i, (pid, quality) in enumerate(best_assignment):
        existing_edges.add((pid, "supports", topics[i]))
    
    # Sort by triple lexicographic order
    sorted_edges = sorted(existing_edges)
    graph = [list(e) for e in sorted_edges]
    
    return {"review": review, "graph": graph}
