# Workflow 可观测性报告

- Trial：`MS11__FKdGmkd__env`
- Task：`MS11`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_272c10788d0344afb3fa8d27 -> tool:dsh:lead:call_6adc578a728e4450a8d97909 -> tool:dsh:lead:call_0c985bd31cff47a480bcf343 -> tool:dsh:lead:call_ca6bca0d9e6049b992584516 -> tool:dsh:lead:call_1ab0f7c8787744578f978ac4 -> tool:dsh:lead:call_2eb09cf4d8a84fd1a42f6fde -> tool:dsh:lead:call_52d2c41d293245f7bcfee805 -> tool:dsh:lead:call_9d5453525761422780e87919 -> tool:dsh:lead:call_f157b8ce449744888fdb3f7e -> tool:dsh:lead:call_f8b0fa779af34a2faaba9b55 -> tool:dsh:lead:call_abf2d33cf6ba48fa91d995f2 -> tool:dsh:lead:call_b3464675cbd84c64b95f0a7a -> tool:dsh:lead:call_b62067b443cf423891b754a1 -> tool:dsh:lead:call_7f8b12b1de9041ad913dae9d -> tool:dsh:lead:call_b4ca713884c04ccfaed71bd7 -> tool:dsh:lead:call_f4bf662df3d04a01be820080 -> tool:dsh:lead:call_01bbdcf6c0ad407696f54f98 -> tool:dsh:lead:call_addad70e8de44995819238e1 -> tool:dsh:lead:call_7180813fa6f94806ad7447af -> tool:dsh:lead:call_5a12c70eea6b44d4adfc6b7c -> tool:dsh:lead:call_92301c9a040f429d85fadf87 -> tool:dsh:lead:call_9c081f15d7584bf5bc3f1269 -> tool:dsh:lead:call_9b8a3660a1b54fc6bbd00a3b -> tool:dsh:lead:call_0890c55f9c9f43db83dcbf8d -> tool:dsh:lead:call_b7e48a5216664356bfa34e5a -> tool:dsh:lead:call_c2515ccecea84666a777e3bd -> tool:dsh:lead:call_198a0c7fa2e94dbca26d2b62 -> tool:dsh:lead:call_258170c54bbb453c8d2cfa5b -> tool:dsh:lead:call_8da040455722439ab526e229 -> tool:dsh:lead:call_1dc8af84253e451885d1394d
- 关键路径耗时：0.778
- Makespan：117.599
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
