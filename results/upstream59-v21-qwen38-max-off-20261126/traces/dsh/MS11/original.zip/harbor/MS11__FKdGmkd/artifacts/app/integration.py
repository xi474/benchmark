def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = student_scores result: {student_id: score_X}
    right = buyer_totals result: {buyer_id: total_Y}
    """
    students = payload["students"]
    buyers = payload["buyers"]
    evidence_rows = payload["evidence"]
    drop_list = payload["drop"]
    
    # left is dict {student: X}, right is dict {buyer: Y}
    scores = left   # {student_id: int}
    totals = right  # {buyer_id: int}
    
    results = []
    
    for drop_source in drop_list:
        result = _solve_drop(students, buyers, scores, totals, evidence_rows, drop_source)
        results.append({"drop": drop_source, "result": result})
    
    return results


def _solve_drop(students, buyers, scores, totals, evidence_rows, drop_source):
    """Solve for one drop scenario. Returns result dict or None."""
    n = len(students)
    
    # Build confidence matrix after dropping a source
    # Step 1: For each source (except dropped), find max strength per (student, buyer) pair
    # Step 2: Sum across sources
    
    # Filter evidence rows
    filtered = []
    for row in evidence_rows:
        src, stu, buy, strength = row[0], row[1], row[2], row[3]
        if drop_source is not None and src == drop_source:
            continue
        filtered.append((src, stu, buy, strength))
    
    # Per source, keep max per (student, buyer)
    source_max = {}  # {(src, stu, buy): max_strength}
    for src, stu, buy, strength in filtered:
        key = (src, stu, buy)
        if key not in source_max or strength > source_max[key]:
            source_max[key] = strength
    
    # Sum across sources per (student, buyer)
    confidence = {}  # {(stu, buy): total_confidence}
    for (src, stu, buy), strength in source_max.items():
        key = (stu, buy)
        confidence[key] = confidence.get(key, 0) + strength
    
    # Build bipartite graph: only edges with confidence > 0
    # Students and buyers are sorted by ID for consistent ordering
    sorted_students = sorted(students)
    sorted_buyers = sorted(buyers)
    
    stu_idx = {s: i for i, s in enumerate(sorted_students)}
    buy_idx = {b: i for i, b in enumerate(sorted_buyers)}
    
    # Build adjacency: for each student, which buyers are available
    adj = [[] for _ in range(n)]
    conf_matrix = [[0] * n for _ in range(n)]
    for (stu, buy), c in confidence.items():
        if stu in stu_idx and buy in buy_idx:
            si = stu_idx[stu]
            bi = buy_idx[buy]
            adj[si].append(bi)
            conf_matrix[si][bi] = c
    
    # Find connected components of the bipartite graph
    # Each component has at most 14 vertices on each side
    components = _find_components(n, adj)
    
    # For each component, enumerate all perfect matchings
    # Then find optimal ones (max floor, then max total)
    # Use component-level enumeration since each component is small
    
    # For each component, get all perfect matchings with their (floor, total)
    comp_matchings = []
    for comp_students, comp_buyers in components:
        matchings = _enumerate_matchings(comp_students, comp_buyers, conf_matrix)
        if not matchings:
            return None  # No perfect matching possible
        comp_matchings.append(matchings)
    
    # Now combine across components
    # We need to find global optimal: maximize min floor across all pairs, then maximize total sum
    # Since components are independent, we can combine them
    
    # First find the global optimal floor and total
    # For each component, find its best (floor, total) among its matchings
    # The global floor = min of per-component floors in the combination
    # The global total = sum of per-component totals
    
    # We need to find combinations that maximize (global_floor, global_total) lexicographically
    # This requires careful combination across components
    
    # Strategy: 
    # 1. Find the maximum achievable global floor
    # 2. Among matchings achieving that floor, find max total
    # 3. Enumerate all matchings achieving both
    
    # For step 1: global floor = min over components of (component's matching floor)
    # To maximize this, each component must use a matching with floor >= target
    # Binary search or iterate over possible floor values
    
    # Collect all distinct floor values across all component matchings
    all_floors = set()
    for matchings in comp_matchings:
        for m in matchings:
            all_floors.add(m['floor'])
    
    # Sort descending to try highest floor first
    sorted_floors = sorted(all_floors, reverse=True)
    
    best_floor = None
    best_total = None
    best_count = 0
    best_combinations = []  # list of full mapping tuples
    
    for target_floor in sorted_floors:
        # For each component, filter matchings with floor >= target_floor
        filtered_comps = []
        for matchings in comp_matchings:
            fm = [m for m in matchings if m['floor'] >= target_floor]
            if not fm:
                break
            filtered_comps.append(fm)
        
        if len(filtered_comps) != len(comp_matchings):
            continue  # Can't achieve this floor
        
        # Now find max total achievable with floor >= target_floor
        # For each component, find max total among filtered matchings
        max_totals_per_comp = [max(m['total'] for m in fc) for fc in filtered_comps]
        achievable_total = sum(max_totals_per_comp)
        
        if best_floor is None or (target_floor, achievable_total) > (best_floor, best_total):
            best_floor = target_floor
            best_total = achievable_total
            
            # Count and collect all combinations achieving this (floor, total)
            # For each component, keep only matchings with floor >= target_floor AND
            # that can participate in a combination with total = best_total
            # Actually, we need: sum of per-comp totals = best_total
            # This means each component must use a matching whose total contributes
            # to reaching best_total. Since components are independent, each component
            # must use a matching with total = max_totals_per_comp[i]
            
            # Wait, that's not quite right. We need sum = best_total, but individual
            # components could trade off. However since we want MAX total, each component
            # independently maximizes its total. So yes, each must use max total matching.
            
            # But actually there might be multiple matchings in a component with the same
            # max total. We need to count all combinations.
            
            # For each component, filter to matchings with floor >= target_floor AND total = max_total_for_that_comp
            final_comps = []
            for i, fc in enumerate(filtered_comps):
                mt = max_totals_per_comp[i]
                final = [m for m in fc if m['total'] == mt]
                final_comps.append(final)
            
            # Count total combinations
            count = 1
            for fc in final_comps:
                count *= len(fc)
            
            best_count = count
            best_combinations = final_comps
            break  # Found the best floor, no need to check lower
    
    if best_floor is None:
        return None
    
    # Now compute numerators for all optimal combinations
    # We need to enumerate all combinations and compute numerators
    # But count could be large... however components are small (<=14 per side)
    # and the number of optimal matchings per component should be manageable
    
    # Generate all combinations
    all_mappings = _generate_combinations(best_combinations)
    
    # For each mapping, compute the correlation numerator
    numerators = []
    buyer_vectors = []
    
    for mapping in all_mappings:
        # mapping is a list of (student_idx, buyer_idx) pairs across all components
        # Build the full assignment: student -> buyer
        assignment = [None] * n
        for si, bi in mapping:
            assignment[si] = bi
        
        # Build buyer vector in student-sorted order
        buyer_vec = tuple(sorted_buyers[assignment[i]] for i in range(n))
        buyer_vectors.append(buyer_vec)
        
        # Compute numerator: n * sum(X*Y) - sum(X) * sum(Y)
        X_vals = [scores[sorted_students[i]] for i in range(n)]
        Y_vals = [totals[sorted_buyers[assignment[i]]] for i in range(n)]
        
        sum_X = sum(X_vals)
        sum_Y = sum(Y_vals)
        sum_XY = sum(x * y for x, y in zip(X_vals, Y_vals))
        
        num = n * sum_XY - sum_X * sum_Y
        numerators.append(num)
    
    min_num = min(numerators)
    max_num = max(numerators)
    
    # Find lex-smallest buyer vector for min and max numerators
    min_indices = [i for i, num in enumerate(numerators) if num == min_num]
    max_indices = [i for i, num in enumerate(numerators) if num == max_num]
    
    min_buyers = min(buyer_vectors[i] for i in min_indices)
    max_buyers = min(buyer_vectors[i] for i in max_indices)
    
    # Find forced pairs: pairs that appear in ALL optimal mappings
    forced_set = None
    for mapping in all_mappings:
        pairs = set()
        for si, bi in mapping:
            pairs.add((sorted_students[si], sorted_buyers[bi]))
        if forced_set is None:
            forced_set = pairs
        else:
            forced_set &= pairs
    
    forced = sorted(forced_set, key=lambda p: p[0]) if forced_set else []
    forced = [[s, b] for s, b in forced]
    
    return {
        "floor": best_floor,
        "total": best_total,
        "count": best_count,
        "min_num": min_num,
        "max_num": max_num,
        "min_buyers": list(min_buyers),
        "max_buyers": list(max_buyers),
        "forced": forced
    }


def _find_components(n, adj):
    """Find connected components in bipartite graph.
    Returns list of (student_indices, buyer_indices) for each component."""
    visited_s = [False] * n
    visited_b = [False] * n
    
    # Build reverse adjacency (buyer -> students)
    rev_adj = [[] for _ in range(n)]
    for si in range(n):
        for bi in adj[si]:
            rev_adj[bi].append(si)
    
    components = []
    for start in range(n):
        if visited_s[start]:
            continue
        # BFS
        comp_s = []
        comp_b = []
        queue_s = [start]
        visited_s[start] = True
        while queue_s:
            next_queue_s = []
            for si in queue_s:
                comp_s.append(si)
                for bi in adj[si]:
                    if not visited_b[bi]:
                        visited_b[bi] = True
                        comp_b.append(bi)
                        # Explore from this buyer back to students
                        for si2 in rev_adj[bi]:
                            if not visited_s[si2]:
                                visited_s[si2] = True
                                next_queue_s.append(si2)
            queue_s = next_queue_s
        
        if comp_s:
            components.append((comp_s, comp_b))
    
    return components


def _enumerate_matchings(comp_students, comp_buyers, conf_matrix):
    """Enumerate all perfect matchings in a component.
    Returns list of dicts with 'floor', 'total', 'pairs' (list of (si, bi))."""
    ns = len(comp_students)
    nb = len(comp_buyers)
    if ns != nb:
        return []
    if ns == 0:
        return [{'floor': float('inf'), 'total': 0, 'pairs': []}]
    
    # Map local indices
    # comp_students and comp_buyers are lists of global indices
    # Build local adjacency
    local_adj = [[] for _ in range(ns)]
    local_conf = [[0] * nb for _ in range(ns)]
    for li, gsi in enumerate(comp_students):
        for lj, gbj in enumerate(comp_buyers):
            c = conf_matrix[gsi][gbj]
            if c > 0:
                local_adj[li].append(lj)
                local_conf[li][lj] = c
    
    # Check if perfect matching is possible (basic check)
    # Use backtracking to enumerate all perfect matchings
    matchings = []
    used = [False] * nb
    
    def backtrack(student_li, current_pairs, current_min, current_total):
        if student_li == ns:
            matchings.append({
                'floor': current_min,
                'total': current_total,
                'pairs': [(comp_students[si], comp_buyers[bi]) for si, bi in current_pairs]
            })
            return
        for bj in local_adj[student_li]:
            if not used[bj]:
                c = local_conf[student_li][bj]
                used[bj] = True
                new_min = min(current_min, c)
                backtrack(student_li + 1, current_pairs + [(student_li, bj)], new_min, current_total + c)
                used[bj] = False
    
    backtrack(0, [], float('inf'), 0)
    return matchings


def _generate_combinations(comp_final_matchings):
    """Generate all combinations of matchings across components.
    Each combination is a flat list of (student_global_idx, buyer_global_idx) pairs."""
    if not comp_final_matchings:
        return [[]]
    
    result = [[]]
    for comp_matchings in comp_final_matchings:
        new_result = []
        for existing in result:
            for m in comp_matchings:
                new_result.append(existing + m['pairs'])
        result = new_result
    
    return result
