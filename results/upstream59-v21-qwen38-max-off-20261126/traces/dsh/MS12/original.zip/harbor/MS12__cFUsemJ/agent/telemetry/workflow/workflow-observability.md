# Workflow 可观测性报告

- Trial：`MS12__cFUsemJ__env`
- Task：`MS12`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（39 节点 / 38 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：39；执行边：38（observed=0，inferred=38）
- Execution Trace Graph：`observed`；temporal_next 边 38，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_73dda0041cb94052b60146f8 -> tool:dsh:lead:call_cedb428687a64202ac070e53 -> tool:dsh:lead:call_3cb8cb7e5bba435cb723cfa4 -> tool:dsh:lead:call_9f31d576012445a6af8ac196 -> tool:dsh:lead:call_eefe36ad720c4c2fad19496d -> tool:dsh:lead:call_6319fa01a8e24579aab2becf -> tool:dsh:lead:call_66704177702741cab0067a60 -> tool:dsh:lead:call_0e89c171eb2143e19df2b1b7 -> tool:dsh:lead:call_031f979608b647bda495208d -> tool:dsh:lead:call_4a65786991164aa9b7cab4be -> tool:dsh:lead:call_9054709015014656855757e1 -> tool:dsh:lead:call_e12929e966aa4e0baa2cd896 -> tool:dsh:lead:call_924992612b4f4dedabee2fdf -> tool:dsh:lead:call_ee9a0017a26042ee9800411a -> tool:dsh:lead:call_d9644e3b489a45cebb53bdc1 -> tool:dsh:lead:call_495c38b493bb419a8f8e473f -> tool:dsh:lead:call_eb2212e253eb428b83a16c5f -> tool:dsh:lead:call_40bd6a0b6a074f388b45d7b7 -> tool:dsh:lead:call_694b444aeb264a5ca9fdfa66 -> tool:dsh:lead:call_bdd8e5f421ba4386b0eae72d -> tool:dsh:lead:call_e79b061216e04107bf084f84 -> tool:dsh:lead:call_7426d08f52e747e48f9bfb44 -> tool:dsh:lead:call_779cc3b0243a43b8aa8cc0de -> tool:dsh:lead:call_c5b1115f60314395950a9525 -> tool:dsh:lead:call_1a7eca751eea45a7869b3b5c -> tool:dsh:lead:call_486d0a9459fb424fa7c9ff42 -> tool:dsh:lead:call_54b3f97bed0841368abb45f2 -> tool:dsh:lead:call_9b9f9971363d4ec8be047dbf -> tool:dsh:lead:call_b9e5e798b6e346b18c08b0c7 -> tool:dsh:lead:call_53d4ca9f0fe1420f983612e4 -> tool:dsh:lead:call_f5220c9a3bd14faa890facf0 -> tool:dsh:lead:call_12252ea4f0ed4c9f86875bac -> tool:dsh:lead:call_90edef5f1ef44c3c975f5a5e -> tool:dsh:lead:call_6100a638a8154d64ad76c5c2 -> tool:dsh:lead:call_219d6e7dd2fb4e0a9a18dbfd -> tool:dsh:lead:call_25522d0af90941b3b01885ee -> tool:dsh:lead:call_922d12dc429b459d8f2f64d4 -> tool:dsh:lead:call_88f92bebd9d2474687e15bb9
- 关键路径耗时：1.011
- Makespan：146.446
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
