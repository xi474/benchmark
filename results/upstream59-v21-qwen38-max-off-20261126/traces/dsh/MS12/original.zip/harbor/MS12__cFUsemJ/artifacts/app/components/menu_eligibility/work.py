def compute(payload):
    """每个到货信号映射至可供菜品 ID，保持 recipes 顺序，检查难度、原料可得性和过敏限制。"""
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]
    
    # Collect all forbidden ingredients across all groups
    # A recipe is unavailable if ANY group has a forbidden ingredient in it
    all_forbidden = set()
    for g in groups:
        # g = [name, count, forbidden_ingredients, liked_categories]
        for ing in g[2]:
            all_forbidden.add(ing)
    
    result = {}
    for signal, available_ingredients in delivery.items():
        available_set = set(available_ingredients)
        eligible = []
        for recipe in recipes:
            # Check difficulty <= 4
            if recipe["difficulty"] > 4:
                continue
            # Check all ingredients are available
            if not all(ing in available_set for ing in recipe["ingredients"]):
                continue
            # Check no forbidden ingredient (any group forbids it)
            if any(ing in all_forbidden for ing in recipe["ingredients"]):
                continue
            eligible.append(recipe["id"])
        result[signal] = eligible
    
    return result
