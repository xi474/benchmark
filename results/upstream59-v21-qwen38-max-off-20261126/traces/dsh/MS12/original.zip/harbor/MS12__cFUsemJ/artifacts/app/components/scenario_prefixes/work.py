def compute(payload):
    """输出 [信号历史,该完整叶的权重或 null]，去重生成所有非空前缀，按历史字典序排列。"""
    scenarios = payload["scenarios"]
    
    # Collect all non-empty prefixes with their weights (only full-length gets weight)
    prefix_map = {}  # tuple of signals -> weight or None
    for sc in scenarios:
        signals = sc["signals"]
        weight = sc["weight"]
        for i in range(1, len(signals) + 1):
            prefix = tuple(signals[:i])
            if prefix not in prefix_map:
                # Full-length prefix gets the weight, others get None
                if i == len(signals):
                    prefix_map[prefix] = weight
                else:
                    prefix_map[prefix] = None
            else:
                # If already exists and this is a full-length match, set weight
                if i == len(signals):
                    prefix_map[prefix] = weight
    
    # Sort by lexicographic order of the prefix (as list of strings)
    sorted_prefixes = sorted(prefix_map.keys(), key=lambda p: list(p))
    
    # Build result: [[history, weight_or_null], ...]
    result = []
    for prefix in sorted_prefixes:
        result.append([list(prefix), prefix_map[prefix]])
    
    return result
