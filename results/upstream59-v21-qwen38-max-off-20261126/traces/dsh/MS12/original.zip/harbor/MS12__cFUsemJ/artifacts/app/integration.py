def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    # left = scenario_prefixes result: list of [history, weight_or_null]
    # right = menu_eligibility result: dict signal -> [recipe_ids in order]
    
    recipes_list = payload["recipes"]
    recipes = {r["id"]: r for r in recipes_list}
    groups = payload["groups"]
    delivery = payload["delivery"]
    budget = payload["budget"]
    scenarios = payload["scenarios"]
    
    # Build prefix info from left
    # left is [[history, weight_or_null], ...] sorted by history lex
    prefixes = []  # list of (tuple_history, weight_or_null)
    for item in left:
        hist = tuple(item[0])
        w = item[1]
        prefixes.append((hist, w))
    
    # Map prefix index
    prefix_to_idx = {p[0]: i for i, p in enumerate(prefixes)}
    num_prefixes = len(prefixes)
    
    # For each prefix, determine available recipes
    # The signal for a prefix is the last element of the history
    # Available recipes come from right[signal], filtered by difficulty/ingredients/allergies (already done)
    prefix_available = {}  # prefix_tuple -> list of recipe ids (in recipes order)
    for hist, _ in prefixes:
        signal = hist[-1]
        prefix_available[hist] = right.get(signal, [])
    
    # For each scenario, build its path of prefixes
    # scenario_paths[i] = list of prefix tuples for scenario i
    scenario_paths = []
    for sc in scenarios:
        signals = sc["signals"]
        path = []
        for d in range(1, len(signals) + 1):
            prefix = tuple(signals[:d])
            path.append(prefix)
        scenario_paths.append(path)
    
    # Compute satisfaction for each group and recipe
    # satisfaction[group_idx][recipe_id] = 1 if group likes the category, else 0
    group_sat = {}
    for gi, g in enumerate(groups):
        liked_cats = set(g[3])
        sat = {}
        for r in recipes_list:
            sat[r["id"]] = 1 if r["cat"] in liked_cats else 0
        group_sat[gi] = sat
    
    # Now we need to find optimal policies
    # A policy assigns a recipe to each prefix
    # Constraints per scenario:
    #   - Each day's recipe must be in prefix_available for that prefix
    #   - No repeated recipe IDs along the path
    #   - No adjacent same category along the path
    #   - Total cost <= budget
    
    # Since max 5 days, 12 recipes, 12 prefixes, we can do DP or enumeration
    # But the constraint is per-scenario, and prefixes are shared across scenarios
    
    # Strategy: enumerate all valid assignments using backtracking with pruning
    # Prefixes are ordered. We assign recipes one by one.
    # For each scenario, track used recipes and previous category.
    
    # Actually, let's think about this differently.
    # We need to assign a recipe to each prefix such that for every scenario,
    # the sequence of recipes along its path satisfies constraints.
    
    # Let's use backtracking over prefixes in order.
    # State: for each scenario, the set of used recipe IDs and the last category.
    
    # First, let's collect all unique recipe IDs that could be assigned
    all_recipe_ids = [r["id"] for r in recipes_list]
    
    # For efficiency, precompute recipe categories and costs
    rec_cat = {r["id"]: r["cat"] for r in recipes_list}
    rec_cost = {r["id"]: r["cost"] for r in recipes_list}
    
    # Build scenario info
    num_scenarios = len(scenarios)
    sc_weights = [sc["weight"] for sc in scenarios]
    sc_num_days = [len(sc["signals"]) for sc in scenarios]
    
    # For each scenario and each day, which prefix index
    sc_day_prefix = []  # sc_day_prefix[s][d] = prefix index
    for s, path in enumerate(scenario_paths):
        row = []
        for prefix in path:
            row.append(prefix_to_idx[prefix])
        sc_day_prefix.append(row)
    
    # Backtracking search
    # assignment[prefix_idx] = recipe_id or None
    assignment = [None] * num_prefixes
    
    # Per-scenario state: used_recipes (set), last_cat, running_cost
    # We'll track these incrementally
    
    best = {"floor": -1, "utility": -1, "cost": float('inf'), "assignments": []}
    
    def evaluate(assign):
        """Evaluate a complete assignment. Returns (floor, utility, cost)."""
        floors = []
        utilities = []
        costs = []
        for s in range(num_scenarios):
            path = scenario_paths[s]
            total_cost = 0
            per_group_sat = [0] * len(groups)
            for pi in sc_day_prefix[s]:
                rid = assign[pi]
                total_cost += rec_cost[rid]
                for gi in range(len(groups)):
                    per_group_sat[gi] += group_sat[gi][rid]
            
            if total_cost > budget:
                return None  # invalid
            
            # Service score = min per-person satisfaction across groups
            # per_group_sat[gi] is already per-person (each person gets 1 if they like the cat)
            service = min(per_group_sat)
            floors.append(service)
            
            # Total person score = sum of (per_person_sat * count)
            total_person = sum(per_group_sat[gi] * groups[gi][1] for gi in range(len(groups)))
            utilities.append(total_person)
            costs.append(total_cost)
        
        floor_val = min(floors)
        utility_val = sum(sc_weights[s] * utilities[s] for s in range(num_scenarios))
        cost_val = sum(sc_weights[s] * costs[s] for s in range(num_scenarios))
        return (floor_val, utility_val, cost_val)
    
    def is_better(new, old):
        """Check if new solution is better than old using the tiebreaking rules."""
        if new[0] > old[0]:
            return True
        if new[0] < old[0]:
            return False
        if new[1] > old[1]:
            return True
        if new[1] < old[1]:
            return False
        if new[2] < old[2]:
            return True
        return False
    
    # Incremental backtracking
    # sc_state[s] = (used_recipes_set, last_cat, running_cost)
    sc_state = [(set(), None, 0) for _ in range(num_scenarios)]
    
    # For each prefix, which scenarios pass through it and at which day
    prefix_scenarios = [[] for _ in range(num_prefixes)]  # list of (scenario_idx, day_in_scenario)
    for s, path in enumerate(scenario_paths):
        for d, prefix in enumerate(path):
            pidx = prefix_to_idx[prefix]
            prefix_scenarios[pidx].append((s, d))
    
    def backtrack(pidx):
        if pidx == num_prefixes:
            # Complete assignment - evaluate
            result = evaluate(assignment)
            if result is None:
                return
            floor_val, utility_val, cost_val = result
            new_score = (floor_val, utility_val, cost_val)
            old_score = (best["floor"], best["utility"], best["cost"])
            if best["floor"] == -1 or is_better(new_score, old_score):
                if is_better(new_score, old_score) or best["floor"] == -1:
                    best["floor"] = floor_val
                    best["utility"] = utility_val
                    best["cost"] = cost_val
                    best["assignments"] = [list(assignment)]
                else:
                    # Same score - check if this assignment gives lex smaller menu
                    # or add to list for allowed computation
                    best["assignments"].append(list(assignment))
            return
        
        prefix = prefixes[pidx][0]
        available = prefix_available[prefix]
        
        for rid in available:
            # Check constraints for all scenarios passing through this prefix
            valid = True
            saved_states = []
            affected = prefix_scenarios[pidx]
            
            for s, d in affected:
                used, last_cat, run_cost = sc_state[s]
                new_cost = run_cost + rec_cost[rid]
                
                # Budget check (can prune early but let's be safe)
                # We can't fully check budget here since future days aren't assigned yet
                # But we can check if already over budget
                # Actually we need to be careful - only check at completion
                
                # Repeat check
                if rid in used:
                    valid = False
                    break
                
                # Adjacent category check
                if d > 0 and last_cat == rec_cat[rid]:
                    valid = False
                    break
                
                saved_states.append((s, used, last_cat, run_cost))
            
            if not valid:
                continue
            
            # Apply state updates
            for s, used, last_cat, run_cost in saved_states:
                new_used = used | {rid}
                sc_state[s] = (new_used, rec_cat[rid], run_cost + rec_cost[rid])
            
            assignment[pidx] = rid
            backtrack(pidx + 1)
            assignment[pidx] = None
            
            # Restore states
            for s, used, last_cat, run_cost in saved_states:
                sc_state[s] = (used, last_cat, run_cost)
    
    backtrack(0)
    
    if not best["assignments"]:
        return {"histories": [list(p[0]) for p in prefixes], "optimal": None}
    
    # Find the lexicographically smallest menu vector among all optimal assignments
    # Menu vector is ordered by prefix order
    all_menus = [tuple(a) for a in best["assignments"]]
    all_menus.sort()
    lex_min_menu = list(all_menus[0])
    
    # Allowed: for each prefix, collect all recipe IDs that appear in any optimal assignment
    allowed_sets = [set() for _ in range(num_prefixes)]
    for a in best["assignments"]:
        for i, rid in enumerate(a):
            allowed_sets[i].add(rid)
    allowed = [sorted(s) for s in allowed_sets]
    
    # Count distinct prefix-to-recipe mappings across all optimal assignments
    distinct_mappings = set()
    for a in best["assignments"]:
        distinct_mappings.add(tuple(a))
    count = len(distinct_mappings)
    
    histories = [list(p[0]) for p in prefixes]
    
    return {
        "histories": histories,
        "optimal": {
            "floor": best["floor"],
            "utility": best["utility"],
            "cost": best["cost"],
            "count": count,
            "menu": lex_min_menu,
            "allowed": allowed
        }
    }
