# Workflow 可观测性报告

- Trial：`MS14__CM3Yr9a__env`
- Task：`MS14`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_4cb3794cb76b4e59961c9ea3 -> tool:dsh:lead:call_c637f73561f3413bad71d546 -> tool:dsh:lead:call_8f97a5066cce483baba4f1e3 -> tool:dsh:lead:call_ec7b22b5fb7d43dcbbb5a9e5 -> tool:dsh:lead:call_a1055c0d3fe04d9bbfb2da67 -> tool:dsh:lead:call_546316286bb5422bbfaf5311 -> tool:dsh:lead:call_98f990de33dc485f8d62c640 -> tool:dsh:lead:call_ae7af2c0fc234682a0957769 -> tool:dsh:lead:call_290761583ead4b41b0841c14 -> tool:dsh:lead:call_99ac5f3e0a9d457f83c60bcb -> tool:dsh:lead:call_91f8c1ac375e4165aa175ff4 -> tool:dsh:lead:call_26f618393b8c4c01a23b16e3 -> tool:dsh:lead:call_3699e5426fdf45a6b9a9a67a -> tool:dsh:lead:call_ffb9a69b374d4d6799f13d90 -> tool:dsh:lead:call_d1da294525d04deea46db173 -> tool:dsh:lead:call_c16ddbe8af204f6295ce4be9 -> tool:dsh:lead:call_038c1754f6f646d6bd570ad5 -> tool:dsh:lead:call_21d21813f6794fe3a15a2cf6 -> tool:dsh:lead:call_0c2358e385cf48ba8717ee0e -> tool:dsh:lead:call_50ee695f37ac47689f1b297e -> tool:dsh:lead:call_8dd63fba5ed5481f94bd8233 -> tool:dsh:lead:call_af490441dc1c4ce5bed1975e -> tool:dsh:lead:call_f6776443457f44a0b8b0a87b -> tool:dsh:lead:call_ad2eeea4ad934766a9da1ceb -> tool:dsh:lead:call_caaebfab4bbb48af813e3024 -> tool:dsh:lead:call_eab6d1b9e4254c48b70cfe34 -> tool:dsh:lead:call_6cb62c3a9b9b477c9b0fadb1 -> tool:dsh:lead:call_9a1dfb86651b45c9a5d55ba7 -> tool:dsh:lead:call_189ffc2fc9164edba87d37d4 -> tool:dsh:lead:call_261c8154afe54c77b95b2acf -> tool:dsh:lead:call_94a50bfb83fc4bd9a783bc6c -> tool:dsh:lead:call_49d2d443df1341d3aca54cb5 -> tool:dsh:lead:call_d023df10f2c146e5b4387afa
- 关键路径耗时：0.675
- Makespan：175.973
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
