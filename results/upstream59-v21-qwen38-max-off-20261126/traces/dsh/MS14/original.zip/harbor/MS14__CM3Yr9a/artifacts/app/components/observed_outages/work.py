def compute(payload):
    """为每个查询逐时隙列出当时可见且实际为 down 的域名数组，升序；按有效时刻再按看到时刻选择最新记录。"""
    queries = payload.get("queries", [])
    log = payload.get("log", [])

    results = []
    for q in queries:
        as_of = q["as_of"]
        start = q["start"]
        end = q["end"]

        # Filter log records visible at as_of (seen_at <= as_of)
        visible = [(domain, eff, seen, status) for domain, eff, seen, status in log if seen <= as_of]

        # Group by domain
        from collections import defaultdict
        domain_records = defaultdict(list)
        for domain, eff, seen, status in visible:
            domain_records[domain].append((eff, seen, status))

        # For each timeslot, determine which domains are down/degraded
        slot_down = []
        for t in range(start, end):
            down_domains = []
            for domain, records in domain_records.items():
                # Find records with effective_time <= t
                candidates = [(eff, seen, status) for eff, seen, status in records if eff <= t]
                if not candidates:
                    continue
                # Pick the one with max effective_time, then max seen_at
                best = max(candidates, key=lambda x: (x[0], x[1]))
                if best[2] != "up":  # down or degraded
                    down_domains.append(domain)
            down_domains.sort()
            slot_down.append(down_domains)

        results.append(slot_down)

    return results
