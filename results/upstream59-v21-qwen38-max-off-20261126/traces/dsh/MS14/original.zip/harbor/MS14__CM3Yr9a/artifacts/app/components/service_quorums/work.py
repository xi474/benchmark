def compute(payload):
    """按服务 ID 索引门槛及直接输入，值为 [need,inputs]；保留输入顺序和共享故障域。"""
    services = payload.get("services", [])
    result = {}
    for svc in services:
        sid = svc["id"]
        need = svc["need"]
        inputs = list(svc["inputs"])
        result[sid] = [need, inputs]
    return result
