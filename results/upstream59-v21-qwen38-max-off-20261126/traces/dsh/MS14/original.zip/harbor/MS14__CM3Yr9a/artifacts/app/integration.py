from itertools import combinations


def _eval_service_available(svc_id, quorums, domain_status, cache):
    """Check if a service is available given current domain statuses.
    domain_status: dict mapping domain name -> bool (True=up)
    quorums: dict mapping service id -> [need, inputs]
    cache: dict for memoization within one evaluation
    """
    if svc_id in cache:
        return cache[svc_id]
    if svc_id not in quorums:
        # It's a domain, not a service
        result = domain_status.get(svc_id, True)
        cache[svc_id] = result
        return result
    need, inputs = quorums[svc_id]
    count = 0
    for inp in inputs:
        if inp in quorums:
            # It's another service
            if _eval_service_available(inp, quorums, domain_status, cache):
                count += 1
        else:
            # It's a domain
            if domain_status.get(inp, True):
                count += 1
        if count >= need:
            cache[svc_id] = True
            return True
    cache[svc_id] = False
    return False


def _check_targets_available(targets, quorums, domain_status):
    """Check if all targets are available."""
    cache = {}
    for t in targets:
        if t in quorums:
            if not _eval_service_available(t, quorums, domain_status, cache):
                return False
        else:
            if not domain_status.get(t, True):
                return False
    return True


def _compute_target_status(target, quorums, domain_status):
    """Return True if target is available."""
    cache = {}
    if target in quorums:
        return _eval_service_available(target, quorums, domain_status, cache)
    else:
        return domain_status.get(target, True)


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = observed_outages result: list of queries, each is list of slots, each is sorted list of down domains
    right = service_quorums result: dict mapping service id -> [need, inputs]
    """
    queries = payload["queries"]
    domains = payload["domains"]
    quorums = right  # {svc_id: [need, inputs]}

    results = []
    for qi, q in enumerate(queries):
        start = q["start"]
        end = q["end"]
        targets = q["targets"]
        slot_down_domains = left[qi]  # list of lists of down domain names

        # Build per-slot domain status and determine target availability
        # domain_status[slot_index] = dict of domain -> bool
        target_unavailable_slots = {}  # target -> list of slots where unavailable
        
        for si, t_offset in enumerate(range(start, end)):
            down_set = set(slot_down_domains[si])
            domain_status = {}
            for d in domains:
                domain_status[d] = d not in down_set
            
            for target in targets:
                avail = _compute_target_status(target, quorums, domain_status)
                if not avail:
                    if target not in target_unavailable_slots:
                        target_unavailable_slots[target] = []
                    target_unavailable_slots[target].append(t_offset)

        # Build incidents: merge consecutive unavailable slots per target
        incidents = []
        for target in sorted(target_unavailable_slots.keys()):
            slots = sorted(target_unavailable_slots[target])
            # Merge into half-open intervals
            if not slots:
                continue
            interval_start = slots[0]
            prev = slots[0]
            for s in slots[1:]:
                if s == prev + 1:
                    prev = s
                else:
                    incidents.append([target, interval_start, prev + 1])
                    interval_start = s
                    prev = s
            incidents.append([target, interval_start, prev + 1])
        
        # Sort incidents by target ID, then by start
        incidents.sort(key=lambda x: (x[0], x[1]))

        # Compute repairs: find all inclusion-minimal domain sets that fix everything
        # First, identify problem slots (where any target is unavailable)
        problem_slots = set()
        for target, slots in target_unavailable_slots.items():
            for s in slots:
                problem_slots.add(s)

        if not problem_slots:
            repairs = [[]]
        else:
            # Candidate domains: those that are down in at least one problem slot
            candidate_domains = set()
            for si, t_offset in enumerate(range(start, end)):
                if t_offset in problem_slots:
                    for d in slot_down_domains[si]:
                        candidate_domains.add(d)
            
            candidate_list = sorted(candidate_domains)
            
            # For each problem slot, precompute domain status
            problem_slot_data = {}
            for si, t_offset in enumerate(range(start, end)):
                if t_offset in problem_slots:
                    down_set = set(slot_down_domains[si])
                    domain_status = {}
                    for d in domains:
                        domain_status[d] = d not in down_set
                    problem_slot_data[t_offset] = domain_status

            def check_repair_set(repair_set):
                """Check if forcing these domains up fixes all problem slots."""
                for t_offset, base_status in problem_slot_data.items():
                    # Create modified status with repair domains forced up
                    status = dict(base_status)
                    for d in repair_set:
                        status[d] = True
                    if not _check_targets_available(targets, quorums, status):
                        return False
                return True

            # Find all inclusion-minimal repair sets using iterative deepening
            minimal_repairs = []
            found_at_size = None
            
            for k in range(len(candidate_list) + 1):
                if found_at_size is not None and k > found_at_size:
                    break
                for combo in combinations(candidate_list, k):
                    combo_set = set(combo)
                    # Check minimality: no proper subset should work
                    # Since we go bottom-up, if any subset of size < k worked,
                    # it would already be in minimal_repairs
                    is_minimal = True
                    if k > 0:
                        for existing in minimal_repairs:
                            if set(existing).issubset(combo_set):
                                is_minimal = False
                                break
                    
                    if is_minimal and check_repair_set(combo_set):
                        minimal_repairs.append(list(combo))
                        if found_at_size is None:
                            found_at_size = k

            # Sort: by size first, then lexicographically
            minimal_repairs.sort(key=lambda x: (len(x), x))
            repairs = minimal_repairs

        results.append({
            "incidents": incidents,
            "repairs": repairs
        })

    return results
