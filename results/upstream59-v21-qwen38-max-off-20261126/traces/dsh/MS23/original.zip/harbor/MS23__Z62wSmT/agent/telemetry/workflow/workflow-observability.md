# Workflow 可观测性报告

- Trial：`MS23__Z62wSmT__env`
- Task：`MS23`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_61231b30c2124066b5b86af9 -> tool:dsh:lead:call_bea857b8a86b43d1ae209217 -> tool:dsh:lead:call_22d437213e0246bdaaa6a387 -> tool:dsh:lead:call_e2785e9ca3bf41fa8906ad33 -> tool:dsh:lead:call_ce04908bde1d404fbf09600b -> tool:dsh:lead:call_eaaedaa2c3244d5bbbe6d124 -> tool:dsh:lead:call_7c3961e2a61f44de83b243ef -> tool:dsh:lead:call_9cb898bc36ab40eba2dd1f12 -> tool:dsh:lead:call_9fd7733006544a7a936cb078 -> tool:dsh:lead:call_022cb7a7148049b5a460a931 -> tool:dsh:lead:call_35d8524f14204f4db219514d -> tool:dsh:lead:call_f7dcfd7101cc4a5281c3f6af -> tool:dsh:lead:call_9d34f91efecd405394a48386 -> tool:dsh:lead:call_f8b6160b5c5e4da4974356de -> tool:dsh:lead:call_6a5aeff7c8ec463eae00505e -> tool:dsh:lead:call_55432fc704534bf9af8c5c62 -> tool:dsh:lead:call_6cc674922a614e6ebe04fb07 -> tool:dsh:lead:call_95fbc419f4f6403da5891d01 -> tool:dsh:lead:call_845a570327ff4f90aa0497b3 -> tool:dsh:lead:call_930b8a47de8549deb392370f -> tool:dsh:lead:call_972ea60e1cb149c581c7c69a -> tool:dsh:lead:call_625931bb86bc4ee589522364 -> tool:dsh:lead:call_a5167577e4be476ab508271e -> tool:dsh:lead:call_1039d659e0b848ac8edd6a07 -> tool:dsh:lead:call_67bad7d290674e7da51f7985 -> tool:dsh:lead:call_48e3cdb3054b443c8ba0e6ff -> tool:dsh:lead:call_08cd54d636114a6e8a3a92a9 -> tool:dsh:lead:call_1b0b8d8c6d0742f4a53e68ed -> tool:dsh:lead:call_2763e701b3fc4a35bcef4ec7 -> tool:dsh:lead:call_e5e45338ad8e4378a3f99a37 -> tool:dsh:lead:call_008c4656ef2840a2a037380f -> tool:dsh:lead:call_537739c786b74667b9e9663d -> tool:dsh:lead:call_79fa30d3fa69414c876e61dc -> tool:dsh:lead:call_0b250450f31a413fb3826129 -> tool:dsh:lead:call_a6336afb9daa427db5b152c1 -> tool:dsh:lead:call_b75969758007404184abcda8 -> tool:dsh:lead:call_3de238b7b8df4208a33c521c
- 关键路径耗时：0.832
- Makespan：197.935
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
