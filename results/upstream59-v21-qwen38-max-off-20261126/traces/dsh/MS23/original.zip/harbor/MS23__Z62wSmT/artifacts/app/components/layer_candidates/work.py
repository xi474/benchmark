def compute(payload):
    """为每个快照按 b 生成候选层数组。每层候选为 [按 a,c 行优先的计数向量,该层的中位数净分]，满足边际、禁止格和 ac 上限；按向量字典序。"""
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden_set = set()
        for f in snap.get("forbidden", []):
            forbidden_set.add(tuple(f))
        
        k_a = len(ab)
        k_b = len(ab[0]) if k_a > 0 else 0
        k_c = len(bc[0]) if len(bc) > 0 else 0
        
        snap_result = []
        for b in range(k_b):
            # Marginals for this layer
            row_sums = [ab[a][b] for a in range(k_a)]  # sum over c
            col_sums = [bc[b][c] for c in range(k_c)]  # sum over a
            
            # Upper bounds from ac
            upper = [[ac[a][c] for c in range(k_c)] for a in range(k_a)]
            
            # Forbidden mask for this b layer
            forbidden_mask = [[False]*k_c for _ in range(k_a)]
            for a in range(k_a):
                for c in range(k_c):
                    if (a, b, c) in forbidden_set:
                        forbidden_mask[a][c] = True
                        upper[a][c] = 0
            
            # Enumerate all valid matrices using backtracking
            candidates = []
            matrix = [[0]*k_c for _ in range(k_a)]
            
            def backtrack(a, c):
                if a == k_a:
                    # Check column sums
                    for cc in range(k_c):
                        if sum(matrix[aa][cc] for aa in range(k_a)) != col_sums[cc]:
                            return
                    # Valid! Compute score and flatten
                    flat = []
                    net_score = 0
                    for aa in range(k_a):
                        for cc in range(k_c):
                            flat.append(matrix[aa][cc])
                            if matrix[aa][cc] > 0:
                                vals = sorted([aa, b, cc])
                                med = vals[1]
                                k = k_a  # k values are 0..k-1
                                if med == k - 1:
                                    s = 1
                                elif med == 0:
                                    s = -1
                                else:
                                    s = 0
                                net_score += matrix[aa][cc] * s
                    candidates.append((flat, net_score))
                    return
                
                if c == k_c:
                    # Check row sum for this a
                    if sum(matrix[a]) != row_sums[a]:
                        return
                    backtrack(a + 1, 0)
                    return
                
                if forbidden_mask[a][c]:
                    matrix[a][c] = 0
                    backtrack(a, c + 1)
                    return
                
                # Remaining columns in this row
                remaining_in_row = row_sums[a] - sum(matrix[a][:c])
                # Remaining capacity from column sum
                current_col_sum = sum(matrix[aa][c] for aa in range(a))
                remaining_in_col = col_sums[c] - current_col_sum
                
                max_val = min(remaining_in_row, remaining_in_col, upper[a][c])
                
                for v in range(max_val + 1):
                    matrix[a][c] = v
                    backtrack(a, c + 1)
                matrix[a][c] = 0
            
            backtrack(0, 0)
            
            # Sort by vector lexicographic order
            candidates.sort(key=lambda x: x[0])
            snap_result.append(candidates)
        
        results.append(snap_result)
    return results
