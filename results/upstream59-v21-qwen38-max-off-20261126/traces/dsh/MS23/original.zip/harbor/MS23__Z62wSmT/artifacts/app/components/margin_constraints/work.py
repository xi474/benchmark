def compute(payload):
    """为每个快照输出 [ab 与 ac 各 a 总量是否相容,按 a,c 行优先展开的 ac 配额]。"""
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        ac = snap["ac"]
        k_a = len(ab)
        # Row sums of ab by a
        ab_row_sums = [sum(ab[a]) for a in range(k_a)]
        # Row sums of ac by a
        ac_row_sums = [sum(ac[a]) for a in range(len(ac))]
        compatible = (ab_row_sums == ac_row_sums)
        # Flatten ac in row-major order (a, c)
        ac_flat = []
        for a in range(len(ac)):
            for c in range(len(ac[a])):
                ac_flat.append(ac[a][c])
        results.append([compatible, ac_flat])
    return results
