def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    results = []
    for idx, snap in enumerate(payload["snapshots"]):
        ac = snap["ac"]
        k_a = len(ac)
        k_c = len(ac[0]) if k_a > 0 else 0
        
        # Check margin compatibility
        compatible, ac_flat = left[idx]
        if not compatible:
            results.append(None)
            continue
        
        # Get layer candidates per b
        layer_cands = right[idx]
        k_b = len(layer_cands)
        
        if k_b == 0:
            # No b values - edge case
            results.append(None)
            continue
        
        # ac target as 2D
        ac_target = [[ac[a][c] for c in range(k_c)] for a in range(k_a)]
        
        # Backtrack over b values, picking one candidate per b
        # Track remaining ac budget
        remaining = [row[:] for row in ac_target]
        
        valid_tables = []  # list of (net_score, full_3d_table)
        
        def backtrack(b_idx):
            if b_idx == k_b:
                # Check remaining is all zeros
                for a in range(k_a):
                    for c in range(k_c):
                        if remaining[a][c] != 0:
                            return
                # Valid table found! Compute net score from accumulated layers
                # We already track scores; just record
                valid_tables.append(current_score)
                return
            
            for flat_vec, layer_score in layer_cands[b_idx]:
                # Check if this candidate fits within remaining budget
                ok = True
                for a in range(k_a):
                    for c in range(k_c):
                        val = flat_vec[a * k_c + c]
                        if val > remaining[a][c]:
                            ok = False
                            break
                    if not ok:
                        break
                
                if not ok:
                    continue
                
                # Apply
                for a in range(k_a):
                    for c in range(k_c):
                        remaining[a][c] -= flat_vec[a * k_c + c]
                
                current_score[0] += layer_score
                backtrack(b_idx + 1)
                current_score[0] -= layer_score
                
                # Undo
                for a in range(k_a):
                    for c in range(k_c):
                        remaining[a][c] += flat_vec[a * k_c + c]
        
        current_score = [0]
        backtrack(0)
        
        if not valid_tables:
            results.append(None)
            continue
        
        # Now we need more info: we need the actual tables for guaranteed and witness
        # Let's redo with full table tracking
        
        valid_tables_full = []  # list of (net_score, 3d_table_as_list_of_lists_of_lists)
        
        remaining2 = [row[:] for row in ac_target]
        chosen_layers = [None] * k_b
        
        def backtrack2(b_idx):
            if b_idx == k_b:
                for a in range(k_a):
                    for c in range(k_c):
                        if remaining2[a][c] != 0:
                            return
                # Build full 3D table
                table = [[[0]*k_c for _ in range(k_b)] for _ in range(k_a)]
                for bb in range(k_b):
                    fv = chosen_layers[bb][0]
                    for a in range(k_a):
                        for c in range(k_c):
                            table[a][bb][c] = fv[a * k_c + c]
                valid_tables_full.append((chosen_net[0], table))
                return
            
            for flat_vec, layer_score in layer_cands[b_idx]:
                ok = True
                for a in range(k_a):
                    for c in range(k_c):
                        val = flat_vec[a * k_c + c]
                        if val > remaining2[a][c]:
                            ok = False
                            break
                    if not ok:
                        break
                
                if not ok:
                    continue
                
                for a in range(k_a):
                    for c in range(k_c):
                        remaining2[a][c] -= flat_vec[a * k_c + c]
                
                chosen_layers[b_idx] = (flat_vec, layer_score)
                chosen_net[0] += layer_score
                backtrack2(b_idx + 1)
                chosen_net[0] -= layer_score
                chosen_layers[b_idx] = None
                
                for a in range(k_a):
                    for c in range(k_c):
                        remaining2[a][c] += flat_vec[a * k_c + c]
        
        chosen_net = [0]
        backtrack2(0)
        
        num_tables = len(valid_tables_full)
        
        # Spectrum: group by net score, sort ascending
        from collections import Counter
        score_counts = Counter()
        for score, _ in valid_tables_full:
            score_counts[score] += 1
        spectrum = sorted([[s, cnt] for s, cnt in score_counts.items()], key=lambda x: x[0])
        
        # Guaranteed: cells where ALL valid tables have count > 0
        # Find min count per cell across all tables
        min_per_cell = {}
        for score, table in valid_tables_full:
            for a in range(k_a):
                for b in range(k_b):
                    for c in range(k_c):
                        key = (a, b, c)
                        val = table[a][b][c]
                        if key not in min_per_cell:
                            min_per_cell[key] = val
                        else:
                            min_per_cell[key] = min(min_per_cell[key], val)
        
        guaranteed = []
        for a in range(k_a):
            for b in range(k_b):
                for c in range(k_c):
                    key = (a, b, c)
                    if key in min_per_cell and min_per_cell[key] > 0:
                        guaranteed.append([a, b, c, min_per_cell[key]])
        
        # Witness: table with lowest net score; among those, the one whose
        # flattened non-zero entries (in a→b→c order) form the lexicographically
        # smallest vector. Output only non-zero entries as [a,b,c,count].
        min_score = min(s for s, _ in valid_tables_full)
        min_tables = [(score, table) for score, table in valid_tables_full if score == min_score]
        
        def get_nonzero_entries(table):
            entries = []
            for a in range(k_a):
                for b in range(k_b):
                    for c in range(k_c):
                        if table[a][b][c] > 0:
                            entries.append([a, b, c, table[a][b][c]])
            return entries
        
        # Sort by the full flattened vector (including zeros) in a→b→c order
        def get_full_flat(table):
            flat = []
            for a in range(k_a):
                for b in range(k_b):
                    for c in range(k_c):
                        flat.append(table[a][b][c])
            return flat
        
        best_table = min(min_tables, key=lambda x: get_full_flat(x[1]))
        witness = get_nonzero_entries(best_table[1])
        
        results.append({
            "tables": num_tables,
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": witness
        })
    
    return results
