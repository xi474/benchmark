# Workflow 可观测性报告

- Trial：`MS28__vo9qHbV__env`
- Task：`MS28`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_8442b1d3de464be29fd09914 -> tool:dsh:lead:call_d4b73a9b018f4ec19304580b -> tool:dsh:lead:call_cfc58346cece4b68b2ab1c16 -> tool:dsh:lead:call_244683db80c342f5ae7bfba8 -> tool:dsh:lead:call_9c1f9c15172d4caaac18e3be -> tool:dsh:lead:call_31d4087af6d741f7a32bc201 -> tool:dsh:lead:call_9343240ec2784d01afd2bfaa -> tool:dsh:lead:call_b4a15d3efc224994a63fa8ac -> tool:dsh:lead:call_6d3672f9ac6b475fa33391b9 -> tool:dsh:lead:call_2b9bd98db66b4f49b8cd8873 -> tool:dsh:lead:call_d7b9a4b749b3444cb3a668e9 -> tool:dsh:lead:call_949586803d9646a8815c9d1a -> tool:dsh:lead:call_48f89daeaab64e3085c096a4 -> tool:dsh:lead:call_4c46b115968c4483b8f7e4b1 -> tool:dsh:lead:call_f445a17ff58b48a59e650b1b -> tool:dsh:lead:call_5c12cb0b5a944c239c40f01b -> tool:dsh:lead:call_3987a647a2e14063b54bb225 -> tool:dsh:lead:call_ebc97f3707ec4c85b1f63ca8 -> tool:dsh:lead:call_5b0958f4f4544493a7780b75 -> tool:dsh:lead:call_598ad254138a4156b9698084 -> tool:dsh:lead:call_f9c97ee0b9214d25a837aff6 -> tool:dsh:lead:call_01b5163831e541949f0cb98e -> tool:dsh:lead:call_d9af961f23c3498184d61d64 -> tool:dsh:lead:call_e17288909c7c4cffab0fc050 -> tool:dsh:lead:call_24b8fa0bbd144b13bc7061d7 -> tool:dsh:lead:call_32eb696c836e47398c1798b6 -> tool:dsh:lead:call_4c795ea9c9dd45b492e59f6e -> tool:dsh:lead:call_5fcb9e69f1974b5e9b17a01b -> tool:dsh:lead:call_18c65c2f77024b5e92961ffc -> tool:dsh:lead:call_b6f54e0f22494a598244d403
- 关键路径耗时：0.558
- Makespan：124.933
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
