def compute(payload):
    """为有截止日的作业返回 [需求,合格时段 ID 升序数组]，先按原始时段和七天半开窗口筛选。"""
    assignments = payload["assignments"]
    slots = payload["slots"]
    
    # Build slot lookup: slot_id -> (day, capacity)
    slot_map = {}
    for s in slots:
        slot_map[s[0]] = (s[1], s[2])
    
    result = {}
    for a in assignments:
        aid, due, demand, eligible = a[0], a[1], a[2], a[3]
        if due is None:
            continue
        # Filter eligible slots: must be in slot_map and due-7 <= day < due
        valid = []
        for sid in eligible:
            if sid in slot_map:
                day = slot_map[sid][0]
                if due - 7 <= day < due:
                    valid.append(sid)
        valid.sort()
        result[aid] = [demand, valid]
    
    return result
