def compute(payload):
    """每个撤回情景返回仍可用的时段映射，时段 ID 对应 [时刻,容量]。"""
    slots = payload["slots"]
    withdrawals = payload["withdrawals"]
    
    # Build slot lookup: slot_id -> [day, capacity]
    slot_map = {}
    for s in slots:
        slot_map[s[0]] = [s[1], s[2]]
    
    result = []
    for w in withdrawals:
        withdrawn = set(w)
        remaining = {}
        for sid, info in slot_map.items():
            if sid not in withdrawn:
                remaining[sid] = [info[0], info[1]]
        result.append(remaining)
    
    return result
