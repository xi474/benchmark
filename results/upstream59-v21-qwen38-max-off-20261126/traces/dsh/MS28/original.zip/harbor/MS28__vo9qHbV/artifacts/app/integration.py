from math import gcd
from itertools import combinations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: deadline_windows result - dict mapping assignment_id -> [demand, [valid_slot_ids]]
    right: remaining_slots result - list of dicts, each mapping slot_id -> [day, capacity]
    
    Returns a list of scenario results in withdrawal order.
    """
    # left = {aid: [demand, [slot_ids_sorted]]} for assignments with deadlines
    # right = [{slot_id: [day, cap]}, ...] per withdrawal scenario
    
    assignments_with_deadline = left  # only those with due dates
    
    results = []
    for scenario_slots in right:
        result = _solve_scenario(assignments_with_deadline, scenario_slots)
        results.append(result)
    
    return results


def _solve_scenario(deadline_assignments, available_slots):
    """Solve one withdrawal scenario.
    
    deadline_assignments: {aid: [demand, [valid_slot_ids]]}
    available_slots: {slot_id: [day, capacity]}
    """
    if not deadline_assignments:
        return {"empty": True}
    
    # Filter valid slots to only those still available after withdrawal
    # and re-check the slot exists in available_slots
    filtered = {}
    for aid, (demand, slot_ids) in deadline_assignments.items():
        valid = [s for s in slot_ids if s in available_slots]
        filtered[aid] = (demand, valid)
    
    # Check for unserved assignments (those with no valid slots)
    unserved = sorted(aid for aid, (demand, slots) in filtered.items() if not slots)
    if unserved:
        return {"unserved": unserved}
    
    # Build bipartite graph and find connected components
    # Nodes: assignment IDs and slot IDs
    # Edges: assignment -> slot if slot is in assignment's valid list
    
    # Union-Find for connected components
    parent = {}
    
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    
    def union(x, y):
        rx, ry = find(x), find(y)
        if rx != ry:
            parent[rx] = ry
    
    all_assignment_ids = list(filtered.keys())
    all_slot_ids = set()
    for aid, (demand, slots) in filtered.items():
        parent[aid] = aid
        for s in slots:
            if s not in parent:
                parent[s] = s
            all_slot_ids.add(s)
            union(aid, s)
    
    # Group assignments by connected component
    comp_assignments = {}
    for aid in all_assignment_ids:
        root = find(aid)
        if root not in comp_assignments:
            comp_assignments[root] = []
        comp_assignments[root].append(aid)
    
    # For each component, find peak load ratio and tight sets
    global_peak_num = 0
    global_peak_den = 1
    all_tight_sets = []
    
    for root, aids in comp_assignments.items():
        # Get all slots in this component
        comp_slots = set()
        for aid in aids:
            for s in filtered[aid][1]:
                comp_slots.add(s)
        
        # Build local data structures
        aid_to_idx = {aid: i for i, aid in enumerate(aids)}
        n = len(aids)
        
        demands = [filtered[aid][0] for aid in aids]
        # For each assignment, bitmask of slots it uses
        slot_list = sorted(comp_slots)
        slot_to_idx = {s: i for i, s in enumerate(slot_list)}
        m = len(slot_list)
        capacities = [available_slots[s][1] for s in slot_list]
        
        # For each assignment, compute slot bitmask
        aid_slot_masks = []
        for aid in aids:
            mask = 0
            for s in filtered[aid][1]:
                mask |= (1 << slot_to_idx[s])
            aid_slot_masks.append(mask)
        
        # Enumerate all non-empty subsets of assignments (up to 2^14)
        best_num = 0
        best_den = 1
        tight_sets = []
        
        for subset_mask in range(1, 1 << n):
            total_demand = 0
            slot_union_mask = 0
            for i in range(n):
                if subset_mask & (1 << i):
                    total_demand += demands[i]
                    slot_union_mask |= aid_slot_masks[i]
            
            total_cap = 0
            temp = slot_union_mask
            bit = 0
            while temp:
                if temp & 1:
                    total_cap += capacities[bit]
                temp >>= 1
                bit += 1
            
            # Compare total_demand / total_cap with best_num / best_den
            # total_demand * best_den vs best_num * total_cap
            lhs = total_demand * best_den
            rhs = best_num * total_cap
            
            if lhs > rhs:
                best_num = total_demand
                best_den = total_cap
                tight_sets = [subset_mask]
            elif lhs == rhs:
                tight_sets.append(subset_mask)
        
        # Update global peak
        # Compare best_num/best_den with global_peak_num/global_peak_den
        lhs = best_num * global_peak_den
        rhs = global_peak_num * best_den
        if lhs > rhs:
            global_peak_num = best_num
            global_peak_den = best_den
            all_tight_sets = [(aids, tight_sets)]
        elif lhs == rhs:
            all_tight_sets.append((aids, tight_sets))
    
    # Simplify peak fraction
    g = gcd(global_peak_num, global_peak_den)
    peak = [global_peak_num // g, global_peak_den // g]
    
    # Collect all tight sets as frozensets of assignment IDs
    all_tight_frozensets = []
    for aids, tight_masks in all_tight_sets:
        for mask in tight_masks:
            s = frozenset(aids[i] for i in range(len(aids)) if mask & (1 << i))
            all_tight_frozensets.append(s)
    
    # Deduplicate
    unique_tight = list(set(all_tight_frozensets))
    count = len(unique_tight)
    
    # Find minimal (inclusion-minimal) tight sets
    # Sort by size first for efficiency
    unique_tight.sort(key=lambda s: (len(s), sorted(s)))
    minimal = []
    for s in unique_tight:
        # Check if any already-added minimal set is a subset of s
        is_minimal = True
        for m in minimal:
            if m <= s:  # m is subset of s
                is_minimal = False
                break
        if is_minimal:
            minimal.append(s)
    
    # Format minimal: each member sorted, then sort by length then lexicographic
    minimal_formatted = [sorted(list(s)) for s in minimal]
    minimal_formatted.sort(key=lambda x: (len(x), x))
    
    # Compute implies
    # For each assignment appearing in at least one tight set,
    # list other assignments that appear in EVERY tight set containing it
    appears_in = {}  # aid -> list of tight set indices
    for idx, ts in enumerate(unique_tight):
        for aid in ts:
            if aid not in appears_in:
                appears_in[aid] = []
            appears_in[aid].append(idx)
    
    implies = []
    for aid in sorted(appears_in.keys()):
        indices = appears_in[aid]
        # Intersection of all tight sets containing aid, minus aid itself
        common = None
        for idx in indices:
            if common is None:
                common = set(unique_tight[idx])
            else:
                common &= unique_tight[idx]
        common.discard(aid)
        implies.append([aid, sorted(common)])
    
    return {
        "peak": peak,
        "count": count,
        "minimal": minimal_formatted,
        "implies": implies
    }
