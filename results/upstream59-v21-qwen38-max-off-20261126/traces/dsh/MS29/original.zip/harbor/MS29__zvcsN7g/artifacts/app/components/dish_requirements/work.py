from itertools import combinations


def compute(payload):
    """返回合格的三类菜品组合及合并需求，格式 [菜品 ID 数组,原料到数量映射]，按菜品字典序枚举。"""
    dishes = payload["dishes"]
    max_difficulty = payload["max_difficulty"]

    # Filter dishes by difficulty
    filtered = [(did, cat, diff, ingr) for did, cat, diff, ingr in dishes if diff <= max_difficulty]

    results = []

    # Find all combinations of exactly 3 dishes with different categories
    for combo in combinations(filtered, 3):
        cats = [c[1] for c in combo]
        if len(set(cats)) != 3:
            continue

        # Sort dish IDs alphabetically
        sorted_ids = sorted([c[0] for c in combo])

        # Merge ingredients (sum quantities of same-named ingredients)
        merged = {}
        for _, _, _, ingr in combo:
            for name, qty in ingr.items():
                merged[name] = merged.get(name, 0) + qty

        results.append([sorted_ids, merged])

    # Sort by the sorted dish ID triple lexicographically
    results.sort(key=lambda x: x[0])

    return results
