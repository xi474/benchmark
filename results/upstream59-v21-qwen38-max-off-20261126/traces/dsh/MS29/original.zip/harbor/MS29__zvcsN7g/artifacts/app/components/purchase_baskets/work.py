import itertools


def compute(payload):
    """输出所有限量采购篮 [总价,总件数,按排序后 offer 的购买数量向量]；按这三项升序排列。"""
    offers = payload["offers"]
    # Sort offers by offer_id alphabetically
    sorted_offers = sorted(offers, key=lambda o: o[0])

    prices = [o[2] for o in sorted_offers]
    max_packs_list = [o[3] for o in sorted_offers]

    # Enumerate all possible purchase baskets using itertools.product
    ranges = [range(mp + 1) for mp in max_packs_list]
    baskets = []
    for buy_vector in itertools.product(*ranges):
        total_cost = sum(p * b for p, b in zip(prices, buy_vector))
        total_packs = sum(buy_vector)
        baskets.append([total_cost, total_packs, list(buy_vector)])

    # Sort by (total_cost asc, total_packs asc, buy_vector lexicographic asc)
    baskets.sort(key=lambda b: (b[0], b[1], b[2]))

    return baskets
