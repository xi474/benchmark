def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    stock = payload.get("stock", {})
    offers_raw = payload.get("offers", [])
    prep_raw = payload.get("prep", [])

    # Sort offers by ID for consistent indexing
    sorted_offers = sorted(offers_raw, key=lambda o: o[0])
    offer_materials = [o[1] for o in sorted_offers]
    n_offers = len(sorted_offers)

    # Parse prep steps, sort by ID for tiebreaking on step sequence
    prep_steps = []
    for p in prep_raw:
        prep_steps.append((p[0], dict(p[1]), dict(p[2]), p[3]))
    prep_steps.sort(key=lambda x: x[0])
    n_prep = len(prep_steps)

    results = []
    for dish_ids, need in left:
        need = dict(need)
        best_plan = _find_best_plan(
            stock, need, offer_materials, n_offers,
            prep_steps, n_prep, right
        )
        results.append({"dishes": dish_ids, "plan": best_plan})

    return results


def _has(inv, mats):
    """Check if inventory satisfies material requirements."""
    for m, q in mats.items():
        if inv.get(m, 0) < q:
            return False
    return True


def _apply(inv, consumes, produces):
    """Subtract consumes then add produces. Returns new dict or None."""
    result = dict(inv)
    for m, q in consumes.items():
        cur = result.get(m, 0)
        if cur < q:
            return None
        result[m] = cur - q
    for m, q in produces.items():
        result[m] = result.get(m, 0) + q
    return result


def _clean(inv):
    """Remove non-positive entries."""
    return {k: v for k, v in inv.items() if v > 0}


def _inv_key(inv):
    """Hashable key for an inventory state."""
    return tuple(sorted((k, v) for k, v in inv.items() if v > 0))


def _find_best_plan(stock, need, offer_materials, n_offers,
                     prep_steps, n_prep, baskets):
    """Find optimal plan for one dish combination."""
    best_key = None  # (cost, packs, buy_tuple, total_steps, step_seq_tuple)
    best_plan = None

    for basket in baskets:
        b_cost, b_packs, b_buy = basket[0], basket[1], basket[2]

        # Prune: baskets are sorted by cost first; if cost exceeds best, done
        if best_key is not None and b_cost > best_key[0]:
            break

        # Compute inventory after purchase
        inv = dict(stock)
        for i in range(n_offers):
            if b_buy[i] > 0:
                for m, q in offer_materials[i].items():
                    inv[m] = inv.get(m, 0) + q * b_buy[i]

        # Search for feasible prep sequence
        max_step_bound = 16
        if best_key is not None:
            # Only accept solutions with fewer steps, or same steps with lex-smaller seq
            max_step_bound = min(16, best_key[3])

        result = _search_prep_bfs(inv, need, prep_steps, n_prep, max_step_bound, best_key)
        if result is None:
            continue

        total_steps, step_seq, final_inv = result

        # Compute leftover after delivering need
        leftover = dict(final_inv)
        for m, q in need.items():
            leftover[m] = leftover.get(m, 0) - q
        left_clean = _clean(leftover)

        cand_key = (b_cost, b_packs, tuple(b_buy), total_steps, tuple(step_seq))
        if best_key is None or cand_key < best_key:
            best_key = cand_key
            best_plan = {
                "cost": b_cost,
                "buy": list(b_buy),
                "steps": list(step_seq),
                "left": left_clean
            }

    return best_plan


def _search_prep_bfs(inv, need, prep_steps, n_prep, max_steps, best_key):
    """BFS layer-by-layer to find optimal prep sequence.
    
    Returns (total_steps, step_seq_list, final_inv) or None.
    Minimizes total_steps first, then step_seq lexicographically.
    """
    if _has(inv, need):
        return (0, [], inv)

    if max_steps <= 0:
        return None

    # State: (inv_key, exec_counts_tuple)
    # For each state, keep only the lexicographically smallest step_seq reaching it
    initial_exec = tuple([0] * n_prep)
    initial_key = (_inv_key(inv), initial_exec)
    current = {initial_key: (dict(inv), [])}

    for step_num in range(1, max_steps + 1):
        next_layer = {}
        solutions = []  # collect all solutions found at this step count

        for (ik, ec), (state_inv, state_seq) in current.items():
            for pi in range(n_prep):
                pid, consumes, produces, max_exec = prep_steps[pi]

                if ec[pi] >= max_exec:
                    continue
                if not _has(state_inv, consumes):
                    continue

                new_inv = _apply(state_inv, consumes, produces)
                if new_inv is None:
                    continue

                new_ec_list = list(ec)
                new_ec_list[pi] += 1
                new_ec = tuple(new_ec_list)
                new_seq = state_seq + [pid]

                if _has(new_inv, need):
                    # Valid solution at this step count
                    # Check against best_key for step_seq tiebreaking
                    if best_key is not None and step_num == best_key[3]:
                        if tuple(new_seq) >= best_key[4]:
                            continue
                    solutions.append((new_seq, new_inv))
                    continue

                new_key = (_inv_key(new_inv), new_ec)
                if new_key in next_layer:
                    if new_seq >= next_layer[new_key][1]:
                        continue
                next_layer[new_key] = (new_inv, new_seq)

        if solutions:
            # Pick lex-smallest step sequence
            best_sol = min(solutions, key=lambda s: s[0])
            return (step_num, best_sol[0], best_sol[1])

        if not next_layer:
            break

        current = next_layer

    return None
