# Workflow 可观测性报告

- Trial：`MS30__rNrEDq8__env`
- Task：`MS30`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（49 节点 / 48 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：49；执行边：48（observed=0，inferred=48）
- Execution Trace Graph：`observed`；temporal_next 边 48，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_592ab00f04b8457b92ff21fe -> tool:dsh:lead:call_3d76e5c4ee7d4d0b8c3e886e -> tool:dsh:lead:call_265fd53630c44e4aac36c043 -> tool:dsh:lead:call_72c588d1b95b4b7eba904793 -> tool:dsh:lead:call_8ac324a917f44960bccb6eb8 -> tool:dsh:lead:call_557456e774b54d5ba2d99e10 -> tool:dsh:lead:call_d041dc0b333441308e488ed6 -> tool:dsh:lead:call_55280acdafdf4324b34ed450 -> tool:dsh:lead:call_154e377710704f1697cd5490 -> tool:dsh:lead:call_e5a039061a444a15abe48a6c -> tool:dsh:lead:call_5dd9dabe3d0b4e16bb6fca91 -> tool:dsh:lead:call_1583fd8d992846228a603c0f -> tool:dsh:lead:call_07dcd340932b4df0a4fab1d6 -> tool:dsh:lead:call_af9bff655f7c4edd931a8db3 -> tool:dsh:lead:call_05aea2b1679f4f8a9653760d -> tool:dsh:lead:call_870e31452db041ca89f8904c -> tool:dsh:lead:call_cc7b3dbd12af49148c54027b -> tool:dsh:lead:call_e5d36d21e747465c93b0fd8c -> tool:dsh:lead:call_002afa8d1ac84da68a93bd9e -> tool:dsh:lead:call_f3a6b1a8670f409795db50c0 -> tool:dsh:lead:call_90ab73e9b5c64748895c724d -> tool:dsh:lead:call_ff68956ae23f4c9e96b8b3c7 -> tool:dsh:lead:call_b7a4e38dcb014360bfe8b334 -> tool:dsh:lead:call_e38a3ac091be45f890c0822b -> tool:dsh:lead:call_b16caf98d516446d98a84ad7 -> tool:dsh:lead:call_7587c515ddef43bfb4c2dc9b -> tool:dsh:lead:call_738de492540e481abc46c12a -> tool:dsh:lead:call_e51b0bd1caba44a5bdf7a14c -> tool:dsh:lead:call_61764b45b42c4012b8c8dd8c -> tool:dsh:lead:call_0330aa38c8c8433baecf8bbe -> tool:dsh:lead:call_64b8ba9548db4d6fa26d7b1e -> tool:dsh:lead:call_d119f1e1351f4e25a86b664a -> tool:dsh:lead:call_5b1fda763bb1476e83125535 -> tool:dsh:lead:call_db74992b4075434793c50e75 -> tool:dsh:lead:call_2cba95ad70a247c1b3679ee5 -> tool:dsh:lead:call_db9919e40ebc48f191bf90e2 -> tool:dsh:lead:call_c8f48e971c194d75b2bd3fe7 -> tool:dsh:lead:call_916631dd0f0c4917a6844d6e -> tool:dsh:lead:call_892f268ffa1e4e9aa1b2983a -> tool:dsh:lead:call_a235e8ae6ce64fea8b3cc89f -> tool:dsh:lead:call_2fc816c45d95431a99c90069 -> tool:dsh:lead:call_d0613b2b0804406e84856b69 -> tool:dsh:lead:call_8ff56fa7a99d409e9a1db885 -> tool:dsh:lead:call_f790878e295b434996965be3 -> tool:dsh:lead:call_730d201dc5e0447499cb0ff5 -> tool:dsh:lead:call_d0db2718265a4f2ebf5ad07d -> tool:dsh:lead:call_acdc3ea2f52d4468999257d0 -> tool:dsh:lead:call_a390f41f3b074506b6175c41
- 关键路径耗时：1.868
- Makespan：214.323
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
