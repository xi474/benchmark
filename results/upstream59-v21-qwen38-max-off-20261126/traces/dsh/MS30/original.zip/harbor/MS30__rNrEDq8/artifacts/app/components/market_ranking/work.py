from fractions import Fraction


def compute(payload):
    """按最新市场日的 30 天窗口、相对绝对涨跌幅和代号打破平局，返回前 top 个房间代号（保持排名）。"""
    market = payload["market"]
    top = payload["top"]

    # Find last teaching day L
    L = max(row[1] for row in market)

    # Filter events in [L-29, L]
    window_events = [row for row in market if L - 29 <= row[1] <= L]

    # Compute abs(close - open) / open for each event
    scored = []
    for row in window_events:
        event_id = row[0]
        open_price = row[2]
        close_price = row[3]
        ratio = Fraction(abs(close_price - open_price), open_price)
        scored.append((ratio, event_id))

    # Sort by ratio descending, then event_id ascending
    scored.sort(key=lambda x: (-x[0], x[1]))

    # Take top N
    result = [item[1] for item in scored[:top]]
    return result
