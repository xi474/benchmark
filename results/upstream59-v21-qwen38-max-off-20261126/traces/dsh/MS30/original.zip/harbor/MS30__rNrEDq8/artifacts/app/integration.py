"""Integration: combine student_tiers and market_ranking into final stable-matching result."""

from itertools import product


def combine(payload, student_tiers_value, market_ranking_value):
    """Combine the two component JSON values under the business contract in TASK.md."""
    rooms = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]

    # student_tiers_value: dict student -> tier (P/D/N)
    # market_ranking_value: list of event IDs in ranking order (top workshops)

    open_workshops_set = set(market_ranking_value)  # workshops that exist (from market ranking)

    results = []
    for cancelled in cancel_list:
        cancelled_set = set(cancelled)
        # Open workshops = those in market ranking AND not cancelled
        available = [w for w in market_ranking_value if w not in cancelled_set]
        available_set = set(available)

        # Build acceptability and preferences
        # Students who have at least one valid score (already in student_tiers_value)
        all_students = sorted(student_tiers_value.keys())

        # For each student, build preference ordering over available workshops
        # prefs[student] = list of groups (high to low), each group is list of workshop IDs (unordered within)
        student_prefs = {}
        for s in all_students:
            if s not in prefs:
                student_prefs[s] = []
                continue
            groups = []
            for group in prefs[s]:
                filtered = [w for w in group if w in available_set]
                if filtered:
                    groups.append(set(filtered))
            student_prefs[s] = groups

        # For each available workshop, build tier-based preference over students
        # room tiers: list of groups from priority to secondary, each group is list of tiers (unordered)
        workshop_info = {}
        for w in available:
            info = rooms[w]
            cap = info["capacity"]
            tier_groups = info["tiers"]  # e.g. [["P"], ["D","N"]]
            # Map tier -> priority rank (lower = better)
            tier_rank = {}
            for rank, group in enumerate(tier_groups):
                for t in group:
                    tier_rank[t] = rank
            workshop_info[w] = {"capacity": cap, "tier_rank": tier_rank}

        # Determine mutual acceptability
        # Student s finds workshop w acceptable iff w appears in student_prefs[s]
        # Workshop w finds student s acceptable iff s's tier is in w's tier_rank
        def student_accepts(s, w):
            for group in student_prefs[s]:
                if w in group:
                    return True
            return False

        def workshop_accepts(w, s):
            tier = student_tiers_value[s]
            return tier in workshop_info[w]["tier_rank"]

        def mutually_acceptable(s, w):
            return student_accepts(s, w) and workshop_accepts(w, s)

        # Student preference comparison: does s strictly prefer w1 over w2?
        # w2 can be None (unassigned). Unassigned is worse than any acceptable workshop.
        def student_strictly_prefers(s, w1, w2):
            """Does s strictly prefer w1 over w2? w2=None means unassigned."""
            if w2 is None:
                # s prefers any acceptable workshop over being unassigned
                return student_accepts(s, w1)
            if w1 == w2:
                return False
            # Find which group each belongs to
            rank1 = None
            rank2 = None
            for i, group in enumerate(student_prefs[s]):
                if w1 in group:
                    rank1 = i
                if w2 in group:
                    rank2 = i
            if rank1 is None:
                return False  # w1 not acceptable
            if rank2 is None:
                return True   # w2 not acceptable but w1 is
            return rank1 < rank2  # lower rank = higher preference

        # Workshop preference comparison: does w strictly prefer s1 over s2?
        def workshop_strictly_prefers(w, s1, s2):
            """Does w strictly prefer s1 over s2?"""
            tier1 = student_tiers_value[s1]
            tier2 = student_tiers_value[s2]
            r1 = workshop_info[w]["tier_rank"].get(tier1)
            r2 = workshop_info[w]["tier_rank"].get(tier2)
            if r1 is None:
                return False
            if r2 is None:
                return True
            return r1 < r2

        # Enumerate all weakly stable matchings
        # Each student can be assigned to an acceptable workshop or unassigned
        # Constraints: capacity, mutual acceptability, stability

        # Build list of options per student
        student_options = {}
        for s in all_students:
            opts = [None]  # None = unassigned
            for w in available:
                if mutually_acceptable(s, w):
                    opts.append(w)
            student_options[s] = opts

        # For small instances (≤8 students per component, ≤5 options each),
        # enumerate via backtracking with pruning

        # First find connected components of the bipartite graph
        # Students and workshops connected by mutual acceptability
        adj_s = {s: set() for s in all_students}
        adj_w = {w: set() for w in available}
        for s in all_students:
            for w in available:
                if mutually_acceptable(s, w):
                    adj_s[s].add(w)
                    adj_w[w].add(s)

        # Find connected components using BFS on the bipartite graph
        visited_s = set()
        visited_w = set()
        components = []

        for s_start in all_students:
            if s_start in visited_s:
                continue
            if not adj_s[s_start]:
                # Isolated student, no acceptable workshops
                components.append(([s_start], []))
                visited_s.add(s_start)
                continue
            comp_s = []
            comp_w_set = set()
            queue_s = [s_start]
            visited_s.add(s_start)
            w_queue = []
            while queue_s or w_queue:
                while queue_s:
                    s = queue_s.pop()
                    comp_s.append(s)
                    for w in adj_s[s]:
                        if w not in visited_w:
                            visited_w.add(w)
                            comp_w_set.add(w)
                            w_queue.append(w)
                while w_queue:
                    w = w_queue.pop()
                    for s in adj_w[w]:
                        if s not in visited_s:
                            visited_s.add(s)
                            queue_s.append(s)
            components.append((sorted(comp_s), sorted(comp_w_set)))

        # Also handle isolated workshops (no acceptable students) - they don't affect matching

        # For each component, enumerate all stable matchings
        # Then combine across components

        def enumerate_stable_matchings(comp_students, comp_workshops):
            """Enumerate all weakly stable matchings for a component."""
            if not comp_students:
                return [{}]

            n = len(comp_students)
            s_idx = {s: i for i, s in enumerate(comp_students)}

            # Options per student (within this component)
            opts = []
            for s in comp_students:
                o = [None]
                for w in comp_workshops:
                    if mutually_acceptable(s, w):
                        o.append(w)
                opts.append(o)

            capacities = {w: workshop_info[w]["capacity"] for w in comp_workshops}

            stable_matchings = []

            def is_stable(assignment):
                """Check if assignment is weakly stable. assignment is dict s->w or None."""
                # Count occupancy
                occ = {w: [] for w in comp_workshops}
                for s in comp_students:
                    w = assignment[s]
                    if w is not None:
                        occ[w].append(s)

                # Check for blocking pairs
                for s in comp_students:
                    cur = assignment[s]
                    for w in comp_workshops:
                        if not mutually_acceptable(s, w):
                            continue
                        if w == cur:
                            continue
                        # Does s strictly prefer w over cur?
                        if not student_strictly_prefers(s, w, cur):
                            continue
                        # Does w have empty seat or strictly prefer s over someone?
                        if len(occ[w]) < capacities[w]:
                            return False  # blocking pair
                        # Check if w strictly prefers s over any current member
                        for s2 in occ[w]:
                            if workshop_strictly_prefers(w, s, s2):
                                return False  # blocking pair
                return True

            # Backtracking enumeration
            assignment = [None] * n
            occ_count = {w: 0 for w in comp_workshops}

            def backtrack(i):
                if i == n:
                    adict = {comp_students[j]: assignment[j] for j in range(n)}
                    if is_stable(adict):
                        stable_matchings.append(dict(adict))
                    return
                s = comp_students[i]
                for w in opts[i]:
                    if w is None:
                        assignment[i] = None
                        backtrack(i + 1)
                    else:
                        if occ_count[w] < capacities[w]:
                            assignment[i] = w
                            occ_count[w] += 1
                            backtrack(i + 1)
                            occ_count[w] -= 1

            backtrack(0)
            return stable_matchings

        # Process each component
        all_component_matchings = []
        for comp_s, comp_w in components:
            matchings = enumerate_stable_matchings(comp_s, comp_w)
            all_component_matchings.append((comp_s, matchings))

        # Combine matchings across components
        # Each full matching is a combination of one matching per component
        # We need to track: total assigned count, and the full assignment vector

        # Build combined matchings
        # Start with empty assignment for all students
        full_matchings = [{}]
        for comp_s, matchings in all_component_matchings:
            new_full = []
            for existing in full_matchings:
                for m in matchings:
                    combined = dict(existing)
                    combined.update(m)
                    new_full.append(combined)
            full_matchings = new_full

        # Now compute sizes, forced, example
        # sizes: [assigned_count, num_matchings_with_that_count], sorted by count asc
        from collections import Counter
        count_counter = Counter()
        max_assigned = 0
        max_matchings = []

        for m in full_matchings:
            assigned = sum(1 for s in all_students if m.get(s) is not None)
            count_counter[assigned] += 1
            if assigned > max_assigned:
                max_assigned = assigned
                max_matchings = [m]
            elif assigned == max_assigned:
                max_matchings.append(m)

        sizes = sorted([[count, num] for count, num in count_counter.items()], key=lambda x: x[0])

        # forced: pairs (student, workshop) that appear in ALL max-size matchings
        forced = []
        if max_matchings:
            for s in all_students:
                vals = set(m.get(s) for m in max_matchings)
                if len(vals) == 1:
                    v = vals.pop()
                    if v is not None:
                        forced.append([s, v])
        forced.sort()

        # example: among max-size matchings, lex-smallest vector of assignments
        # sorted by student ID ascending, unassigned = ""
        def make_vector(m):
            return tuple(m.get(s, "") or "" for s in all_students)

        vectors = [make_vector(m) for m in max_matchings]
        vectors.sort()
        example = list(vectors[0]) if vectors else []

        results.append({
            "sizes": sizes,
            "forced": forced,
            "example": example
        })

    return results
