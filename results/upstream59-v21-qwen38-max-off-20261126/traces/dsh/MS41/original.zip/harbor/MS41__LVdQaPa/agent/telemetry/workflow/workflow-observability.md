# Workflow 可观测性报告

- Trial：`MS41__LVdQaPa__env`
- Task：`MS41`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_3b2181585fb04cf9a2ff078d -> tool:dsh:lead:call_ada95658bdba4993a44778a9 -> tool:dsh:lead:call_3ffbe20da2424fd79f59665c -> tool:dsh:lead:call_053a6f5549b14f2f849b77a2 -> tool:dsh:lead:call_b6553ba11d7547ee97fbcb6a -> tool:dsh:lead:call_68cafaecf7104ccb914f5a7e -> tool:dsh:lead:call_49c476b276b542bbbecd07d8 -> tool:dsh:lead:call_8679fe324b8a4f37881c9a58 -> tool:dsh:lead:call_d1c858d13eb84f14837751ba -> tool:dsh:lead:call_50fd5ac4edcc456fbb753198 -> tool:dsh:lead:call_26b774f2ab1d454cb2a1811d -> tool:dsh:lead:call_c5a3216c33ea4f3ea81b70db -> tool:dsh:lead:call_233d897daade4a858b8b6578 -> tool:dsh:lead:call_d829122eaec4446289b9eb6b -> tool:dsh:lead:call_e84e56f6a914463186607ee7 -> tool:dsh:lead:call_8f2afdd65fb2496996631cc7 -> tool:dsh:lead:call_d110a5cd2b444c28a7ca79cc -> tool:dsh:lead:call_759b1a1b04f44bd9800a032b -> tool:dsh:lead:call_14ade7fb577244cb8d8f16bf -> tool:dsh:lead:call_8d5f13a28dde4e829c07c667 -> tool:dsh:lead:call_680c3a6deb104fe8b7888222 -> tool:dsh:lead:call_1c237e2094a349e68c27b2d1 -> tool:dsh:lead:call_cf66162bcfc4476ba2d155a0 -> tool:dsh:lead:call_5235a21b2c4b4972bf80ba57 -> tool:dsh:lead:call_aa8328e744714f4d81126606 -> tool:dsh:lead:call_1b52055ca9b24d00a7e932dd -> tool:dsh:lead:call_097d94cd9216418da39059eb -> tool:dsh:lead:call_ede0d0461fc24b96bd09493a -> tool:dsh:lead:call_efc25cca8e5d4f2ab17c7882 -> tool:dsh:lead:call_789a169bf19e4a8592614cfe -> tool:dsh:lead:call_ad83e4d86f2e410b8734a4ab -> tool:dsh:lead:call_d1ede83eecd4485ebd535efd
- 关键路径耗时：0.76
- Makespan：210.396
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
