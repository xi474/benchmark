from math import gcd
from fractions import Fraction


def _reduce(n, d):
    if n == 0:
        return [0, 1]
    g = gcd(abs(n), abs(d))
    return [n // g, d // g]


def compute(payload):
    """按 method ID、profile 名输出 [各答案吸收概率,各答案加权成本质量]。"""
    answers = payload["answers"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    na = len(answers)
    answer_set = set(answers)

    result = {}
    for method in methods:
        mid = method["id"]
        start = method["start"]
        graphs = method["graphs"]
        result[mid] = {}

        for pname in profiles:
            graph = graphs[pname]
            # Collect all non-terminal states
            states = list(graph.keys())
            state_idx = {s: i for i, s in enumerate(states)}
            ns = len(states)

            # For each non-terminal state, compute transition probabilities and costs
            # We need: for starting from `start`, what's P(absorb at answer a) and E[cost * I(absorb at a)]?
            # Use system of linear equations with Fractions for exact arithmetic.

            # Let p[s][a] = P(absorb at answer a | currently at state s)
            # Let c[s][a] = E[total remaining cost * I(absorb at a) | currently at state s]
            #
            # For state s with edges [(target, weight, cost), ...]:
            #   total_w = sum of weights
            #   p[s][a] = sum over edges: (w/total_w) * (p[target][a] if target is state else (1 if target==a else 0))
            #   c[s][a] = sum over edges: (w/total_w) * (cost * (p[target][a] if target is state else I(target==a)) + c[target][a] if target is state else 0)
            #
            # Rearranging for linear system:
            # For p: p[s][a] - sum_{edges to states t} (w/total_w)*p[t][a] = sum_{edges to answer a} (w/total_w)
            # For c: c[s][a] - sum_{edges to states t} (w/total_w)*c[t][a] = sum_{all edges} (w/total_w)*cost*p_contribution
            #   where p_contribution for edge (target, w, cost):
            #     if target is state: p[target][a]
            #     if target is answer: I(target==a)

            # First solve for p[s][a] for all s, a
            # Then solve for c[s][a] using known p values

            # Build coefficient matrix for p
            # For each answer a separately:
            # (I - Q) * p_a = b_a where Q[s][t] = prob(s->t) for states s,t

            # Using Fraction for exact arithmetic
            def solve_absorption():
                # Transition probs: trans[s] = [(target_state_or_answer, prob_fraction, cost)]
                trans = []
                for s in states:
                    edges = graph[s]
                    total_w = sum(e[1] for e in edges)
                    row = []
                    for target, w, cost in edges:
                        row.append((target, Fraction(w, total_w), cost))
                    trans.append(row)

                # Solve for absorption probabilities p[s][a]
                # p_vals[s][a] as Fraction
                p_vals = [[Fraction(0)] * na for _ in range(ns)]

                for ai, ans in enumerate(answers):
                    # Build (I - Q) x = b
                    # Matrix A = I - Q, size ns x ns
                    # b[s] = sum of prob(s -> ans directly)
                    A = [[Fraction(0)] * ns for _ in range(ns)]
                    b = [Fraction(0)] * ns
                    for si in range(ns):
                        A[si][si] = Fraction(1)
                        for target, prob, cost in trans[si]:
                            if target in state_idx:
                                ti = state_idx[target]
                                A[si][ti] -= prob
                            elif target == ans:
                                b[si] += prob

                    # Gaussian elimination
                    x = _solve_linear(A, b, ns)
                    for si in range(ns):
                        p_vals[si][ai] = x[si]

                # Solve for cost-quality c[s][a] = E[remaining cost * I(absorb at a) | at s]
                c_vals = [[Fraction(0)] * na for _ in range(ns)]

                for ai, ans in enumerate(answers):
                    A = [[Fraction(0)] * ns for _ in range(ns)]
                    b = [Fraction(0)] * ns
                    for si in range(ns):
                        A[si][si] = Fraction(1)
                        for target, prob, cost in trans[si]:
                            if target in state_idx:
                                ti = state_idx[target]
                                A[si][ti] -= prob
                                b[si] += prob * cost * p_vals[ti][ai]
                            elif target == ans:
                                b[si] += prob * cost * Fraction(1)
                            # if target is another answer, contributes 0 to c[s][ans]

                    x = _solve_linear(A, b, ns)
                    for si in range(ns):
                        c_vals[si][ai] = x[si]

                return p_vals, c_vals

            p_vals, c_vals = solve_absorption()
            start_idx = state_idx[start]

            # Extract results for start state
            abs_probs = [_reduce(p_vals[start_idx][ai].numerator, p_vals[start_idx][ai].denominator) for ai in range(na)]
            cost_quals = [_reduce(c_vals[start_idx][ai].numerator, c_vals[start_idx][ai].denominator) for ai in range(na)]

            result[mid][pname] = [abs_probs, cost_quals]

    return result


def _solve_linear(A, b, n):
    """Solve Ax = b using Gaussian elimination with Fractions. Returns x."""
    # Augmented matrix
    M = [row[:] + [b[i]] for i, row in enumerate(A)]

    for col in range(n):
        # Find pivot
        pivot_row = None
        for row in range(col, n):
            if M[row][col] != 0:
                pivot_row = row
                break
        if pivot_row is None:
            continue
        M[col], M[pivot_row] = M[pivot_row], M[col]
        piv = M[col][col]
        for j in range(col, n + 1):
            M[col][j] /= piv
        for row in range(n):
            if row != col and M[row][col] != 0:
                factor = M[row][col]
                for j in range(col, n + 1):
                    M[row][j] -= factor * M[col][j]

    return [M[i][n] for i in range(n)]
