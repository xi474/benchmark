from math import gcd
from collections import deque


def _reduce(n, d):
    """Return [n, d] in lowest terms with d > 0."""
    if n == 0:
        return [0, 1]
    g = gcd(abs(n), abs(d))
    return [n // g, d // g]


def compute(payload):
    """输出 [先验映射,方法提前决胜表]。"""
    answers = payload["answers"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    na = len(answers)

    # --- Prior mapping: profile_name -> [numerator, denominator] as simplest fraction ---
    total_weight = sum(profiles.values())
    prior = {}
    for pname, w in profiles.items():
        prior[pname] = _reduce(w, total_weight)

    # --- Early-decision tables per method ---
    decision_tables = {}
    for method in methods:
        votes = method["votes"]
        table = {}
        # BFS from zero-count state
        start_state = tuple([0] * na)
        queue = deque()
        queue.append(start_state)
        table[start_state] = None  # will be filled below

        def is_decided(counts):
            """Check if current leader is guaranteed to win regardless of remaining votes."""
            total_cast = sum(counts)
            remaining = votes - total_cast
            if remaining < 0:
                return False, -1
            # Current leader: max count, tie-break by answer index (lower index wins)
            best_idx = 0
            best_count = counts[0]
            for i in range(1, na):
                if counts[i] > best_count:
                    best_count = counts[i]
                    best_idx = i
            # Check: can any other answer beat or tie the leader?
            # "当前领先者也仍能获胜" means leader strictly wins even in worst case
            # Actually re-reading: "如果即使余下每一票都投给任一同一个竞争者，当前领先者也仍能获胜"
            # If all remaining votes go to ANY SINGLE competitor, leader still wins.
            # Leader wins means: leader's count > competitor's count (with tie-break by index)
            # Wait - tie-break: "票数相同取 answers 顺序在前者"
            # So leader wins if: for every competitor j != best_idx,
            #   even if all remaining go to j: counts[j] + remaining < best_count
            #   OR (counts[j] + remaining == best_count AND best_idx < j)
            # Actually "仍能获胜" = still can win = is guaranteed to be the winner
            # With tie-break, leader at index best_idx wins ties against higher indices
            # but loses ties against lower indices. But best_idx already has highest count
            # (or tied with lower indices which would make them the leader instead).
            # Since best_idx is chosen as the lowest index with max count,
            # no lower index has more. So for any j != best_idx:
            #   if j < best_idx: counts[j] <= best_count, needs counts[j]+remaining < best_count
            #     (because if tied, j wins tie-break)
            #   if j > best_idx: counts[j] <= best_count, needs counts[j]+remaining <= best_count
            #     (because if tied, best_idx wins tie-break)
            for j in range(na):
                if j == best_idx:
                    continue
                worst = counts[j] + remaining
                if j < best_idx:
                    # j wins ties, so leader needs strict lead
                    if worst >= best_count:
                        return False, -1
                else:
                    # leader wins ties
                    if worst > best_count:
                        return False, -1
            return True, best_idx

        # Process BFS
        visited = set()
        visited.add(start_state)
        # Re-do with proper BFS
        table = {}
        queue = deque([start_state])
        while queue:
            state = queue.popleft()
            decided, winner = is_decided(state)
            if decided:
                table[state] = winner
                continue  # Don't expand decided states
            table[state] = None
            total_cast = sum(state)
            if total_cast >= votes:
                # No more votes possible but not decided - shouldn't happen
                # Actually if total_cast == votes and not decided, it means
                # there's a true tie that can't be broken? No - is_decided handles this.
                # If remaining=0 and not decided... that means two answers have same count
                # and the lower-index one should win. Let me re-check is_decided.
                # With remaining=0: for j < best_idx, need counts[j] < best_count (strict)
                # For j > best_idx, need counts[j] <= best_count.
                # Since best_idx has max count and lowest index among max,
                # all j < best_idx have counts[j] < best_count (otherwise they'd be leader).
                # All j > best_idx have counts[j] <= best_count.
                # So is_decided should always return True when remaining=0.
                # This branch shouldn't be reached.
                continue
            # Expand: add one vote to each answer
            for i in range(na):
                new_state = list(state)
                new_state[i] += 1
                new_state = tuple(new_state)
                if new_state not in visited:
                    visited.add(new_state)
                    queue.append(new_state)

        # Convert keys to comma-separated strings
        str_table = {}
        for state, winner in table.items():
            key = ",".join(str(c) for c in state)
            str_table[key] = winner

        decision_tables[method["id"]] = str_table

    return [prior, decision_tables]
