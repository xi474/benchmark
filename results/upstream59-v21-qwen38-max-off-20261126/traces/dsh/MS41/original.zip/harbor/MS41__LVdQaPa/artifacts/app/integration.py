from math import gcd
from fractions import Fraction


def _reduce(n, d):
    if n == 0:
        return [0, 1]
    g = gcd(abs(n), abs(d))
    return [n // g, d // g]


def combine(payload, left, right):
    """Combine ballot_rules and answer_absorption results into final output."""
    answers = payload["answers"]
    correct = payload["correct"]
    profiles = payload["profiles"]
    methods = payload["methods"]
    na = len(answers)
    correct_idx = answers.index(correct)

    prior_map = left[0]       # {profile_name: [num, den]}
    decision_tables = left[1] # {method_id: {state_str: winner_idx_or_null}}
    absorption = right         # {method_id: {profile_name: [abs_probs, cost_quals]}}

    results = []

    for method in methods:
        mid = method["id"]
        max_votes = method["votes"]
        dt = decision_tables[mid]

        # For each profile, compute the sequential voting DP
        # We'll accumulate weighted results across profiles

        # Result accumulators (as Fractions)
        total_prob = [Fraction(0)] * na      # P(winner = a)
        total_unresolved = Fraction(0)        # P(unresolved)
        total_launches = Fraction(0)          # E[launches]
        total_cost_correct = Fraction(0)      # E[total_cost * I(correct)]
        total_prob_correct = Fraction(0)      # P(correct)

        for pname, pweight_raw in profiles.items():
            pw = Fraction(prior_map[pname][0], prior_map[pname][1])
            abs_data = absorption[mid][pname]
            abs_probs_raw = abs_data[0]  # [[num,den], ...] per answer
            cost_quals_raw = abs_data[1]  # [[num,den], ...] per answer

            abs_probs = [Fraction(ap[0], ap[1]) for ap in abs_probs_raw]
            cost_quals = [Fraction(cq[0], cq[1]) for cq in cost_quals_raw]

            p_term = sum(abs_probs)  # P(vote terminates)
            p_unres = Fraction(1) - p_term  # P(vote never terminates)

            # DP over count states
            # State: tuple of counts
            # Value: dict with keys 'prob', 'launches_contrib', 'cost_correct_contrib'
            # Actually we need to track multiple quantities simultaneously

            # For each reachable undecided state, compute:
            # - prob_reach[s]: probability of reaching this state (given this profile)
            # Then from each state, we either:
            #   - Are decided (from decision table) → contribute to winner prob
            #   - Launch another vote → branch

            # Use iterative approach: process states in order of total votes cast
            # Start state
            start_state = tuple([0] * na)

            # prob_reach[state] = Fraction: probability of being at this state
            prob_reach = {start_state: Fraction(1)}

            # Accumulate results for this profile
            prof_prob = [Fraction(0)] * na
            prof_unresolved = Fraction(0)
            prof_launches = Fraction(0)
            prof_cost_correct = Fraction(0)

            # Process states level by level (by total votes cast)
            for votes_cast in range(max_votes):
                new_prob_reach = {}
                for state, pr in prob_reach.items():
                    if pr == 0:
                        continue
                    # Check if this state is decided
                    state_key = ",".join(str(c) for c in state)
                    winner = dt.get(state_key)
                    if winner is not None:
                        # Already decided, shouldn't be in prob_reach for expansion
                        # (we should have caught this earlier)
                        prof_prob[winner] += pr
                        continue

                    # Launch a vote (increment launch count)
                    prof_launches += pr  # Each visit launches one vote

                    # Outcomes of this vote:
                    # 1. Unresolved
                    if p_unres > 0:
                        prof_unresolved += pr * p_unres

                    # 2. Terminates at answer a
                    for ai in range(na):
                        if abs_probs[ai] == 0:
                            continue
                        new_state = list(state)
                        new_state[ai] += 1
                        new_state = tuple(new_state)
                        contrib = pr * abs_probs[ai]

                        # Check if new state is decided
                        new_key = ",".join(str(c) for c in new_state)
                        new_winner = dt.get(new_key)
                        if new_winner is not None:
                            # Decided! Record outcome
                            prof_prob[new_winner] += contrib
                            # Cost contribution: this vote's expected cost given answer ai
                            # cost_quals[ai] = E[cost * I(answer=ai)] for one vote
                            # Given answer=ai, E[cost] = cost_quals[ai] / abs_probs[ai]
                            # Contribution to E[total_cost * I(winner=correct)]:
                            #   contrib * E[this_vote_cost | answer=ai] * I(new_winner==correct)
                            #   + but we also need accumulated cost from previous votes...
                            # Hmm, this is tricky. We need to track accumulated cost.
                            pass
                        else:
                            # Not decided yet, add to next level
                            new_prob_reach[new_state] = new_prob_reach.get(new_state, Fraction(0)) + contrib

                prob_reach = new_prob_reach

            # Handle remaining states (at max_votes, not decided)
            for state, pr in prob_reach.items():
                if pr == 0:
                    continue
                state_key = ",".join(str(c) for c in state)
                winner = dt.get(state_key)
                if winner is not None:
                    prof_prob[winner] += pr
                else:
                    # At max votes and not decided - this shouldn't happen
                    # based on the decision table logic, but just in case
                    # The leader at this point wins
                    best_idx = 0
                    best_count = state[0]
                    for i in range(1, na):
                        if state[i] > best_count:
                            best_count = state[i]
                            best_idx = i
                    prof_prob[best_idx] += pr

            # Now handle costs properly. The above approach doesn't track accumulated costs.
            # We need a different approach for cost_if_correct.
            # Let me redo this with proper cost tracking.

            # Actually, let me reconsider. We need E[total_cost | correct].
            # Total cost = sum of costs of all launched votes.
            # E[total_cost * I(correct)] = sum over all paths that end correctly of (path_prob * path_total_cost)
            # Then cost_if_correct = E[total_cost * I(correct)] / P(correct)

            # To track this, at each state we need not just prob_reach but also
            # the expected accumulated cost weighted by probability.

            # Let me redo the DP tracking:
            # reach_prob[s] = P(reach state s)
            # reach_cost[s] = E[accumulated_cost * I(reach s)] (expected accumulated cost times indicator of reaching s)

            # When we launch a vote from state s with reach_prob[s] and reach_cost[s]:
            # - Contributes reach_prob[s] to launches
            # - If unresolved: contributes to unresolved prob (no additional cost tracked for unresolved? 
            #   Actually the problem says "所有已发起票花费之和" - sum of costs of all launched votes.
            #   If a vote never terminates, does it still have a cost? The vote was launched but never completed.
            #   Re-reading: "每次按当前状态的出边权重比例随机选边并支付其非负整数花费"
            #   Cost is paid per edge traversal. If the vote loops forever, infinite cost?
            #   But "若某次发起的票永不结束，整场结果为未决" - unresolved means no result.
            #   cost_if_correct is conditional on correct result, so unresolved cases don't contribute.
            #   So we only care about cost on paths that DO terminate with a winner.

            # OK so for cost tracking on terminating paths:
            # When launching a vote from state s:
            #   For answer ai outcome:
            #     Additional cost = E[cost | answer=ai] = cost_quals[ai] / abs_probs[ai]
            #     New accumulated cost contribution = reach_cost[s] * abs_probs[ai] + reach_prob[s] * cost_quals[ai]
            #     Wait, let me think more carefully.
            #     
            #     reach_cost[s] = E[acc_cost * I(reach s)]
            #     After vote resulting in ai:
            #       new_acc_cost = old_acc_cost + vote_cost
            #       E[new_acc_cost * I(reach s AND vote=ai)] 
            #         = E[(old_acc_cost + vote_cost) * I(reach s) * I(vote=ai)]
            #         = E[old_acc_cost * I(reach s)] * P(vote=ai | reach s) + E[vote_cost * I(vote=ai)] * P(reach s)
            #         = reach_cost[s] * abs_probs[ai] + cost_quals[ai] * reach_prob[s]
            #     
            #     Yes! So:
            #       new_reach_cost[s'] += reach_cost[s] * abs_probs[ai] + cost_quals[ai] * reach_prob[s]
            #       where s' is the new state after adding vote for ai

            # Let me redo the full DP with cost tracking
            reach_prob = {start_state: Fraction(1)}
            reach_cost = {start_state: Fraction(0)}  # E[acc_cost * I(reach)]

            prof_prob = [Fraction(0)] * na
            prof_unresolved = Fraction(0)
            prof_launches = Fraction(0)
            prof_cost_correct_num = Fraction(0)  # E[total_cost * I(correct)]

            for votes_cast in range(max_votes):
                new_reach_prob = {}
                new_reach_cost = {}
                for state in list(reach_prob.keys()):
                    pr = reach_prob[state]
                    rc = reach_cost[state]
                    if pr == 0:
                        continue

                    state_key = ",".join(str(c) for c in state)
                    winner = dt.get(state_key)
                    if winner is not None:
                        # Already decided - shouldn't expand
                        prof_prob[winner] += pr
                        if winner == correct_idx:
                            prof_cost_correct_num += rc
                        continue

                    # Launch vote
                    prof_launches += pr

                    # Unresolved outcome
                    if p_unres > 0:
                        prof_unresolved += pr * p_unres
                        # No cost contribution for unresolved (doesn't lead to correct result)

                    # Answer outcomes
                    for ai in range(na):
                        if abs_probs[ai] == 0:
                            continue
                        new_state = list(state)
                        new_state[ai] += 1
                        new_state = tuple(new_state)

                        contrib_prob = pr * abs_probs[ai]
                        contrib_cost = rc * abs_probs[ai] + cost_quals[ai] * pr

                        new_key = ",".join(str(c) for c in new_state)
                        new_winner = dt.get(new_key)

                        if new_winner is not None:
                            prof_prob[new_winner] += contrib_prob
                            if new_winner == correct_idx:
                                prof_cost_correct_num += contrib_cost
                        else:
                            new_reach_prob[new_state] = new_reach_prob.get(new_state, Fraction(0)) + contrib_prob
                            new_reach_cost[new_state] = new_reach_cost.get(new_state, Fraction(0)) + contrib_cost

                reach_prob = new_reach_prob
                reach_cost = new_reach_cost

            # Handle remaining undecided states at max votes
            for state in reach_prob:
                pr = reach_prob[state]
                rc = reach_cost[state]
                if pr == 0:
                    continue
                state_key = ",".join(str(c) for c in state)
                winner = dt.get(state_key)
                if winner is None:
                    # Determine winner by current counts
                    best_idx = 0
                    best_count = state[0]
                    for i in range(1, na):
                        if state[i] > best_count:
                            best_count = state[i]
                            best_idx = i
                    winner = best_idx
                prof_prob[winner] += pr
                if winner == correct_idx:
                    prof_cost_correct_num += rc

            # Weight by profile prior
            for ai in range(na):
                total_prob[ai] += pw * prof_prob[ai]
            total_unresolved += pw * prof_unresolved
            total_launches += pw * prof_launches
            total_cost_correct += pw * prof_cost_correct_num
            total_prob_correct += pw * prof_prob[correct_idx]

        # Format output
        prob_out = [_reduce(total_prob[ai].numerator, total_prob[ai].denominator) for ai in range(na)]
        unres_out = _reduce(total_unresolved.numerator, total_unresolved.denominator)
        launches_out = _reduce(total_launches.numerator, total_launches.denominator)

        if total_prob_correct == 0:
            cic_out = None
        else:
            cic = total_cost_correct / total_prob_correct
            cic_out = _reduce(cic.numerator, cic.denominator)

        results.append({
            "id": mid,
            "prob": prob_out,
            "unresolved": unres_out,
            "launches": launches_out,
            "cost_if_correct": cic_out,
            "_correct_prob": float(total_prob_correct)  # for sorting, removed later
        })

    # Sort by correct probability descending, then method id ascending
    results.sort(key=lambda r: (-r["_correct_prob"], r["id"]))
    for r in results:
        del r["_correct_prob"]

    return results
