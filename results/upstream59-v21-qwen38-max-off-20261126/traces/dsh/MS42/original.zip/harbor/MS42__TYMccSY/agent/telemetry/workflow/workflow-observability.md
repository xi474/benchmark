# Workflow 可观测性报告

- Trial：`MS42__TYMccSY__env`
- Task：`MS42`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（54 节点 / 53 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：54；执行边：53（observed=0，inferred=53）
- Execution Trace Graph：`observed`；temporal_next 边 53，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_39e6abad97b54e0da2c67866 -> tool:dsh:lead:call_854945f0ff5d479fbc3953dc -> tool:dsh:lead:call_f62ea379894f4f5ca9d5629a -> tool:dsh:lead:call_d803b1241f22481ea2387593 -> tool:dsh:lead:call_a17a571f07ea48669f6c948a -> tool:dsh:lead:call_f77681f545594fd3afe91d3b -> tool:dsh:lead:call_83dd0a1391c840938ea2297e -> tool:dsh:lead:call_42d15438fe87459cbf658f4c -> tool:dsh:lead:call_8309f10e8bd84ef1a1b80697 -> tool:dsh:lead:call_1c53d48028ec431d973e4151 -> tool:dsh:lead:call_dd68b10f90864242b93d1911 -> tool:dsh:lead:call_c5aa571d3a7b4e46882b56fe -> tool:dsh:lead:call_26eaee38fde245c685fc83bd -> tool:dsh:lead:call_4f9c04a44097425da1da6f91 -> tool:dsh:lead:call_1c28ce785ea94de98136ef7e -> tool:dsh:lead:call_6bfae704772d4516aa5d2c3b -> tool:dsh:lead:call_5ddafb8613214996af48a50a -> tool:dsh:lead:call_6308c80beaf4455296357c1e -> tool:dsh:lead:call_88635664cff14430aeb09991 -> tool:dsh:lead:call_846f89f60d1642feaa988026 -> tool:dsh:lead:call_00a183ae4f8742ba9baa6263 -> tool:dsh:lead:call_5c167576e69241f9b53d6044 -> tool:dsh:lead:call_37dda686e74341edac1951e0 -> tool:dsh:lead:call_16910aea935048c4967f3cb6 -> tool:dsh:lead:call_c6e64c7f6a9c4f59bf004773 -> tool:dsh:lead:call_15d5c89e19594be496d2fd3f -> tool:dsh:lead:call_7a51ea89ad4c44e697b52aed -> tool:dsh:lead:call_6acbb6af633348568bd8105e -> tool:dsh:lead:call_cfc9ba0bed71468e98976168 -> tool:dsh:lead:call_ad6d7c5ba58241788cee429b -> tool:dsh:lead:call_b71dde2a8925410c976afea4 -> tool:dsh:lead:call_2c7a5d7dcc644e90849338f1 -> tool:dsh:lead:call_5b084591ff30470e9425cf14 -> tool:dsh:lead:call_5691dd8f9dcb4330b7bac2db -> tool:dsh:lead:call_94715d283e0c42d39f290699 -> tool:dsh:lead:call_228181b3f99c445a9c6d08cb -> tool:dsh:lead:call_7f9fffead2cd40829fe12416 -> tool:dsh:lead:call_c9e29c102b724078b9e6150e -> tool:dsh:lead:call_431e951aea43417aabb9a948 -> tool:dsh:lead:call_95c807427a5840bb9c943c98 -> tool:dsh:lead:call_bbe9aacb54b349e9b85e4a5d -> tool:dsh:lead:call_d82169d639ab4d9993cfd453 -> tool:dsh:lead:call_51f4d6baf59d491592350613 -> tool:dsh:lead:call_02645723abff4dadbaa55c93 -> tool:dsh:lead:call_36e6e6e697434954b708d31a -> tool:dsh:lead:call_03271709c62b4f4384887a2b -> tool:dsh:lead:call_3832011cb2714fdeb476124d -> tool:dsh:lead:call_6b5e9364ef9a4f698534da42 -> tool:dsh:lead:call_e5fe171de249493fb405ff7c -> tool:dsh:lead:call_b15fce4685e84ee1b92f6cce -> tool:dsh:lead:call_349d9ead06ab4d4da6a3e045 -> tool:dsh:lead:call_c10ce4042a3e42d1959a5171 -> tool:dsh:lead:call_42a4a84747d9470d8680108f
- 关键路径耗时：1.639
- Makespan：369.022
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
