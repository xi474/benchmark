def compute(payload):
    """为每门课生成 [项目统计,传递可达表]；统计行 [ID,标签,[成绩和分子,分母],非空数] 按 ID 排序，保留零成绩。可达表的值为有序 ID 数组。"""
    courses = payload["courses"]
    result = {}

    for course_key, course_data in courses.items():
        items = course_data["items"]
        edges = course_data["edges"]

        # Build item statistics
        stats = []
        item_ids = []
        for item in items:
            item_id = item[0]
            label = item[1]
            scores = item[2]
            # Compute sum of non-null scores and count of non-null scores
            score_sum = 0
            count = 0
            for s in scores:
                if s is not None:
                    score_sum += s
                    count += 1
            stats.append([item_id, label, [score_sum, count], count])
            item_ids.append(item_id)

        # Sort stats by ID
        stats.sort(key=lambda x: x[0])

        # Build adjacency list for transitive closure
        # edges are [prerequisite, successor] meaning prerequisite -> successor
        adj = {iid: set() for iid in item_ids}
        for edge in edges:
            pred, succ = edge[0], edge[1]
            adj[pred].add(succ)

        # Compute transitive closure using Floyd-Warshall or BFS from each node
        reachable = {iid: set() for iid in item_ids}
        for start in item_ids:
            # BFS/DFS from start
            visited = set()
            stack = list(adj[start])
            while stack:
                node = stack.pop()
                if node not in visited:
                    visited.add(node)
                    stack.extend(adj[node] - visited)
            reachable[start] = visited

        # Convert to sorted arrays
        reach_table = {iid: sorted(reachable[iid]) for iid in item_ids}

        result[course_key] = [stats, reach_table]

    return result
