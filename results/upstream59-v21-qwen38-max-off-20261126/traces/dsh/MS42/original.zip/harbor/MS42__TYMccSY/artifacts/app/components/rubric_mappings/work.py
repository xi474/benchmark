from itertools import permutations


def compute(payload):
    """返回 [所有可行映射位掩码,旧标签到各新标签的掩码映射]；位序按新标签升序的排列枚举。"""
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    # Collect all new labels mentioned in allowed lists
    new_labels_set = set()
    for allowed in rubrics.values():
        new_labels_set.update(allowed)
    new_labels = sorted(new_labels_set)
    n = len(old_labels)

    # Enumerate all bijections (permutations of new_labels assigned to old_labels)
    # A bijection is valid if for every old_label, the assigned new_label is in its allowed list
    # Bit position i corresponds to the i-th permutation in lexicographic order of new_labels
    valid_mask = 0
    # For each (old_label, new_label), track which bijection indices include that assignment
    assignment_masks = {ol: {nl: 0 for nl in new_labels} for ol in old_labels}

    for idx, perm in enumerate(permutations(new_labels)):
        # perm[i] is the new label assigned to old_labels[i]
        valid = True
        for i, ol in enumerate(old_labels):
            if perm[i] not in rubrics[ol]:
                valid = False
                break
        if valid:
            valid_mask |= (1 << idx)
            for i, ol in enumerate(old_labels):
                assignment_masks[ol][perm[i]] |= (1 << idx)

    return [valid_mask, assignment_masks]
