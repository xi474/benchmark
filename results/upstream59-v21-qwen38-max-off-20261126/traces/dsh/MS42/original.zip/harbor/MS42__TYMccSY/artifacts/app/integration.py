from itertools import permutations
from math import gcd


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    rubrics = payload["rubrics"]
    courses = payload["courses"]

    # Extract all valid bijections
    old_labels = sorted(rubrics.keys())
    new_labels_set = set()
    for allowed in rubrics.values():
        new_labels_set.update(allowed)
    new_labels = sorted(new_labels_set)
    n_labels = len(old_labels)

    valid_bijections = []
    for perm in permutations(new_labels):
        if all(perm[i] in rubrics[old_labels[i]] for i in range(n_labels)):
            valid_bijections.append({old_labels[i]: perm[i] for i in range(n_labels)})

    # Identify course prefixes with both years
    course_keys = set(courses.keys())
    prefixes = sorted(set(
        key[:-6] for key in course_keys
        if key.endswith("-2013J") and key[:-6] + "-2014J" in course_keys
    ))

    # Build per-prefix data
    prefix_data = {}
    for prefix in prefixes:
        old_stats, old_reach = right[prefix + "-2013J"]
        new_stats, new_reach = right[prefix + "-2014J"]
        old_items = [(s[0], s[1], s[2][0], s[2][1]) for s in old_stats if s[3] > 0]
        new_items = [(s[0], s[1], s[2][0], s[2][1]) for s in new_stats if s[3] > 0]
        prefix_data[prefix] = {
            'old_items': old_items,
            'new_items': new_items,
            'old_reach': old_reach,
            'new_reach': new_reach,
        }

    def get_rel(reach, a, b):
        if b in reach.get(a, []): return 1
        if a in reach.get(b, []): return -1
        return 0

    # For each bijection, build candidate pairs and do branch-and-bound
    best_pairs = 0
    best_support = 0
    optimal_alignments = set()

    for bij in valid_bijections:
        # Build all candidate pairs across all prefixes
        # Each candidate: (prefix, oid, nid, support, osum, ocnt, nsum, ncnt)
        candidates = []
        for prefix in prefixes:
            pd = prefix_data[prefix]
            for (oid, olabel, osum, ocnt) in pd['old_items']:
                mapped = bij.get(olabel)
                if mapped is None:
                    continue
                for (nid, nlabel, nsum, ncnt) in pd['new_items']:
                    if nlabel == mapped:
                        candidates.append((prefix, oid, nid, min(ocnt, ncnt)))

        # Branch and bound to find all maximum (pairs, support) matchings
        # State: index into candidates, chosen set, old_used, new_used
        
        def is_order_ok(prefix, oid, nid, chosen_pairs_by_prefix):
            """Check if adding (oid, nid) to prefix's chosen pairs maintains order consistency."""
            existing = chosen_pairs_by_prefix.get(prefix, [])
            if not existing:
                return True
            pd = prefix_data[prefix]
            old_reach = pd['old_reach']
            new_reach = pd['new_reach']
            for (eoid, enid) in existing:
                if get_rel(old_reach, eoid, oid) != get_rel(new_reach, enid, nid):
                    return False
            return True

        results = []  # list of (frozenset_alignment, num_pairs, support)

        def backtrack(idx, chosen, old_used, new_used, pairs_count, support_sum, by_prefix):
            nonlocal best_pairs, best_support

            # Pruning: even if we add all remaining candidates, can we beat best?
            remaining = len(candidates) - idx
            if pairs_count + remaining < best_pairs:
                return
            if pairs_count + remaining == best_pairs and support_sum <= best_support - remaining:
                # Can't beat support either (each pair contributes at least 1 to support)
                # Actually support could be 0... but min count is 1 since we filtered non-null
                pass

            # Record current state
            alignment = frozenset(chosen)
            if pairs_count > best_pairs or (pairs_count == best_pairs and support_sum > best_support):
                best_pairs = pairs_count
                best_support = support_sum
                optimal_alignments.clear()
                optimal_alignments.add(alignment)
            elif pairs_count == best_pairs and support_sum == best_support:
                optimal_alignments.add(alignment)

            for i in range(idx, len(candidates)):
                prefix, oid, nid, sup = candidates[i]
                ok = (prefix, oid) not in old_used and (prefix, nid) not in new_used
                if ok and is_order_ok(prefix, oid, nid, by_prefix):
                    old_used.add((prefix, oid))
                    new_used.add((prefix, nid))
                    chosen.append((prefix, oid, nid))
                    by_prefix.setdefault(prefix, []).append((oid, nid))
                    
                    backtrack(i + 1, chosen, old_used, new_used,
                              pairs_count + 1, support_sum + sup, by_prefix)
                    
                    by_prefix[prefix].pop()
                    chosen.pop()
                    old_used.remove((prefix, oid))
                    new_used.remove((prefix, nid))

        backtrack(0, [], set(), set(), 0, 0, {})

    ways = len(optimal_alignments)

    # Forced pairs
    if ways == 0:
        forced = []
    else:
        common = None
        for a in optimal_alignments:
            common = a if common is None else common & a
        forced = sorted([list(t) for t in (common or set())])

    # Drift
    if best_pairs == 0:
        drift = None
    else:
        drifts = []
        for alignment in optimal_alignments:
            old_total = old_count = new_total = new_count = 0
            for (prefix, oid, nid) in alignment:
                pd = prefix_data[prefix]
                for (iid, _, isum, icnt) in pd['old_items']:
                    if iid == oid:
                        old_total += isum; old_count += icnt; break
                for (iid, _, isum, icnt) in pd['new_items']:
                    if iid == nid:
                        new_total += isum; new_count += icnt; break
            num = new_total * old_count - old_total * new_count
            den = new_count * old_count
            g = gcd(abs(num), den)
            num //= g; den //= g
            if den < 0: num = -num; den = -den
            drifts.append((num, den))

        min_d = min(drifts, key=lambda x: x[0] / x[1])
        max_d = max(drifts, key=lambda x: x[0] / x[1])
        drift = [list(min_d), list(max_d)]

    return {
        "pairs": best_pairs,
        "support": best_support,
        "ways": ways,
        "forced": forced,
        "drift": drift,
    }
