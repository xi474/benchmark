# Workflow 可观测性报告

- Trial：`N11__KfJ8oFj__env`
- Task：`N11`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（32 节点 / 31 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：32；执行边：31（observed=0，inferred=31）
- Execution Trace Graph：`observed`；temporal_next 边 31，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_5f25b79ddc8246dc80981860 -> tool:dsh:lead:call_ee6571f8f0344951ba8ec9e3 -> tool:dsh:lead:call_2e8a907e2b4b48adb9360d7c -> tool:dsh:lead:call_b9c0ec16d9774975b3a228e4 -> tool:dsh:lead:call_4d888b60a44d42838388c08d -> tool:dsh:lead:call_a872b0dfc5b644bc8bcabed0 -> tool:dsh:lead:call_fe7084a7919949c3b1f71996 -> tool:dsh:lead:call_1325ab41dd3a49019b11052b -> tool:dsh:lead:call_85d0830cdf2742e28a8a3d2f -> tool:dsh:lead:call_cba91a61d94445dcbb3f0ca2 -> tool:dsh:lead:call_7b55fd56f10b4c3ebe590333 -> tool:dsh:lead:call_2b71b3c3db1e432b8b57bd25 -> tool:dsh:lead:call_322050c2286146b8858504e8 -> tool:dsh:lead:call_e3914727e3aa4241add85293 -> tool:dsh:lead:call_8ac6fa9508f842c68dc21f6c -> tool:dsh:lead:call_36b02dac6f7b45f196389ecc -> tool:dsh:lead:call_238f67f531394984b463c097 -> tool:dsh:lead:call_c5e1702179d24a28822f6196 -> tool:dsh:lead:call_134c9be4466344fcafb0bdcd -> tool:dsh:lead:call_04477ace2b144f1ca2f32250 -> tool:dsh:lead:call_3cc422b4a7284145aa8c94a5 -> tool:dsh:lead:call_0fcba7e483eb41399b4f7cd6 -> tool:dsh:lead:call_fcc0694f376041e5946e8d15 -> tool:dsh:lead:call_982e7fb3b5274a97b6f68849 -> tool:dsh:lead:call_dda3953231284147aa905d6d -> tool:dsh:lead:call_2c3d44efbd7348809ea966cf -> tool:dsh:lead:call_90a5681789664bf8aced2efa -> tool:dsh:lead:call_9e53347010c94890832802c6 -> tool:dsh:lead:call_d27697a7a0814c0ab3f2ba53 -> tool:dsh:lead:call_7f0f50369f4a4117b976052f -> tool:dsh:lead:call_29ad260102234906abbd1b67
- 关键路径耗时：0.809
- Makespan：92.964
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
