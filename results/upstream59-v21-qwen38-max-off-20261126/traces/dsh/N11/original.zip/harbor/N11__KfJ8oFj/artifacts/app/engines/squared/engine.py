"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def _mat_mul(A, B):
    """Multiply two dense integer matrices (lists of lists)."""
    rows_a = len(A)
    cols_b = len(B[0])
    cols_a = len(A[0])
    result = [[0] * cols_b for _ in range(rows_a)]
    for i in range(rows_a):
        for j in range(cols_b):
            s = 0
            for k in range(cols_a):
                s += A[i][k] * B[k][j]
            result[i][j] = s
    return result


def _is_zero_block(block):
    return block["data"] is None


def _zero_block(rows, cols):
    return {"rows": rows, "cols": cols, "data": None}


def _block_to_dense(block):
    """Convert a block to a dense matrix, treating null as zeros."""
    if block["data"] is None:
        return [[0] * block["cols"] for _ in range(block["rows"])]
    return [row[:] for row in block["data"]]


def _dense_is_zero(matrix):
    for row in matrix:
        for val in row:
            if val != 0:
                return False
    return True


def transform(payload, contract):
    matrix = payload["matrix"]
    layout = payload["layout"]
    row_sizes = layout["row_sizes"]
    col_sizes = layout["col_sizes"]
    n_blocks = len(matrix)  # number of block rows (= block cols for square)

    # Compute B² via block matrix multiplication
    result_blocks = []
    for i in range(n_blocks):
        row = []
        for j in range(n_blocks):
            # C[i][j] = sum_k A[i][k] * A[k][j]
            out_rows = row_sizes[i]
            out_cols = col_sizes[j]
            # Accumulate using dense arithmetic
            acc = [[0] * out_cols for _ in range(out_rows)]
            for k in range(n_blocks):
                a_block = matrix[i][k]
                b_block = matrix[k][j]
                # If either is zero, skip
                if _is_zero_block(a_block) or _is_zero_block(b_block):
                    continue
                a_dense = a_block["data"]
                b_dense = b_block["data"]
                product = _mat_mul(a_dense, b_dense)
                for r in range(out_rows):
                    for c in range(out_cols):
                        acc[r][c] += product[r][c]
            if _dense_is_zero(acc):
                row.append(_zero_block(out_rows, out_cols))
            else:
                row.append({"rows": out_rows, "cols": out_cols, "data": acc})
        result_blocks.append(row)

    return {"layout": layout, "blocks": result_blocks}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
