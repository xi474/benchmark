"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module


def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    # Load contracts
    block_layout_contract = read(root / "engines/block_layout/contract.json")
    squared_contract = read(root / "engines/squared/contract.json")
    cubed_contract = read(root / "engines/cubed/contract.json")

    # Load engine modules
    block_layout_mod = module(root, "engines/block_layout/engine.py")
    squared_mod = module(root, "engines/squared/engine.py")
    cubed_mod = module(root, "engines/cubed/engine.py")

    # Build components in dependency order: block_layout -> squared -> cubed
    block_layout_result = block_layout_mod.build_component(root, block_layout_contract)
    squared_result = squared_mod.build_component(root, squared_contract)
    cubed_result = cubed_mod.build_component(root, cubed_contract)

    # Read result file
    result_file = delivery["result_file"]
    result_value = read(root / result_file)

    # Build final report
    component_outputs = delivery["component_outputs"]
    results = {}
    for comp_name, comp_path in component_outputs.items():
        results[comp_name] = read(root / comp_path)

    final_report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value
    }

    # Write final report
    report_path = root / delivery["report"]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )


if __name__ == '__main__':
    main()
