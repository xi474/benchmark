# Workflow 可观测性报告

- Trial：`N17__XiwH9Aj__env`
- Task：`N17`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（33 节点 / 32 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：33；执行边：32（observed=0，inferred=32）
- Execution Trace Graph：`observed`；temporal_next 边 32，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_92a8af54eaa24ecdbec8a020 -> tool:dsh:lead:call_d2044a3457e74596a7aa864d -> tool:dsh:lead:call_55b896d91a9d41c6b3d7cdce -> tool:dsh:lead:call_59b8698c47ce4843a9df5867 -> tool:dsh:lead:call_be98726cf1fe4ed383540ce9 -> tool:dsh:lead:call_4edf125262674bb383af1bae -> tool:dsh:lead:call_d01e92e17f784965b63e1ac7 -> tool:dsh:lead:call_80e1704145a04da3aee54ae9 -> tool:dsh:lead:call_ba38e2cacd5b4e1bba41a327 -> tool:dsh:lead:call_3dd939d18921476eaa8b439c -> tool:dsh:lead:call_d565c1257caf4fb9aa570083 -> tool:dsh:lead:call_8c601a8763bf409a8c642e94 -> tool:dsh:lead:call_6397d5d7e4aa406d94d189f5 -> tool:dsh:lead:call_a87848ffa3f949beb0b953e5 -> tool:dsh:lead:call_339e461e0eff449c8a03db85 -> tool:dsh:lead:call_172e9f27928642eb8cb99c1d -> tool:dsh:lead:call_0161051f5c9e4263bcdb5372 -> tool:dsh:lead:call_f69f19319b05494aa91b73d3 -> tool:dsh:lead:call_155f0a69c9c94dafa2b0f2aa -> tool:dsh:lead:call_1b19a52e9cf54969a6a2351b -> tool:dsh:lead:call_cbe27701f08c47d99792e979 -> tool:dsh:lead:call_86b336f62c4b4d40a09cc75f -> tool:dsh:lead:call_46dfa333be4f485ebc321ada -> tool:dsh:lead:call_980e2947d7a047eb803f9ac8 -> tool:dsh:lead:call_b3cbfdd1e53c45098ff5a164 -> tool:dsh:lead:call_58de5bc002e34f56866047d7 -> tool:dsh:lead:call_50d17a06342c4a27a73132c0 -> tool:dsh:lead:call_a9a056e49960477fb0022ff9 -> tool:dsh:lead:call_e40f395a2cc443408914f406 -> tool:dsh:lead:call_9f93c5bf1c814df2886e963c -> tool:dsh:lead:call_d1043384d7ff4f3f8a7d6c92 -> tool:dsh:lead:call_76136c6a74a6406589e16cf3
- 关键路径耗时：0.441
- Makespan：104.08
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
