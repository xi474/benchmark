"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build


def transform(payload, contract):
    dependencies = payload['dependencies']
    reverse = {}
    for tid, keys in dependencies.items():
        for key in keys:
            if key not in reverse:
                reverse[key] = []
            reverse[key].append(tid)
    # Sort template IDs for each config key
    for key in reverse:
        reverse[key] = sorted(reverse[key])
    return reverse


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
