"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import re
import ast
from runtime import build


def _extract_conf_chains(node):
    """Recursively extract conf access chains from an AST node.
    Returns list of dot-separated strings like 'auto_save.interval' or 'aliases.a.propname'.
    """
    chains = []
    if isinstance(node, ast.Attribute):
        # e.g. conf.auto_save.interval -> collect attribute chain
        parts = []
        n = node
        while isinstance(n, ast.Attribute):
            parts.append(n.attr)
            n = n.value
        if isinstance(n, ast.Name) and n.id == 'conf':
            parts.reverse()
            chains.append('.'.join(parts))
        else:
            # Recurse into the value in case there are nested conf refs
            chains.extend(_extract_conf_chains(n))
    elif isinstance(node, ast.Subscript):
        # e.g. conf.aliases['a'] -> convert subscript to dot notation
        # First get the base chain
        base_chains = _extract_conf_chains(node.value)
        # Get the index/slice
        idx = node.slice
        if isinstance(idx, ast.Constant) and isinstance(idx.value, str):
            suffix = idx.value
        elif isinstance(idx, ast.Index):  # Python < 3.9 compat
            inner = idx.value
            if isinstance(inner, ast.Constant) and isinstance(inner.value, str):
                suffix = inner.value
            else:
                suffix = None
        else:
            suffix = None

        if suffix is not None and base_chains:
            for bc in base_chains:
                chains.append(bc + '.' + suffix)
        else:
            chains.extend(base_chains)
    elif isinstance(node, ast.BinOp):
        chains.extend(_extract_conf_chains(node.left))
        chains.extend(_extract_conf_chains(node.right))
    elif isinstance(node, ast.UnaryOp):
        chains.extend(_extract_conf_chains(node.operand))
    elif isinstance(node, ast.Call):
        chains.extend(_extract_conf_chains(node.func))
        for arg in node.args:
            chains.extend(_extract_conf_chains(arg))
        for kw in node.keywords:
            chains.extend(_extract_conf_chains(kw.value))
    elif isinstance(node, ast.Compare):
        chains.extend(_extract_conf_chains(node.left))
        for comp in node.comparators:
            chains.extend(_extract_conf_chains(comp))
    elif isinstance(node, ast.BoolOp):
        for val in node.values:
            chains.extend(_extract_conf_chains(val))
    elif isinstance(node, ast.IfExp):
        chains.extend(_extract_conf_chains(node.test))
        chains.extend(_extract_conf_chains(node.body))
        chains.extend(_extract_conf_chains(node.orelse))
    elif isinstance(node, ast.List) or isinstance(node, ast.Tuple) or isinstance(node, ast.Set):
        for elt in node.elts:
            chains.extend(_extract_conf_chains(elt))
    elif isinstance(node, ast.Dict):
        for k in node.keys:
            if k is not None:
                chains.extend(_extract_conf_chains(k))
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    return chains


def _longest_prefix_match(chain, options_set):
    """Find the longest option that is a prefix of the chain (exact match or followed by '.')."""
    best = None
    for opt in options_set:
        if chain == opt or chain.startswith(opt + '.'):
            if best is None or len(opt) > len(best):
                best = opt
    return best


def transform(payload, contract):
    templates = payload['templates']
    options = payload['options']
    options_set = set(options)

    result = {}
    expr_pattern = re.compile(r'\{\{(.*?)\}\}')

    for tid, text in templates.items():
        config_keys = set()
        for match in expr_pattern.finditer(text):
            expr_str = match.group(1).strip()
            try:
                tree = ast.parse(expr_str, mode='eval')
            except SyntaxError:
                continue
            chains = _extract_conf_chains(tree.body)
            for chain in chains:
                matched = _longest_prefix_match(chain, options_set)
                if matched is not None:
                    config_keys.add(matched)
        result[tid] = sorted(config_keys)

    return result


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
