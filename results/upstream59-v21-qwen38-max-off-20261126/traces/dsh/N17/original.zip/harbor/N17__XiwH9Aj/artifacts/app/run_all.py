"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module


def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / 'delivery.json')

    # Load contracts
    td_contract = read(root / 'engines/template_dependencies/contract.json')
    ri_contract = read(root / 'engines/reverse_index/contract.json')
    su_contract = read(root / 'engines/stylesheet_updates/contract.json')

    # Load engine modules
    td_mod = module(root / 'engines/template_dependencies', 'engine.py')
    ri_mod = module(root / 'engines/reverse_index', 'engine.py')
    su_mod = module(root / 'engines/stylesheet_updates', 'engine.py')

    # Execute in dependency order
    # 1. template_dependencies (depends on inputs only)
    td_result = td_mod.build_component(root, td_contract)

    # 2. reverse_index (depends on template_dependencies output)
    ri_result = ri_mod.build_component(root, ri_contract)

    # 3. stylesheet_updates (depends on template_dependencies + reverse_index outputs)
    su_result = su_mod.build_component(root, su_contract)

    # Build final report
    result_file_path = delivery['result_file']
    result_value = read(root / result_file_path)

    final_report = {
        "task": delivery["task"],
        "results": {
            "template_dependencies": td_result,
            "stylesheet_updates": su_result,
            "reverse_index": ri_result
        },
        "result": result_value
    }

    out = root / delivery['report']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == '__main__':
    main()
