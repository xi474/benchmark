# Workflow 可观测性报告

- Trial：`N22__6TuVaiC__env`
- Task：`N22`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_663e9e6b23374e9a89f2db64 -> tool:dsh:lead:call_2ba0474f1ccf4f8da396d4d1 -> tool:dsh:lead:call_cd29a0a2d868477588c8bb6e -> tool:dsh:lead:call_85d548a387cb4328bd319e28 -> tool:dsh:lead:call_fffd10b2eb834beca73af0e4 -> tool:dsh:lead:call_c9d7d53706ad4b27a10d64ea -> tool:dsh:lead:call_bfa2690dbb574767afb39f57 -> tool:dsh:lead:call_db67b4f18e094498bdc22633 -> tool:dsh:lead:call_bdbd8ed542994dd0a2c746eb -> tool:dsh:lead:call_b71d9cd934c74423bb0bf5c0 -> tool:dsh:lead:call_b30b4fb87d68463cbee2fb42 -> tool:dsh:lead:call_acfc5816bcea4ddab2019236 -> tool:dsh:lead:call_5f1a0f2ec1a141709c040360 -> tool:dsh:lead:call_e85a0033c645464ca89e9ceb -> tool:dsh:lead:call_406ae81cd1bc40e8be3781fe -> tool:dsh:lead:call_548540298cad4c34ab379159 -> tool:dsh:lead:call_3907778b1baf44f9a0b5ce78 -> tool:dsh:lead:call_27b1eeb3ebaa4b5b8fdbf0bd -> tool:dsh:lead:call_f928c290183e4860aaff9beb -> tool:dsh:lead:call_7af1ce1308054daa9218d17d -> tool:dsh:lead:call_6f65c0aa657748a4be4cf1b2 -> tool:dsh:lead:call_03857fd16c3b42bb8508de9d -> tool:dsh:lead:call_7c1e67fc9988439f9993f996 -> tool:dsh:lead:call_051e69e6fe234805b07e9f61 -> tool:dsh:lead:call_c2eabc56d8364181a530f54f -> tool:dsh:lead:call_5efbec0098de46eeb8704aa4 -> tool:dsh:lead:call_34ca29194e22415badd2e25d -> tool:dsh:lead:call_8240e39c9bd84d5ab30d22d7 -> tool:dsh:lead:call_3664949781fd445b8a2d4c9a -> tool:dsh:lead:call_66a6c7cc1c304e27bc89cda7 -> tool:dsh:lead:call_34cb4d93c13b4291a97d33f4 -> tool:dsh:lead:call_4b81a9ddbc9d4825b3c334fc -> tool:dsh:lead:call_b50a5732cc1e4bd8bd4fdd31 -> tool:dsh:lead:call_1c941b9c8ce84cfeaaf1b56d -> tool:dsh:lead:call_166494a48232492493653ede
- 关键路径耗时：0.961
- Makespan：158.655
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
