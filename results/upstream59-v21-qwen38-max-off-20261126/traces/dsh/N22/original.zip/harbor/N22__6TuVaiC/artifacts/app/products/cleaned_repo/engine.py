"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import gzip
import tarfile
import io
import os
import subprocess
import tempfile
import hashlib
import re
from runtime import build


def _extract_repo(bundle_b64, dest):
    """Extract a gzip-tar base64 bundle into dest directory."""
    raw = base64.b64decode(bundle_b64)
    gz = gzip.decompress(raw)
    tf = tarfile.open(fileobj=io.BytesIO(gz))
    tf.extractall(dest, filter='data')


def _pack_repo(repo_path):
    """Pack a repo directory into a gzip-tar base64 string."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as tf:
        for root_dir, dirs, files in os.walk(repo_path):
            for fname in sorted(files):
                fpath = os.path.join(root_dir, fname)
                arcname = os.path.relpath(fpath, repo_path)
                tf.add(fpath, arcname=arcname)
    return base64.b64encode(buf.getvalue()).decode('ascii')


def _clean_repo(repo_path, secret):
    """Remove all objects related to the secret, clean reflog, repack."""
    # Find all unreachable objects that contain or reference the secret
    objects_dir = os.path.join(repo_path, '.git', 'objects')
    all_objects = []
    for d in os.listdir(objects_dir):
        if len(d) == 2 and d not in ('pack', 'info'):
            dpath = os.path.join(objects_dir, d)
            if os.path.isdir(dpath):
                for f in os.listdir(dpath):
                    all_objects.append(d + f)

    # Get reachable objects (current branch)
    result = subprocess.run(
        ['git', 'rev-list', '--all', '--objects'],
        cwd=repo_path, capture_output=True, text=True
    )
    reachable = set()
    for line in result.stdout.strip().split('\n'):
        if line:
            reachable.add(line.split()[0])

    unreachable = [o for o in all_objects if o not in reachable]

    # Identify objects containing the secret pattern
    secret_bytes = secret.encode('utf-8')
    objects_to_remove = set()
    pattern = re.compile(rb'secret\[.*?\]')

    for obj in unreachable:
        result = subprocess.run(
            ['git', 'cat-file', '-p', obj],
            cwd=repo_path, capture_output=True
        )
        if pattern.search(result.stdout):
            objects_to_remove.add(obj)

    # Also find commits/trees that reference those blobs
    # Walk unreachable commits and their trees
    for obj in unreachable:
        result = subprocess.run(
            ['git', 'cat-file', '-t', obj],
            cwd=repo_path, capture_output=True, text=True
        )
        obj_type = result.stdout.strip()
        if obj_type == 'commit':
            # Check if this commit's tree contains the secret blob
            result2 = subprocess.run(
                ['git', 'cat-file', '-p', obj],
                cwd=repo_path, capture_output=True, text=True
            )
            for line in result2.stdout.split('\n'):
                if line.startswith('tree '):
                    tree_hash = line.split()[1]
                    if tree_hash in objects_to_remove or any(
                        tree_hash == o for o in unreachable
                    ):
                        # Check if this tree references a secret blob
                        result3 = subprocess.run(
                            ['git', 'cat-file', '-p', tree_hash],
                            cwd=repo_path, capture_output=True, text=True
                        )
                        for tline in result3.stdout.split('\n'):
                            parts = tline.split()
                            if len(parts) >= 3 and parts[1] == 'blob':
                                blob_hash = parts[2]
                                if blob_hash in objects_to_remove:
                                    objects_to_remove.add(obj)
                                    objects_to_remove.add(tree_hash)

    # Remove ORIG_HEAD if it points to an unreachable commit
    orig_head_path = os.path.join(repo_path, '.git', 'ORIG_HEAD')
    if os.path.exists(orig_head_path):
        with open(orig_head_path) as f:
            orig_head = f.read().strip()
        if orig_head in objects_to_remove or orig_head not in reachable:
            os.remove(orig_head_path)

    # Clear reflog entries that reference removed objects
    for logfile in ['.git/logs/HEAD', '.git/logs/refs/heads/master']:
        logpath = os.path.join(repo_path, logfile)
        if os.path.exists(logpath):
            with open(logpath) as f:
                lines = f.readlines()
            new_lines = []
            for line in lines:
                keep = True
                for obj in objects_to_remove:
                    if obj in line:
                        keep = False
                        break
                if keep:
                    new_lines.append(line)
            with open(logpath, 'w') as f:
                f.writelines(new_lines)

    # Remove the actual object files
    for obj in objects_to_remove:
        obj_path = os.path.join(objects_dir, obj[:2], obj[2:])
        if os.path.exists(obj_path):
            os.remove(obj_path)

    # Repack to ensure clean state
    subprocess.run(['git', 'gc', '--prune=now', '--aggressive'],
                   cwd=repo_path, capture_output=True, text=True)
    subprocess.run(['git', 'reflog', 'expire', '--expire=now', '--all'],
                   cwd=repo_path, capture_output=True, text=True)
    subprocess.run(['git', 'gc', '--prune=now'],
                   cwd=repo_path, capture_output=True, text=True)


def _get_files_sha256(repo_path):
    """Get SHA256 of all regular files in working tree."""
    result = {}
    for root_dir, dirs, files in os.walk(repo_path):
        # Skip .git directory
        if '.git' in root_dir.split(os.sep):
            continue
        for fname in sorted(files):
            fpath = os.path.join(root_dir, fname)
            relpath = os.path.relpath(fpath, repo_path)
            with open(fpath, 'rb') as f:
                h = hashlib.sha256(f.read()).hexdigest()
            result[relpath] = h
    return result


def _get_messages(repo_path):
    """Get git log messages newest to oldest."""
    result = subprocess.run(
        ['git', 'log', '--format=%s'],
        cwd=repo_path, capture_output=True, text=True
    )
    return [line for line in result.stdout.strip().split('\n') if line]


def transform(payload, contract):
    bundle_b64 = payload['bundle']
    scan_result = payload['scan']
    secret = scan_result['secret']

    with tempfile.TemporaryDirectory(prefix='cleaned_repo_') as tmpdir:
        _extract_repo(bundle_b64, tmpdir)
        _clean_repo(tmpdir, secret)

        # Verify secret is gone
        files = _get_files_sha256(tmpdir)
        messages = _get_messages(tmpdir)
        new_bundle = _pack_repo(tmpdir)

    return {
        "bundle": new_bundle,
        "files": files,
        "messages": messages
    }


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
