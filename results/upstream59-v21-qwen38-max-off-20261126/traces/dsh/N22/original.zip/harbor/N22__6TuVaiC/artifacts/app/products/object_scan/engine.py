"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import gzip
import tarfile
import io
import os
import subprocess
import tempfile
import re
from runtime import build


def _extract_repo(bundle_b64, dest):
    """Extract a gzip-tar base64 bundle into dest directory."""
    raw = base64.b64decode(bundle_b64)
    gz = gzip.decompress(raw)
    tf = tarfile.open(fileobj=io.BytesIO(gz))
    tf.extractall(dest, filter='data')


def _find_secret(repo_path):
    """Enumerate all git objects, find unreachable ones containing secret[...]."""
    objects_dir = os.path.join(repo_path, '.git', 'objects')
    all_objects = []
    for d in os.listdir(objects_dir):
        if len(d) == 2 and d not in ('pack', 'info'):
            dpath = os.path.join(objects_dir, d)
            if os.path.isdir(dpath):
                for f in os.listdir(dpath):
                    all_objects.append(d + f)

    # Get reachable objects
    result = subprocess.run(
        ['git', 'rev-list', '--all', '--objects'],
        cwd=repo_path, capture_output=True, text=True
    )
    reachable = set()
    for line in result.stdout.strip().split('\n'):
        if line:
            reachable.add(line.split()[0])

    unreachable = [o for o in all_objects if o not in reachable]

    # Search unreachable objects for secret[...] pattern
    pattern = re.compile(rb'secret\[.*?\]')
    for obj in unreachable:
        result = subprocess.run(
            ['git', 'cat-file', '-p', obj],
            cwd=repo_path, capture_output=True
        )
        matches = pattern.findall(result.stdout)
        if matches:
            return matches[0].decode('utf-8')

    return None


def transform(payload, contract):
    bundle_b64 = payload['bundle']
    with tempfile.TemporaryDirectory(prefix='object_scan_') as tmpdir:
        _extract_repo(bundle_b64, tmpdir)
        secret = _find_secret(tmpdir)
    return {"secret": secret}


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
