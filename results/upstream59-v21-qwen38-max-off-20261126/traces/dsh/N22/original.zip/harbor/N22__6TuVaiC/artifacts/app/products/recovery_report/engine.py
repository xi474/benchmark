"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import gzip
import tarfile
import io
import os
import subprocess
import tempfile
import re
from runtime import build


def _extract_repo(bundle_b64, dest):
    """Extract a gzip-tar base64 bundle into dest directory."""
    raw = base64.b64decode(bundle_b64)
    gz = gzip.decompress(raw)
    tf = tarfile.open(fileobj=io.BytesIO(gz))
    tf.extractall(dest, filter='data')


def _count_secret_objects(repo_path):
    """Enumerate ALL git objects and count those containing secret[...]."""
    pattern = re.compile(rb'secret\[.*?\]')
    count = 0

    # Check loose objects
    objects_dir = os.path.join(repo_path, '.git', 'objects')
    for d in os.listdir(objects_dir):
        if len(d) == 2 and d not in ('pack', 'info'):
            dpath = os.path.join(objects_dir, d)
            if os.path.isdir(dpath):
                for f in os.listdir(dpath):
                    obj_hash = d + f
                    result = subprocess.run(
                        ['git', 'cat-file', '-p', obj_hash],
                        cwd=repo_path, capture_output=True
                    )
                    if pattern.search(result.stdout):
                        count += 1

    # Check packed objects
    pack_dir = os.path.join(objects_dir, 'pack')
    if os.path.isdir(pack_dir):
        idx_files = [f for f in os.listdir(pack_dir) if f.endswith('.idx')]
        for idx_file in idx_files:
            pack_name = idx_file.replace('.idx', '.pack')
            pack_path = os.path.join(pack_dir, pack_name)
            if os.path.exists(pack_path):
                # List all objects in the pack
                result = subprocess.run(
                    ['git', 'verify-pack', '-v', os.path.join(pack_dir, idx_file)],
                    cwd=repo_path, capture_output=True, text=True
                )
                for line in result.stdout.split('\n'):
                    parts = line.split()
                    if len(parts) >= 2 and len(parts[0]) == 40:
                        obj_hash = parts[0]
                        result2 = subprocess.run(
                            ['git', 'cat-file', '-p', obj_hash],
                            cwd=repo_path, capture_output=True
                        )
                        if pattern.search(result2.stdout):
                            count += 1

    return count


def transform(payload, contract):
    scan_result = payload['scan']
    cleaned_result = payload['cleaned']

    secret = scan_result['secret']
    files = cleaned_result['files']
    messages = cleaned_result['messages']

    # Verify by actually reading the cleaned repo
    with tempfile.TemporaryDirectory(prefix='recovery_report_') as tmpdir:
        _extract_repo(cleaned_result['bundle'], tmpdir)
        remaining = _count_secret_objects(tmpdir)

    return {
        "secret": secret,
        "files": files,
        "messages": messages,
        "remaining_secret_objects": remaining
    }


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
