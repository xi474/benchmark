"""Implement the project entry point using the published business contracts."""
import json
import sys
from pathlib import Path

# Add workspace root to path so we can import runtime and engines
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from runtime import read as read_json, emit, payload_for


def load_contract(component_name):
    """Load a component's contract.json."""
    contract_path = ROOT / "products" / component_name / "contract.json"
    return read_json(contract_path)


def load_engine(component_name):
    """Dynamically load a component's engine module."""
    from runtime import module
    engine_path = ROOT / "products" / component_name / "engine.py"
    return module(str(ROOT), str(engine_path.relative_to(ROOT)))


def main():
    # Ensure outputs directory exists
    (ROOT / "outputs").mkdir(parents=True, exist_ok=True)

    # Load delivery manifest
    delivery = read_json(ROOT / "delivery.json")

    # Execution order based on dependencies:
    # 1. object_scan (depends only on inputs/request.json)
    # 2. cleaned_repo (depends on inputs/request.json + object_scan output)
    # 3. recovery_report (depends on object_scan + cleaned_repo outputs)

    results = {}

    # Step 1: object_scan
    print("Running object_scan...")
    contract = load_contract("object_scan")
    engine = load_engine("object_scan")
    result = engine.build_component(str(ROOT), contract)
    results["object_scan"] = result
    print(f"  Secret found: {result['secret']}")

    # Step 2: cleaned_repo
    print("Running cleaned_repo...")
    contract = load_contract("cleaned_repo")
    engine = load_engine("cleaned_repo")
    result = engine.build_component(str(ROOT), contract)
    results["cleaned_repo"] = result
    print(f"  Files: {list(result['files'].keys())}")
    print(f"  Messages: {result['messages']}")

    # Step 3: recovery_report
    print("Running recovery_report...")
    contract = load_contract("recovery_report")
    engine = load_engine("recovery_report")
    result = engine.build_component(str(ROOT), contract)
    results["recovery_report"] = result
    print(f"  Remaining secret objects: {result['remaining_secret_objects']}")

    # Write final_report.json
    result_file_path = delivery["result_file"]
    result_value = read_json(ROOT / result_file_path)

    final_report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value
    }

    final_report_path = ROOT / delivery["report"]
    final_report_path.parent.mkdir(parents=True, exist_ok=True)
    final_report_path.write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )
    print(f"\nFinal report written to {final_report_path}")
    print("Done!")


if __name__ == '__main__':
    main()
