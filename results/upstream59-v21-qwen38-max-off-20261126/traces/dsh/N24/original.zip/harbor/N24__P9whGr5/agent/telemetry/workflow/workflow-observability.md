# Workflow 可观测性报告

- Trial：`N24__P9whGr5__env`
- Task：`N24`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（31 节点 / 30 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：31；执行边：30（observed=0，inferred=30）
- Execution Trace Graph：`observed`；temporal_next 边 30，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_17cfe3b6753f4d6bb36fba2b -> tool:dsh:lead:call_c81f68bcc860486b9ecc3900 -> tool:dsh:lead:call_4059d8317793414cac4107fd -> tool:dsh:lead:call_74a85f908ee6421f8993bd45 -> tool:dsh:lead:call_d0752740d64d46f9b737d768 -> tool:dsh:lead:call_18ab0fdca5a34f7ea025c864 -> tool:dsh:lead:call_0000916b824f4b22b0441afb -> tool:dsh:lead:call_6e49d0906c1347919684d567 -> tool:dsh:lead:call_e19555d2174149df91935403 -> tool:dsh:lead:call_6b6468e94247465eaea9a0d2 -> tool:dsh:lead:call_1b74f49111a449dc9753d9ff -> tool:dsh:lead:call_43541c01cb9741b29d678f77 -> tool:dsh:lead:call_299fdb419bdf4eb895f49219 -> tool:dsh:lead:call_d8ca05702617403fb0766483 -> tool:dsh:lead:call_1e2ddc3d761445268c2befb5 -> tool:dsh:lead:call_85c0d0c96e0d44bbb020b5a0 -> tool:dsh:lead:call_304c8315251742f296a5b647 -> tool:dsh:lead:call_51074b5ad32d4475b02aa000 -> tool:dsh:lead:call_43109a71fa4440bcb9217ece -> tool:dsh:lead:call_14c02d8120a14d1d9e22fa7d -> tool:dsh:lead:call_8e6c3f6ce2c54181a9d5cd9a -> tool:dsh:lead:call_8688c026b38c4b8ea54f6480 -> tool:dsh:lead:call_ede6c0f0cd044d4fbf2c13ff -> tool:dsh:lead:call_2c17678c497b46c8ab89505a -> tool:dsh:lead:call_f5075d1f7fb84cb398ed7fd9 -> tool:dsh:lead:call_6434cbc4df6e4db682d6bd7f -> tool:dsh:lead:call_fc1ad282777f49269a56a14e -> tool:dsh:lead:call_8c800fe9e9e14a368ea15aa7 -> tool:dsh:lead:call_eba67190e1d54aa9ab6f6cbc -> tool:dsh:lead:call_810479a082f0449b895b03bc
- 关键路径耗时：0.491
- Makespan：104.428
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
