"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    text = payload["text"]
    records = []
    record_len = 34
    for i in range(0, len(text), record_len):
        rec = text[i:i+record_len]
        if len(rec) < record_len:
            break
        acc_id = rec[0:4]
        name = rec[4:24].rstrip()
        balance = int(rec[24:34])
        records.append({"id": acc_id, "name": name, "balance": balance})
    return records

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
