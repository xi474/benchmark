"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    accounts = payload["accounts"]  # list of {id, name, balance}
    books = payload["books"]        # list of {id, title, owner}
    orders = payload["orders"]      # list of {buyer, seller, book, amount}
    journal = payload["journal"]    # string (initially empty or existing)

    # Build lookup maps
    acc_map = {a["id"]: a for a in accounts}
    book_map = {b["id"]: b for b in books}

    statuses = []
    for order in orders:
        buyer_id = order["buyer"]
        seller_id = order["seller"]
        book_id = order["book"]
        amount = order["amount"]

        buyer_acc = acc_map.get(buyer_id)
        seller_acc = acc_map.get(seller_id)
        book_rec = book_map.get(book_id)

        # Check validity: all exist, buyer != seller, positive amount, sufficient balance, owner == seller
        if (buyer_acc and seller_acc and book_rec
                and buyer_id != seller_id
                and amount > 0
                and buyer_acc["balance"] >= amount
                and book_rec["owner"] == seller_id):
            # Execute transfer
            buyer_acc["balance"] -= amount
            seller_acc["balance"] += amount
            book_rec["owner"] = buyer_id
            # Append to journal: book4 + amount10 + seller4 + buyer4
            journal += f"{book_id}{amount:010d}{seller_id}{buyer_id}"
            statuses.append("accepted")
        else:
            statuses.append("rejected")

    # Re-encode accounts as fixed-length string
    accounts_str = ""
    for a in accounts:
        accounts_str += f"{a['id']}{a['name']:<20s}{a['balance']:010d}"

    # Re-encode books as fixed-length string
    books_str = ""
    for b in books:
        books_str += f"{b['id']}{b['title']:<20s}{b['owner']}"

    return {
        "accounts": accounts_str,
        "books": books_str,
        "journal": journal,
        "statuses": statuses
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
