"""Project entry point: orchestrate components and produce final_report.json."""
import json
import sys
from pathlib import Path

# Ensure /app is on sys.path so runtime and products can be imported
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from runtime import module, read


def main():
    # Load delivery manifest
    delivery = read(ROOT / "delivery.json")

    # Component execution order: accounts, books, orders first (no deps), then settlement
    component_order = ["accounts", "books", "orders", "settlement"]

    results = {}
    for comp_name in component_order:
        contract_path = ROOT / "products" / comp_name / "contract.json"
        contract = read(contract_path)
        engine = module(ROOT, f"products/{comp_name}/engine.py")
        result = engine.build_component(str(ROOT), contract)
        results[comp_name] = result

    # Read the result_file (settlement output)
    result_file_path = ROOT / delivery["result_file"]
    result_value = read(result_file_path)

    # Build final report
    report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value
    }

    # Write final report
    report_path = ROOT / delivery["report"]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )


if __name__ == '__main__':
    main()
