import re

MONTH_MAP = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _strip_non_alnum(s):
    """Lowercase and remove all non-alphanumeric characters."""
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    """Keep only digits."""
    if not s:
        return ""
    return re.sub(r'[^0-9]', '', s)


def _parse_internet_date(s):
    """Parse MM/DD/YYYY to YYYY-MM-DD."""
    if not s:
        return ""
    parts = s.strip().split('/')
    if len(parts) == 3:
        mm, dd, yyyy = parts
        return f"{yyyy}-{mm.zfill(2)}-{dd.zfill(2)}"
    return ""


def _parse_streaming_date(s):
    """Parse DD Mon YYYY to YYYY-MM-DD."""
    if not s:
        return ""
    parts = s.strip().split()
    if len(parts) == 3:
        dd, mon, yyyy = parts
        mm = MONTH_MAP.get(mon.lower()[:3], '')
        if mm:
            return f"{yyyy}-{mm}-{dd.zfill(2)}"
    return ""


def _split_name(name_str):
    """Split 'first last' into (first, last). Handles multi-word by taking first token as first, rest as last."""
    if not name_str:
        return ("", "")
    parts = name_str.strip().split()
    if len(parts) == 1:
        return (_strip_non_alnum(parts[0]), "")
    first = parts[0]
    last = " ".join(parts[1:])
    return (_strip_non_alnum(first), _strip_non_alnum(last))


def compute(payload):
    """标准化 ('internet', 'streaming') 渠道记录，返回 [原位置,字段对象] 数组。"""
    records = payload.get("records", [])
    result = []

    for idx, rec in enumerate(records):
        source = rec.get("source", "")
        if source not in ("internet", "streaming"):
            continue

        fields = rec.get("fields", {})
        rec_id = rec.get("id", "")

        if source == "internet":
            # full_name: "first last"
            first, last = _split_name(fields.get("full_name", ""))
            # birth_date: MM/DD/YYYY
            dob = _parse_internet_date(fields.get("birth_date", ""))
            # mail -> mail
            mail = _strip_non_alnum(fields.get("mail", ""))
            # tel -> phone
            phone = _digits_only(fields.get("tel", ""))
            # street -> address
            address = _strip_non_alnum(fields.get("street", ""))
            ssn = ""

        elif source == "streaming":
            # customer: "first last"
            first, last = _split_name(fields.get("customer", ""))
            # date_of_birth: DD Mon YYYY
            dob = _parse_streaming_date(fields.get("date_of_birth", ""))
            # email -> mail
            mail = _strip_non_alnum(fields.get("email", ""))
            # telephone -> phone
            phone = _digits_only(fields.get("telephone", ""))
            # address -> address
            address = _strip_non_alnum(fields.get("address", ""))
            ssn = ""

        obj = {
            "id": rec_id,
            "first": first,
            "last": last,
            "dob": dob,
            "ssn": ssn,
            "mail": mail,
            "phone": phone,
            "address": address,
        }
        result.append([idx, obj])

    return result
