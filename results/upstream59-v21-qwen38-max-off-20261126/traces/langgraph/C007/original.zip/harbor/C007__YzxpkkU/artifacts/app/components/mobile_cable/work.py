import re


def _clean_text(value):
    """Lowercase and remove all non-alphanumeric characters."""
    if not value:
        return ""
    return re.sub(r'[^a-z0-9]', '', value.lower())


def _digits_only(value):
    """Keep only digit characters."""
    if not value:
        return ""
    return re.sub(r'[^0-9]', '', value)


def _parse_mobile(record):
    """Normalize a mobile source record."""
    f = record.get("fields", {})
    return {
        "id": record["id"],
        "first": _clean_text(f.get("first", "")),
        "last": _clean_text(f.get("last", "")),
        "dob": f.get("dob", ""),  # Already YYYY-MM-DD
        "ssn": _digits_only(f.get("ssn", "")),
        "mail": _clean_text(f.get("email", "")),
        "phone": _digits_only(f.get("phone", "")),
        "address": _clean_text(f.get("address", "")),
    }


def _parse_cable(record):
    """Normalize a cable source record."""
    f = record.get("fields", {})

    # last_first is "last,first"
    last_first = f.get("last_first", "")
    if "," in last_first:
        parts = last_first.split(",", 1)
        last = parts[0].strip()
        first = parts[1].strip()
    else:
        last = last_first.strip()
        first = ""

    # birth is YYYYMMDD -> YYYY-MM-DD
    birth_raw = f.get("birth", "")
    if len(birth_raw) == 8 and birth_raw.isdigit():
        dob = f"{birth_raw[:4]}-{birth_raw[4:6]}-{birth_raw[6:8]}"
    else:
        dob = birth_raw

    return {
        "id": record["id"],
        "first": _clean_text(first),
        "last": _clean_text(last),
        "dob": dob,
        "ssn": _digits_only(f.get("government_id", "")),
        "mail": _clean_text(f.get("contact", "")),
        "phone": _digits_only(f.get("phone", "")),
        "address": _clean_text(f.get("location", "")),
    }


def compute(payload):
    """Standardize ('mobile', 'cable') channel records.

    Returns [[original_index, field_object], ...] where field_object has keys:
    id, first, last, dob, ssn, mail, phone, address.
    Dates are ISO (YYYY-MM-DD), text is lowercase alphanumeric-only,
    phone and SSN are digits-only.
    """
    records = payload.get("records", [])
    result = []
    for idx, record in enumerate(records):
        source = record.get("source", "")
        if source == "mobile":
            result.append([idx, _parse_mobile(record)])
        elif source == "cable":
            result.append([idx, _parse_cable(record)])
    return result
