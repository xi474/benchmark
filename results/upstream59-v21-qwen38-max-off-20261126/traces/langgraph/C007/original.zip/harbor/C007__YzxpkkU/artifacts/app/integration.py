"""Integration module: merge normalized records from two components, generate
match candidates via blocking, and cluster with union-find."""


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract.

    left  = mobile_cable result:   [[orig_idx, {id,first,last,dob,ssn,mail,phone,address}], ...]
    right = internet_streaming result: same shape
    Returns {"clusters": [[record_id, ...], ...]}
    """
    # Merge all normalized records
    all_records = []
    for item in left:
        all_records.append(item[1])
    for item in right:
        all_records.append(item[1])

    ambiguous_names = set(n.lower() for n in payload.get("ambiguous_names", []))

    # Build index by id
    rec_by_id = {r["id"]: r for r in all_records}
    ids = [r["id"] for r in all_records]
    n = len(ids)
    id_to_idx = {rid: i for i, rid in enumerate(ids)}

    # Union-Find
    parent = list(range(n))
    uf_rank = [0] * n

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return
        if uf_rank[ra] < uf_rank[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        if uf_rank[ra] == uf_rank[rb]:
            uf_rank[ra] += 1

    # ---- Helper functions ----

    def is_ambiguous(name):
        return name in ambiguous_names

    def ssn_matches(a_ssn, b_ssn):
        """Check if two SSNs could refer to the same person."""
        if not a_ssn or not b_ssn:
            return False
        la, lb = len(a_ssn), len(b_ssn)
        if la == 9 and lb == 9:
            return a_ssn == b_ssn
        if la == 4 and lb == 9:
            return a_ssn == b_ssn[-4:]
        if la == 9 and lb == 4:
            return a_ssn[-4:] == b_ssn
        if la == 4 and lb == 4:
            return a_ssn == b_ssn
        shorter, longer = (a_ssn, b_ssn) if la <= lb else (b_ssn, a_ssn)
        return longer.endswith(shorter)

    def email_edit_distance_le1(a, b):
        """Check if two emails differ by at most 1 edit."""
        if a == b:
            return True
        la, lb = len(a), len(b)
        if abs(la - lb) > 1:
            return False
        if la == lb:
            diffs = 0
            for i in range(la):
                if a[i] != b[i]:
                    diffs += 1
                    if diffs > 1:
                        return False
            return True
        shorter, longer = (a, b) if la < lb else (b, a)
        ls, ll = len(shorter), len(longer)
        i = 0
        while i < ls and shorter[i] == longer[i]:
            i += 1
        return shorter[i:] == longer[i + 1:]

    def emails_compatible(a_mail, b_mail):
        """Check if two emails could belong to the same person (exact or edit distance 1)."""
        if not a_mail or not b_mail:
            return False
        return email_edit_distance_le1(a_mail, b_mail)

    def names_compatible(a_first, b_first, a_last, b_last):
        """Check if two name pairs could refer to the same person."""
        if a_last != b_last:
            return False
        if a_first == b_first:
            return True
        a_amb = is_ambiguous(a_first)
        b_amb = is_ambiguous(b_first)
        if a_amb and b_amb:
            return False  # Both ambiguous - can't determine from name alone
        if a_amb or b_amb:
            return True  # One ambiguous could expand to the other
        return False  # Different non-ambiguous full names

    def strong_name_match(a_first, b_first):
        """Both are the same non-ambiguous full name."""
        return a_first == b_first and not is_ambiguous(a_first)

    def should_merge(ra, rb):
        """Decide if two records should be merged (same person)."""
        # Must have compatible names
        if not names_compatible(ra["first"], rb["first"], ra["last"], rb["last"]):
            return False

        # Compute evidence signals
        ssn_match = ssn_matches(ra["ssn"], rb["ssn"])
        mail_compat = emails_compatible(ra["mail"], rb["mail"])
        mail_exact = (ra["mail"] and rb["mail"] and ra["mail"] == rb["mail"])
        phone_match = (ra["phone"] and rb["phone"] and ra["phone"] == rb["phone"])
        addr_match = (ra["address"] and rb["address"] and ra["address"] == rb["address"])
        dob_match = (ra["dob"] and rb["dob"] and ra["dob"] == rb["dob"])
        strong_name = strong_name_match(ra["first"], rb["first"])

        a_amb = is_ambiguous(ra["first"])
        b_amb = is_ambiguous(rb["first"])

        # Case 1: Same non-ambiguous first name + same last
        if strong_name:
            if dob_match:
                return True
            if ssn_match:
                return True
            if mail_compat and phone_match:
                return True
            return False

        # Case 2: Both ambiguous (e.g., pat vs pat, robbie vs robbie)
        if a_amb and b_amb:
            # Need very strong evidence since both names are ambiguous
            if not dob_match:
                return False
            # DOB matches + identity-level evidence
            if ssn_match:
                return True
            if mail_compat:
                return True
            return False

        # Case 3: One ambiguous, one full name
        if a_amb or b_amb:
            if not dob_match:
                return False
            # DOB matches - need identity confirmation
            if ssn_match:
                return True
            if mail_compat:
                return True
            # phone+address alone are household-level, not sufficient
            return False

        # Case 4: Different non-ambiguous names - already filtered by names_compatible
        return False

    # ---- Generate candidate pairs via blocking ----
    candidate_pairs = set()

    def add_block_pairs(block_dict):
        for block_ids in block_dict.values():
            if len(block_ids) > 1:
                for i in range(len(block_ids)):
                    for j in range(i + 1, len(block_ids)):
                        pair = (block_ids[i], block_ids[j]) if block_ids[i] < block_ids[j] else (block_ids[j], block_ids[i])
                        candidate_pairs.add(pair)

    # Block 1: SSN full 9-digit
    blocks = {}
    for r in all_records:
        if len(r["ssn"]) == 9:
            blocks.setdefault(r["ssn"], []).append(r["id"])
    add_block_pairs(blocks)

    # Block 2: SSN last 4
    blocks = {}
    for r in all_records:
        ssn = r["ssn"]
        if len(ssn) >= 4:
            blocks.setdefault(ssn[-4:], []).append(r["id"])
    add_block_pairs(blocks)

    # Block 3: Email exact
    blocks = {}
    for r in all_records:
        if r["mail"]:
            blocks.setdefault(r["mail"], []).append(r["id"])
    add_block_pairs(blocks)

    # Block 4: Phone + last name
    blocks = {}
    for r in all_records:
        if r["phone"] and r["last"]:
            blocks.setdefault((r["phone"], r["last"]), []).append(r["id"])
    add_block_pairs(blocks)

    # Block 5: DOB + last name
    blocks = {}
    for r in all_records:
        if r["dob"] and r["last"]:
            blocks.setdefault((r["dob"], r["last"]), []).append(r["id"])
    add_block_pairs(blocks)

    # Block 6: Phone + DOB
    blocks = {}
    for r in all_records:
        if r["phone"] and r["dob"]:
            blocks.setdefault((r["phone"], r["dob"]), []).append(r["id"])
    add_block_pairs(blocks)

    # Block 7: Address + last name + DOB
    blocks = {}
    for r in all_records:
        if r["address"] and r["last"] and r["dob"]:
            blocks.setdefault((r["address"], r["last"], r["dob"]), []).append(r["id"])
    add_block_pairs(blocks)

    # Block 8: Email approximate (for edit distance 1 detection)
    # Group emails by overlapping prefixes/suffixes to catch single-char differences
    # Use multiple prefix lengths to ensure coverage
    for prefix_len in [3, 5, 8]:
        blocks = {}
        for r in all_records:
            if r["mail"] and len(r["mail"]) > prefix_len:
                blocks.setdefault(r["mail"][:prefix_len], []).append(r["id"])
        add_block_pairs(blocks)

    # Also group by suffix
    for suffix_len in [5, 8]:
        blocks = {}
        for r in all_records:
            if r["mail"] and len(r["mail"]) > suffix_len:
                blocks.setdefault(r["mail"][-suffix_len:], []).append(r["id"])
        add_block_pairs(blocks)

    # Evaluate all candidate pairs
    for id_a, id_b in candidate_pairs:
        ra = rec_by_id[id_a]
        rb = rec_by_id[id_b]
        if should_merge(ra, rb):
            union(id_to_idx[id_a], id_to_idx[id_b])

    # Build clusters
    clusters_map = {}
    for i in range(n):
        root = find(i)
        clusters_map.setdefault(root, []).append(ids[i])

    clusters = list(clusters_map.values())
    return {"clusters": clusters}
