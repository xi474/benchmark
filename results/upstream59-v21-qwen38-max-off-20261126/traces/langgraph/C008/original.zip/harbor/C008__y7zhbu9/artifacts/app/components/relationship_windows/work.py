def compute(payload):
    """将链接和合并登记为 [起点,终点,生效时刻,失效时刻]。保留原顺序并补齐缺省区间。"""
    DEFAULT_FROM = 0
    DEFAULT_TO = 10 ** 18

    result = []

    for link in payload.get("links", []):
        result.append([
            link["a"],
            link["b"],
            link.get("from", DEFAULT_FROM),
            link.get("to", DEFAULT_TO),
        ])

    for merge in payload.get("merges", []):
        result.append([
            merge["a"],
            merge["b"],
            merge.get("from", DEFAULT_FROM),
            merge.get("to", DEFAULT_TO),
        ])

    return result
