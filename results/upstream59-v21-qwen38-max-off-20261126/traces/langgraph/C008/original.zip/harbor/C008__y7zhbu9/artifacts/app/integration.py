import json
import hashlib


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    seed = payload["seed"]

    # left: list of [start, end, effective_time, expiry_time]
    #   where start/end are [tenant, subject]
    # right: list of [table_name, id, time, [tenant, subject]]

    # For each record, find valid windows at that record's time,
    # build undirected graph, find connected components,
    # pick canonical (lex-smallest (tenant,subject)), generate token.

    result_records = []

    for rec in right:
        table_name, rec_id, rec_time, subject_pair = rec
        tenant, subject = subject_pair

        # Collect all valid edges at this record's time
        # An edge is valid if effective_time <= rec_time < expiry_time
        edges = []
        for window in left:
            start, end, eff_time, exp_time = window
            if eff_time <= rec_time < exp_time:
                edges.append((tuple(start), tuple(end)))

        # Build adjacency and find connected component containing this record's subject
        # Use Union-Find for efficiency
        nodes = set()
        nodes.add((tenant, subject))
        for a, b in edges:
            nodes.add(a)
            nodes.add(b)

        parent = {n: n for n in nodes}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            rx, ry = find(x), find(y)
            if rx != ry:
                parent[rx] = ry

        for a, b in edges:
            union(a, b)

        # Find all nodes in the same component as this record's subject
        root = find((tenant, subject))
        component_nodes = [n for n in nodes if find(n) == root]

        # Canonical = lexicographically smallest (tenant, subject) tuple
        canonical = min(component_nodes)
        canonical_tenant, canonical_subject = canonical

        # Generate token
        raw = json.dumps(
            [str(seed), canonical_tenant, canonical_subject],
            ensure_ascii=True,
            separators=(',', ':')
        )
        sha = hashlib.sha256(raw.encode('utf-8')).hexdigest()[:12]
        token = 'ref_' + sha

        result_records.append({
            "table": table_name,
            "id": rec_id,
            "time": rec_time,
            "token": token
        })

    return {"records": result_records}
