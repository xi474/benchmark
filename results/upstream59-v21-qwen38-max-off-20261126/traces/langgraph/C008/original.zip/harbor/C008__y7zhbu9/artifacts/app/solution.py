"""Solution for C008 – cross-tenant validity-window anonymisation."""

import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file and return the parsed object."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def transform(payload):
    """Run the full pipeline in-memory without touching disk.

    Wires the two business components (relationship_windows, record_subjects)
    into integration.combine and returns the final result dict.
    """
    from components.relationship_windows.work import compute as rw_compute
    from components.record_subjects.work import compute as rs_compute
    from integration import combine

    # Project payload fields expected by each component
    left = rw_compute({"links": payload.get("links", []),
                       "merges": payload.get("merges", [])})
    right = rs_compute({"records": payload.get("records", [])})

    return combine(payload, left, right)


def build_component(input_path, output_path):
    """Read input, compute the full result independently, write it, and return it.

    Must work even when no previous artefacts exist on disk.
    """
    payload = load_payload(input_path)
    result = transform(payload)

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    return result
