"""Integration: combine component results and run round-by-round scheduling."""

import itertools


def combine(payload, left, right):
    """
    payload: full input dict
    left: sorted events list (from visible_events component)
    right: dict vehicle_id -> [driver_ids] (from crew_compatibility component)
    Returns the rounds output as specified.
    """
    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    rounds_spec = payload["rounds"]

    # Build event index
    sorted_events = left  # already sorted by (visible, id)
    compat = right  # vehicle_id -> [driver_ids]

    # State tracking
    committed = []  # list of assignment dicts that are permanently locked
    cancelled_set = set()  # job ids that have been cancelled
    assigned_job_ids = set()  # job ids that have been assigned (committed or tentative)

    result_rounds = []

    for rnd in rounds_spec:
        cutoff = rnd["cutoff"]
        do_commit = rnd["commit"]

        # Determine visible events up to this cutoff
        visible_events = [e for e in sorted_events if e["visible"] <= cutoff]

        # Collect all known jobs and cancel requests up to this cutoff
        known_jobs = {}  # job_id -> job dict
        cancel_requests = []  # list of job_ids to cancel

        for ev in visible_events:
            if ev["kind"] == "request":
                known_jobs[ev["job"]["id"]] = ev["job"]
            elif ev["kind"] == "cancel":
                cancel_requests.append(ev["job"])

        # Process cancellations
        new_cancelled = []
        ignored_cancellations = []

        for cjob_id in cancel_requests:
            if cjob_id in cancelled_set:
                continue  # already cancelled, skip (dedup)
            if cjob_id not in known_jobs:
                continue  # job hasn't appeared yet, ignore? Actually spec says "cancel引用已出现的job"
            
            # Check if this job has been committed and start < cutoff
            committed_for_job = [a for a in committed if a["job"] == cjob_id]
            if committed_for_job:
                # Job is committed. Check if start < cutoff
                any_started = any(a["start"] < cutoff for a in committed_for_job)
                if any_started:
                    ignored_cancellations.append(cjob_id)
                else:
                    # Remove from committed (task hasn't started)
                    committed = [a for a in committed if a["job"] != cjob_id]
                    assigned_job_ids.discard(cjob_id)
                    cancelled_set.add(cjob_id)
                    new_cancelled.append(cjob_id)
            else:
                # Not committed, just mark cancelled
                cancelled_set.add(cjob_id)
                new_cancelled.append(cjob_id)

        # Deduplicate and sort cancelled lists
        all_cancelled = sorted(set(new_cancelled))
        ignored_cancellations = sorted(set(ignored_cancellations))

        # Determine pending jobs: known, not cancelled, not already committed
        pending_jobs = []
        for jid, job in known_jobs.items():
            if jid in cancelled_set:
                continue
            if jid in assigned_job_ids:
                continue  # already committed
            pending_jobs.append(job)

        # Now optimize: find best set of new assignments for pending jobs
        # given the already-committed assignments as fixed constraints.
        best = _optimize(
            pending_jobs, committed, vehicles, drivers, suppliers,
            compat, cutoff
        )

        new_assignments = best["assignments"]

        if do_commit:
            committed = committed + new_assignments
            for a in new_assignments:
                assigned_job_ids.add(a["job"])
            # After commit, assignments = committed (which now includes new ones)
            all_assignments = list(committed)
        else:
            # Non-commit: assignments = previously committed + tentative new ones
            all_assignments = list(committed) + list(new_assignments)
        
        # Sort by (job, start, vehicle, driver, supplier)
        all_assignments_sorted = sorted(
            all_assignments,
            key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])
        )

        total_profit = sum(a["profit"] for a in all_assignments_sorted)

        result_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments_sorted,
            "profit": total_profit,
            "cancelled": all_cancelled,
            "ignored_cancellations": ignored_cancellations,
        })

    return {"rounds": result_rounds}


def _optimize(pending_jobs, committed, vehicles, drivers, suppliers, compat, cutoff):
    """
    Find the optimal set of new assignments for pending jobs.
    Maximize total profit, then maximize count, then lex-min sorted tuple list.
    """
    if not pending_jobs:
        return {"assignments": [], "profit": 0, "count": 0}

    # Generate all feasible single-job options
    # Each option: (job, vehicle, driver, supplier, start, end, quantity, profit)
    job_options = {}
    for job in pending_jobs:
        opts = _generate_options(job, vehicles, drivers, suppliers, compat, cutoff)
        job_options[job["id"]] = opts

    # Try all subsets of pending jobs (power set), for each subset try all combos
    best_result = {"assignments": [], "profit": 0, "count": 0, "sort_key": []}

    n = len(pending_jobs)
    # Enumerate subsets by size descending for early pruning isn't needed given small n
    for size in range(n, 0, -1):
        for job_subset in itertools.combinations(range(n), size):
            subset_jobs = [pending_jobs[i] for i in job_subset]
            # Try all combinations of options for these jobs
            option_lists = [job_options[j["id"]] for j in subset_jobs]
            if any(len(ol) == 0 for ol in option_lists):
                continue  # some job has no feasible option

            for combo in itertools.product(*option_lists):
                # Check mutual compatibility (no time overlap for vehicle/driver, supplier stock)
                result = _check_combo(combo, committed, vehicles, drivers, suppliers)
                if result is None:
                    continue

                assignments, total_profit = result
                count = len(assignments)

                # Sort key for tie-breaking
                sort_key = _make_sort_key(assignments)

                # Compare: max profit, then max count, then min lex sort_key
                if (total_profit > best_result["profit"] or
                    (total_profit == best_result["profit"] and count > best_result["count"]) or
                    (total_profit == best_result["profit"] and count == best_result["count"] and sort_key < best_result["sort_key"])):
                    best_result = {
                        "assignments": assignments,
                        "profit": total_profit,
                        "count": count,
                        "sort_key": sort_key,
                    }

    return best_result


def _generate_options(job, vehicles, drivers, suppliers, compat, cutoff):
    """Generate all feasible (vehicle, driver, supplier, start, end, quantity, profit) for a job."""
    options = []
    jtype = job["type"]
    qty = job["quantity"]
    release = job["release"]
    deadline = job["deadline"]
    duration = job["duration"]
    revenue = job["revenue"]
    job_suppliers = job["suppliers"]

    min_start = max(cutoff, release)

    for vid, veh in vehicles.items():
        if veh["type"] != jtype:
            continue
        if veh["capacity"] < qty:
            continue

        # Compatible drivers for this vehicle
        compatible_drivers = compat.get(vid, [])

        for did in compatible_drivers:
            drv = drivers[did]

            for sid in job_suppliers:
                sup = suppliers[sid]
                if sup["stock"] < qty:
                    continue  # not enough stock globally (will check more precisely later)

                # start must be integer, start >= min_start
                # end = start + duration <= deadline
                # start <= sup["close"]
                max_start = min(deadline - duration, sup["close"])
                if max_start < min_start:
                    continue

                for start in range(min_start, max_start + 1):
                    end = start + duration
                    unit_cost = sup["unit_cost"]
                    profit = revenue - qty * unit_cost - veh["cost"] * duration

                    options.append({
                        "job": job["id"],
                        "vehicle": vid,
                        "driver": did,
                        "supplier": sid,
                        "start": start,
                        "end": end,
                        "quantity": qty,
                        "profit": profit,
                    })

    return options


def _check_combo(combo, committed, vehicles, drivers, suppliers):
    """
    Check if a combination of new assignments is feasible together with committed ones.
    Returns (assignments_list, total_profit) or None if infeasible.
    """
    new_assignments = list(combo)

    # Check vehicle time overlaps (among new + committed)
    all_assignments = committed + new_assignments

    # Vehicle overlap check
    vehicle_intervals = {}
    for a in all_assignments:
        vid = a["vehicle"]
        if vid not in vehicle_intervals:
            vehicle_intervals[vid] = []
        vehicle_intervals[vid].append((a["start"], a["end"]))

    for vid, intervals in vehicle_intervals.items():
        intervals_sorted = sorted(intervals)
        for i in range(len(intervals_sorted) - 1):
            if intervals_sorted[i][1] > intervals_sorted[i + 1][0]:
                return None  # overlap

    # Driver overlap check
    driver_intervals = {}
    for a in all_assignments:
        did = a["driver"]
        if did not in driver_intervals:
            driver_intervals[did] = []
        driver_intervals[did].append((a["start"], a["end"]))

    for did, intervals in driver_intervals.items():
        intervals_sorted = sorted(intervals)
        for i in range(len(intervals_sorted) - 1):
            if intervals_sorted[i][1] > intervals_sorted[i + 1][0]:
                return None  # overlap

    # Supplier stock check
    supplier_usage = {}
    for a in all_assignments:
        sid = a["supplier"]
        supplier_usage[sid] = supplier_usage.get(sid, 0) + a["quantity"]

    for sid, usage in supplier_usage.items():
        if usage > suppliers[sid]["stock"]:
            return None

    # Driver work hour constraints
    for did in driver_intervals:
        drv = drivers[did]
        tasks = sorted(driver_intervals[did])
        
        # Total work
        total_work = sum(e - s for s, e in tasks)
        if total_work > drv["max_work"]:
            return None

        # Continuous work with break logic
        max_continuous = drv["max_continuous"]
        brk = drv["break"]
        
        continuous = 0
        for i, (s, e) in enumerate(tasks):
            if i == 0:
                continuous = e - s
            else:
                prev_end = tasks[i - 1][1]
                gap = s - prev_end
                if gap >= brk:
                    continuous = e - s  # reset
                else:
                    continuous += (e - s)
            if continuous > max_continuous:
                return None

    total_profit = sum(a["profit"] for a in new_assignments)
    return (new_assignments, total_profit)


def _make_sort_key(assignments):
    """Create the sort key for tie-breaking: sorted list of (job,start,vehicle,driver,supplier) tuples."""
    tuples = sorted(
        (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])
        for a in assignments
    )
    return tuples
