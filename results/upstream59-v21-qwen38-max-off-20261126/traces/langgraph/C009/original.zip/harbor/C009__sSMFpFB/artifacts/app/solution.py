"""Solution entry points for C009."""

import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file and return the parsed object."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def transform(payload):
    """Run the full scheduling pipeline on the given payload and return the result."""
    from component_runtime import UNITS, project, evaluate_unit
    from integration import combine

    values = [evaluate_unit(name, project(payload, fields)) for name, fields in UNITS.items()]
    return combine(payload, *values)


def build_component(input_path, output_path):
    """Read input, compute result, write to output path, and return the result."""
    payload = load_payload(input_path)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    result = transform(payload)

    out.write_text(
        json.dumps(result, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    return result
