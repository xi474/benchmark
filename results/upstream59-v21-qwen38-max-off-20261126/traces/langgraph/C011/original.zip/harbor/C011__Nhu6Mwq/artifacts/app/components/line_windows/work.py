def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload["orders"]
    released = set(payload.get("released", []))
    routing = payload["routing"]
    lines = payload["lines"]
    wip_list = payload.get("wip", [])
    freeze = payload.get("freeze", 0)
    changeover = payload.get("changeover", 0)

    # Pre-compute per-line WIP end times (max end of all WIP on that line)
    # Actually we need the max end across all WIP tasks on each line
    line_wip_max_end = {}
    for w in wip_list:
        lid = w["line"]
        e = w["end"]
        if lid not in line_wip_max_end or e > line_wip_max_end[lid]:
            line_wip_max_end[lid] = e

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]

        # SKU must be in released
        if sku not in released:
            result[oid] = []
            continue

        # Duration
        r = routing[sku]
        duration = r["setup"] + r["per_unit"] * qty

        triples = []
        for line in lines:
            lid = line["id"]
            qualified = line.get("qualified", [])
            if sku not in qualified:
                continue

            windows = line.get("windows", [])
            # Minimum start due to WIP on this line
            wip_end = line_wip_max_end.get(lid, None)
            if wip_end is not None:
                min_start_wip = wip_end + changeover
            else:
                min_start_wip = 0

            for win in windows:
                w_start, w_end = win[0], win[1]
                # Task [start, end) must be fully within [w_start, w_end)
                # start >= max(freeze, w_start, min_start_wip)
                # end = start + duration <= min(w_end, due)
                lo = max(freeze, w_start, min_start_wip)
                hi = min(w_end, due) - duration  # start <= hi
                if hi < lo:
                    continue
                for s in range(lo, hi + 1):
                    e = s + duration
                    triples.append([lid, s, e])

        result[oid] = triples

    return result
