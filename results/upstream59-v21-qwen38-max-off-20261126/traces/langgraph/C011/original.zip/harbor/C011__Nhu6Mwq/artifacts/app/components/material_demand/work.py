def compute(payload):
    """按工单 ID 输出递归展开后的基础物料需求映射。"""
    orders = payload["orders"]
    bom = payload.get("bom", {})

    # Cache for expanded leaf demands per (material, multiplier)
    # We'll use memoization on material -> dict of leaf->qty
    cache = {}

    def expand(material, multiplier):
        """Recursively expand a material to leaf components with quantities."""
        if material not in bom:
            # Leaf material
            return {material: multiplier}

        if (material, multiplier) in cache:
            return cache[(material, multiplier)]

        result = {}
        for child, child_qty in bom[material].items():
            child_expanded = expand(child, child_qty * multiplier)
            for leaf, qty in child_expanded.items():
                result[leaf] = result.get(leaf, 0) + qty

        cache[(material, multiplier)] = result
        return result

    output = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        demand = expand(sku, qty)
        output[oid] = demand

    return output
