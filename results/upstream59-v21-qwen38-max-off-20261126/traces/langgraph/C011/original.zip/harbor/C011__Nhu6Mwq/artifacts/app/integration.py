"""Integration: combine material_demand and line_windows into final plan."""


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract."""
    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    orders = payload["orders"]
    orders_map = {o["id"]: o for o in orders}
    wip_list = payload.get("wip", [])
    lots = payload.get("lots", [])
    substitutes = payload.get("substitutes", {})

    pass_lots = [lot for lot in lots if lot["status"] == "PASS"]

    line_wips = {}
    for w in wip_list:
        line_wips.setdefault(w["line"], []).append(w)
    for lid in line_wips:
        line_wips[lid].sort(key=lambda w: (w["start"], w["end"]))

    feasible_orders = [o["id"] for o in orders if right.get(o["id"])]

    best_result = _solve(
        feasible_orders, right, left, orders_map, line_wips,
        changeover, pass_lots, substitutes,
    )

    if best_result is None:
        selected = []
        erp_orders = []
        mes_items = []
        wms_items = []
    else:
        selected_oids, assignments, allocation = best_result
        selected = sorted(selected_oids)

        # --- ERP ---
        erp_orders = []
        for oid in selected:
            o = orders_map[oid]
            line, start, end = assignments[oid]
            erp_orders.append({
                "wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
                "due": o["due"], "start": start, "end": end, "line": line,
                "status": "PLANNED", "parent": oid,
            })
        for w in wip_list:
            erp_orders.append({
                "wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
                "due": w["due"], "start": w["start"], "end": w["end"],
                "line": w["line"], "status": "WIP_CONT", "parent": None,
            })
        erp_orders.sort(key=lambda x: x["wo"])

        # --- MES ---
        mes_by_line = {}
        for oid in selected_oids:
            line, start, end = assignments[oid]
            o = orders_map[oid]
            mes_by_line.setdefault(line, []).append((start, oid, o["qty"], end))
        for w in wip_list:
            mes_by_line.setdefault(w["line"], []).append(
                (w["start"], w["id"], w["qty"], w["end"])
            )
        wip_ids = {w["id"] for w in wip_list}
        mes_items = []
        for lid in sorted(mes_by_line):
            tasks = sorted(mes_by_line[lid], key=lambda t: (t[0], t[1]))
            for seq_idx, (start, wo, qty, end) in enumerate(tasks, 1):
                mes_items.append({
                    "run": run_id, "line": lid, "seq": seq_idx, "wo": wo,
                    "qty": qty, "start": start, "end": end,
                    "status": "WIP_CONT" if wo in wip_ids else "PLANNED",
                })

        # --- WMS ---
        all_res = []
        for oid in selected_oids:
            for comp, lot_id, qty in allocation.get(oid, []):
                all_res.append((oid, comp, lot_id, qty))
        all_res.sort()
        wms_items = []
        for i, (wo, comp, lot_id, qty) in enumerate(all_res, 1):
            wms_items.append({
                "reservation": f"r{i:04d}", "run": run_id, "wo": wo,
                "component": comp, "lot": lot_id, "qty": qty,
                "status": "RESERVED",
            })

    return {
        "selected": selected,
        "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": erp_orders},
        "mes": mes_items,
        "wms": wms_items,
    }


# ---------------------------------------------------------------------------
# Solver
# ---------------------------------------------------------------------------

def _solve(feasible_orders, right, left, orders_map, line_wips,
           changeover, pass_lots, substitutes):
    n = len(feasible_orders)
    if n == 0:
        return None

    best = [None]

    for mask in range(1, 1 << n):
        sel_idx = [i for i in range(n) if mask & (1 << i)]
        sel_oids = [feasible_orders[i] for i in sel_idx]

        slot_lists = []
        ok = True
        for oid in sel_oids:
            triples = right.get(oid, [])
            if not triples:
                ok = False
                break
            slot_lists.append(triples)
        if not ok:
            continue

        _enum(sel_oids, slot_lists, 0, {},
              line_wips, changeover, left, pass_lots, substitutes, orders_map, best)

    if best[0] is None:
        return None
    return best[0][3]


def _enum(sel_oids, slot_lists, idx, cur,
          line_wips, changeover, left, pass_lots, subs, omap, best):
    if idx == len(sel_oids):
        if not _check_lines(cur, line_wips, changeover):
            return
        alloc = _find_lex_min_alloc(left, pass_lots, subs, sel_oids, cur)
        if alloc is None:
            return
        obj = _objective(sel_oids, cur, alloc, omap)
        if best[0] is None or _better(obj, best[0]):
            best[0] = obj + (
                (list(sel_oids), dict(cur),
                 {k: list(v) for k, v in alloc.items()}),
            )
        return

    oid = sel_oids[idx]
    for triple in slot_lists[idx]:
        line, start, end = triple
        cur[oid] = (line, start, end)
        _enum(sel_oids, slot_lists, idx + 1, cur,
              line_wips, changeover, left, pass_lots, subs, omap, best)
        del cur[oid]


def _check_lines(assignments, line_wips, changeover):
    by_line = {}
    for oid, (line, s, e) in assignments.items():
        by_line.setdefault(line, []).append((s, e))
    for line, tasks in by_line.items():
        all_t = [(w["start"], w["end"]) for w in line_wips.get(line, [])]
        all_t.extend(tasks)
        all_t.sort()
        for i in range(1, len(all_t)):
            if all_t[i][0] < all_t[i - 1][1] + changeover:
                return False
    return True


class _AllocSolver:
    """Finds lex-min allocation across orders with shared lot constraints."""

    def __init__(self, left, pass_lots, subs, sel_oids, assignments):
        self.sorted_oids = sorted(sel_oids)
        self.pass_lots = pass_lots
        self.subs = subs
        self.assignments = assignments
        self.left = left

        # Build flat demand list
        self.demands = []  # (oid, comp, qty, end)
        for oid in self.sorted_oids:
            _, _, end = assignments[oid]
            dem = left.get(oid, {})
            for comp in sorted(dem):
                q = dem[comp]
                if q > 0:
                    self.demands.append((oid, comp, q, end))

        # Precompute eligible lots per demand
        self.demand_eligible = []
        for oid, comp, qty, end in self.demands:
            mats = set(subs.get(comp, [comp]))
            elig = [l["id"] for l in pass_lots
                    if l["material"] in mats and l["expiry"] >= end]
            elig.sort()
            self.demand_eligible.append(elig)

        self.lot_rem_init = {l["id"]: l["qty"] for l in pass_lots}

    def solve(self):
        """Returns {oid: [(comp, lot, qty)]} or None."""
        if not self.demands:
            return {oid: [] for oid in self.sorted_oids}

        # Quick feasibility
        for i, (oid, comp, qty, end) in enumerate(self.demands):
            total = sum(self.lot_rem_init.get(lid, 0) for lid in self.demand_eligible[i])
            if total < qty:
                return None

        self.best = None  # (sched_key, alloc_dict)
        self._backtrack(0, dict(self.lot_rem_init), {})
        
        if self.best is None:
            return None
        return self.best[1]

    def _backtrack(self, di, lot_rem, current_alloc):
        if di == len(self.demands):
            sk = self._sched_key(current_alloc)
            if self.best is None or sk < self.best[0]:
                self.best = (sk, {k: list(v) for k, v in current_alloc.items()})
            return

        oid, comp, qty, end = self.demands[di]
        elig = self.demand_eligible[di]

        for dist in self._gen_lex_dists(qty, elig, lot_rem):
            new_rem = dict(lot_rem)
            for lid, take in dist:
                new_rem[lid] -= take

            if not self._can_satisfy(di + 1, new_rem):
                continue

            entries = [(comp, lid, take) for lid, take in dist]
            new_alloc = dict(current_alloc)
            if oid in new_alloc:
                new_alloc[oid] = new_alloc[oid] + entries
            else:
                new_alloc[oid] = entries

            # Pruning
            if self.best is not None:
                pk = self._sched_key_partial(new_alloc)
                bk = self.best[0]
                plen = len(pk)
                if pk > bk[:plen]:
                    continue

            self._backtrack(di + 1, new_rem, new_alloc)

    def _gen_lex_dists(self, qty, elig_lots, lot_rem):
        """Generate distributions in lex order of (comp, lot, take) entries."""
        if qty == 0:
            yield []
            return
        avail = [(lid, lot_rem.get(lid, 0)) for lid in elig_lots if lot_rem.get(lid, 0) > 0]
        if not avail:
            return
        yield from self._gen_rec(qty, avail, 0, [])

    def _gen_rec(self, remaining, avail, idx, current):
        if remaining == 0:
            yield list(current)
            return
        if idx >= len(avail):
            return

        lid, cap = avail[idx]
        already = sum(t for l, t in current if l == lid)
        max_take = min(cap - already, remaining)

        if max_take > 0:
            # Try take=1..max_take first (lex-smaller entries)
            for take in range(1, max_take + 1):
                current.append((lid, take))
                yield from self._gen_rec(remaining - take, avail, idx, current)
                current.pop()

        # Try skip this lot
        yield from self._gen_rec(remaining, avail, idx + 1, current)

    def _can_satisfy(self, from_idx, lot_rem):
        for j in range(from_idx, len(self.demands)):
            _, _, qty, _ = self.demands[j]
            total = sum(lot_rem.get(lid, 0) for lid in self.demand_eligible[j])
            if total < qty:
                return False
        return True

    def _sched_key(self, alloc):
        """Full schedule key for comparison (alloc part only)."""
        parts = []
        for oid in self.sorted_oids:
            entries = alloc.get(oid, [])
            # Merge same (comp, lot)
            merged = {}
            for c, l, q in entries:
                merged[(c, l)] = merged.get((c, l), 0) + q
            parts.append(tuple((c, l, q) for (c, l), q in sorted(merged.items()) if q > 0))
        return tuple(parts)

    def _sched_key_partial(self, alloc):
        return self._sched_key(alloc)


def _find_lex_min_alloc(left, pass_lots, subs, sel_oids, assignments):
    solver = _AllocSolver(left, pass_lots, subs, sel_oids, assignments)
    return solver.solve()


def _objective(sel_oids, assignments, alloc, omap):
    pri_sums = [0, 0, 0]
    for oid in sel_oids:
        o = omap[oid]
        pri_sums[o["priority"] - 1] += o["qty"]

    keys = sorted(omap.values(), key=lambda o: (o["priority"], o["due"], o["id"]))
    sel_set = set(sel_oids)
    comp_vec = tuple(1 if o["id"] in sel_set else 0 for o in keys)

    entries = []
    for oid in sorted(sel_oids):
        line, start, end = assignments[oid]
        a = tuple(alloc.get(oid, []))
        entries.append((oid, line, start, end, a))
    sched = tuple(entries)

    return (tuple(pri_sums), comp_vec, sched)


def _better(a, b):
    if a[0] != b[0]:
        return a[0] > b[0]
    if a[1] != b[1]:
        return a[1] > b[1]
    if a[2] != b[2]:
        return a[2] < b[2]
    return False
