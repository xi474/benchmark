def compute(payload):
    """保留批次和行序，为每条记录生成清理首尾空白并转小写的邮箱。"""
    batches = payload["batches"]
    result = []
    for batch in batches:
        normalized_batch = []
        for record in batch:
            email = record["email"].strip().lower()
            normalized_batch.append(email)
        result.append(normalized_batch)
    return result
