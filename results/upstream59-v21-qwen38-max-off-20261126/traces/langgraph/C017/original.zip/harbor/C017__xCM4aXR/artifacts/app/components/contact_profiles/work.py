import re


def _normalize_whitespace(s):
    """Strip leading/trailing whitespace and collapse consecutive whitespace to a single space."""
    if not s:
        return s
    s = s.strip()
    if not s:
        return s
    return re.sub(r'\s+', ' ', s)


def compute(payload):
    """保留批次和行序，返回 name,city,source,time 对象；姓名与城市的空白折叠为单个空格。"""
    batches = payload.get("batches", [])
    result = []
    for batch in batches:
        batch_result = []
        for record in batch:
            name = record.get("name", "")
            city = record.get("city", "")
            source = record.get("source", "")
            time_val = record.get("time", 0)

            # Normalize whitespace in name and city
            name = _normalize_whitespace(name)
            city = _normalize_whitespace(city)

            batch_result.append({
                "name": name,
                "city": city,
                "source": source,
                "time": time_val,
            })
        result.append(batch_result)
    return result
