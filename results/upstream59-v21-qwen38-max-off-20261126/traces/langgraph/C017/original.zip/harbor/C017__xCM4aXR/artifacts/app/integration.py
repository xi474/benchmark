import copy


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = contact_keys result:    list of batches, each a list of normalized emails
    right = contact_profiles result: list of batches, each a list of {name, city, source, time}

    Business rules (from TASK.md):
    - email is identity (already normalized by contact_keys)
    - name/city may be empty; record is "complete" when both are non-empty
    - Atomic batch processing: if any record in a batch conflicts with existing
      non-empty name/city, the entire batch is rolled back -> rejected
    - Incomplete records can be promoted to complete when later info fills gaps
    - Non-empty old fields cannot be cleared by empty values
    - Complete records are immutable audit facts: duplicate submissions don't
      change name/city/first_contact, but sources can be merged
    - first_contact = earliest time seen for that email
    - Output: batches (status/items), accepted (complete, sorted by email),
              incomplete (sorted by email), sources (source -> sorted unique emails)
    """

    # Deep copy to avoid mutating inputs
    # left and right are already computed results from components

    # State tracking per email
    # Each email has: name, city, first_contact, sources (set), complete (bool)
    records = {}  # email -> {name, city, first_contact, sources, complete}

    batch_results = []

    num_batches = len(left)

    for batch_idx in range(num_batches):
        emails_in_batch = left[batch_idx]
        profiles_in_batch = right[batch_idx]

        assert len(emails_in_batch) == len(profiles_in_batch)

        # Phase 1: Validate the entire batch against current state
        # We need to check for conflicts before committing anything
        # A conflict occurs when a new non-empty name/city contradicts an existing
        # non-empty name/city for the same email

        # Build a temporary view of what this batch would do
        # We process items within the batch sequentially for promotion logic,
        # but if any conflict is found, the whole batch is rejected

        # First pass: check for conflicts
        conflict = False

        # We also need to track intra-batch state for emails appearing multiple times
        # within the same batch
        batch_temp = {}  # email -> {name, city} accumulated within this batch

        for i in range(len(emails_in_batch)):
            email = emails_in_batch[i]
            profile = profiles_in_batch[i]
            new_name = profile["name"]
            new_city = profile["city"]

            # Determine effective name/city considering existing state + batch temp
            if email in records:
                existing = records[email]
                eff_name = existing["name"]
                eff_city = existing["city"]
            elif email in batch_temp:
                eff_name = batch_temp[email]["name"]
                eff_city = batch_temp[email]["city"]
            else:
                eff_name = ""
                eff_city = ""

            # Check conflict: new non-empty value contradicts existing non-empty value
            if new_name and eff_name and new_name != eff_name:
                conflict = True
                break
            if new_city and eff_city and new_city != eff_city:
                conflict = True
                break

            # Update batch temp (non-empty new values fill in empty slots)
            if email not in batch_temp:
                batch_temp[email] = {"name": eff_name, "city": eff_city}

            if new_name:
                batch_temp[email]["name"] = new_name
            if new_city:
                batch_temp[email]["city"] = new_city

        if conflict:
            batch_results.append({"status": "rejected", "items": []})
            continue

        # Phase 2: No conflict, commit the batch
        item_statuses = []

        for i in range(len(emails_in_batch)):
            email = emails_in_batch[i]
            profile = profiles_in_batch[i]
            new_name = profile["name"]
            new_city = profile["city"]
            source = profile["source"]
            time_val = profile["time"]

            if email not in records:
                # New record
                rec_name = new_name
                rec_city = new_city
                is_complete = bool(rec_name and rec_city)

                records[email] = {
                    "name": rec_name,
                    "city": rec_city,
                    "first_contact": time_val,
                    "sources": {source},
                    "complete": is_complete,
                }

                if is_complete:
                    item_statuses.append("accepted")
                else:
                    item_statuses.append("incomplete")
            else:
                existing = records[email]
                was_complete = existing["complete"]

                if was_complete:
                    # Immutable audit fact: don't change name/city/first_contact
                    # But merge source
                    existing["sources"].add(source)
                    item_statuses.append("duplicate")
                else:
                    # Incomplete record: try to fill in missing fields
                    updated = False
                    if new_name and not existing["name"]:
                        existing["name"] = new_name
                        updated = True
                    if new_city and not existing["city"]:
                        existing["city"] = new_city
                        updated = True

                    # Always merge source
                    existing["sources"].add(source)

                    # Update first_contact to earliest
                    if time_val < existing["first_contact"]:
                        existing["first_contact"] = time_val

                    # Check if now complete
                    now_complete = bool(existing["name"] and existing["city"])

                    if now_complete and not was_complete:
                        existing["complete"] = True
                        item_statuses.append("promoted")
                    elif now_complete and was_complete:
                        # Shouldn't happen since was_complete=False here
                        item_statuses.append("duplicate")
                    else:
                        # Still incomplete
                        item_statuses.append("incomplete")

        batch_results.append({"status": "committed", "items": item_statuses})

    # Build final output
    accepted = []
    incomplete = []

    for email in sorted(records.keys()):
        rec = records[email]
        entry = {
            "email": email,
            "name": rec["name"],
            "city": rec["city"],
            "first_contact": rec["first_contact"],
            "sources": sorted(rec["sources"]),
        }
        if rec["complete"]:
            accepted.append(entry)
        else:
            incomplete.append(entry)

    # Build sources view: source -> sorted unique emails that have valid records
    sources_view = {}
    for email, rec in records.items():
        for src in rec["sources"]:
            if src not in sources_view:
                sources_view[src] = set()
            sources_view[src].add(email)

    # Sort the email lists
    sources_output = {}
    for src in sorted(sources_view.keys()):
        sources_output[src] = sorted(sources_view[src])

    return {
        "batches": batch_results,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_output,
    }
