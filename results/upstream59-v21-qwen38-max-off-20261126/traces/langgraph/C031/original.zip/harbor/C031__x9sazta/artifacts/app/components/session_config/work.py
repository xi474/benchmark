def compute(payload):
    """Build rc content, timeout, and markers from the session config payload."""
    # Extract fields with defaults
    startup = payload.get("startup", "") or ""
    timeout = payload.get("timeout_seconds", 4)
    if timeout is None:
        timeout = 4
    steps = payload.get("steps", [])

    # Build rc content: PS1, PS2, HISTFILE, then append startup string
    rc_lines = [
        "PS1='PROMPT> '",
        "PS2='CONT> '",
        "HISTFILE=/dev/null",
        "",  # blank line before startup
    ]
    # Append startup string (may be empty)
    rc_content = "\n".join(rc_lines) + "\n"
    if startup:
        rc_content += startup + "\n"

    # Collect markers (until values) in order; null is preserved as None
    markers = [step.get("until") for step in steps]

    return {
        "rc": rc_content,
        "timeout": timeout,
        "markers": markers,
    }
