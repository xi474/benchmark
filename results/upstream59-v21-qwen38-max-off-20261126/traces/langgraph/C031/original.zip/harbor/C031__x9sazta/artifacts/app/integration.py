"""Integration: combine key_sequences and session_config into a real PTY bash session."""

import os
import pty
import select
import signal
import tempfile
import time


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  – list of hex-encoded byte strings (one per step) from key_sequences
    right – dict with rc, timeout, markers from session_config

    Returns {"chunks": [...], "closed": bool}
    """
    hex_keys_list = left          # e.g. ["7072696e74662027585c6e270d"]
    rc_content = right["rc"]
    timeout = right.get("timeout", 4)
    markers = right.get("markers", [])

    chunks = []
    closed = False

    # Create a temporary directory to serve as HOME
    tmpdir = tempfile.mkdtemp(prefix="bash_pty_")
    try:
        # Create .hushlogin to suppress login messages
        hushlogin_path = os.path.join(tmpdir, ".hushlogin")
        with open(hushlogin_path, "w") as f:
            pass  # empty file

        # Write rc file
        rc_path = os.path.join(tmpdir, ".bashrc_custom")
        with open(rc_path, "w", encoding="utf-8") as f:
            f.write(rc_content)

        # Build environment
        env = os.environ.copy()
        env["HOME"] = tmpdir
        env["TERM"] = "dumb"
        env["LC_ALL"] = "C"
        env["HISTFILE"] = "/dev/null"

        # Fork with PTY
        pid, master_fd = pty.fork()

        if pid == 0:
            # Child process
            os.execvpe(
                "/bin/bash",
                ["/bin/bash", "--noprofile", "--rcfile", rc_path, "-i"],
                env,
            )
        else:
            # Parent process
            try:
                # Helper to read available data from master_fd with timeout
                def read_available(fd, timeout_sec):
                    """Read all available data from fd within timeout_sec."""
                    buf = bytearray()
                    deadline = time.monotonic() + timeout_sec
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            break
                        try:
                            rlist, _, _ = select.select([fd], [], [], min(remaining, 0.05))
                        except (OSError, ValueError):
                            break
                        if not rlist:
                            continue
                        try:
                            data = os.read(fd, 65536)
                        except OSError:
                            break
                        if not data:
                            # EOF
                            return bytes(buf), True
                        buf.extend(data)
                    return bytes(buf), False

                def read_until_marker(fd, marker, timeout_sec):
                    """Read until marker is found or timeout/EOF.
                    
                    If marker is None, read until EOF.
                    Returns (text, eof_reached).
                    """
                    buf = bytearray()
                    deadline = time.monotonic() + timeout_sec
                    eof = False
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            break
                        try:
                            rlist, _, _ = select.select([fd], [], [], min(remaining, 0.05))
                        except (OSError, ValueError):
                            break
                        if not rlist:
                            continue
                        try:
                            data = os.read(fd, 65536)
                        except OSError:
                            eof = True
                            break
                        if not data:
                            eof = True
                            break
                        buf.extend(data)
                        # Check if marker is in accumulated buffer
                        if marker is not None:
                            marker_bytes = marker.encode("utf-8") if isinstance(marker, str) else marker
                            if marker_bytes in buf:
                                # We found the marker; stop reading but keep what we have
                                # Do a small additional read to capture any trailing bytes
                                # that arrived in the same burst
                                time.sleep(0.02)
                                try:
                                    rlist2, _, _ = select.select([fd], [], [], 0.02)
                                    if rlist2:
                                        extra = os.read(fd, 65536)
                                        if extra:
                                            buf.extend(extra)
                                except (OSError, ValueError):
                                    pass
                                break
                    return bytes(buf), eof

                def normalize_crlf(data_bytes):
                    """Normalize CRLF -> LF, CR -> LF, remove isolated CR."""
                    # Replace CRLF with LF first, then remaining CR with LF
                    text = data_bytes.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
                    return text.decode("utf-8", errors="replace")

                # Step 0: Read initial PROMPT>
                initial_data, eof = read_until_marker(master_fd, "PROMPT> ", timeout)
                chunk_text = normalize_crlf(initial_data)
                chunks.append(chunk_text)
                if eof:
                    closed = True

                # Process each step
                for i, hex_keys in enumerate(hex_keys_list):
                    if closed:
                        break

                    # Decode hex to bytes and write to PTY
                    raw_bytes = bytes.fromhex(hex_keys)
                    try:
                        os.write(master_fd, raw_bytes)
                    except OSError:
                        closed = True
                        break

                    # Determine the marker for this step
                    marker = markers[i] if i < len(markers) else None

                    # Read until marker (or EOF if marker is None)
                    step_data, eof = read_until_marker(master_fd, marker, timeout)
                    chunk_text = normalize_crlf(step_data)
                    chunks.append(chunk_text)
                    if eof:
                        closed = True

            finally:
                # Cleanup: close master fd and kill process group
                try:
                    os.close(master_fd)
                except OSError:
                    pass

                # Kill the child and its process group
                try:
                    os.killpg(pid, signal.SIGTERM)
                except (ProcessLookupError, PermissionError, OSError):
                    pass
                try:
                    os.kill(pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError, OSError):
                    pass
                try:
                    os.waitpid(pid, 0)
                except (ChildProcessError, OSError):
                    pass

    finally:
        # Clean up temp directory
        import shutil
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass

    return {"chunks": chunks, "closed": closed}
