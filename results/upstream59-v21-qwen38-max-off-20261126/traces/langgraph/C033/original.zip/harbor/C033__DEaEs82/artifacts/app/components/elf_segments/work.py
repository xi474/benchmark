def compute(payload):
    """Parse ELF32 LE hex, extract PT_LOAD segments with BSS zero-fill.
    
    Returns [entry_address, [[address, byte], ...]] sorted by address ascending.
    """
    elf_hex = payload["elf_hex"]
    elf = bytes.fromhex(elf_hex)

    # ELF32 header fields (little-endian)
    # e_entry at offset 24, 4 bytes
    e_entry = int.from_bytes(elf[24:28], "little")
    # e_phoff at offset 28, 4 bytes
    e_phoff = int.from_bytes(elf[28:32], "little")
    # e_phentsize at offset 42, 2 bytes
    e_phentsize = int.from_bytes(elf[42:44], "little")
    # e_phnum at offset 44, 2 bytes
    e_phnum = int.from_bytes(elf[44:46], "little")

    PT_LOAD = 1
    memory = {}  # address -> byte value

    for i in range(e_phnum):
        ph_off = e_phoff + i * e_phentsize
        p_type = int.from_bytes(elf[ph_off:ph_off + 4], "little")
        if p_type != PT_LOAD:
            continue
        p_offset = int.from_bytes(elf[ph_off + 4:ph_off + 8], "little")
        p_vaddr = int.from_bytes(elf[ph_off + 8:ph_off + 12], "little")
        p_filesz = int.from_bytes(elf[ph_off + 16:ph_off + 20], "little")
        p_memsz = int.from_bytes(elf[ph_off + 20:ph_off + 24], "little")

        # Load file content
        for j in range(p_filesz):
            memory[p_vaddr + j] = elf[p_offset + j]

        # BSS zero-fill (memsz > filesz)
        for j in range(p_filesz, p_memsz):
            memory[p_vaddr + j] = 0

    # Build sorted list of [address, byte] pairs
    segments = [[addr, memory[addr]] for addr in sorted(memory.keys())]

    return [e_entry, segments]
