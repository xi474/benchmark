def compute(payload):
    """返回 [文件名字节数组映射,标准输入字节数组]，未指定文件或 stdin 时为空。"""
    # Decode files map: each value is a hex string -> list of byte values
    files_map = {}
    raw_files = payload.get("files", {})
    if raw_files:
        for name, hex_str in raw_files.items():
            files_map[name] = list(bytes.fromhex(hex_str))

    # Decode stdin_hex: hex string -> list of byte values, empty list if absent
    stdin_hex = payload.get("stdin_hex", "")
    if stdin_hex:
        stdin_bytes = list(bytes.fromhex(stdin_hex))
    else:
        stdin_bytes = []

    return [files_map, stdin_bytes]
