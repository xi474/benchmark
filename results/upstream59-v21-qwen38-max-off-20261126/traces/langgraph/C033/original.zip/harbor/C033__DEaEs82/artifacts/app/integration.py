"""MIPS32 CPU emulator with delay slots, syscalls, and file IO."""
import math


def combine(payload, left, right):
    """Combine component results into full MIPS32 emulation output."""
    entry_addr, mem_pairs = left
    files_map, stdin_bytes = right

    # Build memory as dict for sparse access
    mem = {}
    for addr, byte_val in mem_pairs:
        mem[addr] = byte_val & 0xFF

    # Initialize registers
    regs = [0] * 32
    sp_default = payload.get("stack_pointer", 0x7FFF0000)
    regs[29] = sp_default & 0xFFFFFFFF
    hi = 0
    lo = 0

    max_steps = payload.get("max_steps", 20000)
    inspect_list = payload.get("inspect", [])

    # File system state
    file_data = {}   # fd -> bytearray (backing store reference or copy)
    file_offsets = {}  # fd -> int
    next_fd = 3

    # Initialize files from input
    open_files = {}  # filename -> bytearray (the backing store)
    for fname, byte_arr in files_map.items():
        open_files[fname] = bytearray(byte_arr)

    # stdin buffer
    stdin_buf = bytearray(stdin_bytes) if stdin_bytes else bytearray()
    stdin_pos = 0

    stdout_buf = bytearray()
    stderr_buf = bytearray()

    syscalls_log = []

    MASK32 = 0xFFFFFFFF

    def sign_ext_16(val):
        val &= 0xFFFF
        return val if val < 0x8000 else val - 0x10000

    def sign_ext_byte(val):
        if val & 0x80:
            return (val | 0xFFFFFF00) & MASK32
        return val & MASK32

    def sign_ext_half(val):
        if val & 0x8000:
            return (val | 0xFFFF0000) & MASK32
        return val & MASK32

    def to_signed(v):
        return v if v < 0x80000000 else v - 0x100000000

    def read_mem_u8(addr):
        return mem.get(addr & MASK32, 0)

    def read_mem_u16(addr):
        a = addr & MASK32
        return (mem.get(a + 1, 0) << 8) | mem.get(a, 0)

    def read_mem_u32(addr):
        a = addr & MASK32
        return (mem.get(a + 3, 0) << 24) | (mem.get(a + 2, 0) << 16) | (mem.get(a + 1, 0) << 8) | mem.get(a, 0)

    def write_mem_u8(addr, val):
        mem[addr & MASK32] = val & 0xFF

    def write_mem_u16(addr, val):
        a = addr & MASK32
        val &= 0xFFFF
        mem[a] = val & 0xFF
        mem[a + 1] = (val >> 8) & 0xFF

    def write_mem_u32(addr, val):
        a = addr & MASK32
        val &= MASK32
        mem[a] = val & 0xFF
        mem[a + 1] = (val >> 8) & 0xFF
        mem[a + 2] = (val >> 16) & 0xFF
        mem[a + 3] = (val >> 24) & 0xFF

    def get_reg(r):
        return regs[r] if r != 0 else 0

    def set_reg(r, val):
        if r != 0:
            regs[r] = val & MASK32

    def execute_insn(insn_word, current_pc):
        """Execute a single instruction. Returns (delayed_pc or None).
        delayed_pc is set if this is a jump/branch that was taken."""
        nonlocal hi, lo, exit_code, next_fd, stdin_pos

        op = (insn_word >> 26) & 0x3F
        rs = (insn_word >> 21) & 0x1F
        rt = (insn_word >> 16) & 0x1F
        rd = (insn_word >> 11) & 0x1F
        shamt = (insn_word >> 6) & 0x1F
        funct = insn_word & 0x3F
        imm16 = insn_word & 0xFFFF
        simm16 = sign_ext_16(imm16)
        target26 = insn_word & 0x3FFFFFF

        delayed_pc = None

        if op == 0x00:  # R-type
            if funct == 0x00:  # sll
                set_reg(rd, (get_reg(rt) << shamt) & MASK32)
            elif funct == 0x02:  # srl
                set_reg(rd, (get_reg(rt) >> shamt) & MASK32)
            elif funct == 0x03:  # sra
                val = get_reg(rt)
                if shamt == 0:
                    set_reg(rd, val)
                elif val & 0x80000000:
                    result = (val >> shamt) | ((MASK32 << (32 - shamt)) & MASK32)
                    set_reg(rd, result)
                else:
                    set_reg(rd, val >> shamt)
            elif funct == 0x08:  # jr
                delayed_pc = get_reg(rs)
            elif funct == 0x09:  # jalr
                delayed_pc = get_reg(rs)
                set_reg(rd if rd != 0 else 31, (current_pc + 8) & MASK32)
            elif funct == 0x20:  # add
                set_reg(rd, (get_reg(rs) + get_reg(rt)) & MASK32)
            elif funct == 0x21:  # addu
                set_reg(rd, (get_reg(rs) + get_reg(rt)) & MASK32)
            elif funct == 0x22:  # sub
                set_reg(rd, (get_reg(rs) - get_reg(rt)) & MASK32)
            elif funct == 0x23:  # subu
                set_reg(rd, (get_reg(rs) - get_reg(rt)) & MASK32)
            elif funct == 0x24:  # and
                set_reg(rd, get_reg(rs) & get_reg(rt))
            elif funct == 0x25:  # or
                set_reg(rd, get_reg(rs) | get_reg(rt))
            elif funct == 0x26:  # xor
                set_reg(rd, get_reg(rs) ^ get_reg(rt))
            elif funct == 0x27:  # nor
                set_reg(rd, ~(get_reg(rs) | get_reg(rt)) & MASK32)
            elif funct == 0x2A:  # slt
                set_reg(rd, 1 if to_signed(get_reg(rs)) < to_signed(get_reg(rt)) else 0)
            elif funct == 0x2B:  # sltu
                set_reg(rd, 1 if get_reg(rs) < get_reg(rt) else 0)
            elif funct == 0x10:  # mfhi
                set_reg(rd, hi)
            elif funct == 0x11:  # mthi
                hi = get_reg(rs)
            elif funct == 0x12:  # mflo
                set_reg(rd, lo)
            elif funct == 0x13:  # mtlo
                lo = get_reg(rs)
            elif funct == 0x18:  # mult
                a_s = to_signed(get_reg(rs))
                b_s = to_signed(get_reg(rt))
                product = a_s * b_s
                product &= 0xFFFFFFFFFFFFFFFF
                lo = product & MASK32
                hi = (product >> 32) & MASK32
            elif funct == 0x19:  # multu
                product = get_reg(rs) * get_reg(rt)
                lo = product & MASK32
                hi = (product >> 32) & MASK32
            elif funct == 0x1A:  # div
                a = get_reg(rs)
                b = get_reg(rt)
                if b != 0:
                    a_s = to_signed(a)
                    b_s = to_signed(b)
                    # Truncate toward zero
                    q = int(a_s / b_s) if (a_s < 0) != (b_s < 0) and a_s % b_s != 0 else a_s // b_s
                    q = math.trunc(a_s / b_s)
                    r = a_s - q * b_s
                    lo = q & MASK32
                    hi = r & MASK32
            elif funct == 0x1B:  # divu
                a = get_reg(rs)
                b = get_reg(rt)
                if b != 0:
                    lo = (a // b) & MASK32
                    hi = (a % b) & MASK32
            elif funct == 0x0C:  # syscall
                _do_syscall(current_pc)
            # else: nop

        elif op == 0x02:  # j
            delayed_pc = ((current_pc + 4) & 0xF0000000) | (target26 << 2)
        elif op == 0x03:  # jal
            delayed_pc = ((current_pc + 4) & 0xF0000000) | (target26 << 2)
            set_reg(31, (current_pc + 8) & MASK32)
        elif op == 0x04:  # beq
            if get_reg(rs) == get_reg(rt):
                delayed_pc = (current_pc + 4 + (simm16 << 2)) & MASK32
        elif op == 0x05:  # bne
            if get_reg(rs) != get_reg(rt):
                delayed_pc = (current_pc + 4 + (simm16 << 2)) & MASK32
        elif op == 0x06:  # blez
            if to_signed(get_reg(rs)) <= 0:
                delayed_pc = (current_pc + 4 + (simm16 << 2)) & MASK32
        elif op == 0x07:  # bgtz
            if to_signed(get_reg(rs)) > 0:
                delayed_pc = (current_pc + 4 + (simm16 << 2)) & MASK32
        elif op == 0x08:  # addi
            set_reg(rt, (get_reg(rs) + simm16) & MASK32)
        elif op == 0x09:  # addiu
            set_reg(rt, (get_reg(rs) + simm16) & MASK32)
        elif op == 0x0A:  # slti
            set_reg(rt, 1 if to_signed(get_reg(rs)) < simm16 else 0)
        elif op == 0x0B:  # sltiu
            set_reg(rt, 1 if get_reg(rs) < (simm16 & MASK32) else 0)
        elif op == 0x0C:  # andi
            set_reg(rt, get_reg(rs) & imm16)
        elif op == 0x0D:  # ori
            set_reg(rt, get_reg(rs) | imm16)
        elif op == 0x0E:  # xori
            set_reg(rt, get_reg(rs) ^ imm16)
        elif op == 0x0F:  # lui
            set_reg(rt, (imm16 << 16) & MASK32)
        elif op == 0x20:  # lb
            addr = (get_reg(rs) + simm16) & MASK32
            set_reg(rt, sign_ext_byte(read_mem_u8(addr)))
        elif op == 0x24:  # lbu
            addr = (get_reg(rs) + simm16) & MASK32
            set_reg(rt, read_mem_u8(addr) & 0xFF)
        elif op == 0x21:  # lh
            addr = (get_reg(rs) + simm16) & MASK32
            set_reg(rt, sign_ext_half(read_mem_u16(addr)))
        elif op == 0x25:  # lhu
            addr = (get_reg(rs) + simm16) & MASK32
            set_reg(rt, read_mem_u16(addr) & 0xFFFF)
        elif op == 0x23:  # lw
            addr = (get_reg(rs) + simm16) & MASK32
            set_reg(rt, read_mem_u32(addr))
        elif op == 0x28:  # sb
            addr = (get_reg(rs) + simm16) & MASK32
            write_mem_u8(addr, get_reg(rt) & 0xFF)
        elif op == 0x29:  # sh
            addr = (get_reg(rs) + simm16) & MASK32
            write_mem_u16(addr, get_reg(rt) & 0xFFFF)
        elif op == 0x2B:  # sw
            addr = (get_reg(rs) + simm16) & MASK32
            write_mem_u32(addr, get_reg(rt))
        # else: nop

        return delayed_pc

    def _do_syscall(current_pc):
        nonlocal exit_code, next_fd, stdin_pos
        syscall_num = get_reg(2)  # v0
        a0 = get_reg(4)
        a1 = get_reg(5)
        a2 = get_reg(6)
        syscalls_log.append({
            "number": syscall_num,
            "args": [a0, a1, a2]
        })
        if syscall_num == 4001:  # exit
            exit_code = a0 & 0xFF
            set_reg(7, 0)
        elif syscall_num == 4003:  # read(fd, buffer, n)
            fd = a0
            buf_addr = a1
            count = a2
            data_read = bytearray()
            if fd == 0:
                avail = len(stdin_buf) - stdin_pos
                to_read = min(count, avail)
                data_read = bytearray(stdin_buf[stdin_pos:stdin_pos + to_read])
                stdin_pos += to_read
            elif fd in file_data:
                fbuf = file_data[fd]
                foff = file_offsets[fd]
                avail = len(fbuf) - foff
                to_read = min(count, avail)
                data_read = bytearray(fbuf[foff:foff + to_read])
                file_offsets[fd] = foff + to_read
            for i, b in enumerate(data_read):
                write_mem_u8((buf_addr + i) & MASK32, b)
            set_reg(2, len(data_read) & MASK32)
            set_reg(7, 0)
        elif syscall_num == 4004:  # write(fd, buffer, n)
            fd = a0
            buf_addr = a1
            count = a2
            data = bytearray()
            for i in range(count):
                data.append(read_mem_u8((buf_addr + i) & MASK32))
            if fd == 1:
                stdout_buf.extend(data)
            elif fd == 2:
                stderr_buf.extend(data)
            elif fd in file_data:
                fbuf = file_data[fd]
                foff = file_offsets[fd]
                while len(fbuf) < foff + len(data):
                    fbuf.append(0)
                fbuf[foff:foff + len(data)] = data
                file_offsets[fd] = foff + len(data)
            set_reg(2, len(data) & MASK32)
            set_reg(7, 0)
        elif syscall_num == 4005:  # open(filename, flags, mode)
            fname_addr = a0
            flags = a1
            fname_bytes = bytearray()
            while True:
                ch = read_mem_u8(fname_addr)
                if ch == 0:
                    break
                fname_bytes.append(ch)
                fname_addr += 1
            fname = fname_bytes.decode("utf-8")
            fd = next_fd
            next_fd += 1
            if flags == 0:  # read-only existing
                if fname in open_files:
                    file_data[fd] = bytearray(open_files[fname])
                else:
                    file_data[fd] = bytearray()
                file_offsets[fd] = 0
            elif flags == 1:  # create/truncate
                open_files[fname] = bytearray()
                file_data[fd] = open_files[fname]
                file_offsets[fd] = 0
            elif flags == 9:  # append/create
                if fname not in open_files:
                    open_files[fname] = bytearray()
                file_data[fd] = open_files[fname]
                file_offsets[fd] = len(open_files[fname])
            set_reg(2, fd & MASK32)
            set_reg(7, 0)
        elif syscall_num == 4006:  # close(fd)
            fd = a0
            if fd in file_data:
                del file_data[fd]
            if fd in file_offsets:
                del file_offsets[fd]
            set_reg(2, 0)
            set_reg(7, 0)

    pc = entry_addr & MASK32
    steps = 0
    exit_code = None

    while exit_code is None and steps < max_steps:
        insn = read_mem_u32(pc)
        steps += 1

        delayed_pc = execute_insn(insn, pc)

        if delayed_pc is not None:
            # Execute delay slot
            ds_pc = (pc + 4) & MASK32
            ds_insn = read_mem_u32(ds_pc)
            steps += 1
            # Delay slot should not itself be a branch/jump per spec
            execute_insn(ds_insn, ds_pc)
            pc = delayed_pc & MASK32
        else:
            pc = (pc + 4) & MASK32

    # Force $0 to 0
    regs[0] = 0

    # Build output files
    out_files = {}
    for fname, fdata in open_files.items():
        out_files[fname] = bytes(fdata).hex()

    # Build inspect results
    inspect_result = []
    for item in inspect_list:
        addr = item["address"]
        length = item["length"]
        hex_str = ""
        for i in range(length):
            hex_str += format(mem.get((addr + i) & MASK32, 0), '02x')
        inspect_result.append({"address": addr, "hex": hex_str})

    return {
        "exit_code": exit_code if exit_code is not None else 0,
        "registers": list(regs),
        "hi": hi,
        "lo": lo,
        "steps": steps,
        "stdout_hex": bytes(stdout_buf).hex(),
        "stderr_hex": bytes(stderr_buf).hex(),
        "files": out_files,
        "inspect": inspect_result,
        "syscalls": syscalls_log,
    }
