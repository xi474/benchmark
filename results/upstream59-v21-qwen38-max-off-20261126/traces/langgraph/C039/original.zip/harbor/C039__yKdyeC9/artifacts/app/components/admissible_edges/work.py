def compute(payload):
    """排除指向根的边，按 allowed 顺序返回节点下标对。"""
    nodes = payload["nodes"]
    allowed = payload["allowed"]
    root = payload["root"]

    # Build name-to-index mapping
    idx = {name: i for i, name in enumerate(nodes)}
    root_idx = idx[root]

    result = []
    for parent_name, child_name in allowed:
        child_i = idx[child_name]
        # Exclude edges pointing to the root node
        if child_i != root_idx:
            result.append([idx[parent_name], child_i])

    return result
