def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    cov = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload["max_parents"]

    n = len(nodes)
    node_idx = {name: i for i, name in enumerate(nodes)}
    root_idx = node_idx[root]

    # Build admissible parents for each node from allowed edges
    # allowed entries are [parent_name, child_name]
    admissible_parents = [[] for _ in range(n)]
    for p_name, c_name in allowed:
        pi = node_idx[p_name]
        ci = node_idx[c_name]
        if ci == root_idx:
            continue  # root cannot have incoming edges
        if pi not in admissible_parents[ci]:
            admissible_parents[ci].append(pi)

    # Sort each admissible parent list
    for i in range(n):
        admissible_parents[i].sort()

    def solve_linear(A, b):
        """Solve Ax = b using Gaussian elimination with partial pivoting.
        A is list of lists (n x n), b is list (n). Returns list x."""
        nn = len(b)
        # Augmented matrix
        M = [A[i][:] + [b[i]] for i in range(nn)]
        for col in range(nn):
            # Partial pivoting
            max_row = col
            max_val = abs(M[col][col])
            for row in range(col + 1, nn):
                if abs(M[row][col]) > max_val:
                    max_val = abs(M[row][col])
                    max_row = row
            M[col], M[max_row] = M[max_row], M[col]
            pivot = M[col][col]
            for row in range(col + 1, nn):
                factor = M[row][col] / pivot
                for j in range(col, nn + 1):
                    M[row][j] -= factor * M[col][j]
        # Back substitution
        x = [0.0] * nn
        for i in range(nn - 1, -1, -1):
            s = M[i][nn]
            for j in range(i + 1, nn):
                s -= M[i][j] * x[j]
            x[i] = s / M[i][i]
        return x

    def subsets_up_to_k(items, k):
        """Generate all subsets of items with size 0..k, each subset as sorted tuple."""
        result = []
        m = len(items)
        # Use bitmask enumeration
        for mask in range(1 << m):
            subset = []
            for bit in range(m):
                if mask & (1 << bit):
                    subset.append(items[bit])
            if len(subset) <= k:
                result.append(tuple(sorted(subset)))
        return result

    result = []
    for node_i in range(n):
        table = {}
        if node_i == root_idx:
            # Root has no incoming edges; only empty parent set
            table[""] = []
        else:
            parents_list = admissible_parents[node_i]
            all_subsets = subsets_up_to_k(parents_list, max_parents)
            for parent_set in all_subsets:
                key = ",".join(str(p) for p in parent_set)
                if len(parent_set) == 0:
                    table[key] = []
                else:
                    # Build Sigma_PP and Sigma_Py
                    k = len(parent_set)
                    Sigma_PP = [[cov[parent_set[a]][parent_set[b]] for b in range(k)] for a in range(k)]
                    Sigma_Py = [cov[parent_set[a]][node_i] for a in range(k)]
                    beta = solve_linear(Sigma_PP, Sigma_Py)
                    table[key] = beta
        result.append(table)

    return result
