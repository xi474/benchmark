import math
from itertools import combinations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left: list of [parent_idx, child_idx] admissible edges (no edges into root)
    right: list of dicts, one per node; each dict maps comma-separated sorted parent
           indices (string key) to list of regression coefficients (unrounded).
    """
    nodes = payload["nodes"]
    cov = payload["covariance"]
    mean = payload["mean"]
    sample_size = payload["sample_size"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload["intervention"]
    n = len(nodes)

    # Build name <-> index mappings
    node_idx = {name: i for i, name in enumerate(nodes)}
    idx_node = {i: name for i, name in enumerate(nodes)}

    # Admissible edges as tuples for easy handling
    admissible = [(e[0], e[1]) for e in left]

    # For cycle detection we need topological ordering check
    def has_cycle(edges, num_nodes):
        """Check if directed graph with given edges has a cycle using DFS."""
        adj = [[] for _ in range(num_nodes)]
        for p, c in edges:
            adj[p].append(c)
        WHITE, GRAY, BLACK = 0, 1, 2
        color = [WHITE] * num_nodes

        def dfs(u):
            color[u] = GRAY
            for v in adj[u]:
                if color[v] == GRAY:
                    return True
                if color[v] == WHITE and dfs(v):
                    return True
            color[u] = BLACK
            return False

        for i in range(num_nodes):
            if color[i] == WHITE:
                if dfs(i):
                    return True
        return False

    # Compute residual variance for a node given parent set
    def residual_variance(node_i, parent_set):
        if len(parent_set) == 0:
            return cov[node_i][node_i]
        k = len(parent_set)
        # CPP matrix
        CPP = [[cov[parent_set[a]][parent_set[b]] for b in range(k)] for a in range(k)]
        # CPy vector
        CPy = [cov[parent_set[a]][node_i] for a in range(k)]
        # Solve CPP * x = CPy => x = CPP^-1 * CPy
        # Then residual = Cyy - CPy^T * x
        x = solve_linear(CPP, CPy)
        cyy = cov[node_i][node_i]
        cyp_dot_x = sum(CPy[j] * x[j] for j in range(k))
        return cyy - cyp_dot_x

    def solve_linear(A, b):
        """Solve Ax = b using Gaussian elimination with partial pivoting."""
        nn = len(b)
        M = [A[i][:] + [b[i]] for i in range(nn)]
        for col in range(nn):
            max_row = col
            max_val = abs(M[col][col])
            for row in range(col + 1, nn):
                if abs(M[row][col]) > max_val:
                    max_val = abs(M[row][col])
                    max_row = row
            M[col], M[max_row] = M[max_row], M[col]
            pivot = M[col][col]
            for row in range(col + 1, nn):
                factor = M[row][col] / pivot
                for j in range(col, nn + 1):
                    M[row][j] -= factor * M[col][j]
        x = [0.0] * nn
        for i in range(nn - 1, -1, -1):
            s = M[i][nn]
            for j in range(i + 1, nn):
                s -= M[i][j] * x[j]
            x[i] = s / M[i][i]
        return x

    # Enumerate all subsets of admissible edges of size edge_count
    # Check constraints: max_parents, no cycles
    best_score = None
    best_edges = None

    ln_n = math.log(sample_size)

    for edge_subset in combinations(range(len(admissible)), edge_count):
        edges = [admissible[i] for i in edge_subset]

        # Check max_parents constraint
        in_degree = [0] * n
        valid = True
        for p, c in edges:
            in_degree[c] += 1
            if in_degree[c] > max_parents:
                valid = False
                break
        if not valid:
            continue

        # Check no cycles
        if has_cycle(edges, n):
            continue

        # Compute BIC score
        score = 0.0
        for node_i in range(n):
            # Find parents of this node in current edge set
            parents = sorted([p for p, c in edges if c == node_i])
            rv = residual_variance(node_i, parents)
            score += sample_size * math.log(rv) + len(parents) * ln_n

        # Round to 9 decimal places for comparison
        score_r9 = round(score, 9)

        if best_score is None or score_r9 < best_score[0]:
            best_score = (score_r9, score)
            best_edges = edges
        elif score_r9 == best_score[0]:
            # Tie-break: sorted (parent, child) edge list lexicographic order
            # Edges are already from admissible which preserves allowed order
            # But we need to sort them by (parent, child) for comparison
            candidate_sorted = sorted(edges)
            best_sorted = sorted(best_edges)
            if candidate_sorted < best_sorted:
                best_score = (score_r9, score)
                best_edges = edges

    if best_edges is None:
        return {"feasible": False}

    # Build final result
    # Sort edges by (parent, child) for output
    sorted_edges = sorted(best_edges)

    # Get coefficients for each edge from precomputed regressions
    coefficients = []
    for p, c in sorted_edges:
        # Look up regression coefficients from right[c] table
        # Parents of c in best_edges
        parents_of_c = sorted([pp for pp, cc in best_edges if cc == c])
        key = ",".join(str(pp) for pp in parents_of_c)
        betas = right[c][key]
        # Find the coefficient for parent p
        idx_in_parents = parents_of_c.index(p)
        coeff = betas[idx_in_parents]
        coefficients.append((p, c, coeff))

    # Compute intervened mean
    int_node = node_idx[intervention["node"]]
    int_value = intervention["value"]

    # Under intervention: set int_node to int_value, cut all incoming edges to int_node
    # Other nodes keep their regression slopes and intercepts determined by observational means
    # For each non-intervened node: E[Y] = intercept + sum(beta_j * E[X_j])
    # intercept = mean_Y - sum(beta_j * mean_Xj)  (from observational data)
    # Under intervention, E[int_node] = int_value
    # We need to solve for expected means in topological order

    # Build adjacency for intervened graph (remove edges into int_node)
    intervened_edges_removed = [(p, c) for p, c in best_edges if c != int_node]

    # Topological sort of the intervened graph
    adj = [[] for _ in range(n)]
    in_deg = [0] * n
    for p, c in intervened_edges_removed:
        adj[p].append(c)
        in_deg[c] += 1

    topo_order = []
    queue = [i for i in range(n) if in_deg[i] == 0]
    temp_in_deg = in_deg[:]
    while queue:
        queue.sort()  # deterministic
        u = queue.pop(0)
        topo_order.append(u)
        for v in adj[u]:
            temp_in_deg[v] -= 1
            if temp_in_deg[v] == 0:
                queue.append(v)

    # Compute expected means
    exp_mean = [0.0] * n
    exp_mean[int_node] = int_value

    for node_i in topo_order:
        if node_i == int_node:
            continue
        # Get parents of node_i in original best_edges (not intervened graph)
        parents_of_i = sorted([p for p, c in best_edges if c == node_i])
        if len(parents_of_i) == 0:
            exp_mean[node_i] = mean[node_i]
        else:
            key = ",".join(str(pp) for pp in parents_of_i)
            betas = right[node_i][key]
            # intercept = mean[node_i] - sum(beta_j * mean[parent_j])
            intercept = mean[node_i] - sum(betas[j] * mean[parents_of_i[j]] for j in range(len(parents_of_i)))
            # E[node_i] = intercept + sum(beta_j * E[parent_j])
            exp_mean[node_i] = intercept + sum(betas[j] * exp_mean[parents_of_i[j]] for j in range(len(parents_of_i)))

    # Intervened edges: edges that remain after cutting incoming edges to intervention node
    intervened_edge_list = sorted([(p, c) for p, c in best_edges if c != int_node])

    # Format output
    def rnd6(x):
        return round(x, 6)

    result = {
        "feasible": True,
        "edges": [[idx_node[p], idx_node[c]] for p, c in sorted_edges],
        "score": rnd6(best_score[1]),
        "coefficients": [[idx_node[p], idx_node[c], rnd6(coeff)] for p, c, coeff in coefficients],
        "intervened_edges": [[idx_node[p], idx_node[c]] for p, c in intervened_edge_list],
        "mean": [rnd6(m) for m in exp_mean],
    }

    return result
