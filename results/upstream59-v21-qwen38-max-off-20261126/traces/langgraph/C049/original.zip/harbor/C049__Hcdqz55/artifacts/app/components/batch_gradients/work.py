import numpy as np


def compute(payload):
    """
    Forward pass storing per-microbatch activations, backward pass in reverse
    microbatch/stage order, mean cross-entropy loss with equal microbatch weighting,
    returns gradients for all layers using float64 manual backprop.
    """
    layers = payload["layers"]
    microbatches = payload["microbatches"]
    num_layers = len(layers)

    # Convert weights and biases to float64 numpy arrays
    weights = [np.array(l["weight"], dtype=np.float64) for l in layers]
    biases = [np.array(l["bias"], dtype=np.float64) for l in layers]

    # Initialize gradient accumulators
    grad_weights = [np.zeros_like(w) for w in weights]
    grad_biases = [np.zeros_like(b) for b in biases]

    total_loss = 0.0
    num_microbatches = len(microbatches)

    # Forward pass for each microbatch, store activations
    # We process microbatches in order for forward, reverse order for backward
    all_activations = []  # list of per-microbatch activation lists

    for mb_idx, mb in enumerate(microbatches):
        inputs = np.array(mb["inputs"], dtype=np.float64)  # [batch_size, in_dim]
        targets = mb["targets"]  # list of class indices
        batch_size = inputs.shape[0]

        # Store activations: pre_activation and post_activation for each layer
        # activations[l] = output after activation (or logits for last layer)
        # pre_activations[l] = z before activation
        mb_activations = {"input": inputs, "pre": [], "post": []}

        current = inputs
        for l in range(num_layers):
            z = current @ weights[l].T + biases[l]  # [batch_size, out_dim]
            mb_activations["pre"].append(z)

            if l < num_layers - 1:
                # tanh activation
                a = np.tanh(z)
            else:
                # last layer: logits (no activation)
                a = z

            mb_activations["post"].append(a)
            current = a

        all_activations.append(mb_activations)

        # Compute cross-entropy loss for this microbatch
        logits = mb_activations["post"][-1]  # [batch_size, num_classes]

        # Softmax
        # For numerical stability, subtract max
        logits_shifted = logits - np.max(logits, axis=1, keepdims=True)
        exp_logits = np.exp(logits_shifted)
        softmax = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)

        # Cross-entropy: -log(softmax[i, target[i]])
        ce = 0.0
        for i in range(batch_size):
            ce -= np.log(softmax[i, targets[i]])
        ce /= batch_size  # mean over batch

        total_loss += ce

    # Equal-weight average across microbatches
    total_loss /= num_microbatches

    # Backward pass: reverse microbatch order, reverse stage order
    for mb_idx in range(num_microbatches - 1, -1, -1):
        mb = microbatches[mb_idx]
        mb_acts = all_activations[mb_idx]
        targets = mb["targets"]
        batch_size = len(targets)

        # Gradient of loss w.r.t. logits (last layer output)
        logits = mb_acts["post"][-1]
        logits_shifted = logits - np.max(logits, axis=1, keepdims=True)
        exp_logits = np.exp(logits_shifted)
        softmax = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)

        # d(CE)/d(logits) = softmax - one_hot(target), averaged over batch
        # Then multiplied by 1/(num_microbatches * batch_size) for equal weighting
        d_logits = softmax.copy()
        for i in range(batch_size):
            d_logits[i, targets[i]] -= 1.0
        # Scale: loss = (1/M) * sum_m (1/B_m) * sum_i CE_i
        # d_loss/d_logits_m_i = (1/M) * (1/B_m) * (softmax_i - onehot_i)
        d_logits *= 1.0 / (num_microbatches * batch_size)

        # Backprop through layers in reverse order
        d_current = d_logits  # gradient w.r.t. output of current layer

        for l in range(num_layers - 1, -1, -1):
            pre = mb_acts["pre"][l]  # [batch_size, out_dim]
            # Input to this layer: for l==0 it's the original input, else post[l-1]
            if l == 0:
                inp = mb_acts["input"]
            else:
                inp = mb_acts["post"][l - 1]

            if l < num_layers - 1:
                # tanh activation: d_tanh/d_z = 1 - tanh(z)^2
                post = mb_acts["post"][l]
                dtanh = 1.0 - post ** 2
                d_pre = d_current * dtanh
            else:
                # last layer: no activation, d_current is already d_loss/d_z
                d_pre = d_current

            # Gradient for weight and bias
            # z = inp @ W.T + b => d_z/d_W = inp (outer product per sample)
            # grad_w[o, i] = sum_n d_pre[n, o] * inp[n, i]
            grad_weights[l] += d_pre.T @ inp
            grad_biases[l] += np.sum(d_pre, axis=0)

            # Gradient w.r.t. input of this layer (for next layer back)
            # d_loss/d_inp = d_pre @ W
            if l > 0:
                d_current = d_pre @ weights[l]

    # Build result
    result = {
        "loss": float(total_loss),
        "gradients": []
    }

    for l in range(num_layers):
        result["gradients"].append({
            "weight": grad_weights[l].tolist(),
            "bias": grad_biases[l].tolist()
        })

    return result
