import math


def compute(payload):
    """Output partitions and AFAB events list.

    Layer boundaries use floor(L * r / world_size).
    Preserves forward order, reverse backward order, and cross-stage sends.
    """
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]

    L = len(layers)
    num_microbatches = len(microbatches)

    # Compute partitions: rank r owns layers [floor(L*r/world), floor(L*(r+1)/world))
    partitions = []
    for r in range(world_size):
        start = math.floor(L * r / world_size)
        stop = math.floor(L * (r + 1) / world_size)
        partitions.append({"stage": r, "start": start, "stop": stop})

    num_stages = world_size

    # Generate AFAB events
    events = []

    # Forward pass: microbatches in order, stages in order
    for mb in range(num_microbatches):
        for s in range(num_stages):
            events.append({"kind": "forward", "microbatch": mb, "stage": s})
            # Non-last stage sends activation to next stage
            if s < num_stages - 1:
                events.append({
                    "kind": "send_activation",
                    "source": s,
                    "target": s + 1
                })

    # Backward pass: microbatches in reverse order, stages in reverse order
    for mb in range(num_microbatches - 1, -1, -1):
        for s in range(num_stages - 1, -1, -1):
            events.append({"kind": "backward", "microbatch": mb, "stage": s})
            # Non-first stage sends gradient to previous stage
            if s > 0:
                events.append({
                    "kind": "send_gradient",
                    "source": s,
                    "target": s - 1
                })

    return {
        "partitions": partitions,
        "events": events
    }
