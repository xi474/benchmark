def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = batch_gradients output:   {"loss": ..., "gradients": [...]}
    right = pipeline_schedule output: {"partitions": [...], "events": [...]}

    Returns the merged final result with keys: loss, gradients, partitions, events.
    """
    return {
        "loss": left["loss"],
        "gradients": left["gradients"],
        "partitions": right["partitions"],
        "events": right["events"],
    }
