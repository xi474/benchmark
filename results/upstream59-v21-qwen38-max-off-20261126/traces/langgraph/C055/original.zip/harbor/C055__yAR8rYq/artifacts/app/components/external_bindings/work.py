def compute(payload):
    """解析不受信任文档的覆盖和文档内锚点。每个有效键输出 [原源序号,声明位置,[值位置,文本,是否密文,来源是否可信]]；位置为 [源名,行,列]。"""
    sources = payload.get("sources", [])
    # Result dict: key -> [source_idx, decl_pos, [val_pos, text, is_vault, is_trusted]]
    result = {}

    for src_idx, source in enumerate(sources):
        if source.get("trusted", False):
            continue  # Only process untrusted sources

        name = source["name"]
        yaml_text = source.get("yaml", "")
        lines = yaml_text.split("\n")
        # Remove trailing empty element from final newline
        # But keep all lines for correct line numbering

        # Anchors defined in this document: anchor_name -> [val_pos, text, is_vault]
        anchors = {}

        for line_idx, line in enumerate(lines):
            line_num = line_idx + 1  # 1-based

            # Skip empty lines and document separators
            stripped = line.strip()
            if not stripped or stripped == "---":
                continue

            # Parse "key: value" format
            colon_pos = line.find(": ")
            if colon_pos == -1:
                continue

            key = line[:colon_pos]
            # Validate key is lowercase letters only
            if not key or not all(c.islower() for c in key):
                continue

            raw_value = line[colon_pos + 2:]  # Everything after ": "
            # Value position: column is 1-based, starts at colon_pos + 2 (0-based) => col = colon_pos + 3
            val_col = colon_pos + 3  # 1-based column of first char of value

            # Check for anchor: &name followed by space
            anchor_name = None
            actual_value = raw_value
            actual_val_col = val_col

            if raw_value.startswith("&"):
                # Find the space after anchor name
                space_pos = raw_value.find(" ", 1)
                if space_pos != -1:
                    anchor_name = raw_value[1:space_pos]
                    actual_value = raw_value[space_pos + 1:]
                    # The value position still includes the &
                    # val_col already points to '&', which is correct per spec
                    # "值从 key 冒号空格后的首字符定位（含 & 或 !）"

            # Check for alias: *name
            if actual_value.startswith("*"):
                alias_name = actual_value[1:]
                if alias_name in anchors:
                    # Alias preserves the original value's position and content
                    ref_val_pos, ref_text, ref_is_vault = anchors[alias_name]
                    decl_pos = [name, line_num, 1]
                    result[key] = [src_idx, decl_pos, [ref_val_pos, ref_text, ref_is_vault, False]]
                    continue
                else:
                    # Alias not found - skip? Per spec "依赖存在" so this shouldn't happen
                    continue

            # Check for vault: !vault <id>
            is_vault = False
            text = actual_value
            if actual_value.startswith("!vault "):
                is_vault = True
                text = actual_value[7:]  # After "!vault "

            val_pos = [name, line_num, actual_val_col]

            # Register anchor if present
            if anchor_name is not None:
                anchors[anchor_name] = [val_pos, text, is_vault]

            decl_pos = [name, line_num, 1]
            result[key] = [src_idx, decl_pos, [val_pos, text, is_vault, False]]

    return result
