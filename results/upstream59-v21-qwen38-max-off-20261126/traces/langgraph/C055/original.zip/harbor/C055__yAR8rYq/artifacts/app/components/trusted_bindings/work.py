def compute(payload):
    """解析受信任文档的覆盖和文档内锚点。每个有效键输出 [原源序号,声明位置,[值位置,文本,是否密文,来源是否可信]]；位置为 [源名,行,列]。"""
    sources = payload.get("sources", [])
    # Result dict: key -> [source_index, decl_pos, [val_pos, text, is_vault, source_trusted]]
    result = {}

    for src_idx, source in enumerate(sources):
        if not source.get("trusted", False):
            continue
        name = source["name"]
        yaml_text = source.get("yaml", "")
        lines = yaml_text.split("\n")

        # Anchors are scoped per YAML document (separated by ---)
        anchors = {}  # anchor_name -> (value_position, text, is_vault)

        for line_idx, line in enumerate(lines):
            line_num = line_idx + 1  # 1-based

            # Skip empty lines
            if line.strip() == "":
                continue

            # Document separator resets anchors
            if line.strip() == "---":
                anchors = {}
                continue

            # Parse "key: value" - exactly one space after colon
            colon_pos = line.find(": ")
            if colon_pos == -1:
                continue

            key = line[:colon_pos]
            # Validate key is lowercase letters only
            if not key.isalpha() or not key.islower():
                continue

            # Value starts after ": " (colon + space)
            value_start_col = colon_pos + 2 + 1  # 1-based column
            raw_value = line[colon_pos + 2:]

            decl_pos = [name, line_num, 1]  # key starts at column 1

            is_vault = False
            anchor_name = None
            text = raw_value
            val_pos = [name, line_num, value_start_col]

            # Step 1: Strip anchor prefix if present: &anchor_name rest
            remaining = raw_value
            if remaining.startswith("&"):
                space_pos = remaining.find(" ", 1)
                if space_pos != -1:
                    anchor_name = remaining[1:space_pos]
                    remaining = remaining[space_pos + 1:]
                    # val_pos stays at the & character position (value_start_col)

            # Step 2: Check for alias reference: *name (only if no anchor prefix was stripped,
            # since aliases and anchors are mutually exclusive on the same token)
            if anchor_name is None and remaining.startswith("*"):
                alias_name = remaining[1:].strip()
                if alias_name in anchors:
                    ref_val_pos, ref_text, ref_is_vault = anchors[alias_name]
                    val_pos = list(ref_val_pos)
                    text = ref_text
                    is_vault = ref_is_vault
                else:
                    text = remaining
            elif remaining.startswith("!vault "):
                # Vault value
                is_vault = True
                text = remaining[7:]  # after "!vault "
            else:
                # Plain text value
                text = remaining

            # Store anchor if defined (snapshot of value at definition point)
            if anchor_name:
                anchors[anchor_name] = (list(val_pos), text, is_vault)

            # Record/override the key binding
            source_trusted = True  # This component only handles trusted sources
            result[key] = [src_idx, decl_pos, [val_pos, text, is_vault, source_trusted]]

    return result
