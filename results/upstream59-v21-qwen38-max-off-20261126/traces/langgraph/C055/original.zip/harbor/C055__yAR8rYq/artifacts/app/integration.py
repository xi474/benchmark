import json


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left  = trusted_bindings result: {key: [src_idx, decl_pos, [val_pos, text, is_vault, trusted]]}
    right = external_bindings result: same format for untrusted sources
    
    payload has: sources, tags, keys
    """
    tags = payload.get("tags", False)
    keys = payload.get("keys", {})

    # Merge bindings: later source_idx wins for same key
    merged = {}
    for key, binding in left.items():
        merged[key] = binding
    for key, binding in right.items():
        if key not in merged:
            merged[key] = binding
        else:
            # Compare source indices; later source overrides
            existing_src_idx = merged[key][0]
            new_src_idx = binding[0]
            if new_src_idx > existing_src_idx:
                merged[key] = binding
            elif new_src_idx == existing_src_idx:
                # Same source - shouldn't happen (trusted vs untrusted are disjoint)
                # but if it does, compare by line number in decl_pos
                existing_line = merged[key][1][1]
                new_line = binding[1][1]
                if new_line > existing_line:
                    merged[key] = binding

    # Check vault sealing: if tags=false, all vault entries must have keys
    if not tags:
        for key, binding in merged.items():
            val_info = binding[2]  # [val_pos, text, is_vault, trusted]
            is_vault = val_info[2]
            if is_vault and val_info[1] not in keys:
                return {"status": "sealed"}

    # Build final entries and compute render values
    # First pass: collect raw info for each key
    key_info = {}
    for key, binding in merged.items():
        src_idx = binding[0]
        decl_pos = binding[1]
        val_pos, text, is_vault, source_trusted = binding[2]

        # Determine effective trusted and render text
        if is_vault:
            if tags:
                # Vault sealed: trusted=false, render="[sealed]"
                effective_trusted = False
                render_text = "[sealed]"
                dump_text = text  # original ciphertext ID for dump
                is_vault_dump = True
            else:
                # Vault unsealed: use keys mapping, trusted=true
                effective_trusted = True
                render_text = keys[text]
                dump_text = render_text
                is_vault_dump = False
        else:
            effective_trusted = source_trusted
            render_text = text  # will be template-resolved later
            dump_text = text
            is_vault_dump = False

        key_info[key] = {
            "decl_pos": decl_pos,
            "val_pos": val_pos,
            "text": text,
            "is_vault": is_vault,
            "effective_trusted": effective_trusted,
            "render_text": render_text,
            "dump_text": dump_text,
            "is_vault_dump": is_vault_dump,
        }

    # Recursive template rendering for trusted values
    # Build render cache
    render_cache = {}

    def get_render(key):
        if key in render_cache:
            return render_cache[key]
        info = key_info[key]
        if not info["effective_trusted"]:
            # Untrusted: keep original text as-is (no template expansion)
            render_cache[key] = info["render_text"]
            return render_cache[key]
        # Trusted: expand ${ref} references
        text = info["render_text"]
        result = _expand_templates(text, key_info, get_render)
        render_cache[key] = result
        return result

    # Compute renders for all keys
    for key in key_info:
        get_render(key)

    # Build entries sorted by key
    sorted_keys = sorted(key_info.keys())
    entries = []
    for key in sorted_keys:
        info = key_info[key]
        entry = [
            key,
            info["decl_pos"],
            info["val_pos"],
            info["effective_trusted"],
            render_cache[key],
        ]
        entries.append(entry)

    # Build dump string
    dump_lines = []
    for key in sorted_keys:
        info = key_info[key]
        if info["is_vault_dump"]:
            # Vault preserved: key: !vault "ciphertext_id"
            dump_val = "!vault " + json.dumps(info["dump_text"], ensure_ascii=False)
        else:
            dump_val = json.dumps(info["dump_text"], ensure_ascii=False)
        dump_lines.append(key + ": " + dump_val)
    dump = "\n".join(dump_lines) + "\n" if dump_lines else ""

    return {
        "status": "ok",
        "entries": entries,
        "dump": dump,
    }


def _expand_templates(text, key_info, get_render):
    """Recursively replace ${key} references in text with rendered values."""
    result = []
    i = 0
    while i < len(text):
        if text[i:i+2] == "${":
            end = text.find("}", i + 2)
            if end != -1:
                ref_key = text[i+2:end]
                if ref_key in key_info:
                    result.append(get_render(ref_key))
                else:
                    result.append(text[i:end+1])
                i = end + 1
            else:
                result.append(text[i])
                i += 1
        else:
            result.append(text[i])
            i += 1
    return "".join(result)
