def compute(payload):
    """返回各依赖批次，每批含按 ID 升序排列的任务 ID。同批共享同一事实快照。"""
    tasks = payload["tasks"]
    
    # Build adjacency info
    task_map = {t["id"]: t for t in tasks}
    remaining = set(task_map.keys())
    satisfied = set()
    waves = []
    
    while remaining:
        # Find all tasks whose dependencies are fully satisfied
        wave = []
        for tid in sorted(remaining):
            needs = task_map[tid]["needs"]
            if all(dep in satisfied for dep in needs):
                wave.append(tid)
        
        if not wave:
            # Should not happen for a DAG, but guard against infinite loop
            break
        
        waves.append(wave)
        for tid in wave:
            remaining.remove(tid)
            satisfied.add(tid)
    
    return waves
