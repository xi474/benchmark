def compute(payload):
    """每个 host/stream 返回各次循环读取的 [items,数量,总和] 列表，保持原顺序。"""
    feeds = payload["feeds"]
    result = {}
    for host in sorted(feeds.keys()):
        host_data = feeds[host]
        result[host] = {}
        for stream in sorted(host_data.keys()):
            batches = host_data[stream]
            stats = []
            for batch in batches:
                items = list(batch)
                count = len(items)
                total = sum(items)
                stats.append([items, count, total])
            result[host][stream] = stats
    return result
