def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left  = dependency_waves result: list of waves, each wave is list of task IDs (sorted asc)
    right = feed_statistics result: {host: {stream: [[items, count, sum], ...]}}
    """
    waves = left           # [["a","b"],["c"]]
    feed_stats = right     # {host: {stream: [[items,count,sum],...]}}

    tasks_list = payload["tasks"]
    task_map = {t["id"]: t for t in tasks_list}
    pools = payload["pools"]
    initial = dict(payload["initial"])  # copy
    feeds_raw = payload["feeds"]

    # Build feed_cycles: for each (host, stream), the list of batches (just the items arrays)
    # We need to track cyclic index per (host, stream)
    feed_batches = {}
    for host in feeds_raw:
        feed_batches[host] = {}
        for stream in feeds_raw[host]:
            feed_batches[host][stream] = list(feeds_raw[host][stream])

    # Round-robin counters
    pool_rr = {p: 0 for p in pools}          # per-pool counter
    feed_rr = {}                              # per (host, stream) counter
    for host in feeds_raw:
        for stream in feeds_raw[host]:
            feed_rr[(host, stream)] = 0

    # Track committed deltas per task
    committed_delta = {}

    # Track facts
    facts = dict(initial)

    # Track reads
    pool_reads = {p: 0 for p in pools}
    feed_reads = {}
    for host in feeds_raw:
        feed_reads[host] = {}
        for stream in feeds_raw[host]:
            feed_reads[host][stream] = 0

    # Result tasks dict
    result_tasks = {}

    for wave in waves:
        # Snapshot facts at wave start
        base_snapshot = dict(facts)

        # Process tasks in this wave sorted by id (they already are from component)
        wave_tasks_sorted = sorted(wave)

        # Collect deltas to apply at end of wave
        wave_deltas = {}  # host -> total delta

        for tid in wave_tasks_sorted:
            task = task_map[tid]
            pool_name = task["pool"]
            stream_name = task["stream"]
            attempts_needed = task["attempts"]

            # Pool selection: round-robin
            pool_hosts = pools[pool_name]
            pool_idx = pool_rr[pool_name] % len(pool_hosts)
            host = pool_hosts[pool_idx]
            pool_rr[pool_name] += 1
            pool_reads[pool_name] += 1

            # Feed selection: round-robin on (host, stream)
            batches = feed_batches[host][stream_name]
            feed_idx = feed_rr[(host, stream_name)] % len(batches)
            items = list(batches[feed_idx])
            feed_rr[(host, stream_name)] += 1
            feed_reads[host][stream_name] += 1

            # base = fact value of host at wave start
            base = base_snapshot[host]

            # parent = sum of committed deltas of direct parents
            parent = sum(committed_delta.get(dep, 0) for dep in task["needs"])

            # Compute business result
            # Each item: (base + item) * (1 + parent)
            # delta = sum of those
            delta = sum((base + item) * (1 + parent) for item in items)

            # Store result
            result_tasks[tid] = {
                "host": host,
                "items": items,
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": attempts_needed
            }

            # Mark as committed (after all attempts succeed)
            committed_delta[tid] = delta

            # Accumulate delta for host
            wave_deltas[host] = wave_deltas.get(host, 0) + delta

        # End of wave: update facts
        for host, d in wave_deltas.items():
            facts[host] = facts[host] + d

    return {
        "tasks": result_tasks,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads
    }
