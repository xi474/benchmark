def compute(payload):
    """输出 [处理器声明顺序映射,叶节点到通知清单的映射]。叶节点按同一树位置编码；通知名去重并按声明顺序排列，含 rescue、always。"""
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    # Handler declaration order mapping: handler_name -> index
    handler_order = {}
    for i, h in enumerate(handlers):
        handler_order[h] = i

    # Leaf node to notification list mapping
    # Tree position: phase_idx / item_idx [/ branch_idx / sub_item_idx ...]
    # Phases in order: pre, roles, includes, tasks, post
    phase_names = ["pre", "roles", "includes", "tasks", "post"]

    leaf_notifications = {}  # tree_position_string -> [handler_names deduped & ordered]

    def walk_items(items, path_prefix):
        """Walk a list of tasks/blocks at a given path prefix."""
        for idx, item in enumerate(items):
            pos = f"{path_prefix}/{idx}" if path_prefix != "" else str(idx)
            if isinstance(item, dict) and "block" in item:
                block = item["block"]
                # branch 0 = tasks, 1 = rescue, 2 = always
                for branch_idx, branch_key in enumerate(["tasks", "rescue", "always"]):
                    branch_items = block.get(branch_key, [])
                    walk_items(branch_items, f"{pos}/{branch_idx}")
            else:
                # It's a task (leaf node)
                notify = item.get("notify", [])
                if notify:
                    # Deduplicate preserving declaration order
                    seen = set()
                    ordered = []
                    for n in notify:
                        if n not in seen:
                            seen.add(n)
                            ordered.append(n)
                    # Sort by handler declaration order
                    ordered.sort(key=lambda x: handler_order.get(x, float('inf')))
                    leaf_notifications[pos] = ordered

    for phase_idx, phase_name in enumerate(phase_names):
        phase_items = program.get(phase_name, [])
        if phase_items:
            walk_items(phase_items, str(phase_idx))

    return [handler_order, leaf_notifications]
