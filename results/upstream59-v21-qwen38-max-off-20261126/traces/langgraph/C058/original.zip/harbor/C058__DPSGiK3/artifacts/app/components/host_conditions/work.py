def compute(payload):
    """每个 host 对应一张节点表，按树位置（各级整数以 / 分隔）记录 [可执行,会失败]；包含块节点。"""
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})

    # Phase order as specified
    PHASE_ORDER = ["pre", "roles", "includes", "tasks", "post"]

    result = {h: {} for h in hosts}

    def host_matches_only(host, only_set):
        """Check if host satisfies the 'only' constraint."""
        if only_set is None:
            return True
        return host in only_set

    def host_in_fail_hosts(host, fail_hosts):
        """Check if host is in fail_hosts."""
        if not fail_hosts:
            return False
        return host in fail_hosts

    def process_items(phase_idx, items, parent_executable):
        """Process a list of items (tasks or blocks) within a phase."""
        for item_idx, item in enumerate(items):
            pos = f"{phase_idx}/{item_idx}"
            if isinstance(item, dict) and "block" in item:
                process_block(pos, item, parent_executable)
            else:
                process_task(pos, item, parent_executable)

    def process_task(pos, task, parent_executable):
        """Process a single task node."""
        only = task.get("only")
        if only is not None:
            only = set(only)
        fail_hosts = task.get("fail_hosts")
        if fail_hosts is not None:
            fail_hosts = set(fail_hosts)

        for host in hosts:
            executable = parent_executable[host] and host_matches_only(host, only)
            will_fail = executable and host_in_fail_hosts(host, fail_hosts)
            result[host][pos] = [executable, will_fail]

    def process_block(pos, block_def, parent_executable):
        """Process a block node and its children."""
        only = block_def.get("only")
        if only is not None:
            only = set(only)

        # Block's own executability
        block_executable = {}
        for host in hosts:
            block_executable[host] = parent_executable[host] and host_matches_only(host, only)

        # Record the block node itself
        for host in hosts:
            # Blocks don't have fail_hosts themselves
            result[host][pos] = [block_executable[host], False]

        block_data = block_def.get("block", {})
        # Branch 0: tasks, Branch 1: rescue, Branch 2: always
        for branch_idx, branch_key in enumerate(["tasks", "rescue", "always"]):
            branch_items = block_data.get(branch_key, [])
            for task_idx, task in enumerate(branch_items):
                child_pos = f"{pos}/{branch_idx}/{task_idx}"
                if isinstance(task, dict) and "block" in task:
                    process_block(child_pos, task, block_executable)
                else:
                    process_task(child_pos, task, block_executable)

    # Process each phase
    for phase_idx, phase_name in enumerate(PHASE_ORDER):
        phase_items = program.get(phase_name, [])
        if not phase_items:
            continue
        # All hosts start as executable at the phase level
        parent_executable = {h: True for h in hosts}
        process_items(phase_idx, phase_items, parent_executable)

    return result
