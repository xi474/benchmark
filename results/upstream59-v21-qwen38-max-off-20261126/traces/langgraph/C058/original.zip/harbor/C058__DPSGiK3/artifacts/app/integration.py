def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = host_conditions result:   {host: {tree_pos_str: [executable, will_fail]}}
    right = handler_bindings result:  [handler_order_map, leaf_notifications_map]

    Returns {"batches": [...], "final": {host: "ok"/"failed"}}
    """
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})

    handler_order = right[0]       # {handler_name: index}
    leaf_notifs = right[1]         # {tree_pos_str: [handler_names ordered]}

    PHASE_NAMES = ["pre", "roles", "includes", "tasks", "post"]

    # Convert string positions from components to tuples
    def str_pos_to_tuple(s):
        return tuple(int(x) for x in s.split("/"))

    # Build per-host condition lookup: {host: {pos_tuple: [executable, will_fail]}}
    host_conds = {}
    for h in hosts:
        cond_map = {}
        raw = left.get(h, {})
        for spos, val in raw.items():
            tpos = str_pos_to_tuple(spos)
            cond_map[tpos] = val
        host_conds[h] = cond_map

    # Build notification lookup: {pos_tuple: [handler_names]}
    notif_map = {}
    for spos, hlist in leaf_notifs.items():
        tpos = str_pos_to_tuple(spos)
        notif_map[tpos] = hlist

    def get_executable(host, pos):
        conds = host_conds.get(host, {})
        val = conds.get(pos)
        if val is None:
            return False
        return val[0]

    def get_will_fail(host, pos):
        conds = host_conds.get(host, {})
        val = conds.get(pos)
        if val is None:
            return False
        return val[1]

    # ---- Recursive simulation per host ----
    # Produces a list of events and tracks final status.
    # Events: ('task', task_id, status, pos_tuple)
    #         ('flush', phase_idx, [handler_names])
    #         ('handler', handler_name, phase_idx)

    def simulate_host(host):
        events = []
        stopped = [False]
        current_phase = [None]
        pending_notifs = [{}]  # {handler_name: True}
        failed_flag = [False]  # tracks if host ultimately failed

        def flush_phase():
            if pending_notifs[0]:
                hlist = sorted(pending_notifs[0].keys(),
                               key=lambda h: handler_order.get(h, float('inf')))
                events.append(('flush', current_phase[0], hlist))
                for h in hlist:
                    events.append(('handler', h, current_phase[0]))
                pending_notifs[0] = {}

        def process_items(items, path_prefix, phase_idx):
            """Process a list of items. Returns True if uncaught failure."""
            for idx, item in enumerate(items):
                if stopped[0]:
                    return True
                pos = path_prefix + (idx,)

                if isinstance(item, dict) and "block" in item:
                    failure = process_block(pos, item, phase_idx)
                    if failure:
                        return True
                else:
                    executable = get_executable(host, pos)
                    if not executable:
                        continue
                    will_fail = get_will_fail(host, pos)
                    status = "failed" if will_fail else "ok"
                    events.append(('task', item.get("id", ""), status, pos))
                    if will_fail:
                        return True
                    else:
                        notifs = notif_map.get(pos, [])
                        for h in notifs:
                            pending_notifs[0][h] = True
            return False

        def process_block(pos, block_def, phase_idx):
            """Process a block. Returns True if uncaught failure."""
            if stopped[0]:
                return True

            executable = get_executable(host, pos)
            if not executable:
                return False

            block_data = block_def.get("block", {})

            # Branch 0: tasks
            branch0 = block_data.get("tasks", [])
            normal_failed = False

            for idx, item in enumerate(branch0):
                if stopped[0]:
                    return True
                child_pos = pos + (0, idx)

                if isinstance(item, dict) and "block" in item:
                    failure = process_block(child_pos, item, phase_idx)
                    if failure:
                        normal_failed = True
                        break
                else:
                    exec_flag = get_executable(host, child_pos)
                    if not exec_flag:
                        continue
                    will_fail = get_will_fail(host, child_pos)
                    status = "failed" if will_fail else "ok"
                    events.append(('task', item.get("id", ""), status, child_pos))
                    if will_fail:
                        normal_failed = True
                        break
                    else:
                        notifs = notif_map.get(child_pos, [])
                        for h in notifs:
                            pending_notifs[0][h] = True

            # Branch 1: rescue
            branch1 = block_data.get("rescue", [])
            rescue_failed = False

            if normal_failed:
                if len(branch1) > 0:
                    for idx, item in enumerate(branch1):
                        if stopped[0]:
                            return True
                        child_pos = pos + (1, idx)

                        if isinstance(item, dict) and "block" in item:
                            failure = process_block(child_pos, item, phase_idx)
                            if failure:
                                rescue_failed = True
                                break
                        else:
                            exec_flag = get_executable(host, child_pos)
                            if not exec_flag:
                                continue
                            will_fail = get_will_fail(host, child_pos)
                            status = "failed" if will_fail else "ok"
                            events.append(('task', item.get("id", ""), status, child_pos))
                            if will_fail:
                                rescue_failed = True
                                break
                            else:
                                notifs = notif_map.get(child_pos, [])
                                for h in notifs:
                                    pending_notifs[0][h] = True
                else:
                    rescue_failed = True

            # Branch 2: always - runs regardless
            branch2 = block_data.get("always", [])
            always_failed = False

            for idx, item in enumerate(branch2):
                if stopped[0]:
                    break
                child_pos = pos + (2, idx)

                if isinstance(item, dict) and "block" in item:
                    failure = process_block(child_pos, item, phase_idx)
                    if failure:
                        always_failed = True
                else:
                    exec_flag = get_executable(host, child_pos)
                    if not exec_flag:
                        continue
                    will_fail = get_will_fail(host, child_pos)
                    status = "failed" if will_fail else "ok"
                    events.append(('task', item.get("id", ""), status, child_pos))
                    if will_fail:
                        always_failed = True
                    else:
                        notifs = notif_map.get(child_pos, [])
                        for h in notifs:
                            pending_notifs[0][h] = True

            # Determine if block has uncaught failure
            if normal_failed and (rescue_failed or len(branch1) == 0):
                return True
            if always_failed:
                return True
            return False

        # Process each phase
        for phase_idx, phase_name in enumerate(PHASE_NAMES):
            phase_items = program.get(phase_name, [])
            if not phase_items:
                continue

            if stopped[0]:
                break

            current_phase[0] = phase_idx
            failure = process_items(phase_items, (phase_idx,), phase_idx)

            if failure:
                stopped[0] = True
                failed_flag[0] = True

            # Flush at end of phase (even if failed, existing notifications are flushed)
            flush_phase()

        return events, failed_flag[0]

    # ---- Generate per-host event sequences ----
    host_events = {}
    host_failed = {}
    for h in hosts:
        evts, did_fail = simulate_host(h)
        host_events[h] = evts
        host_failed[h] = did_fail

    # ---- Merge into batches using linear scheduling ----
    # Sort key for events:
    #   task:   (0, pos_tuple)
    #   flush:  (1, phase_idx, 0)
    #   handler:(1, phase_idx, 1, handler_decl_index)
    # This ensures tasks sort before flushes in same phase,
    # and handlers sort after flush but within same phase.

    def event_sort_key(event):
        if event[0] == 'task':
            return (0, event[3])
        elif event[0] == 'flush':
            return (1, event[1], 0)
        elif event[0] == 'handler':
            h_idx = handler_order.get(event[1], float('inf'))
            return (1, event[2], 1, h_idx)
        return (2,)

    # Initialize pointers
    host_pointers = {h: 0 for h in hosts}

    batches = []

    while True:
        # Find the minimum sort key among all hosts' next events
        min_key = None
        for h in hosts:
            ptr = host_pointers[h]
            evts = host_events[h]
            if ptr < len(evts):
                key = event_sort_key(evts[ptr])
                if min_key is None or key < min_key:
                    min_key = key

        if min_key is None:
            break

        # Advance all hosts whose next event has this sort key (in input order)
        for h in hosts:
            ptr = host_pointers[h]
            evts = host_events[h]
            if ptr < len(evts):
                key = event_sort_key(evts[ptr])
                if key == min_key:
                    evt = evts[ptr]
                    if evt[0] == 'task':
                        batches.append({
                            "host": h,
                            "task": evt[1],
                            "kind": "task",
                            "status": evt[2]
                        })
                    elif evt[0] == 'flush':
                        batches.append({
                            "host": h,
                            "task": "",
                            "kind": "flush",
                            "status": "ok",
                            "handlers": evt[2]
                        })
                    elif evt[0] == 'handler':
                        batches.append({
                            "host": h,
                            "task": evt[1],
                            "kind": "handler",
                            "status": "ok"
                        })
                    host_pointers[h] = ptr + 1

    # ---- Compute final status ----
    final = {}
    for h in hosts:
        final[h] = "failed" if host_failed[h] else "ok"

    return {"batches": batches, "final": final}
