"""Public entry points for C058 multi-host task orchestration."""
import copy
import json
from pathlib import Path


def load_payload(input_path):
    """Read a UTF-8 JSON file and return the parsed object."""
    return json.loads(Path(input_path).read_text(encoding="utf-8"))


def transform(payload):
    """Compute the orchestration result from payload without mutating it.

    Wires host_conditions and handler_bindings components through
    integration.combine to produce {"batches": [...], "final": {...}}.
    """
    # Work on a deep copy so the caller's object is never mutated.
    data = copy.deepcopy(payload)

    # Import components lazily to avoid circular imports at module level.
    from components.host_conditions.work import compute as compute_host_conditions
    from components.handler_bindings.work import compute as compute_handler_bindings
    from integration import combine

    # Project the fields each component needs (matching components.json).
    hc_fields = ["hosts", "program"]
    hb_fields = ["handlers", "program"]

    hc_input = {k: data[k] for k in hc_fields if k in data}
    hb_input = {k: data[k] for k in hb_fields if k in data}

    left = compute_host_conditions(hc_input)
    right = compute_handler_bindings(hb_input)

    return combine(data, left, right)


def build_component(input_path, output_path):
    """Read input, compute result, write UTF-8 JSON to output_path, return result.

    Works in a clean directory (creates parent dirs as needed).
    Does not depend on pre-existing output artifacts.
    """
    payload = load_payload(input_path)
    result = transform(payload)

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    return result
