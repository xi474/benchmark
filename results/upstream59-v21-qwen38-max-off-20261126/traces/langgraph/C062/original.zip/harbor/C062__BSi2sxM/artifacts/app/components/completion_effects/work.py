def compute(payload):
    """对每个 complete 事件按原始位置记录 [正常完成事件名,新 revision 或 null]。取消与关闭优先级由整合逻辑决定。"""
    events = payload.get("events", [])
    result = {}
    for idx, ev in enumerate(events):
        if ev.get("op") == "complete":
            changed = ev.get("changed", False)
            if changed:
                event_name = "snapshot_updated"
                new_revision = ev.get("revision")
            else:
                event_name = "poll_unchanged"
                new_revision = None
            result[str(idx)] = [event_name, new_revision]
    return result
