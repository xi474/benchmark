def compute(payload):
    """对每个 open 事件按其原始位置（十进制字符串）建立初始状态，字段同最终 stores 项。"""
    events = payload.get("events", [])
    result = {}
    for idx, event in enumerate(events):
        if event.get("op") == "open":
            key = str(idx)
            result[key] = {
                "backend": event["backend"],
                "state": "open",
                "job": None,
                "revision": event.get("revision", 0),
                "closed_at": None,
                "updates": 0,
            }
    return result
