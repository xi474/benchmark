def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = store_initializers result: {str(idx): {backend, state, job, revision, closed_at, updates}}
    right = completion_effects result: {str(idx): [event_name, new_revision_or_null]}

    We simulate the full close-barrier event processing and return
    {"events": [...], "stores": {...}}.
    """
    events = payload.get("events", [])

    # Build initial store states from left component, keyed by store name.
    # left is keyed by original event index (string). We need to map store names.
    store_init = {}  # store_name -> initial state dict
    open_event_indices = {}  # store_name -> original index (int)
    for idx_str, init_state in left.items():
        idx = int(idx_str)
        ev = events[idx]
        store_name = ev["store"]
        store_init[store_name] = dict(init_state)  # copy
        open_event_indices[store_name] = idx

    # Current store states
    stores = {}
    for sname, state in store_init.items():
        stores[sname] = dict(state)

    # Track which stores have been opened (to know when we see an open event)
    # Also track closing barrier waiters
    closing_barriers = {}  # store_name -> list of close event indices waiting

    # Track cancelled jobs: set of (store, job) that have been cancelled
    cancelled_jobs = set()

    # Map from event index to whether it's a complete for a cancelled job
    # We'll determine this during simulation

    output_events = []

    # We need to process events in order, handling the close barrier logic.
    # The tricky part: close with in-flight job sends cancel, then waits for
    # the corresponding complete callback. The close doesn't return until
    # that complete is processed.

    # Since events are ordered by time and array order, and "all started jobs
    # eventually have complete", we can process linearly but need to handle
    # the barrier: when we hit a close with an in-flight job, we emit
    # cancel_sent and close_waiting, then continue processing until we find
    # the matching complete, at which point we emit callback_cancelled and
    # close_returned.

    # Actually, re-reading the spec more carefully:
    # "close无在途job立即返回并关闭；有在途job则发取消，直到对应callback结束才返回"
    # This means close blocks until the complete callback finishes.
    # But in our event stream, events are already ordered. The complete for
    # the cancelled job will appear later in the stream.
    #
    # "对closing再次close等待同一屏障" - another close on same store while
    # closing also waits for the same barrier.
    #
    # "closed再次close立即返回" - close on already-closed store returns immediately.
    #
    # Output ordering: "按照事件处理顺序" - in event processing order.
    # "一次取消complete先callback_cancelled再close_returned"

    # Let me think about this differently. The events in the input represent
    # the chronological sequence of operations. When a close encounters an
    # in-flight job, it conceptually blocks. But the complete event for that
    # job appears later in the input stream. So we process events in order,
    # and when we encounter a close with in-flight job:
    #   1. Set store state to "closing"
    #   2. Emit cancel_sent(job)
    #   3. Mark the job as cancelled
    #   4. Emit close_waiting
    #   5. Continue processing subsequent events
    #   6. When we hit the matching complete, since job is cancelled:
    #      - Emit callback_cancelled(job) instead of snapshot_updated/poll_unchanged
    #      - Then emit close_returned for each waiting close
    #      - Set store to closed
    #
    # Wait, but what about other events between close and its matching complete?
    # They should still be processed normally (for other stores, or polls rejected, etc.)

    # Let me re-read: "close...直到对应callback结束才返回"
    # The close call itself doesn't return until the callback completes.
    # But in our event stream model, we're just producing an audit log.
    # The key insight: the close event in the input triggers the close operation.
    # If there's an in-flight job, the close sends cancel and waits.
    # The matching complete (which comes later) resolves the barrier.
    # At that point, close_returned is emitted.

    # For multiple closes on the same store while closing:
    # They all wait on the same barrier. When the complete arrives,
    # all waiting closes get their close_returned.

    # Let me implement this step by step.

    # State tracking per store beyond what's in stores dict:
    # - pending_closes: number of close calls waiting for barrier (including the first)
    pending_closes = {}  # store_name -> count of close calls waiting

    # Process each event
    i = 0
    while i < len(events):
        ev = events[i]
        op = ev.get("op")
        store_name = ev.get("store")
        time_val = ev.get("time")

        if op == "open":
            # Initialize store from left component data
            state = store_init[store_name]
            stores[store_name] = dict(state)
            output_events.append({
                "time": time_val,
                "store": store_name,
                "event": "opened"
            })

        elif op == "poll":
            job = ev.get("job")
            st = stores.get(store_name)
            if st is None:
                # Should not happen per contract
                i += 1
                continue

            if st["state"] in ("closing", "closed"):
                output_events.append({
                    "time": time_val,
                    "store": store_name,
                    "event": "poll_rejected"
                })
            elif st["state"] == "open":
                if st["job"] is None:
                    # First poll: start job
                    st["job"] = job
                    st["state"] = "open"  # still open, just has a job
                    output_events.append({
                        "time": time_val,
                        "store": store_name,
                        "event": "poll_started",
                        "job": job
                    })
                else:
                    # Already has a job: coalesce
                    output_events.append({
                        "time": time_val,
                        "store": store_name,
                        "event": "poll_coalesced"
                    })

        elif op == "complete":
            job = ev.get("job")
            st = stores.get(store_name)
            if st is None:
                i += 1
                continue

            idx_str = str(i)
            is_cancelled = (store_name, job) in cancelled_jobs

            if is_cancelled:
                # Cancelled complete: emit callback_cancelled, then close_returned for all waiters
                output_events.append({
                    "time": time_val,
                    "store": store_name,
                    "event": "callback_cancelled",
                    "job": job
                })
                # Now resolve the barrier
                st["job"] = None
                st["state"] = "closed"
                st["closed_at"] = time_val
                # Emit close_returned for each pending close
                num_closes = pending_closes.get(store_name, 0)
                for _ in range(num_closes):
                    output_events.append({
                        "time": time_val,
                        "store": store_name,
                        "event": "close_returned"
                    })
                pending_closes[store_name] = 0
                cancelled_jobs.discard((store_name, job))
            else:
                # Normal complete: use right component data
                effect = right.get(idx_str)
                if effect is not None:
                    event_name, new_revision = effect
                    if event_name == "snapshot_updated":
                        st["revision"] = new_revision
                        st["updates"] = st.get("updates", 0) + 1
                        output_events.append({
                            "time": time_val,
                            "store": store_name,
                            "event": "snapshot_updated",
                            "job": job
                        })
                    else:
                        # poll_unchanged
                        output_events.append({
                            "time": time_val,
                            "store": store_name,
                            "event": "poll_unchanged",
                            "job": job
                        })
                # Clear the job
                st["job"] = None

        elif op == "close":
            st = stores.get(store_name)
            if st is None:
                i += 1
                continue

            if st["state"] == "closed":
                # Already closed: immediate return
                output_events.append({
                    "time": time_val,
                    "store": store_name,
                    "event": "close_returned"
                })
            elif st["state"] == "closing":
                # Already closing: wait on same barrier
                pending_closes[store_name] = pending_closes.get(store_name, 0) + 1
                output_events.append({
                    "time": time_val,
                    "store": store_name,
                    "event": "close_waiting"
                })
            else:
                # state == "open"
                if st["job"] is None:
                    # No in-flight job: close immediately
                    st["state"] = "closed"
                    st["closed_at"] = time_val
                    output_events.append({
                        "time": time_val,
                        "store": store_name,
                        "event": "close_returned"
                    })
                else:
                    # Has in-flight job: send cancel, enter closing state
                    job = st["job"]
                    st["state"] = "closing"
                    cancelled_jobs.add((store_name, job))
                    pending_closes[store_name] = pending_closes.get(store_name, 0) + 1
                    output_events.append({
                        "time": time_val,
                        "store": store_name,
                        "event": "cancel_sent",
                        "job": job
                    })
                    output_events.append({
                        "time": time_val,
                        "store": store_name,
                        "event": "close_waiting"
                    })

        i += 1

    # Build final stores output
    final_stores = {}
    for sname in stores:
        s = stores[sname]
        final_stores[sname] = {
            "backend": s["backend"],
            "state": s["state"],
            "job": s["job"],
            "revision": s["revision"],
            "closed_at": s["closed_at"],
            "updates": s["updates"]
        }

    return {
        "events": output_events,
        "stores": final_stores
    }
