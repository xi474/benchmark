def compute(payload):
    """按事务、语句、行变更生成已解码的列映射。D 用空对象；类型错误用 null，使整合端按事务回滚。"""
    # Expected types for each known column name
    EXPECTED_TYPE = {
        "key": "text",
        "body": "text",
        "rank": "int",
    }

    def decode_cols(cols):
        """Decode a cols array into a dict. Return None if any type error."""
        if cols is None:
            return {}
        result = {}
        for col in cols:
            name = col.get("name")
            declared_type = col.get("type")
            value = col.get("value")

            # Check if column name is known and type matches
            if name in EXPECTED_TYPE:
                expected = EXPECTED_TYPE[name]
                if declared_type != expected:
                    return None  # type tag mismatch

            # Validate and decode value based on declared type
            if declared_type == "text":
                # text: value must be string or null
                if value is not None and not isinstance(value, str):
                    return None
                result[name] = value
            elif declared_type == "int":
                # int: value must be a decimal integer string or null
                if value is None:
                    result[name] = None
                elif isinstance(value, str):
                    try:
                        result[name] = int(value)
                    except (ValueError, TypeError):
                        return None
                else:
                    return None
            else:
                # Unknown type tag — treat as type error
                return None

        return result

    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        statements = tx.get("statements", [])
        tx_result = []
        for stmt in statements:
            stmt_result = []
            for op_item in stmt:
                op = op_item.get("op")
                if op == "D":
                    stmt_result.append({})
                elif op in ("I", "U"):
                    cols = op_item.get("cols", [])
                    decoded = decode_cols(cols)
                    if decoded is None:
                        stmt_result.append(None)
                    else:
                        stmt_result.append(decoded)
                else:
                    # Unknown op — treat as error
                    stmt_result.append(None)
            tx_result.append(stmt_result)
        result.append(tx_result)
    return result
