def compute(payload):
    """按事务、语句生成被消费旧主键的去重有序数组，I 不消耗旧主键。"""
    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        statements = tx.get("statements", [])
        tx_old_keys = []
        for stmt in statements:
            seen = set()
            ordered_keys = []
            for op_item in stmt:
                op = op_item.get("op")
                if op in ("U", "D"):
                    old_key = op_item.get("old")
                    if old_key is not None and old_key not in seen:
                        seen.add(old_key)
                        ordered_keys.append(old_key)
            tx_old_keys.append(ordered_keys)
        result.append(tx_old_keys)
    return result
