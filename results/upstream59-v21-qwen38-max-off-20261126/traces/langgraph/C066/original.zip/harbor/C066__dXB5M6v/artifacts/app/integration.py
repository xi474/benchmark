import copy


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    payload: full input with 'initial' and 'txs'
    left:    row_identities result  [[[old_key, ...], ...], ...]  (per tx, per stmt)
    right:   column_decoding result [[[{col_map}|None|{}, ...], ...], ...]  (per tx, per stmt, per op)

    Returns: {"log": [[lsn, status], ...], "rows": {key: {body, rank}, ...}}
    """
    # Deep-copy initial state so we don't mutate the input
    state = copy.deepcopy(payload.get("initial", {}))
    txs = payload.get("txs", [])

    committed_lsns = set()
    log = []

    for tx_idx, tx in enumerate(txs):
        lsn = tx["lsn"]

        # REPLAY check: if already committed, skip
        if lsn in committed_lsns:
            log.append([lsn, "REPLAY"])
            continue

        # Save state snapshot for potential rollback
        saved_state = copy.deepcopy(state)
        aborted = False

        statements = tx.get("statements", [])
        stmt_old_keys = left[tx_idx] if tx_idx < len(left) else []
        stmt_decoded = right[tx_idx] if tx_idx < len(right) else []

        for stmt_idx, stmt in enumerate(statements):
            if aborted:
                break

            old_keys = stmt_old_keys[stmt_idx] if stmt_idx < len(stmt_old_keys) else []
            decoded_ops = stmt_decoded[stmt_idx] if stmt_idx < len(stmt_decoded) else []

            # --- Validate phase ---

            # 1. Check that all old keys exist in current state
            for old_key in old_keys:
                if old_key not in state:
                    aborted = True
                    break

            if aborted:
                break

            # 2. Check for type errors in decoded ops (null means type error → abort)
            for dec in decoded_ops:
                if dec is None:
                    aborted = True
                    break

            if aborted:
                break

            # 3. Build new rows for this statement
            # Each op in the statement produces a new row (for I and U) or nothing (for D).
            # We need to pair ops with their decoded columns.
            new_rows = {}  # key -> {body, rank}
            op_index = 0

            for op_item in stmt:
                op = op_item.get("op")
                dec = decoded_ops[op_index] if op_index < len(decoded_ops) else None
                op_index += 1

                if op == "D":
                    # Delete: no new row produced
                    continue
                elif op == "I":
                    # Insert: must have key, body, rank all provided in cols
                    if dec is None:
                        aborted = True
                        break
                    new_key = dec.get("key")
                    if new_key is None:
                        # key must be non-null for I
                        aborted = True
                        break
                    new_body = dec.get("body")
                    new_rank = dec.get("rank")
                    # Check that all three columns are present in decoded
                    if "key" not in dec or "body" not in dec or "rank" not in dec:
                        aborted = True
                        break
                    if new_key in new_rows:
                        # Collision within same statement
                        aborted = True
                        break
                    new_rows[new_key] = {"body": new_body, "rank": new_rank}
                elif op == "U":
                    # Update: old must exist (already validated above)
                    old_key = op_item.get("old")
                    old_row = state[old_key]
                    if dec is None:
                        aborted = True
                        break
                    # Merge: start from old values, override with provided cols
                    new_key = dec.get("key", old_key)
                    new_body = dec.get("body", old_row["body"])
                    new_rank = dec.get("rank", old_row["rank"])
                    if new_key in new_rows:
                        # Collision within same statement
                        aborted = True
                        break
                    new_rows[new_key] = {"body": new_body, "rank": new_rank}

            if aborted:
                break

            # 4. Check for collisions between new rows and existing state
            # (after removing old keys). But we haven't removed old keys yet.
            # The spec says: "一条语句同时移除所有 U/D 的旧身份，再放置 I/U 的新行"
            # So: remove old keys first, then place new rows.
            # Collision check: new keys must not collide with each other (checked above)
            # AND must not collide with remaining state after old key removal.

            # Compute state after removing old keys
            temp_state = {k: v for k, v in state.items() if k not in set(old_keys)}

            for new_key in new_rows:
                if new_key in temp_state:
                    aborted = True
                    break

            if aborted:
                break

            # --- Apply phase ---
            state = temp_state
            for new_key, new_row in new_rows.items():
                state[new_key] = new_row

        if aborted:
            # Rollback entire transaction
            state = saved_state
            log.append([lsn, "ABORT"])
        else:
            committed_lsns.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": state}
