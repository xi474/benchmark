def compute(payload):
    """按输入顺序重放策略变更，为每个 request 原位置生成授权布尔值。"""
    # Deep copy initial policies so we don't mutate input
    policies = {}
    for user, rules in payload.get("policies", {}).items():
        policies[user] = [dict(r) for r in rules]

    events = payload.get("events", [])
    result = {}
    request_index = 0

    for event in events:
        op = event.get("op")
        if op == "policy":
            # Replace the specified user's allow list
            user = event["user"]
            policies[user] = [dict(r) for r in event.get("allow", [])]
        elif op == "request":
            user = event.get("user")
            cluster = event.get("cluster")
            service = event.get("service")
            verb = event.get("verb")

            allowed = _check_authorization(policies, user, cluster, service, verb)
            result[str(request_index)] = allowed
            request_index += 1

    return result


def _check_authorization(policies, user, cluster, service, verb):
    """Check if user is authorized for the given cluster/service/verb."""
    user_rules = policies.get(user, [])
    for rule in user_rules:
        if rule.get("cluster") != cluster:
            continue
        if rule.get("verb") != verb:
            continue
        # Service matching: rule may omit service, or use "*" for wildcard
        rule_service = rule.get("service")
        if rule_service is None or rule_service == "*":
            return True
        if rule_service == service:
            return True
    return False
