import copy


def compute(payload):
    """按事件位置返回请求当时的 [集群模式,服务是否可用]；合并端负责授权优先和实际计数。"""
    clusters = payload.get("clusters", {})
    events = payload.get("events", [])

    # Deep copy cluster state so we can mutate it as service events arrive
    state = copy.deepcopy(clusters)

    result = {}
    request_index = 0

    for event in events:
        op = event.get("op")

        if op == "service":
            # Service event: update availability for a specific cluster/service
            cluster_name = event.get("cluster")
            service_name = event.get("service")
            available = event.get("available", False)
            if cluster_name in state:
                if "services" not in state[cluster_name]:
                    state[cluster_name]["services"] = {}
                state[cluster_name]["services"][service_name] = available

        elif op == "request":
            # Request event: look up current cluster mode and service availability
            cluster_name = event.get("cluster")
            service_name = event.get("service")

            cluster_info = state.get(cluster_name, {})
            mode = cluster_info.get("mode", "unknown")
            services = cluster_info.get("services", {})
            available = bool(services.get(service_name, False))

            result[str(request_index)] = [mode, available]
            request_index += 1

    return result
