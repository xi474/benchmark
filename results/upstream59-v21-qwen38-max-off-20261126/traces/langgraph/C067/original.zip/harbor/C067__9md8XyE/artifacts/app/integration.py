def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload.get("events", [])

    # Counters
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0

    # Credential cache: key=(user, cluster, service) -> {"credential": str, "expires": int}
    cache = {}
    cert_counter = 0

    replies = []
    request_index = 0

    for event in events:
        if event.get("op") != "request":
            continue

        req_id = event["id"]
        user = event["user"]
        cluster = event["cluster"]
        service = event["service"]
        verb = event["verb"]
        now = event["time"]

        idx_key = str(request_index)
        request_index += 1

        # Step 1: Authorization check (always counted)
        authorizer_calls += 1
        authorized = left.get(idx_key, False)

        if not authorized:
            replies.append({"id": req_id, "status": "denied"})
            continue

        # Step 2: Service lookup (only if authorized)
        service_lookups += 1
        mode_available = right.get(idx_key, ["unknown", False])
        mode = mode_available[0]
        available = mode_available[1]

        if not available:
            replies.append({"id": req_id, "status": "not_found"})
            continue

        # Step 3: Service is available
        if mode == "local":
            # Local: use local credential, no cache
            replies.append({
                "id": req_id,
                "status": "ok",
                "credential": "local",
                "route": "local"
            })
        else:
            # Remote: resolve reverse_tunnel route
            remote_routes += 1

            cache_key = (user, cluster, service)

            # Check cache - cleanup expired entries on access
            entry = cache.get(cache_key)
            if entry is not None and entry["expires"] <= now:
                # Expired - remove from cache
                del cache[cache_key]
                entry = None

            if entry is None:
                # Cache miss - issue new certificate
                cert_counter += 1
                certificates_issued += 1
                credential = f"cert-{cert_counter}"
                expires = now + ttl
                cache[cache_key] = {"credential": credential, "expires": expires}
            else:
                # Cache hit - use existing credential, don't extend
                credential = entry["credential"]

            replies.append({
                "id": req_id,
                "status": "ok",
                "credential": credential,
                "route": "reverse_tunnel"
            })

    # Build sorted cache output: sorted by user, cluster, service (lexicographic)
    sorted_cache = []
    for key in sorted(cache.keys()):
        user, cluster, service = key
        entry = cache[key]
        sorted_cache.append({
            "user": user,
            "cluster": cluster,
            "service": service,
            "credential": entry["credential"],
            "expires": entry["expires"]
        })

    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": sorted_cache
    }
