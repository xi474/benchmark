"""C067 – Per-request authorization with ephemeral credential cache.

Public entry points
-------------------
* ``transform(payload)``          – pure function, returns result dict
* ``load_payload(input_path)``    – read UTF-8 JSON file → object
* ``build_component(input_path, output_path)`` – read, compute, write, return
"""

import json
from pathlib import Path


# ---------------------------------------------------------------------------
# Payload I/O
# ---------------------------------------------------------------------------

def load_payload(input_path):
    """Read a UTF-8 JSON file and return the parsed object."""
    return json.loads(Path(input_path).read_text(encoding="utf-8"))


def _write_json(path, value):
    """Write *value* as compact UTF-8 JSON to *path*."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# Component helpers
# ---------------------------------------------------------------------------

def _project(payload, fields):
    """Return a sub-dict containing only *fields* present in *payload*."""
    return {k: payload[k] for k in fields if k in payload}


_COMPONENT_FIELDS = {
    "policy_decisions": ["policies", "events"],
    "service_routes":   ["clusters", "events"],
}


def _evaluate_component(name, payload):
    """Run a single component's ``compute`` on *payload*."""
    from importlib import import_module
    mod = import_module(f"components.{name}.work")
    return mod.compute(payload)


# ---------------------------------------------------------------------------
# Integration
# ---------------------------------------------------------------------------

def _combine(payload, left, right):
    """Delegate to ``integration.combine``."""
    from integration import combine
    return combine(payload, left, right)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def transform(payload):
    """Compute the full business result from *payload* without side effects.

    Runs both components in-process and merges via ``integration.combine``.
    Does **not** modify *payload*.
    """
    values = []
    for name, fields in _COMPONENT_FIELDS.items():
        values.append(_evaluate_component(name, _project(payload, fields)))
    return _combine(payload, *values)


def build_component(input_path, output_path):
    """Read input, compute the result, write it to *output_path*, and return it.

    Works in a fresh directory with no prior artifacts required.
    """
    payload = load_payload(input_path)
    result = transform(payload)
    _write_json(output_path, result)
    return result


# ---------------------------------------------------------------------------
# CLI convenience (optional)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse, sys

    parser = argparse.ArgumentParser(description="C067 solution")
    parser.add_argument("--input", default="public_input.json")
    parser.add_argument("--output", default="output.json")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()

    if args.check:
        payload = load_payload("public_input.json")
        expected = load_payload("public_expected.json")
        got = transform(payload)
        if got == expected:
            print("public check passed")
        else:
            print("FAIL: output does not match expected", file=sys.stderr)
            sys.exit(1)
    else:
        build_component(args.input, args.output)
