def compute(payload):
    """按 get 驱动的 16×TTL 规则生成触发清理的 get 位置，以及下一次清理的时间。输出以位置字符串为键的映射。"""
    ttl = payload["ttl"]
    events = payload["events"]
    interval = 16 * ttl
    next_cleanup = interval
    result = {}

    for pos, event in enumerate(events):
        if event["op"] != "get":
            continue
        t = event["time"]
        if t >= next_cleanup:
            # Cleanup triggered at this get position
            next_cleanup = t + interval
            result[str(pos)] = next_cleanup

    return result
