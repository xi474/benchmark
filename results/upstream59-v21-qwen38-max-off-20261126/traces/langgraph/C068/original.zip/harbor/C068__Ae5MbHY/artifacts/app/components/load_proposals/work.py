def compute(payload):
    """为每个 get 的原始位置生成 [若启动时的完成时刻,value,error]；只有命中未复用时才实际启动。"""
    events = payload["events"]
    result = {}
    # Track in-flight loads: key -> finish_time
    # We also need to complete them in load-start order when time advances.
    # Use a list of (finish_time, key) sorted by finish_time (which equals start order
    # since loads are started in event order and finish_time = start_time + delay,
    # but start_time is non-decreasing so finish_time preserves start order for same key?
    # Actually different keys can interleave. We need to complete in load-start order.)
    # Since events are processed in order and loads start at event time,
    # load-start order = the order we added them. We'll use a list as queue.
    in_flight_list = []  # list of (finish_time, key) in start order
    in_flight_set = {}   # key -> finish_time for quick lookup

    for pos, event in enumerate(events):
        op = event["op"]
        t = event["time"]

        # Complete all loads with finish_time <= t, in start order
        remaining = []
        for finish_time, key in in_flight_list:
            if finish_time <= t:
                # Load completes; remove from set
                if key in in_flight_set and in_flight_set[key] == finish_time:
                    del in_flight_set[key]
            else:
                remaining.append((finish_time, key))
        in_flight_list = remaining

        if op == "get":
            key = event["key"]
            delay = event["delay"]
            value = event["value"]
            error = event.get("error", None)

            if key in in_flight_set:
                # Reuse existing in-flight load; no new entry
                pass
            else:
                # Start a new load
                finish_time = t + delay
                in_flight_list.append((finish_time, key))
                in_flight_set[key] = finish_time
                result[str(pos)] = [finish_time, value, error]

        # cancel and advance don't produce proposals

    return result
