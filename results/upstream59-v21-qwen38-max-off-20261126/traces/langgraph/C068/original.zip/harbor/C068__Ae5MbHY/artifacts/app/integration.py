def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = cleanup_clock result: {pos_str: new_next_cleanup, ...}
    right = load_proposals result: {pos_str: [finish_time, value, error], ...}
    """
    ttl = payload["ttl"]
    events = payload["events"]

    # Parse component outputs
    cleanup_triggers = left   # {str(pos): new_next_cleanup}
    proposals = right         # {str(pos): [finish_time, value, error]}

    # State
    cache = {}            # key -> {"value": ..., "error": ..., "expires": ...}
    next_cleanup = 16 * ttl
    results = []          # ordered by get occurrence
    loads = []            # actual loads started, in start order
    # In-flight loads: key -> {"finish_time", "started_at", "value", "error", "waiters": [result_index...]}
    in_flight = {}
    # Ordered list of in-flight keys by start order for completion ordering
    in_flight_order = []  # list of (finish_time, key) in start order

    for pos, event in enumerate(events):
        op = event["op"]
        t = event["time"]

        # Before each event, complete all loads with finish_time <= t, in load-start order
        _complete_loads(t, cache, in_flight, in_flight_order, loads, results, ttl)

        if op == "get":
            key = event["key"]
            eid = event["id"]
            delay = event["delay"]
            value = event["value"]
            error = event.get("error", None)

            # Check if cleanup should trigger (using cleanup_clock component result)
            pos_str = str(pos)
            if pos_str in cleanup_triggers:
                # Perform cleanup: remove all expired entries
                _do_cleanup(cache, t)
                next_cleanup = cleanup_triggers[pos_str]

            # Also check specific key expiry on access
            if key in cache and cache[key]["expires"] <= t:
                del cache[key]

            # Determine result
            result_entry = {"id": eid, "status": None, "value": None, "error": None, "finished_at": None}
            result_idx = len(results)
            results.append(result_entry)

            if key in cache:
                # Cache hit
                entry = cache[key]
                if entry["error"] is not None:
                    result_entry["status"] = "error"
                    result_entry["value"] = None
                    result_entry["error"] = entry["error"]
                else:
                    result_entry["status"] = "ok"
                    result_entry["value"] = entry["value"]
                    result_entry["error"] = None
                result_entry["finished_at"] = t
            elif key in in_flight:
                # Join existing in-flight load
                in_flight[key]["waiters"].append(result_idx)
                # finished_at will be set when load completes
            elif pos_str in proposals:
                # Start new load (proposal exists = not sharing in-flight)
                finish_time, prop_value, prop_error = proposals[pos_str]
                in_flight[key] = {
                    "finish_time": finish_time,
                    "started_at": t,
                    "value": prop_value,
                    "error": prop_error,
                    "waiters": [result_idx]
                }
                in_flight_order.append((finish_time, key))
                if delay == 0:
                    # Complete immediately within this get
                    _complete_loads(t, cache, in_flight, in_flight_order, loads, results, ttl)
            else:
                # No proposal means this get shares an in-flight load
                # (shouldn't reach here given the logic above, but safety)
                if key in in_flight:
                    in_flight[key]["waiters"].append(result_idx)

        elif op == "cancel":
            cancel_id = event["id"]
            # Find the result entry for this id and mark cancelled if not yet completed
            cidx = result_idx_for_id(results, cancel_id)
            if cidx >= 0 and results[cidx]["status"] is None:
                results[cidx]["status"] = "cancelled"
                results[cidx]["value"] = None
                results[cidx]["error"] = "cancelled"
                results[cidx]["finished_at"] = t
                # Remove from in-flight waiters (but don't cancel the shared load)
                for key, info in list(in_flight.items()):
                    if cidx in info["waiters"]:
                        info["waiters"].remove(cidx)

        # advance: nothing special beyond load completion (already done above)

    # Build final cache output sorted by key
    cache_output = []
    for key in sorted(cache.keys()):
        entry = cache[key]
        cache_output.append({
            "key": key,
            "value": entry["value"],
            "error": entry["error"],
            "expires": entry["expires"]
        })

    return {
        "results": results,
        "loads": loads,
        "cache": cache_output,
        "next_cleanup": next_cleanup
    }


def result_idx_for_id(results, eid):
    for i, r in enumerate(results):
        if r["id"] == eid:
            return i
    return -1


def _complete_loads(current_time, cache, in_flight, in_flight_order, loads, results, ttl):
    """Complete all loads with finish_time <= current_time, in load-start order."""
    new_order = []
    for finish_time, key in in_flight_order:
        if key not in in_flight:
            # Already removed (shouldn't happen normally)
            continue
        info = in_flight[key]
        if info["finish_time"] != finish_time:
            # Stale entry
            new_order.append((finish_time, key))
            continue
        if finish_time <= current_time:
            # Complete this load
            stamp = finish_time
            expires = stamp + ttl

            # Store in cache (even if all waiters cancelled)
            cache[key] = {
                "value": info["value"] if info["error"] is None else None,
                "error": info["error"],
                "expires": expires
            }

            # Record the load
            loads.append({
                "key": key,
                "started_at": info["started_at"],
                "finished_at": finish_time
            })

            # Resolve waiters
            for idx in info["waiters"]:
                r = results[idx]
                if r["status"] is not None:
                    # Already cancelled
                    continue
                if info["error"] is not None:
                    r["status"] = "error"
                    r["value"] = None
                    r["error"] = info["error"]
                else:
                    r["status"] = "ok"
                    r["value"] = info["value"]
                    r["error"] = None
                r["finished_at"] = finish_time

            del in_flight[key]
        else:
            new_order.append((finish_time, key))
    in_flight_order[:] = new_order


def _do_cleanup(cache, current_time):
    """Remove all expired cache entries."""
    expired_keys = [k for k, v in cache.items() if v["expires"] <= current_time]
    for k in expired_keys:
        del cache[k]
