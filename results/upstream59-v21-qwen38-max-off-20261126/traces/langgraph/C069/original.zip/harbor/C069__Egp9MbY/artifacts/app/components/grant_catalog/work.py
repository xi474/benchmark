def compute(payload):
    """生成授权条目的有效条件和有序角色/资源集合。以原授权 ID 为键，每项含 approved、expiry、roles、resources。"""
    access_requests = payload.get("access_requests", {})
    result = {}
    for grant_id, entry in access_requests.items():
        result[grant_id] = {
            "approved": entry.get("approved", False),
            "expiry": entry.get("expiry"),
            "roles": sorted(entry.get("roles", [])),
            "resources": sorted(entry.get("resources", [])),
        }
    return result
