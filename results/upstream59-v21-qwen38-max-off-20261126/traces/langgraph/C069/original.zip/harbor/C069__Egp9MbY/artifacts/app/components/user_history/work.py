import copy


def compute(payload):
    """记录各续期事件发生时的用户快照，重放 update_user 的 roles、traits；以原位置字符串为键。"""
    events = payload.get("events", [])
    user = copy.deepcopy(payload.get("user", {}))

    result = {}

    for idx, event in enumerate(events):
        op = event.get("op")
        if op == "update_user":
            # Apply update_user: only replace the given roles/traits
            if "roles" in event:
                user["roles"] = list(event["roles"])
            if "traits" in event:
                # Merge traits: replace only the keys provided
                if "traits" not in user:
                    user["traits"] = {}
                for k, v in event["traits"].items():
                    user["traits"][k] = list(v) if isinstance(v, list) else copy.deepcopy(v)
        elif op == "renew":
            # Record snapshot of current user state at this renew event
            result[str(idx)] = copy.deepcopy(user)

    return result
