import base64
import copy
import json


def _b64url_encode(obj):
    """Encode object as JSON with sort_keys, compact separators, ensure_ascii=False,
    then base64url encode without padding."""
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    raw = text.encode('utf-8')
    encoded = base64.urlsafe_b64encode(raw).decode('ascii')
    # Strip trailing '='
    return encoded.rstrip('=')


def _make_ssh_certificate(user_snapshot, roles, resources, login_time, expires):
    obj = {
        "roles": sorted(roles),
        "allowed_resources": sorted(resources),
        "extensions": {
            "logins": list(user_snapshot.get("traits", {}).get("logins", [])),
            "db_users": list(user_snapshot.get("traits", {}).get("db_users", [])),
        },
        "login_time": login_time,
        "expires": expires,
    }
    return "SSH-MODEL1." + _b64url_encode(obj)


def _make_tls_certificate(user_name, active_request_ids, login_time, expires):
    obj = {
        "user": user_name,
        "active_requests": sorted(active_request_ids),
        "login_time": login_time,
        "expires": expires,
    }
    return "TLS-MODEL1." + _b64url_encode(obj)


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = user_history result: {event_index_str: user_snapshot}
    right = grant_catalog result: {request_id: {approved, expiry, roles, resources}}
    """
    user_initial = payload["user"]
    start_time = payload["start_time"]
    session_ttl = payload["session_ttl"]
    events = payload.get("events", [])
    initial_id = payload.get("initial_id", "s0")

    # grant_catalog data
    grants = right  # {id: {approved, expiry, roles, resources}}

    # user_history snapshots keyed by event index string
    user_snapshots = left  # {str(idx): user_snapshot}

    # Session store: id -> session dict
    # Each session: {cached_user, login_time, expiry, active_requests: {req_id: {expiry, roles, resources}}}
    sessions = {}

    # Create initial session s0
    sessions[initial_id] = {
        "cached_user": copy.deepcopy(user_initial),
        "login_time": start_time,
        "expiry": start_time + session_ttl,
        "active_requests": {},  # req_id -> {expiry, roles, resources}
    }

    replies = []
    session_ids = [initial_id]

    # Sort events by time, preserving array order for same time
    indexed_events = list(enumerate(events))
    indexed_events.sort(key=lambda x: x[1].get("time", 0))

    for orig_idx, event in indexed_events:
        op = event.get("op")
        if op == "update_user":
            # update_user is handled by user_history component;
            # we don't need to do anything here since user_snapshots
            # already reflect the updated state at each renew point.
            continue
        elif op == "renew":
            new_id = event["id"]
            prev_id = event["prev"]
            now = event["time"]
            reload_user = event.get("reload_user", False)
            switchback = event.get("switchback", False)
            access_request = event.get("access_request", None)

            # prev must be a successfully created session
            if prev_id not in sessions:
                replies.append({"id": new_id, "status": "error"})
                continue

            prev_session = sessions[prev_id]

            # Check if prev is expired
            if prev_session["expiry"] <= now:
                replies.append({"id": new_id, "status": "expired"})
                continue

            # Determine user snapshot for this event
            # The user_history component records snapshots at renew events by original index
            snapshot_key = str(orig_idx)

            if reload_user:
                # Use latest backend user (from user_history snapshot at this point)
                if snapshot_key in user_snapshots:
                    cached_user = copy.deepcopy(user_snapshots[snapshot_key])
                else:
                    cached_user = copy.deepcopy(prev_session["cached_user"])
            else:
                # Default: carry forward prev's cached user
                cached_user = copy.deepcopy(prev_session["cached_user"])

            # Start with prev's active requests
            active_requests = copy.deepcopy(prev_session["active_requests"])

            if switchback:
                # Clear all temporary requests and resources
                active_requests = {}

            # Handle assume (access_request)
            if access_request is not None:
                grant_id = access_request
                grant = grants.get(grant_id)

                if grant is None or not grant["approved"]:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue

                if grant["expiry"] <= now:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue

                # Check resource_already_active: if any active request has resources,
                # and the new request also has resources, reject
                new_has_resources = len(grant.get("resources", [])) > 0
                if new_has_resources:
                    for req_id, req_data in active_requests.items():
                        if len(req_data.get("resources", [])) > 0:
                            replies.append({"id": new_id, "status": "resource_already_active"})
                            break
                    else:
                        # No conflict, proceed
                        pass
                    # Check if we broke out due to conflict
                    if any(len(req_data.get("resources", [])) > 0 for req_data in active_requests.values()):
                        continue

                # Add/update the request in active_requests
                active_requests[grant_id] = {
                    "expiry": grant["expiry"],
                    "roles": list(grant.get("roles", [])),
                    "resources": list(grant.get("resources", [])),
                }

            # Filter out expired active requests (those with expiry <= now)
            # But per spec: "没有显式切回时，活跃request不得静默丢弃，到期则request_unavailable"
            # This means if an active request has expired and wasn't explicitly switched back,
            # it should cause request_unavailable? Let me re-read...
            # Actually: "到期则request_unavailable" - expired requests become unavailable
            # But the spec says active requests that expire should NOT be silently dropped.
            # If they expire, the status should be request_unavailable.
            # Wait, re-reading: "没有显式切回时，活跃request不得静默丢弃，到期则request_unavailable"
            # This means: without explicit switchback, active requests must not be silently discarded;
            # when they expire, the result is request_unavailable.
            
            # Check for expired active requests
            has_expired_request = False
            for req_id, req_data in list(active_requests.items()):
                if req_data["expiry"] <= now:
                    has_expired_request = True
                    break

            if has_expired_request:
                replies.append({"id": new_id, "status": "request_unavailable"})
                continue

            # Compute roles: cached user base roles ∪ active request roles
            base_roles = set(cached_user.get("roles", []))
            for req_data in active_requests.values():
                base_roles.update(req_data.get("roles", []))
            final_roles = sorted(base_roles)

            # Compute resources: union of active request resources
            all_resources = set()
            for req_data in active_requests.values():
                all_resources.update(req_data.get("resources", []))
            final_resources = sorted(all_resources)

            # Compute expiry: min(now + ttl, all active request expiries)
            new_expiry = now + session_ttl
            for req_data in active_requests.values():
                new_expiry = min(new_expiry, req_data["expiry"])

            # login_time carries forward from prev
            login_time = prev_session["login_time"]

            # Create the new session
            new_session = {
                "cached_user": cached_user,
                "login_time": login_time,
                "expiry": new_expiry,
                "active_requests": active_requests,
            }
            sessions[new_id] = new_session
            session_ids.append(new_id)

            # Generate certificates
            ssh_cert = _make_ssh_certificate(cached_user, final_roles, final_resources, login_time, new_expiry)
            tls_cert = _make_tls_certificate(
                cached_user.get("name", ""),
                list(active_requests.keys()),
                login_time,
                new_expiry,
            )

            replies.append({
                "id": new_id,
                "status": "ok",
                "ssh_certificate": ssh_cert,
                "tls_certificate": tls_cert,
            })

    return {
        "replies": replies,
        "session_ids": session_ids,
    }
