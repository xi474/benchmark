"""C069 – Session renewal, role/resource & identity encoding.

Public entry points
-------------------
* ``transform(payload)``          – pure function, returns result dict, never mutates *payload*.
* ``load_payload(input_path)``    – read a UTF-8 JSON file and return the parsed object.
* ``build_component(input_path, output_path)``
      read → compute → write UTF-8 JSON → return the same result dict.

All three work in a pristine directory with no prior artifacts.
"""

import copy
import json
from pathlib import Path

# Component field projections (mirrors components.json)
_COMPONENT_FIELDS = {
    "user_history": ["events", "user"],
    "grant_catalog": ["access_requests"],
}


def load_payload(input_path):
    """Read a UTF-8 JSON file and return the parsed Python object."""
    return json.loads(Path(input_path).read_text(encoding="utf-8"))


def _project(payload, fields):
    """Return a shallow dict containing only *fields* present in *payload*."""
    return {k: payload[k] for k in fields if k in payload}


def transform(payload):
    """Compute the full business result from *payload* without mutating it.

    Runs both component ``compute()`` functions on their respective field
    projections, then delegates to ``integration.combine``.
    """
    # Deep-copy so that component code can never mutate the caller's object.
    safe = copy.deepcopy(payload)

    from components.user_history.work import compute as user_history_compute
    from components.grant_catalog.work import compute as grant_catalog_compute
    from integration import combine

    left = user_history_compute(_project(safe, _COMPONENT_FIELDS["user_history"]))
    right = grant_catalog_compute(_project(safe, _COMPONENT_FIELDS["grant_catalog"]))

    return combine(safe, left, right)


def build_component(input_path, output_path):
    """Load *input_path*, compute the result, write it to *output_path* as
    compact UTF-8 JSON, and return the result dict."""
    payload = load_payload(input_path)
    result = transform(payload)

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        encoding="utf-8",
    )
    return result
