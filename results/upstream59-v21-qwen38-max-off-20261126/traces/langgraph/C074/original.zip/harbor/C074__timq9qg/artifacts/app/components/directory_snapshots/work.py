import copy


def compute(payload):
    """按扫描轮次生成映射，从每个完成目录的逻辑路径映射至 [保留文件映射,可见子目录名升序数组]。按轮累计替换节点。"""
    nodes = copy.deepcopy(payload.get("nodes", {}))
    mounts = payload.get("mounts", {})
    scans = payload.get("scans", [])

    results = []

    for scan in scans:
        # Apply replacements simultaneously
        replace = scan.get("replace", {})
        if replace:
            new_nodes = {}
            for nid, ndef in replace.items():
                new_nodes[nid] = copy.deepcopy(ndef)
            for nid, ndef in new_nodes.items():
                nodes[nid] = ndef

        finish = scan.get("finish", [])
        round_result = {}

        for logical_path in finish:
            parts = logical_path.split("/")
            mount_name = parts[0]
            dir_parts = parts[1:]

            # Resolve mount to starting node
            if mount_name not in mounts:
                continue
            current_node_id = mounts[mount_name]

            # Navigate through directory segments, checking ignore at each level
            reachable = True
            for seg in dir_parts:
                if current_node_id not in nodes:
                    reachable = False
                    break
                node = nodes[current_node_id]
                ignore_set = set(node.get("ignore", []))
                if seg in ignore_set:
                    reachable = False
                    break
                dirs = node.get("dirs", {})
                if seg not in dirs:
                    reachable = False
                    break
                current_node_id = dirs[seg]

            if not reachable:
                continue

            # Now current_node_id is the target node for this finished directory
            if current_node_id not in nodes:
                continue

            target_node = nodes[current_node_id]
            ignore_set = set(target_node.get("ignore", []))

            # Retained files: files not in ignore list
            files = {}
            for fname, tid in target_node.get("files", {}).items():
                if fname not in ignore_set:
                    files[fname] = tid

            # Visible subdirectories: dirs not in ignore list, sorted
            visible_dirs = sorted(
                dname for dname in target_node.get("dirs", {}).keys()
                if dname not in ignore_set
            )

            round_result[logical_path] = [files, visible_dirs]

        results.append(round_result)

    return results
