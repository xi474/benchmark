def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: list of per-round dicts {logical_path: [files_dict, sorted_visible_dirs]}
    right: list of per-round ordered lists of finished paths (depth-sorted)
    
    Returns: list of per-round {index, changed} objects.
    """
    initial = dict(payload.get("initial", {}))
    index = dict(initial)
    
    results = []
    
    for round_idx in range(len(right)):
        ordered_paths = right[round_idx]  # finished paths in precedence order
        snapshots = left[round_idx]       # {logical_path: [files, visible_dirs]}
        
        old_index = dict(index)
        
        for dir_path in ordered_paths:
            if dir_path not in snapshots:
                continue
            
            files_map, visible_dirs = snapshots[dir_path]
            visible_dirs_set = set(visible_dirs)
            files_set = set(files_map.keys())
            
            prefix = dir_path + "/"
            
            # Collect all index entries under this directory
            # Group by immediate child name
            children_entries = {}  # child_name -> [(full_path, tid)]
            for path, tid in list(index.items()):
                if path.startswith(prefix):
                    remainder = path[len(prefix):]
                    child = remainder.split("/")[0]
                    if child not in children_entries:
                        children_entries[child] = []
                    children_entries[child].append((path, tid))
            
            # Process each child group
            for child, entries in children_entries.items():
                if child in files_set:
                    # This child is now a file. Keep only the exact file entry, remove deeper ones.
                    exact_path = prefix + child
                    for path, tid in entries:
                        if path != exact_path:
                            del index[path]
                    # Set the file entry to current value
                    index[exact_path] = files_map[child]
                elif child in visible_dirs_set:
                    # Visible but unfinished subdir: preserve all entries
                    pass
                else:
                    # Disappeared or ignored: prune all entries under this child
                    for path, tid in entries:
                        del index[path]
            
            # Add new file entries that don't exist yet
            for fname, tid in files_map.items():
                fpath = prefix + fname
                if fpath not in index:
                    index[fpath] = tid
        
        # Compute changed tracks
        changed = _compute_changed(old_index, index)
        
        results.append({
            "index": dict(index),
            "changed": changed
        })
    
    return results


def _compute_changed(old_index, new_index):
    """Compute changed track IDs between old and new index.
    
    Returns dict: track_id -> [sorted_old_paths, sorted_new_paths]
    Only includes tracks where the path sets differ.
    """
    # Build reverse maps: track_id -> set of paths
    old_tracks = {}
    for path, tid in old_index.items():
        if tid not in old_tracks:
            old_tracks[tid] = set()
        old_tracks[tid].add(path)
    
    new_tracks = {}
    for path, tid in new_index.items():
        if tid not in new_tracks:
            new_tracks[tid] = set()
        new_tracks[tid].add(path)
    
    all_tids = set(old_tracks.keys()) | set(new_tracks.keys())
    
    changed = {}
    for tid in all_tids:
        old_paths = old_tracks.get(tid, set())
        new_paths = new_tracks.get(tid, set())
        if old_paths != new_paths:
            changed[tid] = [sorted(old_paths), sorted(new_paths)]
    
    return changed
