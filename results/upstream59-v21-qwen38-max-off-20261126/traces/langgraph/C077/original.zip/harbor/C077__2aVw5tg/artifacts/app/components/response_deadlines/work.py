def compute(payload):
    """按 response 位置记录 [原因,到期时间]；失败优先于陈旧，延迟分别为 2000/1000，正常相应用 null。"""
    events = payload.get("events", [])
    result = {}
    for idx, ev in enumerate(events):
        if ev.get("op") != "response":
            continue
        t = ev["time"]
        if ev.get("failed"):
            result[str(idx)] = ["failure", t + 2000]
        elif ev.get("stale") == 1:
            result[str(idx)] = ["stale", t + 1000]
        else:
            result[str(idx)] = None
    return result
