def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left  = mutation_membership result: {str(event_index): [active_ids...]} for start/finish events
    right = response_deadlines result:  {str(event_index): [reason, deadline] | null} for response events
    
    Returns {fetches, commits, events (audit), state}.
    """
    import copy
    events = payload.get("events", [])
    
    # Build lookup from component results
    # left: keyed by string index -> active list after that event
    # right: keyed by string index -> deadline info for response events
    
    fetches = []
    commits = []
    audit = []
    
    # State
    active = []          # ordered list of active modification IDs
    owed = False         # pending refresh obligation
    in_flight = None     # current fetch id in flight, or None
    retry_at = None      # scheduled retry time, or None
    items = []           # committed items
    fetch_counter = 0    # next fetch number
    
    loading = False
    
    def is_loading():
        """Loading if there's a pending request, retry, or owed refresh."""
        return in_flight is not None or retry_at is not None or owed
    
    def try_fetch(time):
        """Attempt to issue a fetch if conditions allow."""
        nonlocal in_flight, owed, fetch_counter, loading
        # Can't fetch if modifications are active
        if len(active) > 0:
            return
        # Can't fetch if already in flight
        if in_flight is not None:
            return
        # Can't fetch if retry timer is pending
        if retry_at is not None:
            return
        # Need something to fetch (owed obligation)
        if not owed:
            return
        # Issue fetch
        fetch_counter += 1
        fid = f"fetch-{fetch_counter}"
        in_flight = fid
        owed = False
        fetches.append({"id": fid, "time": time})
        audit.append({"time": time, "event": "fetch", "id": fid})
    
    def process_timer(time):
        """Process retry timer if it fires at this time. Timers fire before external events."""
        nonlocal in_flight, retry_at, owed
        if retry_at is not None and retry_at <= time:
            # Timer fires: clear old request mark
            retry_time = retry_at
            retry_at = None
            in_flight = None  # clear old request marking
            # Now try to fetch (retry)
            # But we need owed to be true to fetch. The retry itself implies we need to re-fetch.
            # Set owed so try_fetch can pick it up
            owed = True
            try_fetch(retry_time)
    
    # Process events in order
    for idx, ev in enumerate(events):
        time = ev["time"]
        op = ev.get("op")
        
        # Before processing this event, check if any timer fires at this time
        # Timers fire before external events at the same time
        process_timer(time)
        
        if op == "start":
            mid = ev["id"]
            # Use component result for active list
            active = list(left[str(idx)])
            audit.append({"time": time, "event": "modification_started", "id": mid})
            
        elif op == "finish":
            mid = ev["id"]
            # Use component result for active list
            active = list(left[str(idx)])
            audit.append({"time": time, "event": "modification_finished", "id": mid})
            # Finish produces owed obligation
            owed = True
            # Try to fetch (only if this was the last active modification)
            try_fetch(time)
            
        elif op == "refresh":
            # Refresh produces owed obligation
            owed = True
            # If there's already a retry timer or in-flight, obligation merges
            # Try to fetch
            try_fetch(time)
            
        elif op == "response":
            fid = ev["id"]
            deadline_info = right.get(str(idx))
            
            if deadline_info is None:
                # Success response
                # Commit items
                resp_items = ev.get("items", [])
                items = items + resp_items
                commits.append({"time": time, "items": list(resp_items)})
                audit.append({"time": time, "event": "committed", "id": fid})
                in_flight = None
                
                # If still owed and no modifications blocking, fetch again
                if owed and len(active) == 0:
                    try_fetch(time)
                    
            elif deadline_info[0] == "failure":
                # Failed: don't commit, set retry timer
                audit.append({"time": time, "event": "retry_scheduled", "due": deadline_info[1], "reason": "failure"})
                if retry_at is None:
                    retry_at = deadline_info[1]
                # in_flight stays (request is done but we track via retry)
                # Actually per spec: failed sets unique timer. in_flight should be cleared
                # since the request completed (just failed). But retry_at tracks the pending retry.
                in_flight = None
                
            elif deadline_info[0] == "stale":
                # Stale: don't commit, set retry timer, keep in_flight until timer fires
                audit.append({"time": time, "event": "retry_scheduled", "due": deadline_info[1], "reason": "stale"})
                if retry_at is None:
                    retry_at = deadline_info[1]
                # Keep in_flight as-is (spec says "保持原request标记为in_flight直至到点")
                
        elif op == "advance":
            # advance doesn't produce obligations or affect state directly
            pass
    
    # After all events, process any remaining timer
    # (shouldn't normally happen in well-formed input, but just in case)
    
    loading = is_loading()
    
    state = {
        "active": list(active),
        "owed": owed,
        "loading": loading,
        "placeholders": loading,
        "in_flight": in_flight,
        "retry_at": retry_at,
        "items": items
    }
    
    return {
        "fetches": fetches,
        "commits": commits,
        "events": audit,
        "state": state
    }
