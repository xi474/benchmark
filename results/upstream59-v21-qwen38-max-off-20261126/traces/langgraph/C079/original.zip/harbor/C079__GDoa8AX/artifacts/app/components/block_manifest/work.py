def compute(payload):
    """返回 [kind,index,hex] 列表；若有缩略图则排首，再按块大小顺序切出文件块。"""
    result = []
    chunk_size = payload["chunk_size"]

    # Thumbnail first if present (even if empty hex string)
    if "thumbnail_hex" in payload:
        result.append(["thumbnail", 0, payload["thumbnail_hex"]])

    # Split file_hex into chunks of chunk_size bytes
    file_hex = payload.get("file_hex", "")
    # Each byte is 2 hex chars
    hex_chunk_size = chunk_size * 2
    index = 0
    for i in range(0, len(file_hex), hex_chunk_size):
        chunk = file_hex[i:i + hex_chunk_size]
        result.append(["file", index, chunk])
        index += 1

    return result
