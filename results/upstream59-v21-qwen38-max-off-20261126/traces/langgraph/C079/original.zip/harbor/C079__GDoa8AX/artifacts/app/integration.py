"""Integration layer: AES-256-GCM encrypt/verify/retry with nonce sequencing."""
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = block_manifest result: list of [kind, index, hex]
    right = retry_faults result: dict mapping block label -> sorted list of corrupt attempt indices
    """
    # Parse key and base nonce
    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce_int = int(payload["base_nonce_hex"], 16)
    max_retries = payload["max_retries"]

    aesgcm = AESGCM(session_key)

    blocks_out = []
    attempts_out = []
    notifications = []
    failed_block = None
    file_sha_parts = []  # collect plaintext bytes of successful file blocks only

    global_attempt = 0  # global attempt counter for nonce sequencing

    for kind, index, hex_data in left:
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(hex_data)
        aad = f"{kind}:{index}".encode("utf-8")

        block_verified = False
        first_failure_notified = False

        for local_attempt in range(1 + max_retries):
            # Compute nonce for this attempt
            nonce_int = base_nonce_int + global_attempt
            nonce = nonce_int.to_bytes(12, "big")

            # Encrypt
            ciphertext = aesgcm.encrypt(nonce, plaintext, aad)

            # Apply corruption if this local attempt is listed for this block
            corrupt_list = right.get(label, [])
            if local_attempt in corrupt_list:
                # Flip the lowest bit of the last byte of ciphertext
                ct_bytes = bytearray(ciphertext)
                ct_bytes[-1] ^= 0x01
                ciphertext = bytes(ct_bytes)

            # Verify by decrypting
            verified = False
            try:
                decrypted = aesgcm.decrypt(nonce, ciphertext, aad)
                if decrypted == plaintext:
                    verified = True
            except Exception:
                pass

            attempts_out.append({
                "block": label,
                "attempt": local_attempt,
                "verified": verified,
            })

            global_attempt += 1

            if verified:
                # Success: publish this block
                blocks_out.append({
                    "kind": kind,
                    "index": index,
                    "nonce_hex": nonce.hex(),
                    "ciphertext_hex": ciphertext.hex(),
                    "plaintext_sha256": hashlib.sha256(plaintext).hexdigest(),
                })
                # Accumulate file plaintext for SHA256 (not thumbnail)
                if kind == "file":
                    file_sha_parts.append(plaintext)
                block_verified = True
                break
            else:
                # Verification failed
                if not first_failure_notified:
                    notifications.append({
                        "block": label,
                        "error": "verification_failed",
                    })
                    first_failure_notified = True

        if not block_verified:
            # Exhausted all retries for this block
            failed_block = label
            break

    # Compute file_sha256 from successfully processed file blocks
    if file_sha_parts:
        file_sha256 = hashlib.sha256(b"".join(file_sha_parts)).hexdigest()
    else:
        file_sha256 = hashlib.sha256(b"").hexdigest()

    status = "ok" if failed_block is None else "verification_failed"

    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks_out,
        "attempts": attempts_out,
        "notifications": notifications,
        "file_sha256": file_sha256,
    }
