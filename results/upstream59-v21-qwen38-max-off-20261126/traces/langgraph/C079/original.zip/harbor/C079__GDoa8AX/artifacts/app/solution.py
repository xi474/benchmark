"""Solution entry points: transform, load_payload, build_component.

All three wire through integration.combine and work in a clean directory
without requiring pre-existing artifacts.
"""
import json
from pathlib import Path

from components.block_manifest.work import compute as _block_manifest_compute
from components.retry_faults.work import compute as _retry_faults_compute
from integration import combine


# Fields each component needs from the full payload (mirrors components.json)
_BLOCK_MANIFEST_FIELDS = ("file_hex", "chunk_size", "thumbnail_hex")
_RETRY_FAULTS_FIELDS = ("corrupt_attempts", "max_retries")


def _project(payload, fields):
    """Return a dict containing only the listed keys that exist in payload."""
    return {k: payload[k] for k in fields if k in payload}


def load_payload(input_path):
    """Read a UTF-8 JSON file and return the parsed object."""
    return json.loads(Path(input_path).read_text(encoding="utf-8"))


def transform(payload):
    """Compute the full business result from an in-memory payload.

    Evaluates both components inline (no disk artifacts required) and
    passes their outputs to integration.combine.  Does not mutate *payload*.
    """
    left = _block_manifest_compute(_project(payload, _BLOCK_MANIFEST_FIELDS))
    right = _retry_faults_compute(_project(payload, _RETRY_FAULTS_FIELDS))
    return combine(payload, left, right)


def build_component(input_path, output_path):
    """Read input, compute the full result, write it as UTF-8 JSON, and return it.

    Works in a fresh directory with no prior artifacts.
    """
    payload = load_payload(input_path)
    result = transform(payload)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    return result
