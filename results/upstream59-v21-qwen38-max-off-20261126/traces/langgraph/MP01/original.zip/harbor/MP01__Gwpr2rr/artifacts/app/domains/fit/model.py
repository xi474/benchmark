import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check that no NaN or Infinity exists in the JSON structure."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("Non-finite number found in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read UTF-8 JSON from path. Top-level must be object or array. Reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("Top-level JSON must be object or array")
    _check_finite(data)
    return data
