import json
import sys
from pathlib import Path

# Add component dir to path so model/transform can be imported
_component_dir = Path(__file__).resolve().parent
if str(_component_dir) not in sys.path:
    sys.path.insert(0, str(_component_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    return result


def _write_json(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    p.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    # Determine root and contract path
    # When run as `python3 <component_dir>/render.py`, cwd is workspace root
    root = Path.cwd()
    contract_path = Path(__file__).resolve().parent / "contract.json"
    result = build_component(root, contract_path)
    contract = load_payload(contract_path)
    output_path = root / contract["output"]
    _write_json(output_path, result)
