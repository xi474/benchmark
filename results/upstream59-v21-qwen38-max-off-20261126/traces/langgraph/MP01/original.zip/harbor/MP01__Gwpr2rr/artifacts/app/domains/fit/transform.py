import copy


def _is_finite_number(v):
    """Check v is a finite number (int or float), not bool."""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        import math
        return math.isfinite(v)
    return False


def _is_non_negative_number(v):
    return _is_finite_number(v) and v >= 0


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("Input must be an object")

    # Validate required fields
    for field in ("classes", "sample_weight", "members"):
        if field not in data:
            raise ValueError(f"Missing required field: {field}")

    classes = data["classes"]
    sample_weight = data["sample_weight"]
    members = data["members"]

    # Validate classes: list of unique non-empty strings
    if not isinstance(classes, list):
        raise ValueError("classes must be a list")
    seen_classes = set()
    for c in classes:
        if not isinstance(c, str) or not c.strip():
            raise ValueError("Each class must be a non-empty string")
        if c in seen_classes:
            raise ValueError(f"Duplicate class: {c}")
        seen_classes.add(c)

    global_classes = list(classes)

    # Validate sample_weight: list of non-negative numbers
    if not isinstance(sample_weight, list):
        raise ValueError("sample_weight must be a list")
    for sw in sample_weight:
        if not _is_non_negative_number(sw):
            raise ValueError("Each sample_weight must be a non-negative number")
    sample_count = len(sample_weight)

    # Validate members
    if not isinstance(members, list):
        raise ValueError("members must be a list")

    seen_ids = set()
    active_members = []

    for m in members:
        if not isinstance(m, dict):
            raise ValueError("Each member must be an object")
        if "id" not in m:
            raise ValueError("Member missing id")
        if "active" not in m:
            raise ValueError("Member missing active")

        mid = m["id"]
        if not isinstance(mid, str):
            raise ValueError("Member id must be a string")
        if mid in seen_ids:
            raise ValueError(f"Duplicate member id: {mid}")
        seen_ids.add(mid)

        active = m["active"]
        if not isinstance(active, bool):
            raise ValueError("Member active must be bool")

        if not active:
            # Closed member: only validate id/active, skip rest
            continue

        # Active member: validate all fields
        if "weight" not in m:
            raise ValueError("Active member missing weight")
        if "predictions" not in m:
            raise ValueError("Active member missing predictions")
        if "classes" not in m:
            raise ValueError("Active member missing classes")
        if "probabilities" not in m:
            raise ValueError("Active member missing probabilities")

        w = m["weight"]
        if not _is_non_negative_number(w):
            raise ValueError("Member weight must be a non-negative number")

        preds = m["predictions"]
        if not isinstance(preds, list):
            raise ValueError("Member predictions must be a list")
        if len(preds) != sample_count:
            raise ValueError("Member predictions length must equal sample_count")
        for p in preds:
            if not isinstance(p, str):
                raise ValueError("Each prediction must be a string")
            if p not in seen_classes:
                raise ValueError(f"Prediction '{p}' not in global classes")

        m_classes = m["classes"]
        if not isinstance(m_classes, list):
            raise ValueError("Member classes must be a list")
        # Must be a permutation of global classes
        if sorted(m_classes) != sorted(global_classes):
            raise ValueError("Member classes must be a permutation of global classes")
        # Check uniqueness
        if len(set(m_classes)) != len(m_classes):
            raise ValueError("Member classes must be unique")
        for mc in m_classes:
            if not isinstance(mc, str):
                raise ValueError("Each member class must be a string")

        probs = m["probabilities"]
        if not isinstance(probs, list):
            raise ValueError("Member probabilities must be a list")
        if len(probs) != sample_count:
            raise ValueError("Member probabilities rows must equal sample_count")
        num_classes = len(global_classes)
        for row in probs:
            if not isinstance(row, list):
                raise ValueError("Each probability row must be a list")
            if len(row) != len(m_classes):
                raise ValueError("Probability row length must match member classes length")
            row_sum = 0.0
            for val in row:
                if not _is_non_negative_number(val):
                    raise ValueError("Each probability must be a non-negative number")
                row_sum += val
            if abs(row_sum - 1.0) > 1e-9:
                raise ValueError("Probability row sum must be close to 1")

        active_members.append(m)

    # At least one active member with weight sum > 0
    if not active_members:
        raise ValueError("At least one active member required")
    total_weight = sum(m["weight"] for m in active_members)
    if total_weight <= 0:
        raise ValueError("Sum of active member weights must be > 0")

    # Build result: deep copy active members, add fit_weight = sample_weight
    result_members = []
    for m in active_members:
        mc = copy.deepcopy(m)
        mc["fit_weight"] = list(sample_weight)
        result_members.append(mc)

    result = {
        "classes": list(global_classes),
        "sample_count": sample_count,
        "members": result_members,
    }

    return {"name": contract["name"], "result": result}
