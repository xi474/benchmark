import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # Compute sha256 of the canonical serialization
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    components = core.get("components", {})
    attention_set = set()

    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # Check blocked explicitly true
        if result.get("blocked") is True:
            attention_set.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention_set.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None:
                # Non-empty check: for lists/dicts/strings, check truthiness; 
                # but spec says "non-empty", so empty list/dict/string doesn't trigger
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention_set.add(comp_name)
                elif isinstance(val, (int, float, bool)):
                    # These are not "empty" containers, they are values
                    # The spec says "non-empty" which applies to collections
                    # But let's be safe: only trigger for non-empty collections
                    pass

    attention = sorted(attention_set)

    report = {
        "title": "可关闭成员的硬/软加权投票",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": attention,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
