import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("No contracts found")

    # Build dependency graph: each contract's inputs may reference other contract outputs
    # Map output path -> contract path
    output_to_contract = {}
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_data[cp] = c
        output_to_contract[c["output"]] = cp

    # Topological sort based on dependencies
    # A contract depends on another if any of its inputs matches another contract's output
    deps = {}  # cp -> set of cp it depends on
    for cp in contracts:
        c = contract_data[cp]
        dep_set = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                if dep_cp != cp:
                    dep_set.add(dep_cp)
        deps[cp] = dep_set

    # Kahn's algorithm for topological sort
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    reverse_deps = {cp: set() for cp in contracts}
    for cp in contracts:
        for d in deps[cp]:
            reverse_deps[d].add(cp)

    queue = [cp for cp in contracts if in_degree[cp] == 0]
    order = []
    while queue:
        queue.sort()  # deterministic ordering
        node = queue.pop(0)
        order.append(node)
        for dependent in reverse_deps[node]:
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    if len(order) != len(contracts):
        raise ValueError("Dependency cycle detected")

    # Execute each component in topological order
    for cp in order:
        render_py = cp.parent / "render.py"
        if not render_py.exists():
            raise ValueError(f"render.py not found for {cp}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Component {cp} failed with exit code {result.returncode}")

    # Run integrate.py
    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"integrate.py failed with exit code {result.returncode}")

    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"final_report.py failed with exit code {result.returncode}")


if __name__ == "__main__":
    main()
