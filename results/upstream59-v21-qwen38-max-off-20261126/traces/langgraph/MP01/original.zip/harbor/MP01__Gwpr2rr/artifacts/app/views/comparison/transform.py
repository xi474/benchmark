def _extract_result(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result; else return payload."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    hard_data = _extract_result(payloads[0])
    soft_data = _extract_result(payloads[1])

    hard_preds = hard_data["predictions"]
    soft_preds = soft_data["predictions"]

    if len(hard_preds) != len(soft_preds):
        raise ValueError("Sample count mismatch between hard and soft predictions")

    disagreements = []
    for i in range(len(hard_preds)):
        if hard_preds[i] != soft_preds[i]:
            disagreements.append(i)

    result = {
        "hard": hard_preds,
        "soft": soft_preds,
        "disagreements": disagreements,
    }

    return {"name": contract["name"], "result": result}
