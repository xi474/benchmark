def _extract_result(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result; else return payload."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    fit_data = _extract_result(payloads[0])

    global_classes = fit_data["classes"]
    sample_count = fit_data["sample_count"]
    members = fit_data["members"]

    # For each sample, accumulate weighted votes per class
    scores = []  # list of lists, one per sample, each inner list has votes per global class
    predictions = []

    for i in range(sample_count):
        votes = {c: 0.0 for c in global_classes}
        for m in members:
            w = m["weight"]
            pred = m["predictions"][i]
            votes[pred] += w
        # Build score list in global classes order
        score_row = [votes[c] for c in global_classes]
        scores.append(score_row)

        # Find max vote, tie-break by global classes order (first in list wins)
        max_vote = -1.0
        best_class = global_classes[0]
        for c in global_classes:
            if votes[c] > max_vote:
                max_vote = votes[c]
                best_class = c
        predictions.append(best_class)

    result = {
        "predictions": predictions,
        "scores": scores,
    }

    return {"name": contract["name"], "result": result}
