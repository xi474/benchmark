def _extract_result(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result; else return payload."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    fit_data = _extract_result(payloads[0])

    global_classes = fit_data["classes"]
    sample_count = fit_data["sample_count"]
    members = fit_data["members"]
    num_classes = len(global_classes)

    # For each sample, compute weighted average of probabilities mapped to global classes
    avg_probs = []  # list of lists, one per sample
    predictions = []

    for i in range(sample_count):
        weighted_sum = [0.0] * num_classes
        total_weight = 0.0

        for m in members:
            w = m["weight"]
            m_classes = m["classes"]
            probs_row = m["probabilities"][i]

            # Map member's probability columns to global class indices
            for j, mc in enumerate(m_classes):
                gi = global_classes.index(mc)
                weighted_sum[gi] += w * probs_row[j]
            total_weight += w

        # Normalize by total weight
        if total_weight > 0:
            prob_row = [ws / total_weight for ws in weighted_sum]
        else:
            prob_row = [0.0] * num_classes

        avg_probs.append(prob_row)

        # Predict: argmax with tie-break by global classes order
        max_prob = -1.0
        best_class = global_classes[0]
        for ci, c in enumerate(global_classes):
            if prob_row[ci] > max_prob:
                max_prob = prob_row[ci]
                best_class = c
        predictions.append(best_class)

    result = {
        "predictions": predictions,
        "probabilities": avg_probs,
    }

    return {"name": contract["name"], "result": result}
