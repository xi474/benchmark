import copy
import json


def _validate_finite_number(v):
    """Check that v is a finite number (int or float, not bool)."""
    if isinstance(v, bool):
        raise ValueError(f"Boolean is not a valid number")
    if not isinstance(v, (int, float)):
        raise ValueError(f"Expected finite number, got {type(v).__name__}")
    if isinstance(v, float):
        import math
        if math.isnan(v) or math.isinf(v):
            raise ValueError("Non-finite number")


def _json_equal(a, b):
    """Deep equality comparison using JSON semantics."""
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == \
           json.dumps(b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def _validate_input(payload):
    """Validate the segment_attributes input payload."""
    if not isinstance(payload, dict):
        raise ValueError("Input must be an object")

    for field in ("columns", "pieces", "attribute_policy"):
        if field not in payload:
            raise ValueError(f"Missing required field: {field}")

    columns = payload["columns"]
    pieces = payload["pieces"]
    attribute_policy = payload["attribute_policy"]

    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    seen_cols = set()
    for c in columns:
        if not isinstance(c, str):
            raise ValueError("Column names must be strings")
        if c in seen_cols:
            raise ValueError(f"Duplicate column name: {c}")
        seen_cols.add(c)

    if attribute_policy not in ("drop_conflicts", "first"):
        raise ValueError(f"Invalid attribute_policy: {attribute_policy}")

    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")

    all_coords = set()
    piece_ids = set()

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("Each piece must be an object")

        for field in ("id", "coordinates", "data", "attrs"):
            if field not in piece:
                raise ValueError(f"Piece missing required field: {field}")

        pid = piece["id"]
        if not isinstance(pid, str):
            raise ValueError("Piece id must be a string")
        if pid in piece_ids:
            raise ValueError(f"Duplicate piece id: {pid}")
        piece_ids.add(pid)

        coords = piece["coordinates"]
        if not isinstance(coords, list):
            raise ValueError("coordinates must be a list")

        coord_set = set()
        for c in coords:
            _validate_finite_number(c)
            if c in coord_set:
                raise ValueError(f"Duplicate coordinate in piece {pid}: {c}")
            coord_set.add(c)
            if c in all_coords:
                raise ValueError(f"Coordinate {c} overlaps across pieces")
            all_coords.add(c)

        data = piece["data"]
        if not isinstance(data, list):
            raise ValueError("data must be a list")

        if len(data) != len(coords):
            raise ValueError(f"data rows ({len(data)}) != coordinates length ({len(coords)}) in piece {pid}")

        for row in data:
            if not isinstance(row, list):
                raise ValueError("Each data row must be a list")
            if len(row) != len(columns):
                raise ValueError(f"Data row width ({len(row)}) != columns length ({len(columns)}) in piece {pid}")
            for val in row:
                _validate_finite_number(val)

        attrs = piece["attrs"]
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be an object")

    return columns, pieces, attribute_policy


def transform(payloads, contract):
    """segment_attributes: merge piece attributes based on attribute_policy."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    payload = payloads[0]
    columns, pieces, attribute_policy = _validate_input(payload)

    # Collect all attribute keys and their values per piece order
    # key -> list of values in piece order
    attr_values = {}
    for piece in pieces:
        attrs = piece["attrs"]
        for k, v in attrs.items():
            if k not in attr_values:
                attr_values[k] = []
            attr_values[k].append(v)

    merged_attrs = {}
    conflicts = []

    for key in sorted(attr_values.keys()):
        values = attr_values[key]
        if attribute_policy == "first":
            # Take first value encountered
            merged_attrs[key] = values[0]
        elif attribute_policy == "drop_conflicts":
            # Only keep if all values are equal (JSON deep equality)
            # Missing doesn't count as conflict - but here we only have values from pieces that have the key
            all_same = all(_json_equal(values[0], v) for v in values[1:])
            if all_same:
                merged_attrs[key] = values[0]
            else:
                conflicts.append(key)

    # Sort conflicts
    conflicts.sort()

    result = {
        "attrs": merged_attrs,
        "conflicts": conflicts
    }

    return {"name": contract["name"], "result": result}
