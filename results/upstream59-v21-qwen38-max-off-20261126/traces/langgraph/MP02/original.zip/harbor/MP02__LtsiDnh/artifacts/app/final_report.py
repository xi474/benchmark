"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # Compute sha256 of the complete core object
    # Serialized with specific format: no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(serialized).hexdigest()

    components = core.get("components", {})
    component_count = len(components)

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # Check blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            if key in result:
                val = result[key]
                # Non-empty: for lists/dicts/strings, check truthiness; 
                # but we need to be careful - "non-empty" means the value exists and is not empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float, bool)) and val:
                    # For non-collection types, non-empty doesn't apply the same way
                    # But the spec says "non-empty" which typically applies to collections
                    pass

    attention_sorted = sorted(attention)

    report = {
        "title": "单变化轴的数据分片拼接",
        "component_count": component_count,
        "sha256": sha256_hex,
        "attention": attention_sorted
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
