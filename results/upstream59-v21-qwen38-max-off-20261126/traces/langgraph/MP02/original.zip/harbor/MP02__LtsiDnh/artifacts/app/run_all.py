"""Orchestrate all components based on their contract.json files.

Execution order respects dependencies:
1. domains/index (depends only on inputs)
2. domains/attributes (depends only on inputs)
3. views/table (depends on inputs + index output + attributes output)
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _find_contracts():
    """Find all contract.json files not in outputs directory."""
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def _topological_sort(contracts):
    """Sort contracts by dependency order.
    
    A component depends on another if its inputs reference the other's output.
    """
    # Build a map from output path to contract
    output_to_contract = {}
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_data[cp] = c
        output_to_contract[c["output"]] = cp

    # Build dependency graph
    deps = {}  # cp -> set of cp it depends on
    for cp, c in contract_data.items():
        deps[cp] = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                deps[cp].add(output_to_contract[inp])

    # Topological sort (Kahn's algorithm)
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    result = []

    while queue:
        queue.sort()  # deterministic ordering
        cp = queue.pop(0)
        result.append(cp)
        for other_cp in contracts:
            if cp in deps[other_cp]:
                deps[other_cp].discard(cp)
                in_degree[other_cp] -= 1
                if in_degree[other_cp] == 0:
                    queue.append(other_cp)

    if len(result) != len(contracts):
        raise ValueError("Dependency cycle detected")

    return result


def main():
    contracts = _find_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    ordered = _topological_sort(contracts)

    for cp in ordered:
        render_script = cp.with_name("render.py")
        if not render_script.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)

        proc = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            timeout=60
        )
        if proc.returncode != 0:
            print(f"Component {cp} failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)

    # Run integrate.py
    integrate_script = ROOT / "integrate.py"
    if integrate_script.exists():
        proc = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=ROOT,
            timeout=60
        )
        if proc.returncode != 0:
            print(f"integrate.py failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)

    # Run final_report.py
    report_script = ROOT / "final_report.py"
    if report_script.exists():
        proc = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=ROOT,
            timeout=60
        )
        if proc.returncode != 0:
            print(f"final_report.py failed with exit code {proc.returncode}", file=sys.stderr)
            sys.exit(proc.returncode)


if __name__ == "__main__":
    main()
