import json
import sys
from pathlib import Path

# Ensure the component directory is on sys.path for imports
_COMPONENT_DIR = Path(__file__).resolve().parent
if str(_COMPONENT_DIR) not in sys.path:
    sys.path.insert(0, str(_COMPONENT_DIR))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return envelope."""
    root = Path(root).resolve()
    contract_path = Path(contract_path).resolve()
    contract = load_payload(contract_path)

    payloads = []
    for inp in contract["inputs"]:
        payload_path = root / inp
        payloads.append(load_payload(payload_path))

    result = transform(payloads, contract)
    return result


def _write_json(path, data):
    """Write JSON with standard formatting."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    p.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    # Determine root and contract path relative to this script
    component_dir = Path(__file__).resolve().parent
    contract_path = component_dir / "contract.json"
    # Root is the workspace root (two levels up from component dir: component -> views -> root)
    root = component_dir.parents[1]

    envelope = build_component(root, contract_path)

    contract = load_payload(contract_path)
    output_path = root / contract["output"]
    _write_json(output_path, envelope)
