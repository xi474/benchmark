import copy
import json


def _validate_finite_number(v):
    """Check that v is a finite number (int or float, not bool)."""
    if isinstance(v, bool):
        raise ValueError(f"Boolean is not a valid number")
    if not isinstance(v, (int, float)):
        raise ValueError(f"Expected finite number, got {type(v).__name__}")
    if isinstance(v, float):
        import math
        if math.isnan(v) or math.isinf(v):
            raise ValueError("Non-finite number")


def _json_equal(a, b):
    """Deep equality comparison using JSON semantics."""
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == \
           json.dumps(b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def _validate_case_input(payload):
    """Validate the original case.json input."""
    if not isinstance(payload, dict):
        raise ValueError("Input must be an object")

    for field in ("columns", "pieces", "attribute_policy"):
        if field not in payload:
            raise ValueError(f"Missing required field: {field}")

    columns = payload["columns"]
    pieces = payload["pieces"]
    attribute_policy = payload["attribute_policy"]

    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    seen_cols = set()
    for c in columns:
        if not isinstance(c, str):
            raise ValueError("Column names must be strings")
        if c in seen_cols:
            raise ValueError(f"Duplicate column name: {c}")
        seen_cols.add(c)

    if attribute_policy not in ("drop_conflicts", "first"):
        raise ValueError(f"Invalid attribute_policy: {attribute_policy}")

    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")

    all_coords = set()
    piece_ids = set()
    piece_map = {}

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("Each piece must be an object")

        for field in ("id", "coordinates", "data", "attrs"):
            if field not in piece:
                raise ValueError(f"Piece missing required field: {field}")

        pid = piece["id"]
        if not isinstance(pid, str):
            raise ValueError("Piece id must be a string")
        if pid in piece_ids:
            raise ValueError(f"Duplicate piece id: {pid}")
        piece_ids.add(pid)

        coords = piece["coordinates"]
        if not isinstance(coords, list):
            raise ValueError("coordinates must be a list")

        coord_set = set()
        for c in coords:
            _validate_finite_number(c)
            if c in coord_set:
                raise ValueError(f"Duplicate coordinate in piece {pid}: {c}")
            coord_set.add(c)
            if c in all_coords:
                raise ValueError(f"Coordinate {c} overlaps across pieces")
            all_coords.add(c)

        data = piece["data"]
        if not isinstance(data, list):
            raise ValueError("data must be a list")

        if len(data) != len(coords):
            raise ValueError(f"data rows ({len(data)}) != coordinates length ({len(coords)}) in piece {pid}")

        for row in data:
            if not isinstance(row, list):
                raise ValueError("Each data row must be a list")
            if len(row) != len(columns):
                raise ValueError(f"Data row width ({len(row)}) != columns length ({len(columns)}) in piece {pid}")
            for val in row:
                _validate_finite_number(val)

        attrs = piece["attrs"]
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be an object")

        piece_map[pid] = piece

    return columns, pieces, attribute_policy, piece_map


def _validate_index_output(payload):
    """Validate segment_index output."""
    if not isinstance(payload, dict):
        raise ValueError("Index output must be an object")
    for field in ("columns", "order"):
        if field not in payload:
            raise ValueError(f"Index output missing field: {field}")
    return payload


def _validate_attributes_output(payload):
    """Validate segment_attributes output."""
    if not isinstance(payload, dict):
        raise ValueError("Attributes output must be an object")
    for field in ("attrs", "conflicts"):
        if field not in payload:
            raise ValueError(f"Attributes output missing field: {field}")
    return payload


def transform(payloads, contract):
    """segment_assemble: assemble final table from upstream results."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    case_payload = payloads[0]
    index_result = payloads[1]
    attributes_result = payloads[2]

    # Handle envelope: if input has name/result keys, extract result
    if isinstance(index_result, dict) and set(index_result.keys()) == {"name", "result"}:
        index_data = index_result["result"]
    else:
        index_data = index_result

    if isinstance(attributes_result, dict) and set(attributes_result.keys()) == {"name", "result"}:
        attributes_data = attributes_result["result"]
    else:
        attributes_data = attributes_result

    columns, pieces, attribute_policy, piece_map = _validate_case_input(case_payload)
    index_out = _validate_index_output(index_data)
    attrs_out = _validate_attributes_output(attributes_data)

    order = index_out["order"]

    # Build assembled table following the upstream order
    coordinates = []
    data = []

    for entry in order:
        coord = entry["coordinate"]
        piece_id = entry["piece"]
        row_idx = entry["row"]

        piece = piece_map[piece_id]
        row_data = piece["data"][row_idx]

        coordinates.append(coord)
        data.append(list(row_data))  # copy

    result = {
        "coordinates": coordinates,
        "columns": list(columns),
        "data": data,
        "attrs": attrs_out["attrs"],
        "attribute_conflicts": attrs_out["conflicts"]
    }

    return {"name": contract["name"], "result": result}
