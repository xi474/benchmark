import json
import sys
from pathlib import Path

# Ensure component directory is on path for imports
_component_dir = Path(__file__).resolve().parent
if str(_component_dir) not in sys.path:
    sys.path.insert(0, str(_component_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Load inputs per contract, run transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = []
    for inp in contract['inputs']:
        payloads.append(load_payload(root / inp))

    result = transform(payloads, contract)
    return result


def _write_output(root, contract_path):
    """Build component and write output to contract-specified path."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    result = build_component(root, contract_path)

    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result


if __name__ == "__main__":
    # Determine workspace root: go up from this script's directory to find the workspace
    script_dir = Path(__file__).resolve().parent
    # The component dir is e.g. domains/fstab; root is two levels up
    root = script_dir.parents[1]
    contract_path = script_dir / 'contract.json'
    _write_output(root, contract_path)
