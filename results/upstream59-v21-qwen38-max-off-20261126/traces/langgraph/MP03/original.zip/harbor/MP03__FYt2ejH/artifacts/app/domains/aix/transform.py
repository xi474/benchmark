def transform(payloads, contract):
    """Parse AIX mount format from case.json payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("input must be object")
    if 'aix' not in case:
        raise ValueError("missing 'aix' field")

    aix_str = case['aix']
    if not isinstance(aix_str, str):
        raise ValueError("'aix' must be string")

    records = []
    current_mount = None
    current_attrs = {}
    known_keys = {'dev', 'vfs', 'options'}

    def _flush():
        nonlocal current_mount, current_attrs
        if current_mount is not None:
            if 'dev' not in current_attrs:
                raise ValueError(f"missing required 'dev' for mount {current_mount}")
            device = current_attrs['dev']
            fstype = current_attrs.get('vfs', 'jfs2')
            options_str = current_attrs.get('options', 'rw')
            # Parse options: comma-split, dedup, sort
            parts = options_str.split(',')
            seen = set()
            unique = []
            for p in parts:
                if p not in seen:
                    seen.add(p)
                    unique.append(p)
            opts = sorted(unique)
            records.append({
                'device': device,
                'mount': current_mount,
                'fstype': fstype,
                'options': opts,
            })
        current_mount = None
        current_attrs = {}

    for line in aix_str.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue

        # Check if this is a mount point header (non-indented, ends with ':')
        # Non-indented means original line doesn't start with whitespace
        if not line[0:1].isspace() and stripped.endswith(':'):
            _flush()
            current_mount = stripped[:-1].strip()
            if not current_mount:
                raise ValueError("empty mount point")
            current_attrs = {}
        elif '=' in stripped:
            if current_mount is None:
                raise ValueError("attribute without mount point header")
            key, _, value = stripped.partition('=')
            key = key.strip()
            value = value.strip()
            if key not in known_keys:
                raise ValueError(f"unknown key '{key}'")
            if key in current_attrs:
                raise ValueError(f"duplicate key '{key}'")
            current_attrs[key] = value
        else:
            # Non-empty line that's not a header and not key=value
            if current_mount is None:
                raise ValueError("content without mount point header")
            raise ValueError(f"invalid line format: {stripped}")

    _flush()

    return {'name': contract['name'], 'result': {'records': records}}
