def _decode_escapes(s):
    """Decode \\040 -> space, \\011 -> tab, \\134 -> backslash."""
    result = []
    i = 0
    while i < len(s):
        if s[i] == '\\' and i + 3 < len(s) and s[i+1:i+4].isdigit():
            code = s[i+1:i+4]
            val = int(code, 8)
            if code == '040':
                result.append(' ')
            elif code == '011':
                result.append('\t')
            elif code == '134':
                result.append('\\')
            else:
                # Other octal escapes - keep as-is per spec (only these three specified)
                result.append(s[i])
                result.append(s[i+1:i+4])
            i += 4
        else:
            result.append(s[i])
            i += 1
    return ''.join(result)


def _parse_options(opts_str):
    """Comma-split, dedup, sort options."""
    parts = opts_str.split(',')
    seen = set()
    unique = []
    for p in parts:
        if p not in seen:
            seen.add(p)
            unique.append(p)
    return sorted(unique)


def transform(payloads, contract):
    """Parse fstab format from case.json payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("input must be object")
    if 'fstab' not in case:
        raise ValueError("missing 'fstab' field")

    fstab_str = case['fstab']
    if not isinstance(fstab_str, str):
        raise ValueError("'fstab' must be string")

    records = []
    for line in fstab_str.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        cols = stripped.split()
        if len(cols) < 4 or len(cols) > 6:
            raise ValueError(f"fstab line must have 4-6 columns: {stripped}")
        device = _decode_escapes(cols[0])
        mount = _decode_escapes(cols[1])
        fstype = _decode_escapes(cols[2])
        options = _parse_options(_decode_escapes(cols[3]))
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': options,
        })

    return {'name': contract['name'], 'result': {'records': records}}
