import re


def _decode_escapes(s):
    """Decode \\040 -> space in device/mountpoint."""
    result = []
    i = 0
    while i < len(s):
        if s[i] == '\\' and i + 3 < len(s) and s[i+1:i+4].isdigit():
            code = s[i+1:i+4]
            if code == '040':
                result.append(' ')
            else:
                result.append(s[i])
                result.append(s[i+1:i+4])
            i += 4
        else:
            result.append(s[i])
            i += 1
    return ''.join(result)


def transform(payloads, contract):
    """Parse Linux mount output format from case.json payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("input must be object")
    if 'mount' not in case:
        raise ValueError("missing 'mount' field")

    mount_str = case['mount']
    if not isinstance(mount_str, str):
        raise ValueError("'mount' must be string")

    # Pattern: device on mountpoint type fstype (options)
    pattern = re.compile(r'^(\S+)\s+on\s+(\S+)\s+type\s+(\S+)\s+\(([^)]+)\)$')

    records = []
    for line in mount_str.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        m = pattern.match(stripped)
        if not m:
            raise ValueError(f"invalid mount line: {stripped}")
        device_raw = m.group(1)
        mount_raw = m.group(2)
        fstype = m.group(3)
        options_raw = m.group(4).strip()

        if not options_raw:
            raise ValueError("empty options in parentheses")

        device = _decode_escapes(device_raw)
        mount_point = _decode_escapes(mount_raw)

        # Parse options: comma-split, dedup, sort
        parts = options_raw.split(',')
        seen = set()
        unique = []
        for p in parts:
            p = p.strip()
            if p not in seen:
                seen.add(p)
                unique.append(p)
        opts = sorted(unique)

        records.append({
            'device': device,
            'mount': mount_point,
            'fstype': fstype,
            'options': opts,
        })

    return {'name': contract['name'], 'result': {'records': records}}
