"""Execute all components in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts, determine dependency order
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts.append((cp, c))

    # Topological sort based on inputs/outputs dependencies
    # Build a map: output_path -> component script
    output_to_script = {}
    for cp, c in contracts:
        output_to_script[c['output']] = cp

    # Determine execution order: components whose inputs don't depend on other outputs first
    executed = set()
    ordered = []
    remaining = list(contracts)

    while remaining:
        progress = False
        next_remaining = []
        for cp, c in remaining:
            deps_met = True
            for inp in c['inputs']:
                if inp in output_to_script and inp not in executed:
                    deps_met = False
                    break
            if deps_met:
                ordered.append((cp, c))
                executed.add(c['output'])
                progress = True
            else:
                next_remaining.append((cp, c))
        if not progress:
            raise RuntimeError("circular dependency or unresolvable inputs")
        remaining = next_remaining

    # Execute each component
    for cp, c in ordered:
        render_script = cp.parent / 'render.py'
        if not render_script.exists():
            raise FileNotFoundError(f"render.py not found for {c['name']}")
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {c['name']}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.exists():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
