def transform(payloads, contract):
    """Merge mount records from fstab, aix, mount sources by priority."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    # payloads are in order: fstab, aix, mount (per contract inputs order)
    source_names = ['fstab', 'aix', 'mount']

    # Collect all records with their source
    all_records = []
    for idx, payload in enumerate(payloads):
        if not isinstance(payload, dict):
            raise ValueError(f"payload {idx} must be object")
        if 'name' not in payload or 'result' not in payload:
            raise ValueError(f"payload {idx} missing name/result")
        result = payload['result']
        if not isinstance(result, dict) or 'records' not in result:
            raise ValueError(f"payload {idx} result missing records")
        source = source_names[idx]
        for rec in result['records']:
            all_records.append({
                'device': rec['device'],
                'mount': rec['mount'],
                'fstype': rec['fstype'],
                'options': rec['options'],
                'source': source,
            })

    # Group by mount point, preserving source priority then original order
    from collections import OrderedDict
    mount_groups = OrderedDict()
    for rec in all_records:
        mp = rec['mount']
        if mp not in mount_groups:
            mount_groups[mp] = []
        mount_groups[mp].append(rec)

    # For each mount point, pick winner (first by source priority, already ordered)
    winners = {}
    conflicts = []

    for mp, recs in mount_groups.items():
        winner = recs[0]  # First record wins (source priority + line order)
        winners[mp] = winner

        # Check for conflicts: any difference in device/fstype/options among all records
        has_conflict = False
        for r in recs[1:]:
            if (r['device'] != winner['device'] or
                r['fstype'] != winner['fstype'] or
                r['options'] != winner['options']):
                has_conflict = True
                break

        if has_conflict:
            conflicts.append({
                'mount': mp,
                'evidence': list(recs),  # All records including duplicates
            })

    # Sort winners by mount point
    sorted_mounts = sorted(winners.keys())
    sorted_records = [winners[mp] for mp in sorted_mounts]

    # Sort conflicts by mount point
    conflicts.sort(key=lambda c: c['mount'])

    return {
        'name': contract['name'],
        'result': {
            'records': sorted_records,
            'conflicts': conflicts,
        }
    }
