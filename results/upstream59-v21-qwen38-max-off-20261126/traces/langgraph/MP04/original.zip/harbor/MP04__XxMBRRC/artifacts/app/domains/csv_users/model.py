import json
from pathlib import Path


def _reject_non_finite(s):
    raise ValueError(f"non-finite number in JSON: {s}")


def load_payload(path):
    """Read UTF-8 JSON file. Only object/array top-level allowed. Reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text, parse_constant=_reject_non_finite)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")
    return data
