import csv
import io
import re


def _parse_date(val):
    """Parse YYYY-MM-DD or DD/MM/YYYY to ISO date string YYYY-MM-DD."""
    if val is None:
        return None
    if not isinstance(val, str):
        raise ValueError(f"joined must be string, got {type(val).__name__}")
    s = val.strip()
    if not s:
        return None
    # Try YYYY-MM-DD
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    # Try DD/MM/YYYY
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    raise ValueError(f"invalid date format: {s}")


def _normalize_id(raw_id):
    """Normalize user ID. Must be non-empty str or int (bool illegal). Return stripped str."""
    if isinstance(raw_id, bool):
        raise ValueError("id cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        s = raw_id.strip()
        if not s:
            raise ValueError("id cannot be empty string")
        return s
    raise ValueError(f"id must be str or int, got {type(raw_id).__name__}")


def _resolve_csv_field(row, new_key, old_key):
    """Resolve field with new-key priority from CSV row. Empty cells are missing."""
    if new_key in row and row[new_key] != '':
        return row[new_key]
    if old_key in row and row[old_key] != '':
        return row[old_key]
    return None


def transform(payloads, contract):
    """Parse CSV user records from csv_text field in input payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'csv_text' not in payload:
        raise ValueError("missing csv_text field")

    csv_text = payload['csv_text']
    if not isinstance(csv_text, str):
        raise ValueError("csv_text must be string")

    # Empty text returns empty records
    if not csv_text.strip():
        return {"name": contract["name"], "result": {"records": []}}

    # Parse CSV with standard csv module (handles double-quote escaping, embedded newlines)
    reader = csv.DictReader(io.StringIO(csv_text))
    headers = reader.fieldnames
    if headers is None:
        return {"name": contract["name"], "result": {"records": []}}

    # Check for required id column
    has_id = 'id' in headers
    has_user_id = 'user_id' in headers
    if not has_id and not has_user_id:
        raise ValueError("CSV must have id or user_id column")

    # Column names must be unique
    if len(headers) != len(set(headers)):
        raise ValueError("duplicate column names")

    # Process rows
    users = {}
    for row in reader:
        # Get ID - prefer user_id over id
        raw_id = None
        if has_user_id and row.get('user_id', '') != '':
            raw_id = row['user_id']
        elif has_id and row.get('id', '') != '':
            raw_id = row['id']

        if raw_id is None:
            continue  # skip rows without ID

        uid = _normalize_id(raw_id)

        if uid not in users:
            users[uid] = {'id': uid}

        # CSV empty cells are treated as missing (don't clear old values)
        # Field priority: full_name > name, mail > email, joined_at > joined

        # Name
        name_val = _resolve_csv_field(row, 'full_name', 'name')
        if name_val is not None:
            users[uid]['name'] = name_val

        # Email
        email_val = _resolve_csv_field(row, 'mail', 'email')
        if email_val is not None:
            users[uid]['email'] = email_val

        # Joined
        joined_val = _resolve_csv_field(row, 'joined_at', 'joined')
        if joined_val is not None:
            parsed = _parse_date(joined_val)
            if parsed is not None:
                users[uid]['joined'] = parsed

    sorted_records = sorted(users.values(), key=lambda u: u['id'])
    return {"name": contract["name"], "result": {"records": sorted_records}}
