import json
import sys
from pathlib import Path

# Ensure we can import sibling modules
_dir = Path(__file__).resolve().parent
if str(_dir) not in sys.path:
    sys.path.insert(0, str(_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    return transform(payloads, contract)


def _write_output(root, contract_path):
    """Build component and write output to contract.output."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    result = build_component(root, contract_path)
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result


if __name__ == "__main__":
    # When run as script, use current working directory context
    # Determine root from contract location
    contract_file = Path(__file__).resolve().with_name('contract.json')
    # root is the workspace root (parent of domains/)
    root = contract_file.resolve().parents[2]
    _write_output(root, contract_file)
