import json
import re


def _parse_date(val):
    """Parse YYYY-MM-DD or DD/MM/YYYY to ISO date string YYYY-MM-DD."""
    if val is None:
        return None
    if not isinstance(val, str):
        raise ValueError(f"joined must be string, got {type(val).__name__}")
    s = val.strip()
    if not s:
        return None
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    raise ValueError(f"invalid date format: {s}")


def _normalize_id(raw_id):
    """Normalize user ID. Must be non-empty str or int (bool illegal). Return stripped str."""
    if isinstance(raw_id, bool):
        raise ValueError("id cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        s = raw_id.strip()
        if not s:
            raise ValueError("id cannot be empty string")
        return s
    raise ValueError(f"id must be str or int, got {type(raw_id).__name__}")


def _resolve_field(rec, new_key, old_key):
    """Resolve field with new-key priority. Returns value or None if neither present/non-null."""
    if new_key in rec and rec[new_key] is not None:
        return rec[new_key]
    if old_key in rec and rec[old_key] is not None:
        return rec[old_key]
    return None


def transform(payloads, contract):
    """Parse JSONL user records from jsonl_text field in input payload."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")
    if 'jsonl_text' not in payload:
        raise ValueError("missing jsonl_text field")

    jsonl_text = payload['jsonl_text']
    if not isinstance(jsonl_text, str):
        raise ValueError("jsonl_text must be string")

    # Parse each non-blank line as a JSON object
    records = []
    for line in jsonl_text.split('\n'):
        stripped = line.strip()
        if not stripped:
            continue  # ignore blank lines
        try:
            obj = json.loads(stripped, parse_constant=lambda s: (_ for _ in ()).throw(ValueError(f"non-finite: {s}")))
        except json.JSONDecodeError as e:
            raise ValueError(f"invalid JSONL line: {e}") from e
        if not isinstance(obj, dict):
            raise ValueError("each JSONL line must be an object")
        records.append(obj)

    # Process records same as json_users
    users = {}
    for rec in records:
        raw_id = None
        if 'user_id' in rec:
            raw_id = rec['user_id']
        elif 'id' in rec:
            raw_id = rec['id']
        else:
            raise ValueError("record missing id/user_id")

        uid = _normalize_id(raw_id)

        if uid not in users:
            users[uid] = {'id': uid}

        # Name: full_name > name
        name_val = _resolve_field(rec, 'full_name', 'name')
        if name_val is not None:
            users[uid]['name'] = name_val

        # Email: mail > email
        email_val = _resolve_field(rec, 'mail', 'email')
        if email_val is not None:
            users[uid]['email'] = email_val

        # Joined: joined_at > joined
        joined_val = _resolve_field(rec, 'joined_at', 'joined')
        if joined_val is not None:
            parsed = _parse_date(joined_val)
            if parsed is not None:
                users[uid]['joined'] = parsed

    sorted_records = sorted(users.values(), key=lambda u: u['id'])
    return {"name": contract["name"], "result": {"records": sorted_records}}
