"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.exists():
        raise FileNotFoundError("core_manifest.json not found")

    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core.get('components', {})
    component_count = len(components)

    # SHA256 of the complete core object
    # Serialize with exact spec: ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256_hex = hashlib.sha256(serialized).hexdigest()

    # Attention: components matching any condition
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ['complete', 'checkout', 'committed', 'ok']:
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ['unavailable', 'missing', 'conflicts', 'unreachable']:
            if key in result:
                val = result[key]
                if val:  # non-empty (list, dict, string, etc.)
                    attention.add(comp_name)

    attention_sorted = sorted(attention)

    report = {
        "title": "多格式用户合并与完整冲突报告",
        "component_count": component_count,
        "sha256": sha256_hex,
        "attention": attention_sorted
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
