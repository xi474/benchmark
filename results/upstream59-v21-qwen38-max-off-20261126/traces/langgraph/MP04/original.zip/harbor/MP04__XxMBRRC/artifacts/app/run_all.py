"""Orchestrate all components based on contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: some components depend on others' outputs
    # We need to run them in topological order
    # Parse contracts to determine dependencies
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_data[cp] = c

    # Determine execution order: components whose inputs are in inputs/ can run first,
    # then components whose inputs depend on other outputs
    # Simple approach: keep running until all done, respecting dependencies
    remaining = list(contracts)
    completed = set()
    max_iterations = len(remaining) + 1

    for _ in range(max_iterations):
        if not remaining:
            break
        progress = False
        next_remaining = []
        for cp in remaining:
            c = contract_data[cp]
            # Check if all inputs are available
            all_available = True
            for inp in c['inputs']:
                inp_path = ROOT / inp
                if not inp_path.exists():
                    all_available = False
                    break
            if all_available:
                # Run the component's render.py
                render_py = cp.with_name('render.py')
                if not render_py.exists():
                    print(f"Missing render.py for {cp}", file=sys.stderr)
                    sys.exit(1)
                result = subprocess.run(
                    [sys.executable, str(render_py)],
                    cwd=ROOT,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                if result.returncode != 0:
                    print(f"Component {c['name']} failed:", file=sys.stderr)
                    print(result.stderr, file=sys.stderr)
                    sys.exit(1)
                completed.add(cp)
                progress = True
            else:
                next_remaining.append(cp)
        remaining = next_remaining
        if not progress and remaining:
            print(f"Circular dependency or missing inputs for: {[str(c) for c in remaining]}", file=sys.stderr)
            sys.exit(1)

    if remaining:
        print("Could not complete all components", file=sys.stderr)
        sys.exit(1)

    # Run integrate.py to create core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
