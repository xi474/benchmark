def transform(payloads, contract):
    """Merge user records from JSON, CSV, JSONL sources with conflict detection."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    # Sources in priority order: json, csv, jsonl
    source_names = ['json', 'csv', 'jsonl']
    source_records = {}  # source_name -> {id -> record}

    for i, payload in enumerate(payloads):
        src = source_names[i]
        if not isinstance(payload, dict):
            raise ValueError(f"payload {i} must be object")
        if 'result' in payload and 'name' in payload:
            # It's an envelope from upstream component
            records = payload['result'].get('records', [])
        elif 'records' in payload:
            records = payload['records']
        else:
            raise ValueError(f"payload {i} missing records")

        if not isinstance(records, list):
            raise ValueError(f"records must be array")

        by_id = {}
        for rec in records:
            if not isinstance(rec, dict):
                raise ValueError("each record must be object")
            uid = rec.get('id')
            if uid is None:
                raise ValueError("record missing id")
            by_id[uid] = rec
        source_records[src] = by_id

    # Collect all unique IDs
    all_ids = set()
    for src_records in source_records.values():
        all_ids.update(src_records.keys())

    # Merge fields: name, email, joined
    merge_fields = ['name', 'email', 'joined']

    users = []
    conflicts = []

    for uid in sorted(all_ids):
        merged = {'id': uid}
        # Track all source values per field for conflict detection
        field_values = {f: [] for f in merge_fields}

        for src in source_names:
            rec = source_records[src].get(uid)
            if rec is None:
                continue
            for f in merge_fields:
                if f in rec:
                    val = rec[f]
                    # null already removed at parse layer
                    field_values[f].append({'source': src, 'value': val})

        # For each field, pick first existing value by source priority
        for f in merge_fields:
            vals = field_values[f]
            if vals:
                merged[f] = vals[0]['value']

        users.append(merged)

        # Detect conflicts: different sources with different values for same field
        for f in merge_fields:
            vals = field_values[f]
            if len(vals) >= 2:
                # Check if there are actually different values
                unique_values = set()
                for v in vals:
                    # Convert to comparable form
                    unique_values.add(v['value'])
                if len(unique_values) > 1:
                    conflicts.append({
                        'id': uid,
                        'field': f,
                        'values': vals
                    })

    # Sort conflicts by (id, field)
    conflicts.sort(key=lambda c: (c['id'], c['field']))

    return {
        "name": contract["name"],
        "result": {
            "users": users,
            "conflicts": conflicts
        }
    }
