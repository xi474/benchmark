import json
import sys
from pathlib import Path

# Ensure component directory is on path for imports
_component_dir = str(Path(__file__).resolve().parent)
if _component_dir not in sys.path:
    sys.path.insert(0, _component_dir)

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with required formatting."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    p.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    # CLI mode: write output to contract.output
    here = Path(__file__).resolve().parent
    contract_path = here / "contract.json"
    # root is workspace root (two levels up from component dir)
    root = here.parent.parent
    result = build_component(root, contract_path)
    contract = load_payload(contract_path)
    _write_json(root / contract["output"], result)
