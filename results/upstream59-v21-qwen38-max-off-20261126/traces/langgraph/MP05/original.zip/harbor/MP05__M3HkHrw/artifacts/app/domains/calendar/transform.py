def transform(payloads, contract):
    """
    shared_durations: For events containing self_id, compute per-contact
    cumulative minutes within the window [start, end). Clip event times to
    window. Deduplicate attendees per event. Do not merge overlapping events.
    Return {minutes: {contact_id: total_minutes}} including 0-duration contacts.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]

    # Validate required fields
    for field in ("contacts", "self_id", "window", "events"):
        if field not in data:
            raise ValueError(f"missing field: {field}")

    contacts = data["contacts"]
    self_id = data["self_id"]
    window = data["window"]
    events = data["events"]

    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")
    if not isinstance(window, list) or len(window) != 2:
        raise ValueError("window must be [start, end]")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")
    if not isinstance(events, list):
        raise ValueError("events must be list")

    w_start, w_end = window
    if not isinstance(w_start, (int, float)) or isinstance(w_start, bool):
        raise ValueError("window start must be number")
    if not isinstance(w_end, (int, float)) or isinstance(w_end, bool):
        raise ValueError("window end must be number")

    # Build contact map
    contact_map = {}
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError("age must be non-negative integer")
        contact_map[cid] = age

    # Initialize minutes for all non-self contacts
    minutes = {}
    for cid in contact_map:
        if cid != self_id:
            minutes[cid] = 0

    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be object")
        for f in ("id", "start", "end", "attendees"):
            if f not in ev:
                raise ValueError(f"event missing field: {f}")

        ev_start = ev["start"]
        ev_end = ev["end"]
        attendees = ev["attendees"]

        if not isinstance(ev_start, (int, float)) or isinstance(ev_start, bool):
            raise ValueError("event start must be number")
        if not isinstance(ev_end, (int, float)) or isinstance(ev_end, bool):
            raise ValueError("event end must be number")
        if not isinstance(attendees, list):
            raise ValueError("attendees must be list")

        # Check attendees exist
        for a in attendees:
            if a not in contact_map:
                raise ValueError(f"attendee {a} not in contacts")

        # Only process events containing self_id
        if self_id not in attendees:
            continue

        # Clip to window (half-open interval)
        clipped_start = max(ev_start, w_start)
        clipped_end = min(ev_end, w_end)
        duration = clipped_end - clipped_start
        if duration <= 0:
            continue

        # Deduplicate attendees, exclude self
        seen = set()
        for a in attendees:
            if a != self_id and a not in seen:
                seen.add(a)
                minutes[a] += duration

    return {"name": contract["name"], "result": {"minutes": minutes}}
