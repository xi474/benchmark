def transform(payloads, contract):
    """
    group_candidates: Extract group members from groups where any message
    casefold-contains the keyword. Exclude self_id, deduplicate, sort.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]

    # Validate required fields
    for field in ("contacts", "self_id", "keyword", "groups"):
        if field not in data:
            raise ValueError(f"missing field: {field}")

    contacts = data["contacts"]
    self_id = data["self_id"]
    keyword = data["keyword"]
    groups = data["groups"]

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")
    if not isinstance(groups, list):
        raise ValueError("groups must be list")

    # Build contact id set for validation
    contact_ids = set()
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError("age must be non-negative integer")
        contact_ids.add(cid)

    keyword_lower = keyword.casefold()
    result_ids = set()

    for g in groups:
        if not isinstance(g, dict):
            raise ValueError("group must be object")
        if "id" not in g or "members" not in g or "messages" not in g:
            raise ValueError("group missing required fields")
        members = g["members"]
        messages = g["messages"]
        if not isinstance(members, list):
            raise ValueError("members must be list")
        if not isinstance(messages, list):
            raise ValueError("messages must be list")

        # Check all members exist in contacts
        for m in members:
            if m not in contact_ids:
                raise ValueError(f"member {m} not in contacts")

        # Check if any message contains keyword (case-insensitive)
        matched = False
        for msg in messages:
            if not isinstance(msg, str):
                raise ValueError("message must be string")
            if keyword_lower in msg.casefold():
                matched = True
                break

        if matched:
            for m in members:
                if m != self_id:
                    result_ids.add(m)

    return {"name": contract["name"], "result": {"ids": sorted(result_ids)}}
