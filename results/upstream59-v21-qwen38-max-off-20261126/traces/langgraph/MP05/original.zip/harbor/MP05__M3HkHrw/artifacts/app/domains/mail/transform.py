def transform(payloads, contract):
    """
    mail_candidates: Extract senders of emails whose subject casefold-contains
    the keyword. Exclude self_id, deduplicate, sort. Unknown sender raises error.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]

    # Validate required fields
    for field in ("contacts", "self_id", "keyword", "emails"):
        if field not in data:
            raise ValueError(f"missing field: {field}")

    contacts = data["contacts"]
    self_id = data["self_id"]
    keyword = data["keyword"]
    emails = data["emails"]

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")
    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")
    if not isinstance(emails, list):
        raise ValueError("emails must be list")

    # Build contact id set for validation
    contact_ids = set()
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError("age must be non-negative integer")
        contact_ids.add(cid)

    keyword_lower = keyword.casefold()
    result_ids = set()

    for e in emails:
        if not isinstance(e, dict):
            raise ValueError("email must be object")
        if "id" not in e or "sender" not in e or "subject" not in e:
            raise ValueError("email missing required fields")
        sender = e["sender"]
        subject = e["subject"]
        if not isinstance(sender, str):
            raise ValueError("sender must be string")
        if not isinstance(subject, str):
            raise ValueError("subject must be string")

        # Unknown sender check
        if sender not in contact_ids:
            raise ValueError(f"unknown sender: {sender}")

        # Check if subject contains keyword (case-insensitive)
        if keyword_lower in subject.casefold():
            if sender != self_id:
                result_ids.add(sender)

    return {"name": contract["name"], "result": {"ids": sorted(result_ids)}}
