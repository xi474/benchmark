"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _is_non_empty(val):
    """Check if a value is non-empty (for attention triggering).
    
    Only containers (list, dict, str) have a meaningful 'empty' concept.
    null, false, 0, and other scalars are not considered 'non-empty'.
    """
    if isinstance(val, (list, dict, str)):
        return len(val) > 0
    return False


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    # title
    title = "跨应用候选并集与相处时长排名"

    # component_count
    component_count = len(core["components"])

    # sha256: serialize the complete core object
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: components with certain conditions
    attention = []
    for name, result in core["components"].items():
        if not isinstance(result, dict):
            continue
        triggered = False

        # result.blocked explicitly true (must be bool True, not truthy)
        if result.get("blocked") is True:
            triggered = True

        # complete/checkout/committed/ok explicitly false (must be bool False)
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True

        # unavailable/missing/conflicts/unreachable non-empty
        # Only containers (list, dict, str) can be non-empty
        # Missing fields, null, false, 0 do not trigger
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            if key in result and _is_non_empty(result[key]):
                triggered = True

        if triggered:
            attention.append(name)

    attention.sort()

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
