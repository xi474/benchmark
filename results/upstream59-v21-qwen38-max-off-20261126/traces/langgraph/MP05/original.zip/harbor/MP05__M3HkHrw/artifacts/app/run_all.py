"""Orchestrate all components based on their contracts."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_contracts():
    """Find all contract files, excluding outputs directory."""
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        raise ValueError("no contracts found")
    return contracts


def topological_sort(contracts):
    """Sort contracts by dependency order using topological sort.
    
    A component depends on another if any of its inputs references
    an output file produced by that other component.
    """
    # Map output paths to contract paths
    output_to_contract = {}
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_data[cp] = c
        output_path = c["output"]
        output_to_contract[output_path] = cp

    # Build adjacency list: edges[cp] = set of contracts that cp depends on
    edges = {cp: set() for cp in contracts}
    for cp in contracts:
        c = contract_data[cp]
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep = output_to_contract[inp]
                if dep != cp:
                    edges[cp].add(dep)

    # Kahn's algorithm for topological sort
    in_degree = {cp: 0 for cp in contracts}
    reverse_edges = {cp: set() for cp in contracts}
    for cp, deps in edges.items():
        for dep in deps:
            reverse_edges[dep].add(cp)
            in_degree[cp] += 1

    queue = sorted([cp for cp in contracts if in_degree[cp] == 0], key=str)
    result = []

    while queue:
        node = queue.pop(0)
        result.append(node)
        for dependent in sorted(reverse_edges[node], key=str):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
        queue.sort(key=str)

    if len(result) != len(contracts):
        raise ValueError("cycle detected in component dependencies")

    return result


def run_component(render_py):
    """Run a component's render.py script."""
    result = subprocess.run(
        [sys.executable, str(render_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: {render_py}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


def main():
    contracts = load_contracts()
    sorted_contracts = topological_sort(contracts)

    for cp in sorted_contracts:
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            raise FileNotFoundError(f"render.py not found for {cp}")
        run_component(render_py)

    # Run integrate.py to produce core_manifest.json
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
