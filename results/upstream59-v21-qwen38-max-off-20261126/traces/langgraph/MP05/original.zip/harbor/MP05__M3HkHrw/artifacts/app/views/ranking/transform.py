def transform(payloads, contract):
    """
    contact_rank: Union of group and mail candidates. Rank by cumulative
    minutes descending, age descending, contact_id ascending.
    Return {ranking: [{id, minutes, age}], winner: first id or null}.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    # payloads[0] = original case.json
    # payloads[1] = groups output (envelope with name/result)
    # payloads[2] = mail output (envelope with name/result)
    # payloads[3] = calendar output (envelope with name/result)

    case_data = payloads[0]
    groups_result = payloads[1]
    mail_result = payloads[2]
    calendar_result = payloads[3]

    # Extract business results from envelopes
    # When input object has keys name/result, only result is business input
    if isinstance(groups_result, dict) and set(groups_result.keys()) == {"name", "result"}:
        groups_data = groups_result["result"]
    else:
        groups_data = groups_result

    if isinstance(mail_result, dict) and set(mail_result.keys()) == {"name", "result"}:
        mail_data = mail_result["result"]
    else:
        mail_data = mail_result

    if isinstance(calendar_result, dict) and set(calendar_result.keys()) == {"name", "result"}:
        calendar_data = calendar_result["result"]
    else:
        calendar_data = calendar_result

    # Build contact map from case data
    contacts = case_data.get("contacts", [])
    contact_map = {}
    for c in contacts:
        contact_map[c["id"]] = c["age"]

    # Union of candidate ids
    group_ids = set(groups_data.get("ids", []))
    mail_ids = set(mail_data.get("ids", []))
    candidate_ids = group_ids | mail_ids

    # Get minutes from calendar
    cal_minutes = calendar_data.get("minutes", {})

    # Build ranking entries
    ranking = []
    for cid in candidate_ids:
        age = contact_map.get(cid)
        if age is None:
            raise ValueError(f"candidate {cid} not in contacts")
        mins = cal_minutes.get(cid, 0)
        ranking.append({"id": cid, "minutes": mins, "age": age})

    # Sort: minutes desc, age desc, id asc
    ranking.sort(key=lambda x: (-x["minutes"], -x["age"], x["id"]))

    winner = ranking[0]["id"] if ranking else None

    return {
        "name": contract["name"],
        "result": {
            "ranking": ranking,
            "winner": winner
        }
    }
