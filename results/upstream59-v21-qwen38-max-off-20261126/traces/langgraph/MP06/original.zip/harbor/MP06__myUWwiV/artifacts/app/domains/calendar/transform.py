def transform(payloads, contract):
    """cancel_morning: select morning social events to cancel.
    
    Input: single payload with {events, day, contacts}.
    Select events where:
      - start in [day*1440, day*1440+720)
      - social is True (bool)
      - cancelled is False (bool)
      - end > start
    Return {cancelled: sorted target ids,
            snapshots: target original records sorted by id,
            remaining: other original records sorted by id}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    # Validate required fields
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    for key in ('events', 'day', 'contacts'):
        if key not in data:
            raise ValueError(f"missing required field: {key}")
    
    events = data['events']
    day = data['day']
    
    # Validate day
    if isinstance(day, bool) or not isinstance(day, int):
        raise ValueError("day must be int")
    if day < 0:
        raise ValueError("day must be >= 0")
    
    if not isinstance(events, list):
        raise ValueError("events must be array")
    
    morning_start = day * 1440
    morning_end = morning_start + 720
    
    cancelled_ids = []
    snapshots = []
    remaining = []
    
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be object")
        for key in ('id', 'start', 'end', 'social', 'cancelled', 'attendees'):
            if key not in ev:
                raise ValueError(f"event missing field: {key}")
        
        eid = ev['id']
        start = ev['start']
        end = ev['end']
        social = ev['social']
        cancelled = ev['cancelled']
        
        # Type checks
        if not isinstance(eid, str):
            raise ValueError("event id must be string")
        if isinstance(start, bool) or not isinstance(start, int):
            raise ValueError("event start must be int")
        if isinstance(end, bool) or not isinstance(end, int):
            raise ValueError("event end must be int")
        if not isinstance(social, bool):
            raise ValueError("event social must be bool")
        if not isinstance(cancelled, bool):
            raise ValueError("event cancelled must be bool")
        if not isinstance(ev['attendees'], list):
            raise ValueError("event attendees must be array")
        
        is_target = (
            morning_start <= start < morning_end
            and social is True
            and cancelled is False
            and end > start
        )
        
        if is_target:
            cancelled_ids.append(eid)
            snapshots.append(ev)
        else:
            remaining.append(ev)
    
    cancelled_ids.sort()
    snapshots.sort(key=lambda e: e['id'])
    remaining.sort(key=lambda e: e['id'])
    
    return {
        "name": contract["name"],
        "result": {
            "cancelled": cancelled_ids,
            "snapshots": snapshots,
            "remaining": remaining
        }
    }
