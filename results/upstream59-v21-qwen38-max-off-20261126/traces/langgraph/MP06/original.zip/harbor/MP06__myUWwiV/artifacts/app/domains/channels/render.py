import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Orchestrate load -> transform and return the envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    
    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    
    return result


if __name__ == "__main__":
    script_dir = Path(__file__).resolve().parent
    contract_path = script_dir / 'contract.json'
    root = script_dir.parent.parent
    build_component(root, contract_path)
