def transform(payloads, contract):
    """channel_directory: build contact channel directory.
    
    Input: single payload with {events, day, contacts}.
    For each contact: 
      - primary: "message" if message is non-null, else "chat" if chat is non-null, else null
      - address: the value of the selected primary channel, or null
      - email: the email value (independent)
    Return {contacts: {id: {email, primary, address}}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    for key in ('events', 'day', 'contacts'):
        if key not in data:
            raise ValueError(f"missing required field: {key}")
    
    contacts = data['contacts']
    if not isinstance(contacts, list):
        raise ValueError("contacts must be array")
    
    seen_ids = set()
    result_contacts = {}
    
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError("contact must be object")
        for key in ('id', 'email', 'message', 'chat'):
            if key not in c:
                raise ValueError(f"contact missing field: {key}")
        
        cid = c['id']
        email = c['email']
        message = c['message']
        chat = c['chat']
        
        if not isinstance(cid, str):
            raise ValueError("contact id must be string")
        if cid in seen_ids:
            raise ValueError(f"duplicate contact id: {cid}")
        seen_ids.add(cid)
        
        # Validate email/message/chat: must be null or non-empty string
        for field_name, val in [('email', email), ('message', message), ('chat', chat)]:
            if val is not None:
                if not isinstance(val, str):
                    raise ValueError(f"contact {field_name} must be null or string")
                if val.strip() == '':
                    raise ValueError(f"contact {field_name} must be non-empty when not null")
        
        # Primary: prefer message, fallback to chat
        if message is not None:
            primary = "message"
            address = message
        elif chat is not None:
            primary = "chat"
            address = chat
        else:
            primary = None
            address = None
        
        result_contacts[cid] = {
            "email": email,
            "primary": primary,
            "address": address
        }
    
    return {
        "name": contract["name"],
        "result": {
            "contacts": result_contacts
        }
    }
