"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _is_non_empty(val):
    """Check if a value is non-empty (list, dict, or string with len > 0)."""
    if isinstance(val, (list, dict, str)):
        return len(val) > 0
    return False


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    # title
    title = '取消日程后多渠道通知'

    # component_count
    component_count = len(core['components'])

    # sha256: serialize the full core object with specific settings
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: components meeting any trigger condition
    attention = set()
    for comp_name, result in core['components'].items():
        if not isinstance(result, dict):
            continue

        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            if key in result and _is_non_empty(result[key]):
                attention.add(comp_name)

    attention = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
