"""Orchestrate all components based on their contracts.

Discovers all contract.json files, determines execution order from dependencies,
and runs each component's render.py via subprocess.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Clean outputs directory to ensure fresh computation
    out_dir = ROOT / 'outputs'
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Find all contracts (excluding outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: contract output -> contract path
    output_to_contract = {}
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_data[cp] = c
        output_to_contract[c['output']] = cp

    # Topological sort with cycle detection
    # States: 0=unvisited, 1=in-progress, 2=done
    state = {cp: 0 for cp in contracts}
    order = []

    def visit(cp):
        if state[cp] == 2:
            return
        if state[cp] == 1:
            print(f"Circular dependency detected involving {cp}", file=sys.stderr)
            sys.exit(1)
        state[cp] = 1
        c = contract_data[cp]
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                visit(dep_cp)
            else:
                # Input is not another component's output; it must be an existing file
                input_path = ROOT / inp
                if not input_path.exists():
                    print(f"Missing input file: {inp} for component {cp}", file=sys.stderr)
                    sys.exit(1)
        state[cp] = 2
        order.append(cp)

    for cp in contracts:
        visit(cp)

    # Execute each component in topological order
    for cp in order:
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
