def transform(payloads, contract):
    """cancel_notifications: build notification outbox from cancelled events and channels.
    
    Inputs (in order per contract):
      0: calendar result {cancelled, snapshots, remaining}
      1: channels result {contacts: {id: {email, primary, address}}}
    
    Return {outbox: [...], unreachable: [...], group: null or {...}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    cal = payloads[0]
    chan = payloads[1]
    
    # Extract business results - if wrapped in {name, result}, use result
    if isinstance(cal, dict) and set(cal.keys()) >= {'name', 'result'}:
        cal = cal['result']
    if isinstance(chan, dict) and set(chan.keys()) >= {'name', 'result'}:
        chan = chan['result']
    
    cancelled_ids = cal['cancelled']
    snapshots = cal['snapshots']
    contacts_dir = chan['contacts']
    
    # Collect all attendees from target snapshots (union, deduplicated)
    attendee_ids = set()
    for snap in snapshots:
        for aid in snap['attendees']:
            attendee_ids.add(aid)
    
    # Validate all attendee IDs exist in contacts directory
    for aid in attendee_ids:
        if aid not in contacts_dir:
            raise ValueError(f"unknown contact id: {aid}")
    
    requires = sorted(cancelled_ids)
    
    outbox = []
    unreachable = []
    group_members = []
    
    for aid in sorted(attendee_ids):
        cinfo = contacts_dir[aid]
        email = cinfo['email']
        primary = cinfo['primary']  # "message", "chat", or null
        address = cinfo['address']
        
        has_email = email is not None
        
        # Each contact with email gets an independent email entry
        if has_email:
            outbox.append({
                "channel": "email",
                "to": email,
                "recipients": [aid],
                "requires": requires
            })
        
        # Primary channel handling
        if primary == "message":
            group_members.append(aid)
        elif primary == "chat":
            outbox.append({
                "channel": "chat",
                "to": address,
                "recipients": [aid],
                "requires": requires
            })
        
        # Unreachable: no email AND no primary channel
        if not has_email and primary is None:
            unreachable.append(aid)
    
    # Build group if there are message-preferred members
    if group_members:
        group_members.sort()
        group = {
            "id": "cancelled-social",
            "members": group_members,
            "requires": requires
        }
        outbox.append({
            "channel": "message_group",
            "to": "cancelled-social",
            "recipients": group_members,
            "requires": requires
        })
    else:
        group = None
    
    # Sort outbox by (channel, to)
    outbox.sort(key=lambda x: (x['channel'], x['to']))
    unreachable.sort()
    
    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox,
            "unreachable": unreachable,
            "group": group
        }
    }
