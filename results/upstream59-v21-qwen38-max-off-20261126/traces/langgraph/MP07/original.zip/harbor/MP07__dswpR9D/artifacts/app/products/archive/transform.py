def _extract_result(payload):
    """If payload is a dict with exactly name/result keys, return result; else return payload as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    """archive_after_send: move attachments to archive if all receipts ok, apply cleanup deletes."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    receipts_data = _extract_result(payloads[1])
    cleanup_data = _extract_result(payloads[2])

    if not isinstance(case, dict):
        raise ValueError("case must be object")
    if not isinstance(receipts_data, dict):
        raise ValueError("receipts result must be object")
    if not isinstance(cleanup_data, dict):
        raise ValueError("cleanup result must be object")

    for key in ("files", "attachments", "recipients", "archive_prefix"):
        if key not in case:
            raise ValueError(f"missing field: {key}")

    files = case["files"]
    attachments = case["attachments"]
    recipients = case["recipients"]
    archive_prefix = case["archive_prefix"]

    if not isinstance(files, list):
        raise ValueError("files must be array")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be array")
    if not isinstance(recipients, list):
        raise ValueError("recipients must be array")
    if not isinstance(archive_prefix, str) or not archive_prefix.strip():
        raise ValueError("archive_prefix must be non-empty string")

    # Build file map: path -> hex
    file_map = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path or hex")
        file_map[f["path"]] = f["hex"]

    # Check receipts: all ok must be true AND at least one recipient
    receipts_list = receipts_data.get("receipts", [])
    all_ok = len(recipients) > 0 and all(r.get("ok") is True for r in receipts_list)

    # Get cleanup delete list
    delete_paths = cleanup_data.get("delete", [])
    if not isinstance(delete_paths, list):
        raise ValueError("delete must be array")

    # Determine moves
    moves = []
    blocked = False

    if all_ok:
        # Deduplicate and sort attachments (same as receipts)
        unique_attachments = sorted(set(attachments))

        # Compute target paths
        seen_targets = set()
        delete_set = set(delete_paths)

        for att_path in unique_attachments:
            # Target: archive_prefix/att_path
            target = archive_prefix + "/" + att_path

            # Check for duplicate targets
            if target in seen_targets:
                raise ValueError(f"duplicate archive target: {target}")
            seen_targets.add(target)

            # Check target already exists in current files
            if target in file_map:
                raise ValueError(f"archive target already exists: {target}")

            # Check overlap between cleanup source and move source
            if att_path in delete_set:
                raise ValueError(f"move source overlaps with cleanup: {att_path}")

            moves.append({"from": att_path, "to": target})
    else:
        blocked = True

    # Sort moves by from
    moves.sort(key=lambda m: m["from"])

    # Build final files list:
    # - Remove deleted files
    # - If not blocked, remove moved sources and add moved targets
    delete_set = set(delete_paths)
    move_from_set = set()
    move_map = {}  # from -> to
    if not blocked:
        for m in moves:
            move_from_set.add(m["from"])
            move_map[m["from"]] = m["to"]

    final_files = []
    for f in files:
        fpath = f["path"]
        if fpath in delete_set:
            continue
        if not blocked and fpath in move_from_set:
            # This file was moved; add it at new location
            new_path = move_map[fpath]
            final_files.append({"path": new_path, "hex": f["hex"]})
        else:
            final_files.append({"path": fpath, "hex": f["hex"]})

    # Sort files by path
    final_files.sort(key=lambda f: f["path"])

    # Deleted list sorted
    deleted_sorted = sorted(delete_paths)

    result = {
        "moves": moves,
        "deleted": deleted_sorted,
        "blocked": blocked,
        "files": final_files,
    }

    return {"name": contract["name"], "result": result}
