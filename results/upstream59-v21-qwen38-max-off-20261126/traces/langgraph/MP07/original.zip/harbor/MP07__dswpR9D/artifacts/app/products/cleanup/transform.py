def _is_under_prefix(file_path, prefix):
    """Check if file_path is under the given prefix directory using path segment boundaries.
    
    home/tmp/a.tmp matches prefix home/tmp
    home/tmp-old/b.tmp does NOT match prefix home/tmp
    """
    # Ensure prefix doesn't end with /
    prefix = prefix.rstrip("/")
    # file_path must start with prefix + "/"
    return file_path.startswith(prefix + "/")


def transform(payloads, contract):
    """independent_cleanup: find .tmp files under cleanup_prefix directory."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("case must be object")

    for key in ("files", "cleanup_prefix"):
        if key not in case:
            raise ValueError(f"missing field: {key}")

    files = case["files"]
    cleanup_prefix = case["cleanup_prefix"]

    if not isinstance(files, list):
        raise ValueError("files must be array")
    if not isinstance(cleanup_prefix, str) or not cleanup_prefix.strip():
        raise ValueError("cleanup_prefix must be non-empty string")

    # Find .tmp files under cleanup_prefix (path segment boundary match)
    delete_list = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f:
            raise ValueError("file entry missing path")
        fpath = f["path"]
        if _is_under_prefix(fpath, cleanup_prefix) and fpath.endswith(".tmp"):
            delete_list.append(fpath)

    delete_list.sort()

    result = {
        "delete": delete_list,
    }

    return {"name": contract["name"], "result": result}
