import hashlib


def transform(payloads, contract):
    """attachment_receipts: deduplicate/sort attachments, compute SHA256, build receipts."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("case must be object")

    # Validate required fields
    for key in ("files", "attachments", "recipients", "send_ok"):
        if key not in case:
            raise ValueError(f"missing field: {key}")

    files = case["files"]
    attachments = case["attachments"]
    recipients = case["recipients"]
    send_ok = case["send_ok"]

    if not isinstance(files, list):
        raise ValueError("files must be array")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be array")
    if not isinstance(recipients, list):
        raise ValueError("recipients must be array")
    if not isinstance(send_ok, dict):
        raise ValueError("send_ok must be object")

    # Build file lookup: path -> hex
    file_map = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path or hex")
        file_map[f["path"]] = f["hex"]

    # Deduplicate and sort attachments
    unique_attachments = sorted(set(attachments))

    # Verify each attachment exists in files
    att_results = []
    for att_path in unique_attachments:
        if att_path not in file_map:
            raise ValueError(f"attachment {att_path} not found in files")
        raw_bytes = bytes.fromhex(file_map[att_path])
        sha = hashlib.sha256(raw_bytes).hexdigest()
        att_results.append({"path": att_path, "sha256": sha})

    # Validate recipients are unique non-empty strings
    seen_recipients = set()
    for r in recipients:
        if not isinstance(r, str) or not r.strip():
            raise ValueError("recipient must be non-empty string")
        if r in seen_recipients:
            raise ValueError(f"duplicate recipient: {r}")
        seen_recipients.add(r)

    # Build receipts sorted by recipient id
    receipt_list = []
    for rid in sorted(recipients):
        if rid not in send_ok:
            raise ValueError(f"recipient {rid} not in send_ok")
        ok_val = send_ok[rid]
        if not isinstance(ok_val, bool):
            raise ValueError(f"send_ok[{rid}] must be bool")
        receipt_list.append({"recipient": rid, "ok": ok_val})

    result = {
        "attachments": att_results,
        "receipts": receipt_list,
    }

    return {"name": contract["name"], "result": result}
