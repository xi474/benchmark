"""Generate the final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # Compute sha256 of compact JSON serialization of the full core object
    compact = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    sha256_hex = hashlib.sha256(compact.encode("utf-8")).hexdigest()

    # Determine attention list
    components = core.get("components", {})
    attention_set = set()

    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # Check blocked is explicitly true
        if result.get("blocked") is True:
            attention_set.add(comp_name)

        # Check complete/checkout/committed/ok are explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention_set.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable are non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != "" and val != {}:
                # Non-empty check: lists with items, non-empty strings, non-empty dicts
                if isinstance(val, (list, str, dict)) and len(val) > 0:
                    attention_set.add(comp_name)

    attention = sorted(attention_set)

    report = {
        "title": "节日照片迁移后发送与缺失报告",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": attention,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
