import json
from pathlib import Path


def load_payload(path):
    """Load and validate a UTF-8 JSON payload from *path*.

    Rules (per README stable-interface contract):
    - File is read as UTF-8 text and parsed as JSON.
    - Top-level value must be an object (dict) or array (list).
    - Any occurrence of NaN / Infinity / -Infinity (non-standard JSON
      numeric literals) raises ValueError.
    - Invalid JSON or disallowed top-level types also raise ValueError.
    """
    p = Path(path)
    try:
        raw = p.read_text(encoding="utf-8")
    except Exception as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc

    def _reject_constant(s):
        raise ValueError(f"non-finite JSON literal not allowed: {s}")

    try:
        data = json.loads(raw, parse_constant=_reject_constant)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {path}: {exc}") from exc

    if not isinstance(data, (dict, list)):
        raise ValueError(
            f"top-level JSON value must be object or array, got {type(data).__name__}"
        )

    return data
