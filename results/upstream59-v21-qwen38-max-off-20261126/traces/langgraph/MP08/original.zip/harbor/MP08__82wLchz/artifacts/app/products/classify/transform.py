def transform(payloads, contract):
    """Photo classification: select photos by festival, report missing festivals.

    payloads[0] = case.json content (dict with files, photos, festivals, destination, recipient)
    contract = contract dict with name, operation, inputs, output

    Returns {"name": contract["name"], "result": {"selected": [...], "missing": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError(
            f"expected {len(contract['inputs'])} payloads, got {len(payloads)}"
        )

    case = payloads[0]

    # Validate required fields
    for field in ("files", "photos", "festivals", "destination", "recipient"):
        if field not in case:
            raise ValueError(f"missing required field: {field}")

    photos = case["photos"]
    festivals = case["festivals"]

    # Validate festivals is a list of unique non-empty strings
    if not isinstance(festivals, list):
        raise ValueError("festivals must be a list")
    seen_festivals = set()
    for f in festivals:
        if not isinstance(f, str) or not f.strip():
            raise ValueError("each festival must be a non-empty string")
        if f in seen_festivals:
            raise ValueError(f"duplicate festival: {f}")
        seen_festivals.add(f)

    # Validate photos
    if not isinstance(photos, list):
        raise ValueError("photos must be a list")

    # Build set of valid file paths from files list
    files = case["files"]
    if not isinstance(files, list):
        raise ValueError("files must be a list")
    file_paths = set()
    for entry in files:
        if not isinstance(entry, dict) or "path" not in entry:
            raise ValueError("each file entry must have 'path'")
        file_paths.add(entry["path"])

    # Validate each photo
    photo_paths = set()
    for p in photos:
        if not isinstance(p, dict):
            raise ValueError("each photo must be a dict")
        if "path" not in p or "festival" not in p:
            raise ValueError("each photo must have 'path' and 'festival'")
        if not isinstance(p["path"], str) or not p["path"].strip():
            raise ValueError("photo path must be a non-empty string")
        if not isinstance(p["festival"], str) or not p["festival"].strip():
            raise ValueError("photo festival must be a non-empty string")
        if p["path"] not in file_paths:
            raise ValueError(f"photo path {p['path']} not in files")
        if p["path"] in photo_paths:
            raise ValueError(f"duplicate photo path: {p['path']}")
        photo_paths.add(p["path"])

    # Select photos whose festival is in the festivals list
    selected = []
    festivals_with_photos = set()
    for p in photos:
        if p["festival"] in seen_festivals:
            selected.append({"path": p["path"], "festival": p["festival"]})
            festivals_with_photos.add(p["festival"])

    # Sort selected by (festival, path)
    selected.sort(key=lambda x: (x["festival"], x["path"]))

    # Missing: festivals that have no photos, sorted
    missing = sorted(f for f in festivals if f not in festivals_with_photos)

    return {
        "name": contract["name"],
        "result": {
            "selected": selected,
            "missing": missing,
        },
    }
