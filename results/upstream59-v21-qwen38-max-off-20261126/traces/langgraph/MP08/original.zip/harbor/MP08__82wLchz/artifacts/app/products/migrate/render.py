import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs per contract, call transform, return the envelope dict."""
    root = Path(root)
    contract_path = Path(contract_path)

    # Load contract
    contract_text = contract_path.read_text(encoding="utf-8")
    contract = json.loads(contract_text)

    # Import model and transform from the same package directory
    pkg_dir = contract_path.parent
    sys.path.insert(0, str(pkg_dir))
    try:
        from model import load_payload
        from transform import transform
    finally:
        sys.path.pop(0)

    # Load all input payloads in contract.inputs order
    payloads = [load_payload(root / p) for p in contract["inputs"]]

    # Call transform
    result = transform(payloads, contract)

    return result


if __name__ == "__main__":
    # When executed as CLI: python3 <component_dir>/render.py
    here = Path(__file__).resolve().parent
    contract_path = here / "contract.json"

    # Root is the workspace root (two levels up from products/<name>/)
    root = here.parents[1]

    result = build_component(root, contract_path)

    # Read contract to get output path
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Write with required JSON formatting
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
