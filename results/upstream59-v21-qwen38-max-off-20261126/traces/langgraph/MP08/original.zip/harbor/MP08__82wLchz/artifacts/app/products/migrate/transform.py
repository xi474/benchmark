def transform(payloads, contract):
    """Photo migration: move selected photos to destination, preserving sub-paths.

    payloads[0] = case.json content (original snapshot)
    payloads[1] = classify result (with selected and missing)
    contract = contract dict

    Returns {"name": contract["name"], "result": {"moves": [...], "files": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError(
            f"expected {len(contract['inputs'])} payloads, got {len(payloads)}"
        )

    case = payloads[0]
    classify_result = payloads[1]

    # When input object keys are exactly name/result, only result is business input
    if isinstance(classify_result, dict) and set(classify_result.keys()) == {"name", "result"}:
        classify_result = classify_result["result"]

    # Validate required fields in case
    for field in ("files", "destination"):
        if field not in case:
            raise ValueError(f"missing required field: {field}")

    destination = case["destination"]
    if not isinstance(destination, str) or not destination.strip():
        raise ValueError("destination must be a non-empty string")

    files = case["files"]
    if not isinstance(files, list):
        raise ValueError("files must be a list")

    selected = classify_result.get("selected", [])
    if not isinstance(selected, list):
        raise ValueError("selected must be a list")

    # Build hex lookup from original files
    hex_lookup = {}
    for entry in files:
        if not isinstance(entry, dict) or "path" not in entry or "hex" not in entry:
            raise ValueError("each file entry must have 'path' and 'hex'")
        hex_lookup[entry["path"]] = entry["hex"]

    # Build set of selected paths with their festivals
    selected_map = {}  # path -> festival
    for s in selected:
        if not isinstance(s, dict) or "path" not in s or "festival" not in s:
            raise ValueError("each selected entry must have 'path' and 'festival'")
        selected_map[s["path"]] = s["festival"]

    # Compute moves and new file list
    moves = []
    new_files = []
    target_paths = set()

    for entry in files:
        orig_path = entry["path"]
        hex_val = entry["hex"]

        if orig_path in selected_map:
            # This photo is selected - migrate it
            to_path = destination + "/" + orig_path
            # Check for duplicate target
            if to_path in target_paths:
                raise ValueError(f"duplicate target path: {to_path}")
            target_paths.add(to_path)

            moves.append({
                "from": orig_path,
                "to": to_path,
                "festival": selected_map[orig_path],
            })
            new_files.append({"path": to_path, "hex": hex_val})
        else:
            # Not selected - keep original path
            new_files.append({"path": orig_path, "hex": hex_val})

    # Sort moves by (from, to)
    moves.sort(key=lambda x: (x["from"], x["to"]))

    # Sort files by path
    new_files.sort(key=lambda x: x["path"])

    return {
        "name": contract["name"],
        "result": {
            "moves": moves,
            "files": new_files,
        },
    }
