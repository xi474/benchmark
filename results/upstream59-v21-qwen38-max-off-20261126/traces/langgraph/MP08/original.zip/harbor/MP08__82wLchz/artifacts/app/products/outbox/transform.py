def transform(payloads, contract):
    """Photo outbox: generate send list and missing report.

    payloads[0] = case.json content (original snapshot)
    payloads[1] = classify result
    payloads[2] = migrate result
    contract = contract dict

    Returns {"name": contract["name"], "result": {"to": ..., "attachments": [...], "missing": [...], "message": ...}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError(
            f"expected {len(contract['inputs'])} payloads, got {len(payloads)}"
        )

    case = payloads[0]
    classify_result = payloads[1]
    migrate_result = payloads[2]

    # Unwrap name/result envelopes if present
    if isinstance(classify_result, dict) and set(classify_result.keys()) == {"name", "result"}:
        classify_result = classify_result["result"]
    if isinstance(migrate_result, dict) and set(migrate_result.keys()) == {"name", "result"}:
        migrate_result = migrate_result["result"]

    # Validate required fields
    if "recipient" not in case:
        raise ValueError("missing required field: recipient")
    recipient = case["recipient"]
    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be a non-empty string")

    # Get missing from classify result
    missing = classify_result.get("missing", [])
    if not isinstance(missing, list):
        raise ValueError("missing must be a list")

    # Get attachments from migrate result - all migrated photo paths
    moves = migrate_result.get("moves", [])
    if not isinstance(moves, list):
        raise ValueError("moves must be a list")

    # Attachments are the 'to' paths from moves, sorted
    attachments = sorted(m["to"] for m in moves)

    # Build message
    if not missing:
        message = "Photos ready"
    else:
        message = "Missing: " + ", ".join(missing)

    return {
        "name": contract["name"],
        "result": {
            "to": recipient,
            "attachments": attachments,
            "missing": missing,
            "message": message,
        },
    }
