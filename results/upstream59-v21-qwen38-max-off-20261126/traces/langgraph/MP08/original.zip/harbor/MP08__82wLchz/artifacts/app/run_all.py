"""Orchestrate the full pipeline: materialize → components → integrate."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # 1. Run materialize if present
    mat = ROOT / "materialize.py"
    if mat.is_file():
        subprocess.run(
            [sys.executable, str(mat)], cwd=ROOT, check=True, timeout=30
        )

    # 2. Discover all contracts and determine execution order via topological sort
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding="utf-8"))
        contracts.append((cp, c))

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: contract output -> contract info
    output_to_contract = {}
    for cp, c in contracts:
        output_to_contract[c["output"]] = (cp, c)

    # Topological sort based on input dependencies
    visited = set()
    order = []

    def visit(output_path):
        if output_path in visited:
            return
        if output_path in output_to_contract:
            cp, c = output_to_contract[output_path]
            # Visit dependencies first
            for inp in c["inputs"]:
                visit(inp)
            visited.add(output_path)
            order.append((cp, c))

    for cp, c in contracts:
        visit(c["output"])

    # 3. Execute each component's render.py in order
    for cp, c in order:
        render_script = cp.parent / "render.py"
        if not render_script.is_file():
            print(f"Missing render.py for {c['name']}", file=sys.stderr)
            sys.exit(1)
        subprocess.run(
            [sys.executable, str(render_script)], cwd=ROOT, check=True, timeout=60
        )

    # 4. Run integrate.py to build core_manifest.json
    integrate = ROOT / "integrate.py"
    if integrate.is_file():
        subprocess.run(
            [sys.executable, str(integrate)], cwd=ROOT, check=True, timeout=30
        )

    # 5. Run final_report.py to generate final_report.json
    final_report = ROOT / "final_report.py"
    if final_report.is_file():
        subprocess.run(
            [sys.executable, str(final_report)], cwd=ROOT, check=True, timeout=30
        )


if __name__ == "__main__":
    main()
