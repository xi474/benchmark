import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check for NaN/Infinity in nested structures."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number encountered")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read UTF-8 JSON file; only object/array top-level allowed.
    
    Raises ValueError for:
    - Invalid JSON
    - Non object/array top-level type
    - Nested NaN/Infinity values
    """
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")
    
    _check_finite(data)
    return data
