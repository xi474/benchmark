def transform(payloads, contract):
    """panel_slots: select earliest 2 meeting slots from windows minus busy, after now."""
    data = payloads[0]

    now = data['now']
    windows = data['windows']
    busy = data['busy']
    duration = data['duration']
    gap = data['gap']

    # Validate types
    if not isinstance(now, int) or isinstance(now, bool):
        raise ValueError("now must be int")
    if not isinstance(duration, int) or isinstance(duration, bool) or duration < 1:
        raise ValueError("duration must be int >= 1")
    if not isinstance(gap, int) or isinstance(gap, bool) or gap < 0:
        raise ValueError("gap must be int >= 0")
    if not isinstance(windows, list):
        raise ValueError("windows must be list")
    if not isinstance(busy, list):
        raise ValueError("busy must be list")

    # Build available intervals: union of windows, clipped to [now, inf)
    raw_intervals = []
    for w in windows:
        s = w['start']
        e = w['end']
        if not isinstance(s, int) or isinstance(s, bool):
            raise ValueError("window start must be int")
        if not isinstance(e, int) or isinstance(e, bool):
            raise ValueError("window end must be int")
        if e <= s:
            raise ValueError("window end must be > start")
        cs = max(s, now)
        ce = e
        if cs < ce:
            raw_intervals.append((cs, ce))

    # Sort and merge overlapping intervals
    raw_intervals.sort()
    merged = []
    for s, e in raw_intervals:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    # Subtract busy intervals
    busy_intervals = []
    for b in busy:
        bs = b['start']
        be = b['end']
        if not isinstance(bs, int) or isinstance(bs, bool):
            raise ValueError("busy start must be int")
        if not isinstance(be, int) or isinstance(be, bool):
            raise ValueError("busy end must be int")
        if be <= bs:
            raise ValueError("busy end must be > start")
        busy_intervals.append((bs, be))

    busy_intervals.sort()

    def subtract_intervals(avail, subs):
        """Subtract sorted sub-intervals from sorted avail intervals."""
        result = []
        bi = 0
        for as_, ae in avail:
            cur_s = as_
            while bi < len(subs) and subs[bi][1] <= cur_s:
                bi += 1
            ti = bi
            while ti < len(subs) and subs[ti][0] < ae:
                ss, se = subs[ti]
                if se <= cur_s:
                    ti += 1
                    continue
                if ss >= ae:
                    break
                if ss > cur_s:
                    result.append((cur_s, min(ss, ae)))
                cur_s = max(cur_s, se)
                ti += 1
            if cur_s < ae:
                result.append((cur_s, ae))
        return result

    available = subtract_intervals(merged, busy_intervals)

    # Greedy: find earliest slot that fits duration
    # Use index-based iteration so we can re-check same interval after finding a slot
    slots = []
    search_from = None  # minimum start time for next slot
    i = 0
    while i < len(available) and len(slots) < 2:
        s, e = available[i]
        effective_start = s
        if search_from is not None:
            effective_start = max(s, search_from)
        if effective_start + duration <= e:
            slot_start = effective_start
            slot_end = slot_start + duration
            slots.append({'start': slot_start, 'end': slot_end})
            if len(slots) == 1:
                search_from = slot_end + gap
                # Don't advance i; re-check this interval for second slot
                continue
        i += 1

    complete = len(slots) == 2

    return {
        'name': contract['name'],
        'result': {
            'slots': slots,
            'complete': complete
        }
    }
