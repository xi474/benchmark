import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Load inputs per contract, run transform, return {name, result} envelope."""
    root = Path(root)
    contract_path = Path(contract_path)

    with open(contract_path, 'r', encoding='utf-8') as f:
        contract = json.load(f)

    comp_dir = contract_path.parent
    sys.path.insert(0, str(comp_dir))
    try:
        from transform import transform
    finally:
        sys.path.pop(0)

    payloads = []
    for inp in contract['inputs']:
        p = root / inp
        with open(p, 'r', encoding='utf-8') as f:
            payloads.append(json.load(f))

    result = transform(payloads, contract)
    return result


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[2]
    contract_path = Path(__file__).resolve().parent / 'contract.json'

    result = build_component(root, contract_path)

    with open(contract_path, 'r', encoding='utf-8') as f:
        contract = json.load(f)

    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
