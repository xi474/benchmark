def transform(payloads, contract):
    """panel_commit: combine slots, invitees, supplies into events and notification."""
    # payloads in order: panel_slots result, panel_invitees result, supply_selection result
    slots_data = payloads[0]
    invitees_data = payloads[1]
    supplies_data = payloads[2]

    # Extract business results - handle both raw dicts and {name, result} wrappers
    def extract_result(d):
        if isinstance(d, dict) and set(d.keys()) == {'name', 'result'}:
            return d['result']
        return d

    slots_res = extract_result(slots_data)
    invitees_res = extract_result(invitees_data)
    supplies_res = extract_result(supplies_data)

    complete = slots_res['complete']
    slots = slots_res['slots']
    members = invitees_res['members']
    group_id = invitees_res['group_id']

    if complete and len(slots) == 2:
        events = [
            {
                'id': group_id + '-1',
                'start': slots[0]['start'],
                'end': slots[0]['end'],
                'members': members
            },
            {
                'id': group_id + '-2',
                'start': slots[1]['start'],
                'end': slots[1]['end'],
                'members': members
            }
        ]
        event_ids = [events[0]['id'], events[1]['id']]
        notification = {
            'group_id': group_id,
            'members': members,
            'event_ids': event_ids
        }
    else:
        events = []
        notification = None

    return {
        'name': contract['name'],
        'result': {
            'events': events,
            'notification': notification,
            'purchase': supplies_res
        }
    }
