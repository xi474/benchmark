def transform(payloads, contract):
    """panel_invitees: merge members from specified groups, exclude listed contacts."""
    data = payloads[0]

    groups = data['groups']
    invite_groups = data['invite_groups']
    exclude = data['exclude']
    namespace = data['namespace']

    # Validate types
    if not isinstance(groups, list):
        raise ValueError("groups must be list")
    if not isinstance(invite_groups, list):
        raise ValueError("invite_groups must be list")
    if not isinstance(exclude, list):
        raise ValueError("exclude must be list")
    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be non-empty string")

    # Build group lookup
    group_map = {}
    for g in groups:
        gid = g['id']
        members = g['members']
        if not isinstance(members, list) or len(members) == 0:
            raise ValueError("group members must be non-empty list")
        group_map[gid] = members

    # Validate invite_groups exist
    for ig in invite_groups:
        if ig not in group_map:
            raise ValueError(f"unknown group: {ig}")

    # Union of members from invited groups
    member_set = set()
    for ig in invite_groups:
        for m in group_map[ig]:
            member_set.add(m)

    # Exclude
    exclude_set = set(exclude)
    member_set -= exclude_set

    # Sort by Python default string ordering
    sorted_members = sorted(member_set)

    group_id = namespace + "-panel"

    return {
        'name': contract['name'],
        'result': {
            'members': sorted_members,
            'group_id': group_id
        }
    }
