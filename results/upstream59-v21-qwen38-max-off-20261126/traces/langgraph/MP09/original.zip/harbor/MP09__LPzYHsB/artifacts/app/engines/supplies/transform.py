def transform(payloads, contract):
    """supply_selection: select best product per category by rating desc, price asc, id asc."""
    data = payloads[0]

    products = data['products']
    requirements = data['requirements']

    # Validate types
    if not isinstance(products, list):
        raise ValueError("products must be list")
    if not isinstance(requirements, list):
        raise ValueError("requirements must be list")

    # Build requirements lookup by category
    req_map = {}
    for r in requirements:
        cat = r['category']
        qty = r['quantity']
        if not isinstance(qty, int) or isinstance(qty, bool) or qty < 1:
            raise ValueError("quantity must be int >= 1")
        if cat in req_map:
            raise ValueError(f"duplicate requirement category: {cat}")
        req_map[cat] = qty

    # Group products by category
    products_by_cat = {}
    for p in products:
        pid = p['id']
        cat = p['category']
        stock = p['stock']
        price = p['price_cents']
        rating = p['rating']

        if not isinstance(stock, int) or isinstance(stock, bool) or stock < 0:
            raise ValueError("stock must be int >= 0")
        if not isinstance(price, int) or isinstance(price, bool) or price < 0:
            raise ValueError("price_cents must be int >= 0")
        if not isinstance(rating, int) or isinstance(rating, bool) or rating < 0:
            raise ValueError("rating must be int >= 0")

        if cat not in products_by_cat:
            products_by_cat[cat] = []
        products_by_cat[cat].append(p)

    items = []
    unavailable = []

    for cat in sorted(req_map.keys()):
        qty = req_map[cat]
        candidates = products_by_cat.get(cat, [])

        # Filter by sufficient stock
        eligible = [p for p in candidates if p['stock'] >= qty]

        if not eligible:
            unavailable.append(cat)
            continue

        # Sort by: rating DESC, price_cents ASC, id ASC
        eligible.sort(key=lambda p: (-p['rating'], p['price_cents'], p['id']))
        best = eligible[0]

        items.append({
            'category': cat,
            'id': best['id'],
            'quantity': qty,
            'total_cents': best['price_cents'] * qty
        })

    return {
        'name': contract['name'],
        'result': {
            'items': items,
            'unavailable': sorted(unavailable)
        }
    }
