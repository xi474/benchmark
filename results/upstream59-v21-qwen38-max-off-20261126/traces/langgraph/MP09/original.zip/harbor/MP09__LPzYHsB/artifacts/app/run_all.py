"""Orchestrate all components based on contract.json files and their dependencies."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: contract output -> contract path
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        with open(cp, 'r', encoding='utf-8') as f:
            c = json.load(f)
        output_to_contract[c['output']] = cp
        contract_info[cp] = c

    # Topological sort based on input dependencies
    # A component depends on another if any of its inputs is an output of another component
    visited = set()
    order = []

    def visit(cp):
        if cp in visited:
            return
        visited.add(cp)
        c = contract_info[cp]
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                visit(dep_cp)
        order.append(cp)

    for cp in contracts:
        visit(cp)

    # Execute each component's render.py in order
    for cp in order:
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp.parent.name} failed", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
