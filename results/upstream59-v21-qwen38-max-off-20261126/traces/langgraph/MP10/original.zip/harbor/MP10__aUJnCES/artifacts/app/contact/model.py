import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON file. Only object/array top-level allowed.
    Reject non-standard JSON (NaN/Infinity). Raise ValueError on issues."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in {path}: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError(f"Top-level must be object or array in {path}")
    return data
