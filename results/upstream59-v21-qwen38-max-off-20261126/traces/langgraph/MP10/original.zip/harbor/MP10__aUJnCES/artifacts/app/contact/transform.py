def transform(payloads, contract):
    """recent_contact operation: find most recent conversation matching topic substring."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("input must be object")

    # Validate required fields
    if 'conversations' not in inp:
        raise ValueError("missing field: conversations")
    if 'topic' not in inp:
        raise ValueError("missing field: topic")

    conversations = inp['conversations']
    topic = inp['topic']

    if not isinstance(conversations, list):
        raise ValueError("conversations must be array")
    if not isinstance(topic, str):
        raise ValueError("topic must be string")

    topic_lower = topic.casefold()

    # Filter conversations where topic.casefold() contains the search topic as substring
    matched = []
    for conv in conversations:
        if not isinstance(conv, dict):
            raise ValueError("conversation must be object")
        for field in ('id', 'contact_id', 'ts', 'topic'):
            if field not in conv:
                raise ValueError(f"missing field in conversation: {field}")

        conv_topic = conv['topic']
        if not isinstance(conv_topic, str):
            raise ValueError("conversation topic must be string")

        if topic_lower in conv_topic.casefold():
            matched.append(conv)

    if not matched:
        result = {
            "contact_id": None,
            "conversation_id": None
        }
    else:
        # Pick max ts, then min id for ties
        best = max(matched, key=lambda c: (c['ts'], _negate_id(c['id'])))
        # Actually: max ts, then min id. So sort by (ts desc, id asc)
        # Use: max by ts, then among those with same max ts, min by id
        max_ts = max(c['ts'] for c in matched)
        candidates = [c for c in matched if c['ts'] == max_ts]
        best = min(candidates, key=lambda c: c['id'])

        result = {
            "contact_id": best['contact_id'],
            "conversation_id": best['id']
        }

    return {"name": contract["name"], "result": result}


def _negate_id(id_str):
    """Helper - not used in final logic but kept for reference."""
    return id_str
