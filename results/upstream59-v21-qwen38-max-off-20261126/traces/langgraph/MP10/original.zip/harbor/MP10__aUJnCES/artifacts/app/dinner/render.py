import json
import sys
from pathlib import Path


def _get_loaders():
    """Get load_payload and transform, handling both package and script contexts."""
    try:
        from .model import load_payload
        from .transform import transform
    except ImportError:
        # Running as script - add parent to path
        here = Path(__file__).resolve().parent
        root = here.parent
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        if str(here) not in sys.path:
            sys.path.insert(0, str(here))
        from model import load_payload
        from transform import transform
    return load_payload, transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, write output, return envelope."""
    load_payload, transform = _get_loaders()
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract['inputs']]
    envelope = transform(payloads, contract)

    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return envelope


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    contract_path = here / 'contract.json'
    build_component(root, contract_path)
