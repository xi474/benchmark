from datetime import date, timedelta


def transform(payloads, contract):
    """dinner_date operation: find next date strictly after today matching weekday."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("input must be object")

    # Validate required fields
    for field in ('today', 'weekday', 'hour', 'guest_count'):
        if field not in inp:
            raise ValueError(f"missing field: {field}")

    today_str = inp['today']
    weekday = inp['weekday']
    hour = inp['hour']
    guest_count = inp['guest_count']

    # Type checks - integers exclude bool
    if not isinstance(today_str, str):
        raise ValueError("today must be string")
    if isinstance(weekday, bool) or not isinstance(weekday, int):
        raise ValueError("weekday must be int")
    if isinstance(hour, bool) or not isinstance(hour, int):
        raise ValueError("hour must be int")
    if isinstance(guest_count, bool) or not isinstance(guest_count, int):
        raise ValueError("guest_count must be int")

    # Range checks
    if not (0 <= weekday <= 6):
        raise ValueError("weekday must be 0..6")
    if not (0 <= hour <= 23):
        raise ValueError("hour must be 0..23")
    if guest_count < 1:
        raise ValueError("guest_count must be >= 1")

    # Parse today
    try:
        today = date.fromisoformat(today_str)
    except (ValueError, TypeError):
        raise ValueError("today must be valid ISO date")

    # Find next date strictly after today matching weekday
    # Python weekday: Monday=0 ... Sunday=6 (same as spec)
    days_ahead = weekday - today.weekday()
    if days_ahead <= 0:
        days_ahead += 7
    next_date = today + timedelta(days=days_ahead)

    start = f"{next_date.isoformat()}T{hour:02d}:00"

    result = {
        "start": start,
        "guest_count": guest_count
    }

    return {"name": contract["name"], "result": result}
