"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    # sha256 of the complete core object
    core_bytes = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(core_bytes).hexdigest()

    components = core.get('components', {})
    component_count = len(components)

    # attention: component names where any of these conditions hold
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue

        # result.blocked explicitly true
        if result.get('blocked') is True:
            attention.add(name)

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)

    report = {
        "title": "晚宴计划、联系人定位与餐具采购",
        "component_count": component_count,
        "sha256": sha256_hex,
        "attention": sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
