"""Orchestrate all components based on their contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency order: components whose inputs depend on other outputs
    # must run after those components. Simple topological sort.
    # Map output path -> component dir
    output_to_dir = {}
    comp_info = []
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_dir = cp.parent
        comp_info.append((cp, c, comp_dir))
        output_to_dir[c['output']] = comp_dir

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(cp, c, comp_dir):
        name = c['name']
        if name in visited:
            return
        if name in visiting:
            print(f"Circular dependency detected: {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)

        # Check dependencies
        for inp in c['inputs']:
            if inp in output_to_dir:
                dep_dir = output_to_dir[inp]
                dep_cp = dep_dir / 'contract.json'
                dep_c = json.loads(dep_cp.read_text(encoding='utf-8'))
                visit(dep_cp, dep_c, dep_dir)

        visiting.discard(name)
        visited.add(name)
        ordered.append((cp, c, comp_dir))

    for cp, c, comp_dir in comp_info:
        visit(cp, c, comp_dir)

    # Execute each component's render.py in order
    for cp, c, comp_dir in ordered:
        render_script = comp_dir / 'render.py'
        if not render_script.exists():
            print(f"Missing render.py for {c['name']}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {c['name']} failed", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.exists():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
