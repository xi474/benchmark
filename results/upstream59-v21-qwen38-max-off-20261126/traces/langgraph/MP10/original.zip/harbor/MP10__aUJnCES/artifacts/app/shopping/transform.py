def transform(payloads, contract):
    """dinner_checkout operation: match variants to wanted items, pick best per kind."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    snapshot = payloads[0]   # original case.json
    dinner_result = payloads[1]  # outputs/dinner.json (envelope with name/result)
    contact_result = payloads[2]  # outputs/contact.json (envelope with name/result)

    # Extract business data from envelopes
    # When input object keys are exactly {name, result}, only result is business input
    if isinstance(dinner_result, dict) and set(dinner_result.keys()) == {'name', 'result'}:
        dinner_data = dinner_result['result']
    else:
        dinner_data = dinner_result

    if isinstance(contact_result, dict) and set(contact_result.keys()) == {'name', 'result'}:
        contact_data = contact_result['result']
    else:
        contact_data = contact_result

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be object")

    # Validate snapshot fields
    for field in ('variants', 'wanted'):
        if field not in snapshot:
            raise ValueError(f"missing field in snapshot: {field}")

    variants = snapshot['variants']
    wanted = snapshot['wanted']

    if not isinstance(variants, list):
        raise ValueError("variants must be array")
    if not isinstance(wanted, list):
        raise ValueError("wanted must be array")

    # Get guest_count from dinner result
    if not isinstance(dinner_data, dict):
        raise ValueError("dinner result must be object")
    if 'guest_count' not in dinner_data:
        raise ValueError("missing guest_count in dinner result")
    guest_count = dinner_data['guest_count']
    if isinstance(guest_count, bool) or not isinstance(guest_count, int):
        raise ValueError("guest_count must be int")
    if guest_count < 1:
        raise ValueError("guest_count must be >= 1")

    start = dinner_data.get('start')

    # Get recipient from contact result
    if not isinstance(contact_data, dict):
        raise ValueError("contact result must be object")
    recipient = contact_data.get('contact_id')  # may be None

    # Process each wanted kind
    items = []
    unavailable = []

    for w in wanted:
        if not isinstance(w, dict):
            raise ValueError("wanted item must be object")
        if 'kind' not in w:
            raise ValueError("missing kind in wanted item")
        if 'attributes' not in w:
            raise ValueError("missing attributes in wanted item")

        kind = w['kind']
        attrs = w['attributes']

        if not isinstance(kind, str):
            raise ValueError("kind must be string")
        if not isinstance(attrs, dict):
            raise ValueError("attributes must be object")

        # Find matching variants: exact attributes match and sufficient stock
        candidates = []
        for v in variants:
            if not isinstance(v, dict):
                raise ValueError("variant must be object")
            for vf in ('id', 'kind', 'attributes', 'stock', 'price_cents'):
                if vf not in v:
                    raise ValueError(f"missing field in variant: {vf}")

            if v['kind'] != kind:
                continue
            if v['attributes'] != attrs:
                continue
            if not isinstance(v['stock'], int) or isinstance(v['stock'], bool):
                raise ValueError("stock must be int")
            if not isinstance(v['price_cents'], int) or isinstance(v['price_cents'], bool):
                raise ValueError("price_cents must be int")
            if v['stock'] >= guest_count:
                candidates.append(v)

        if not candidates:
            unavailable.append(kind)
        else:
            # Pick lowest price_cents, then lowest id
            best = min(candidates, key=lambda v: (v['price_cents'], v['id']))
            items.append({
                "id": best['id'],
                "kind": kind,
                "quantity": guest_count
            })

    # Sort items by kind (string dict order)
    items.sort(key=lambda x: x['kind'])
    # Sort unavailable by kind (string dict order)
    unavailable.sort()

    # Calculate total
    total_cents = sum(item['quantity'] * _get_price(variants, item['id']) for item in items)

    # Checkout: all kinds available AND recipient is not null
    checkout = len(unavailable) == 0 and recipient is not None

    result = {
        "items": items,
        "total_cents": total_cents,
        "checkout": checkout,
        "recipient": recipient,
        "start": start,
        "unavailable": unavailable
    }

    return {"name": contract["name"], "result": result}


def _get_price(variants, vid):
    """Get price_cents for a variant by id."""
    for v in variants:
        if v['id'] == vid:
            return v['price_cents']
    raise ValueError(f"variant {vid} not found")
