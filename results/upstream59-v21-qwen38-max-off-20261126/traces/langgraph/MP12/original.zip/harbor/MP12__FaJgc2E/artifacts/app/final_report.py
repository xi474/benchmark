"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    # title is fixed
    title = '下载目录归档、邮件清理与目标回复'

    # component_count is number of components
    component_count = len(core['components'])

    # sha256: serialize the complete core object with specific formatting
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: components meeting any of these conditions (deduplicated, sorted)
    attention = set()
    for comp_name, result in core['components'].items():
        if not isinstance(result, dict):
            continue

        # result.blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # Non-empty check: the field exists and is not empty
                # For lists: non-empty list; for strings: non-empty string; etc.
                if isinstance(val, (list, str, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, bool):
                    pass  # bool handled above
                elif val is not None:
                    # Other non-None, non-empty values
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
