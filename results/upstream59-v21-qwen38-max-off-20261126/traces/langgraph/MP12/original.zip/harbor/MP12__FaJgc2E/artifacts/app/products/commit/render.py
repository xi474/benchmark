import json
import sys
from pathlib import Path

_COMPONENT_DIR = Path(__file__).resolve().parent
if str(_COMPONENT_DIR) not in sys.path:
    sys.path.insert(0, str(_COMPONENT_DIR))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Build the component result from root and contract_path."""
    root = Path(root)
    contract_path = Path(contract_path)

    contract = load_payload(contract_path)

    payloads = []
    for inp in contract['inputs']:
        payloads.append(load_payload(root / inp))

    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with standard formatting."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == "__main__":
    contract_path = Path(__file__).resolve().with_name('contract.json')
    root = Path(__file__).resolve().parents[2]

    result = build_component(root, contract_path)

    contract = load_payload(contract_path)
    output_path = root / contract['output']
    _write_json(output_path, result)
