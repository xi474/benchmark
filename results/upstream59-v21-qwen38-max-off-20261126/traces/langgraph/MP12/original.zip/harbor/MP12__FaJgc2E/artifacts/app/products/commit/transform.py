def transform(payloads, contract):
    """Implement workspace_commit business logic.
    
    Inputs in order: original snapshot (case.json), download_archive result, 
    mail_trash result, manager_reply result.
    
    - If reply email is also in trash_ids, raise ValueError (conflict)
    - Apply file moves from download_archive
    - Set folder to TRASH for emails in trash_ids
    - Return {files: [{path, hex}] sorted by path, emails: sorted by id, reply: upstream reply}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    files_result = payloads[1]
    mail_result = payloads[2]
    reply_result = payloads[3]

    # Handle the envelope format: when input has name/result keys, use result
    if isinstance(files_result, dict) and set(files_result.keys()) == {'name', 'result'}:
        files_data = files_result['result']
    else:
        files_data = files_result

    if isinstance(mail_result, dict) and set(mail_result.keys()) == {'name', 'result'}:
        mail_data = mail_result['result']
    else:
        mail_data = mail_result

    if isinstance(reply_result, dict) and set(reply_result.keys()) == {'name', 'result'}:
        reply_data = reply_result['result']
    else:
        reply_data = reply_result

    if not isinstance(case, dict):
        raise ValueError("case must be object")

    # Extract data
    original_files = case.get('files', [])
    original_emails = case.get('emails', [])
    moves = files_data.get('moves', [])
    trash_ids = set(mail_data.get('trash_ids', []))
    reply_email_id = reply_data.get('email_id')

    # Check conflict: reply email in trash_ids
    if reply_email_id in trash_ids:
        raise ValueError("reply email is in trash_ids - commit conflict")

    # Apply file moves
    # Build a map of original files by path
    file_map = {}
    for f in original_files:
        file_map[f['path']] = f['hex']

    # Apply moves: remove source, add target with same hex
    for move in moves:
        src = move['from']
        dst = move['to']
        if src not in file_map:
            raise ValueError(f"move source not found: {src}")
        hex_val = file_map[src]
        del file_map[src]
        file_map[dst] = hex_val

    # Build output files list sorted by path
    out_files = [{"path": p, "hex": h} for p, h in file_map.items()]
    out_files.sort(key=lambda x: x['path'])

    # Apply mail trashing
    out_emails = []
    for email in original_emails:
        e = dict(email)  # shallow copy
        if e['id'] in trash_ids:
            e['folder'] = 'TRASH'
        out_emails.append(e)

    # Sort emails by id
    out_emails.sort(key=lambda x: x['id'])

    return {
        "name": contract["name"],
        "result": {
            "files": out_files,
            "emails": out_emails,
            "reply": reply_data
        }
    }
