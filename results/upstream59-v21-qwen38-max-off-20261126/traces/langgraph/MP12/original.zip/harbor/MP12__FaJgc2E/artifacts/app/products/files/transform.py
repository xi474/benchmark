import os


def _is_safe_relative(p):
    """Check path is safe relative: no absolute, no backslash, no colon, no empty segments, no . or .."""
    if not p or p.startswith('/') or p.startswith('\\'):
        return False
    if ':' in p:
        return False
    parts = p.split('/')
    for part in parts:
        if part == '' or part == '.' or part == '..':
            return False
    return True


def transform(payloads, contract):
    """download_archive: archive files from Downloads prefix matching extensions.
    
    payloads[0] = case with files, download_prefix, archive_prefix, extensions
    Returns {"name": contract["name"], "result": {"moves": [{"from", "to"}]}} sorted by from
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("payload must be an object")
    for field in ("files", "download_prefix", "archive_prefix", "extensions"):
        if field not in case:
            raise ValueError(f"missing required field: {field}")
    
    files = case["files"]
    download_prefix = case["download_prefix"]
    archive_prefix = case["archive_prefix"]
    extensions = case["extensions"]
    
    if not isinstance(files, list):
        raise ValueError("files must be a list")
    if not isinstance(download_prefix, str):
        raise ValueError("download_prefix must be a string")
    if not isinstance(archive_prefix, str):
        raise ValueError("archive_prefix must be a string")
    if not isinstance(extensions, dict):
        raise ValueError("extensions must be an object")
    
    # Build lowercase extension -> subdir mapping
    ext_map = {}
    for ext, subdir in extensions.items():
        ext_map[ext.lower()] = subdir
    
    moves = []
    seen_targets = set()
    
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("each file must be an object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file missing path or hex")
        
        fpath = f["path"]
        
        # Only process direct children of download_prefix
        # Path must start with download_prefix + "/"
        prefix_with_sep = download_prefix + "/"
        if not fpath.startswith(prefix_with_sep):
            continue
        
        remainder = fpath[len(prefix_with_sep):]
        # Must be direct child (no more slashes)
        if '/' in remainder:
            continue
        
        # Get extension (case-insensitive)
        _, ext = os.path.splitext(remainder)
        ext_lower = ext.lower()
        
        if ext_lower not in ext_map:
            continue
        
        subdir = ext_map[ext_lower]
        basename = os.path.basename(fpath)
        target = f"{archive_prefix}/{subdir}/{basename}"
        
        if not _is_safe_relative(target):
            raise ValueError(f"unsafe target path: {target}")
        
        if target in seen_targets:
            raise ValueError(f"duplicate target: {target}")
        seen_targets.add(target)
        
        moves.append({"from": fpath, "to": target})
    
    # Sort by from
    moves.sort(key=lambda m: m["from"])
    
    return {"name": contract["name"], "result": {"moves": moves}}
