def transform(payloads, contract):
    """Implement mail_trash business logic.
    
    Input payload contains: emails, month (YYYY-MM), trash_keyword
    Select emails where:
      - date belongs to month (YYYY-MM prefix match)
      - subject casefold contains trash_keyword casefold as substring
      - folder != "TRASH"
    Return {"name": contract["name"], "result": {"trash_ids": sorted list of IDs}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    if not isinstance(case, dict):
        raise ValueError("case must be object")

    for field in ('emails', 'month', 'trash_keyword'):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    emails = case['emails']
    month = case['month']
    trash_keyword = case['trash_keyword']

    if not isinstance(emails, list):
        raise ValueError("emails must be array")
    if not isinstance(month, str):
        raise ValueError("month must be string")
    if not isinstance(trash_keyword, str):
        raise ValueError("trash_keyword must be string")

    # Validate month format YYYY-MM
    if len(month) != 7 or month[4] != '-':
        raise ValueError(f"invalid month format: {month}")

    keyword_lower = trash_keyword.casefold()
    trash_ids = []

    for email in emails:
        if not isinstance(email, dict):
            raise ValueError("email entry must be object")
        for field in ('id', 'date', 'subject', 'folder', 'sender', 'thread_id'):
            if field not in email:
                raise ValueError(f"email missing field: {field}")

        eid = email['id']
        date = email['date']
        subject = email['subject']
        folder = email['folder']

        if not isinstance(eid, str):
            raise ValueError("email id must be string")
        if not isinstance(date, str):
            raise ValueError("email date must be string")
        if not isinstance(subject, str):
            raise ValueError("email subject must be string")
        if not isinstance(folder, str):
            raise ValueError("email folder must be string")

        # Validate date format YYYY-MM-DD
        if len(date) != 10 or date[4] != '-' or date[7] != '-':
            raise ValueError(f"invalid date format: {date}")

        # Check date belongs to month
        if date[:7] != month:
            continue

        # Check subject contains trash_keyword (casefold)
        if keyword_lower not in subject.casefold():
            continue

        # Check not already in TRASH
        if folder == "TRASH":
            continue

        trash_ids.append(eid)

    # Sort IDs (Python default string sort)
    trash_ids.sort()

    return {"name": contract["name"], "result": {"trash_ids": trash_ids}}
