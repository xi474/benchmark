def transform(payloads, contract):
    """Implement manager_reply business logic.
    
    Input payload contains: emails, reply_email_id, manager, reply_text
    Find email by reply_email_id where sender == manager.
    Return {"name": contract["name"], "result": {"email_id", "thread_id", "to": manager, "text": reply_text}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    if not isinstance(case, dict):
        raise ValueError("case must be object")

    for field in ('emails', 'reply_email_id', 'manager', 'reply_text'):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    emails = case['emails']
    reply_email_id = case['reply_email_id']
    manager = case['manager']
    reply_text = case['reply_text']

    if not isinstance(emails, list):
        raise ValueError("emails must be array")
    if not isinstance(reply_email_id, str):
        raise ValueError("reply_email_id must be string")
    if not isinstance(manager, str):
        raise ValueError("manager must be string")
    if not isinstance(reply_text, str):
        raise ValueError("reply_text must be string")

    # Find the target email
    target = None
    for email in emails:
        if not isinstance(email, dict):
            raise ValueError("email entry must be object")
        for field in ('id', 'date', 'subject', 'folder', 'sender', 'thread_id'):
            if field not in email:
                raise ValueError(f"email missing field: {field}")

        if email['id'] == reply_email_id:
            target = email
            break

    if target is None:
        raise ValueError(f"reply_email_id not found: {reply_email_id}")

    if target['sender'] != manager:
        raise ValueError(f"email sender does not match manager")

    return {
        "name": contract["name"],
        "result": {
            "email_id": reply_email_id,
            "thread_id": target['thread_id'],
            "to": manager,
            "text": reply_text
        }
    }
