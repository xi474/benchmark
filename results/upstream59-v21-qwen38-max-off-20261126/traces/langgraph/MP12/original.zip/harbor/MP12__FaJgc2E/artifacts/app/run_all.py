"""Run all components in dependency order, regenerating all outputs."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_component(component_dir):
    """Run a component's render.py to generate its output."""
    render_script = component_dir / 'render.py'
    if not render_script.exists():
        raise FileNotFoundError(f"render.py not found in {component_dir}")
    
    result = subprocess.run(
        [sys.executable, str(render_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: {render_script}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


def main():
    # Determine execution order based on dependencies
    # files, mail, reply have no dependencies on other outputs
    # commit depends on files, mail, reply outputs
    
    # Run independent components first
    run_component(ROOT / 'products' / 'files')
    run_component(ROOT / 'products' / 'mail')
    run_component(ROOT / 'products' / 'reply')
    
    # Run dependent component
    run_component(ROOT / 'products' / 'commit')
    
    # Run integrate to produce core_manifest.json
    integrate_script = ROOT / 'integrate.py'
    result = subprocess.run(
        [sys.executable, str(integrate_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: integrate.py", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    
    # Run final_report
    final_report_script = ROOT / 'final_report.py'
    result = subprocess.run(
        [sys.executable, str(final_report_script)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print(f"FAILED: final_report.py", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)
    
    print("ALL_COMPONENTS_OK")


if __name__ == '__main__':
    main()
