def transform(payloads, contract):
    """Compute category features: group by key, check vocabulary term presence."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    records = data['records']
    vocabulary = data['vocabulary']
    
    # Group by key
    groups = {}
    for rec in records:
        k = rec['key']
        if k not in groups:
            groups[k] = []
        groups[k].append(rec)
    
    rows = []
    for key in sorted(groups.keys()):
        recs = groups[key]
        categories = [r['category'] for r in recs if r['category'] is not None]
        
        # All-null category group: omit this key
        if len(categories) == 0:
            continue
        
        # Check each vocabulary term
        cat_set = set(categories)
        values = {}
        for term in vocabulary:
            values[term] = term in cat_set
        
        rows.append({"key": key, "values": values})
    
    return {"name": contract["name"], "result": {"rows": rows}}
