def transform(payloads, contract):
    """Compute numeric features: group by key, compute count/sum/mean of non-null values."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    records = data['records']
    
    # Validate unique IDs
    ids = [r['id'] for r in records]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate record IDs")
    
    # Group by key
    groups = {}
    for rec in records:
        k = rec['key']
        if k not in groups:
            groups[k] = []
        groups[k].append(rec)
    
    rows = []
    for key in sorted(groups.keys()):
        recs = groups[key]
        values = [r['value'] for r in recs if r['value'] is not None]
        count = len(values)
        if count == 0:
            row_values = {"count": 0, "sum": 0, "mean": None}
        else:
            s = sum(values)
            mean = s / count
            row_values = {"count": count, "sum": s, "mean": mean}
        rows.append({"key": key, "values": row_values})
    
    return {"name": contract["name"], "result": {"rows": rows}}
