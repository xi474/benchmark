def transform(payloads, contract):
    """Compute time features: group by key, compute first/last/span of non-null times."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    records = data['records']
    
    # Group by key
    groups = {}
    for rec in records:
        k = rec['key']
        if k not in groups:
            groups[k] = []
        groups[k].append(rec)
    
    rows = []
    for key in sorted(groups.keys()):
        recs = groups[key]
        times = [r['time'] for r in recs if r['time'] is not None]
        
        # All-null time group: omit this key
        if len(times) == 0:
            continue
        
        first = min(times)
        last = max(times)
        span = last - first
        values = {"first": first, "last": last, "span": span}
        rows.append({"key": key, "values": values})
    
    return {"name": contract["name"], "result": {"rows": rows}}
