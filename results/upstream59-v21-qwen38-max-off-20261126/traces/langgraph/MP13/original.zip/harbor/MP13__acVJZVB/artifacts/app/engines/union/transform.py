def transform(payloads, contract):
    """Feature union: outer join on keys from numeric, category, time outputs."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    numeric_data = payloads[0]
    category_data = payloads[1]
    time_data = payloads[2]
    
    # Extract rows from each component result
    # Each payload is the full {name, result} envelope; result has {rows: [...]}
    num_rows = {r['key']: r['values'] for r in numeric_data['result']['rows']}
    cat_rows = {r['key']: r['values'] for r in category_data['result']['rows']}
    time_rows = {r['key']: r['values'] for r in time_data['result']['rows']}
    
    # Collect all keys (outer join)
    all_keys = sorted(set(num_rows.keys()) | set(cat_rows.keys()) | set(time_rows.keys()))
    
    # Determine column names with prefixes
    num_cols = []
    cat_cols = []
    time_cols = []
    
    if num_rows:
        sample = next(iter(num_rows.values()))
        num_cols = sorted(sample.keys())
    else:
        num_cols = ["count", "mean", "sum"]  # default numeric columns
    
    if cat_rows:
        sample = next(iter(cat_rows.values()))
        cat_cols = sorted(sample.keys())
    
    if time_rows:
        sample = next(iter(time_rows.values()))
        time_cols = sorted(sample.keys())
    else:
        time_cols = ["first", "last", "span"]  # default time columns
    
    prefixed_num = [f"num.{c}" for c in num_cols]
    prefixed_cat = [f"cat.{c}" for c in cat_cols]
    prefixed_time = [f"time.{c}" for c in time_cols]
    
    all_columns = sorted(prefixed_num + prefixed_cat + prefixed_time)
    
    # Build data rows
    data = []
    for key in all_keys:
        row = []
        nv = num_rows.get(key)
        cv = cat_rows.get(key)
        tv = time_rows.get(key)
        
        for col in all_columns:
            if col.startswith("num."):
                base = col[4:]
                if nv is not None and base in nv:
                    row.append(nv[base])
                else:
                    row.append(None)
            elif col.startswith("cat."):
                base = col[4:]
                if cv is not None and base in cv:
                    row.append(cv[base])
                else:
                    row.append(None)
            elif col.startswith("time."):
                base = col[5:]
                if tv is not None and base in tv:
                    row.append(tv[base])
                else:
                    row.append(None)
            else:
                row.append(None)
        data.append(row)
    
    return {
        "name": contract["name"],
        "result": {
            "index": all_keys,
            "columns": all_columns,
            "data": data
        }
    }
