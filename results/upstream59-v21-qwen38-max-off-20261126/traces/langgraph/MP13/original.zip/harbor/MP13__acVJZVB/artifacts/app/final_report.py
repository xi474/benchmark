"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    # Compute sha256 of the complete core object
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # Determine attention list
    attention = []
    components = core.get('components', {})
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        # result.blocked explicitly true
        if result.get('blocked') is True:
            triggered = True
        # complete/checkout/committed/ok any explicitly false
        for field in ('complete', 'checkout', 'committed', 'ok'):
            if field in result and result[field] is False:
                triggered = True
        # unavailable/missing/conflicts/unreachable any non-empty
        for field in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(field)
            if val is not None and val != [] and val != {} and val != "" and val != 0:
                # Non-empty check: lists/dicts/strings that are non-empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    triggered = True
                elif isinstance(val, (int, float)) and val != 0:
                    triggered = True
        if triggered:
            attention.append(name)

    attention = sorted(set(attention))

    report = {
        "title": "聚合特征的行键保真与特征合并",
        "component_count": len(components),
        "sha256": sha256,
        "attention": attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
