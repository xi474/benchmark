"""Orchestrate all components based on contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' not in rel.parts:
            contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph: component output -> render.py path
    # We need to run components in order: numeric, category, time first, then union
    # Union depends on outputs of the other three
    
    # Collect component info
    components = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        components[c['name']] = {
            'contract': cp,
            'render': cp.with_name('render.py'),
            'inputs': c['inputs'],
            'output': c['output'],
            'deps': set()
        }

    # Determine dependencies: if a component's input is another component's output
    output_to_name = {}
    for name, info in components.items():
        output_to_name[info['output']] = name

    for name, info in components.items():
        for inp in info['inputs']:
            if inp in output_to_name:
                info['deps'].add(output_to_name[inp])

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        if name in visited:
            return
        visiting.add(name)
        for dep in sorted(components[name]['deps']):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(components.keys()):
        visit(name)

    # Execute each component in order
    for name in ordered:
        info = components[name]
        render_path = info['render']
        if not render_path.exists():
            raise ValueError(f"render.py not found for {name}")
        
        result = subprocess.run(
            [sys.executable, str(render_path)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {name}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_path = ROOT / 'integrate.py'
    if integrate_path.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_path)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_path = ROOT / 'final_report.py'
    if report_path.exists():
        result = subprocess.run(
            [sys.executable, str(report_path)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
