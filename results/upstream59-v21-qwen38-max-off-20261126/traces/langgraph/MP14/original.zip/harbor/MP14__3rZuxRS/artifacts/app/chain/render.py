"""Render layer for exception chain component.

Provides build_component(root, contract_path) which reads inputs,
calls transform, writes output, and returns the result envelope.
"""
import json
import sys
from pathlib import Path

# Support both package import and direct import
try:
    from .model import load_payload
    from .transform import transform
except ImportError:
    from model import load_payload
    from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, write output, return envelope.

    Args:
        root: workspace root Path
        contract_path: path to this component's contract.json

    Returns:
        {"name": ..., "result": ...}
    """
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    return result


if __name__ == "__main__":
    cp = Path(__file__).resolve().with_name("contract.json")
    root = cp.resolve().parents[1]
    result = build_component(root, cp)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
