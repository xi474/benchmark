"""Transform layer for exception_chain component.

Builds the exception chain from root following cause/context links,
with cycle detection and length limit of 8.
"""


def _validate_node(node):
    """Validate basic fields of a node."""
    if not isinstance(node, dict):
        raise ValueError("node must be a dict")
    for field in ("id", "type", "message", "suppress_context"):
        if field not in node:
            raise ValueError(f"missing required field: {field}")
    if not isinstance(node["id"], str):
        raise ValueError("id must be a string")
    if not isinstance(node["type"], str):
        raise ValueError("type must be a string")
    if not isinstance(node["message"], str):
        raise ValueError("message must be a string")
    if not isinstance(node["suppress_context"], bool):
        raise ValueError("suppress_context must be a bool")
    # cause and context must be present
    if "cause" not in node:
        raise ValueError("missing required field: cause")
    if "context" not in node:
        raise ValueError("missing required field: context")
    if node["cause"] is not None and not isinstance(node["cause"], str):
        raise ValueError("cause must be string or null")
    if node["context"] is not None and not isinstance(node["context"], str):
        raise ValueError("context must be string or null")
    if "frames" not in node:
        raise ValueError("missing required field: frames")
    if not isinstance(node["frames"], list):
        raise ValueError("frames must be a list")
    for f in node["frames"]:
        if not isinstance(f, dict):
            raise ValueError("frame must be a dict")
        for ff in ("file", "function"):
            if ff not in f:
                raise ValueError(f"frame missing field: {ff}")
        if "line" not in f:
            raise ValueError("frame missing field: line")
        if not isinstance(f["line"], int) or isinstance(f["line"], bool) or f["line"] < 1:
            raise ValueError("frame line must be a positive integer")
        if "locals" not in f:
            raise ValueError("frame missing field: locals")
        if not isinstance(f["locals"], dict):
            raise ValueError("frame locals must be an object")


def transform(payloads, contract):
    """Build exception chain from root following cause/context links.

    Args:
        payloads: list of loaded payloads matching contract.inputs order
        contract: the contract dict

    Returns:
        {"name": contract["name"], "result": {"chain": [...]}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be a dict")
    if "root" not in data:
        raise ValueError("missing required field: root")
    if "nodes" not in data:
        raise ValueError("missing required field: nodes")
    if not isinstance(data["nodes"], list):
        raise ValueError("nodes must be a list")

    root_id = data["root"]
    if not isinstance(root_id, str):
        raise ValueError("root must be a string")

    # Build node map
    node_map = {}
    for node in data["nodes"]:
        _validate_node(node)
        nid = node["id"]
        if nid in node_map:
            raise ValueError(f"duplicate node id: {nid}")
        node_map[nid] = node

    if root_id not in node_map:
        raise ValueError(f"root id '{root_id}' not found in nodes")

    # Walk the chain from root backwards (collecting), then reverse
    # We walk from root, following cause (priority) or context (if not suppressed)
    visited = set()
    chain_reversed = []  # will be root -> ... -> innermost

    current_id = root_id
    while current_id is not None:
        if current_id in visited:
            raise ValueError(f"cycle detected at node '{current_id}'")
        if len(chain_reversed) >= 8:
            raise ValueError("chain length exceeds maximum of 8")
        visited.add(current_id)

        if current_id not in node_map:
            raise ValueError(f"referenced node '{current_id}' not found")

        node = node_map[current_id]
        chain_reversed.append(node)

        # Determine next link
        if node["cause"] is not None:
            next_id = node["cause"]
        elif not node["suppress_context"] and node["context"] is not None:
            next_id = node["context"]
        else:
            next_id = None

        current_id = next_id

    # Reverse to get innermost -> root
    chain_nodes = list(reversed(chain_reversed))

    # Build result chain with link info
    result_chain = []
    for i, node in enumerate(chain_nodes):
        if i == 0:
            link = None
        else:
            # The link describes how this node connects to the previous one
            # Previous node in chain_nodes is the one we came FROM when walking
            # Actually: chain_nodes[i-1] is closer to innermost, chain_nodes[i] is closer to root
            # When we walked from root, chain_reversed had root first.
            # After reversing: chain_nodes[0] = innermost, chain_nodes[-1] = root
            # For chain_nodes[i], its link to chain_nodes[i-1]:
            #   chain_nodes[i] was reached from chain_nodes[i-1]? No.
            #   Actually chain_nodes[i]'s cause or context points to chain_nodes[i-1].
            prev_node = chain_nodes[i]
            target_id = chain_nodes[i - 1]["id"]
            if prev_node["cause"] == target_id:
                link = "cause"
            elif prev_node["context"] == target_id:
                link = "context"
            else:
                raise ValueError("chain link inconsistency")

        result_chain.append({
            "id": node["id"],
            "type": node["type"],
            "message": node["message"],
            "link": link,
        })

    return {"name": contract["name"], "result": {"chain": result_chain}}
