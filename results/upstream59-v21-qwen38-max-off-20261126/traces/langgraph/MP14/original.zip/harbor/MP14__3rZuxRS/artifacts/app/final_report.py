"""Generate final report from core manifest.

Reads outputs/core_manifest.json and writes outputs/final_report.json
with title, component_count, sha256, and attention fields.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core["components"]
    component_count = len(components)

    # SHA256 of the complete core object
    core_str = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    sha256 = hashlib.sha256(core_str.encode("utf-8")).hexdigest()

    # Attention: components matching any trigger condition
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != "" and val != {} and val != 0:
                # Non-empty check: list/dict/string must be non-empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, (int, float)) and not isinstance(val, bool) and val != 0:
                    attention.add(name)

    report = {
        "title": "异常链的可移植序列化与报告",
        "component_count": component_count,
        "sha256": sha256,
        "attention": sorted(attention),
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
