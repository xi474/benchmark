"""Transform layer for portable_frames component.

Processes all nodes' frames, normalizing file paths and serializing
locals values as canonical JSON strings.
"""
import json
import os


def _validate_node(node):
    """Validate basic fields of a node."""
    if not isinstance(node, dict):
        raise ValueError("node must be a dict")
    for field in ("id", "type", "message", "suppress_context"):
        if field not in node:
            raise ValueError(f"missing required field: {field}")
    if not isinstance(node["id"], str):
        raise ValueError("id must be a string")
    if not isinstance(node["type"], str):
        raise ValueError("type must be a string")
    if not isinstance(node["message"], str):
        raise ValueError("message must be a string")
    if not isinstance(node["suppress_context"], bool):
        raise ValueError("suppress_context must be a bool")
    if "cause" not in node:
        raise ValueError("missing required field: cause")
    if "context" not in node:
        raise ValueError("missing required field: context")
    if node["cause"] is not None and not isinstance(node["cause"], str):
        raise ValueError("cause must be string or null")
    if node["context"] is not None and not isinstance(node["context"], str):
        raise ValueError("context must be string or null")
    if "frames" not in node:
        raise ValueError("missing required field: frames")
    if not isinstance(node["frames"], list):
        raise ValueError("frames must be a list")
    for f in node["frames"]:
        if not isinstance(f, dict):
            raise ValueError("frame must be a dict")
        for ff in ("file", "function"):
            if ff not in f:
                raise ValueError(f"frame missing field: {ff}")
        if "line" not in f:
            raise ValueError("frame missing field: line")
        if not isinstance(f["line"], int) or isinstance(f["line"], bool) or f["line"] < 1:
            raise ValueError("frame line must be a positive integer")
        if "locals" not in f:
            raise ValueError("frame missing field: locals")
        if not isinstance(f["locals"], dict):
            raise ValueError("frame locals must be an object")


def _normalize_file(filepath):
    """Replace backslashes with / then keep only basename."""
    normalized = filepath.replace("\\", "/")
    return os.path.basename(normalized)


def _serialize_local_value(value):
    """Serialize a local variable value to canonical JSON string."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def transform(payloads, contract):
    """Process all nodes' frames into portable format.

    Args:
        payloads: list of loaded payloads matching contract.inputs order
        contract: the contract dict

    Returns:
        {"name": contract["name"], "result": {"frames": {...}}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be a dict")
    if "nodes" not in data:
        raise ValueError("missing required field: nodes")
    if not isinstance(data["nodes"], list):
        raise ValueError("nodes must be a list")

    frames_result = {}
    seen_ids = set()

    for node in data["nodes"]:
        _validate_node(node)
        nid = node["id"]
        if nid in seen_ids:
            raise ValueError(f"duplicate node id: {nid}")
        seen_ids.add(nid)

        processed_frames = []
        for f in node["frames"]:
            # Validate function non-empty
            func = f["function"]
            if not isinstance(func, str) or not func.strip():
                raise ValueError("function must be a non-empty string")

            # Normalize file path
            file_path = f["file"]
            if not isinstance(file_path, str):
                raise ValueError("file must be a string")
            norm_file = _normalize_file(file_path)

            # Serialize locals
            serialized_locals = {}
            for k, v in f["locals"].items():
                serialized_locals[k] = _serialize_local_value(v)

            processed_frames.append({
                "file": norm_file,
                "line": f["line"],
                "function": func,
                "locals": serialized_locals,
            })

        frames_result[nid] = processed_frames

    return {"name": contract["name"], "result": {"frames": frames_result}}
