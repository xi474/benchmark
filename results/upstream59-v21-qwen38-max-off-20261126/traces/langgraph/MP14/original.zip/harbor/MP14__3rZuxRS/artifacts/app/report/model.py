"""Model layer for exception report component.

Provides load_payload(path) which reads a UTF-8 JSON file and validates:
- Top-level must be object (dict) or array (list)
- No NaN or Infinity values anywhere in the structure
- Invalid JSON raises ValueError
"""
import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check that no float value is NaN or Infinity."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read UTF-8 JSON from path, validate top-level type and finiteness.
    
    Args:
        path: Path-like object pointing to a JSON file
        
    Returns:
        Parsed JSON object (dict or list)
        
    Raises:
        ValueError: If JSON is invalid, top-level is not dict/list,
                   or contains NaN/Infinity
    """
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")
    
    _check_finite(data)
    
    return data
