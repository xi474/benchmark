"""Transform layer for exception_report component.

Combines chain and frames results into a human-readable report
with proper separators and formatted output.
"""


def transform(payloads, contract):
    """Build exception report from chain and frames results.

    Args:
        payloads: list of loaded payloads matching contract.inputs order
                  [chain_result, frames_result]
        contract: the contract dict

    Returns:
        {"name": contract["name"], "result": {"nodes": [...], "text": "..."}}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    chain_data = payloads[0]
    frames_data = payloads[1]

    # Extract result objects - inputs may be wrapped in {name, result} or raw
    if isinstance(chain_data, dict) and "result" in chain_data and "name" in chain_data:
        chain_result = chain_data["result"]
    else:
        chain_result = chain_data

    if isinstance(frames_data, dict) and "result" in frames_data and "name" in frames_data:
        frames_result = frames_data["result"]
    else:
        frames_result = frames_data

    if not isinstance(chain_result, dict) or "chain" not in chain_result:
        raise ValueError("chain input must have 'chain' field")
    if not isinstance(frames_result, dict) or "frames" not in frames_result:
        raise ValueError("frames input must have 'frames' field")

    chain_list = chain_result["chain"]
    frames_map = frames_result["frames"]

    if not isinstance(chain_list, list):
        raise ValueError("chain must be a list")
    if not isinstance(frames_map, dict):
        raise ValueError("frames must be a dict")

    lines = []
    nodes = []

    for i, entry in enumerate(chain_list):
        if not isinstance(entry, dict):
            raise ValueError("chain entry must be a dict")
        for field in ("id", "type", "message", "link"):
            if field not in entry:
                raise ValueError(f"chain entry missing field: {field}")

        nid = entry["id"]
        ntype = entry["type"]
        nmessage = entry["message"]
        link = entry["link"]

        # Add separator for non-first items
        if i > 0:
            if link == "cause":
                lines.append("--- direct cause ---")
            elif link == "context":
                lines.append("--- during handling ---")
            else:
                raise ValueError(f"unexpected link value: {link}")

        # Get frames for this node
        node_frames = frames_map.get(nid, [])

        # Add frame lines
        for f in node_frames:
            if not isinstance(f, dict):
                raise ValueError("frame must be a dict")
            for ff in ("file", "line", "function"):
                if ff not in f:
                    raise ValueError(f"frame missing field: {ff}")
            lines.append(f"  {f['file']}:{f['line']} in {f['function']}")

        # Add type: message line
        lines.append(f"{ntype}: {nmessage}")

        # Build node with frames (including locals preserved)
        nodes.append({
            "id": nid,
            "type": ntype,
            "message": nmessage,
            "link": link,
            "frames": node_frames,
        })

    # Build text: join lines with newline, add trailing newline if non-empty
    if lines:
        text = "\n".join(lines) + "\n"
    else:
        text = ""

    return {"name": contract["name"], "result": {"nodes": nodes, "text": text}}
