"""Orchestrate all components based on their contract.json files.

Runs each component's render.build_component in dependency order,
ensuring outputs are freshly computed.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: report depends on chain and frames outputs
    # Simple approach: sort by dependency - components whose inputs are
    # only from inputs/ come first, then those depending on outputs/
    
    def get_deps(cp):
        """Get set of output files this contract depends on."""
        c = json.loads(cp.read_text(encoding="utf-8"))
        deps = set()
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                deps.add(inp)
        return deps

    # Topological sort
    remaining = list(contracts)
    ordered = []
    produced = set()  # outputs that have been produced
    
    # Add input files as already available
    for f in ROOT.glob("inputs/*"):
        produced.add(f"inputs/{f.name}")

    max_iterations = len(remaining) + 1
    for _ in range(max_iterations):
        if not remaining:
            break
        progress = False
        next_remaining = []
        for cp in remaining:
            deps = get_deps(cp)
            if deps <= produced:
                ordered.append(cp)
                c = json.loads(cp.read_text(encoding="utf-8"))
                produced.add(c["output"])
                progress = True
            else:
                next_remaining.append(cp)
        remaining = next_remaining
        if not progress and remaining:
            print(f"Unresolvable dependencies: {[str(c) for c in remaining]}", file=sys.stderr)
            sys.exit(1)

    # Execute each component
    for cp in ordered:
        c = json.loads(cp.read_text(encoding="utf-8"))
        comp_dir = cp.parent
        comp_name = comp_dir.name
        
        # Import the component's render module
        sys.path.insert(0, str(ROOT))
        try:
            mod = __import__(f"{comp_name}.render", fromlist=["build_component"])
            result = mod.build_component(ROOT, cp)
        except Exception as e:
            print(f"Component {comp_name} failed: {e}", file=sys.stderr)
            sys.exit(1)
        finally:
            if str(ROOT) in sys.path:
                sys.path.remove(str(ROOT))

    # Run integrate.py
    import subprocess
    result = subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"integrate.py failed: {result.stderr}", file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    result = subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"final_report.py failed: {result.stderr}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
