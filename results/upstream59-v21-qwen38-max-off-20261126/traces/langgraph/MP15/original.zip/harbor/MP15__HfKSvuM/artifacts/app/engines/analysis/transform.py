import ast


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    source_payload = payloads[0]
    ordinary_result = payloads[1]
    annotation_result = payloads[2]
    comment_result = payloads[3]

    if not isinstance(source_payload, dict) or 'source' not in source_payload:
        raise ValueError("missing 'source' field")

    source = source_payload['source']
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    # Extract uses from each component result
    ordinary_uses = ordinary_result.get('result', ordinary_result).get('uses', [])
    annotation_uses = annotation_result.get('result', annotation_result).get('uses', [])
    comment_uses = comment_result.get('result', comment_result).get('uses', [])

    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    # Check for global/nonlocal
    for node in ast.walk(tree):
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            raise ValueError("global/nonlocal not supported")

    # Parse imports at module level and function level
    module_imports = {}  # bound_name -> {name, module, line}
    function_imports = {}  # func_name -> {bound_name -> {name, module, line}}

    _parse_imports(tree, module_imports, function_imports)

    # Collect all scopes and their local names (parameters, assignments)
    # For shadowing analysis
    func_local_names = {}  # func_name -> set of locally defined names
    _collect_local_names(tree, func_local_names)

    # Build imports list and track usage
    imports_list = []
    usage_map = {}  # (scope, bound_name) -> set of use types

    # Process module-level imports
    for bound_name, info in module_imports.items():
        key = ("module", bound_name)
        entry = {
            "scope": "module",
            "name": bound_name,
            "module": info["module"],
            "line": info["line"],
            "used_by": []
        }
        imports_list.append(entry)
        usage_map[key] = set()

    # Process function-level imports
    for func_name, fimports in function_imports.items():
        for bound_name, info in fimports.items():
            key = (func_name, bound_name)
            entry = {
                "scope": func_name,
                "name": bound_name,
                "module": info["module"],
                "line": info["line"],
                "used_by": []
            }
            imports_list.append(entry)
            usage_map[key] = set()

    # Now match uses to imports
    all_uses = [
        (u, "ordinary") for u in ordinary_uses
    ] + [
        (u, "annotation") for u in annotation_uses
    ] + [
        (u, "comment") for u in comment_uses
    ]

    for use, use_type in all_uses:
        scope = use["scope"]
        name = use["name"]

        # Try to resolve which import this use refers to
        resolved_key = _resolve_use(scope, name, module_imports, function_imports, func_local_names)
        if resolved_key and resolved_key in usage_map:
            usage_map[resolved_key].add(use_type)

    # Build used_by lists in order: ordinary, annotation, comment
    for entry in imports_list:
        key = (entry["scope"], entry["name"])
        used = usage_map.get(key, set())
        used_by = []
        if "ordinary" in used:
            used_by.append("ordinary")
        if "annotation" in used:
            used_by.append("annotation")
        if "comment" in used:
            used_by.append("comment")
        entry["used_by"] = used_by

    # Sort imports by (scope, line, name)
    imports_list.sort(key=lambda x: (x["scope"], x["line"], x["name"]))

    # Compute unused: scope:name where used_by is empty
    unused = []
    for entry in imports_list:
        if not entry["used_by"]:
            unused.append(f"{entry['scope']}:{entry['name']}")
    unused.sort()

    return {"name": contract["name"], "result": {"imports": imports_list, "unused": unused}}


def _parse_imports(tree, module_imports, function_imports):
    """Parse import statements and populate import maps."""
    for stmt in tree.body:
        if isinstance(stmt, ast.Import):
            for alias in stmt.names:
                if alias.name == '*':
                    raise ValueError("wildcard import not supported")
                bound_name = alias.asname if alias.asname else alias.name.split('.')[0]
                if bound_name in module_imports:
                    raise ValueError(f"duplicate import binding: {bound_name}")
                module_imports[bound_name] = {
                    "name": bound_name,
                    "module": alias.name,
                    "line": stmt.lineno
                }
        elif isinstance(stmt, ast.ImportFrom):
            if stmt.level and stmt.level > 0:
                raise ValueError("relative import not supported")
            for alias in stmt.names:
                if alias.name == '*':
                    raise ValueError("wildcard import not supported")
                bound_name = alias.asname if alias.asname else alias.name
                if bound_name in module_imports:
                    raise ValueError(f"duplicate import binding: {bound_name}")
                module_imports[bound_name] = {
                    "name": bound_name,
                    "module": stmt.module,
                    "line": stmt.lineno
                }
        elif isinstance(stmt, ast.FunctionDef):
            func_imports = {}
            for child_stmt in stmt.body:
                if isinstance(child_stmt, ast.Import):
                    for alias in child_stmt.names:
                        if alias.name == '*':
                            raise ValueError("wildcard import not supported")
                        bound_name = alias.asname if alias.asname else alias.name.split('.')[0]
                        if bound_name in func_imports:
                            raise ValueError(f"duplicate import binding in {stmt.name}: {bound_name}")
                        func_imports[bound_name] = {
                            "name": bound_name,
                            "module": alias.name,
                            "line": child_stmt.lineno
                        }
                elif isinstance(child_stmt, ast.ImportFrom):
                    if child_stmt.level and child_stmt.level > 0:
                        raise ValueError("relative import not supported")
                    for alias in child_stmt.names:
                        if alias.name == '*':
                            raise ValueError("wildcard import not supported")
                        bound_name = alias.asname if alias.asname else alias.name
                        if bound_name in func_imports:
                            raise ValueError(f"duplicate import binding in {stmt.name}: {bound_name}")
                        func_imports[bound_name] = {
                            "name": bound_name,
                            "module": child_stmt.module,
                            "line": child_stmt.lineno
                        }
            if func_imports:
                function_imports[stmt.name] = func_imports


def _collect_local_names(tree, func_local_names):
    """Collect locally defined names (parameters, assignment targets) per function."""
    for stmt in tree.body:
        if isinstance(stmt, ast.FunctionDef):
            local_names = set()
            # Parameters
            args = stmt.args
            for a in args.posonlyargs + args.args + args.kwonlyargs:
                local_names.add(a.arg)
            if args.vararg:
                local_names.add(args.vararg.arg)
            if args.kwarg:
                local_names.add(args.kwarg.arg)

            # Assignment targets in function body
            for child in ast.walk(stmt):
                if child is stmt:
                    continue
                if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                    local_names.add(child.id)

            func_local_names[stmt.name] = local_names


def _resolve_use(scope, name, module_imports, function_imports, func_local_names):
    """Resolve a use to an import key (scope, bound_name)."""
    if scope == "module":
        # Module-level use: only matches module imports
        if name in module_imports:
            return ("module", name)
        return None
    else:
        # Function-level use
        # 1. Check function-local imports first
        if scope in function_imports and name in function_imports[scope]:
            return (scope, name)

        # 2. Check if name is shadowed by local definition (param/assignment)
        if scope in func_local_names and name in func_local_names[scope]:
            # Shadowed - doesn't refer to any import
            return None

        # 3. Fall back to module import
        if name in module_imports:
            return ("module", name)

        return None
