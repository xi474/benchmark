import ast


def _collect_loads_from_annotation(node, scope_name):
    """Collect Load names from an annotation node."""
    uses = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            uses.append({"scope": scope_name, "name": child.id, "line": child.lineno})
    return uses


def _parse_string_annotation(node, source_lines):
    """If annotation is a string constant (forward reference), parse it as expression.
    Returns the parsed AST node or the original node if not a string."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        try:
            parsed = ast.parse(node.value, mode='eval')
            # The parsed expression inherits the line number from the original node
            _fix_line_numbers(parsed.body, node.lineno)
            return parsed.body
        except SyntaxError as e:
            raise ValueError(f"bad forward reference expression: {e}") from e
    return node


def _fix_line_numbers(node, lineno):
    """Set line numbers on all nodes in the tree."""
    for child in ast.walk(node):
        if hasattr(child, 'lineno'):
            child.lineno = lineno
        if hasattr(child, 'col_offset'):
            pass  # keep as-is


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict) or 'source' not in payload:
        raise ValueError("missing 'source' field")

    source = payload['source']
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    source_lines = source.splitlines(True)
    uses = []

    for stmt in tree.body:
        if isinstance(stmt, ast.AnnAssign):
            # Module-level annotated assignment
            if stmt.annotation is not None:
                ann = _parse_string_annotation(stmt.annotation, source_lines)
                uses.extend(_collect_loads_from_annotation(ann, "module"))
        elif isinstance(stmt, ast.FunctionDef):
            # Validate no nested functions etc.
            _validate_function(stmt)
            # Function signature annotations belong to module scope
            args = stmt.args
            for a in args.posonlyargs + args.args + args.kwonlyargs:
                if a.annotation is not None:
                    ann = _parse_string_annotation(a.annotation, source_lines)
                    uses.extend(_collect_loads_from_annotation(ann, "module"))
            if args.vararg and args.vararg.annotation is not None:
                ann = _parse_string_annotation(args.vararg.annotation, source_lines)
                uses.extend(_collect_loads_from_annotation(ann, "module"))
            if args.kwarg and args.kwarg.annotation is not None:
                ann = _parse_string_annotation(args.kwarg.annotation, source_lines)
                uses.extend(_collect_loads_from_annotation(ann, "module"))
            if stmt.returns is not None:
                ann = _parse_string_annotation(stmt.returns, source_lines)
                uses.extend(_collect_loads_from_annotation(ann, "module"))

            # Function body AnnAssign annotations belong to function scope
            for child_stmt in ast.walk(stmt):
                if child_stmt is stmt:
                    continue
                if isinstance(child_stmt, ast.AnnAssign) and child_stmt.annotation is not None:
                    ann = _parse_string_annotation(child_stmt.annotation, source_lines)
                    uses.extend(_collect_loads_from_annotation(ann, stmt.name))
        elif isinstance(stmt, ast.AsyncFunctionDef):
            raise ValueError("async functions not supported")
        elif isinstance(stmt, ast.ClassDef):
            raise ValueError("classes not supported")

    # Deduplicate by (scope, line, name)
    seen = set()
    deduped = []
    for u in uses:
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            deduped.append(u)

    # Sort by (scope, line, name)
    deduped.sort(key=lambda x: (x["scope"], x["line"], x["name"]))

    return {"name": contract["name"], "result": {"uses": deduped}}


def _validate_function(func_node):
    """Validate function: no nested functions, no async, no class defs."""
    for child in ast.walk(func_node):
        if child is func_node:
            continue
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError("nested functions not supported")
        if isinstance(child, ast.ClassDef):
            raise ValueError("class definitions inside functions not supported")
        if isinstance(child, ast.Lambda):
            raise ValueError("lambda not supported")
