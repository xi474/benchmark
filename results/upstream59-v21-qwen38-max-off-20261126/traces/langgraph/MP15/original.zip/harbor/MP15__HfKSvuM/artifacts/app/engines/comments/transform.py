import ast


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict) or 'source' not in payload:
        raise ValueError("missing 'source' field")

    source = payload['source']
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []

    # Check for unsupported type comments on function signatures and for/with
    _check_unsupported_type_comments(tree, source)

    # Walk all Assign nodes and check for type_comment
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and hasattr(node, 'type_comment') and node.type_comment:
            tc = node.type_comment.strip()
            # # type: ignore should not produce references
            if tc == 'ignore':
                continue
            # Parse the type comment as an expression
            try:
                parsed = ast.parse(tc, mode='eval')
            except SyntaxError as e:
                raise ValueError(f"bad type comment expression: {e}") from e

            # Determine scope
            scope = _determine_scope(tree, node)

            # Extract Load names
            for child in ast.walk(parsed):
                if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
                    uses.append({
                        "scope": scope,
                        "name": child.id,
                        "line": node.lineno
                    })

    # Deduplicate by (scope, line, name)
    seen = set()
    deduped = []
    for u in uses:
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            deduped.append(u)

    # Sort by (scope, line, name)
    deduped.sort(key=lambda x: (x["scope"], x["line"], x["name"]))

    return {"name": contract["name"], "result": {"uses": deduped}}


def _determine_scope(tree, target_node):
    """Determine if a node is at module level or inside a function."""
    # Build parent map
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            child._parent = node

    current = target_node
    while hasattr(current, '_parent'):
        parent = current._parent
        if isinstance(parent, ast.FunctionDef):
            return parent.name
        current = parent
    return "module"


def _check_unsupported_type_comments(tree, source):
    """Check for type comments on function signatures, for, with - these are errors."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if hasattr(node, 'type_comment') and node.type_comment:
                raise ValueError("function signature type_comment not supported")
        if isinstance(node, ast.For):
            if hasattr(node, 'type_comment') and node.type_comment:
                raise ValueError("for type_comment not supported")
        if isinstance(node, ast.With):
            if hasattr(node, 'type_comment') and node.type_comment:
                raise ValueError("with type_comment not supported")
