import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs per contract, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)

    # Load contract
    from model import load_payload
    from transform import transform

    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result


if __name__ == "__main__":
    # When run as script, use the component's own directory
    here = Path(__file__).resolve().parent
    root = here.parents[1]  # workspace root
    contract_path = here / 'contract.json'

    # Add component dir to path so model/transform imports work
    sys.path.insert(0, str(here))

    result = build_component(root, contract_path)
