import ast


def _collect_loads(node):
    """Collect all Name nodes with Load context from an AST node, excluding annotations and type comments."""
    loads = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            loads.append((child.id, child.lineno))
    return loads


def _get_annotation_nodes(node):
    """Get all AST nodes that are part of annotations (should be excluded from ordinary uses)."""
    ann_nodes = set()
    for child in ast.walk(node):
        # AnnAssign.annotation
        if isinstance(child, ast.AnnAssign) and child.annotation is not None:
            for sub in ast.walk(child.annotation):
                ann_nodes.add(id(sub))
        # Function argument annotations
        if isinstance(child, (ast.FunctionDef,)):
            args = child.args
            for a in args.args + args.posonlyargs + args.kwonlyargs:
                if a.annotation is not None:
                    for sub in ast.walk(a.annotation):
                        ann_nodes.add(id(sub))
            if args.vararg and args.vararg.annotation is not None:
                for sub in ast.walk(args.vararg.annotation):
                    ann_nodes.add(id(sub))
            if args.kwarg and args.kwarg.annotation is not None:
                for sub in ast.walk(args.kwarg.annotation):
                    ann_nodes.add(id(sub))
            if child.returns is not None:
                for sub in ast.walk(child.returns):
                    ann_nodes.add(id(sub))
    return ann_nodes


def _extract_ordinary_from_node(node, scope_name, source_lines):
    """Extract ordinary Load names from a node, excluding annotation subtrees."""
    # First collect all annotation node ids to exclude
    ann_ids = _get_annotation_nodes(node)

    uses = []
    # We need to walk but skip annotation subtrees
    # Use a custom walk that skips annotation children
    _walk_excluding_annotations(node, ann_ids, uses, scope_name, source_lines)
    return uses


def _walk_excluding_annotations(node, ann_ids, uses, scope_name, source_lines):
    """Walk AST collecting Load names, skipping nodes that are part of annotations."""
    if id(node) in ann_ids:
        return

    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
        uses.append({"scope": scope_name, "name": node.id, "line": node.lineno})
        return

    # For type_comment on Assign - we should NOT extract from type comments in ordinary
    # But ast.parse with type_comments=True puts them in node.type_comment as string
    # We just ignore type_comment attribute entirely for ordinary

    for child in ast.iter_child_nodes(node):
        if id(child) not in ann_ids:
            _walk_excluding_annotations(child, ann_ids, uses, scope_name, source_lines)


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict) or 'source' not in payload:
        raise ValueError("missing 'source' field")

    source = payload['source']
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    source_lines = source.splitlines(True)
    uses = []

    for stmt in tree.body:
        if isinstance(stmt, (ast.Import, ast.ImportFrom)):
            # Import statements themselves don't produce Load references
            continue
        elif isinstance(stmt, ast.FunctionDef):
            # Validate: no nested functions, no async, no class
            _validate_function(stmt)
            # Decorators and defaults are in module scope
            for deco in stmt.decorator_list:
                _walk_excluding_annotations(deco, set(), uses, "module", source_lines)
            # Default values for arguments are in module scope
            _extract_defaults_module_scope(stmt, uses, source_lines)
            # Function body is in function scope
            func_ann_ids = _get_annotation_nodes(stmt)
            for child_stmt in stmt.body:
                _walk_body_for_ordinary(child_stmt, func_ann_ids, uses, stmt.name, source_lines)
        elif isinstance(stmt, ast.AsyncFunctionDef):
            raise ValueError("async functions not supported")
        elif isinstance(stmt, ast.ClassDef):
            raise ValueError("classes not supported")
        else:
            # Module-level statement
            _walk_excluding_annotations(stmt, _get_annotation_nodes(tree), uses, "module", source_lines)

    # Deduplicate by (scope, line, name)
    seen = set()
    deduped = []
    for u in uses:
        key = (u["scope"], u["line"], u["name"])
        if key not in seen:
            seen.add(key)
            deduped.append(u)

    # Sort by (scope, line, name)
    deduped.sort(key=lambda x: (x["scope"], x["line"], x["name"]))

    return {"name": contract["name"], "result": {"uses": deduped}}


def _validate_function(func_node):
    """Validate function: no nested functions, no async, no class defs."""
    for child in ast.walk(func_node):
        if child is func_node:
            continue
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError("nested functions not supported")
        if isinstance(child, ast.ClassDef):
            raise ValueError("class definitions inside functions not supported")
        if isinstance(child, ast.Lambda):
            raise ValueError("lambda not supported")


def _extract_defaults_module_scope(func_node, uses, source_lines):
    """Extract Load names from default argument values (module scope)."""
    args = func_node.args
    # defaults apply to last N positional args
    for default in args.defaults:
        _walk_excluding_annotations(default, set(), uses, "module", source_lines)
    for default in args.kw_defaults:
        if default is not None:
            _walk_excluding_annotations(default, set(), uses, "module", source_lines)


def _walk_body_for_ordinary(stmt, ann_ids, uses, scope_name, source_lines):
    """Walk function body statements for ordinary uses, excluding annotations."""
    if id(stmt) in ann_ids:
        return
    if isinstance(stmt, ast.Name) and isinstance(stmt.ctx, ast.Load):
        uses.append({"scope": scope_name, "name": stmt.id, "line": stmt.lineno})
        return
    for child in ast.iter_child_nodes(stmt):
        if id(child) not in ann_ids:
            _walk_body_for_ordinary(child, ann_ids, uses, scope_name, source_lines)
