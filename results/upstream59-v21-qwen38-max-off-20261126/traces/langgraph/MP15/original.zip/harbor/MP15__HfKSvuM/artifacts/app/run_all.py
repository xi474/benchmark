"""Orchestrate all components based on file contracts."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph: component -> set of input paths that are outputs of other components
    comp_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_info[c['name']] = {
            'contract_path': cp,
            'component_dir': cp.parent,
            'inputs': c['inputs'],
            'output': c['output'],
        }

    # Topological sort based on dependencies
    # A component depends on another if any of its inputs is another component's output
    output_to_comp = {}
    for name, info in comp_info.items():
        output_to_comp[info['output']] = name

    deps = {}
    for name, info in comp_info.items():
        deps[name] = set()
        for inp in info['inputs']:
            if inp in output_to_comp:
                deps[name].add(output_to_comp[inp])

    # Topological sort
    order = []
    visited = set()
    temp = set()

    def visit(name):
        if name in temp:
            raise ValueError(f"circular dependency involving {name}")
        if name in visited:
            return
        temp.add(name)
        for dep in deps[name]:
            visit(dep)
        temp.remove(name)
        visited.add(name)
        order.append(name)

    for name in comp_info:
        visit(name)

    # Execute components in order
    for name in order:
        info = comp_info[name]
        render_py = info['component_dir'] / 'render.py'
        if not render_py.exists():
            raise ValueError(f"render.py not found for {name}")

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
