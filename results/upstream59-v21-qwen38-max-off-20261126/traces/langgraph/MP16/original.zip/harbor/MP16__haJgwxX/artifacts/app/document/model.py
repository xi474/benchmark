"""Model layer for document component: unified API document data structures."""

import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check that no float NaN or Infinity exists in the structure."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number encountered")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read a UTF-8 JSON file. Only object/array top-level allowed.
    
    Raises ValueError for invalid JSON, non-object/array top-level,
    or nested NaN/Infinity.
    """
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"invalid JSON: {e}") from e
    
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    
    _check_finite(data)
    return data
