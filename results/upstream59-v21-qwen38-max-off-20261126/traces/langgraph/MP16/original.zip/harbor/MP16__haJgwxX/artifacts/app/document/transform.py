"""Transform layer for document component: aggregate API documentation."""

import re


def _replace_aliases_in_type(type_str, aliases):
    """Replace standalone identifiers in a type string with alias qualified names.
    
    Only replace identifiers that are NOT immediately preceded or followed by a dot.
    This means we don't replace parts of already-qualified names like 'base.Item'.
    """
    if type_str is None:
        return None
    
    # We need to find standalone identifiers (not adjacent to dots)
    # Strategy: tokenize and replace
    result = []
    i = 0
    n = len(type_str)
    
    while i < n:
        # Check if we're at the start of an identifier
        if type_str[i].isalpha() or type_str[i] == '_':
            # Extract the full identifier
            j = i
            while j < n and (type_str[j].isalnum() or type_str[j] == '_'):
                j += 1
            ident = type_str[i:j]
            
            # Check if preceded by a dot
            preceded_by_dot = (i > 0 and type_str[i - 1] == '.')
            # Check if followed by a dot
            followed_by_dot = (j < n and type_str[j] == '.')
            
            if not preceded_by_dot and not followed_by_dot and ident in aliases:
                result.append(aliases[ident])
            else:
                result.append(ident)
            i = j
        else:
            result.append(type_str[i])
            i += 1
    
    return ''.join(result)


def transform(payloads, contract):
    """Aggregate API documentation from upstream component results.
    
    payloads[0] = signatures result (with 'result' key containing overloads)
    payloads[1] = parameters result (with 'result' key containing docs)
    payloads[2] = inheritance result (with 'result' key containing provider, namespace, aliases)
    
    Returns {"name": contract["name"], "result": {overloads, provider, namespace, parameters}}
    """
    sig_data = payloads[0]
    param_data = payloads[1]
    inh_data = payloads[2]
    
    # Extract results - inputs may be envelopes with name/result or raw results
    if isinstance(sig_data, dict) and set(sig_data.keys()) == {'name', 'result'}:
        sig_result = sig_data['result']
    else:
        sig_result = sig_data
    
    if isinstance(param_data, dict) and set(param_data.keys()) == {'name', 'result'}:
        param_result = param_data['result']
    else:
        param_result = param_data
    
    if isinstance(inh_data, dict) and set(inh_data.keys()) == {'name', 'result'}:
        inh_result = inh_data['result']
    else:
        inh_result = inh_data
    
    overloads = sig_result.get("overloads", [])
    docs = param_result.get("docs", {})
    provider = inh_result.get("provider")
    namespace = inh_result.get("namespace")
    aliases = inh_result.get("aliases", {})
    
    # Get parameters from provider's doc
    parameters = []
    if provider is not None and provider in docs:
        provider_params = docs[provider]
        for p in provider_params:
            new_type = _replace_aliases_in_type(p.get("type"), aliases)
            parameters.append({
                "name": p["name"],
                "type": new_type,
                "description": p.get("description", ""),
            })
    
    return {
        "name": contract["name"],
        "result": {
            "overloads": overloads,
            "provider": provider,
            "namespace": namespace,
            "parameters": parameters,
        },
    }
