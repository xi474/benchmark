"""Generate final report from core manifest."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core.get("components", {})

    # Title is fixed
    title = "API 文档的签名、参数与继承信息聚合"

    # Component count
    component_count = len(components)

    # SHA256 of the complete core object
    core_str = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    sha256 = hashlib.sha256(core_str.encode("utf-8")).hexdigest()

    # Attention: components matching any trigger condition
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # result.blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0:
                # Non-empty check: list/dict must be non-empty, string must be non-empty
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(comp_name)
                elif not isinstance(val, (list, dict, str)):
                    # For other types, non-empty means truthy but not None
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
