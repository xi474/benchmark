"""Transform layer for inheritance component: resolve inherited documentation."""


def transform(payloads, contract):
    """Resolve inherited doc from input payload.
    
    payloads[0] is the case.json content with 'objects' and 'target' keys.
    Returns {"name": contract["name"], "result": {provider, namespace, aliases}}
    """
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if "objects" not in data:
        raise ValueError("missing required field: objects")
    if "target" not in data:
        raise ValueError("missing required field: target")
    
    objects = data["objects"]
    target_id = data["target"]
    
    if not isinstance(objects, list):
        raise ValueError("objects must be an array")
    if not isinstance(target_id, str):
        raise ValueError("target must be a string")
    
    # Build lookup by id
    obj_map = {}
    for obj in objects:
        if not isinstance(obj, dict):
            raise ValueError("each object must be a dict")
        if "id" not in obj:
            raise ValueError("missing required field: id")
        obj_map[obj["id"]] = obj
    
    if target_id not in obj_map:
        raise ValueError(f"target '{target_id}' not found in objects")
    
    target_obj = obj_map[target_id]
    
    # Candidate order: target first, then its mro
    if "mro" not in target_obj:
        raise ValueError("missing required field: mro")
    
    mro = target_obj["mro"]
    candidates = [target_id] + list(mro)
    
    # Find first candidate with non-empty stripped doc
    provider = None
    namespace = None
    aliases = {}
    
    for cand_id in candidates:
        if cand_id not in obj_map:
            raise ValueError(f"MRO reference '{cand_id}' not found in objects")
        cand = obj_map[cand_id]
        
        if "doc" not in cand:
            raise ValueError("missing required field: doc")
        
        doc = cand["doc"]
        if not isinstance(doc, str):
            raise ValueError("doc must be a string")
        
        if doc.strip():
            provider = cand_id
            if "namespace" not in cand:
                raise ValueError("missing required field: namespace")
            namespace = cand["namespace"]
            if "aliases" not in cand:
                raise ValueError("missing required field: aliases")
            aliases = cand["aliases"]
            break
    
    return {
        "name": contract["name"],
        "result": {
            "provider": provider,
            "namespace": namespace,
            "aliases": aliases,
        },
    }
