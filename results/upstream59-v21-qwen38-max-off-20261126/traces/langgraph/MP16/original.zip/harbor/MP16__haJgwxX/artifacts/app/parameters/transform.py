"""Transform layer for parameters component: parse parameter documentation."""

import re


def _parse_doc(doc_str):
    """Parse a docstring for :param and :type directives.
    
    Supports:
      :param name: description
      :param TYPE name: description
      :type name: TYPE
    
    Returns list of {name, type, description} sorted by name.
    """
    params = {}  # name -> {name, type, description}
    seen_param = set()
    seen_type = set()
    
    lines = doc_str.split('\n')
    
    for line in lines:
        stripped = line.strip()
        
        # Try :param TYPE name: description  or  :param name: description
        param_match = re.match(r'^:param\s+(.+?):\s*(.*)', stripped)
        if param_match:
            rest = param_match.group(1).strip()
            description = param_match.group(2)
            
            # Determine if there's a type prefix before the name
            # The name is always the last token (Python identifier)
            # TYPE can contain spaces, brackets, etc.
            # We need to find the last identifier as the name
            # Split from the right to find the name
            parts = rest.rsplit(None, 1)
            if len(parts) == 2:
                potential_type, potential_name = parts
                # Check if potential_name is a valid Python identifier
                if potential_name.isidentifier():
                    param_type = potential_type
                    param_name = potential_name
                else:
                    # The whole rest is the name (no type)
                    param_name = rest
                    param_type = None
            elif len(parts) == 1:
                param_name = rest
                param_type = None
            else:
                continue
            
            if not param_name.isidentifier():
                raise ValueError(f"invalid parameter name: {param_name}")
            
            if param_name in seen_param:
                raise ValueError(f"duplicate param directive for: {param_name}")
            seen_param.add(param_name)
            
            params[param_name] = {
                "name": param_name,
                "type": param_type,
                "description": description,
            }
            continue
        
        # Try :type name: TYPE
        type_match = re.match(r'^:type\s+(\w+)\s*:\s*(.*)', stripped)
        if type_match:
            param_name = type_match.group(1)
            type_value = type_match.group(2).strip()
            
            if not param_name.isidentifier():
                raise ValueError(f"invalid parameter name in :type: {param_name}")
            
            if param_name in seen_type:
                raise ValueError(f"duplicate type directive for: {param_name}")
            seen_type.add(param_name)
            
            if param_name in params:
                # Override the inline type
                params[param_name]["type"] = type_value
            else:
                # Type without param - still keep it with empty description
                params[param_name] = {
                    "name": param_name,
                    "type": type_value,
                    "description": "",
                }
            continue
        
        # Non-directive lines are ignored
    
    # Sort by name
    result = sorted(params.values(), key=lambda x: x["name"])
    return result


def transform(payloads, contract):
    """Parse parameter docs from input payload.
    
    payloads[0] is the case.json content with 'objects' key.
    Returns {"name": contract["name"], "result": {docs: {id: [...]}}}
    """
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if "objects" not in data:
        raise ValueError("missing required field: objects")
    
    objects = data["objects"]
    if not isinstance(objects, list):
        raise ValueError("objects must be an array")
    
    docs = {}
    for obj in objects:
        if not isinstance(obj, dict):
            raise ValueError("each object must be a dict")
        if "id" not in obj:
            raise ValueError("missing required field: id")
        if "doc" not in obj:
            raise ValueError("missing required field: doc")
        
        obj_id = obj["id"]
        doc_str = obj["doc"]
        
        if not isinstance(doc_str, str):
            raise ValueError("doc must be a string")
        
        parsed = _parse_doc(doc_str)
        docs[obj_id] = parsed
    
    return {
        "name": contract["name"],
        "result": {
            "docs": docs,
        },
    }
