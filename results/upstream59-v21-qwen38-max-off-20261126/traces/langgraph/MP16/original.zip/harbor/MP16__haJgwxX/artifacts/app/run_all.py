"""Orchestrate all components: run each component's render in dependency order,
then run integrate.py and final_report.py."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph from contract inputs
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = {"path": cp, "contract": c}

    # Topological sort based on input dependencies
    def get_deps(contract):
        deps = set()
        for inp in contract.get("inputs", []):
            if inp.startswith("outputs/"):
                for name, info in contract_map.items():
                    if info["contract"].get("output") == inp:
                        deps.add(name)
        return deps

    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"circular dependency detected involving {name}")
        visiting.add(name)
        deps = get_deps(contract_map[name]["contract"])
        for dep in sorted(deps):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Run each component in order
    for name in ordered:
        cp = contract_map[name]["path"]
        render_script = cp.with_name("render.py")
        if not render_script.exists():
            raise ValueError(f"render.py not found for component {name}")

        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"component {name} failed with exit code {result.returncode}")

    # Run integrate.py to produce core_manifest.json
    integrate_script = ROOT / "integrate.py"
    if integrate_script.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"integrate.py failed with exit code {result.returncode}")

    # Run final_report.py to produce final_report.json
    report_script = ROOT / "final_report.py"
    if report_script.exists():
        result = subprocess.run(
            [sys.executable, str(report_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"final_report.py failed with exit code {result.returncode}")


if __name__ == "__main__":
    main()
