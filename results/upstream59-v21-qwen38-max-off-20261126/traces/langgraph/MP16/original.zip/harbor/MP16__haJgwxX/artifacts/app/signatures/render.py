"""Render layer for signatures component: file I/O and CLI interface."""

import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs from root, call transform, return envelope.
    
    Args:
        root: workspace root Path
        contract_path: path to contract.json
    
    Returns:
        {"name": ..., "result": ...}
    """
    root = Path(root)
    contract_path = Path(contract_path)
    
    # Determine component directory and ensure proper imports
    component_dir = Path(__file__).resolve().parent
    root_str = str(root)
    comp_str = str(component_dir)
    
    # Ensure both root and component dir are on sys.path
    for p in [root_str, comp_str]:
        if p not in sys.path:
            sys.path.insert(0, p)
    
    # Import using the package name if possible, fallback to direct
    pkg_name = component_dir.name
    try:
        mod_model = __import__(f"{pkg_name}.model", fromlist=["load_payload"])
        mod_transform = __import__(f"{pkg_name}.transform", fromlist=["transform"])
    except (ImportError, ModuleNotFoundError):
        import model as mod_model
        import transform as mod_transform
    
    contract = mod_model.load_payload(contract_path)
    payloads = [mod_model.load_payload(root / p) for p in contract["inputs"]]
    result = mod_transform.transform(payloads, contract)
    
    return result


if __name__ == "__main__":
    component_dir = Path(__file__).resolve().parent
    root = component_dir.parent
    
    sys.path.insert(0, str(root))
    
    import importlib
    mod = importlib.import_module(f"{component_dir.name}.render")
    
    contract_path = component_dir / "contract.json"
    result = mod.build_component(root, contract_path)
    
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    output_path = root / contract["output"]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )
