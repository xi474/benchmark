"""Transform layer for signatures component: parse Python overload signatures."""

import ast
import inspect


def _parse_signature(sig_str):
    """Parse a single Python function signature string into structured form.
    
    Input: e.g. "f(x: int, /, *, strict: bool = False) -> str"
    Returns: {name, parameters: [{name, kind, annotation, default}], returns}
    """
    # Build a fake function definition so ast can parse it
    fake_def = f"def {sig_str}: pass"
    tree = ast.parse(fake_def)
    func_node = tree.body[0]
    
    name = func_node.name
    
    # Parse return annotation
    returns = None
    if func_node.returns is not None:
        returns = ast.unparse(func_node.returns)
    
    parameters = []
    
    args = func_node.args
    
    # Count positional-only args
    posonlyargs = getattr(args, 'posonlyargs', [])
    num_posonly = len(posonlyargs)
    
    # Regular args (positional or keyword)
    num_args = len(args.args)
    
    # Defaults alignment: defaults are right-aligned to args
    # posonlyargs + args share the same defaults list
    all_positional = posonlyargs + args.args
    num_all_pos = len(all_positional)
    num_defaults = len(args.defaults)
    default_offset = num_all_pos - num_defaults
    
    for i, arg in enumerate(all_positional):
        param_name = arg.arg
        annotation = ast.unparse(arg.annotation) if arg.annotation else None
        
        # Determine kind
        if i < num_posonly:
            kind = "posonly"
        else:
            kind = "positional"
        
        # Default value
        default = None
        default_idx = i - default_offset
        if default_idx >= 0 and default_idx < len(args.defaults):
            default = ast.unparse(args.defaults[default_idx])
        
        parameters.append({
            "name": param_name,
            "kind": kind,
            "annotation": annotation,
            "default": default,
        })
    
    # *args (vararg)
    if args.vararg is not None:
        varg = args.vararg
        parameters.append({
            "name": varg.arg,
            "kind": "vararg",
            "annotation": ast.unparse(varg.annotation) if varg.annotation else None,
            "default": None,
        })
    
    # keyword-only args
    for i, arg in enumerate(args.kwonlyargs):
        annotation = ast.unparse(arg.annotation) if arg.annotation else None
        default = None
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            default = ast.unparse(args.kw_defaults[i])
        
        parameters.append({
            "name": arg.arg,
            "kind": "kwonly",
            "annotation": annotation,
            "default": default,
        })
    
    # **kwargs (kwarg)
    if args.kwarg is not None:
        kw = args.kwarg
        parameters.append({
            "name": kw.arg,
            "kind": "kwarg",
            "annotation": ast.unparse(kw.annotation) if kw.annotation else None,
            "default": None,
        })
    
    return {
        "name": name,
        "parameters": parameters,
        "returns": returns,
    }


def transform(payloads, contract):
    """Parse overload signatures from input payload.
    
    payloads[0] is the case.json content with 'overloads' key.
    Returns {"name": contract["name"], "result": {overloads: [...]}}
    """
    data = payloads[0]
    
    if not isinstance(data, dict):
        raise ValueError("input must be an object")
    if "overloads" not in data:
        raise ValueError("missing required field: overloads")
    
    overloads_raw = data["overloads"]
    if not isinstance(overloads_raw, list):
        raise ValueError("overloads must be an array")
    
    overloads = []
    for sig_str in overloads_raw:
        if not isinstance(sig_str, str):
            raise ValueError("each overload must be a string")
        parsed = _parse_signature(sig_str)
        overloads.append(parsed)
    
    return {
        "name": contract["name"],
        "result": {
            "overloads": overloads,
        },
    }
