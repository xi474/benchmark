import json
from pathlib import Path


def load_payload(path):
    """Load a UTF-8 JSON file. Only object/array top-level allowed.
    Raises ValueError on invalid JSON, non-object/array top-level, or NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("Top-level must be object or array")
    _check_finite(data)
    return data


def _check_finite(obj):
    """Recursively check for NaN/Infinity in nested structures."""
    if isinstance(obj, float):
        import math
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("Non-finite number found")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
