import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Build component result from root and contract path."""
    root = Path(root)
    contract_path = Path(contract_path)

    # Load contract
    contract = json.loads(contract_path.read_text(encoding='utf-8'))

    # Import model and transform from the same package
    comp_dir = contract_path.parent
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(comp_dir))

    from model import load_payload
    from transform import transform

    # Load payloads in contract input order
    payloads = [load_payload(root / p) for p in contract['inputs']]

    # Transform
    result = transform(payloads, contract)

    return result


if __name__ == "__main__":
    # CLI: write output to contract's output path
    root = Path(__file__).resolve().parents[1]
    contract_path = Path(__file__).resolve().parent / 'contract.json'

    result = build_component(root, contract_path)

    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
