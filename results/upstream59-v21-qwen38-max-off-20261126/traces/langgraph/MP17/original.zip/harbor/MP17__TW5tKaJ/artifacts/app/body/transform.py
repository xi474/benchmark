import re


def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    """multipart_body: assemble multipart form-data body from encoded parts."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    case = payloads[0]  # Original snapshot - not wrapped
    encoding_data = _unwrap(payloads[1])  # May be wrapped

    # Get boundary from original case
    if not isinstance(case, dict):
        raise ValueError("Case must be object")
    if 'boundary' not in case:
        raise ValueError("Missing boundary in case")

    boundary = case['boundary']
    if not isinstance(boundary, str) or not re.fullmatch(r'[A-Za-z0-9-]+', boundary):
        raise ValueError("Invalid boundary")

    if not isinstance(encoding_data, dict):
        raise ValueError("Encoding data must be object")
    if 'parts' not in encoding_data:
        raise ValueError("Missing parts in encoding data")

    enc_parts = encoding_data['parts']
    if not isinstance(enc_parts, list):
        raise ValueError("Parts must be array")

    # Check that boundary bytes don't appear in any payload
    boundary_bytes = boundary.encode('ascii')
    for part in enc_parts:
        payload_hex = part.get('payload_hex', '')
        payload_bytes = bytes.fromhex(payload_hex)
        if boundary_bytes in payload_bytes:
            raise ValueError("Boundary found in payload")

    # Build the multipart body
    body_parts = []
    for part in enc_parts:
        name = part['name']
        filename = part.get('filename')
        mimetype = part['mimetype']
        encoding = part['encoding']
        payload_hex = part['payload_hex']
        payload_bytes = bytes.fromhex(payload_hex)

        chunk = b''
        chunk += f'--{boundary}\r\n'.encode('ascii')

        # Content-Transfer-Encoding header for base64
        if encoding == 'base64':
            chunk += b'Content-Transfer-Encoding: base64\r\n'

        # Content-Type header
        chunk += f'Content-Type: {mimetype}\r\n'.encode('ascii')

        # Content-Disposition header
        disp = f'form-data; name="{name}"'
        if filename is not None:
            disp += f'; filename="{filename}"'
        chunk += f'Content-Disposition: {disp}\r\n'.encode('ascii')

        # Empty line separator
        chunk += b'\r\n'

        # Payload
        chunk += payload_bytes

        # Trailing CRLF after payload
        chunk += b'\r\n'

        body_parts.append(chunk)

    # Final boundary
    final = f'--{boundary}--\r\n'.encode('ascii')

    body = b''.join(body_parts) + final
    content_type = f'multipart/form-data; boundary={boundary}'

    return {
        'name': contract['name'],
        'result': {
            'content_type': content_type,
            'body_hex': body.hex(),
        }
    }
