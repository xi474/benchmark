import base64


def _unwrap(payload):
    """If payload is a dict with exactly keys 'name' and 'result', return result."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    """multipart_encoding: add payload_hex to each part based on encoding."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    parts_data = _unwrap(payloads[0])

    if not isinstance(parts_data, dict):
        raise ValueError("Input must be object")
    if 'parts' not in parts_data:
        raise ValueError("Missing 'parts' key")

    input_parts = parts_data['parts']
    if not isinstance(input_parts, list):
        raise ValueError("'parts' must be array")

    result_parts = []
    for part in input_parts:
        if not isinstance(part, dict):
            raise ValueError("Each part must be object")

        encoding = part.get('encoding')
        hex_str = part.get('hex')

        if encoding is None or hex_str is None:
            raise ValueError("Part missing encoding or hex")

        raw_bytes = bytes.fromhex(hex_str)

        if encoding == 'raw':
            payload_bytes = raw_bytes
        elif encoding == 'base64':
            # Base64 encode and fold at 76 chars with CRLF between lines, no trailing CRLF
            b64 = base64.b64encode(raw_bytes).decode('ascii')
            lines = [b64[i:i+76] for i in range(0, len(b64), 76)]
            payload_bytes = '\r\n'.join(lines).encode('ascii')
        else:
            raise ValueError(f"Unknown encoding: {encoding}")

        new_part = dict(part)
        new_part['payload_hex'] = payload_bytes.hex()
        result_parts.append(new_part)

    return {'name': contract['name'], 'result': {'parts': result_parts}}
