import re
import os


def transform(payloads, contract):
    """multipart_parts: convert fields+files into sorted parts list."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    case = payloads[0]

    # Validate required fields
    if not isinstance(case, dict):
        raise ValueError("Input must be object")
    for key in ('fields', 'files', 'boundary'):
        if key not in case:
            raise ValueError(f"Missing required field: {key}")

    fields = case['fields']
    files = case['files']
    boundary = case['boundary']

    if not isinstance(fields, dict):
        raise ValueError("fields must be object")
    if not isinstance(files, dict):
        raise ValueError("files must be object")
    if not isinstance(boundary, str):
        raise ValueError("boundary must be string")

    # boundary: only alphanumeric and hyphen, non-empty
    if not boundary or not re.fullmatch(r'[A-Za-z0-9-]+', boundary):
        raise ValueError("Invalid boundary")

    # Validate field names
    field_name_re = re.compile(r'^[A-Za-z0-9_.\-]+$')
    safe_path_re = re.compile(r'^[A-Za-z0-9_.\-]+(/[A-Za-z0-9_.\-]+)*$')

    # Validate files keys are safe relative paths
    for fpath in files:
        if not isinstance(fpath, str):
            raise ValueError("File path must be string")
        if not _is_safe_path(fpath):
            raise ValueError(f"Unsafe file path: {fpath}")
        if not isinstance(files[fpath], str):
            raise ValueError("File content must be hex string")

    parts = []

    for name, value in fields.items():
        if not isinstance(name, str) or not field_name_re.match(name):
            raise ValueError(f"Invalid field name: {name}")

        if isinstance(value, str):
            # Plain text field
            filename = None
            mimetype = 'text/plain'
            encoding = 'raw'
            data_bytes = value.encode('utf-8')
            hex_val = data_bytes.hex()
        elif isinstance(value, dict):
            # Object field
            if not value:
                raise ValueError(f"Empty field object for {name}")

            has_content = 'content' in value
            has_filename = 'filename' in value
            has_mimetype = 'mimetype' in value

            if not has_content and not has_filename:
                raise ValueError(f"Field object must have content or filename: {name}")

            # Determine filename
            if has_filename:
                fn = value['filename']
                if not isinstance(fn, str):
                    raise ValueError(f"filename must be string: {name}")
                basename = os.path.basename(fn)
                if not basename or not re.fullmatch(r'[A-Za-z0-9_.\-]+', basename):
                    raise ValueError(f"Invalid filename: {fn}")
                filename = basename
            else:
                filename = None

            # Determine content bytes
            if has_content:
                content = value['content']
                if not isinstance(content, str):
                    raise ValueError(f"content must be string: {name}")
                data_bytes = content.encode('utf-8')
                encoding = 'raw'
            else:
                # Read from files
                fn_path = value['filename']
                if fn_path not in files:
                    raise ValueError(f"File not found: {fn_path}")
                hex_str = files[fn_path]
                data_bytes = bytes.fromhex(hex_str)
                encoding = 'base64'

            # Determine mimetype
            if has_mimetype:
                mt = value['mimetype']
                if not isinstance(mt, str):
                    raise ValueError(f"mimetype must be string: {name}")
                if not re.fullmatch(r'[A-Za-z0-9!#$&\-.^_+]+/[A-Za-z0-9!#$&\-.^_+]+', mt):
                    raise ValueError(f"Invalid mimetype: {mt}")
                mimetype = mt
            else:
                # Infer from filename extension
                if filename is not None:
                    ext = _get_ext(filename)
                    mimetype = _ext_to_mime(ext)
                else:
                    mimetype = 'application/octet-stream'

            hex_val = data_bytes.hex()
        else:
            raise ValueError(f"Field value must be string or object: {name}")

        parts.append({
            'name': name,
            'filename': filename,
            'mimetype': mimetype,
            'encoding': encoding,
            'hex': hex_val,
        })

    # Sort by name (Python default string sort = lexicographic)
    parts.sort(key=lambda p: p['name'])

    return {'name': contract['name'], 'result': {'parts': parts}}


def _is_safe_path(p):
    """Check if path is a safe relative path."""
    if not p or not isinstance(p, str):
        return False
    if '\\' in p or ':' in p:
        return False
    if p.startswith('/'):
        return False
    segments = p.split('/')
    for seg in segments:
        if not seg or seg == '.' or seg == '..':
            return False
        if not re.fullmatch(r'[A-Za-z0-9_.\-]+', seg):
            return False
    return True


def _get_ext(filename):
    """Get lowercase extension including dot."""
    idx = filename.rfind('.')
    if idx == -1:
        return ''
    return filename[idx:].lower()


def _ext_to_mime(ext):
    """Map extension to MIME type."""
    mapping = {
        '.txt': 'text/plain',
        '.json': 'application/json',
        '.jpg': 'image/jpeg',
    }
    return mapping.get(ext, 'application/octet-stream')
