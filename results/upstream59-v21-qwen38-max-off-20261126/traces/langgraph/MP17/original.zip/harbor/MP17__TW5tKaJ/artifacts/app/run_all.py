import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contracts, determine execution order based on dependencies
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts.append((cp, c))

    if not contracts:
        raise ValueError("No contracts found")

    # Topological sort based on input dependencies
    # Build dependency graph: contract output -> contract name
    output_to_name = {}
    for cp, c in contracts:
        output_to_name[c['output']] = c['name']

    # Determine which contracts depend on which outputs
    name_to_cp = {c['name']: cp for cp, c in contracts}
    name_to_contract = {c['name']: c for cp, c in contracts}

    # Build adjacency: for each contract, find which other contracts must run first
    deps = {}
    for cp, c in contracts:
        dep_names = set()
        for inp in c['inputs']:
            if inp in output_to_name:
                dep_names.add(output_to_name[inp])
        deps[c['name']] = dep_names

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            raise ValueError(f"Circular dependency detected involving {name}")
        if name in visited:
            return
        visiting.add(name)
        for dep in deps.get(name, set()):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for cp, c in contracts:
        visit(c['name'])

    # Execute each component in order via its render.py CLI
    for name in ordered:
        cp = name_to_cp[name]
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            raise ValueError(f"Missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Component {name} failed with exit code {result.returncode}")

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"integrate.py failed with exit code {result.returncode}")

    # Run final_report.py to produce final_report.json
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"final_report.py failed with exit code {result.returncode}")


if __name__ == '__main__':
    main()
