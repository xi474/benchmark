"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)
    
    # title
    title = '集合文件清单的指令选择与归档元数据'
    
    # component_count
    components = core.get('components', {})
    component_count = len(components)
    
    # sha256: serialize the complete core object (including outer "components")
    # with specific formatting, no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()
    
    # attention: list of component names where any of these conditions hold:
    # - result.blocked is explicitly true
    # - complete/checkout/committed/ok is explicitly false
    # - unavailable/missing/conflicts/unreachable is non-empty
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        # Check blocked
        if result.get('blocked') is True:
            attention.add(name)
        
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None:
                # Non-empty check: for lists/dicts/strings, check truthiness
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, (int, float)) and val != 0:
                    # Numbers: non-zero means non-empty? 
                    # Actually spec says "non-empty" which applies to collections
                    # But let's be safe - only trigger for actual collections
                    pass
    
    attention_list = sorted(attention)
    
    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention_list
    }
    
    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(content + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
