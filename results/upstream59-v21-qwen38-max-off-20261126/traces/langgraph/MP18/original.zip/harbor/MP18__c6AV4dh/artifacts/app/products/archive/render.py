import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Load inputs from root, call transform, return envelope."""
    comp_dir = Path(contract_path).resolve().parent
    sys.path.insert(0, str(comp_dir))
    
    from model import load_payload
    from transform import transform
    
    root = Path(root)
    contract_path = Path(contract_path)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    result = transform(payloads, contract)
    return result


def _write_json(path, data):
    """Write JSON with standard formatting."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    path.write_text(content + '\n', encoding='utf-8')


if __name__ == '__main__':
    comp_dir = Path(__file__).resolve().parent
    contract_path = comp_dir / 'contract.json'
    
    import json as _json
    c = _json.loads(contract_path.read_text(encoding='utf-8'))
    
    root = Path.cwd()
    
    result = build_component(root, contract_path)
    output_path = root / c['output']
    _write_json(output_path, result)
