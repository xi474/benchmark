import hashlib


def _unwrap(obj):
    """If obj is a dict with exactly keys {name, result}, return result. Otherwise return obj as-is."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    """manifest_archive operation.
    
    Inputs: [inventory.json, selection.json]
    Output: {entries: [{path, size, sha256}], total_bytes}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    inventory = _unwrap(payloads[0])
    selection = _unwrap(payloads[1])
    
    if not isinstance(inventory, dict):
        raise ValueError("inventory must be an object")
    if not isinstance(selection, dict):
        raise ValueError("selection must be an object")
    
    inv_files = inventory.get('files', [])
    selected_paths = selection.get('selected', [])
    
    # Build a map from path to hex for quick lookup
    file_map = {}
    for f in inv_files:
        file_map[f['path']] = f['hex']
    
    # Validate selected: no duplicates, each must be in inventory regular files
    seen = set()
    for p in selected_paths:
        if p in seen:
            raise ValueError(f"duplicate selected path: {p}")
        seen.add(p)
        if p not in file_map:
            raise ValueError(f"selected path not in inventory: {p}")
    
    entries = []
    total_bytes = 0
    
    for p in selected_paths:
        hex_str = file_map[p]
        # Convert hex to actual bytes
        raw_bytes = bytes.fromhex(hex_str)
        size = len(raw_bytes)
        sha256_hash = hashlib.sha256(raw_bytes).hexdigest()
        entries.append({
            'path': p,
            'size': size,
            'sha256': sha256_hash
        })
        total_bytes += size
    
    result = {
        'entries': entries,
        'total_bytes': total_bytes
    }
    
    return {'name': contract['name'], 'result': result}
