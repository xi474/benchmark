def _unwrap(obj):
    """If obj is a dict with exactly keys {name, result}, return result. Otherwise return obj as-is."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def _is_safe_relative_path(p):
    """Check that path is a safe relative path using /, no absolute, no backslash,
    no colon, no empty segments, no . or .. segments."""
    if not isinstance(p, str):
        return False
    if not p:
        return False
    if '\\' in p or ':' in p:
        return False
    if p.startswith('/'):
        return False
    parts = p.split('/')
    for part in parts:
        if part == '' or part == '.' or part == '..':
            return False
    return True


def _validate_hex(h):
    """Validate hex string: must be valid hex (even length, valid chars)."""
    if not isinstance(h, str):
        raise ValueError("hex must be a string")
    if len(h) % 2 != 0:
        raise ValueError("hex string must have even length")
    try:
        bytes.fromhex(h)
    except ValueError:
        raise ValueError("invalid hex string")


def transform(payloads, contract):
    """manifest_inventory operation.
    
    Input: case.json with {files: [{path, kind, hex, target}], manifest, build_ignore}
    Output: {files: [{path, hex}] sorted by path, symlinks: [paths sorted]}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    case = _unwrap(payloads[0])
    
    if not isinstance(case, dict):
        raise ValueError("case must be an object")
    
    # Validate required fields
    if 'files' not in case:
        raise ValueError("missing 'files' field")
    if 'manifest' not in case:
        raise ValueError("missing 'manifest' field")
    if 'build_ignore' not in case:
        raise ValueError("missing 'build_ignore' field")
    
    files = case['files']
    manifest = case['manifest']
    build_ignore = case['build_ignore']
    
    if not isinstance(files, list):
        raise ValueError("'files' must be an array")
    
    # manifest must be str or null
    if manifest is not None and not isinstance(manifest, str):
        raise ValueError("'manifest' must be string or null")
    
    # build_ignore must be list or null
    if build_ignore is not None and not isinstance(build_ignore, list):
        raise ValueError("'build_ignore' must be array or null")
    
    regular_files = []
    symlinks = []
    seen_paths = set()
    
    for entry in files:
        if not isinstance(entry, dict):
            raise ValueError("each file entry must be an object")
        
        # Required fields
        for field in ('path', 'kind', 'hex', 'target'):
            if field not in entry:
                raise ValueError(f"missing '{field}' in file entry")
        
        path = entry['path']
        kind = entry['kind']
        hex_val = entry['hex']
        target = entry['target']
        
        if not isinstance(path, str):
            raise ValueError("'path' must be a string")
        if kind not in ('file', 'symlink'):
            raise ValueError("'kind' must be 'file' or 'symlink'")
        
        # Validate safe relative path
        if not _is_safe_relative_path(path):
            raise ValueError(f"unsafe path: {path}")
        
        # Check uniqueness
        if path in seen_paths:
            raise ValueError(f"duplicate path: {path}")
        seen_paths.add(path)
        
        if kind == 'file':
            # hex must be valid for regular files
            _validate_hex(hex_val)
            if target is not None:
                raise ValueError("target must be null for regular files")
            regular_files.append({'path': path, 'hex': hex_val})
        elif kind == 'symlink':
            # symlink: target must be safe relative path
            if target is None:
                raise ValueError("symlink must have non-null target")
            if not isinstance(target, str):
                raise ValueError("target must be a string for symlinks")
            if not _is_safe_relative_path(target):
                raise ValueError(f"unsafe symlink target: {target}")
            symlinks.append(path)
    
    # Sort files by path
    regular_files.sort(key=lambda x: x['path'])
    symlinks.sort()
    
    result = {
        'files': regular_files,
        'symlinks': symlinks
    }
    
    return {'name': contract['name'], 'result': result}
