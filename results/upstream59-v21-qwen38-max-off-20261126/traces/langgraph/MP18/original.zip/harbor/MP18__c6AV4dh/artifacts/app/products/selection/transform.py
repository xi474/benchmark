import fnmatch


def _unwrap(obj):
    """If obj is a dict with exactly keys {name, result}, return result. Otherwise return obj as-is."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def _is_safe_relative_path(p):
    """Check that path is a safe relative path."""
    if not isinstance(p, str):
        return False
    if not p:
        return False
    if '\\' in p or ':' in p:
        return False
    if p.startswith('/'):
        return False
    parts = p.split('/')
    for part in parts:
        if part == '' or part == '.' or part == '..':
            return False
    return True


def _should_exclude_default(path):
    """Check if path should be unconditionally excluded.
    Exclude .git directory and any .git subdirectory, *.pyc, MANIFEST.in itself."""
    parts = path.split('/')
    # Check for .git at any level
    for part in parts:
        if part == '.git':
            return True
    # Check *.pyc
    basename = parts[-1] if parts else ''
    if fnmatch.fnmatchcase(basename, '*.pyc'):
        return True
    # Check MANIFEST.in (exact match of full path)
    if path == 'MANIFEST.in':
        return True
    return False


def transform(payloads, contract):
    """manifest_selection operation.
    
    Inputs: [case.json, inventory.json]
    Output: {selected: [sorted paths]}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    case = _unwrap(payloads[0])
    inventory = _unwrap(payloads[1])
    
    if not isinstance(case, dict):
        raise ValueError("case must be an object")
    if not isinstance(inventory, dict):
        raise ValueError("inventory must be an object")
    
    manifest = case.get('manifest')
    build_ignore = case.get('build_ignore')
    
    # manifest and build_ignore cannot both be non-null
    if manifest is not None and build_ignore is not None:
        raise ValueError("manifest and build_ignore cannot both be non-null")
    
    # Get all regular file paths from inventory
    inv_files = inventory.get('files', [])
    all_paths = set()
    for f in inv_files:
        all_paths.add(f['path'])
    
    if manifest is None:
        # Default: select all regular files, then exclude by build_ignore
        selected = set(all_paths)
        
        if build_ignore is not None:
            if not isinstance(build_ignore, list):
                raise ValueError("build_ignore must be an array")
            for pattern in build_ignore:
                if not isinstance(pattern, str):
                    raise ValueError("build_ignore patterns must be strings")
                # fnmatchcase against full relative path
                to_remove = set()
                for p in selected:
                    if fnmatch.fnmatchcase(p, pattern):
                        to_remove.add(p)
                selected -= to_remove
    else:
        # manifest mode: start from empty set, process instructions line by line
        if not isinstance(manifest, str):
            raise ValueError("manifest must be a string")
        
        selected = set()
        lines = manifest.split('\n')
        
        for line in lines:
            stripped = line.strip()
            # Skip empty lines and comments
            if not stripped or stripped.startswith('#'):
                continue
            
            parts = stripped.split()
            cmd = parts[0]
            
            if cmd == 'include':
                if len(parts) != 2:
                    raise ValueError(f"invalid include syntax: {stripped}")
                pattern = parts[1]
                # Match complete path
                for p in all_paths:
                    if fnmatch.fnmatchcase(p, pattern):
                        selected.add(p)
            
            elif cmd == 'exclude':
                if len(parts) != 2:
                    raise ValueError(f"invalid exclude syntax: {stripped}")
                pattern = parts[1]
                # Match complete path
                to_remove = set()
                for p in selected:
                    if fnmatch.fnmatchcase(p, pattern):
                        to_remove.add(p)
                selected -= to_remove
            
            elif cmd == 'recursive-include':
                if len(parts) != 3:
                    raise ValueError(f"invalid recursive-include syntax: {stripped}")
                dir_prefix = parts[1]
                pattern = parts[2]
                # Match DIR/ at any depth, basename matches pattern
                for p in all_paths:
                    # Path must be under dir_prefix
                    if p.startswith(dir_prefix + '/'):
                        basename = p.split('/')[-1]
                        if fnmatch.fnmatchcase(basename, pattern):
                            selected.add(p)
            
            elif cmd == 'global-exclude':
                if len(parts) != 2:
                    raise ValueError(f"invalid global-exclude syntax: {stripped}")
                pattern = parts[1]
                # Match basename
                to_remove = set()
                for p in selected:
                    basename = p.split('/')[-1]
                    if fnmatch.fnmatchcase(basename, pattern):
                        to_remove.add(p)
                selected -= to_remove
            
            else:
                raise ValueError(f"unknown manifest command: {cmd}")
    
    # Unconditional exclusions
    final_selected = set()
    for p in selected:
        if not _should_exclude_default(p):
            final_selected.add(p)
    
    result = {
        'selected': sorted(final_selected)
    }
    
    return {'name': contract['name'], 'result': result}
