"""Run all components in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contracts
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)
    
    # Build dependency graph from contract inputs/outputs
    # Map output path -> component contract path
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        output = c['output']
        inputs = c['inputs']
        contract_info[cp] = {'name': name, 'output': output, 'inputs': inputs}
        output_to_contract[output] = cp
    
    # Topological sort based on dependencies
    # A component depends on another if any of its inputs is another component's output
    visited = set()
    order = []
    visiting = set()
    
    def visit(cp):
        if cp in visited:
            return
        if cp in visiting:
            print(f"Circular dependency detected", file=sys.stderr)
            sys.exit(1)
        visiting.add(cp)
        info = contract_info[cp]
        for inp in info['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                visit(dep_cp)
        visiting.remove(cp)
        visited.add(cp)
        order.append(cp)
    
    for cp in contracts:
        visit(cp)
    
    # Execute each component in order
    for cp in order:
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {contract_info[cp]['name']} failed", file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
