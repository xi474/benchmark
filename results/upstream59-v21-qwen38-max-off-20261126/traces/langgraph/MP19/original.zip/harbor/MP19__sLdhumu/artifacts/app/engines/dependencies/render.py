import json
from pathlib import Path


def build_component(root, contract_path):
    """Build dependencies component from file interface."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    # Load contract
    contract_text = contract_path.read_text(encoding="utf-8")
    contract = json.loads(contract_text)
    
    # Import model and transform from same directory
    import sys
    comp_dir = str(contract_path.parent)
    if comp_dir not in sys.path:
        sys.path.insert(0, comp_dir)
    
    from model import load_payload
    from transform import transform
    
    # Load all input payloads
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    # Run transform
    result = transform(payloads, contract)
    
    # Write output
    output_path = root / contract['output']
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_text = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    output_path.write_text(output_text, encoding="utf-8")
    
    return result


if __name__ == "__main__":
    import sys
    root = Path(__file__).resolve().parents[2]
    contract_path = Path(__file__).resolve().parent / 'contract.json'
    build_component(root, contract_path)
