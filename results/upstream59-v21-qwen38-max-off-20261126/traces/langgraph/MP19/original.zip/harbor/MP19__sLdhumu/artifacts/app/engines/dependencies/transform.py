from collections import deque


def transform(payloads, contract):
    """Compute dependency closure via BFS from entry point.
    
    Inputs: [case.json, scanner.json]
    Output: {paths: [sorted paths], external: [sorted external names]}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    case = payloads[0]
    scanner_result = payloads[1]
    
    # Handle name/result wrapper
    if isinstance(scanner_result, dict) and set(scanner_result.keys()) == {'name', 'result'}:
        scanner_result = scanner_result['result']
    
    # Validate case
    for field in ('modules', 'entry', 'externals', 'aliases'):
        if field not in case:
            raise ValueError(f"Missing required field: {field}")
    
    modules = case['modules']
    entry = case['entry']
    externals = case['externals']
    aliases = case['aliases']
    
    imports_map = scanner_result['imports']  # path -> [module names]
    module_paths = scanner_result['module_paths']  # module_name -> path
    
    # BFS from entry
    visited_paths = set()
    external_deps = set()
    queue = deque()
    
    # Start with entry path
    queue.append(entry)
    visited_paths.add(entry)
    
    while queue:
        current_path = queue.popleft()
        
        # Get imports for this path
        dep_modules = imports_map.get(current_path, [])
        
        for mod_name in dep_modules:
            if mod_name in module_paths:
                # Local module - add its path
                dep_path = module_paths[mod_name]
                if dep_path not in visited_paths:
                    visited_paths.add(dep_path)
                    queue.append(dep_path)
                
                # Also add all parent package __init__.py files
                _add_parent_inits(mod_name, module_paths, visited_paths, queue)
            else:
                # External module
                resolved = _resolve_external_name(mod_name, externals, aliases)
                if resolved is None:
                    raise ValueError(f"Unknown module: {mod_name}")
                external_deps.add(resolved)
    
    # Ensure entry's parent packages are included
    entry_module = None
    for mname, mpath in module_paths.items():
        if mpath == entry:
            entry_module = mname
            break
    
    if entry_module is not None:
        _add_parent_inits(entry_module, module_paths, visited_paths, queue)
        # Process any newly added items
        while queue:
            current_path = queue.popleft()
            dep_modules = imports_map.get(current_path, [])
            for mod_name in dep_modules:
                if mod_name in module_paths:
                    dep_path = module_paths[mod_name]
                    if dep_path not in visited_paths:
                        visited_paths.add(dep_path)
                        queue.append(dep_path)
                    _add_parent_inits(mod_name, module_paths, visited_paths, queue)
                else:
                    resolved = _resolve_external_name(mod_name, externals, aliases)
                    if resolved is None:
                        raise ValueError(f"Unknown module: {mod_name}")
                    external_deps.add(resolved)
    
    return {
        "name": contract["name"],
        "result": {
            "paths": sorted(visited_paths),
            "external": sorted(external_deps)
        }
    }


def _add_parent_inits(module_name, module_paths, visited_paths, queue):
    """Add all parent package __init__.py paths for a given module."""
    parts = module_name.split('.') if module_name else []
    
    # For each parent level, check if __init__.py exists
    for i in range(len(parts)):
        parent = '.'.join(parts[:i])  # "" for root, "pkg" for pkg, etc.
        if parent in module_paths:
            ppath = module_paths[parent]
            if ppath not in visited_paths:
                visited_paths.add(ppath)
                queue.append(ppath)


def _resolve_external_name(name, externals, aliases):
    """Resolve external module name through aliases."""
    resolved = aliases.get(name, name)
    
    if resolved in externals:
        return resolved
    
    first_segment = resolved.split('.')[0]
    if first_segment in externals:
        return first_segment
    
    return None
