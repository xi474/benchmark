import hashlib
import io
import struct
import time
import zipfile


def transform(payloads, contract):
    """Create deterministic ZIP payload from dependency closure.
    
    Inputs: [case.json, dependencies.json]
    Output: {paths, zip_hex, sha256, external}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    case = payloads[0]
    deps_result = payloads[1]
    
    # Handle name/result wrapper
    if isinstance(deps_result, dict) and set(deps_result.keys()) == {'name', 'result'}:
        deps_result = deps_result['result']
    
    modules = case['modules']
    dep_paths = deps_result['paths']
    external = deps_result['external']
    
    # Validate paths exist in modules
    for p in dep_paths:
        if p not in modules:
            raise ValueError(f"Source path not found in modules: {p}")
    
    # Check for duplicates
    if len(dep_paths) != len(set(dep_paths)):
        raise ValueError("Duplicate paths in dependency closure")
    
    # Build sorted list of paths for ZIP
    zip_paths = sorted(dep_paths)
    
    # Check if root __init__.py is needed but missing
    has_root_init = '__init__.py' in dep_paths
    need_root_init = False
    
    # If any path has a package component, we might need root __init__.py
    # According to spec: "如果根__init__.py缺失则增加空根__init__.py"
    # This means if there are any package files (paths with /), add empty root __init__.py
    has_packages = any('/' in p for p in zip_paths)
    if has_packages and not has_root_init:
        need_root_init = True
    
    if need_root_init:
        zip_paths = sorted(zip_paths + ['__init__.py'])
    
    # Create deterministic ZIP
    buf = io.BytesIO()
    
    # Fixed timestamp: 1980-01-01 00:00:00
    fixed_date_time = (1980, 1, 1, 0, 0, 0)
    
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_STORED) as zf:
        for zpath in zip_paths:
            if zpath == '__init__.py' and need_root_init:
                data = b''
            else:
                source = modules[zpath]
                data = source.encode('utf-8')
            
            info = zipfile.ZipInfo(filename=zpath, date_time=fixed_date_time)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o644 << 16
            info.comment = b''
            
            zf.writestr(info, data)
    
    zip_bytes = buf.getvalue()
    zip_hex = zip_bytes.hex()
    sha256_hash = hashlib.sha256(zip_bytes).hexdigest()
    
    return {
        "name": contract["name"],
        "result": {
            "paths": zip_paths,
            "zip_hex": zip_hex,
            "sha256": sha256_hash,
            "external": external
        }
    }
