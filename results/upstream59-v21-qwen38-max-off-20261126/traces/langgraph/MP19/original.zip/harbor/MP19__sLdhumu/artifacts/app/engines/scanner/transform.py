import ast


def transform(payloads, contract):
    """Perform static import scan on modules.
    
    Input: case.json with {modules, entry, externals, aliases}
    Output: {imports: {path: [sorted module names]}, module_paths: {module_name: path}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    case = payloads[0]
    
    # Extract and validate fields
    if not isinstance(case, dict):
        raise ValueError("case must be a dict")
    
    for field in ('modules', 'entry', 'externals', 'aliases'):
        if field not in case:
            raise ValueError(f"Missing required field: {field}")
    
    modules = case['modules']
    entry = case['entry']
    externals = case['externals']
    aliases = case['aliases']
    
    if not isinstance(modules, dict):
        raise ValueError("modules must be a dict")
    if not isinstance(entry, str):
        raise ValueError("entry must be a string")
    if not isinstance(externals, list):
        raise ValueError("externals must be a list")
    if not isinstance(aliases, dict):
        raise ValueError("aliases must be a dict")
    
    if entry not in modules:
        raise ValueError(f"entry path '{entry}' not in modules")
    
    # Build module_paths: map canonical module name -> path
    # For each .py file, derive its module name
    module_paths = {}
    path_to_module = {}
    
    for path in modules:
        if not path.endswith('.py'):
            raise ValueError(f"Module path must end with .py: {path}")
        
        # Convert path to module name
        # e.g., "pkg/a.py" -> "pkg.a", "main.py" -> "main", "pkg/__init__.py" -> "pkg"
        rel = path[:-3]  # remove .py
        parts = rel.replace('\\', '/').split('/')
        
        if parts[-1] == '__init__':
            # Package init
            if len(parts) == 1:
                # Root __init__.py -> module name ""
                mod_name = ""
            else:
                mod_name = '.'.join(parts[:-1])
        else:
            mod_name = '.'.join(parts)
        
        module_paths[mod_name] = path
        path_to_module[path] = mod_name
    
    # Now parse each module's source and extract imports
    imports = {}  # path -> set of canonical module names
    
    for path, source in modules.items():
        try:
            tree = ast.parse(source, filename=path)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in {path}: {e}") from e
        
        current_module = path_to_module[path]
        found_imports = set()
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.name
                    # Check if it's a local module (or prefix matches a local module)
                    resolved = _resolve_import(name, current_module, module_paths, externals, aliases)
                    if resolved is not None:
                        found_imports.add(resolved)
            
            elif isinstance(node, ast.ImportFrom):
                if node.level is None or node.level == 0:
                    # Absolute import: from X import y
                    if node.module is None:
                        raise ValueError(f"from * import not allowed in {path}")
                    
                    base_module = node.module
                    
                    # Try X.y as local module first
                    if node.names:
                        for alias in node.names:
                            if alias.name == '*':
                                raise ValueError(f"from * import not allowed in {path}")
                            
                            # Try base_module.name as a local module
                            candidate = f"{base_module}.{alias.name}"
                            if candidate in module_paths:
                                found_imports.add(candidate)
                            elif base_module in module_paths:
                                found_imports.add(base_module)
                            else:
                                # It's an external dependency on base_module
                                resolved = _resolve_external(base_module, externals, aliases)
                                if resolved is not None:
                                    found_imports.add(resolved)
                    else:
                        # from X import (nothing?) - shouldn't happen normally
                        pass
                else:
                    # Relative import: from . import y or from .x import y
                    level = node.level
                    # Determine the current package
                    current_parts = current_module.split('.') if current_module else []
                    
                    # For relative imports, we go up 'level' packages
                    # If current module is a package (__init__.py), level=1 means current package
                    # If current module is not __init__, level=1 means parent package
                    
                    # Check if current path is __init__.py
                    is_init = path.endswith('__init__.py')
                    
                    if is_init:
                        # Current module IS the package, so level=1 stays in current package
                        pkg_parts = current_parts[:]
                    else:
                        # Current module is inside a package, level=1 goes to parent
                        pkg_parts = current_parts[:-1] if current_parts else []
                    
                    # Go up (level-1) more levels
                    for _ in range(level - 1):
                        if not pkg_parts:
                            raise ValueError(f"Relative import exceeds root in {path}")
                        pkg_parts = pkg_parts[:-1]
                    
                    # Now resolve the imported name
                    if node.module:
                        # from .x import y -> resolve relative module
                        rel_parts = node.module.split('.')
                        target_parts = pkg_parts + rel_parts
                        target_module = '.'.join(target_parts)
                        
                        if node.names:
                            for alias in node.names:
                                if alias.name == '*':
                                    raise ValueError(f"from * import not allowed in {path}")
                                # Try target_module.name as local
                                candidate = f"{target_module}.{alias.name}"
                                if candidate in module_paths:
                                    found_imports.add(candidate)
                                elif target_module in module_paths:
                                    found_imports.add(target_module)
                                else:
                                    raise ValueError(f"Cannot resolve relative import in {path}: {node.module}.{alias.name}")
                        else:
                            if target_module in module_paths:
                                found_imports.add(target_module)
                    else:
                        # from . import y
                        if node.names:
                            for alias in node.names:
                                if alias.name == '*':
                                    raise ValueError(f"from * import not allowed in {path}")
                                candidate_parts = pkg_parts + [alias.name]
                                candidate = '.'.join(candidate_parts)
                                if candidate in module_paths:
                                    found_imports.add(candidate)
                                else:
                                    raise ValueError(f"Cannot resolve relative import in {path}: .{alias.name}")
        
        imports[path] = sorted(found_imports)
    
    return {
        "name": contract["name"],
        "result": {
            "imports": imports,
            "module_paths": module_paths
        }
    }


def _resolve_import(name, current_module, module_paths, externals, aliases):
    """Resolve an absolute import name. Returns canonical module name or None."""
    # First check if exact name is a local module
    if name in module_paths:
        return name
    
    # Check if any prefix is a local module (e.g., import pkg.a.b -> pkg.a might be local)
    parts = name.split('.')
    for i in range(len(parts), 0, -1):
        prefix = '.'.join(parts[:i])
        if prefix in module_paths:
            return prefix
    
    # It's external - resolve through aliases first
    return _resolve_external(name, externals, aliases)


def _resolve_external(name, externals, aliases):
    """Resolve an external module name through aliases and externals list."""
    # Apply alias first (exact match)
    resolved = aliases.get(name, name)
    
    # Check if resolved name or its first segment is in externals
    if resolved in externals:
        return resolved
    
    first_segment = resolved.split('.')[0]
    if first_segment in externals:
        return first_segment
    
    # Not recognized as external
    return None
