import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)
    
    components = core['components']
    
    # Compute sha256 of the complete core object
    core_serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256_hash = hashlib.sha256(core_serialized).hexdigest()
    
    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        
        # Check blocked is explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)
        
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            if key in result:
                val = result[key]
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    # Non-empty for numeric? Spec says "非空" which typically means non-empty collection
                    # But let's be safe - only collections/strings
                    pass
    
    report = {
        "title": "Python 支持模块发现与可重复 ZIP 载荷",
        "component_count": len(components),
        "sha256": sha256_hash,
        "attention": sorted(attention)
    }
    
    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    out_path.write_text(out_text, encoding="utf-8")


if __name__ == '__main__':
    main()
