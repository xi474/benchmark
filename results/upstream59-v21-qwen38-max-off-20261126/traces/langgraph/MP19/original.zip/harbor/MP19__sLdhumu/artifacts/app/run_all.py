import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' not in rel.parts:
            contracts.append(cp)
    
    if not contracts:
        raise ValueError("No contracts found")
    
    # Build dependency order based on input/output relationships
    # Load all contracts first
    contract_data = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_data[cp] = c
    
    # Topological sort based on dependencies
    # A component depends on another if its inputs include the other's output
    output_to_contract = {}
    for cp, c in contract_data.items():
        output_to_contract[c['output']] = cp
    
    # Build adjacency: component -> set of components it depends on
    deps = {}
    for cp, c in contract_data.items():
        deps[cp] = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                deps[cp].add(output_to_contract[inp])
    
    # Topological sort (Kahn's algorithm)
    in_degree = {cp: 0 for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            pass  # We need reverse edges
    
    # Build reverse: who depends on whom
    dependents = {cp: set() for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            dependents[d].add(cp)
    
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    order = []
    
    while queue:
        queue.sort()  # deterministic
        cp = queue.pop(0)
        order.append(cp)
        for dependent in dependents[cp]:
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
    
    if len(order) != len(contracts):
        raise ValueError("Circular dependency detected")
    
    # Execute each component in order
    for cp in order:
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            raise ValueError(f"render.py not found for {cp}")
        
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode != 0:
            print(f"FAILED: {render_py}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
