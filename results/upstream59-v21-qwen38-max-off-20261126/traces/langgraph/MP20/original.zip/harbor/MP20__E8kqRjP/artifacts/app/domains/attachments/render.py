import json
import sys
from pathlib import Path

# Add component dir and root to path for imports
_component_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(_component_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, call transform, write output, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_text = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    out_path.write_text(out_text, encoding='utf-8')

    return result


if __name__ == "__main__":
    # CLI: run from any directory, use script location to find contract
    contract_path = Path(__file__).resolve().with_name('contract.json')
    root = contract_path.parents[1]  # workspace root (two levels up from component)
    # Actually, components are at domains/X or views/X, so root is parents[2]
    root = Path(__file__).resolve().parents[2]
    build_component(root, contract_path)
