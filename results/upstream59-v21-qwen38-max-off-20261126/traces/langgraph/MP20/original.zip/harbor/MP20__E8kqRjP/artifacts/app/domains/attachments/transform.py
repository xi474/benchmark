import json


def _unwrap(payload):
    """If payload is a dict with exactly keys {name, result}, return result. Otherwise return as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def _is_finite_json(val):
    """Check that a value is valid finite JSON."""
    import math
    if val is None:
        return True
    if isinstance(val, bool):
        return True
    if isinstance(val, int):
        return True
    if isinstance(val, float):
        return not (math.isnan(val) or math.isinf(val))
    if isinstance(val, str):
        return True
    if isinstance(val, list):
        return all(_is_finite_json(v) for v in val)
    if isinstance(val, dict):
        return all(_is_finite_json(v) for v in val.values())
    return False


def transform(payloads, contract):
    """feature_attachments: extract each variant's attachment into
    {attachments: {flag_id: {variant_id: {value, canonical}}}}"""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = _unwrap(payloads[0])

    if not isinstance(case, dict):
        raise ValueError("input must be an object")
    if 'flags' not in case:
        raise ValueError("missing 'flags'")

    flags = case['flags']
    if not isinstance(flags, list):
        raise ValueError("'flags' must be an array")

    attachments = {}
    for flag in flags:
        if not isinstance(flag, dict):
            raise ValueError("each flag must be an object")
        flag_id = flag['id']
        if not isinstance(flag_id, str) or not flag_id.strip():
            raise ValueError("flag id must be non-empty string")

        variants = flag.get('variants', [])
        if not isinstance(variants, list):
            raise ValueError("flag.variants must be an array")

        flag_attachments = {}
        for variant in variants:
            if not isinstance(variant, dict):
                raise ValueError("each variant must be an object")
            variant_id = variant['id']
            if not isinstance(variant_id, str) or not variant_id.strip():
                raise ValueError("variant id must be non-empty string")

            attachment = variant.get('attachment')
            if not _is_finite_json(attachment):
                raise ValueError("variant attachment contains non-finite values")

            # canonical is compact JSON string: sort_keys=True, separators=(',',':'), ensure_ascii=False
            canonical = json.dumps(
                attachment,
                ensure_ascii=False,
                sort_keys=True,
                separators=(',', ':'),
                allow_nan=False
            )

            flag_attachments[variant_id] = {
                "value": attachment,
                "canonical": canonical
            }

        attachments[flag_id] = flag_attachments

    result = {"attachments": attachments}
    return {"name": contract["name"], "result": result}
