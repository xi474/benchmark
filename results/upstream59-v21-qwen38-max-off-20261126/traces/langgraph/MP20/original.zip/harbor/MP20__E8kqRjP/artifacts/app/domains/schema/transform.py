import copy


def _unwrap(payload):
    """If payload is a dict with exactly keys {name, result}, return result. Otherwise return as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def _validate_string(val, field_name):
    """Validate that val is a non-empty string (after strip)."""
    if not isinstance(val, str):
        raise ValueError(f"{field_name} must be a string")
    if not val.strip():
        raise ValueError(f"{field_name} must be non-empty after strip")


def _is_finite_json(val):
    """Check that a value is valid finite JSON (no NaN/Infinity)."""
    import math
    if val is None:
        return True
    if isinstance(val, bool):
        return True
    if isinstance(val, int):
        return True
    if isinstance(val, float):
        return not (math.isnan(val) or math.isinf(val))
    if isinstance(val, str):
        return True
    if isinstance(val, list):
        return all(_is_finite_json(v) for v in val)
    if isinstance(val, dict):
        return all(_is_finite_json(v) for v in val.values())
    return False


def transform(payloads, contract):
    """feature_schema: validate flag/segment structure, return deep copy of {flags, segments}."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = _unwrap(payloads[0])

    # Validate top-level keys
    if not isinstance(case, dict):
        raise ValueError("input must be an object")

    if 'flags' not in case:
        raise ValueError("missing 'flags'")
    if 'segments' not in case:
        raise ValueError("missing 'segments'")

    flags = case['flags']
    segments = case['segments']

    if not isinstance(flags, list):
        raise ValueError("'flags' must be an array")
    if not isinstance(segments, list):
        raise ValueError("'segments' must be an array")

    # Validate flags
    flag_ids = set()
    for flag in flags:
        if not isinstance(flag, dict):
            raise ValueError("each flag must be an object")
        if 'id' not in flag:
            raise ValueError("flag missing 'id'")
        _validate_string(flag['id'], "flag.id")
        if flag['id'] in flag_ids:
            raise ValueError(f"duplicate flag id: {flag['id']}")
        flag_ids.add(flag['id'])

        if 'variants' not in flag:
            raise ValueError("flag missing 'variants'")
        if not isinstance(flag['variants'], list):
            raise ValueError("flag.variants must be an array")

        variant_ids = set()
        for variant in flag['variants']:
            if not isinstance(variant, dict):
                raise ValueError("each variant must be an object")
            if 'id' not in variant:
                raise ValueError("variant missing 'id'")
            _validate_string(variant['id'], "variant.id")
            if variant['id'] in variant_ids:
                raise ValueError(f"duplicate variant id '{variant['id']}' in flag '{flag['id']}'")
            variant_ids.add(variant['id'])

            if 'attachment' not in variant:
                raise ValueError("variant missing 'attachment'")
            if not _is_finite_json(variant['attachment']):
                raise ValueError("variant attachment contains non-finite values")

        if 'rules' not in flag:
            raise ValueError("flag missing 'rules'")
        if not isinstance(flag['rules'], list):
            raise ValueError("flag.rules must be an array")

        rule_ids = set()
        for rule in flag['rules']:
            if not isinstance(rule, dict):
                raise ValueError("each rule must be an object")
            if 'id' not in rule:
                raise ValueError("rule missing 'id'")
            _validate_string(rule['id'], "rule.id")
            if rule['id'] in rule_ids:
                raise ValueError(f"duplicate rule id '{rule['id']}' in flag '{flag['id']}'")
            rule_ids.add(rule['id'])

            if 'segment' not in rule:
                raise ValueError("rule missing 'segment'")
            _validate_string(rule['segment'], "rule.segment")

            if 'variant' not in rule:
                raise ValueError("rule missing 'variant'")
            _validate_string(rule['variant'], "rule.variant")

    # Validate segments
    segment_ids = set()
    for seg in segments:
        if not isinstance(seg, dict):
            raise ValueError("each segment must be an object")
        if 'id' not in seg:
            raise ValueError("segment missing 'id'")
        _validate_string(seg['id'], "segment.id")
        if seg['id'] in segment_ids:
            raise ValueError(f"duplicate segment id: {seg['id']}")
        segment_ids.add(seg['id'])

    result = {
        "flags": copy.deepcopy(flags),
        "segments": copy.deepcopy(segments)
    }

    return {"name": contract["name"], "result": result}
