"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core.get('components', {})

    # SHA256 of the complete core object
    core_bytes = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256_hex = hashlib.sha256(core_bytes).hexdigest()

    # Attention: components matching any trigger condition
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0:
                # Non-empty check: list/dict must be non-empty, string non-empty
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(comp_name)

    report = {
        "title": "特性配置的模式、附件与引用一致性",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    out_path.write_text(out_text, encoding='utf-8')


if __name__ == '__main__':
    main()
