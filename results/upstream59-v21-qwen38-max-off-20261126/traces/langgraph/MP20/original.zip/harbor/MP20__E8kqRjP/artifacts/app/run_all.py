"""Orchestrate all components based on contract.json files.

Execution order respects dependencies:
- schema and attachments are independent (both read inputs/case.json)
- references depends on schema output
- snapshot depends on all three upstream outputs
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' not in rel.parts:
            contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contracts
    # Each contract has inputs that may reference other component outputs
    comp_map = {}  # name -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_map[c['name']] = cp

    # Topological sort based on input dependencies
    # A component depends on another if any of its inputs is an output of that component
    output_to_comp = {}
    for name, cp in comp_map.items():
        c = json.loads(cp.read_text(encoding='utf-8'))
        output_to_comp[c['output']] = name

    deps = {}  # name -> set of dependency names
    for name, cp in comp_map.items():
        c = json.loads(cp.read_text(encoding='utf-8'))
        dep_set = set()
        for inp in c['inputs']:
            if inp in output_to_comp:
                dep_set.add(output_to_comp[inp])
        deps[name] = dep_set

    # Topological sort (Kahn's algorithm)
    in_degree = {name: len(d) for name, d in deps.items()}
    queue = sorted([n for n, d in in_degree.items() if d == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for name, dep_set in deps.items():
            if node in dep_set:
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)
                    queue.sort()

    if len(order) != len(comp_map):
        print("Dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute components in order
    for name in order:
        cp = comp_map[name]
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py to build core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"integrate.py failed", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"final_report.py failed", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
