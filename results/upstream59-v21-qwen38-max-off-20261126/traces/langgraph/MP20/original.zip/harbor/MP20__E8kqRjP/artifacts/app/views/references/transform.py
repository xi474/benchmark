def _unwrap(payload):
    """If payload is a dict with exactly keys {name, result}, return result. Otherwise return as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    """feature_references: two-phase validation of segment and variant references.
    
    Input is feature_schema result (payloads[0]).
    Phase 1: Check all rule segment refs, sorted by flag/rule ID, first missing wins.
    Phase 2: Check all rule variant refs within owning flag.
    Returns {ok, error} - errors are business rejections, not ValueError.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    schema = _unwrap(payloads[0])

    if not isinstance(schema, dict):
        raise ValueError("schema input must be an object")

    flags = schema.get('flags', [])
    segments = schema.get('segments', [])

    # Build segment ID set
    segment_ids = set()
    for seg in segments:
        if isinstance(seg, dict) and 'id' in seg:
            segment_ids.add(seg['id'])

    # Phase 1: Check segment references
    # Sort flags by id, then rules by id within each flag
    sorted_flags = sorted(flags, key=lambda f: f.get('id', ''))
    for flag in sorted_flags:
        flag_id = flag.get('id', '')
        rules = flag.get('rules', [])
        sorted_rules = sorted(rules, key=lambda r: r.get('id', ''))
        for rule in sorted_rules:
            rule_id = rule.get('id', '')
            target_segment = rule.get('segment', '')
            if target_segment not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": flag_id,
                            "rule": rule_id,
                            "target": target_segment
                        }
                    }
                }

    # Phase 2: Check variant references (within owning flag only)
    for flag in sorted_flags:
        flag_id = flag.get('id', '')
        variants = flag.get('variants', [])
        variant_ids = set()
        for v in variants:
            if isinstance(v, dict) and 'id' in v:
                variant_ids.add(v['id'])

        rules = flag.get('rules', [])
        sorted_rules = sorted(rules, key=lambda r: r.get('id', ''))
        for rule in sorted_rules:
            rule_id = rule.get('id', '')
            target_variant = rule.get('variant', '')
            if target_variant not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": flag_id,
                            "rule": rule_id,
                            "target": target_variant
                        }
                    }
                }

    return {
        "name": contract["name"],
        "result": {
            "ok": True,
            "error": None
        }
    }
