import json


def _unwrap(payload):
    """If payload is a dict with exactly keys {name, result}, return result. Otherwise return as-is."""
    if isinstance(payload, dict) and set(payload.keys()) == {'name', 'result'}:
        return payload['result']
    return payload


def transform(payloads, contract):
    """feature_snapshot: build exportable config snapshot if references are valid.
    
    Inputs in order: case.json, schema result, attachments result, references result.
    If references failed: atomic rollback returning old_snapshot.
    If references ok: construct sorted snapshot and export.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = _unwrap(payloads[0])
    schema = _unwrap(payloads[1])
    attachments_result = _unwrap(payloads[2])
    references_result = _unwrap(payloads[3])

    # Check if references validation passed
    refs_ok = references_result.get('ok', False)
    refs_error = references_result.get('error', None)

    if not refs_ok:
        # Atomic rollback: return old_snapshot from original input
        old_snapshot = case.get('old_snapshot', {})
        return {
            "name": contract["name"],
            "result": {
                "committed": False,
                "snapshot": old_snapshot,
                "error": refs_error,
                "export": None
            }
        }

    # Build snapshot from schema + attachments
    # flags sorted by id, variants sorted by id within each flag, rules sorted by id
    schema_flags = schema.get('flags', [])
    schema_segments = schema.get('segments', [])
    attachments_map = attachments_result.get('attachments', {})

    snapshot_flags = []
    for flag in sorted(schema_flags, key=lambda f: f.get('id', '')):
        flag_id = flag['id']
        flag_attachments = attachments_map.get(flag_id, {})

        # Build variants with attachment values from attachments result
        variants = []
        for v in sorted(flag.get('variants', []), key=lambda x: x.get('id', '')):
            vid = v['id']
            att_info = flag_attachments.get(vid, {})
            att_value = att_info.get('value', v.get('attachment'))
            variants.append({
                "id": vid,
                "attachment": att_value
            })

        # Rules sorted by id, keep original rule structure
        rules = []
        for r in sorted(flag.get('rules', []), key=lambda x: x.get('id', '')):
            rules.append({
                "id": r['id'],
                "segment": r['segment'],
                "variant": r['variant']
            })

        snapshot_flags.append({
            "id": flag_id,
            "variants": variants,
            "rules": rules
        })

    # Segments sorted by id
    snapshot_segments = []
    for seg in sorted(schema_segments, key=lambda s: s.get('id', '')):
        snapshot_segments.append({"id": seg['id']})

    snapshot = {
        "flags": snapshot_flags,
        "segments": snapshot_segments
    }

    # Export is compact canonical JSON of the snapshot
    export = json.dumps(
        snapshot,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    )

    return {
        "name": contract["name"],
        "result": {
            "committed": True,
            "snapshot": snapshot,
            "error": None,
            "export": export
        }
    }
