"""Data model and payload loader for the export component."""

import json
import math
from pathlib import Path


def _check_finite(obj):
    """Recursively check that no NaN or Infinity values exist in the parsed JSON structure.

    Raises ValueError if any non-finite float is found.
    """
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("Non-finite number (NaN or Infinity) found in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)


def load_payload(path):
    """Read a UTF-8 JSON file and return the parsed object.

    Only object (dict) or array (list) top-level types are allowed.
    Raises ValueError for:
      - invalid JSON
      - top-level types other than dict or list
      - any NaN / Infinity values nested anywhere
    """
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc

    if not isinstance(data, (dict, list)):
        raise ValueError(
            f"Top-level JSON must be object or array, got {type(data).__name__}"
        )

    _check_finite(data)
    return data
