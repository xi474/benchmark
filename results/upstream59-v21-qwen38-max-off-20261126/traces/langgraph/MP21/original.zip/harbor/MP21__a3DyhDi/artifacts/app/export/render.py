"""Render (file interface) for the export component."""

import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read inputs per contract, run transform, return envelope.

    root: workspace root Path
    contract_path: path to this component's contract.json
    """
    root = Path(root)
    contract_path = Path(contract_path)
    comp_dir = contract_path.parent

    # Ensure both root and component dir are on sys.path
    for p in [str(root), str(comp_dir)]:
        if p not in sys.path:
            sys.path.insert(0, p)

    # Try package import first, fall back to direct import
    try:
        from .model import load_payload
        from .transform import transform
    except ImportError:
        from model import load_payload
        from transform import transform

    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    return result


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    sys.path.insert(0, str(root))
    contract_path = here / "contract.json"
    build_component(root, contract_path)
