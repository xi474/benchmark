"""M3U export transform for the export component."""

from decimal import Decimal, ROUND_HALF_UP


def _sanitize_m3u_line(s):
    """Ensure string has no CR/LF characters for M3U safety."""
    if "\r" in s or "\n" in s:
        raise ValueError("String contains CR or LF, not allowed in M3U")
    return s


def transform(payloads, contract):
    """Perform playlist_m3u operation.

    payloads: list with one element - the playlist_replace result object
              (containing playlist and tracks).
    contract: dict with name, operation, inputs, output.

    Returns {"name": contract["name"], "result": {"m3u": str}}
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError(
            f"Expected {len(contract.get('inputs', []))} payloads, got {len(payloads)}"
        )

    data = payloads[0]

    # The input is the playlist_replace result envelope: {"name": ..., "result": {...}}
    # Per README: "当输入对象键恰为name/result时，仅其result为业务输入"
    if isinstance(data, dict) and set(data.keys()) == {"name", "result"}:
        data = data["result"]

    playlist = data.get("playlist")
    tracks = data.get("tracks")

    if playlist is None:
        raise ValueError("Missing required field: playlist")
    if tracks is None:
        raise ValueError("Missing required field: tracks")

    name = playlist.get("name")
    if name is None:
        raise ValueError("Missing required field: playlist.name")

    # Sanitize playlist name
    _sanitize_m3u_line(str(name))

    lines = []
    lines.append("#EXTM3U")
    lines.append(f"#PLAYLIST:{name}")

    for track in tracks:
        duration = track.get("duration")
        artist = track.get("artist", "")
        title = track.get("title", "")
        path = track.get("path", "")

        if duration is None:
            raise ValueError("Track missing duration")

        # Round duration using Decimal ROUND_HALF_UP
        d = Decimal(str(duration)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        int_seconds = int(d)

        # Sanitize strings
        _sanitize_m3u_line(str(artist))
        _sanitize_m3u_line(str(title))
        _sanitize_m3u_line(str(path))

        lines.append(f"#EXTINF:{int_seconds},{artist} - {title}")
        lines.append(str(path))

    m3u = "\n".join(lines) + "\n"

    return {"name": contract["name"], "result": {"m3u": m3u}}
