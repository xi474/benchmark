"""Generate the final report from core_manifest.json."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    # title is fixed
    title = "播放列表重写、条件查询与 M3U 导出"

    # component_count is number of keys in components
    component_count = len(core["components"])

    # sha256: serialize the full core object with specific settings, no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: list of component names meeting any trigger condition
    attention = set()
    for comp_name, result in core["components"].items():
        if not isinstance(result, dict):
            continue
        # result.blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != "" and val != {} and val != 0 and val is not False:
                # "non-empty" - check if it's a collection or truthy value
                # But we need to be careful: the spec says "非空" which means non-empty
                # For lists/dicts/strings: non-empty means len > 0
                # For other types: just being present and not None might count
                # Let's interpret strictly: if it's a list/dict/str, check len; otherwise if present and not None
                if isinstance(val, (list, dict, str)):
                    if len(val) > 0:
                        attention.add(comp_name)
                elif val is not None:
                    attention.add(comp_name)

    attention = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
