"""Playlist replace transform for the playlist component."""


def transform(payloads, contract):
    """Perform playlist_replace operation.

    payloads: list with one element - the case object containing
              tracks, playlist, replacement, criteria.
    contract: dict with name, operation, inputs, output.

    Returns {"name": contract["name"], "result": {...}}
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError(
            f"Expected {len(contract.get('inputs', []))} payloads, got {len(payloads)}"
        )

    case = payloads[0]

    # Extract fields from input
    tracks = case.get("tracks")
    playlist = case.get("playlist")
    replacement = case.get("replacement")
    # criteria is present but not used in playlist_replace itself

    if tracks is None or playlist is None or replacement is None:
        raise ValueError("Missing required fields: tracks, playlist, replacement")

    if not isinstance(tracks, list):
        raise ValueError("tracks must be a list")
    if not isinstance(playlist, dict):
        raise ValueError("playlist must be an object")
    if not isinstance(replacement, list):
        raise ValueError("replacement must be a list")

    # Build track lookup by id
    track_map = {}
    for t in tracks:
        tid = t.get("id")
        if tid is None:
            raise ValueError("Track missing id")
        if tid in track_map:
            raise ValueError(f"Duplicate track id: {tid}")
        # Validate duration is non-negative finite number
        dur = t.get("duration")
        if dur is None:
            raise ValueError(f"Track {tid} missing duration")
        if isinstance(dur, bool):
            raise ValueError(f"Track {tid} duration must be a number, not bool")
        if not isinstance(dur, (int, float)):
            raise ValueError(f"Track {tid} duration must be a number")
        import math
        if math.isnan(dur) or math.isinf(dur):
            raise ValueError(f"Track {tid} duration must be finite")
        if dur < 0:
            raise ValueError(f"Track {tid} duration must be non-negative")
        track_map[tid] = t

    # Validate replacement IDs exist in track_map
    for rid in replacement:
        if rid not in track_map:
            raise ValueError(f"Replacement references unknown track id: {rid}")

    # Build new playlist
    new_track_ids = list(replacement)  # preserve order, duplicates allowed
    new_track_count = len(new_track_ids)

    # Duration: sum of durations by occurrence count
    total_duration = 0
    for rid in new_track_ids:
        total_duration += track_map[rid]["duration"]

    # Build tracks list in replacement order
    new_tracks = []
    for rid in new_track_ids:
        new_tracks.append(track_map[rid])

    result_playlist = {
        "id": playlist["id"],
        "name": playlist["name"],
        "track_ids": new_track_ids,
        "track_count": new_track_count,
        "duration": total_duration,
    }

    result = {
        "playlist": result_playlist,
        "tracks": new_tracks,
    }

    return {"name": contract["name"], "result": result}
