"""Playlist query transform for the query component."""

import math


def transform(payloads, contract):
    """Perform playlist_query operation.

    payloads: list with one element - the case object containing criteria.
    contract: dict with name, operation, inputs, output.

    Returns {"name": contract["name"], "result": {"sql": ..., "params": ...}}
    """
    if len(payloads) != len(contract.get("inputs", [])):
        raise ValueError(
            f"Expected {len(contract.get('inputs', []))} payloads, got {len(payloads)}"
        )

    case = payloads[0]
    criteria = case.get("criteria")
    if criteria is None:
        raise ValueError("Missing required field: criteria")
    if not isinstance(criteria, dict):
        raise ValueError("criteria must be an object")

    filters = criteria.get("filters")
    limit = criteria.get("limit")

    if filters is None:
        raise ValueError("Missing required field: criteria.filters")
    if limit is None:
        raise ValueError("Missing required field: criteria.limit")

    if not isinstance(filters, list):
        raise ValueError("filters must be a list")

    # Validate limit: int 1..100, not bool
    if isinstance(limit, bool):
        raise ValueError("limit must be an integer, not bool")
    if not isinstance(limit, int):
        raise ValueError("limit must be an integer")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be between 1 and 100")

    # Valid fields and their types
    str_fields = {"id", "name"}
    num_fields = {"track_count", "duration"}
    valid_fields = str_fields | num_fields
    valid_ops = {"eq", "ne", "gt", "ge", "lt", "le"}
    # id/name only support eq/ne
    str_ops = {"eq", "ne"}

    conditions = []
    params = []

    for f in filters:
        if not isinstance(f, dict):
            raise ValueError("Each filter must be an object")

        field = f.get("field")
        op = f.get("op")
        value = f.get("value")

        if field is None or op is None or "value" not in f:
            raise ValueError("Filter missing required fields: field, op, value")

        if field not in valid_fields:
            raise ValueError(f"Invalid filter field: {field}")
        if op not in valid_ops:
            raise ValueError(f"Invalid filter op: {op}")

        # Validate value type based on field
        if field in str_fields:
            if op not in str_ops:
                raise ValueError(f"Field {field} only supports eq/ne, got {op}")
            if not isinstance(value, str):
                raise ValueError(f"Value for field {field} must be a string")
        elif field in num_fields:
            if isinstance(value, bool):
                raise ValueError(f"Value for field {field} must be a number, not bool")
            if not isinstance(value, (int, float)):
                raise ValueError(f"Value for field {field} must be a number")
            if math.isnan(value) or math.isinf(value):
                raise ValueError(f"Value for field {field} must be finite")
            if value < 0:
                raise ValueError(f"Value for field {field} must be non-negative")

        # Map op to SQL operator
        op_map = {
            "eq": "=",
            "ne": "!=",
            "gt": ">",
            "ge": ">=",
            "lt": "<",
            "le": "<=",
        }
        sql_op = op_map[op]
        conditions.append(f"{field} {sql_op} ?")
        params.append(value)

    # Build SQL
    sql = "SELECT id FROM playlists"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)

    result = {
        "sql": sql,
        "params": params,
    }

    return {"name": contract["name"], "result": result}
