"""Orchestrate all components based on file contracts."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("No contracts found")

    # Build dependency graph: each contract's inputs may reference other contract outputs
    # We need topological ordering
    contract_map = {}  # name -> contract_path
    output_to_name = {}  # output path string -> component name
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = cp
        output_to_name[c["output"]] = c["name"]

    # Build adjacency: component A depends on B if A's input is B's output
    deps = {name: set() for name in contract_map}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        for inp in c["inputs"]:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                deps[c["name"]].add(dep_name)

    # Topological sort (Kahn's algorithm)
    in_degree = {name: 0 for name in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            pass  # we count below
    # Recompute in_degree properly
    reverse_deps = {name: set() for name in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            reverse_deps[d].add(name)
            in_degree[name] += 1

    queue = sorted([n for n in contract_map if in_degree[n] == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for dependent in sorted(reverse_deps[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
                queue.sort()

    if len(order) != len(contract_map):
        raise ValueError("Dependency cycle detected")

    # Execute each component via its render.py
    for name in order:
        cp = contract_map[name]
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            raise ValueError(f"No render.py for component {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Component {name} failed with exit code {result.returncode}")

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"integrate.py failed with exit code {result.returncode}")

    # Run final_report.py
    report_py = ROOT / "final_report.py"
    if report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(report_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"final_report.py failed with exit code {result.returncode}")


if __name__ == "__main__":
    main()
