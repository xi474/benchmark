def transform(payloads, contract):
    """Extract language codes from MARC records.
    
    Inputs: [original_input, marc_xml_records_result]
    - original_input has language_codes (valid 3-letter lowercase codes)
    - marc_xml_records_result has records with controls and fields
    
    Output: {records: [{id, languages: [sorted unique valid codes]}]}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    orig_input = payloads[0]
    reader_result = payloads[1]
    
    if not isinstance(orig_input, dict):
        raise ValueError("original input must be object")
    if 'language_codes' not in orig_input:
        raise ValueError("missing language_codes")
    
    valid_codes = set(orig_input['language_codes'])
    # Validate: each must be exactly 3 lowercase letters
    for code in valid_codes:
        if not isinstance(code, str) or len(code) != 3 or not code.isalpha() or not code.islower():
            raise ValueError(f"invalid language code: {code}")
    
    # Extract reader data
    if 'name' in reader_result and 'result' in reader_result and len(reader_result) == 2:
        data = reader_result['result']
    else:
        data = reader_result
    
    records_in = data.get('records', [])
    
    out_records = []
    
    for rec in records_in:
        rec_id = rec['id']
        controls = rec.get('controls', {})
        fields = rec.get('fields', [])
        
        langs = set()
        
        # Check 008 control field
        if '008' in controls:
            val = controls['008']
            if len(val) >= 38:
                code_008 = val[35:38]
                if code_008 in valid_codes:
                    langs.add(code_008)
        
        # Check 041 datafields
        for f in fields:
            if f['tag'] == '041':
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'd', 'h'):
                        raw = sf['value'].strip()
                        if len(raw) == 0:
                            continue
                        if len(raw) % 3 != 0:
                            raise ValueError(f"041 subfield length not multiple of 3: '{raw}'")
                        # Split into 3-char chunks
                        for i in range(0, len(raw), 3):
                            chunk = raw[i:i+3]
                            if chunk in valid_codes:
                                langs.add(chunk)
        
        out_records.append({
            'id': rec_id,
            'languages': sorted(langs)
        })
    
    # Sort by id
    out_records.sort(key=lambda r: r['id'])
    
    return {
        'name': contract['name'],
        'result': {'records': out_records}
    }
