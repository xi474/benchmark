import re


def _clean_name(text):
    """Collapse internal whitespace, strip leading/trailing spaces/slashes/commas/colons/semicolons.
    Preserve periods."""
    # Collapse internal whitespace
    text = re.sub(r'\s+', ' ', text)
    # Strip leading/trailing: space, slash, comma, colon, semicolon
    text = text.strip(' \t\n\r/,;:')
    return text


def _parse_link_code(code_value):
    """Parse a $6 value like '880-01' or '100-01/r'.
    Returns (tag, nn) or None if invalid format."""
    if not isinstance(code_value, str):
        return None
    # Remove /suffix if present
    base = code_value.split('/')[0]
    parts = base.split('-')
    if len(parts) != 2:
        return None
    tag = parts[0]
    nn = parts[1]
    if not tag.isdigit() or len(tag) != 3:
        return None
    if not nn.isdigit():
        return None
    return (tag, nn)


def transform(payloads, contract):
    """Extract authors and titles with alternate script links from MARC records.
    
    Input: marc_xml_records result {records: [...]}
    Output: {records: [{id, authors: [{name, alternates: [sorted unique]}], titles: [{title, alternates}]}]}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    reader_result = payloads[0]
    if not isinstance(reader_result, dict):
        raise ValueError("input must be object")
    
    # Extract the actual data - if it has name/result structure, use result
    if 'name' in reader_result and 'result' in reader_result and len(reader_result) == 2:
        data = reader_result['result']
    else:
        data = reader_result
    
    records_in = data.get('records', [])
    
    out_records = []
    
    for rec in records_in:
        rec_id = rec['id']
        fields = rec.get('fields', [])
        
        # Build index of 880 fields by their link code
        # 880 $6 should be like "100-01" or "245-01" (with optional /suffix)
        alt_index = {}  # (target_tag, nn) -> list of subfield values
        for f in fields:
            if f['tag'] == '880':
                link_code = None
                for sf in f['subfields']:
                    if sf['code'] == '6':
                        link_code = sf['value']
                        break
                if link_code is None:
                    continue
                parsed = _parse_link_code(link_code)
                if parsed is None:
                    continue
                target_tag, nn = parsed
                # Only accept 100 or 245 as targets
                if target_tag not in ('100', '245'):
                    continue
                # Collect $a and $b from this 880
                parts = []
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'b'):
                        parts.append(sf['value'])
                alt_text = _clean_name(' '.join(parts))
                key = (target_tag, nn)
                if key not in alt_index:
                    alt_index[key] = []
                alt_index[key].append(alt_text)
        
        # Process 100 fields for authors
        authors = []
        for f in fields:
            if f['tag'] == '100':
                # Get link code
                link_code = None
                for sf in f['subfields']:
                    if sf['code'] == '6':
                        link_code = sf['value']
                        break
                
                # Build name from $a/$b
                parts = []
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'b'):
                        parts.append(sf['value'])
                name = _clean_name(' '.join(parts))
                
                # Find alternates
                alternates = []
                if link_code is not None:
                    parsed = _parse_link_code(link_code)
                    if parsed is not None:
                        src_tag, nn = parsed
                        if src_tag == '880':
                            # This 100's $6 points to an 880
                            key = ('100', nn)
                            if key in alt_index:
                                alternates = list(alt_index[key])
                
                # Deduplicate and sort alternates
                alternates = sorted(set(alternates))
                authors.append({'name': name, 'alternates': alternates})
        
        # Process 245 fields for titles
        titles = []
        for f in fields:
            if f['tag'] == '245':
                # Get link code
                link_code = None
                for sf in f['subfields']:
                    if sf['code'] == '6':
                        link_code = sf['value']
                        break
                
                # Build title from $a/$b
                parts = []
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'b'):
                        parts.append(sf['value'])
                title = _clean_name(' '.join(parts))
                
                # Find alternates
                alternates = []
                if link_code is not None:
                    parsed = _parse_link_code(link_code)
                    if parsed is not None:
                        src_tag, nn = parsed
                        if src_tag == '880':
                            key = ('245', nn)
                            if key in alt_index:
                                alternates = list(alt_index[key])
                
                alternates = sorted(set(alternates))
                titles.append({'title': title, 'alternates': alternates})
        
        out_records.append({
            'id': rec_id,
            'authors': authors,
            'titles': titles
        })
    
    # Sort by id
    out_records.sort(key=lambda r: r['id'])
    
    return {
        'name': contract['name'],
        'result': {'records': out_records}
    }
