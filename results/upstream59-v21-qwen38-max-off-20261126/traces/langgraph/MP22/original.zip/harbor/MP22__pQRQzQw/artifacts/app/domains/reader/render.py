import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    # Load contract
    from model import load_payload
    contract = load_payload(contract_path)
    
    # Load payloads in order
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    # Transform
    from transform import transform
    result = transform(payloads, contract)
    
    return result


if __name__ == '__main__':
    # CLI mode: write output to contract.output
    here = Path(__file__).resolve().parent
    root = here.parents[1]  # workspace root (domains/../..)
    # Actually, we need to find the workspace root relative to this script
    # The script is at domains/reader/render.py, so root is two levels up
    # But we must support arbitrary cwd
    
    contract_path = here / 'contract.json'
    
    # Determine root: the parent of the directory containing 'domains'
    # Since this file is at <root>/domains/reader/render.py
    root = here.parent.parent
    
    result = build_component(root, contract_path)
    
    # Read contract to get output path
    import json as _json
    contract = _json.loads(contract_path.read_text(encoding='utf-8'))
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        _json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
