import xml.etree.ElementTree as ET


def _strip_ns(tag):
    """Remove namespace from tag if present."""
    if '}' in tag:
        return tag.split('}', 1)[1]
    return tag


def transform(payloads, contract):
    """Parse MARC XML and extract records.
    
    Input: {xml: str, language_codes: [str]}
    Output: {records: [{id, controls: {tag: text}, fields: [{tag, subfields: [{code, value}]}]}]}
    Records sorted by id.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if 'xml' not in data:
        raise ValueError("missing 'xml' field")
    if 'language_codes' not in data:
        raise ValueError("missing 'language_codes' field")
    
    xml_str = data['xml']
    if not isinstance(xml_str, str):
        raise ValueError("xml must be string")
    
    # Check for DOCTYPE/ENTITY
    upper = xml_str.upper()
    if 'DOCTYPE' in upper or 'ENTITY' in upper:
        raise ValueError("DOCTYPE/ENTITY not allowed")
    
    # Parse XML
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError as e:
        raise ValueError(f"invalid XML: {e}") from e
    
    root_tag = _strip_ns(root.tag)
    if root_tag not in ('collection', 'record'):
        raise ValueError(f"root must be collection or record, got {root_tag}")
    
    # Get records
    if root_tag == 'collection':
        record_elements = []
        for child in root:
            if _strip_ns(child.tag) == 'record':
                record_elements.append(child)
            else:
                raise ValueError(f"unknown element in collection: {_strip_ns(child.tag)}")
    else:
        record_elements = [root]
    
    records = []
    seen_ids = set()
    
    for rec_elem in record_elements:
        controls = {}
        fields = []
        rec_id = None
        
        for child in rec_elem:
            ctag = _strip_ns(child.tag)
            
            if ctag == 'controlfield':
                tag = child.get('tag')
                if tag is None:
                    raise ValueError("controlfield missing tag")
                if len(tag) != 3 or not tag.isdigit():
                    raise ValueError(f"controlfield tag must be 3 digits: {tag}")
                if tag in controls:
                    raise ValueError(f"duplicate controlfield tag: {tag}")
                text = child.text or ''
                if tag == '001':
                    if not text.strip():
                        raise ValueError("001 controlfield must be non-empty")
                    rec_id = text
                controls[tag] = text
                
            elif ctag == 'datafield':
                tag = child.get('tag')
                if tag is None:
                    raise ValueError("datafield missing tag")
                if len(tag) != 3 or not tag.isdigit():
                    raise ValueError(f"datafield tag must be 3 digits: {tag}")
                subfields = []
                for sf in child:
                    sftag = _strip_ns(sf.tag)
                    if sftag != 'subfield':
                        raise ValueError(f"unknown element in datafield: {sftag}")
                    code = sf.get('code')
                    if code is None:
                        raise ValueError("subfield missing code")
                    if len(code) != 1 or not code.isalnum():
                        raise ValueError(f"subfield code must be single alnum: {code}")
                    value = sf.text or ''
                    subfields.append({'code': code, 'value': value})
                fields.append({'tag': tag, 'subfields': subfields})
                
            else:
                raise ValueError(f"unknown element in record: {ctag}")
        
        if rec_id is None:
            raise ValueError("record missing 001 controlfield")
        if rec_id in seen_ids:
            raise ValueError(f"duplicate record id: {rec_id}")
        seen_ids.add(rec_id)
        
        records.append({
            'id': rec_id,
            'controls': controls,
            'fields': fields
        })
    
    # Sort by id
    records.sort(key=lambda r: r['id'])
    
    return {
        'name': contract['name'],
        'result': {'records': records}
    }
