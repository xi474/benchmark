import re


# Mapping from MARC tag to subject category
TAG_TO_CATEGORY = {
    '600': 'people',
    '610': 'organizations',
    '611': 'meetings',
    '630': 'works',
    '650': 'topics',
    '651': 'places',
}

SUBJECT_TAGS = set(TAG_TO_CATEGORY.keys())


def _clean_segment(text):
    """Collapse internal whitespace, strip leading/trailing spaces/slashes/commas/colons/semicolons.
    Preserve periods."""
    text = re.sub(r'\s+', ' ', text)
    text = text.strip(' \t\n\r/,;:')
    return text


def transform(payloads, contract):
    """Extract and count subject headings from MARC records.
    
    Input: marc_xml_records result
    Output: {records: [{id, subjects: {people:[], organizations:[], meetings:[], works:[], topics:[], places:[]}}]}
    Each category has [{value, count}] sorted by value.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    reader_result = payloads[0]
    
    # Extract data
    if 'name' in reader_result and 'result' in reader_result and len(reader_result) == 2:
        data = reader_result['result']
    else:
        data = reader_result
    
    records_in = data.get('records', [])
    
    out_records = []
    
    for rec in records_in:
        rec_id = rec['id']
        fields = rec.get('fields', [])
        
        # Count subjects by category and full heading value
        # Key: (category, full_heading) -> count
        counts = {}
        
        for f in fields:
            if f['tag'] not in SUBJECT_TAGS:
                continue
            
            category = TAG_TO_CATEGORY[f['tag']]
            
            # Build main heading from $a/$b
            main_parts = []
            subdivisions = []
            
            for sf in f['subfields']:
                if sf['code'] in ('a', 'b'):
                    main_parts.append(sf['value'])
                elif sf['code'] in ('v', 'x', 'y', 'z'):
                    subdivisions.append(sf['value'])
            
            # Join main parts with space
            main_heading = _clean_segment(' '.join(main_parts))
            
            # Build full heading: main -- subdiv1 -- subdiv2 ...
            segments = [main_heading]
            for sub in subdivisions:
                segments.append(_clean_segment(sub))
            
            full_heading = ' -- '.join(segments)
            
            key = (category, full_heading)
            counts[key] = counts.get(key, 0) + 1
        
        # Build output subjects dict
        subjects = {}
        for cat in ['people', 'organizations', 'meetings', 'works', 'topics', 'places']:
            items = []
            for (c, val), cnt in counts.items():
                if c == cat:
                    items.append({'value': val, 'count': cnt})
            items.sort(key=lambda x: x['value'])
            subjects[cat] = items
        
        out_records.append({
            'id': rec_id,
            'subjects': subjects
        })
    
    # Sort by id
    out_records.sort(key=lambda r: r['id'])
    
    return {
        'name': contract['name'],
        'result': {'records': out_records}
    }
