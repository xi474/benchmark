"""Generate final report from core manifest.

Reads outputs/core_manifest.json, writes outputs/final_report.json with:
- title: 'MARC 作者标题、语言和主题导入'
- component_count: number of components
- sha256: SHA256 hex of canonical JSON serialization of core object
- attention: sorted list of component names with issues
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core.get('components', {})
    component_count = len(components)

    # Compute SHA256 of canonical JSON
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # Check blocked
        if result.get('blocked') is True:
            attention.add(name)
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None:
                # Non-empty check: for lists/dicts/strings, check truthiness
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(name)
                elif val is True:
                    attention.add(name)

    report = {
        'title': 'MARC 作者标题、语言和主题导入',
        'component_count': component_count,
        'sha256': sha256,
        'attention': sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
