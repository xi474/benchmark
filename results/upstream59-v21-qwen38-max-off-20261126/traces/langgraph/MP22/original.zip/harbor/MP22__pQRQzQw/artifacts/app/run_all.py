"""Orchestrate all components based on their contracts.

Execution order follows the DAG:
1. reader (no deps)
2. names (depends on reader)
3. languages (depends on reader + original input)
4. subjects (depends on reader)
5. catalog (depends on names, languages, subjects)
Then run integrate.py to produce core_manifest.json.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts and their dependencies
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts.append((cp, c))

    # Build dependency graph and topological sort
    # Each contract's inputs may reference other contract outputs
    output_to_contract = {}
    for cp, c in contracts:
        output_to_contract[c['output']] = (cp, c)

    # Determine execution order via topological sort
    def get_deps(c):
        deps = []
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp, dep_c = output_to_contract[inp]
                deps.append(dep_c['name'])
        return deps

    # Simple topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(name, cp, c):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        visiting.add(name)
        for dep_name in get_deps(c):
            for dcp, dc in contracts:
                if dc['name'] == dep_name:
                    visit(dep_name, dcp, dc)
                    break
        visiting.remove(name)
        visited.add(name)
        ordered.append((cp, c))

    for cp, c in contracts:
        visit(c['name'], cp, c)

    # Execute each component in order
    for cp, c in ordered:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            raise FileNotFoundError(f"render.py not found for {c['name']}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {c['name']}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
