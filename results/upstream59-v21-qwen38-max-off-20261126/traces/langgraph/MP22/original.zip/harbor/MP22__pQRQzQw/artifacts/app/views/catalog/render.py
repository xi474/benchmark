import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    from model import load_payload
    contract = load_payload(contract_path)
    
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    from transform import transform
    result = transform(payloads, contract)
    
    return result


if __name__ == '__main__':
    here = Path(__file__).resolve().parent
    # views/catalog -> root is two levels up
    root = here.parent.parent
    contract_path = here / 'contract.json'
    
    result = build_component(root, contract_path)
    
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
