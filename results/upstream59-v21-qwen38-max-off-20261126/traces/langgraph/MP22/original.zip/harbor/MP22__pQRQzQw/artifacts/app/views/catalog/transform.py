def transform(payloads, contract):
    """Join names, languages, and subjects into a unified catalog.
    
    Inputs: [names_result, languages_result, subjects_result]
    Output: {records: [{id, authors, titles, languages, subjects}], record_count}
    All three must have identical ID sets.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    
    names_data = payloads[0]
    langs_data = payloads[1]
    subjects_data = payloads[2]
    
    # Extract results
    def extract(d):
        if isinstance(d, dict) and 'name' in d and 'result' in d and len(d) == 2:
            return d['result']
        return d
    
    names = extract(names_data)
    langs = extract(langs_data)
    subjects = extract(subjects_data)
    
    # Build lookup dicts by id
    names_by_id = {r['id']: r for r in names.get('records', [])}
    langs_by_id = {r['id']: r for r in langs.get('records', [])}
    subjects_by_id = {r['id']: r for r in subjects.get('records', [])}
    
    # Check ID sets match
    ids_names = set(names_by_id.keys())
    ids_langs = set(langs_by_id.keys())
    ids_subjects = set(subjects_by_id.keys())
    
    if ids_names != ids_langs or ids_names != ids_subjects:
        raise ValueError("record ID sets do not match across components")
    
    # Check uniqueness within each (already guaranteed by dict construction, but verify counts)
    if len(names_by_id) != len(names.get('records', [])):
        raise ValueError("duplicate IDs in names")
    if len(langs_by_id) != len(langs.get('records', [])):
        raise ValueError("duplicate IDs in languages")
    if len(subjects_by_id) != len(subjects.get('records', [])):
        raise ValueError("duplicate IDs in subjects")
    
    # Join records
    out_records = []
    for rec_id in sorted(ids_names):
        n = names_by_id[rec_id]
        l = langs_by_id[rec_id]
        s = subjects_by_id[rec_id]
        
        out_records.append({
            'id': rec_id,
            'authors': n.get('authors', []),
            'titles': n.get('titles', []),
            'languages': l.get('languages', []),
            'subjects': s.get('subjects', {})
        })
    
    return {
        'name': contract['name'],
        'result': {
            'records': out_records,
            'record_count': len(out_records)
        }
    }
