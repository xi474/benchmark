"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    if not core_path.exists():
        raise ValueError("core_manifest.json not found")

    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core['components']

    # Compute sha256 of the full core object
    # Serialized with specific format: no trailing newline
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue

        # Check blocked
        if result.get('blocked') is True:
            attention.add(comp_name)

        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # "non-empty" - check if it's a non-empty collection or truthy value
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)
                elif val is True:
                    attention.add(comp_name)

    attention_sorted = sorted(attention)

    report = {
        "title": "受目录容量限制的可逆文件重分片",
        "component_count": len(components),
        "sha256": sha,
        "attention": attention_sorted
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    out_path.write_text(text, encoding='utf-8')


if __name__ == '__main__':
    main()
