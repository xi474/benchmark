import json
import math
from pathlib import Path


def _validate_no_nan_inf(obj):
    """Recursively check for NaN/Infinity in any nested structure."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number encountered")
    elif isinstance(obj, dict):
        for v in obj.values():
            _validate_no_nan_inf(v)
    elif isinstance(obj, list):
        for v in obj:
            _validate_no_nan_inf(v)


def load_payload(path):
    """Read UTF-8 JSON from path. Top-level must be object or array.
    Rejects invalid JSON, non-object/array top-level, and any NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _validate_no_nan_inf(data)
    return data
