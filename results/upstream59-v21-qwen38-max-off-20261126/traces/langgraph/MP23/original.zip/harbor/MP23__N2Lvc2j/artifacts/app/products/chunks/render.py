import json
import sys
from pathlib import Path

# Ensure we can import sibling modules
_dir = Path(__file__).resolve().parent
if str(_dir) not in sys.path:
    sys.path.insert(0, str(_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, return wrapped result."""
    root = Path(root).resolve()
    contract_path = Path(contract_path).resolve()
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract['inputs']]
    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with standard formatting."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    path.write_text(text, encoding='utf-8')


if __name__ == '__main__':
    # Determine root and contract path
    # Support arbitrary current directory: contract is next to this script
    script_dir = Path(__file__).resolve().parent
    contract_path = script_dir / 'contract.json'

    # Root is the workspace root (parent of products/)
    root = script_dir.parents[1]

    result = build_component(root, contract_path)

    # Write output
    contract = load_payload(contract_path)
    output_path = root / contract['output']
    _write_json(output_path, result)
