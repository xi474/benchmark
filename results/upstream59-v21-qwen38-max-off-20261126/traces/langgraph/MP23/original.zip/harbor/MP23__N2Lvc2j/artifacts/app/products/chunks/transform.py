import hashlib


def transform(payloads, contract):
    """reshard_chunks: split files into byte-limited chunks."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    # Validate required fields
    if not isinstance(case, dict):
        raise ValueError("input must be object")
    for key in ('files', 'max_file_bytes', 'max_entries'):
        if key not in case:
            raise ValueError(f"missing field: {key}")

    files = case['files']
    max_file_bytes = case['max_file_bytes']
    # max_entries is present but not used in chunks operation

    if not isinstance(files, list):
        raise ValueError("files must be array")
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")

    # Validate each file entry
    paths_seen = set()
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if 'path' not in f or 'hex' not in f:
            raise ValueError("file entry missing path or hex")
        path = f['path']
        hex_str = f['hex']
        if not isinstance(path, str) or not isinstance(hex_str, str):
            raise ValueError("path and hex must be strings")
        if path in paths_seen:
            raise ValueError(f"duplicate path: {path}")
        paths_seen.add(path)
        # Validate hex is valid
        try:
            bytes.fromhex(hex_str)
        except ValueError:
            raise ValueError(f"invalid hex for path {path}")

    # Sort files by path (Python default string sort = lexicographic)
    sorted_files = sorted(files, key=lambda f: f['path'])

    chunks = []
    manifest_files = []
    global_chunk_idx = 0

    for f in sorted_files:
        path = f['path']
        raw = bytes.fromhex(f['hex'])
        size = len(raw)
        sha = hashlib.sha256(raw).hexdigest()
        parts = []

        if size == 0:
            # Empty file: no chunks
            pass
        else:
            offset = 0
            while offset < size:
                end = min(offset + max_file_bytes, size)
                chunk_data = raw[offset:end]
                chunk_name = f"d{global_chunk_idx:06d}.bin"
                chunks.append({
                    "name": chunk_name,
                    "hex": chunk_data.hex()
                })
                parts.append(chunk_name)
                global_chunk_idx += 1
                offset = end

        manifest_files.append({
            "path": path,
            "size": size,
            "sha256": sha,
            "parts": parts
        })

    result = {
        "chunks": chunks,
        "manifest": {
            "files": manifest_files
        }
    }

    return {"name": contract["name"], "result": result}
