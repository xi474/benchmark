import json


def transform(payloads, contract):
    """reshard_layout: arrange chunks into a capacity-limited directory tree."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    chunks_result = payloads[1]

    # Extract needed values from case
    if not isinstance(case, dict):
        raise ValueError("case must be object")
    max_file_bytes = case['max_file_bytes']
    max_entries = case['max_entries']

    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    # Extract chunks result - it may be wrapped in {name, result} or be the result directly
    if isinstance(chunks_result, dict) and 'result' in chunks_result and 'name' in chunks_result:
        chunks_data = chunks_result['result']
    else:
        chunks_data = chunks_result

    if not isinstance(chunks_data, dict):
        raise ValueError("chunks data must be object")

    manifest = chunks_data['manifest']
    data_chunks = chunks_data['chunks']

    # Build a map of chunk name -> hex for data chunks
    chunk_hex_map = {}
    for c in data_chunks:
        chunk_hex_map[c['name']] = c['hex']

    # Serialize manifest as compact canonical JSON (sort_keys, no extra whitespace)
    manifest_json = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    manifest_bytes = manifest_json.encode('utf-8')

    # Split manifest bytes into chunks of max_file_bytes
    meta_chunks = []
    meta_idx = 0
    offset = 0
    while offset < len(manifest_bytes):
        end = min(offset + max_file_bytes, len(manifest_bytes))
        chunk_data = manifest_bytes[offset:end]
        chunk_name = f"m{meta_idx:06d}.bin"
        meta_chunks.append({
            "name": chunk_name,
            "hex": chunk_data.hex()
        })
        meta_idx += 1
        offset = end

    # If manifest is empty (shouldn't happen normally), we still need at least... 
    # Actually if there are no files, manifest could be {"files":[]} which is non-empty JSON

    # Combine all chunks: data chunks + meta chunks
    all_chunks = []
    for c in data_chunks:
        all_chunks.append({"name": c["name"], "hex": c["hex"]})
    for c in meta_chunks:
        all_chunks.append({"name": c["name"], "hex": c["hex"]})

    # Sort by name (lexicographic)
    all_chunks.sort(key=lambda c: c["name"])
    N = len(all_chunks)

    if N == 0:
        # No chunks at all
        return {"name": contract["name"], "result": {
            "tree": [],
            "max_entries": max_entries,
            "max_file_bytes": max_file_bytes
        }}

    # Find minimum h >= 1 such that max_entries^h >= N
    h = 1
    while max_entries ** h < N:
        h += 1

    # Assign each chunk to a path based on its sorted index
    tree = []
    for i, chunk in enumerate(all_chunks):
        # Convert index i to h-digit base-max_entries
        digits = []
        val = i
        for _ in range(h):
            digits.append(val % max_entries)
            val //= max_entries
        digits.reverse()  # most significant first

        # First h-1 digits become directory levels "n<digit>"
        parts = []
        for d in range(h - 1):
            parts.append(f"n{digits[d]}")
        # Last digit is not in path; filename is original chunk name
        parts.append(chunk["name"])
        path = "/".join(parts)

        tree.append({"path": path, "hex": chunk["hex"]})

    # Sort tree by path
    tree.sort(key=lambda e: e["path"])

    result = {
        "tree": tree,
        "max_entries": max_entries,
        "max_file_bytes": max_file_bytes
    }

    return {"name": contract["name"], "result": result}
