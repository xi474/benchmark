import hashlib
import json
import re


def _is_safe_relative_path(p):
    """Check path is safe relative: no absolute, no backslash, no colon, 
    no empty segments, no . or .. segments."""
    if not p or not isinstance(p, str):
        return False
    if p.startswith('/') or '\\' in p or ':' in p:
        return False
    parts = p.split('/')
    for part in parts:
        if part == '' or part == '.' or part == '..':
            return False
    return True


def transform(payloads, contract):
    """reshard_restore: validate layout tree and restore original files."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    layout_data = payloads[0]

    # Handle wrapped result
    if isinstance(layout_data, dict) and 'result' in layout_data and 'name' in layout_data:
        layout = layout_data['result']
    else:
        layout = layout_data

    if not isinstance(layout, dict):
        raise ValueError("layout must be object")

    for key in ('tree', 'max_entries', 'max_file_bytes'):
        if key not in layout:
            raise ValueError(f"missing field: {key}")

    tree = layout['tree']
    max_entries = layout['max_entries']
    max_file_bytes = layout['max_file_bytes']

    if not isinstance(tree, list):
        raise ValueError("tree must be array")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")

    # Validate each tree entry
    basename_pattern_d = re.compile(r'^d(\d+)\.bin$')
    basename_pattern_m = re.compile(r'^m(\d+)\.bin$')

    all_basenames = set()
    d_chunks = {}  # name -> hex
    m_chunks = {}  # name -> hex

    # Track directory contents for max_entries validation
    dir_contents = {}  # dir_path -> set of direct children names

    for entry in tree:
        if not isinstance(entry, dict):
            raise ValueError("tree entry must be object")
        if 'path' not in entry or 'hex' not in entry:
            raise ValueError("tree entry missing path or hex")

        path = entry['path']
        hex_str = entry['hex']

        if not isinstance(path, str) or not isinstance(hex_str, str):
            raise ValueError("path and hex must be strings")

        if not _is_safe_relative_path(path):
            raise ValueError(f"unsafe path: {path}")

        # Check file size
        raw = bytes.fromhex(hex_str)
        if len(raw) > max_file_bytes:
            raise ValueError(f"file exceeds max_file_bytes: {path}")

        basename = path.split('/')[-1]

        # Check basename uniqueness
        if basename in all_basenames:
            raise ValueError(f"duplicate basename: {basename}")
        all_basenames.add(basename)

        # Validate basename format
        dm = basename_pattern_d.match(basename)
        mm = basename_pattern_m.match(basename)
        if not dm and not mm:
            raise ValueError(f"invalid basename format: {basename}")

        if dm:
            d_chunks[basename] = hex_str
        else:
            m_chunks[basename] = hex_str

        # Track directory structure
        parts = path.split('/')
        if len(parts) > 1:
            dir_path = '/'.join(parts[:-1])
        else:
            dir_path = ''

        if dir_path not in dir_contents:
            dir_contents[dir_path] = set()
        dir_contents[dir_path].add(basename)

        # Also track intermediate directories as entries in their parent
        for i in range(1, len(parts) - 1):
            parent = '/'.join(parts[:i])
            child_dir = parts[i]
            if parent not in dir_contents:
                dir_contents[parent] = set()
            dir_contents[parent].add(child_dir)

        # Root level
        if len(parts) > 1:
            root_child = parts[0]
            if '' not in dir_contents:
                dir_contents[''] = set()
            dir_contents[''].add(root_child)

    # Validate max_entries per directory
    for dir_path, children in dir_contents.items():
        if len(children) > max_entries:
            raise ValueError(f"directory {dir_path!r} has {len(children)} entries > max_entries={max_entries}")

    # Validate m chunks are consecutively numbered from 0
    m_indices = []
    for name in m_chunks:
        mm = basename_pattern_m.match(name)
        if mm:
            m_indices.append(int(mm.group(1)))
    m_indices.sort()
    for expected, actual in enumerate(m_indices):
        if expected != actual:
            raise ValueError(f"m chunks not consecutive: expected m{expected:06d}.bin, got m{actual:06d}.bin")

    # Concatenate m chunks in order to get manifest JSON
    manifest_bytes = b''
    for idx in range(len(m_indices)):
        name = f"m{idx:06d}.bin"
        manifest_bytes += bytes.fromhex(m_chunks[name])

    # Parse manifest
    try:
        manifest = json.loads(manifest_bytes.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise ValueError(f"invalid manifest JSON: {e}")

    if not isinstance(manifest, dict) or 'files' not in manifest:
        raise ValueError("manifest must have 'files' field")

    # Restore files according to manifest
    d_referenced = set()
    restored_files = []
    total_bytes = 0

    for finfo in manifest['files']:
        if not isinstance(finfo, dict):
            raise ValueError("manifest file entry must be object")
        for key in ('path', 'size', 'sha256', 'parts'):
            if key not in finfo:
                raise ValueError(f"manifest file entry missing: {key}")

        orig_path = finfo['path']
        expected_size = finfo['size']
        expected_sha = finfo['sha256']
        parts = finfo['parts']

        if not isinstance(orig_path, str) or not _is_safe_relative_path(orig_path):
            raise ValueError(f"unsafe original path: {orig_path}")
        if not isinstance(expected_size, int) or isinstance(expected_size, bool):
            raise ValueError("size must be int")
        if not isinstance(expected_sha, str):
            raise ValueError("sha256 must be string")
        if not isinstance(parts, list):
            raise ValueError("parts must be array")

        # Reassemble file from d chunks
        file_bytes = b''
        for part_name in parts:
            if part_name not in d_chunks:
                raise ValueError(f"missing data chunk: {part_name}")
            if part_name in d_referenced:
                raise ValueError(f"duplicate reference to chunk: {part_name}")
            d_referenced.add(part_name)
            file_bytes += bytes.fromhex(d_chunks[part_name])

        # Verify size
        if len(file_bytes) != expected_size:
            raise ValueError(f"size mismatch for {orig_path}: expected {expected_size}, got {len(file_bytes)}")

        # Verify sha256
        actual_sha = hashlib.sha256(file_bytes).hexdigest()
        if actual_sha != expected_sha:
            raise ValueError(f"sha256 mismatch for {orig_path}")

        restored_files.append({
            "path": orig_path,
            "hex": file_bytes.hex()
        })
        total_bytes += len(file_bytes)

    # Check all d chunks were referenced
    unreferenced = set(d_chunks.keys()) - d_referenced
    if unreferenced:
        raise ValueError(f"unreferenced data chunks: {sorted(unreferenced)}")

    # Sort by path
    restored_files.sort(key=lambda f: f['path'])

    result = {
        "files": restored_files,
        "total_bytes": total_bytes
    }

    return {"name": contract["name"], "result": result}
