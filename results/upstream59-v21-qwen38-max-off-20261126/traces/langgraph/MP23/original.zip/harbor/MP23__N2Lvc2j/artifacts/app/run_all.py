"""Run all components in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph based on input paths
    # A component depends on another if one of its inputs is an output of that component
    contract_map = {}  # name -> contract_path
    output_to_name = {}  # output_rel -> name

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = cp
        output_to_name[c['output']] = c['name']

    # Topological sort
    deps = {}  # name -> set of dependency names
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        deps[name] = set()
        for inp in c['inputs']:
            if inp in output_to_name:
                deps[name].add(output_to_name[inp])

    # Kahn's algorithm
    order = []
    remaining = dict(deps)
    while remaining:
        ready = [n for n, d in remaining.items() if not d]
        if not ready:
            raise ValueError("circular dependency detected")
        ready.sort()  # deterministic order
        for n in ready:
            order.append(n)
            del remaining[n]
        for n in remaining:
            remaining[n] -= set(ready)

    # Execute each component in order
    for name in order:
        cp = contract_map[name]
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            raise ValueError(f"render.py not found for {name}")

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED: {name}", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: integrate", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("FAILED: final_report", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
