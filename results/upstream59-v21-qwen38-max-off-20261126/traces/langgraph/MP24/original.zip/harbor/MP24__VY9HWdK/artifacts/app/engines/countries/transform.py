def transform(payloads, contract):
    """For each professor, collect all unique countries from their departments.
    Return {"name": contract["name"], "result": {"countries": {prof_id: [sorted unique countries]}}}"""
    case = payloads[0]

    departments = case['departments']
    professors = case['professors']

    # Build dept_id -> country mapping
    dept_country = {}
    for d in departments:
        dept_country[d['id']] = d['country']

    # For each professor, collect unique countries
    countries = {}
    for prof in professors:
        prof_countries = set()
        for dept_id in prof['departments']:
            c = dept_country.get(dept_id)
            if c is not None:
                prof_countries.add(c)
        countries[prof['id']] = sorted(prof_countries)

    return {
        "name": contract["name"],
        "result": {
            "countries": countries
        }
    }
