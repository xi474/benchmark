import json
from pathlib import Path
import sys

# Add component dir to path for imports
_component_dir = str(Path(__file__).resolve().parent)
if _component_dir not in sys.path:
    sys.path.insert(0, _component_dir)

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs from root, call transform, return envelope.
    Also writes output to contract.output."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

    return result


if __name__ == "__main__":
    # When run as CLI, determine root and contract path
    here = Path(__file__).resolve().parent
    root = here.parents[1]  # workspace root
    contract_path = here / 'contract.json'
    build_component(root, contract_path)
