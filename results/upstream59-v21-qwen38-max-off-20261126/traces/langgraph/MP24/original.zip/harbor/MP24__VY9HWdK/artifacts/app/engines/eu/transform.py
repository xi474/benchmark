def transform(payloads, contract):
    """Filter professors where at least one department's country is in the EU list.
    Return {"name": contract["name"], "result": {"ids": [sorted professor IDs]}}"""
    case = payloads[0]

    departments = case['departments']
    professors = case['professors']
    eu_set = set(case['eu'])

    # Build dept_id -> country mapping
    dept_country = {}
    for d in departments:
        dept_country[d['id']] = d['country']

    # Filter professors: at least one department country in EU
    qualified_ids = []
    for prof in professors:
        prof_depts = set(prof['departments'])  # deduplicate
        for dept_id in prof_depts:
            if dept_country.get(dept_id) in eu_set:
                qualified_ids.append(prof['id'])
                break

    qualified_ids.sort()

    return {
        "name": contract["name"],
        "result": {
            "ids": qualified_ids
        }
    }
