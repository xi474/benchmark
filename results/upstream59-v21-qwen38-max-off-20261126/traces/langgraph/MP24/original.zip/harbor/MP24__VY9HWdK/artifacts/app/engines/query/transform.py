def transform(payloads, contract):
    """Query: EU-qualified professors with at least one department having >10 active students.
    
    Inputs (in order per contract):
      0: case.json (original input)
      1: eu.json (eu_professors result)
      2: students.json (department_students result)
      3: countries.json (employment_countries result)
    
    Return {"name": contract["name"], "result": {"professors": [...]}}
    Each professor: {id, countries: [all employment countries sorted], eligible_departments: [depts with >10 students sorted]}
    Sorted by id.
    """
    case = payloads[0]
    eu_result = payloads[1]
    students_result = payloads[2]
    countries_result = payloads[3]

    # Extract data from upstream results
    # eu_result has structure {"name": ..., "result": {"ids": [...]}}
    # But per README: "当输入对象键恰为name/result时，仅其result为业务输入"
    # So payloads may already be unwrapped or may need unwrapping
    
    def _unwrap(obj):
        """If obj is a dict with exactly keys 'name' and 'result', return result; else return obj."""
        if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
            return obj['result']
        return obj

    eu_data = _unwrap(eu_result)
    students_data = _unwrap(students_result)
    countries_data = _unwrap(countries_result)

    eu_ids = set(eu_data['ids'])
    dept_counts = students_data['counts']
    prof_countries = countries_data['countries']

    departments = case['departments']
    professors = case['professors']

    # Build dept_id -> country mapping for reference
    # (not needed here since we use upstream results)

    result_professors = []
    for prof in professors:
        pid = prof['id']
        
        # Must be EU-qualified
        if pid not in eu_ids:
            continue
        
        # Find eligible departments (count > 10)
        eligible_depts = []
        for dept_id in set(prof['departments']):
            count = dept_counts.get(dept_id, 0)
            if count > 10:
                eligible_depts.append(dept_id)
        
        # Must have at least one eligible department
        if not eligible_depts:
            continue
        
        eligible_depts.sort()
        
        result_professors.append({
            "id": pid,
            "countries": prof_countries.get(pid, []),
            "eligible_departments": eligible_depts
        })
    
    # Sort by id
    result_professors.sort(key=lambda x: x['id'])

    return {
        "name": contract["name"],
        "result": {
            "professors": result_professors
        }
    }
