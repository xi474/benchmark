def transform(payloads, contract):
    """Count active students per department.
    Active: start <= as_of AND (end is null OR as_of < end).
    DISTINCT by student.id per department.
    Return {"name": contract["name"], "result": {"counts": {dept_id: count}}}"""
    case = payloads[0]

    departments = case['departments']
    students = case['students']
    as_of = case['as_of']

    # Initialize counts for all departments
    dept_students = {}
    for d in departments:
        dept_students[d['id']] = set()

    # Count active students per department
    for student in students:
        sid = student['id']
        for enrolment in student['enrolments']:
            dept_id = enrolment['department']
            start = enrolment['start']
            end = enrolment['end']

            # Check active: start <= as_of AND (end is null OR as_of < end)
            if start <= as_of and (end is None or as_of < end):
                if dept_id in dept_students:
                    dept_students[dept_id].add(sid)

    # Convert sets to counts
    counts = {}
    for dept_id, sids in dept_students.items():
        counts[dept_id] = len(sids)

    return {
        "name": contract["name"],
        "result": {
            "counts": counts
        }
    }
