"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    # title
    title = '大学任职、在读人数与国家集合查询'

    # component_count
    component_count = len(core['components'])

    # sha256: serialize the complete core object (including outer "components")
    # with json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)
    # then encode to utf-8 (no trailing newline), compute SHA256 lowercase hex
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: components where any of these conditions hold:
    # - result.blocked is explicitly true
    # - complete/checkout/committed/ok is explicitly false
    # - unavailable/missing/conflicts/unreachable is non-empty
    # Fields that don't exist don't trigger; false vs 0/null distinction matters
    attention = set()
    for comp_name, comp_result in core['components'].items():
        if not isinstance(comp_result, dict):
            continue
        
        # Check blocked
        if comp_result.get('blocked') is True:
            attention.add(comp_name)
        
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            val = comp_result.get(key)
            if val is False:
                attention.add(comp_name)
        
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = comp_result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0:
                # Non-empty check: list/dict/string with content, or truthy value
                # But we need "non-empty" which means: if it's a list/dict, len > 0; 
                # if string, len > 0; otherwise if it exists and is not None/empty
                if isinstance(val, (list, dict, str)):
                    if len(val) > 0:
                        attention.add(comp_name)
                elif val:  # other truthy values
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
