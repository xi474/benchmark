"""Orchestration script: execute all components in dependency order."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("No contracts found")

    # Build dependency graph from contract inputs
    # Each contract's inputs may reference outputs of other contracts
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = {'path': cp, 'contract': c}

    # Topological sort based on input dependencies
    # A component depends on another if any of its inputs is an output of that component
    output_to_component = {}
    for name, info in contract_map.items():
        out_path = info['contract']['output']
        output_to_component[out_path] = name

    # Build adjacency: component -> set of components it depends on
    deps = {}
    for name, info in contract_map.items():
        deps[name] = set()
        for inp in info['contract']['inputs']:
            if inp in output_to_component:
                dep_name = output_to_component[inp]
                if dep_name != name:
                    deps[name].add(dep_name)

    # Topological sort (Kahn's algorithm)
    in_degree = {name: 0 for name in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            in_degree[name] += 1  # This is wrong direction; fix below

    # Recompute: in_degree[x] = number of components that x depends on... 
    # Actually for topo sort we need: in_degree[x] = number of predecessors
    # Let's use a simpler approach: repeatedly pick nodes with no unresolved deps
    resolved = set()
    order = []
    remaining = set(contract_map.keys())

    while remaining:
        # Find components whose all deps are resolved
        ready = set()
        for name in remaining:
            if deps[name].issubset(resolved):
                ready.add(name)
        
        if not ready:
            raise ValueError(f"Circular dependency detected among: {remaining}")
        
        # Sort ready components for deterministic order
        for name in sorted(ready):
            order.append(name)
            resolved.add(name)
            remaining.remove(name)

    # Execute components in order
    for name in order:
        info = contract_map[name]
        render_py = info['path'].parent / 'render.py'
        if not render_py.exists():
            raise ValueError(f"render.py not found for component {name}")
        
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print("integrate.py failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if result.returncode != 0:
        print("final_report.py failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
