import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON file; only object/array top-level allowed.
    Raises ValueError on invalid JSON, non-object/array top-level, or NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text, parse_constant=lambda c: (_ for _ in ()).throw(ValueError(f"non-finite constant: {c}")))
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")
    return data
