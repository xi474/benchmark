import json
from pathlib import Path
import sys

# Add component dir to path for local imports
_component_dir = str(Path(__file__).resolve().parent)
if _component_dir not in sys.path:
    sys.path.insert(0, _component_dir)

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    
    result = transform(payloads, contract)
    return result


def _write_json(path, data):
    """Write JSON with standard formatting."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    p.write_text(text + '\n', encoding='utf-8')


if __name__ == "__main__":
    contract_path = Path(__file__).resolve().parent / 'contract.json'
    root = contract_path.resolve().parents[2]
    
    result = build_component(root, contract_path)
    
    contract = load_payload(contract_path)
    output_path = root / contract['output']
    _write_json(output_path, result)
