import re


def _parse_amount(raw):
    """Parse an amount string: optional 'USD' prefix, optional thousands separators,
    must have exactly 2 decimal places, non-negative. Returns normalized string with 2 decimals.
    Raises ValueError on invalid format."""
    s = raw.strip()
    
    # Remove optional USD prefix (case-insensitive)
    if s.upper().startswith('USD'):
        s = s[3:].strip()
    
    # Validate format: digits with optional comma thousands separators, then . and exactly 2 digits
    # Pattern: optional digits with commas, then dot, then exactly 2 digits
    # e.g., 1,200.50 or 1200.50 or 0.00
    pattern = r'^(\d{1,3}(?:,\d{3})*|\d+)\.(\d{2})$'
    m = re.match(pattern, s)
    if not m:
        raise ValueError(f"invalid amount format: {raw!r}")
    
    integer_part = m.group(1).replace(',', '')
    decimal_part = m.group(2)
    
    # Check non-negative (no minus sign allowed since pattern doesn't include it)
    value_str = integer_part + '.' + decimal_part
    
    return value_str


def transform(payloads, contract):
    """Extract Total/Amount Due/VAT from document text lines.
    
    payloads[0] = {documents: [{id, filename, text}]}
    Returns {"name": contract["name"], "result": {"amounts": {id: {total, vat}}}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    data = payloads[0]
    if not isinstance(data, dict) or 'documents' not in data:
        raise ValueError("input must be object with 'documents' key")
    
    documents = data['documents']
    if not isinstance(documents, list):
        raise ValueError("'documents' must be a list")
    
    # Check unique IDs
    ids = [doc['id'] for doc in documents]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate document IDs")
    
    amounts = {}
    for doc in documents:
        doc_id = doc['id']
        text = doc['text']
        
        total_val = None
        amount_due_val = None
        vat_val = None
        
        has_total = False
        has_amount_due = False
        has_vat = False
        
        for line in text.split('\n'):
            stripped = line.strip()
            lower = stripped.lower()
            
            # Match "Total: <amount>" (case-insensitive, whole line match for label)
            m = re.match(r'^total\s*:\s*(.+)$', stripped, re.IGNORECASE)
            if m:
                if has_total:
                    raise ValueError(f"duplicate Total for document {doc_id}")
                has_total = True
                try:
                    total_val = _parse_amount(m.group(1))
                except ValueError:
                    raise ValueError(f"invalid Total amount in document {doc_id}: {m.group(1)!r}")
            
            # Match "Amount Due: <amount>"
            m = re.match(r'^amount\s+due\s*:\s*(.+)$', stripped, re.IGNORECASE)
            if m:
                if has_amount_due:
                    raise ValueError(f"duplicate Amount Due for document {doc_id}")
                has_amount_due = True
                try:
                    amount_due_val = _parse_amount(m.group(1))
                except ValueError:
                    raise ValueError(f"invalid Amount Due amount in document {doc_id}: {m.group(1)!r}")
            
            # Match "VAT: <amount>"
            m = re.match(r'^vat\s*:\s*(.+)$', stripped, re.IGNORECASE)
            if m:
                if has_vat:
                    raise ValueError(f"duplicate VAT for document {doc_id}")
                has_vat = True
                try:
                    vat_val = _parse_amount(m.group(1))
                except ValueError:
                    raise ValueError(f"invalid VAT amount in document {doc_id}: {m.group(1)!r}")
        
        # Total takes priority over Amount Due
        if has_total:
            final_total = total_val
        elif has_amount_due:
            final_total = amount_due_val
        else:
            final_total = None
        
        # VAT defaults to "0.00" if not present
        final_vat = vat_val if has_vat else "0.00"
        
        amounts[doc_id] = {"total": final_total, "vat": final_vat}
    
    return {"name": contract["name"], "result": {"amounts": amounts}}
