import re


def transform(payloads, contract):
    """Classify documents by case-insensitive word matching.
    
    payloads[0] = {documents: [{id, filename, text}]}
    Returns {"name": contract["name"], "result": {"classes": {id: category}}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    data = payloads[0]
    if not isinstance(data, dict) or 'documents' not in data:
        raise ValueError("input must be object with 'documents' key")
    
    documents = data['documents']
    if not isinstance(documents, list):
        raise ValueError("'documents' must be a list")
    
    # Check unique IDs
    ids = [doc['id'] for doc in documents]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate document IDs")
    
    classes = {}
    for doc in documents:
        doc_id = doc['id']
        text = doc['text']
        
        # Extract words (case-insensitive)
        words = set(re.findall(r'[a-zA-Z]+', text.lower()))
        
        if 'invoice' in words:
            category = 'invoice'
        elif 'receipt' in words:
            category = 'receipt'
        else:
            category = 'other'
        
        classes[doc_id] = category
    
    return {"name": contract["name"], "result": {"classes": classes}}
