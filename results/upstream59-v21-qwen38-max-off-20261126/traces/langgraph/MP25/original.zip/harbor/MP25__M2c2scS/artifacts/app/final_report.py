"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    # title
    title = '文本票据分类、金额提取与归档汇总'

    # component_count
    component_count = len(core['components'])

    # sha256: serialize the full core object (including outer "components" key)
    # with specific formatting, no trailing newline
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: list of component names meeting any condition
    attention = set()
    for comp_name, comp_result in core['components'].items():
        if not isinstance(comp_result, dict):
            continue

        # result.blocked explicitly true
        if comp_result.get('blocked') is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in comp_result and comp_result[key] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = comp_result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0 and val is not False:
                # "non-empty" - check if it's a non-empty collection or truthy value
                # But we need to be careful: the spec says "non-empty"
                # For lists/dicts/strings: non-empty means len > 0
                # For other types: if present and not None, it counts
                if isinstance(val, (list, dict, str)):
                    if len(val) > 0:
                        attention.add(comp_name)
                elif val is not None:
                    # Non-collection, non-None value present
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
