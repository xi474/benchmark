"""Orchestrate all components based on their contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency order: components whose inputs depend on other outputs
    # must run after those components. Simple topological sort.
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = {'path': cp, 'contract': c}

    # Determine execution order via topological sort
    # A component depends on another if any of its inputs is an output of that component
    output_to_name = {}
    for name, info in contract_map.items():
        out = info['contract']['output']
        output_to_name[out] = name

    deps = {name: set() for name in contract_map}
    for name, info in contract_map.items():
        for inp in info['contract']['inputs']:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                deps[name].add(dep_name)

    # Topological sort (Kahn's algorithm)
    in_degree = {name: len(d) for name, d in deps.items()}
    queue = [name for name, deg in in_degree.items() if deg == 0]
    order = []
    while queue:
        queue.sort()  # deterministic order
        node = queue.pop(0)
        order.append(node)
        for name, d in deps.items():
            if node in d:
                d.remove(node)
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)

    if len(order) != len(contract_map):
        raise ValueError("dependency cycle detected")

    # Execute each component in order
    for name in order:
        info = contract_map[name]
        render_py = info['path'].parent / 'render.py'
        if not render_py.is_file():
            raise ValueError(f"render.py not found for component {name}")

        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
