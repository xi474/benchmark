import csv
import io


def _is_safe_path_segment(s):
    """Check if string is a safe single path segment."""
    if not s or not isinstance(s, str):
        return False
    # No absolute paths, backslashes, colons, empty segments, . or ..
    if '/' in s or '\\' in s or ':' in s:
        return False
    if s in ('.', '..'):
        return False
    if not s.strip():
        return False
    return True


def transform(payloads, contract):
    """Build archive summary from documents, classification, and amounts.
    
    payloads[0] = {documents: [{id, filename, text}]}
    payloads[1] = {"name": "classification", "result": {"classes": {id: category}}}
    payloads[2] = {"name": "amounts", "result": {"amounts": {id: {total, vat}}}}
    
    Returns {"name": contract["name"], "result": {...}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"expected {len(contract['inputs'])} payloads, got {len(payloads)}")
    
    docs_data = payloads[0]
    class_data = payloads[1]
    amounts_data = payloads[2]
    
    # Extract business data - when input has name/result keys, use result
    if isinstance(class_data, dict) and set(class_data.keys()) == {'name', 'result'}:
        classes = class_data['result']['classes']
    else:
        classes = class_data.get('classes', class_data)
    
    if isinstance(amounts_data, dict) and set(amounts_data.keys()) == {'name', 'result'}:
        amounts = amounts_data['result']['amounts']
    else:
        amounts = amounts_data.get('amounts', amounts_data)
    
    if not isinstance(docs_data, dict) or 'documents' not in docs_data:
        raise ValueError("first input must be object with 'documents' key")
    
    documents = docs_data['documents']
    
    archives = []
    rows = []
    
    for doc in documents:
        doc_id = doc['id']
        filename = doc['filename']
        text = doc['text']
        
        kind = classes[doc_id]
        amt_info = amounts[doc_id]
        total = amt_info['total']
        vat = amt_info['vat']
        
        # Validate: invoice/receipt must have total
        if kind in ('invoice', 'receipt') and total is None:
            raise ValueError(f"document {doc_id} classified as {kind} but has no total")
        
        # Validate id is safe single path segment
        if not _is_safe_path_segment(doc_id):
            raise ValueError(f"unsafe id path segment: {doc_id!r}")
        
        # Archive path: classified/<category>/<id>/<original_filename>
        archive_path = f"classified/{kind}/{doc_id}/{filename}"
        
        # Hex of text UTF-8 bytes
        text_hex = text.encode('utf-8').hex()
        
        archives.append({"path": archive_path, "hex": text_hex})
        rows.append({
            "id": doc_id,
            "filename": filename,
            "kind": kind,
            "total": total if total is not None else "",
            "vat": vat
        })
    
    # Sort archives by path (Python default string sort = lexicographic)
    archives.sort(key=lambda x: x['path'])
    
    # Sort rows by id
    rows.sort(key=lambda x: x['id'])
    
    # Build CSV using standard csv.writer with LF line endings
    csv_buf = io.StringIO()
    writer = csv.writer(csv_buf, lineterminator='\n')
    writer.writerow(['id', 'filename', 'kind', 'total', 'vat'])
    for row in rows:
        writer.writerow([row['id'], row['filename'], row['kind'], row['total'], row['vat']])
    csv_str = csv_buf.getvalue()
    
    # Compute totals: sum of total for invoice and receipt separately
    invoice_total = 0
    receipt_total = 0
    
    for doc in documents:
        doc_id = doc['id']
        kind = classes[doc_id]
        total = amounts[doc_id]['total']
        
        if total is not None:
            # Parse the amount string to Decimal-like value using integer arithmetic
            # to avoid float issues
            parts = total.split('.')
            int_part = int(parts[0])
            dec_part = int(parts[1])
            cents = int_part * 100 + dec_part
            
            if kind == 'invoice':
                invoice_total += cents
            elif kind == 'receipt':
                receipt_total += cents
    
    def _cents_to_str(cents):
        sign = ''
        if cents < 0:
            sign = '-'
            cents = -cents
        dollars = cents // 100
        remainder = cents % 100
        return f"{sign}{dollars}.{remainder:02d}"
    
    totals = {
        "invoice": _cents_to_str(invoice_total),
        "receipt": _cents_to_str(receipt_total)
    }
    
    result = {
        "archives": archives,
        "rows": rows,
        "csv": csv_str,
        "totals": totals
    }
    
    return {"name": contract["name"], "result": result}
