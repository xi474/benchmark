import importlib.util
import json
import sys
from pathlib import Path


def _load_module_from_path(module_name, file_path):
    """Load a Python module from a specific file path."""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def build_component(root, contract_path):
    """Read inputs per contract, call transform, return wrapped result."""
    root = Path(root)
    contract_path = Path(contract_path)

    # Load contract
    contract = json.loads(contract_path.read_text(encoding="utf-8"))

    comp_dir = contract_path.parent

    # Load model and transform from component directory
    model_mod = _load_module_from_path("model", comp_dir / "model.py")
    transform_mod = _load_module_from_path("transform", comp_dir / "transform.py")

    # Load payloads in contract.inputs order
    payloads = [model_mod.load_payload(root / p) for p in contract["inputs"]]

    # Call transform
    result = transform_mod.transform(payloads, contract)

    return result


if __name__ == "__main__":
    comp_dir = Path(__file__).resolve().parent
    contract_path = comp_dir / "contract.json"
    root = comp_dir.parents[1]

    result = build_component(root, contract_path)

    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)

    out_text = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    out_path.write_text(out_text, encoding="utf-8")
