def transform(payloads, contract):
    """dinner_apply: apply changes to calendar - remove cancelled, add new events."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    calendar_payload = payloads[0]  # outputs/calendar.json
    plan_payload = payloads[1]      # outputs/plan.json
    notifications_payload = payloads[2]  # outputs/notifications.json

    # Extract results
    if isinstance(calendar_payload, dict) and set(calendar_payload.keys()) == {"name", "result"}:
        calendar_data = calendar_payload["result"]
    else:
        calendar_data = calendar_payload

    if isinstance(plan_payload, dict) and set(plan_payload.keys()) == {"name", "result"}:
        plan_data = plan_payload["result"]
    else:
        plan_data = plan_payload

    if isinstance(notifications_payload, dict) and set(notifications_payload.keys()) == {"name", "result"}:
        notif_data = notifications_payload["result"]
    else:
        notif_data = notifications_payload

    old_events = calendar_data["events"]
    cancelled_ids = set(plan_data["cancelled"])
    added = plan_data["added"]
    outbox = notif_data["outbox"]

    # Remove cancelled events from old events
    remaining = [ev for ev in old_events if ev["id"] not in cancelled_ids]

    # Add new events
    final_events = remaining + list(added)

    # Sort final events by id
    final_events.sort(key=lambda e: e["id"])

    return {
        "name": contract["name"],
        "result": {
            "events": final_events,
            "outbox": outbox
        }
    }
