from datetime import datetime


def transform(payloads, contract):
    """dinner_calendar_index: index events and find existing dinners."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    # Validate required fields
    if "today" not in case:
        raise ValueError("missing 'today'")
    if "events" not in case:
        raise ValueError("missing 'events'")
    if "contacts" not in case:
        raise ValueError("missing 'contacts'")

    events = case["events"]
    contacts = case["contacts"]

    if not isinstance(events, list):
        raise ValueError("'events' must be a list")
    if not isinstance(contacts, list):
        raise ValueError("'contacts' must be a list")

    contacts_set = set()
    for c in contacts:
        if not isinstance(c, str):
            raise ValueError("contact id must be string")
        if c in contacts_set:
            raise ValueError(f"duplicate contact: {c}")
        contacts_set.add(c)

    # Validate and process events
    seen_ids = set()
    processed_events = []
    existing_dinner_dates = set()

    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be object")

        # Required fields
        for field in ("id", "start", "end", "kind", "attendees"):
            if field not in ev:
                raise ValueError(f"missing event field: {field}")

        eid = ev["id"]
        start_str = ev["start"]
        end_str = ev["end"]
        kind = ev["kind"]
        attendees = ev["attendees"]

        if not isinstance(eid, str):
            raise ValueError("event id must be string")
        if not isinstance(start_str, str):
            raise ValueError("event start must be string")
        if not isinstance(end_str, str):
            raise ValueError("event end must be string")
        if not isinstance(kind, str):
            raise ValueError("event kind must be string")
        if not isinstance(attendees, list):
            raise ValueError("event attendees must be list")

        # kind non-empty, strip check
        if not kind.strip():
            raise ValueError("kind must be non-empty after strip")

        # Event ID unique
        if eid in seen_ids:
            raise ValueError(f"duplicate event id: {eid}")
        seen_ids.add(eid)

        # Parse times
        start_dt = datetime.fromisoformat(start_str)
        end_dt = datetime.fromisoformat(end_str)

        # end > start
        if end_dt <= start_dt:
            raise ValueError(f"event {eid}: end must be > start")

        # All attendees exist in contacts
        deduped_attendees = []
        seen_att = set()
        for att in attendees:
            if not isinstance(att, str):
                raise ValueError("attendee must be string")
            if att not in contacts_set:
                raise ValueError(f"attendee {att} not in contacts")
            if att not in seen_att:
                seen_att.add(att)
                deduped_attendees.append(att)

        # Check if this is an existing dinner: kind=dinner, start at 19:00, end <= 20:00 same day
        if kind == "dinner":
            if (start_dt.hour == 19 and start_dt.minute == 0
                    and end_dt.date() == start_dt.date()
                    and end_dt.hour <= 20
                    and (end_dt.hour < 20 or end_dt.minute == 0)):
                # This is a valid existing dinner
                existing_dinner_dates.add(start_dt.date().isoformat())

        # Build processed event with deduped attendees
        processed_event = {
            "id": eid,
            "start": start_str,
            "end": end_str,
            "kind": kind,
            "attendees": sorted(deduped_attendees)
        }
        processed_events.append(processed_event)

    # Sort events by id, then attendees (already sorted within each event)
    # "按id,attendees去重排序" - sort by id primarily
    processed_events.sort(key=lambda e: e["id"])

    # existing_dinners: sorted unique dates
    existing_dinners_sorted = sorted(existing_dinner_dates)

    return {
        "name": contract["name"],
        "result": {
            "events": processed_events,
            "existing_dinners": existing_dinners_sorted
        }
    }
