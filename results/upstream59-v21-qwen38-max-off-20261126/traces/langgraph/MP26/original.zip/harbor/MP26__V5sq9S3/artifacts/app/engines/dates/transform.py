from datetime import date, timedelta


def transform(payloads, contract):
    """dinner_days: compute dates from today to next natural week's Friday (inclusive)."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    # Validate required fields
    if "today" not in case:
        raise ValueError("missing 'today'")
    if "events" not in case:
        raise ValueError("missing 'events'")
    if "contacts" not in case:
        raise ValueError("missing 'contacts'")

    today_str = case["today"]
    if not isinstance(today_str, str):
        raise ValueError("'today' must be a string")

    today = date.fromisoformat(today_str)

    # Compute next natural week's Friday
    # Monday is week start (weekday 0)
    current_week_monday = today - timedelta(days=today.weekday())
    next_week_friday = current_week_monday + timedelta(days=11)  # +7 for next week start, +4 for Friday

    # Generate all dates from today to next_week_friday inclusive
    dates = []
    d = today
    while d <= next_week_friday:
        dates.append(d.isoformat())
        d += timedelta(days=1)

    return {
        "name": contract["name"],
        "result": {
            "dates": dates
        }
    }
