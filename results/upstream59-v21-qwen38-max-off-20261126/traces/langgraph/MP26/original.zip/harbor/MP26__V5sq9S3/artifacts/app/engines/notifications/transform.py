def transform(payloads, contract):
    """dinner_notifications: generate notifications for affected contacts from cancelled events."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    plan_payload = payloads[0]  # outputs/plan.json

    # Extract result
    if isinstance(plan_payload, dict) and set(plan_payload.keys()) == {"name", "result"}:
        plan_data = plan_payload["result"]
    else:
        plan_data = plan_payload

    snapshots = plan_data["snapshots"]  # list of cancelled event objects

    # For each cancelled event snapshot, collect affected contacts
    # contact_id -> set of cancelled event ids they were attending
    contact_events = {}

    for ev in snapshots:
        eid = ev["id"]
        attendees = ev.get("attendees", [])
        for att in attendees:
            if att not in contact_events:
                contact_events[att] = set()
            contact_events[att].add(eid)

    # Build outbox: one entry per affected contact
    outbox = []
    for to_contact in sorted(contact_events.keys()):
        event_ids = sorted(contact_events[to_contact])
        outbox.append({
            "to": to_contact,
            "event_ids": event_ids
        })

    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox
        }
    }
