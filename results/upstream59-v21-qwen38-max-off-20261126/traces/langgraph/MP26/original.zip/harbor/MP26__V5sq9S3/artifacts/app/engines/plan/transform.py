from datetime import datetime


def transform(payloads, contract):
    """dinner_change_plan: create new dinner reminders and cancel conflicting events."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    dates_payload = payloads[0]  # outputs/dates.json -> {"name":"dates","result":{"dates":[...]}}
    calendar_payload = payloads[1]  # outputs/calendar.json -> {"name":"calendar","result":{...}}

    # Extract results (when input has name/result keys, use result)
    if isinstance(dates_payload, dict) and set(dates_payload.keys()) == {"name", "result"}:
        dates_data = dates_payload["result"]
    else:
        dates_data = dates_payload

    if isinstance(calendar_payload, dict) and set(calendar_payload.keys()) == {"name", "result"}:
        calendar_data = calendar_payload["result"]
    else:
        calendar_data = calendar_payload

    all_dates = dates_data["dates"]  # list of YYYY-MM-DD strings
    existing_dinners = set(calendar_data["existing_dinners"])  # set of date strings
    old_events = calendar_data["events"]  # list of event objects

    # Build index of old events by id
    old_event_map = {}
    for ev in old_events:
        old_event_map[ev["id"]] = ev

    # Determine which dates need new dinner reminders (skip existing_dinners dates)
    new_dates = [d for d in all_dates if d not in existing_dinners]

    # Create new dinner events
    added = []
    new_event_ids = set()
    for d in new_dates:
        new_id = f"dinner-{d}"
        # Check new ID doesn't conflict with any old event ID
        if new_id in old_event_map:
            raise ValueError(f"new dinner id '{new_id}' conflicts with existing event id")
        new_event_ids.add(new_id)
        added.append({
            "id": new_id,
            "start": f"{d}T19:00",
            "end": f"{d}T20:00",
            "kind": "dinner",
            "attendees": []
        })

    # Sort added by start time
    added.sort(key=lambda e: e["start"])

    # Determine which old events to cancel
    # Cancel all old events that have half-open interval intersection with any new reminder
    # Half-open interval: [start, end) - so exactly 19:00 end does NOT conflict with 19:00 start
    # "恰19点结束不冲突" means an event ending at exactly 19:00 does not conflict with a dinner starting at 19:00

    cancelled_ids = set()
    snapshots = []

    for ev in old_events:
        ev_start = datetime.fromisoformat(ev["start"])
        ev_end = datetime.fromisoformat(ev["end"])

        # Check against each new dinner's half-open interval [new_start, new_end)
        # Intersection of [ev_start, ev_end) and [new_start, new_end) exists iff
        # ev_start < new_end AND new_start < ev_end
        should_cancel = False
        for new_ev in added:
            new_start = datetime.fromisoformat(new_ev["start"])
            new_end = datetime.fromisoformat(new_ev["end"])

            # Half-open intersection: ev_start < new_end AND new_start < ev_end
            if ev_start < new_end and new_start < ev_end:
                should_cancel = True
                break

        if should_cancel:
            cancelled_ids.add(ev["id"])
            # Snapshot is the original event as-is from calendar
            snapshots.append(dict(ev))

    # Sort cancelled IDs
    cancelled_sorted = sorted(cancelled_ids)

    # Sort snapshots by id
    snapshots.sort(key=lambda e: e["id"])

    return {
        "name": contract["name"],
        "result": {
            "added": added,
            "cancelled": cancelled_sorted,
            "snapshots": snapshots
        }
    }
