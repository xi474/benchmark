"""Generate final report from core manifest."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # title
    title = "每日晚餐提醒的去重、冲突取消与通知"

    # component_count
    component_count = len(core["components"])

    # sha256: serialize the complete core object (including outer "components" key)
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    # attention: components matching any condition
    attention = set()
    for comp_name, result in core["components"].items():
        if not isinstance(result, dict):
            continue

        # result.blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None:
                # Non-empty check: for lists/dicts/strings, check truthiness
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float, bool)):
                    # These are not "non-empty" in the collection sense
                    pass

    attention_sorted = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_sorted
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    out_path.write_text(out_text, encoding="utf-8")


if __name__ == "__main__":
    main()
