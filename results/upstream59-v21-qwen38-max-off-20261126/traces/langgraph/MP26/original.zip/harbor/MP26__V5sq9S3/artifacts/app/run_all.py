"""Orchestrate all components based on file contracts."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency graph from contract inputs/outputs
    # Each contract has output path and input paths
    # We need to execute in topological order
    comp_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        comp_info[c["name"]] = {
            "contract_path": cp,
            "output": c["output"],
            "inputs": c["inputs"],
            "render_script": cp.parent / "render.py"
        }

    # Topological sort based on dependencies
    # An input that starts with "outputs/" depends on another component's output
    def get_deps(name):
        deps = set()
        for inp in comp_info[name]["inputs"]:
            if inp.startswith("outputs/"):
                # Find which component produces this output
                for other_name, info in comp_info.items():
                    if info["output"] == inp:
                        deps.add(other_name)
        return deps

    # Kahn's algorithm for topological sort
    in_degree = {name: 0 for name in comp_info}
    adj = {name: [] for name in comp_info}
    for name in comp_info:
        for dep in get_deps(name):
            adj[dep].append(name)
            in_degree[name] += 1

    queue = sorted([n for n in comp_info if in_degree[n] == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for neighbor in sorted(adj[node]):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
                queue.sort()

    if len(order) != len(comp_info):
        raise ValueError("dependency cycle detected")

    # Execute each component in order
    for name in order:
        info = comp_info[name]
        render_script = info["render_script"]
        if not render_script.exists():
            raise ValueError(f"render.py not found for {name}")

        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_result = subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if integrate_result.returncode != 0:
        print("integrate.py failed:", file=sys.stderr)
        print(integrate_result.stderr, file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    report_result = subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60
    )
    if report_result.returncode != 0:
        print("final_report.py failed:", file=sys.stderr)
        print(report_result.stderr, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
