def compute(payload):
    """按主题输入顺序生成评分表；每行把具有效章节证据的论文 ID 映射到该主题最高质量分。"""
    topics = payload["topics"]
    papers = payload["papers"]

    result = []
    for topic in topics:
        scores = {}
        for paper in papers:
            methods_set = set(paper["methods"])
            best = None
            for claim in paper["claims"]:
                claim_topic, claim_section, claim_quality = claim
                if claim_topic == topic and claim_section in methods_set:
                    if best is None or claim_quality > best:
                        best = claim_quality
            if best is not None:
                scores[paper["id"]] = best
        result.append(scores)
    return result
