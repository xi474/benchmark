def compute(payload):
    """返回去重并按三元组字典序排列的已有图事实。"""
    graph = payload.get("graph", [])
    # Convert each edge to a tuple for hashing/dedup, then sort lexicographically
    seen = set()
    unique = []
    for edge in graph:
        key = tuple(edge)
        if key not in seen:
            seen.add(key)
            unique.append(edge)
    # Sort lexicographically by the triple (element-wise string comparison, case-sensitive)
    unique.sort(key=lambda e: (e[0], e[1], e[2]))
    return unique
