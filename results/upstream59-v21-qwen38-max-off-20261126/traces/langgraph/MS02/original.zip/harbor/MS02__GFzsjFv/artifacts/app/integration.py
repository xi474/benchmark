def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  : list[dict]  – evidence_scores result, one dict per topic (topic order)
    right : list[list]  – graph_facts result, already deduped & sorted existing edges
    payload : dict      – original input with "topics" and "papers" keys
    """
    topics = payload["topics"]
    n_topics = len(topics)

    # If no topics, return empty review + existing graph
    if n_topics == 0:
        return {"review": [], "graph": right}

    # Build candidate lists per topic: list of (paper_id, quality) sorted for determinism
    # left[i] corresponds to topics[i]
    candidates = []
    for i in range(n_topics):
        score_map = left[i]
        cands = sorted(score_map.items(), key=lambda x: x[0])  # sort by paper_id
        candidates.append(cands)

    # Check feasibility: every topic must have at least one candidate
    for c in candidates:
        if not c:
            return None

    # We need to find an assignment that:
    # 1. Maximizes the minimum quality across all topics
    # 2. Among those, maximizes total quality
    # 3. Among those, picks lex-smallest paper ID sequence (by topic order)

    # Strategy: enumerate via backtracking with pruning.
    # With max 8 topics and 12 papers, worst case is manageable.

    best_assignment = None  # list of (paper_id, quality) per topic
    best_min_q = -1
    best_total_q = -1
    best_ids = None  # tuple of paper_ids for lex comparison

    def backtrack(topic_idx, used_papers, current_assignment, current_min, current_total):
        nonlocal best_assignment, best_min_q, best_total_q, best_ids

        if topic_idx == n_topics:
            # Complete assignment found
            ids_tuple = tuple(a[0] for a in current_assignment)
            if (current_min > best_min_q or
                (current_min == best_min_q and current_total > best_total_q) or
                (current_min == best_min_q and current_total == best_total_q and
                 (best_ids is None or ids_tuple < best_ids))):
                best_min_q = current_min
                best_total_q = current_total
                best_ids = ids_tuple
                best_assignment = list(current_assignment)
            return

        for paper_id, quality in candidates[topic_idx]:
            if paper_id in used_papers:
                continue
            new_min = min(current_min, quality)
            # Pruning: if new_min already worse than best_min_q, skip
            # But we also need to consider that future topics might lower it further
            # so we can only prune if new_min < best_min_q
            if new_min < best_min_q:
                continue
            # If new_min == best_min_q, we can still potentially match on total and lex
            # Upper bound on total: current_total + quality + sum of max possible for remaining
            # This is optional optimization; let's keep it simple for correctness
            used_papers.add(paper_id)
            current_assignment.append((paper_id, quality))
            backtrack(topic_idx + 1, used_papers, current_assignment, new_min, current_total + quality)
            current_assignment.pop()
            used_papers.remove(paper_id)

    backtrack(0, set(), [], float('inf'), 0)

    if best_assignment is None:
        return None

    # Build review
    review = []
    for i in range(n_topics):
        paper_id, quality = best_assignment[i]
        review.append([topics[i], paper_id, quality])

    # Build graph: union of existing edges (right) + new supports edges
    edge_set = set()
    for e in right:
        edge_set.add(tuple(e))
    for i in range(n_topics):
        paper_id, quality = best_assignment[i]
        edge_set.add((paper_id, "supports", topics[i]))

    # Sort by triple lexicographically (case-sensitive string comparison)
    sorted_edges = sorted(edge_set, key=lambda e: (e[0], e[1], e[2]))
    graph = [list(e) for e in sorted_edges]

    return {"review": review, "graph": graph}
