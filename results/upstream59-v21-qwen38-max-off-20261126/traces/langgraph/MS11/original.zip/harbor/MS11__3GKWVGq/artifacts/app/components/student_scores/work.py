def compute(payload):
    """按学生 ID 输出课程 1、2 非空成绩的百分制整型均值（sum×100 整除数量）。"""
    grades = payload.get("grades", [])
    # Collect non-null grades for courses 1 and 2 per student
    student_grades = {}
    for row in grades:
        student_id, course, score = row[0], row[1], row[2]
        if course not in (1, 2):
            continue
        if score is None:
            continue
        if student_id not in student_grades:
            student_grades[student_id] = []
        student_grades[student_id].append(score)
    
    # Calculate integer average: (sum * 100) // count
    result = {}
    for student_id, scores in student_grades.items():
        total = sum(scores)
        count = len(scores)
        result[student_id] = (total * 100) // count
    
    return result
