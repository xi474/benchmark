"""Integration module: combine student scores and buyer totals with evidence-based matching."""

from itertools import product as iter_product


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: dict mapping student_id -> integer grade X
    right: dict mapping buyer_id -> integer total Y
    
    Returns list of {drop, result} entries.
    """
    students = payload["students"]
    buyers = payload["buyers"]
    evidence = payload.get("evidence", [])
    drop_list = payload.get("drop", [None])
    
    n = len(students)
    
    # Sort students for consistent ordering
    sorted_students = sorted(students)
    # Map student index
    student_idx = {s: i for i, s in enumerate(sorted_students)}
    
    # X values in student-sorted order
    X = [left[s] for s in sorted_students]
    # Y values indexed by buyer
    Y_map = right
    
    results = []
    
    for drop_source in drop_list:
        result = _solve_drop(
            sorted_students, buyers, evidence, drop_source,
            n, X, Y_map, student_idx
        )
        results.append({"drop": drop_source, "result": result})
    
    return results


def _build_confidence_matrix(evidence, drop_source, students, buyers):
    """Build confidence matrix from evidence, optionally dropping a source.
    
    Returns dict mapping (student, buyer) -> confidence, or None if no valid mapping possible.
    """
    student_set = set(students)
    buyer_set = set(buyers)
    
    # Group evidence by (source, student, buyer) -> max strength
    source_pair_max = {}
    for row in evidence:
        src, stu, buy, strength = row[0], row[1], row[2], row[3]
        if drop_source is not None and src == drop_source:
            continue
        if stu not in student_set or buy not in buyer_set:
            continue
        key = (src, stu, buy)
        if key not in source_pair_max or strength > source_pair_max[key]:
            source_pair_max[key] = strength
    
    # Sum across sources for each (student, buyer) pair
    pair_conf = {}
    for (src, stu, buy), val in source_pair_max.items():
        pair_key = (stu, buy)
        pair_conf[pair_key] = pair_conf.get(pair_key, 0) + val
    
    return pair_conf


def _find_connected_components(students, buyers, pair_conf):
    """Find connected components in the bipartite evidence graph.
    
    Returns list of (student_subset, buyer_subset) tuples.
    """
    # Build adjacency
    student_neighbors = {s: set() for s in students}
    buyer_neighbors = {b: set() for b in buyers}
    
    for (s, b), conf in pair_conf.items():
        if conf > 0:
            student_neighbors[s].add(b)
            buyer_neighbors[b].add(s)
    
    visited_s = set()
    visited_b = set()
    components = []
    
    for s in students:
        if s in visited_s:
            continue
        # BFS
        comp_s = set()
        comp_b = set()
        queue_s = [s]
        visited_s.add(s)
        
        while queue_s:
            cs = queue_s.pop()
            comp_s.add(cs)
            for nb in student_neighbors[cs]:
                if nb not in visited_b:
                    visited_b.add(nb)
                    comp_b.add(nb)
                    for ns in buyer_neighbors[nb]:
                        if ns not in visited_s:
                            visited_s.add(ns)
                            queue_s.append(ns)
        
        if comp_s:
            components.append((sorted(comp_s), sorted(comp_b)))
    
    return components


def _enumerate_perfect_matchings(comp_students, comp_buyers, pair_conf):
    """Enumerate all perfect matchings in a component using backtracking.
    
    Returns list of matchings, each matching is a dict {student: buyer}.
    """
    n = len(comp_students)
    if n != len(comp_buyers):
        return []
    
    if n == 0:
        return [{}]
    
    # Build allowed edges
    allowed = {}
    for s in comp_students:
        allowed[s] = []
        for b in comp_buyers:
            if pair_conf.get((s, b), 0) > 0:
                allowed[s].append(b)
    
    # Check if perfect matching is possible (each student has at least one edge)
    for s in comp_students:
        if not allowed[s]:
            return []
    
    matchings = []
    used_buyers = set()
    current = {}
    
    def backtrack(idx):
        if idx == n:
            matchings.append(dict(current))
            return
        s = comp_students[idx]
        for b in allowed[s]:
            if b not in used_buyers:
                used_buyers.add(b)
                current[s] = b
                backtrack(idx + 1)
                del current[s]
                used_buyers.remove(b)
    
    backtrack(0)
    return matchings


def _compute_numerator(X_vals, Y_vals, n):
    """Compute n*sum(X*Y) - sum(X)*sum(Y) as integer."""
    sum_xy = sum(x * y for x, y in zip(X_vals, Y_vals))
    sum_x = sum(X_vals)
    sum_y = sum(Y_vals)
    return n * sum_xy - sum_x * sum_y


def _solve_drop(sorted_students, buyers, evidence, drop_source, n, X, Y_map, student_idx):
    """Solve for a single drop scenario."""
    
    pair_conf = _build_confidence_matrix(evidence, drop_source, sorted_students, buyers)
    
    # Find connected components
    components = _find_connected_components(sorted_students, buyers, pair_conf)
    
    # Check all students and buyers are covered
    all_students_covered = set()
    all_buyers_covered = set()
    for comp_s, comp_b in components:
        all_students_covered.update(comp_s)
        all_buyers_covered.update(comp_b)
    
    if all_students_covered != set(sorted_students) or all_buyers_covered != set(buyers):
        return None
    
    # For each component, enumerate perfect matchings
    comp_matchings = []
    for comp_s, comp_b in components:
        ms = _enumerate_perfect_matchings(comp_s, comp_b, pair_conf)
        if not ms:
            return None
        comp_matchings.append(ms)
    
    # Combine matchings across components
    # We need to find global matchings that maximize (min_conf, total_conf)
    # First, compute per-matching stats for each component
    
    def matching_stats(matching):
        """Return (min_conf, total_conf) for a matching."""
        confs = [pair_conf[(s, b)] for s, b in matching.items()]
        return min(confs), sum(confs)
    
    # For efficiency with small components, enumerate all combinations
    # and filter by optimal (floor, total)
    
    # Generate all global matchings by combining component matchings
    best_floor = -1
    best_total = -1
    best_matchings = []
    
    # Use iterative combination
    def combine_components(comp_idx, current_matching, current_floor, current_total):
        nonlocal best_floor, best_total, best_matchings
        
        if comp_idx == len(components):
            # Evaluate this complete matching
            if current_floor > best_floor or (current_floor == best_floor and current_total > best_total):
                best_floor = current_floor
                best_total = current_total
                best_matchings = [dict(current_matching)]
            elif current_floor == best_floor and current_total == best_total:
                best_matchings.append(dict(current_matching))
            return
        
        for m in comp_matchings[comp_idx]:
            m_floor, m_total = matching_stats(m)
            new_floor = min(current_floor, m_floor) if current_floor >= 0 else m_floor
            new_total = current_total + m_total
            
            # Pruning: if new_floor < best_floor, skip
            if new_floor < best_floor:
                continue
            # If new_floor == best_floor but even max possible total can't beat best, skip
            # (hard to compute max remaining total easily, so just continue)
            
            merged = dict(current_matching)
            merged.update(m)
            combine_components(comp_idx + 1, merged, new_floor, new_total)
    
    combine_components(0, {}, -1, 0)
    
    if not best_matchings:
        return None
    
    # Compute numerators for all optimal matchings
    numerators = []
    buyer_vectors = []
    
    for matching in best_matchings:
        # Build buyer vector in student-sorted order
        buyer_vec = [matching[s] for s in sorted_students]
        Y_vals = [Y_map[b] for b in buyer_vec]
        num = _compute_numerator(X, Y_vals, n)
        numerators.append(num)
        buyer_vectors.append(buyer_vec)
    
    min_num = min(numerators)
    max_num = max(numerators)
    
    # Find lex-smallest buyer vector for min and max
    min_indices = [i for i, num in enumerate(numerators) if num == min_num]
    max_indices = [i for i, num in enumerate(numerators) if num == max_num]
    
    min_buyers = min([buyer_vectors[i] for i in min_indices])
    max_buyers = min([buyer_vectors[i] for i in max_indices])
    
    # Forced pairs: pairs that appear in ALL optimal matchings
    forced_set = None
    for matching in best_matchings:
        pairs = set((s, b) for s, b in matching.items())
        if forced_set is None:
            forced_set = pairs
        else:
            forced_set &= pairs
    
    forced = sorted([[s, b] for s, b in forced_set], key=lambda x: x[0]) if forced_set else []
    
    return {
        "floor": best_floor,
        "total": best_total,
        "count": len(best_matchings),
        "min_num": min_num,
        "max_num": max_num,
        "min_buyers": min_buyers,
        "max_buyers": max_buyers,
        "forced": forced
    }
