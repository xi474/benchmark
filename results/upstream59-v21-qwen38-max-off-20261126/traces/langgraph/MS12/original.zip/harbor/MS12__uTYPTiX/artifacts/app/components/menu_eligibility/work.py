def compute(payload):
    """每个到货信号映射至可供菜品 ID，保持 recipes 顺序，检查难度、原料可得性和过敏限制。"""
    recipes = payload["recipes"]
    groups = payload.get("groups", [])
    delivery = payload.get("delivery", {})

    # Collect all forbidden ingredients across all groups
    # A dish is unavailable if ANY group forbids ANY of its ingredients
    forbidden_ingredients = set()
    for group in groups:
        # group format: [name, count, forbidden_list, liked_cats]
        if len(group) >= 3:
            for ing in group[2]:
                forbidden_ingredients.add(ing)

    result = {}
    for signal, available_ingredients in delivery.items():
        available_set = set(available_ingredients)
        eligible = []
        for recipe in recipes:
            # Check difficulty <= 4
            if recipe.get("difficulty", 0) > 4:
                continue
            # Check all ingredients are available
            recipe_ingredients = recipe.get("ingredients", [])
            if not all(ing in available_set for ing in recipe_ingredients):
                continue
            # Check no group forbids any ingredient in this recipe
            if any(ing in forbidden_ingredients for ing in recipe_ingredients):
                continue
            eligible.append(recipe["id"])
        result[signal] = eligible

    return result
