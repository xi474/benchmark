def compute(payload):
    """输出 [信号历史,该完整叶的权重或 null]，去重生成所有非空前缀，按历史字典序排列。"""
    scenarios = payload.get("scenarios", [])

    # Collect all non-empty prefixes and map complete paths to weights
    prefix_set = set()
    leaf_weights = {}

    for sc in scenarios:
        signals = sc["signals"]
        weight = sc["weight"]
        for i in range(1, len(signals) + 1):
            prefix = tuple(signals[:i])
            prefix_set.add(prefix)
        # The full signal sequence is a leaf; record its weight
        full = tuple(signals)
        leaf_weights[full] = weight

    # Sort prefixes lexicographically; Python tuple comparison naturally gives
    # shorter-before-extension when elements match, and standard lex order otherwise.
    sorted_prefixes = sorted(prefix_set)

    result = []
    for p in sorted_prefixes:
        w = leaf_weights.get(p, None)
        result.append([list(p), w])

    return result
