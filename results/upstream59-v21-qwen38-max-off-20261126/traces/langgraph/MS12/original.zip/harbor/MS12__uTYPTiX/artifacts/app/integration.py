def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: list of [prefix_list, weight_or_null] - sorted prefixes
    right: dict mapping signal -> list of eligible dish IDs
    """
    recipes = payload["recipes"]
    groups = payload.get("groups", [])
    budget = payload["budget"]
    scenarios = payload.get("scenarios", [])
    
    # Build recipe lookup
    recipe_map = {}
    for r in recipes:
        recipe_map[r["id"]] = r
    
    # Parse prefixes from left
    # left is list of [prefix_as_list, weight_or_null]
    prefixes = []  # list of (tuple_prefix, weight_or_none)
    for entry in left:
        pfx = tuple(entry[0])
        w = entry[1]
        prefixes.append((pfx, w))
    
    if not prefixes:
        return {"histories": [], "optimal": None}
    
    # Build trie structure
    # Each prefix has a parent (all but last element) and children
    prefix_set = set(p for p, _ in prefixes)
    prefix_index = {p: i for i, (p, _) in enumerate(prefixes)}
    
    # For each prefix, find its parent
    parent_of = {}
    children_of = {}
    for p, _ in prefixes:
        if len(p) == 1:
            parent_of[p] = None
        else:
            par = p[:-1]
            parent_of[p] = par
        children_of[p] = []
    
    for p, _ in prefixes:
        par = parent_of[p]
        if par is not None:
            children_of[par].append(p)
    
    # Identify leaf prefixes (those with a weight)
    leaf_weights = {}
    for p, w in prefixes:
        if w is not None:
            leaf_weights[p] = w
    
    # For each leaf, compute the path from root to leaf
    def get_path(pfx):
        path = []
        cur = pfx
        while cur is not None:
            path.append(cur)
            cur = parent_of[cur]
        path.reverse()
        return path
    
    leaves = sorted(leaf_weights.keys())
    leaf_paths = {leaf: get_path(leaf) for leaf in leaves}
    
    # For each group, compute liked categories
    group_info = []
    for g in groups:
        name, count, forbidden, liked = g[0], g[1], g[2], g[3]
        group_info.append({"name": name, "count": count, "liked": set(liked)})
    
    # Eligible dishes per signal (from right component)
    eligible_per_signal = right
    
    # For each prefix, the signal is the last element
    # Get eligible dishes for each prefix
    eligible_per_prefix = {}
    for p, _ in prefixes:
        signal = p[-1]
        eligible_per_prefix[p] = eligible_per_signal.get(signal, [])
    
    # Satisfaction: for a dish, how many points does each group get?
    # A group gets 1 point per person if the dish's category is in their liked list
    def dish_satisfaction(dish_id):
        """Returns list of per-person satisfaction for each group."""
        r = recipe_map[dish_id]
        cat = r["cat"]
        sats = []
        for gi in group_info:
            if cat in gi["liked"]:
                sats.append(1)
            else:
                sats.append(0)
        return sats
    
    # Now do backtracking search over prefixes in order
    # Assignment: prefix -> dish_id
    # We process prefixes in sorted order (which is the order in `prefixes`)
    
    num_prefixes = len(prefixes)
    
    # For efficient path checking, maintain for each leaf the current path state
    # When we assign a dish to prefix p, it affects all leaves whose path includes p
    
    # Precompute which leaves pass through each prefix
    leaves_through = {p: [] for p, _ in prefixes}
    for leaf in leaves:
        for p in leaf_paths[leaf]:
            leaves_through[p].append(leaf)
    
    # State for backtracking
    assignment = {}  # prefix -> dish_id
    
    # For each leaf, track: used dishes set, previous category, cumulative cost
    # These are updated incrementally as we assign dishes along the path
    
    # We'll maintain per-leaf state
    leaf_state = {}
    for leaf in leaves:
        leaf_state[leaf] = {
            "used": set(),
            "prev_cat": None,
            "cost": 0,
            "satisfaction": [0] * len(group_info),  # per-group total satisfaction
        }
    
    best = {"floor": -1, "utility": -1, "cost": float('inf'), "assignment": None}
    
    # Collect all optimal assignments for computing allowed
    all_optimal_assignments = []
    
    def evaluate_assignment():
        """Evaluate the current complete assignment."""
        min_service = float('inf')
        total_weighted_utility = 0
        total_weighted_cost = 0
        
        for leaf in leaves:
            w = leaf_weights[leaf]
            st = leaf_state[leaf]
            
            # Service score = min over groups of per-person satisfaction
            service = min(st["satisfaction"]) if group_info else 0
            min_service = min(min_service, service)
            
            # Total person-satisfaction for this scenario
            person_sat = sum(st["satisfaction"][gi] * group_info[gi]["count"] 
                           for gi in range(len(group_info)))
            total_weighted_utility += w * person_sat
            
            total_weighted_cost += w * st["cost"]
        
        return min_service, total_weighted_utility, total_weighted_cost
    
    def is_better(floor, utility, cost, best_floor, best_utility, best_cost):
        """Check if (floor, utility, cost) is strictly better than best."""
        if floor > best_floor:
            return True
        if floor < best_floor:
            return False
        if utility > best_utility:
            return True
        if utility < best_utility:
            return False
        if cost < best_cost:
            return True
        return False
    
    def is_at_least_as_good(floor, utility, cost, best_floor, best_utility, best_cost):
        """Check if (floor, utility, cost) is at least as good as best (for collecting all optimal)."""
        if floor != best_floor:
            return False
        if utility != best_utility:
            return False
        if cost != best_cost:
            return False
        return True
    
    def backtrack(idx):
        if idx == num_prefixes:
            # Complete assignment - evaluate
            fl, ut, co = evaluate_assignment()
            if is_better(fl, ut, co, best["floor"], best["utility"], best["cost"]):
                best["floor"] = fl
                best["utility"] = ut
                best["cost"] = co
                best["assignment"] = dict(assignment)
                all_optimal_assignments.clear()
                all_optimal_assignments.append(dict(assignment))
            elif is_at_least_as_good(fl, ut, co, best["floor"], best["utility"], best["cost"]):
                all_optimal_assignments.append(dict(assignment))
            return
        
        pfx = prefixes[idx][0]
        eligible = eligible_per_prefix[pfx]
        
        # Determine constraints from paths through this prefix
        # For each leaf through this prefix, check:
        # 1. Dish not already used on that leaf's path
        # 2. Dish category != previous category on that leaf's path
        # 3. Cumulative cost + dish cost <= budget for that leaf
        
        dish_cost_cache = {}
        
        for dish_id in eligible:
            r = recipe_map[dish_id]
            d_cost = r["cost"]
            d_cat = r["cat"]
            d_sat = dish_satisfaction(dish_id)
            
            # Check constraints for all leaves through this prefix
            valid = True
            affected_leaves = leaves_through[pfx]
            
            for leaf in affected_leaves:
                st = leaf_state[leaf]
                if dish_id in st["used"]:
                    valid = False
                    break
                if st["prev_cat"] is not None and d_cat == st["prev_cat"]:
                    valid = False
                    break
                if st["cost"] + d_cost > budget:
                    valid = False
                    break
            
            if not valid:
                continue
            
            # Apply assignment
            assignment[pfx] = dish_id
            saved_states = []
            for leaf in affected_leaves:
                st = leaf_state[leaf]
                saved = (st["used"].copy(), st["prev_cat"], st["cost"], 
                        st["satisfaction"][:])
                saved_states.append(saved)
                
                st["used"].add(dish_id)
                st["prev_cat"] = d_cat
                st["cost"] += d_cost
                for gi in range(len(group_info)):
                    st["satisfaction"][gi] += d_sat[gi]
            
            # Pruning: check if any leaf already violates budget
            # (already checked above)
            
            # Also prune: if current partial assignment already can't beat best
            # Simple pruning: check if any completed leaf has service score < best floor
            can_prune = False
            for leaf in leaves:
                st = leaf_state[leaf]
                # If this leaf is complete (all prefixes on its path assigned)
                path = leaf_paths[leaf]
                all_assigned = all(p in assignment for p in path)
                if all_assigned:
                    service = min(st["satisfaction"]) if group_info else 0
                    if service < best["floor"]:
                        can_prune = True
                        break
            
            if not can_prune:
                backtrack(idx + 1)
            
            # Undo assignment
            del assignment[pfx]
            for i, leaf in enumerate(affected_leaves):
                st = leaf_state[leaf]
                saved = saved_states[i]
                st["used"] = saved[0]
                st["prev_cat"] = saved[1]
                st["cost"] = saved[2]
                st["satisfaction"] = saved[3]
    
    backtrack(0)
    
    # Build output
    histories = [list(p) for p, _ in prefixes]
    
    if best["assignment"] is None:
        return {"histories": histories, "optimal": None}
    
    # menu: lexicographically smallest dish vector among all optimal assignments
    # The menu is ordered by prefix order
    def assignment_to_menu(asgn):
        return [asgn[p] for p, _ in prefixes]
    
    all_menus = [assignment_to_menu(a) for a in all_optimal_assignments]
    all_menus.sort()
    menu = all_menus[0]
    
    # count: number of distinct prefix-to-dish mappings
    count = len(all_optimal_assignments)
    
    # allowed: for each prefix, collect all dishes that appear in at least one optimal assignment
    allowed = []
    for i, (p, _) in enumerate(prefixes):
        dishes_at_prefix = set()
        for asgn in all_optimal_assignments:
            dishes_at_prefix.add(asgn[p])
        allowed.append(sorted(dishes_at_prefix))
    
    return {
        "histories": histories,
        "optimal": {
            "floor": best["floor"],
            "utility": best["utility"],
            "cost": best["cost"],
            "count": count,
            "menu": menu,
            "allowed": allowed,
        }
    }
