def compute(payload):
    """为每个查询逐时隙列出当时可见且实际为 down 的域名数组，升序；按有效时刻再按看到时刻选择最新记录。"""
    queries = payload["queries"]
    log = payload["log"]

    result = []
    for q in queries:
        as_of = q["as_of"]
        start = q["start"]
        end = q["end"]

        # Filter log records visible at as_of (seen_time <= as_of)
        visible = []
        for entry in log:
            domain, eff, seen, status = entry[0], entry[1], entry[2], entry[3]
            if seen <= as_of:
                visible.append((domain, eff, seen, status))

        # Group by domain
        domain_records = {}
        for domain, eff, seen, status in visible:
            if domain not in domain_records:
                domain_records[domain] = []
            domain_records[domain].append((eff, seen, status))

        # For each timeslot, determine which domains are down
        query_result = []
        for t in range(start, end):
            down_domains = []
            for domain, records in domain_records.items():
                # Find records with effective_time <= t
                candidates = [(eff, seen, status) for eff, seen, status in records if eff <= t]
                if not candidates:
                    # No record applies; domain starts as up (initial state)
                    continue
                # Pick the one with max effective_time, then max seen_time
                best = max(candidates, key=lambda x: (x[0], x[1]))
                if best[2] in ("down", "degraded"):
                    down_domains.append(domain)
            down_domains.sort()
            query_result.append(down_domains)

        result.append(query_result)

    return result
