def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: observed_outages result - list of per-query, per-timeslot arrays of down domains
    right: service_quorums result - dict mapping service_id -> [need, inputs]
    """
    queries = payload["queries"]
    domains = payload.get("domains", [])
    services = right  # {service_id: [need, [inputs...]]}
    
    results = []
    
    for qi, query in enumerate(queries):
        start = query["start"]
        end = query["end"]
        targets = query["targets"]
        down_per_slot = left[qi]  # list of lists of down domain names
        
        # For each timeslot, compute which targets are unavailable
        target_unavailable = {t: [] for t in targets}
        
        for slot_idx in range(end - start):
            down_domains = set(down_per_slot[slot_idx])
            avail = _evaluate_availability(domains, services, down_domains)
            for tgt in targets:
                if not avail.get(tgt, True):
                    target_unavailable[tgt].append(start + slot_idx)
        
        # Merge adjacent unavailable slots into half-open intervals
        incidents = []
        for tgt in sorted(targets):
            slots = target_unavailable[tgt]
            if not slots:
                continue
            seg_start = slots[0]
            seg_end = slots[0] + 1
            for s in slots[1:]:
                if s == seg_end:
                    seg_end = s + 1
                else:
                    incidents.append([tgt, seg_start, seg_end])
                    seg_start = s
                    seg_end = s + 1
            incidents.append([tgt, seg_start, seg_end])
        
        incidents.sort(key=lambda x: (x[0], x[1]))
        
        # Compute minimal repair sets
        repairs = _compute_minimal_repairs(
            domains, services, targets, down_per_slot
        )
        
        results.append({
            "incidents": incidents,
            "repairs": repairs
        })
    
    return results


def _evaluate_availability(domains, services, down_domains):
    """Evaluate availability of all entities given a set of down domains."""
    available = {}
    for d in domains:
        available[d] = d not in down_domains
    
    changed = True
    while changed:
        changed = False
        for sid, (need, inputs) in services.items():
            if sid in available:
                continue
            count = sum(1 for inp in inputs if available.get(inp, False))
            available[sid] = count >= need
            changed = True
    
    return available


def _is_valid_repair(domains, services, targets, down_per_slot, repair_set):
    """Check if all targets are available at every timeslot when repair_set domains are forced UP."""
    for slot_idx in range(len(down_per_slot)):
        down_domains = set(down_per_slot[slot_idx]) - repair_set
        avail = _evaluate_availability(domains, services, down_domains)
        for tgt in targets:
            if not avail.get(tgt, True):
                return False
    return True


def _compute_minimal_repairs(domains, services, targets, down_per_slot):
    """Compute all inclusion-minimal permanent repair sets.
    
    Enumerates subsets of candidate domains by increasing size,
    skipping any superset of an already-found minimal set.
    """
    from itertools import combinations
    
    domain_list = sorted(domains)
    domain_set = set(domain_list)
    
    # Check if no repair needed
    if _is_valid_repair(domains, services, targets, down_per_slot, set()):
        return [[]]
    
    # Only consider domains that are actually down in some slot
    candidate_domains = set()
    for slot_downs in down_per_slot:
        for d in slot_downs:
            if d in domain_set:
                candidate_domains.add(d)
    
    candidate_list = sorted(candidate_domains)
    n_cand = len(candidate_list)
    
    minimal_sets = []
    
    for size in range(1, n_cand + 1):
        for combo in combinations(candidate_list, size):
            combo_set = set(combo)
            
            # Pruning: skip if any existing minimal set is a subset of combo
            dominated = False
            for ms in minimal_sets:
                if all(d in combo_set for d in ms):
                    dominated = True
                    break
            if dominated:
                continue
            
            if _is_valid_repair(domains, services, targets, down_per_slot, combo_set):
                minimal_sets.append(list(combo))
    
    # Sort: by size, then lexicographically
    minimal_sets.sort(key=lambda s: (len(s), s))
    return minimal_sets
