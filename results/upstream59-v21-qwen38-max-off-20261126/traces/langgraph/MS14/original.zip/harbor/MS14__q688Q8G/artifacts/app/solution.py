import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file and return the parsed payload."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def transform(payload):
    """Run both components inline and combine results."""
    from component_runtime import evaluate_unit, project, UNITS
    from integration import combine
    
    values = [evaluate_unit(name, project(payload, fields)) for name, fields in UNITS.items()]
    return combine(payload, *values)


def build_component(input_path, output_path):
    """Read input, compute, write output, and return the result."""
    from component_runtime import read, write, persist, assemble, transform as _transform, UNITS, project, ROOT
    from pathlib import Path as P
    
    payload = read(input_path)
    out = P(output_path)
    
    if P(input_path).resolve() == ROOT / "public_input.json" and out.resolve() == ROOT / "outputs/result.json":
        for name, fields in UNITS.items():
            persist(name, project(payload, fields))
        value = assemble(payload)
    else:
        value = _transform(payload)
    
    out.parent.mkdir(parents=True, exist_ok=True)
    write(out, value)
    return value
