def compute(payload):
    """为每个快照按 b 生成候选层数组。每层候选为 [按 a,c 行优先的计数向量,该层的中位数净分]，满足边际、禁止格和 ac 上限；按向量字典序。"""
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])

        k = len(ab)  # ab is k x k
        k_c = len(bc[0]) if len(bc) > 0 else 0  # bc is k x k, so k_c == k

        # Build forbidden set for quick lookup
        forbidden_set = set()
        for f in forbidden:
            forbidden_set.add((f[0], f[1], f[2]))

        snapshot_result = []
        for b in range(k):
            # Margins for this layer
            row_sums = tuple(ab[a][b] for a in range(k))   # sum over c for each a
            col_sums = tuple(bc[b][c] for c in range(k_c))  # sum over a for each c

            # Upper bounds from ac
            caps = [[ac[a][c] for c in range(k_c)] for a in range(k)]

            # Forbidden mask for this b layer
            forbidden_mask = [[False] * k_c for _ in range(k)]
            for a in range(k):
                for c in range(k_c):
                    if (a, b, c) in forbidden_set:
                        forbidden_mask[a][c] = True

            # Precompute median scores per cell for this b
            cell_scores = [[0] * k_c for _ in range(k)]
            for a in range(k):
                for c in range(k_c):
                    med = _median(a, b, c)
                    if med == k - 1:
                        cell_scores[a][c] = 1
                    elif med == 0:
                        cell_scores[a][c] = -1
                    # else 0

            # Enumerate all valid layers via backtracking
            candidates = []
            total_cells = k * k_c

            def solve(idx, rem_row, rem_col, grid_vals, net_score):
                if idx == total_cells:
                    if all(r == 0 for r in rem_row) and all(c == 0 for c in rem_col):
                        candidates.append((list(grid_vals), net_score))
                    return

                a = idx // k_c
                c = idx % k_c

                if forbidden_mask[a][c]:
                    # Cell must be 0
                    solve(idx + 1, rem_row, rem_col, grid_vals + [0], net_score)
                    return

                max_val = min(rem_row[a], rem_col[c], caps[a][c])

                for v in range(max_val + 1):
                    nr_a = rem_row[a] - v
                    nc_c = rem_col[c] - v

                    if nr_a < 0 or nc_c < 0:
                        break

                    # Pruning: can remaining cells in row a (after column c) absorb nr_a?
                    row_cap = 0
                    for cc in range(c + 1, k_c):
                        if not forbidden_mask[a][cc]:
                            row_cap += min(caps[a][cc], rem_col[cc])
                    if row_cap < nr_a:
                        continue

                    # Pruning: can remaining cells in col c absorb nc_c?
                    # Cells below (a,c) in same col: (a+1, c)...(k-1, c)
                    col_cap = 0
                    for aa in range(a + 1, k):
                        if not forbidden_mask[aa][c]:
                            col_cap += min(caps[aa][c], rem_row[aa])
                    if col_cap < nc_c:
                        continue

                    new_rem_row = list(rem_row)
                    new_rem_col = list(rem_col)
                    new_rem_row[a] = nr_a
                    new_rem_col[c] = nc_c

                    solve(idx + 1, new_rem_row, new_rem_col,
                          grid_vals + [v], net_score + v * cell_scores[a][c])

            solve(0, list(row_sums), list(col_sums), [], 0)

            # Sort by vector lexicographically
            candidates.sort(key=lambda x: x[0])

            snapshot_result.append([[vec, score] for vec, score in candidates])

        results.append(snapshot_result)

    return results


def _median(a, b, c):
    """Return the median of three values."""
    if a <= b:
        if b <= c:
            return b
        elif a <= c:
            return c
        else:
            return a
    else:
        if a <= c:
            return a
        elif b <= c:
            return c
        else:
            return b
