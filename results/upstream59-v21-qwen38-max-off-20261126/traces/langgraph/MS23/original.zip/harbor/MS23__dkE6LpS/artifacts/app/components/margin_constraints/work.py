def compute(payload):
    """为每个快照输出 [ab 与 ac 各 a 总量是否相容,按 a,c 行优先展开的 ac 配额]。"""
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        ac = snap["ac"]
        # Row sums of ab over b for each a
        ab_row_sums = [sum(row) for row in ab]
        # Row sums of ac over c for each a
        ac_row_sums = [sum(row) for row in ac]
        # Check compatibility: for each a, the total from ab must equal total from ac
        compatible = (ab_row_sums == ac_row_sums)
        # Flatten ac in row-major order (a outer, c inner)
        ac_flat = []
        for row in ac:
            ac_flat.extend(row)
        results.append([compatible, ac_flat])
    return results
