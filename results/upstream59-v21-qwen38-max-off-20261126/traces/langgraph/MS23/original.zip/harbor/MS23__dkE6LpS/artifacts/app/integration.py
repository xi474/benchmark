def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: list of [compatible_bool, ac_flat_vector] per snapshot (from margin_constraints)
    right: list of per-b candidate arrays per snapshot (from layer_candidates)
    
    Returns: list of result dicts per snapshot with tables/spectrum/guaranteed/witness
    """
    snapshots = payload["snapshots"]
    results = []
    
    for snap_idx, snap in enumerate(snapshots):
        mc = left[snap_idx]  # [compatible, ac_flat]
        lc = right[snap_idx]  # list of per-b candidate arrays
        
        compatible = mc[0]
        ac_flat = mc[1]
        
        ab = snap["ab"]
        k = len(ab)  # number of rating levels
        k_c = len(snap["bc"][0]) if len(snap["bc"]) > 0 else 0
        
        # Reconstruct ac matrix from flat
        ac = []
        idx = 0
        for a in range(k):
            row = []
            for c in range(k_c):
                row.append(ac_flat[idx])
                idx += 1
            ac.append(row)
        
        if not compatible:
            results.append(None)
            continue
        
        # lc is a list of k elements (one per b value)
        # Each element is a list of candidates: [count_vector, net_score]
        # count_vector is in a,c row-major order (length k * k_c)
        
        # We need to pick one candidate per b such that for each (a,c),
        # sum over b of X[a][b][c] == ac[a][c]
        
        # Enumerate all valid combinations via backtracking over b values
        num_b = len(lc)
        
        # For efficiency, precompute ac targets as flat vector
        ac_target = list(ac_flat)  # length k * k_c
        
        valid_tables = []  # list of (full_3d_flat_vector, total_net_score)
        
        def backtrack(b_idx, remaining_ac, current_layers, current_net):
            """
            b_idx: current b index to assign
            remaining_ac: flat vector of remaining capacity for each (a,c) cell
            current_layers: list of chosen (vector, score) for b=0..b_idx-1
            current_net: accumulated net score so far
            """
            if b_idx == num_b:
                # Check all remaining_ac are zero
                if all(r == 0 for r in remaining_ac):
                    # Build the full 3D table as flat vector in a,b,c order
                    # and collect non-zero entries
                    full_table = _build_table(current_layers, k, k_c, num_b)
                    valid_tables.append((full_table, current_net))
                return
            
            candidates = lc[b_idx]
            for vec, score in candidates:
                # Check if this candidate fits within remaining_ac
                feasible = True
                new_remaining = list(remaining_ac)
                for i in range(len(vec)):
                    if vec[i] > new_remaining[i]:
                        feasible = False
                        break
                    new_remaining[i] -= vec[i]
                
                if not feasible:
                    continue
                
                # Pruning: for remaining b values, check if remaining_ac can be satisfied
                # Simple check: for each (a,c), remaining must be achievable
                # We skip complex pruning for correctness; total customers <= 40 keeps it tractable
                
                backtrack(b_idx + 1, new_remaining, 
                         current_layers + [(vec, score)], 
                         current_net + score)
        
        backtrack(0, list(ac_target), [], 0)
        
        if not valid_tables:
            results.append(None)
            continue
        
        num_tables = len(valid_tables)
        
        # Compute spectrum: group by net score, sort by net score ascending
        from collections import Counter
        score_counts = Counter()
        for _, net in valid_tables:
            score_counts[net] += 1
        
        spectrum = sorted([[score, count] for score, count in score_counts.items()], 
                         key=lambda x: x[0])
        
        # Compute guaranteed: cells (a,b,c) where ALL valid tables have count > 0
        # Find minimum count across all tables for each cell
        # Cells are indexed in a,b,c order
        total_cells = k * num_b * k_c
        
        # Initialize min counts to infinity
        min_counts = [float('inf')] * total_cells
        for table_flat, _ in valid_tables:
            for i in range(total_cells):
                if table_flat[i] < min_counts[i]:
                    min_counts[i] = table_flat[i]
        
        guaranteed = []
        for a in range(k):
            for b in range(num_b):
                for c in range(k_c):
                    idx = a * num_b * k_c + b * k_c + c
                    if min_counts[idx] > 0:
                        guaranteed.append([a, b, c, min_counts[idx]])
        
        # Compute witness: the table with lowest net score; among ties, 
        # the one whose full cell vector (including zeros, in a→b→c order) 
        # is lexicographically smallest. Output only non-zero entries.
        # Sort by (net_score, full_vector_lex)
        valid_tables.sort(key=lambda x: (x[1], x[0]))
        best_table_flat, best_net = valid_tables[0]
        
        witness = []
        for a in range(k):
            for b in range(num_b):
                for c in range(k_c):
                    idx = a * num_b * k_c + b * k_c + c
                    val = best_table_flat[idx]
                    if val > 0:
                        witness.append([a, b, c, val])
        
        results.append({
            "tables": num_tables,
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": witness
        })
    
    return results


def _build_table(layers, k, k_c, num_b):
    """Build a flat 3D table in a,b,c order from per-b layer vectors.
    
    layers: list of (vec, score) where vec is in a,c row-major order for that b
    Returns: flat list in a,b,c order (a outer, b middle, c inner)
    """
    # Initialize 3D array
    table = [[[0] * k_c for _ in range(num_b)] for _ in range(k)]
    
    for b in range(num_b):
        vec = layers[b][0]
        idx = 0
        for a in range(k):
            for c in range(k_c):
                table[a][b][c] = vec[idx]
                idx += 1
    
    # Flatten in a,b,c order
    flat = []
    for a in range(k):
        for b in range(num_b):
            for c in range(k_c):
                flat.append(table[a][b][c])
    
    return flat
