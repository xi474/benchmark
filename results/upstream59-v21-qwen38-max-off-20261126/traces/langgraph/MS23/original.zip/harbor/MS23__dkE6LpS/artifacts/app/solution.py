"""Solution module exposing transform, load_payload, and build_component."""
import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file and return the parsed payload."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def transform(payload):
    """Run both components in-process and combine results."""
    from component_runtime import transform as _transform
    return _transform(payload)


def build_component(input_path, output_path):
    """Read input, compute, write output, and return the result."""
    from component_runtime import build_component as _build
    return _build(input_path, output_path)
