def compute(payload):
    """为有截止日的作业返回 [需求,合格时段 ID 升序数组]，先按原始时段和七天半开窗口筛选。"""
    assignments = payload["assignments"]
    slots = payload["slots"]

    # Build slot lookup: slot_id -> day
    slot_day = {}
    for slot in slots:
        slot_id, day, _capacity = slot[0], slot[1], slot[2]
        slot_day[slot_id] = day

    result = {}
    for assignment in assignments:
        assign_id = assignment[0]
        due = assignment[1]
        demand = assignment[2]
        serviceable_slots = assignment[3]

        # Skip assignments without a deadline
        if due is None:
            continue

        # Filter slots: must be in serviceable list AND satisfy due-7 <= day < due
        valid_slots = []
        for sid in serviceable_slots:
            if sid in slot_day:
                day = slot_day[sid]
                if due - 7 <= day < due:
                    valid_slots.append(sid)

        # Sort valid slot IDs in ascending order
        valid_slots.sort()

        result[assign_id] = [demand, valid_slots]

    return result
