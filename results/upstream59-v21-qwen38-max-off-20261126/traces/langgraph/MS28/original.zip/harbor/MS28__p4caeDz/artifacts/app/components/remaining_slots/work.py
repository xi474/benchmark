def compute(payload):
    """每个撤回情景返回仍可用的时段映射，时段 ID 对应 [时刻,容量]。"""
    slots = payload["slots"]
    withdrawals = payload["withdrawals"]

    # Build base slot map: slot_id -> [day, capacity]
    all_slots = {s[0]: [s[1], s[2]] for s in slots}

    result = []
    for withdrawn_ids in withdrawals:
        withdrawn_set = set(withdrawn_ids)
        remaining = {sid: val for sid, val in all_slots.items() if sid not in withdrawn_set}
        result.append(remaining)

    return result
