from math import gcd
from itertools import combinations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: dict mapping assignment_id -> [demand, sorted_valid_slot_ids]
          (only assignments with deadlines)
    right: list of dicts, one per withdrawal scenario,
           each mapping slot_id -> [day, capacity]
    
    Returns a list of scenario results in withdrawals order.
    """
    # left = deadline_windows result: {assign_id: [demand, [slot_ids...]]}
    # right = remaining_slots result: [{slot_id: [day, capacity]}, ...]
    
    results = []
    
    for scenario_idx, available_slots in enumerate(right):
        # available_slots: {slot_id: [day, capacity]}
        
        # Build per-assignment info: only assignments that have valid slots
        # AND those valid slots still exist after withdrawal
        assign_demands = {}  # assign_id -> demand
        assign_slots = {}    # assign_id -> frozenset of available valid slot ids
        
        unserved = []
        
        for assign_id, (demand, valid_slot_ids) in left.items():
            # Filter to only slots that are still available
            avail = [sid for sid in valid_slot_ids if sid in available_slots]
            if not avail:
                unserved.append(assign_id)
            else:
                assign_demands[assign_id] = demand
                assign_slots[assign_id] = frozenset(avail)
        
        if unserved:
            results.append({"unserved": sorted(unserved)})
            continue
        
        if not assign_demands:
            results.append({"empty": True})
            continue
        
        # Now we need to find peak load ratio, tight sets, etc.
        # Build bipartite graph and find connected components
        assign_ids = sorted(assign_demands.keys())
        assign_index = {aid: i for i, aid in enumerate(assign_ids)}
        n = len(assign_ids)
        
        # Build adjacency: assignment -> set of slot ids
        # For connected components, we need assignment-slot bipartite connectivity
        # Use union-find on assignments: two assignments are connected if they share a slot
        
        parent = list(range(n))
        
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
        
        # For each slot, collect assignments that use it
        slot_to_assigns = {}
        for aid in assign_ids:
            for sid in assign_slots[aid]:
                if sid not in slot_to_assigns:
                    slot_to_assigns[sid] = []
                slot_to_assigns[sid].append(assign_index[aid])
        
        for sid, aids in slot_to_assigns.items():
            for i in range(1, len(aids)):
                union(aids[0], aids[i])
        
        # Group assignments by component
        comp_map = {}
        for i in range(n):
            r = find(i)
            if r not in comp_map:
                comp_map[r] = []
            comp_map[r].append(i)
        
        # For each component, enumerate all non-empty subsets
        # Track global peak ratio and all tight sets
        
        global_peak_num = 0
        global_peak_den = 1
        all_tight_sets = []  # list of frozensets of assign_ids
        
        for comp_indices in comp_map.values():
            m = len(comp_indices)
            comp_assign_ids = [assign_ids[i] for i in comp_indices]
            
            # Precompute demands and slot sets for this component
            comp_demands = [assign_demands[comp_assign_ids[j]] for j in range(m)]
            comp_slot_sets = [assign_slots[comp_assign_ids[j]] for j in range(m)]
            
            # Enumerate all non-empty subsets (bitmask)
            for mask in range(1, 1 << m):
                total_demand = 0
                union_slots = set()
                bits = []
                for j in range(m):
                    if mask & (1 << j):
                        total_demand += comp_demands[j]
                        union_slots |= comp_slot_sets[j]
                        bits.append(comp_assign_ids[j])
                
                # Compute capacity of union of slots
                total_capacity = sum(available_slots[sid][1] for sid in union_slots)
                
                if total_capacity == 0:
                    # This shouldn't happen since we filtered unserved already
                    continue
                
                # Compare ratio total_demand / total_capacity with global_peak
                # Use cross multiplication to avoid floating point
                # new_ratio > old_ratio iff total_demand * global_peak_den > global_peak_num * total_capacity
                cmp = total_demand * global_peak_den - global_peak_num * total_capacity
                
                if cmp > 0:
                    # New peak found
                    global_peak_num = total_demand
                    global_peak_den = total_capacity
                    all_tight_sets = [frozenset(bits)]
                elif cmp == 0:
                    all_tight_sets.append(frozenset(bits))
        
        # Simplify peak fraction
        g = gcd(global_peak_num, global_peak_den)
        peak = [global_peak_num // g, global_peak_den // g]
        
        count = len(all_tight_sets)
        
        # Find minimal tight sets (by inclusion)
        # Sort by size first, then lexicographically
        all_tight_sorted = sorted(all_tight_sets, key=lambda s: (len(s), sorted(s)))
        
        minimal = []
        for ts in all_tight_sorted:
            # Check if any already-added minimal set is a subset of ts
            is_minimal = True
            for ms in minimal:
                if ms <= ts:  # ms is subset of ts
                    is_minimal = False
                    break
            if is_minimal:
                minimal.append(sorted(ts))
        
        # Sort minimal: by length first, then lexicographically
        minimal.sort(key=lambda s: (len(s), s))
        
        # Compute implies
        # For each assignment that appears in at least one tight set,
        # list the other assignments that appear in ALL tight sets containing it
        # Wait, re-read: "列表列出每个包含它的紧集也包含的其他作业"
        # This means: for assignment A, collect all other assignments B such that
        # B appears in every tight set that contains A? No...
        # "列表列出每个包含它的紧集也包含的其他作业，不含它自己"
        # Hmm, this is ambiguous. Let me look at the expected output.
        
        # Expected for scenario 0:
        # implies: [["Q",["R","S"]], ["R",["Q","S"]], ["S",["Q","R"]]]
        # The only tight set is {Q,R,S}. So for Q, the other members are R,S.
        # This suggests: for each assignment in any tight set, list the union of
        # other assignments across all tight sets containing it? Or intersection?
        
        # With only one tight set {Q,R,S}, both union and intersection give {R,S} for Q.
        # Let me think about what makes sense semantically...
        # "每个包含它的紧集也包含的其他作业" = "other assignments that each tight set 
        # containing it also contains"
        # This sounds like intersection: assignments that appear in EVERY tight set 
        # that contains this assignment.
        
        # Actually re-reading more carefully: "列表列出每个包含它的紧集也包含的其他作业"
        # could mean "list the other assignments that each tight-set containing it also contains"
        # i.e., the intersection over all tight sets containing this assignment, of 
        # (tight_set - {this_assignment}).
        
        # Let me verify with the example: only one tight set {Q,R,S}
        # For Q: intersection of ({Q,R,S}-{Q}) = {R,S} ✓
        # For R: intersection of ({Q,R,S}-{R}) = {Q,S} ✓
        # For S: intersection of ({Q,R,S}-{S}) = {Q,R} ✓
        
        # Collect all assignments appearing in any tight set
        assigns_in_tight = set()
        for ts in all_tight_sets:
            assigns_in_tight |= ts
        
        implies = []
        for aid in sorted(assigns_in_tight):
            # Find all tight sets containing aid
            containing = [ts for ts in all_tight_sets if aid in ts]
            # Intersection of (ts - {aid}) for all such ts
            others = None
            for ts in containing:
                o = ts - {aid}
                if others is None:
                    others = o
                else:
                    others = others & o
            implies.append([aid, sorted(others)])
        
        results.append({
            "peak": peak,
            "count": count,
            "minimal": minimal,
            "implies": implies
        })
    
    return results
