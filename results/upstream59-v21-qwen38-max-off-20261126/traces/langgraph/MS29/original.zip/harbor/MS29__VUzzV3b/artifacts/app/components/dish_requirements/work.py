from itertools import combinations


def compute(payload):
    """返回合格的三类菜品组合及合并需求，格式 [菜品 ID 数组,原料到数量映射]，按菜品字典序枚举。"""
    dishes = payload["dishes"]
    max_difficulty = payload["max_difficulty"]

    # Filter dishes by difficulty
    candidates = []
    for d in dishes:
        dish_id, category, difficulty, ingredients = d[0], d[1], d[2], d[3]
        if difficulty <= max_difficulty:
            candidates.append((dish_id, category, ingredients))

    # Group by category
    cat_map = {}
    for dish_id, category, ingredients in candidates:
        if category not in cat_map:
            cat_map[category] = []
        cat_map[category].append((dish_id, ingredients))

    categories = sorted(cat_map.keys())

    # Enumerate all valid 3-dish combos from distinct categories
    results = []
    if len(categories) >= 3:
        for cat_combo in combinations(categories, 3):
            # For each combination of 3 categories, pick one dish from each
            dish_lists = [cat_map[c] for c in cat_combo]
            # Generate all combinations of one dish from each category
            def _enumerate(lists, idx, current):
                if idx == len(lists):
                    yield list(current)
                    return
                for dish_id, ingredients in lists[idx]:
                    current.append((dish_id, ingredients))
                    yield from _enumerate(lists, idx + 1, current)
                    current.pop()

            for combo in _enumerate(dish_lists, 0, []):
                # Sort dish IDs lexicographically
                dish_ids = sorted([c[0] for c in combo])
                # Merge ingredients
                merged = {}
                for _, ingredients in combo:
                    for ing, qty in ingredients.items():
                        merged[ing] = merged.get(ing, 0) + qty
                results.append((dish_ids, merged))

    # Sort by dish ID triple lexicographically
    results.sort(key=lambda x: x[0])

    # Convert to output format
    output = []
    for dish_ids, merged in results:
        output.append([dish_ids, merged])

    return output
