from itertools import product


def compute(payload):
    """Enumerate all feasible integer purchase vectors within offer limits.

    Returns a list of [total_cost, total_packages, buy_vector] sorted by
    (total_cost, total_packages, buy_vector) in ascending order.

    The buy_vector is ordered by offer ID ascending (lexicographic on the
    string offer IDs).
    """
    offers = payload["offers"]

    # Sort offers by their ID (first element) to establish canonical ordering
    sorted_offers = sorted(offers, key=lambda o: o[0])

    n = len(sorted_offers)
    prices = [o[2] for o in sorted_offers]
    max_pkgs = [o[3] for o in sorted_offers]

    # Generate all combinations of purchase quantities
    ranges = [range(m + 1) for m in max_pkgs]

    results = []
    for vec in product(*ranges):
        total_cost = sum(v * p for v, p in zip(vec, prices))
        total_packages = sum(vec)
        results.append([total_cost, total_packages, list(vec)])

    # Sort by (total_cost, total_packages, buy_vector lexicographically)
    results.sort(key=lambda r: (r[0], r[1], r[2]))

    return results
