"""Integration: combine dish_requirements and purchase_baskets with prep simulation."""


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left: list of [dish_ids, merged_ingredients] from dish_requirements
    right: list of [cost, packages, buy_vector] from purchase_baskets (sorted by cost/packages/vector)

    For each dish combo, find the optimal purchase basket + prep sequence that satisfies
    the merged ingredient requirements, minimizing:
      1. total cost
      2. total packages  
      3. buy vector (lexicographic, by offer ID ascending)
      4. total prep step count
      5. prep step sequence (lexicographic)

    Returns list of {dishes, plan} sorted by dish ID triple lexicographically.
    plan is null if no feasible solution exists.
    """
    stock = payload.get("stock", {})
    offers = payload.get("offers", [])
    prep_ops = payload.get("prep", [])

    # Sort offers by ID to establish canonical ordering (same as purchase_baskets component)
    sorted_offers = sorted(offers, key=lambda o: o[0])

    # Parse prep operations: each is (op_id, consumes_dict, produces_dict, max_executions)
    parsed_preps = []
    for p in prep_ops:
        op_id = p[0]
        consumes = dict(p[1])
        produces = dict(p[2])
        max_exec = p[3]
        parsed_preps.append((op_id, consumes, produces, max_exec))

    results = []

    for dish_ids, required in left:
        best_plan = None

        # Try each purchase basket (already sorted by cost, packages, buy_vector)
        for cost, packages, buy_vector in right:
            # Early termination: if we already have a plan and this basket is strictly worse
            # on the first three criteria, no prep sequence can make it better
            if best_plan is not None:
                if (cost, packages, list(buy_vector)) > (best_plan["cost"], best_plan["_packages"], best_plan["buy"]):
                    continue

            # Compute initial inventory after purchasing
            inventory = dict(stock)
            for i, qty in enumerate(buy_vector):
                if qty > 0:
                    offer_items = sorted_offers[i][1]
                    for item, amount in offer_items.items():
                        inventory[item] = inventory.get(item, 0) + amount * qty

            # Find optimal prep sequence for this basket
            plan = _find_prep_plan(inventory, required, parsed_preps, cost, buy_vector, packages)
            if plan is not None:
                if best_plan is None or _plan_better(plan, best_plan):
                    best_plan = plan

        if best_plan is not None:
            results.append({
                "dishes": dish_ids,
                "plan": {
                    "cost": best_plan["cost"],
                    "buy": best_plan["buy"],
                    "steps": best_plan["steps"],
                    "left": best_plan["left"],
                }
            })
        else:
            results.append({
                "dishes": dish_ids,
                "plan": None
            })

    return results


def _meets_requirements(inventory, required):
    """Check if inventory has at least the required amounts."""
    for item, qty in required.items():
        if inventory.get(item, 0) < qty:
            return False
    return True


def _compute_leftover(inventory, required):
    """Compute positive leftover after subtracting requirements."""
    leftover = {}
    all_items = set(inventory.keys()) | set(required.keys())
    for item in sorted(all_items):
        diff = inventory.get(item, 0) - required.get(item, 0)
        if diff > 0:
            leftover[item] = diff
    return leftover


def _plan_better(a, b):
    """Return True if plan a is better than plan b according to the optimization criteria:
    1. Minimize cost
    2. Minimize packages
    3. Minimize buy vector (lexicographic)
    4. Minimize step count
    5. Minimize step sequence (lexicographic)
    """
    if a["cost"] != b["cost"]:
        return a["cost"] < b["cost"]
    if a["_packages"] != b["_packages"]:
        return a["_packages"] < b["_packages"]
    if a["buy"] != b["buy"]:
        return a["buy"] < b["buy"]
    a_steps = a["steps"]
    b_steps = b["steps"]
    if len(a_steps) != len(b_steps):
        return len(a_steps) < len(b_steps)
    return a_steps < b_steps


def _inv_key(inv):
    """Create a hashable key from an inventory dict."""
    return tuple(sorted((k, v) for k, v in inv.items() if v > 0))


def _exec_key(execs):
    """Create a hashable key from remaining executions list."""
    return tuple(execs)


def _find_prep_plan(inventory, required, prep_ops, cost, buy_vector, packages):
    """Find optimal prep sequence using BFS.

    Returns a plan dict or None if infeasible.
    Max 16 total prep executions allowed.
    
    BFS guarantees minimum step count. Among solutions with the same step count,
    we track the lexicographically smallest step sequence to each state.
    """
    MAX_STEPS = 16

    # Check if already satisfied without any prep
    if _meets_requirements(inventory, required):
        leftover = _compute_leftover(inventory, required)
        return {
            "cost": cost,
            "buy": list(buy_vector),
            "steps": [],
            "left": leftover,
            "_packages": packages,
        }

    # BFS with state = (inventory, remaining_executions)
    # Track best (lex-smallest) step sequence reaching each state
    from collections import deque

    init_inv = dict(inventory)
    init_execs = [op[3] for op in prep_ops]

    # State -> best steps sequence reaching it
    best_path_to_state = {}
    init_state = (_inv_key(init_inv), _exec_key(init_execs))
    best_path_to_state[init_state] = []

    queue = deque()
    queue.append((init_inv, init_execs, []))

    best_result = None
    best_step_count = MAX_STEPS + 1  # Track minimum steps found

    while queue:
        current_inv, current_execs, current_steps = queue.popleft()

        # Pruning: if we already found a solution with fewer or equal steps, skip deeper exploration
        if len(current_steps) >= best_step_count:
            continue

        # Check if this path to this state is still the best known
        state = (_inv_key(current_inv), _exec_key(current_execs))
        if state in best_path_to_state and best_path_to_state[state] < current_steps:
            continue  # A better path to this state was already found

        # Try each prep operation (in order of op index for determinism)
        for op_idx, (op_id, consumes, produces, max_exec) in enumerate(prep_ops):
            if current_execs[op_idx] <= 0:
                continue

            # Check if all consumed materials are available
            can_execute = True
            for item, qty in consumes.items():
                if current_inv.get(item, 0) < qty:
                    can_execute = False
                    break

            if not can_execute:
                continue

            # Execute: deduct consumes, add produces
            new_inv = dict(current_inv)
            for item, qty in consumes.items():
                new_inv[item] -= qty
                if new_inv[item] == 0:
                    del new_inv[item]
            for item, qty in produces.items():
                new_inv[item] = new_inv.get(item, 0) + qty

            new_execs = list(current_execs)
            new_execs[op_idx] -= 1

            new_steps = current_steps + [op_id]
            new_state = (_inv_key(new_inv), _exec_key(new_execs))

            # Check if this is a better path to this state
            if new_state in best_path_to_state:
                if best_path_to_state[new_state] <= new_steps:
                    continue  # Already have an equal or better path
            best_path_to_state[new_state] = new_steps

            # Check if requirements are met
            if _meets_requirements(new_inv, required):
                leftover = _compute_leftover(new_inv, required)
                candidate = {
                    "cost": cost,
                    "buy": list(buy_vector),
                    "steps": new_steps,
                    "left": leftover,
                    "_packages": packages,
                }
                if best_result is None or _plan_better(candidate, best_result):
                    best_result = candidate
                    best_step_count = len(new_steps)
                continue  # Don't expand further from a solved state

            if len(new_steps) < best_step_count:
                queue.append((new_inv, new_execs, new_steps))

    return best_result
