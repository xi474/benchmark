"""Solution module with transform, load_payload, and build_component entry points."""
import json
from pathlib import Path


def load_payload(path):
    """Read a UTF-8 JSON file and return the parsed payload."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def transform(payload):
    """Run the full pipeline on a payload dict and return the result."""
    from component_runtime import UNITS, project, evaluate_unit
    from integration import combine
    values = [evaluate_unit(name, project(payload, fields)) for name, fields in UNITS.items()]
    return combine(payload, *values)


def build_component(input_path, output_path):
    """Read input, compute, write output, and return the result."""
    from component_runtime import read, write, UNITS, project, persist, assemble, fingerprint
    payload = read(input_path)
    out = Path(output_path)
    root = Path(__file__).resolve().parent

    if Path(input_path).resolve() == root / "public_input.json" and out.resolve() == root / "outputs/result.json":
        for name, fields in UNITS.items():
            persist(name, project(payload, fields))
        value = assemble(payload)
    else:
        value = transform(payload)

    out.parent.mkdir(parents=True, exist_ok=True)
    write(out, value)
    return value
