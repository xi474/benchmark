def compute(payload):
    """按最新市场日的 30 天窗口、相对绝对涨跌幅和代号打破平局，返回前 top 个房间代号（保持排名）。"""
    market = payload["market"]
    top = payload["top"]

    # Find last teaching day L
    L = max(row[1] for row in market)

    # Filter to 30-day window [L-29, L] inclusive
    window_start = L - 29
    filtered = [row for row in market if window_start <= row[1] <= L]

    # Compute abs(close - open) / open for ranking
    def sort_key(row):
        event_id = row[0]
        open_price = row[2]
        close_price = row[3]
        ratio = abs(close_price - open_price) / open_price
        # Sort by ratio descending, then event_id ascending
        return (-ratio, event_id)

    filtered.sort(key=sort_key)

    # Select top events
    result = [row[0] for row in filtered[:top]]
    return result
