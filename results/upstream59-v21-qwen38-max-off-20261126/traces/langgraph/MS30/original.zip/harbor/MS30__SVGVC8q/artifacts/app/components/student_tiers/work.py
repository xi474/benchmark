from fractions import Fraction


def compute(payload):
    """使用 16、17 号课程非空成绩的精确分数比，按原门槛输出学生到 P/D/N 层级映射。"""
    grades = payload["grades"]

    # Collect per-student ratios for courses 16 and 17 with non-null scores
    student_ratios = {}  # student -> list of Fraction(score, max_score)
    for row in grades:
        student, course, score, max_score = row[0], row[1], row[2], row[3]
        if course not in (16, 17):
            continue
        if score is None or max_score is None:
            continue
        ratio = Fraction(score, max_score)
        student_ratios.setdefault(student, []).append(ratio)

    # Compute equal-weight average and classify
    result = {}
    for student, ratios in student_ratios.items():
        avg = sum(ratios) / len(ratios)
        if avg < Fraction(60, 100):
            tier = "N"
        elif avg < Fraction(75, 100):
            tier = "D"
        else:
            tier = "P"
        result[student] = tier

    return result
