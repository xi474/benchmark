"""Integration module: combine student tiers and market ranking into stable matching results."""

from itertools import product


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    Args:
        payload: Full input payload with grades, market, rooms, prefs, top, cancel
        left: Student tier mapping {student_id: "P"/"D"/"N"}
        right: Ranked list of top event IDs
    
    Returns:
        List of results per cancel scenario, each with sizes, forced, example.
    """
    rooms = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]
    
    # All students who have at least one valid score (appear in left)
    all_students = sorted(left.keys())
    
    results = []
    
    for cancelled in cancel_list:
        cancelled_set = set(cancelled)
        # Open workshops: from right (ranked events), minus cancelled
        open_workshops = [w for w in right if w not in cancelled_set]
        
        # Build acceptability graph
        # For each student, which open workshops are acceptable
        # Acceptable means: student's tier is in room's tiers AND workshop is in student's prefs
        
        # Build student preference ordering over workshops
        # prefs[student] = [[group1 workshops], [group2 workshops], ...]
        # Earlier group = more preferred. Within group = equal preference.
        
        # Build room priority ordering over tiers
        # rooms[w]["tiers"] = [[tier1], [tier2], ...]
        # Earlier tier = higher priority. Within tier = equal priority.
        
        # Determine acceptable pairs
        student_options = {}  # student -> list of acceptable workshops
        for s in all_students:
            tier = left[s]
            s_prefs = prefs.get(s, [])
            # Flatten prefs to get set of acceptable workshops
            acceptable_set = set()
            for group in s_prefs:
                for w in group:
                    acceptable_set.add(w)
            
            options = []
            for w in open_workshops:
                if w not in acceptable_set:
                    continue
                # Check if student's tier is accepted by this room
                room_tiers = rooms[w]["tiers"]
                tier_accepted = False
                for tier_group in room_tiers:
                    if tier in tier_group:
                        tier_accepted = True
                        break
                if tier_accepted:
                    options.append(w)
            student_options[s] = options
        
        # Build bipartite graph and find connected components
        # Students and workshops as nodes; edges where acceptable
        # Decompose into independent components
        
        # Map workshops to indices for easier handling
        workshop_set = set(open_workshops)
        
        # Find connected components using union-find on the bipartite graph
        # Nodes: students + workshops
        # We'll use a simple BFS/DFS approach
        
        adj_s = {s: set(student_options[s]) for s in all_students}
        adj_w = {w: set() for w in open_workshops}
        for s in all_students:
            for w in student_options[s]:
                adj_w[w].add(s)
        
        visited_s = set()
        visited_w = set()
        components = []  # list of (set_of_students, set_of_workshops)
        
        for s in all_students:
            if s in visited_s or not adj_s[s]:
                continue
            # BFS
            comp_s = set()
            comp_w = set()
            queue = [('s', s)]
            while queue:
                typ, node = queue.pop()
                if typ == 's':
                    if node in visited_s:
                        continue
                    visited_s.add(node)
                    comp_s.add(node)
                    for w in adj_s[node]:
                        if w not in visited_w:
                            queue.append(('w', w))
                else:  # typ == 'w'
                    if node in visited_w:
                        continue
                    visited_w.add(node)
                    comp_w.add(node)
                    for ss in adj_w[node]:
                        if ss not in visited_s:
                            queue.append(('s', ss))
            if comp_s:
                components.append((comp_s, comp_w))
        
        # Also handle students with no acceptable options - they form singleton components
        # but since they can't be matched, they don't affect stability
        # Actually, isolated students (no edges) are trivially unmatched in all matchings
        
        # For each component, enumerate all weakly stable matchings
        # A matching assigns each student to at most one workshop, each workshop <= capacity
        
        # Weak stability: no blocking pair (s, w) where:
        # - s strictly prefers w to current assignment (or s is unmatched and w is acceptable)
        # - w has empty seat OR w strictly prefers s to some assigned student
        # - Zero-capacity workshops cannot block
        
        all_stable_matchings = _enumerate_all_stable(
            all_students, open_workshops, student_options, 
            prefs, rooms, left, components
        )
        
        # Compute sizes, forced, example
        if not all_stable_matchings:
            # Shouldn't happen - at least empty matching should be stable
            all_stable_matchings = [{}]
        
        # sizes: [matched_count, number_of_matchings] grouped by matched_count, sorted ascending
        from collections import Counter
        size_counts = Counter()
        for m in all_stable_matchings:
            matched = sum(1 for s in all_students if m.get(s, "") != "")
            size_counts[matched] += 1
        
        sizes = sorted([[count, num] for count, num in size_counts.items()], key=lambda x: x[0])
        
        # Max matched count
        max_matched = max(size_counts.keys())
        
        # forced: pairs (student, workshop) that appear in ALL matchings with max_matched
        max_matchings = [m for m in all_stable_matchings 
                        if sum(1 for s in all_students if m.get(s, "") != "") == max_matched]
        
        forced = []
        if max_matchings:
            # Find pairs present in all max matchings
            first = max_matchings[0]
            candidate_pairs = [(s, first[s]) for s in all_students if first.get(s, "") != ""]
            for s, w in candidate_pairs:
                if all(m.get(s) == w for m in max_matchings):
                    forced.append([s, w])
            forced.sort()
        
        # example: among max matchings, find the lexicographically smallest vector
        # when listing assigned workshops in student ID ascending order
        # Unassigned = ""
        def matching_to_vector(m):
            return tuple(m.get(s, "") for s in all_students)
        
        best_vector = min(matching_to_vector(m) for m in max_matchings)
        example = list(best_vector)
        
        results.append({
            "sizes": sizes,
            "forced": forced,
            "example": example
        })
    
    return results


def _student_pref_rank(student, workshop, prefs):
    """Return preference rank for student over workshop. Lower = more preferred.
    None means not acceptable."""
    s_prefs = prefs.get(student, [])
    for rank, group in enumerate(s_prefs):
        if workshop in group:
            return rank
    return None


def _room_priority_rank(workshop, tier, rooms):
    """Return priority rank for room over student tier. Lower = higher priority.
    None means tier not accepted."""
    room_tiers = rooms[workshop]["tiers"]
    for rank, tier_group in enumerate(room_tiers):
        if tier in tier_group:
            return rank
    return None


def _is_blocking(s, w, matching, student_options, prefs, rooms, left, capacities):
    """Check if (s, w) is a blocking pair for the given matching."""
    cap = capacities.get(w, 0)
    if cap <= 0:
        return False
    
    # Check if s finds w acceptable
    if w not in student_options.get(s, []):
        return False
    
    # Check if s strictly prefers w to current assignment
    current_w = matching.get(s, "")
    if current_w == w:
        return False  # Already matched here
    
    if current_w == "":
        # s is unmatched, any acceptable w is strictly preferred
        s_prefers = True
    else:
        cur_rank = _student_pref_rank(s, current_w, prefs)
        new_rank = _student_pref_rank(s, w, prefs)
        if new_rank is None:
            return False
        s_prefers = new_rank < cur_rank
    
    if not s_prefers:
        return False
    
    # Check if w has empty seat or strictly prefers s to some assigned student
    assigned_to_w = [ss for ss, ww in matching.items() if ww == w]
    
    if len(assigned_to_w) < cap:
        return True  # Empty seat available
    
    # Check if w strictly prefers s to some assigned student
    s_tier = left[s]
    s_priority = _room_priority_rank(w, s_tier, rooms)
    if s_priority is None:
        return False
    
    for assigned_s in assigned_to_w:
        a_tier = left[assigned_s]
        a_priority = _room_priority_rank(w, a_tier, rooms)
        if a_priority is not None and s_priority < a_priority:
            return True  # w strictly prefers s over assigned_s
    
    return False


def _is_weakly_stable(matching, all_students, open_workshops, student_options, 
                       prefs, rooms, left, capacities):
    """Check if a matching is weakly stable."""
    for s in all_students:
        for w in open_workshops:
            if _is_blocking(s, w, matching, student_options, prefs, rooms, left, capacities):
                return False
    return True


def _enumerate_all_stable(all_students, open_workshops, student_options,
                          prefs, rooms, left, components):
    """Enumerate all weakly stable matchings by decomposing into components."""
    
    # For each component, enumerate all stable matchings independently
    # Then combine via cartesian product
    
    capacities = {w: rooms[w]["capacity"] for w in open_workshops}
    
    # Students not in any component (no acceptable options) are always unmatched
    component_students = set()
    for comp_s, comp_w in components:
        component_students.update(comp_s)
    
    isolated_students = [s for s in all_students if s not in component_students]
    
    # For each component, enumerate all valid matchings and filter stable ones
    component_matchings = []
    
    for comp_s, comp_w in components:
        comp_students = sorted(comp_s)
        comp_workshops = sorted(comp_w)
        comp_caps = {w: capacities[w] for w in comp_workshops}
        
        # Enumerate all possible assignments for students in this component
        # Each student can be assigned to one of their acceptable workshops (within component) or unmatched
        student_choices = []
        for s in comp_students:
            choices = [""] + [w for w in student_options[s] if w in comp_w]
            student_choices.append(choices)
        
        # Generate all possible matchings and check capacity + stability
        stable_matchings = []
        
        for assignment in product(*student_choices):
            matching = {}
            for i, s in enumerate(comp_students):
                matching[s] = assignment[i]
            
            # Check capacity constraints
            valid = True
            workshop_counts = {}
            for s, w in matching.items():
                if w != "":
                    workshop_counts[w] = workshop_counts.get(w, 0) + 1
            
            for w, count in workshop_counts.items():
                if count > comp_caps.get(w, 0):
                    valid = False
                    break
            
            if not valid:
                continue
            
            # Check weak stability within this component
            # Need to check blocking pairs only within component
            is_stable = True
            for s in comp_students:
                for w in comp_workshops:
                    if _is_blocking_component(s, w, matching, student_options, 
                                             prefs, rooms, left, comp_caps, comp_students):
                        is_stable = False
                        break
                if not is_stable:
                    break
            
            if is_stable:
                stable_matchings.append(matching)
        
        component_matchings.append(stable_matchings)
    
    # Combine component matchings via cartesian product
    if not component_matchings:
        # No components - only isolated students, all unmatched
        return [{s: "" for s in all_students}]
    
    all_matchings = []
    for combo in product(*component_matchings):
        full_matching = {s: "" for s in all_students}
        for comp_matching in combo:
            full_matching.update(comp_matching)
        all_matchings.append(full_matching)
    
    return all_matchings


def _is_blocking_component(s, w, matching, student_options, prefs, rooms, left, 
                           capacities, comp_students):
    """Check if (s, w) is a blocking pair within a component."""
    cap = capacities.get(w, 0)
    if cap <= 0:
        return False
    
    if w not in student_options.get(s, []):
        return False
    
    current_w = matching.get(s, "")
    if current_w == w:
        return False
    
    if current_w == "":
        s_prefers = True
    else:
        cur_rank = _student_pref_rank(s, current_w, prefs)
        new_rank = _student_pref_rank(s, w, prefs)
        if new_rank is None:
            return False
        s_prefers = new_rank < cur_rank
    
    if not s_prefers:
        return False
    
    assigned_to_w = [ss for ss in comp_students if matching.get(ss) == w]
    
    if len(assigned_to_w) < cap:
        return True
    
    s_tier = left[s]
    s_priority = _room_priority_rank(w, s_tier, rooms)
    if s_priority is None:
        return False
    
    for assigned_s in assigned_to_w:
        a_tier = left[assigned_s]
        a_priority = _room_priority_rank(w, a_tier, rooms)
        if a_priority is not None and s_priority < a_priority:
            return True
    
    return False
