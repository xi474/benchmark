from fractions import Fraction


def compute(payload):
    """按 method ID、profile 名输出 [各答案吸收概率,各答案加权成本质量]；向量元素均为约分的 [分子,分母]，保留 answers 顺序。"""
    methods = payload["methods"]
    profiles = payload["profiles"]
    answers = payload["answers"]
    answer_set = set(answers)
    answer_index = {a: i for i, a in enumerate(answers)}
    n_answers = len(answers)

    result = {}

    for method in methods:
        mid = method["id"]
        start = method["start"]
        graphs = method["graphs"]
        result[mid] = {}

        for profile_name in profiles:
            graph = graphs.get(profile_name, {})
            # Collect non-terminal states
            non_terminals = list(graph.keys())
            nt_index = {s: i for i, s in enumerate(non_terminals)}
            n_nt = len(non_terminals)

            # Build transition info
            # For each non-terminal state, list of (target, weight, cost)
            edges = {}
            for s in non_terminals:
                edges[s] = graph[s]

            # Solve for absorption probabilities p[s][a] for each answer a
            # p[s][a] = sum_{(t,w,c) in edges[s]} (w/W_s) * (1 if t==a else p[t][a] if t not in answer_set else 0)
            # Rearranged: p[s][a] - sum_{t not in answer_set} (w/W_s)*p[t][a] = sum_{t==a} (w/W_s)

            # We solve one system per answer, but can do all at once
            # For each answer a, build Ax = b where x = p[*][a]

            # Also solve for c[s][a] = weighted cost quality
            # c[s][a] = sum_{(t,w,cost) in edges[s]} (w/W_s) * (cost if t==a else (cost*p[t][a] + c[t][a]) if t not in answer_set else 0)
            # Rearranged: c[s][a] - sum_{t not in answer_set} (w/W_s)*c[t][a] = sum_{(t,w,cost)} (w/W_s)*(cost if t==a else cost*p[t][a] if t not in answer_set else 0)

            # First solve absorption probabilities
            # p_vals[s_idx][a_idx] = absorption prob from state s to answer a
            p_vals = [[Fraction(0)] * n_answers for _ in range(n_nt)]

            if n_nt > 0:
                for a_idx, ans in enumerate(answers):
                    # Build matrix A and vector b
                    # A[i][j] = delta(i,j) - sum of (w/W) for edges from state i to non-terminal j
                    # b[i] = sum of (w/W) for edges from state i directly to answer ans
                    A = [[Fraction(0)] * n_nt for _ in range(n_nt)]
                    b = [Fraction(0)] * n_nt

                    for s in non_terminals:
                        si = nt_index[s]
                        edge_list = edges[s]
                        W = sum(w for _, w, _ in edge_list)
                        if W == 0:
                            continue
                        A[si][si] = Fraction(1)
                        for t, w, c in edge_list:
                            if t == ans:
                                b[si] += Fraction(w, W)
                            elif t in answer_set:
                                pass  # other answer, contributes 0
                            else:
                                ti = nt_index[t]
                                A[si][ti] -= Fraction(w, W)

                    # Solve Ax = b using Gaussian elimination with Fractions
                    x = _solve_linear(A, b, n_nt)
                    for si in range(n_nt):
                        p_vals[si][a_idx] = x[si]

            # Now solve for weighted cost quality c[s][a]
            c_vals = [[Fraction(0)] * n_answers for _ in range(n_nt)]

            if n_nt > 0:
                for a_idx, ans in enumerate(answers):
                    A = [[Fraction(0)] * n_nt for _ in range(n_nt)]
                    b = [Fraction(0)] * n_nt

                    for s in non_terminals:
                        si = nt_index[s]
                        edge_list = edges[s]
                        W = sum(w for _, w, _ in edge_list)
                        if W == 0:
                            continue
                        A[si][si] = Fraction(1)
                        rhs = Fraction(0)
                        for t, w, cost in edge_list:
                            wf = Fraction(w, W)
                            if t == ans:
                                rhs += wf * cost
                            elif t in answer_set:
                                pass
                            else:
                                ti = nt_index[t]
                                A[si][ti] -= wf
                                rhs += wf * cost * p_vals[ti][a_idx]
                        b[si] = rhs

                    x = _solve_linear(A, b, n_nt)
                    for si in range(n_nt):
                        c_vals[si][a_idx] = x[si]

            # Extract results for start state
            if start in answer_set:
                # Start is itself an answer - immediate absorption
                abs_probs = [Fraction(0)] * n_answers
                abs_probs[answer_index[start]] = Fraction(1)
                wcost = [Fraction(0)] * n_answers
                # cost is 0 since no transition needed
            elif start in nt_index:
                si = nt_index[start]
                abs_probs = [p_vals[si][a] for a in range(n_answers)]
                wcost = [c_vals[si][a] for a in range(n_answers)]
            else:
                # Start state not in graph and not an answer - shouldn't happen normally
                # but handle gracefully: no absorption
                abs_probs = [Fraction(0)] * n_answers
                wcost = [Fraction(0)] * n_answers

            # Convert to [numerator, denominator] format
            abs_probs_out = [[int(f.numerator), int(f.denominator)] for f in abs_probs]
            wcost_out = [[int(f.numerator), int(f.denominator)] for f in wcost]

            result[mid][profile_name] = [abs_probs_out, wcost_out]

    return result


def _solve_linear(A, b, n):
    """Solve Ax = b using Gaussian elimination with exact Fractions. Returns list of Fractions."""
    if n == 0:
        return []

    # Augmented matrix
    M = [row[:] + [b[i]] for i, row in enumerate(A)]

    # Forward elimination with partial pivoting
    pivot_row = [0] * n
    for col in range(n):
        # Find pivot
        best = -1
        for row in range(col, n):
            if M[row][col] != 0:
                best = row
                break
        if best == -1:
            # Singular or underdetermined; leave as zero
            continue
        # Swap
        M[col], M[best] = M[best], M[col]
        pv = M[col][col]
        # Scale pivot row
        for j in range(col, n + 1):
            M[col][j] /= pv
        # Eliminate
        for row in range(n):
            if row != col and M[row][col] != 0:
                factor = M[row][col]
                for j in range(col, n + 1):
                    M[row][j] -= factor * M[col][j]

    # Back substitution (already in reduced row echelon form)
    x = [Fraction(0)] * n
    for i in range(n):
        x[i] = M[i][n]

    return x
