from math import gcd
from collections import deque


def _simplest(num, den):
    """Return [numerator, denominator] in simplest form with positive denominator."""
    if den < 0:
        num, den = -num, -den
    g = gcd(abs(num), abs(den))
    return [num // g, den // g]


def compute(payload):
    """输出 [先验映射,方法提前决胜表]。先验为最简分数。每种方法列出从零票起可达的计数状态（键为逗号分隔的答案票数）；值是已经胜出的答案下标或 null。决胜后不扩展。"""
    profiles = payload["profiles"]
    methods = payload["methods"]
    answers = payload["answers"]
    n_answers = len(answers)

    # --- Prior mapping ---
    total_weight = sum(profiles.values())
    prior_map = {}
    for pname, w in profiles.items():
        prior_map[pname] = _simplest(w, total_weight)

    # --- Early-decision tables per method ---
    decision_tables = {}

    for method in methods:
        max_votes = method["votes"]
        table = {}

        # BFS from zero state
        zero_state = tuple([0] * n_answers)
        queue = deque()
        queue.append(zero_state)
        visited = set()
        visited.add(zero_state)

        while queue:
            state = queue.popleft()
            total_cast = sum(state)
            remaining = max_votes - total_cast

            # Determine current leader: highest count, tiebreak by answers order (lower index wins)
            leader_idx = 0
            leader_count = state[0]
            for i in range(1, n_answers):
                if state[i] > leader_count:
                    leader_count = state[i]
                    leader_idx = i

            # Check if leader is unassailable
            # Even if ALL remaining votes go to any single competitor, leader still wins
            decisive = True
            if remaining == 0:
                # No more votes; leader wins (could be a tie resolved by index)
                decisive = True
            else:
                # For each other answer, check if giving all remaining to that answer
                # would make it strictly beat the leader
                for i in range(n_answers):
                    if i == leader_idx:
                        continue
                    # If this competitor gets all remaining votes
                    new_count = state[i] + remaining
                    if new_count > leader_count:
                        decisive = False
                        break
                    elif new_count == leader_count:
                        # Tie: tiebreak goes to lower index
                        if i < leader_idx:
                            decisive = False
                            break

            state_key = ",".join(str(c) for c in state)

            if decisive:
                table[state_key] = leader_idx
                # Don't expand decided states
            else:
                table[state_key] = None
                # Expand: add one vote to each answer
                if remaining > 0:
                    for i in range(n_answers):
                        new_state = list(state)
                        new_state[i] += 1
                        new_state_t = tuple(new_state)
                        if new_state_t not in visited:
                            visited.add(new_state_t)
                            queue.append(new_state_t)

        decision_tables[method["id"]] = table

    return [prior_map, decision_tables]
