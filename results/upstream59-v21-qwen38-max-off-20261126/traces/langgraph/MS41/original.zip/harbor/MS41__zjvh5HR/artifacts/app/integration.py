from fractions import Fraction


def _to_frac(pair):
    """Convert [num, den] to Fraction."""
    return Fraction(pair[0], pair[1])


def _from_frac(f):
    """Convert Fraction to [num, den] in simplest form with positive denominator."""
    return [int(f.numerator), int(f.denominator)]


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = [prior_map, early_decision_tables]
      prior_map: {profile_name: [num, den]}
      early_decision_tables: {method_id: {state_key: winner_index_or_null}}
    
    right = {method_id: {profile_name: [absorption_probs, weighted_cost_quality]}}
      absorption_probs: [[num,den], ...] per answer
      weighted_cost_quality: [[num,den], ...] per answer
    
    Returns: sorted list of method results.
    """
    answers = payload["answers"]
    correct = payload["correct"]
    n_answers = len(answers)
    correct_idx = answers.index(correct)

    prior_map, decision_tables = left

    methods_results = []

    for method in payload["methods"]:
        mid = method["id"]
        max_votes = method["votes"]
        table = decision_tables[mid]
        method_data = right[mid]

        # For each profile, compute prob, unresolved, launches, cost_quality
        # Then average over profiles using prior weights

        overall_prob = [Fraction(0)] * n_answers
        overall_unresolved = Fraction(0)
        overall_launches = Fraction(0)
        overall_cost_correct_num = Fraction(0)  # E[cost * I(correct)]
        overall_prob_correct = Fraction(0)

        for pname, prior_pair in prior_map.items():
            prior = _to_frac(prior_pair)
            abs_probs_raw, wcost_raw = method_data[pname]

            # Single ballot absorption probabilities and weighted cost quality
            q = [_to_frac(abs_probs_raw[a]) for a in range(n_answers)]
            c = [_to_frac(wcost_raw[a]) for a in range(n_answers)]
            u = Fraction(1) - sum(q)  # unresolved probability for single ballot

            # Build reachable states via BFS from (0,...,0)
            zero_state = tuple([0] * n_answers)
            
            # We need to enumerate all reachable non-terminal states
            # A state is terminal if it's decisive (table says non-null) or sum == max_votes
            from collections import deque
            queue = deque()
            queue.append(zero_state)
            visited = set()
            visited.add(zero_state)
            all_states = []

            while queue:
                state = queue.popleft()
                all_states.append(state)
                state_key = ",".join(str(x) for x in state)
                total = sum(state)

                # Check if terminal
                if state_key in table and table[state_key] is not None:
                    continue  # decisive, don't expand
                if total >= max_votes:
                    continue  # no more votes

                # Expand
                for i in range(n_answers):
                    new_state = list(state)
                    new_state[i] += 1
                    ns = tuple(new_state)
                    if ns not in visited:
                        visited.add(ns)
                        queue.append(ns)

            # Process states in reverse order of total count (topological order)
            # States with higher total are processed first
            all_states.sort(key=lambda s: sum(s), reverse=True)

            # For each state, compute:
            # g[s][a] = P(answer a wins from state s)
            # f[s] = P(unresolved from state s)
            # h[s] = E[additional ballots launched from state s]
            # k[s] = E[total future cost * I(correct wins) from state s]

            g = {}  # state -> list of Fractions
            f = {}  # state -> Fraction
            h = {}  # state -> Fraction
            k = {}  # state -> Fraction

            for state in all_states:
                state_key = ",".join(str(x) for x in state)
                total = sum(state)

                # Determine if terminal
                is_decisive = state_key in table and table[state_key] is not None
                is_max_votes = total >= max_votes

                if is_decisive or is_max_votes:
                    # Terminal state
                    if is_decisive:
                        winner = table[state_key]
                    else:
                        # Determine leader: highest count, tiebreak by lower index
                        winner = 0
                        best_count = state[0]
                        for i in range(1, n_answers):
                            if state[i] > best_count:
                                best_count = state[i]
                                winner = i
                    
                    g[state] = [Fraction(1) if i == winner else Fraction(0) for i in range(n_answers)]
                    f[state] = Fraction(0)
                    h[state] = Fraction(0)
                    k[state] = Fraction(0)
                else:
                    # Non-terminal: launch one more ballot
                    g_s = [Fraction(0)] * n_answers
                    f_s = u  # unresolved contribution
                    h_s = Fraction(1)  # we launch 1 ballot
                    k_s = Fraction(0)

                    for a in range(n_answers):
                        if q[a] == 0:
                            continue
                        # Next state after voting for answer a
                        ns_list = list(state)
                        ns_list[a] += 1
                        ns = tuple(ns_list)

                        for ans_idx in range(n_answers):
                            g_s[ans_idx] += q[a] * g[ns][ans_idx]
                        f_s += q[a] * f[ns]
                        h_s += q[a] * h[ns]
                        # k[s] = sum_a (c[a] * g[s'][correct_idx] + q[a] * k[s'])
                        k_s += c[a] * g[ns][correct_idx] + q[a] * k[ns]

                    g[state] = g_s
                    f[state] = f_s
                    h[state] = h_s
                    k[state] = k_s

            # Accumulate profile contribution
            init = zero_state
            for a in range(n_answers):
                overall_prob[a] += prior * g[init][a]
            overall_unresolved += prior * f[init]
            overall_launches += prior * h[init]
            overall_cost_correct_num += prior * k[init]
            overall_prob_correct += prior * g[init][correct_idx]

        # Compute cost_if_correct
        if overall_prob_correct == 0:
            cost_if_correct = None
        else:
            cost_if_correct = _from_frac(overall_cost_correct_num / overall_prob_correct)

        result = {
            "id": mid,
            "prob": [_from_frac(overall_prob[a]) for a in range(n_answers)],
            "unresolved": _from_frac(overall_unresolved),
            "launches": _from_frac(overall_launches),
            "cost_if_correct": cost_if_correct,
        }
        methods_results.append(result)

    # Sort by correctness probability descending, then method id ascending
    def sort_key(r):
        prob_correct = _to_frac(r["prob"][correct_idx])
        return (-prob_correct, r["id"])

    methods_results.sort(key=sort_key)

    return methods_results
