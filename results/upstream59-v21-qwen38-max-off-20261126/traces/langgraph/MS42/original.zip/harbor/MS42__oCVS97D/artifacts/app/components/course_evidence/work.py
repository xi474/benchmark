def compute(payload):
    """为每门课生成 [项目统计,传递可达表]；统计行 [ID,标签,[成绩和分子,分母],非空数] 按 ID 排序，保留零成绩。可达表的值为有序 ID 数组。"""
    courses = payload.get("courses", {})
    result = {}

    for course_code, course_data in courses.items():
        items = course_data.get("items", [])
        edges = course_data.get("edges", [])

        # Build item stats
        stats = []
        all_ids = []
        for item in items:
            item_id = item[0]
            label = item[1]
            scores = item[2] if len(item) > 2 else []

            all_ids.append(item_id)

            # Compute sum and count of non-null scores
            score_sum = 0
            non_null_count = 0
            for s in scores:
                if s is not None:
                    score_sum += s
                    non_null_count += 1

            stats.append([item_id, label, [score_sum, non_null_count], non_null_count])

        # Sort stats by ID
        stats.sort(key=lambda x: x[0])

        # Build transitive reachability table
        # First build adjacency list from edges
        adj = {item_id: set() for item_id in all_ids}
        for edge in edges:
            src, dst = edge[0], edge[1]
            if src in adj:
                adj[src].add(dst)

        # Compute transitive closure using BFS/DFS from each node
        reachability = {}
        for start_id in all_ids:
            # BFS to find all reachable nodes
            visited = set()
            queue = list(adj.get(start_id, set()))
            while queue:
                node = queue.pop(0)
                if node not in visited:
                    visited.add(node)
                    for neighbor in adj.get(node, set()):
                        if neighbor not in visited:
                            queue.append(neighbor)
            reachability[start_id] = sorted(visited)

        result[course_code] = [stats, reachability]

    return result
