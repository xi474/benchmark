from itertools import permutations


def compute(payload):
    """返回 [所有可行映射位掩码,旧标签到各新标签的掩码映射]；位序按新标签升序的排列枚举。"""
    rubrics = payload["rubrics"]
    old_tags = sorted(rubrics.keys())
    # Collect all new tags and sort them
    new_tags_set = set()
    for allowed in rubrics.values():
        new_tags_set.update(allowed)
    new_tags = sorted(new_tags_set)
    n = len(old_tags)

    # For each old tag, compute the set of allowed new tag indices
    new_tag_index = {t: i for i, t in enumerate(new_tags)}
    allowed_indices = []
    for ot in old_tags:
        allowed_indices.append(set(new_tag_index[nt] for nt in rubrics[ot]))

    # Enumerate all bijections (permutations of new tag indices assigned to old tags)
    # A bijection is valid if old_tags[i] -> perm[i] is allowed for all i
    valid_bijections = []
    for perm in permutations(range(n)):
        valid = True
        for i in range(n):
            if perm[i] not in allowed_indices[i]:
                valid = False
                break
        if valid:
            valid_bijections.append(perm)

    # Number of valid bijections
    num_valid = len(valid_bijections)

    # All valid mapping bitmask: bit i set if bijection i is valid
    all_valid_mask = 0
    for i in range(num_valid):
        all_valid_mask |= (1 << i)

    # For each (old_tag, new_tag), compute bitmask over bijection indices
    old_to_new_bitmask = {}
    for oi, ot in enumerate(old_tags):
        old_to_new_bitmask[ot] = {}
        for nt in rubrics[ot]:
            ni = new_tag_index[nt]
            mask = 0
            for bi, perm in enumerate(valid_bijections):
                if perm[oi] == ni:
                    mask |= (1 << bi)
            old_to_new_bitmask[ot][nt] = mask

    return [all_valid_mask, old_to_new_bitmask]
