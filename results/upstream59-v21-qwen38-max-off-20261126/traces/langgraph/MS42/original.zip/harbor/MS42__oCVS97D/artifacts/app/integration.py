from itertools import combinations
from math import gcd


def _reconstruct_bijections(all_valid_mask, old_to_new_bitmask):
    """Reconstruct all valid bijections from bitmask data.
    
    Returns list of dicts {old_tag: new_tag} for each valid bijection.
    Also returns sorted lists of old_tags and new_tags.
    """
    # Determine number of bijections
    num_bijections = all_valid_mask.bit_length() if all_valid_mask > 0 else 0
    
    old_tags = sorted(old_to_new_bitmask.keys())
    # Collect all new tags
    new_tags_set = set()
    for ot in old_tags:
        new_tags_set.update(old_to_new_bitmask[ot].keys())
    new_tags = sorted(new_tags_set)
    
    # For each bijection index, reconstruct the mapping
    bijections = []
    for bi in range(num_bijections):
        if not (all_valid_mask & (1 << bi)):
            continue
        mapping = {}
        for ot in old_tags:
            for nt in new_tags:
                if nt in old_to_new_bitmask[ot]:
                    if old_to_new_bitmask[ot][nt] & (1 << bi):
                        mapping[ot] = nt
                        break
        bijections.append(mapping)
    
    return bijections, old_tags, new_tags


def _parse_course_prefix(code):
    """Extract prefix from course code like 'ENG-2013J' -> ('ENG', '2013J')."""
    # Find the last '-' that separates prefix from year
    idx = code.rfind('-')
    if idx == -1:
        return None, None
    return code[:idx], code[idx+1:]


def _get_reachability_relation(reach_table, id1, id2):
    """Determine the order relation between id1 and id2.
    Returns: 'lt' if id1 reaches id2, 'gt' if id2 reaches id1, 
             'eq' if same, 'incomp' if incomparable.
    """
    if id1 == id2:
        return 'eq'
    id1_reaches_id2 = id2 in reach_table.get(id1, [])
    id2_reaches_id1 = id1 in reach_table.get(id2, [])
    if id1_reaches_id2 and id2_reaches_id1:
        # This shouldn't happen in a DAG unless they're the same node
        return 'eq'
    if id1_reaches_id2:
        return 'lt'
    if id2_reaches_id1:
        return 'gt'
    return 'incomp'


def _check_order_consistency(pairs, old_reach, new_reach):
    """Check if a set of pairs preserves the partial order exactly.
    pairs: list of (old_id, new_id)
    """
    for i in range(len(pairs)):
        for j in range(i + 1, len(pairs)):
            old_i, new_i = pairs[i]
            old_j, new_j = pairs[j]
            old_rel = _get_reachability_relation(old_reach, old_i, old_j)
            new_rel = _get_reachability_relation(new_reach, new_i, new_j)
            if old_rel != new_rel:
                return False
    return True


def _compute_alignment_support(pairs, old_stats_map, new_stats_map):
    """Compute support for an alignment: sum of min(non_null_old, non_null_new) for each pair."""
    total = 0
    for old_id, new_id in pairs:
        old_nonnull = old_stats_map[old_id][3]  # non_null_count
        new_nonnull = new_stats_map[new_id][3]
        total += min(old_nonnull, new_nonnull)
    return total


def _compute_drift_for_alignment(all_pairs, course_data):
    """Compute drift for an alignment.
    Merge all non-null scores from paired new items, compute mean.
    Merge all non-null scores from paired old items, compute mean.
    Return new_mean - old_mean as a fraction [numerator, denominator].
    """
    # We need original score arrays, but we only have stats [sum, count].
    # Actually, we need to go back to the payload for raw scores.
    # But combine() receives payload too! Let me restructure.
    pass


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    rubrics = payload.get("rubrics", {})
    courses = payload.get("courses", {})
    
    all_valid_mask, old_to_new_bitmask = left
    course_evidence = right
    
    # Reconstruct all valid bijections
    bijections, old_tags_list, new_tags_list = _reconstruct_bijections(all_valid_mask, old_to_new_bitmask)
    
    # Group courses by prefix
    prefix_courses = {}  # prefix -> {'old': course_code, 'new': course_code}
    for code in courses:
        prefix, suffix = _parse_course_prefix(code)
        if prefix is None:
            continue
        if prefix not in prefix_courses:
            prefix_courses[prefix] = {}
        if suffix == '2013J':
            prefix_courses[prefix]['old'] = code
        elif suffix == '2014J':
            prefix_courses[prefix]['new'] = code
    
    # Only keep prefixes with both old and new
    valid_prefixes = {p: v for p, v in prefix_courses.items() if 'old' in v and 'new' in v}
    
    if not valid_prefixes:
        return {"pairs": 0, "support": 0, "ways": 1, "forced": [], "drift": None}
    
    # For each valid prefix, prepare item data
    # Build per-prefix candidate pairs for each bijection
    # Then find optimal alignments
    
    # For each bijection, for each prefix, build candidate (old_item, new_item) pairs
    # where labels match under that bijection and both have non-null scores
    
    # Pre-compute stats maps and reachability for each course
    course_stats = {}  # course_code -> {item_id: stat_row}
    course_reach = {}  # course_code -> reachability dict
    for code, evidence in course_evidence.items():
        stats_list, reach_dict = evidence
        stats_map = {}
        for row in stats_list:
            stats_map[row[0]] = row  # [ID, label, [sum, count], non_null_count]
        course_stats[code] = stats_map
        course_reach[code] = reach_dict
    
    # For each bijection and each prefix, enumerate all valid subsets of pairs
    # that respect ordering constraints
    
    # Strategy: For each bijection, for each prefix, find all valid pair subsets
    # Then combine across prefixes (pairs from different prefixes are independent)
    # Maximize total pairs, then total support
    
    # Since constraints are small, we can enumerate
    
    # First, for each bijection and prefix, get candidate pairs
    def get_candidate_pairs(bijection, prefix):
        old_code = valid_prefixes[prefix]['old']
        new_code = valid_prefixes[prefix]['new']
        old_sm = course_stats.get(old_code, {})
        new_sm = course_stats.get(new_code, {})
        
        candidates = []
        for old_id, old_row in old_sm.items():
            old_label = old_row[1]
            old_nonnull = old_row[3]
            if old_nonnull == 0:
                continue
            if old_label not in bijection:
                continue
            mapped_new_label = bijection[old_label]
            for new_id, new_row in new_sm.items():
                new_label = new_row[1]
                new_nonnull = new_row[3]
                if new_nonnull == 0:
                    continue
                if new_label == mapped_new_label:
                    candidates.append((old_id, new_id))
        return candidates
    
    # For each bijection, find best alignment across all prefixes
    # An alignment is a union of per-prefix pair subsets, each respecting order
    
    # For each bijection and prefix, enumerate all valid subsets (respecting order)
    # Then find the combination across prefixes that maximizes pairs then support
    
    # Since prefixes are independent (order constraints only within same course),
    # we can optimize each prefix independently for a given bijection
    
    # For each bijection and prefix, find all maximal valid subsets
    # Actually, we want the subset with max pairs, then max support
    # Since items are small (≤6), we can enumerate all subsets
    
    def find_best_subsets_for_prefix(bijection, prefix):
        """Find all subsets of candidate pairs that respect order constraints.
        Return list of (pairs_tuple, num_pairs, support)."""
        candidates = get_candidate_pairs(bijection, prefix)
        old_code = valid_prefixes[prefix]['old']
        new_code = valid_prefixes[prefix]['new']
        old_reach = course_reach.get(old_code, {})
        new_reach = course_reach.get(new_code, {})
        old_sm = course_stats.get(old_code, {})
        new_sm = course_stats.get(new_code, {})
        
        n = len(candidates)
        valid_subsets = []
        
        # Enumerate all subsets
        for mask in range(1 << n):
            subset = []
            used_old = set()
            used_new = set()
            valid = True
            for i in range(n):
                if mask & (1 << i):
                    old_id, new_id = candidates[i]
                    # Each item used at most once
                    if old_id in used_old or new_id in used_new:
                        valid = False
                        break
                    used_old.add(old_id)
                    used_new.add(new_id)
                    subset.append((old_id, new_id))
            
            if not valid:
                continue
            
            # Check order consistency
            if not _check_order_consistency(subset, old_reach, new_reach):
                continue
            
            # Compute support
            support = 0
            for old_id, new_id in subset:
                support += min(old_sm[old_id][3], new_sm[new_id][3])
            
            # Use frozenset for deduplication
            pairs_key = tuple(sorted(subset))
            valid_subsets.append((pairs_key, len(subset), support))
        
        # Deduplicate by pairs_key
        seen = {}
        for pk, np, sp in valid_subsets:
            if pk not in seen:
                seen[pk] = (np, sp)
        
        return list(seen.items())  # [(pairs_key, (num_pairs, support)), ...]
    
    # For each bijection, find best alignment across all prefixes
    # Since prefixes are independent, for each prefix pick the best subset
    # But we need to track ALL optimal alignments (across bijections) for ways/forced/drift
    
    # Collect all unique alignment sets with their (total_pairs, total_support)
    # alignment_key = tuple of sorted (prefix, old_id, new_id) triples
    
    all_alignments = {}  # alignment_key -> set of bijection indices that produce it
    
    for bi_idx, bijection in enumerate(bijections):
        # For each prefix, get all valid subsets
        prefix_options = {}  # prefix -> [(pairs_key, (num_pairs, support))]
        for prefix in valid_prefixes:
            prefix_options[prefix] = find_best_subsets_for_prefix(bijection, prefix)
        
        # Find the best combination across prefixes
        # Since prefixes are independent, we can pick the best for each prefix
        # But we need to enumerate ALL combinations that achieve the global optimum
        
        # First find max total pairs achievable
        # For each prefix, find max pairs among its valid subsets
        prefix_max_pairs = {}
        for prefix in valid_prefixes:
            options = prefix_options[prefix]
            if not options:
                prefix_max_pairs[prefix] = 0
            else:
                prefix_max_pairs[prefix] = max(np for _, (np, _) in options)
        
        total_max_pairs = sum(prefix_max_pairs.values())
        
        # Now find max total support among combinations achieving total_max_pairs
        # For each prefix, filter to subsets with max pairs, then find max support
        prefix_best_support = {}
        for prefix in valid_prefixes:
            mp = prefix_max_pairs[prefix]
            options = prefix_options[prefix]
            if mp == 0:
                prefix_best_support[prefix] = 0
            else:
                prefix_best_support[prefix] = max(sp for _, (np, sp) in options if np == mp)
        
        total_max_support = sum(prefix_best_support.values())
        
        # Now enumerate all combinations achieving (total_max_pairs, total_max_support)
        # For each prefix, get all subsets with (max_pairs, max_support)
        prefix_optimal = {}
        for prefix in valid_prefixes:
            mp = prefix_max_pairs[prefix]
            ms = prefix_best_support[prefix]
            options = prefix_options[prefix]
            if mp == 0:
                prefix_optimal[prefix] = [()]  # empty alignment
            else:
                prefix_optimal[prefix] = [pk for pk, (np, sp) in options if np == mp and sp == ms]
        
        # Generate all combinations
        prefixes_list = sorted(valid_prefixes.keys())
        
        def generate_combos(idx, current_triples):
            if idx == len(prefixes_list):
                key = tuple(sorted(current_triples))
                if key not in all_alignments:
                    all_alignments[key] = set()
                all_alignments[key].add(bi_idx)
                return
            prefix = prefixes_list[idx]
            for pk in prefix_optimal[prefix]:
                new_triples = list(current_triples)
                for old_id, new_id in pk:
                    new_triples.append((prefix, old_id, new_id))
                generate_combos(idx + 1, new_triples)
        
        generate_combos(0, [])
    
    # Also consider the empty alignment
    empty_key = ()
    if empty_key not in all_alignments:
        all_alignments[empty_key] = set()
    # Empty alignment is always valid (produced by any bijection choosing no pairs)
    # But we only care about optimal ones
    
    if not all_alignments:
        return {"pairs": 0, "support": 0, "ways": 1, "forced": [], "drift": None}
    
    # Find optimal: max pairs, then max support
    # Compute pairs and support for each alignment
    alignment_scores = {}
    for akey in all_alignments:
        num_pairs = len(akey)
        # Compute support
        support = 0
        for prefix, old_id, new_id in akey:
            old_code = valid_prefixes[prefix]['old']
            new_code = valid_prefixes[prefix]['new']
            old_sm = course_stats.get(old_code, {})
            new_sm = course_stats.get(new_code, {})
            support += min(old_sm[old_id][3], new_sm[new_id][3])
        alignment_scores[akey] = (num_pairs, support)
    
    # Find max pairs
    max_pairs = max(np for np, _ in alignment_scores.values())
    # Filter to max pairs
    candidates = {k: v for k, v in alignment_scores.items() if v[0] == max_pairs}
    # Find max support
    max_support = max(sp for _, sp in candidates.values())
    # Filter to optimal
    optimal_keys = [k for k, v in candidates.items() if v[1] == max_support]
    
    ways = len(optimal_keys)
    
    # Forced pairs: intersection of all optimal alignments
    if optimal_keys:
        forced_set = set(optimal_keys[0])
        for ok in optimal_keys[1:]:
            forced_set &= set(ok)
        forced = sorted(forced_set)  # lex sort on (prefix, old_id, new_id)
    else:
        forced = []
    
    # Drift computation
    if max_pairs == 0:
        drift = None
    else:
        drifts = []
        for ok in optimal_keys:
            # Collect all non-null scores from paired items
            old_scores = []
            new_scores = []
            for prefix, old_id, new_id in ok:
                old_code = valid_prefixes[prefix]['old']
                new_code = valid_prefixes[prefix]['new']
                
                # Get original scores from payload
                old_items = courses[old_code]['items']
                new_items = courses[new_code]['items']
                
                for item in old_items:
                    if item[0] == old_id:
                        for s in item[2]:
                            if s is not None:
                                old_scores.append(s)
                
                for item in new_items:
                    if item[0] == new_id:
                        for s in item[2]:
                            if s is not None:
                                new_scores.append(s)
            
            if not old_scores or not new_scores:
                drift_val = 0
            else:
                # Compute as exact fractions
                new_sum = sum(new_scores)
                new_count = len(new_scores)
                old_sum = sum(old_scores)
                old_count = len(old_scores)
                
                # drift = new_sum/new_count - old_sum/old_count
                # = (new_sum * old_count - old_sum * new_count) / (new_count * old_count)
                num = new_sum * old_count - old_sum * new_count
                den = new_count * old_count
                
                if num == 0:
                    drift_val = (0, 1)
                else:
                    g = gcd(abs(num), abs(den))
                    num //= g
                    den //= g
                    if den < 0:
                        num = -num
                        den = -den
                    drift_val = (num, den)
            
            drifts.append(drift_val)
        
        # Min and max drift
        # Compare as fractions
        def frac_value(f):
            return f[0] / f[1]
        
        min_drift = min(drifts, key=frac_value)
        max_drift = max(drifts, key=frac_value)
        
        drift = [list(min_drift), list(max_drift)]
    
    return {
        "pairs": max_pairs,
        "support": max_support,
        "ways": ways,
        "forced": [list(f) for f in forced],
        "drift": drift
    }
