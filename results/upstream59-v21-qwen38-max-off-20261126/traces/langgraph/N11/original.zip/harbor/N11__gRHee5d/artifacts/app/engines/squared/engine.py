"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build


def mat_mul(A, B):
    """Multiply two dense integer matrices (lists of lists)."""
    rows_a = len(A)
    cols_a = len(A[0])
    cols_b = len(B[0])
    result = []
    for i in range(rows_a):
        row = []
        for j in range(cols_b):
            s = 0
            for k in range(cols_a):
                s += A[i][k] * B[k][j]
            row.append(s)
        result.append(row)
    return result


def mat_add(A, B):
    """Add two dense integer matrices."""
    rows = len(A)
    cols = len(A[0])
    return [[A[i][j] + B[i][j] for j in range(cols)] for i in range(rows)]


def is_zero_matrix(data):
    """Check if a dense matrix is all zeros."""
    if data is None:
        return True
    for row in data:
        for val in row:
            if val != 0:
                return False
    return True


def block_multiply(matrix_a, matrix_b, row_sizes, col_sizes):
    """
    Multiply two block matrices. Each is a 2D list of blocks.
    Each block has {rows, cols, data} where data is null or a 2D int list.
    Returns a new block matrix with same block structure.
    """
    n_block_rows = len(matrix_a)
    n_block_cols = len(matrix_b[0])
    # For multiplication: A is (n_block_rows x n_inner), B is (n_inner x n_block_cols)
    n_inner = len(matrix_a[0])

    result = []
    for i in range(n_block_rows):
        row = []
        for j in range(n_block_cols):
            r = row_sizes[i]
            c = col_sizes[j]
            # Accumulate sum over inner dimension
            acc = None
            for k in range(n_inner):
                blk_a = matrix_a[i][k]
                blk_b = matrix_b[k][j]
                da = blk_a["data"]
                db = blk_b["data"]
                # If either is null (zero), product is zero - skip
                if da is None or db is None:
                    continue
                prod = mat_mul(da, db)
                if acc is None:
                    acc = prod
                else:
                    acc = mat_add(acc, prod)
            # If acc is None or all zeros, output null
            if acc is None or is_zero_matrix(acc):
                row.append({"rows": r, "cols": c, "data": None})
            else:
                row.append({"rows": r, "cols": c, "data": acc})
        result.append(row)
    return result


def transform(payload, contract):
    matrix = payload["matrix"]
    layout = payload["layout"]
    row_sizes = layout["row_sizes"]
    col_sizes = layout["col_sizes"]

    result_blocks = block_multiply(matrix, matrix, row_sizes, col_sizes)
    return {"layout": layout, "blocks": result_blocks}


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
