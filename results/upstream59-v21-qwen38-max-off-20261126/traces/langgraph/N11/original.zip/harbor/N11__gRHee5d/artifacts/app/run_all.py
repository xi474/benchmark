"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module


def main():
    root = Path(__file__).resolve().parent

    # Load delivery manifest
    delivery = read(root / "delivery.json")

    # Load contracts for each component
    components = ["block_layout", "squared", "cubed"]
    results = {}

    # Execute in dependency order: block_layout first, then squared, then cubed
    for comp_name in components:
        contract_path = root / "engines" / comp_name / "contract.json"
        contract = read(contract_path)
        engine_mod = module(root / "engines" / comp_name, "engine.py")
        result = engine_mod.build_component(root, contract)
        results[comp_name] = result

    # Build final report
    result_file = delivery["result_file"]
    result_value = read(root / result_file)

    final_report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value
    }

    output_path = root / delivery["report"]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )


if __name__ == '__main__':
    main()
