"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import re
import ast
from runtime import build


def _extract_conf_chains(node):
    """Recursively extract conf access chains from an AST node.
    Returns list of lists of strings, each representing a dotted path after 'conf'."""
    chains = []
    if isinstance(node, ast.Attribute):
        # e.g., conf.auto_save.interval -> walk up
        parts = []
        n = node
        while isinstance(n, ast.Attribute):
            parts.append(n.attr)
            n = n.value
        if isinstance(n, ast.Name) and n.id == 'conf':
            parts.reverse()
            chains.append(parts)
        else:
            # recurse into value
            chains.extend(_extract_conf_chains(n))
    elif isinstance(node, ast.Subscript):
        # e.g., conf.aliases['a'] or conf.aliases['a'].propname
        # First get the base chain from .value
        base_chains = _extract_conf_chains(node.value)
        # Get the index/slice
        idx = node.slice
        if isinstance(idx, ast.Constant) and isinstance(idx.value, str):
            sub_key = idx.value
            for chain in base_chains:
                chains.append(chain + [sub_key])
        elif isinstance(idx, ast.Index):
            # Python 3.8 compat
            val = idx.value
            if isinstance(val, ast.Constant) and isinstance(val.value, str):
                for chain in base_chains:
                    chains.append(chain + [val.value])
            elif isinstance(val, ast.Str):
                for chain in base_chains:
                    chains.append(chain + [val.s])
        # If subscript key is not a static string, we still keep base chains as-is? 
        # Per spec: "静态字符串下标" - only static string subscripts
        # If no valid extension, just keep base chains
        if not any(True for c in chains if len(c) > (len(base_chains[0]) if base_chains else 0)):
            chains.extend(base_chains)
    elif isinstance(node, ast.BinOp):
        chains.extend(_extract_conf_chains(node.left))
        chains.extend(_extract_conf_chains(node.right))
    elif isinstance(node, ast.UnaryOp):
        chains.extend(_extract_conf_chains(node.operand))
    elif isinstance(node, ast.Call):
        chains.extend(_extract_conf_chains(node.func))
        for arg in node.args:
            chains.extend(_extract_conf_chains(arg))
        for kw in node.keywords:
            chains.extend(_extract_conf_chains(kw.value))
    elif isinstance(node, ast.Compare):
        chains.extend(_extract_conf_chains(node.left))
        for comp in node.comparators:
            chains.extend(_extract_conf_chains(comp))
    elif isinstance(node, ast.BoolOp):
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    elif isinstance(node, ast.IfExp):
        chains.extend(_extract_conf_chains(node.test))
        chains.extend(_extract_conf_chains(node.body))
        chains.extend(_extract_conf_chains(node.orelse))
    elif isinstance(node, ast.List) or isinstance(node, ast.Tuple) or isinstance(node, ast.Set):
        for elt in node.elts:
            chains.extend(_extract_conf_chains(elt))
    elif isinstance(node, ast.Dict):
        for k in node.keys:
            if k is not None:
                chains.extend(_extract_conf_chains(k))
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    elif isinstance(node, ast.Name):
        pass  # bare name, not a conf chain
    elif isinstance(node, ast.Constant) or isinstance(node, ast.Num) or isinstance(node, ast.Str):
        pass  # literal
    return chains


def _longest_prefix_match(chain_parts, options_set):
    """Given chain parts like ['aliases', 'a', 'propname'], find the longest
    prefix that exists in options_set. Return it or None."""
    best = None
    for i in range(1, len(chain_parts) + 1):
        candidate = '.'.join(chain_parts[:i])
        if candidate in options_set:
            if best is None or len(candidate) > len(best):
                best = candidate
    return best


def transform(payload, contract):
    templates = payload['templates']
    options = payload['options']
    options_set = set(options)

    result = {}
    for tid, text in templates.items():
        deps = set()
        # Find all {{ ... }} expressions
        for match in re.finditer(r'\{\{(.*?)\}\}', text, re.DOTALL):
            expr = match.group(1).strip()
            try:
                tree = ast.parse(expr, mode='eval')
            except SyntaxError:
                continue
            chains = _extract_conf_chains(tree.body)
            for chain in chains:
                matched = _longest_prefix_match(chain, options_set)
                if matched is not None:
                    deps.add(matched)
        result[tid] = sorted(deps)
    return result


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
