"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, build, module


def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    # Load contracts
    td_contract = read(root / "engines/template_dependencies/contract.json")
    ri_contract = read(root / "engines/reverse_index/contract.json")
    su_contract = read(root / "engines/stylesheet_updates/contract.json")

    # 1. template_dependencies (no upstream deps)
    td_mod = module(root, "engines/template_dependencies/engine.py")
    td_result = td_mod.build_component(root, td_contract)

    # 2. reverse_index (depends on template_dependencies output)
    ri_mod = module(root, "engines/reverse_index/engine.py")
    ri_result = ri_mod.build_component(root, ri_contract)

    # 3. stylesheet_updates (depends on template_dependencies + reverse_index outputs)
    su_mod = module(root, "engines/stylesheet_updates/engine.py")
    su_result = su_mod.build_component(root, su_contract)

    # Read result_file
    result_file_path = root / delivery["result_file"]
    result_value = read(result_file_path)

    # Build final report
    component_outputs = delivery["component_outputs"]
    results = {}
    for comp_name, out_path in component_outputs.items():
        results[comp_name] = read(root / out_path)

    final_report = {
        "task": "N17",
        "results": results,
        "result": result_value
    }

    out_dir = root / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "final_report.json").write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )


if __name__ == '__main__':
    main()
