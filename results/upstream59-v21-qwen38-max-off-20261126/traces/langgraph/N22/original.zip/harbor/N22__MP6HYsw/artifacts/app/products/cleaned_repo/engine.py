"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import gzip
import tarfile
import io
import tempfile
import os
import subprocess
import hashlib
import re
from runtime import build


def _extract_repo(bundle_b64, dest):
    """Extract base64 gzip-tar bundle to dest directory."""
    raw = gzip.decompress(base64.b64decode(bundle_b64))
    tf = tarfile.open(fileobj=io.BytesIO(raw))
    tf.extractall(dest)


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def _clean_repo(repo_dir, secret):
    """Remove all traces of the secret from the repo."""
    # 1. Delete reflogs
    logs_dir = os.path.join(repo_dir, '.git', 'logs')
    if os.path.exists(logs_dir):
        import shutil
        shutil.rmtree(logs_dir)

    # 2. Remove ORIG_HEAD if it points to unreachable commit
    orig_head = os.path.join(repo_dir, '.git', 'ORIG_HEAD')
    if os.path.exists(orig_head):
        os.remove(orig_head)

    # 3. Run git gc --prune=now --aggressive to remove unreachable objects
    subprocess.run(['git', 'gc', '--prune=now', '--aggressive'],
                   cwd=repo_dir, capture_output=True, text=True)

    # 4. Also run reflog expire
    subprocess.run(['git', 'reflog', 'expire', '--expire=now', '--all'],
                   cwd=repo_dir, capture_output=True, text=True)

    # 5. Run prune again
    subprocess.run(['git', 'prune', '--expire=now'],
                   cwd=repo_dir, capture_output=True, text=True)

    # 6. Verify no secret objects remain - manually check all remaining objects
    objects_dir = os.path.join(repo_dir, '.git', 'objects')
    pattern = re.compile(re.escape(secret))
    
    # Check loose objects
    for prefix in os.listdir(objects_dir):
        prefix_path = os.path.join(objects_dir, prefix)
        if len(prefix) == 2 and os.path.isdir(prefix_path):
            for suffix in os.listdir(prefix_path):
                obj_hash = prefix + suffix
                result = subprocess.run(
                    ['git', 'cat-file', '-p', obj_hash],
                    cwd=repo_dir, capture_output=True, text=True
                )
                if pattern.search(result.stdout):
                    # Remove this object file
                    os.remove(os.path.join(prefix_path, suffix))

    # 7. Repack to ensure clean state
    subprocess.run(['git', 'repack', '-a', '-d'],
                   cwd=repo_dir, capture_output=True, text=True)
    subprocess.run(['git', 'prune', '--expire=now'],
                   cwd=repo_dir, capture_output=True, text=True)


def _ensure_git_structure(repo_dir):
    """Ensure essential git directories exist for repo recognition."""
    for d in ['refs/heads', 'refs/tags', 'objects/info', 'objects/pack']:
        os.makedirs(os.path.join(repo_dir, '.git', d), exist_ok=True)


def _create_bundle(repo_dir):
    """Create a tar.gz of the repo and return base64."""
    _ensure_git_structure(repo_dir)
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as tf:
        for root, dirs, files in os.walk(repo_dir):
            for f in sorted(files):
                full = os.path.join(root, f)
                arcname = os.path.relpath(full, repo_dir)
                tf.add(full, arcname=arcname)
    return base64.b64encode(buf.getvalue()).decode('ascii')


def _get_files_sha256(repo_dir):
    """Get SHA256 of all non-.git files."""
    result = {}
    for root, dirs, files in os.walk(repo_dir):
        # Skip .git directory
        rel_root = os.path.relpath(root, repo_dir)
        if rel_root.startswith('.git'):
            continue
        dirs[:] = [d for d in dirs if not (rel_root == '.' and d == '.git')]
        for f in sorted(files):
            full = os.path.join(root, f)
            rel = os.path.relpath(full, repo_dir)
            if not rel.startswith('.git'):
                result[rel] = _sha256_file(full)
    return result


def _get_messages(repo_dir):
    """Get commit messages newest first."""
    result = subprocess.run(
        ['git', 'log', '--format=%s'],
        cwd=repo_dir, capture_output=True, text=True
    )
    messages = [line for line in result.stdout.strip().split('\n') if line]
    return messages


def transform(payload, contract):
    bundle = payload['bundle']
    scan_result = payload['scan']
    secret = scan_result['secret']

    with tempfile.TemporaryDirectory() as td:
        _extract_repo(bundle, td)
        _clean_repo(td, secret)
        
        new_bundle = _create_bundle(td)
        files = _get_files_sha256(td)
        messages = _get_messages(td)

    return {
        "bundle": new_bundle,
        "files": files,
        "messages": messages
    }


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
