"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import gzip
import tarfile
import io
import tempfile
import os
import subprocess
import re
from runtime import build


def _extract_repo(bundle_b64, dest):
    """Extract base64 gzip-tar bundle to dest directory."""
    raw = gzip.decompress(base64.b64decode(bundle_b64))
    tf = tarfile.open(fileobj=io.BytesIO(raw))
    tf.extractall(dest)


def _find_secret_in_objects(repo_dir):
    """Enumerate all git objects and find secret[...] markers."""
    # Get all object hashes (reachable + unreachable)
    # First, list all loose objects
    objects_dir = os.path.join(repo_dir, '.git', 'objects')
    all_hashes = []
    for prefix in os.listdir(objects_dir):
        if len(prefix) == 2 and prefix != 'pa':  # skip 'pack' and 'info'
            prefix_dir = os.path.join(objects_dir, prefix)
            if os.path.isdir(prefix_dir):
                for suffix in os.listdir(prefix_dir):
                    all_hashes.append(prefix + suffix)

    # Also check packed objects
    result = subprocess.run(
        ['git', 'rev-list', '--all', '--objects'],
        cwd=repo_dir, capture_output=True, text=True
    )
    for line in result.stdout.strip().split('\n'):
        if line:
            h = line.split()[0]
            if h not in all_hashes:
                all_hashes.append(h)

    # Check fsck for unreachable
    result = subprocess.run(
        ['git', 'fsck', '--unreachable', '--no-reflogs'],
        cwd=repo_dir, capture_output=True, text=True
    )
    for line in result.stdout.strip().split('\n'):
        if line:
            parts = line.split()
            if len(parts) >= 3:
                h = parts[2]
                if h not in all_hashes:
                    all_hashes.append(h)

    # Search each object for secret[...] pattern
    pattern = re.compile(r'secret\[.*?\]')
    for obj_hash in all_hashes:
        result = subprocess.run(
            ['git', 'cat-file', '-p', obj_hash],
            cwd=repo_dir, capture_output=True, text=True
        )
        content = result.stdout
        match = pattern.search(content)
        if match:
            return match.group(0)

    return None


def transform(payload, contract):
    bundle = payload['bundle']
    with tempfile.TemporaryDirectory() as td:
        _extract_repo(bundle, td)
        secret = _find_secret_in_objects(td)
    return {"secret": secret}


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
