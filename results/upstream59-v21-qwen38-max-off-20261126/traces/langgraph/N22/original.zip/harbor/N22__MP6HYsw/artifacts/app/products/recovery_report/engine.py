"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import gzip
import tarfile
import io
import tempfile
import os
import subprocess
import hashlib
import re
from runtime import build


def _extract_repo(bundle_b64, dest):
    """Extract base64 gzip-tar bundle to dest directory."""
    raw = gzip.decompress(base64.b64decode(bundle_b64))
    tf = tarfile.open(fileobj=io.BytesIO(raw))
    tf.extractall(dest)
    # Ensure essential git directories exist for repo recognition
    for d in ['refs/heads', 'refs/tags']:
        os.makedirs(os.path.join(dest, '.git', d), exist_ok=True)


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def _count_secret_objects(repo_dir, secret):
    """Count objects containing the secret marker."""
    count = 0
    pattern = re.compile(re.escape(secret))
    
    # Get all object hashes
    objects_dir = os.path.join(repo_dir, '.git', 'objects')
    all_hashes = set()
    
    # Loose objects
    for prefix in os.listdir(objects_dir):
        prefix_path = os.path.join(objects_dir, prefix)
        if len(prefix) == 2 and os.path.isdir(prefix_path):
            for suffix in os.listdir(prefix_path):
                all_hashes.add(prefix + suffix)
    
    # Packed objects via rev-list
    result = subprocess.run(
        ['git', 'rev-list', '--all', '--objects'],
        cwd=repo_dir, capture_output=True, text=True
    )
    for line in result.stdout.strip().split('\n'):
        if line:
            all_hashes.add(line.split()[0])
    
    # fsck unreachable
    result = subprocess.run(
        ['git', 'fsck', '--unreachable', '--no-reflogs'],
        cwd=repo_dir, capture_output=True, text=True
    )
    for line in result.stdout.strip().split('\n'):
        if line:
            parts = line.split()
            if len(parts) >= 3:
                all_hashes.add(parts[2])

    for obj_hash in all_hashes:
        result = subprocess.run(
            ['git', 'cat-file', '-p', obj_hash],
            cwd=repo_dir, capture_output=True, text=True
        )
        if pattern.search(result.stdout):
            count += 1
    
    return count


def _get_files_sha256(repo_dir):
    """Get SHA256 of all non-.git files."""
    result = {}
    for root, dirs, files in os.walk(repo_dir):
        rel_root = os.path.relpath(root, repo_dir)
        if rel_root.startswith('.git'):
            continue
        dirs[:] = [d for d in dirs if not (rel_root == '.' and d == '.git')]
        for f in sorted(files):
            full = os.path.join(root, f)
            rel = os.path.relpath(full, repo_dir)
            if not rel.startswith('.git'):
                result[rel] = _sha256_file(full)
    return result


def _get_messages(repo_dir):
    """Get commit messages newest first."""
    result = subprocess.run(
        ['git', 'log', '--format=%s'],
        cwd=repo_dir, capture_output=True, text=True
    )
    messages = [line for line in result.stdout.strip().split('\n') if line]
    return messages


def transform(payload, contract):
    scan_result = payload['scan']
    cleaned_result = payload['cleaned']
    secret = scan_result['secret']
    cleaned_bundle = cleaned_result['bundle']

    with tempfile.TemporaryDirectory() as td:
        _extract_repo(cleaned_bundle, td)
        
        remaining = _count_secret_objects(td, secret)
        files = _get_files_sha256(td)
        messages = _get_messages(td)

    return {
        "secret": secret,
        "files": files,
        "messages": messages,
        "remaining_secret_objects": remaining
    }


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
