"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module


def main():
    root = Path(__file__).resolve().parent
    
    # Load delivery contract
    delivery = read(root / "delivery.json")
    
    # Ensure outputs directory exists
    (root / "outputs").mkdir(exist_ok=True)
    
    # Component execution order based on dependencies:
    # 1. object_scan (depends on: inputs/request.json#/bundle)
    # 2. cleaned_repo (depends on: inputs/request.json#/bundle, outputs/object_scan.json#)
    # 3. recovery_report (depends on: outputs/object_scan.json#, outputs/cleaned_repo.json#)
    
    component_order = ["object_scan", "cleaned_repo", "recovery_report"]
    results = {}
    
    for comp_name in component_order:
        comp_dir = root / "products" / comp_name
        contract = read(comp_dir / "contract.json")
        eng = module(comp_dir, "engine.py")
        result = eng.build_component(str(root), contract)
        results[comp_name] = result
    
    # Write final report
    result_file_path = delivery["result_file"]
    result_value = read(root / result_file_path)
    
    final_report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value
    }
    
    final_path = root / delivery["report"]
    final_path.parent.mkdir(parents=True, exist_ok=True)
    final_path.write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )


if __name__ == '__main__':
    main()
