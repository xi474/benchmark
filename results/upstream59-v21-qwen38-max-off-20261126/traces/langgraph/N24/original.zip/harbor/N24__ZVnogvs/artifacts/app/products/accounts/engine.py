"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    text = payload["text"]
    RECORD_LEN = 34
    accounts = []
    for i in range(0, len(text), RECORD_LEN):
        rec = text[i:i+RECORD_LEN]
        if len(rec) < RECORD_LEN:
            break
        acc_id = rec[0:4]
        name = rec[4:24].rstrip()
        balance = int(rec[24:34])
        accounts.append({"id": acc_id, "name": name, "balance": balance})
    return accounts

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
