"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    text = payload["text"]
    RECORD_LEN = 28
    books = []
    for i in range(0, len(text), RECORD_LEN):
        rec = text[i:i+RECORD_LEN]
        if len(rec) < RECORD_LEN:
            break
        book_id = rec[0:4]
        title = rec[4:24].rstrip()
        owner = rec[24:28]
        books.append({"id": book_id, "title": title, "owner": owner})
    return books

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
