"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    orders_raw = payload["orders"]
    orders = []
    for raw in orders_raw:
        buyer = raw[0:4]
        seller = raw[4:8]
        book = raw[8:12]
        amount = int(raw[12:22])
        orders.append({"buyer": buyer, "seller": seller, "book": book, "amount": amount})
    return orders

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
