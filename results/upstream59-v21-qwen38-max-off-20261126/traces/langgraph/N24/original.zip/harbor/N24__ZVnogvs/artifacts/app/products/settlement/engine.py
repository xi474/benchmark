"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    accounts = payload["accounts"]  # list of {id, name, balance}
    books = payload["books"]        # list of {id, title, owner}
    orders = payload["orders"]      # list of {buyer, seller, book, amount}
    journal = payload.get("journal", "")  # existing journal string

    # Build lookup indices
    acc_by_id = {a["id"]: a for a in accounts}
    book_by_id = {b["id"]: b for b in books}

    statuses = []

    for order in orders:
        buyer_id = order["buyer"]
        seller_id = order["seller"]
        book_id = order["book"]
        amount = order["amount"]

        # Validation checks
        buyer = acc_by_id.get(buyer_id)
        seller = acc_by_id.get(seller_id)
        book = book_by_id.get(book_id)

        if (buyer is None or seller is None or book is None
                or buyer_id == seller_id
                or amount <= 0
                or buyer["balance"] < amount
                or book["owner"] != seller_id):
            statuses.append("rejected")
            continue

        # Execute transfer
        buyer["balance"] -= amount
        seller["balance"] += amount
        book["owner"] = buyer_id

        # Append journal entry: book(4) + amount(10) + seller(4) + buyer(4)
        journal_entry = f"{book_id}{amount:010d}{seller_id}{buyer_id}"
        journal += journal_entry

        statuses.append("accepted")

    # Re-encode accounts as fixed-length string
    accounts_str = ""
    for a in accounts:
        name_padded = a["name"].ljust(20)
        balance_padded = f"{a['balance']:010d}"
        accounts_str += f"{a['id']}{name_padded}{balance_padded}"

    # Re-encode books as fixed-length string
    books_str = ""
    for b in books:
        title_padded = b["title"].ljust(20)
        books_str += f"{b['id']}{title_padded}{b['owner']}"

    return {
        "accounts": accounts_str,
        "books": books_str,
        "journal": journal,
        "statuses": statuses
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
