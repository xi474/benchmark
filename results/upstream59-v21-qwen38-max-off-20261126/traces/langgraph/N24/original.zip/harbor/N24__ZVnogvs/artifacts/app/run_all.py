"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module

def main():
    root = Path(__file__).resolve().parent
    
    # Ensure outputs directory exists
    (root / "outputs").mkdir(exist_ok=True)
    
    # Load delivery manifest
    delivery = read(root / "delivery.json")
    
    # Component execution order: accounts, books, orders first (no deps), then settlement
    component_order = ["accounts", "books", "orders", "settlement"]
    
    results = {}
    
    for comp_name in component_order:
        contract_path = root / "products" / comp_name / "contract.json"
        contract = read(contract_path)
        
        engine_path = root / "products" / comp_name / "engine.py"
        eng = module(root, engine_path)
        
        result = eng.build_component(str(root), contract)
        results[comp_name] = result
    
    # Build final report
    result_file = delivery["result_file"]
    result_value = read(root / result_file)
    
    final_report = {
        "task": delivery["task"],
        "results": {k: v for k, v in results.items()},
        "result": result_value
    }
    
    report_path = root / delivery["report"]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )

if __name__ == '__main__':
    main()
