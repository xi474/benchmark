import json

with open("components/mobile_cable/input.json") as f:
    data = json.load(f)
records = data["records"]

with open("components/mobile_cable/expected.json") as f:
    expected = json.load(f)

# Check which records are in mobile_cable (source == 'mobile' or 'cable')
mc_records = [(i, r) for i, r in enumerate(records) if r['source'] in ('mobile', 'cable')]
print(f"Mobile/Cable records count: {len(mc_records)}")
for idx, rec in mc_records:
    print(f"  index={idx}, id={rec['id']}, source={rec['source']}")

print(f"\nExpected count: {len(expected)}")
for item in expected:
    orig_idx = item[0]
    obj = item[1]
    print(f"  orig_idx={orig_idx}, id={obj['id']}, first={obj['first']}, last={obj['last']}, dob={obj['dob']}, ssn={obj['ssn']}, mail={obj['mail']}, phone={obj['phone']}, address={obj['address']}")