import json

with open("components/mobile_cable/input.json") as f:
    data = json.load(f)

records = data.get("records", [])
print(f"Total records: {len(records)}")
for i, r in enumerate(records):
    print(f"  [{i}] source={r['source']}, id={r['id']}")

if "ambiguous_names" in data:
    print(f"\nAmbiguous names: {data['ambiguous_names']}")
else:
    print("\nNo ambiguous_names key in payload")

print("\nAll keys:", list(data.keys()))