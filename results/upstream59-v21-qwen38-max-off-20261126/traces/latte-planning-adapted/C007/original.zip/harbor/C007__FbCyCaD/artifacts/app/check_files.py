import os, json

# List all files
print("--- Files ---")
for root, dirs, files in os.walk("."):
    dirs[:] = [d for d in dirs if not d.startswith('.')]
    for f in sorted(files):
        fp = os.path.join(root, f)
        print(fp)

# Read full public_input.json
with open("public_input.json") as f:
    data = json.load(f)
print(f"\nTotal records: {len(data['records'])}")
for i, r in enumerate(data['records']):
    print(f"  [{i}] id={r['id']}, source={r['source']}")

if "ambiguous_names" in data:
    print(f"\nambiguous_names: {data['ambiguous_names']}")