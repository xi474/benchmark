import re
from datetime import datetime


def _normalize_text(s):
    """Lowercase and remove all non-alphanumeric characters."""
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _parse_date(date_str, source):
    """Parse date string to ISO format based on source type."""
    if not date_str:
        return ""
    try:
        if source == "streaming":
            # Format: "03 Mar 1973"
            dt = datetime.strptime(date_str.strip(), "%d %b %Y")
        elif source == "internet":
            # Format: "03/03/1972" (MM/DD/YYYY)
            dt = datetime.strptime(date_str.strip(), "%m/%d/%Y")
        else:
            return ""
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return ""


def compute(payload):
    """标准化 ('internet', 'streaming') 渠道记录，返回 [原位置,字段对象] 数组。
    
    对象字段 id,first,last,dob,ssn,mail,phone,address，
    日期 ISO，文字小写去非字母数字，电话及证件仅留数字。
    """
    records = payload.get("records", [])
    result = []

    for idx, record in enumerate(records):
        source = record.get("source", "")
        if source not in ("internet", "streaming"):
            continue

        fields = record.get("fields", {})
        rec_id = record.get("id", "")

        if source == "streaming":
            customer = fields.get("customer", "")
            dob_raw = fields.get("date_of_birth", "")
            email = fields.get("email", "")
            phone = fields.get("telephone", "")
            address = fields.get("address", "")
        elif source == "internet":
            customer = fields.get("full_name", "")
            dob_raw = fields.get("birth_date", "")
            email = fields.get("mail", "")
            phone = fields.get("tel", "")
            address = fields.get("street", "")
        else:
            continue

        # Split name into first and last
        parts = customer.split()
        first = parts[0] if parts else ""
        last = " ".join(parts[1:]) if len(parts) > 1 else ""

        normalized = {
            "id": rec_id,
            "first": _normalize_text(first),
            "last": _normalize_text(last),
            "dob": _parse_date(dob_raw, source),
            "ssn": "",
            "mail": _normalize_text(email),
            "phone": re.sub(r'[^0-9]', '', str(phone)),
            "address": _normalize_text(address),
        }

        result.append([idx, normalized])

    return result