"""
Normalize mobile and cable channel records.

Returns a list of [original_index, normalized_fields_object] pairs.
Normalized fields: id, first, last, dob, ssn, mail, phone, address.
Rules:
  - Dates converted to ISO format (YYYY-MM-DD)
  - Text fields lowercased with non-alphanumeric characters removed
  - Phone and SSN/government_id keep only digits
"""
import re


def _clean_text(value):
    """Lowercase and remove all non-alphanumeric characters."""
    if not value:
        return ""
    return re.sub(r'[^a-z0-9]', '', str(value).lower())


def _digits_only(value):
    """Keep only digit characters."""
    if not value:
        return ""
    return re.sub(r'[^0-9]', '', str(value))


def _parse_mobile_dob(dob_str):
    """Mobile DOB is already YYYY-MM-DD, just validate/return."""
    if not dob_str:
        return ""
    return str(dob_str)


def _parse_cable_dob(birth_str):
    """Cable birth is YYYYMMDD, convert to YYYY-MM-DD."""
    if not birth_str:
        return ""
    s = str(birth_str)
    if len(s) == 8:
        return f"{s[:4]}-{s[4:6]}-{s[6:8]}"
    return s


def compute(payload):
    """
    Normalize ('mobile', 'cable') channel records from payload.
    
    Args:
        payload: dict with 'records' key containing list of record dicts
        
    Returns:
        List of [original_index, normalized_fields_object] pairs
    """
    records = payload.get("records", [])
    result = []

    for idx, rec in enumerate(records):
        source = rec.get("source", "")
        if source not in ("mobile", "cable"):
            continue

        fields = rec.get("fields", {})
        rec_id = rec.get("id", "")

        if source == "mobile":
            first = _clean_text(fields.get("first", ""))
            last = _clean_text(fields.get("last", ""))
            dob = _parse_mobile_dob(fields.get("dob", ""))
            ssn = _digits_only(fields.get("ssn", ""))
            mail = _clean_text(fields.get("email", ""))
            phone = _digits_only(fields.get("phone", ""))
            address = _clean_text(fields.get("address", ""))

        elif source == "cable":
            # last_first is "last,first"
            last_first = fields.get("last_first", "")
            if last_first and "," in str(last_first):
                parts = str(last_first).split(",", 1)
                last = _clean_text(parts[0])
                first = _clean_text(parts[1])
            else:
                last = ""
                first = _clean_text(last_first)

            dob = _parse_cable_dob(fields.get("birth", ""))
            ssn = _digits_only(fields.get("government_id", ""))
            mail = _clean_text(fields.get("contact", ""))
            phone = _digits_only(fields.get("phone", ""))
            address = _clean_text(fields.get("location", ""))

        else:
            continue

        normalized = {
            "id": rec_id,
            "first": first,
            "last": last,
            "dob": dob,
            "ssn": ssn,
            "mail": mail,
            "phone": phone,
            "address": address,
        }

        result.append([idx, normalized])

    return result