import json
with open("components/mobile_cable/input.json") as f:
    data = json.load(f)
for i, rec in enumerate(data.get("records", [])):
    print(f"[{i}] source={rec.get('source')} id={rec.get('id')[:20]}... fields={json.dumps(rec.get('fields', {}))}")
print("\nKeys:", list(data.keys()))
if "ambiguous_names" in data:
    print("ambiguous_names:", data["ambiguous_names"])