with open("component_runtime.py") as f:
    content = f.read()
print(content[3000:])