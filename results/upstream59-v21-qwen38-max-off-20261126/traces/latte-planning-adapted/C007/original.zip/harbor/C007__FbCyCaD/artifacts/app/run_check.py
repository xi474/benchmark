import subprocess, sys
result = subprocess.run([sys.executable, "-B", "component_runtime.py", "check", "internet_streaming"], capture_output=True, text=True)
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("Return code:", result.returncode)