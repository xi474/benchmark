import json
import sys
sys.path.insert(0, "components/mobile_cable")
from work import compute

with open("components/mobile_cable/input.json") as f:
    payload = json.load(f)

with open("components/mobile_cable/expected.json") as f:
    expected = json.load(f)

actual = compute(payload)

print(f"Actual count: {len(actual)}")
print(f"Expected count: {len(expected)}")

# Compare indices
actual_indices = [a[0] for a in actual]
expected_indices = [e[0] for e in expected]
print(f"\nActual indices:   {actual_indices}")
print(f"Expected indices: {expected_indices}")

missing = set(expected_indices) - set(actual_indices)
extra = set(actual_indices) - set(expected_indices)
if missing:
    print(f"\nMissing from actual: {sorted(missing)}")
if extra:
    print(f"\nExtra in actual: {sorted(extra)}")

# Check matching entries
for a_item in actual:
    idx = a_item[0]
    for e_item in expected:
        if e_item[0] == idx:
            if a_item[1] != e_item[1]:
                print(f"\nMismatch at index {idx}:")
                print(f"  Actual:   {json.dumps(a_item[1], indent=2)}")
                print(f"  Expected: {json.dumps(e_item[1], indent=2)}")
            break