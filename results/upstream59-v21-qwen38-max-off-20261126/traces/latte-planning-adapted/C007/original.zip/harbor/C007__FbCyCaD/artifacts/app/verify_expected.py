import json

with open("components/internet_streaming/input.json") as f:
    data = json.load(f)

records = data["records"]
for i in [5, 6, 11, 15, 18, 19, 20, 22]:
    r = records[i]
    print(f"Index {i}: source={r['source']}, fields={json.dumps(r['fields'])}")