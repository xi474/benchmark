def compute(payload):
    """每步按 Linux 终端键表编码为连续字节，返回十六进制字符串列表。"""
    KEY_MAP = {
        "Enter": b'\x0d',
        "C-c": b'\x03',
        "C-d": b'\x04',
        "C-u": b'\x15',
        "Tab": b'\x09',
        "Backspace": b'\x7f',
    }

    result = []
    for step in payload["steps"]:
        seq = b""
        for key in step["keys"]:
            if key in KEY_MAP:
                seq += KEY_MAP[key]
            else:
                seq += key.encode("utf-8")
        result.append(seq.hex())
    return result