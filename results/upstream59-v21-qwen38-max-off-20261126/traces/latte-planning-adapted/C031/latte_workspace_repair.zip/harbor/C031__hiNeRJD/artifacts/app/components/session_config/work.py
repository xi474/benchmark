def compute(payload):
    """Output rc (fixed PROMPT>, CONT>, disable history, append startup), timeout (default 4), markers (ordered until values, may be null)."""
    startup = payload.get("startup", "") or ""
    timeout = payload.get("timeout_seconds", 4)
    steps = payload.get("steps", [])

    rc = "PS1='PROMPT> '\nPS2='CONT> '\nHISTFILE=/dev/null\n\n" + startup
    markers = [step.get("until") for step in steps]

    return {
        "rc": rc,
        "timeout": timeout,
        "markers": markers,
    }