import os
import pty
import select
import signal
import shutil
import tempfile
import binascii


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    rc_content = right["rc"]
    timeout = right["timeout"]
    markers = right["markers"]

    # 1. Create temp dir, set HOME, create .hushlogin
    tmpdir = tempfile.mkdtemp()
    hushlogin_path = os.path.join(tmpdir, ".hushlogin")
    with open(hushlogin_path, "w") as f:
        pass  # empty file

    # 2. Write rc content to temp rcfile
    rcfile_path = os.path.join(tmpdir, ".bashrc_custom")
    with open(rcfile_path, "w") as f:
        f.write(rc_content)

    master_fd = None
    slave_fd = None
    pid = None
    closed = False
    chunks = []

    try:
        # 3. Start bash in a real PTY
        master_fd, slave_fd = pty.openpty()

        env = os.environ.copy()
        env["TERM"] = "dumb"
        env["LC_ALL"] = "C"
        env["HISTFILE"] = "/dev/null"
        env["HOME"] = tmpdir

        pid = os.fork()
        if pid == 0:
            # Child process
            os.close(master_fd)
            os.setsid()
            # Acquire controlling terminal
            import fcntl
            import termios
            fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)
            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            if slave_fd > 2:
                os.close(slave_fd)
            os.execve("/bin/bash", ["/bin/bash", "--noprofile", "--rcfile", rcfile_path, "-i"], env)
            os._exit(1)
        else:
            # Parent process
            os.close(slave_fd)
            slave_fd = None

            def read_until(marker, tout):
                """Read from PTY master_fd until marker string is found or EOF/timeout."""
                buf = b""
                while True:
                    ready, _, _ = select.select([master_fd], [], [], tout)
                    if not ready:
                        # Timeout - return what we have
                        break
                    try:
                        data = os.read(master_fd, 4096)
                    except OSError:
                        break
                    if not data:
                        # EOF
                        nonlocal closed
                        closed = True
                        break
                    buf += data
                    text_so_far = buf.decode("utf-8", errors="replace")
                    if marker is not None and marker in text_so_far:
                        # Read any remaining data that came in the same burst
                        while True:
                            ready2, _, _ = select.select([master_fd], [], [], 0.05)
                            if not ready2:
                                break
                            try:
                                extra = os.read(master_fd, 4096)
                            except OSError:
                                break
                            if not extra:
                                closed = True
                                break
                            buf += extra
                            # Check again if marker still present (it should be)
                            text_so_far = buf.decode("utf-8", errors="replace")
                            if marker in text_so_far:
                                break
                        break
                return buf.decode("utf-8", errors="replace")

            def normalize(text):
                """Normalize line endings: \r\n -> \n, lone \r -> \n."""
                text = text.replace("\r\n", "\n")
                text = text.replace("\r", "\n")
                return text

            # 4. Read until initial prompt "PROMPT> "
            initial_text = read_until("PROMPT> ", timeout)
            chunks.append(normalize(initial_text))

            # 5. For each step, decode hex, write to PTY, read until marker
            for i, hex_str in enumerate(left):
                raw_bytes = binascii.unhexlify(hex_str)
                os.write(master_fd, raw_bytes)

                marker = markers[i] if i < len(markers) else None
                step_text = read_until(marker, timeout)
                chunks.append(normalize(step_text))

    finally:
        # 8. Clean up
        if pid is not None:
            try:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            except (ProcessLookupError, OSError):
                pass
            try:
                os.waitpid(pid, 0)
            except ChildProcessError:
                pass

        if master_fd is not None:
            try:
                os.close(master_fd)
            except OSError:
                pass
        if slave_fd is not None:
            try:
                os.close(slave_fd)
            except OSError:
                pass

        shutil.rmtree(tmpdir, ignore_errors=True)

    # 9. Return result
    return {"chunks": chunks, "closed": closed}