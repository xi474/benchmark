import subprocess, sys
result = subprocess.run(
    [sys.executable, "-B", "component_runtime.py", "check", "key_sequences"],
    cwd="/app",
    capture_output=True,
    text=True
)
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("RC:", result.returncode)