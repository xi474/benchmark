import json
from pathlib import Path
from components.session_config.work import compute

payload = json.loads(Path("components/session_config/input.json").read_text(encoding="utf-8"))
expected = json.loads(Path("components/session_config/expected.json").read_text(encoding="utf-8"))
result = compute(payload)
print("Result:", json.dumps(result))
print("Expected:", json.dumps(expected))
assert result == expected, f"Mismatch: {result} != {expected}"
print("session_config check passed")