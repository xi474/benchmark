import importlib
for mod in ['yaml', 'pyyaml', 'ruamel']:
    try:
        importlib.import_module(mod)
        print(f"{mod}: available")
    except ImportError:
        print(f"{mod}: NOT available")