import yaml


def compute(payload):
    """Parse untrusted documents' overrides and intra-document anchors.
    Each valid key outputs [original_source_index, declaration_position,
    [value_position, text, is_secret, source_is_trusted]];
    positions are [source_name, line, col].
    """
    sources = payload.get("sources", [])
    result = {}

    for src_idx, source in enumerate(sources):
        if source.get("trusted", False):
            continue

        name = source["name"]
        yaml_text = source.get("yaml", "")

        # Parse YAML with location tracking
        events = list(yaml.parse(yaml_text))

        # First pass: collect anchors and their scalar values/positions
        anchors = {}
        i = 0
        while i < len(events):
            ev = events[i]
            if isinstance(ev, yaml.ScalarEvent) and ev.anchor:
                anchors[ev.anchor] = {
                    "value": ev.value,
                    "start_line": ev.start_mark.line + 1,
                    "start_col": ev.start_mark.column + 1,
                }
            elif isinstance(ev, (yaml.SequenceStartEvent, yaml.MappingStartEvent)) and ev.anchor:
                anchors[ev.anchor] = {
                    "value": None,
                    "start_line": ev.start_mark.line + 1,
                    "start_col": ev.start_mark.column + 1,
                }
            i += 1

        # Second pass: extract key-value pairs from mapping
        i = 0
        while i < len(events):
            ev = events[i]
            if isinstance(ev, yaml.MappingStartEvent):
                # Process mapping entries
                i += 1
                while i < len(events) and not isinstance(events[i], yaml.MappingEndEvent):
                    key_ev = events[i]
                    if isinstance(key_ev, yaml.ScalarEvent):
                        key_name = key_ev.value
                        key_line = key_ev.start_mark.line + 1
                        key_col = key_ev.start_mark.column + 1
                        i += 1

                        val_ev = events[i]
                        if isinstance(val_ev, yaml.ScalarEvent):
                            val_text = val_ev.value
                            val_line = val_ev.start_mark.line + 1
                            val_col = val_ev.start_mark.column + 1

                            result[key_name] = [
                                src_idx,
                                [name, key_line, key_col],
                                [[name, val_line, val_col], val_text, False, False]
                            ]
                            i += 1
                        elif isinstance(val_ev, yaml.AliasEvent):
                            # Resolve alias
                            anchor_name = val_ev.anchor
                            if anchor_name in anchors:
                                anchor_info = anchors[anchor_name]
                                result[key_name] = [
                                    src_idx,
                                    [name, key_line, key_col],
                                    [[name, anchor_info["start_line"], anchor_info["start_col"]],
                                     anchor_info["value"], False, False]
                                ]
                            i += 1
                        elif isinstance(val_ev, (yaml.MappingStartEvent, yaml.SequenceStartEvent)):
                            # Skip complex values for now
                            depth = 1
                            i += 1
                            while i < len(events) and depth > 0:
                                if isinstance(events[i], (yaml.MappingStartEvent, yaml.SequenceStartEvent)):
                                    depth += 1
                                elif isinstance(events[i], (yaml.MappingEndEvent, yaml.SequenceEndEvent)):
                                    depth -= 1
                                i += 1
                        else:
                            i += 1
                    else:
                        i += 1
                i += 1  # skip MappingEndEvent
            else:
                i += 1

    return result