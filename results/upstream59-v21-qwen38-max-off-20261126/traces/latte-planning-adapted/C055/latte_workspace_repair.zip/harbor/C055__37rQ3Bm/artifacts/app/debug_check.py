import json
from pathlib import Path
from components.external_bindings.work import compute

input_data = json.loads(Path("components/external_bindings/input.json").read_text())
expected = json.loads(Path("components/external_bindings/expected.json").read_text())

result = compute(input_data)
print("ACTUAL:")
print(json.dumps(result, indent=2))
print("\nEXPECTED:")
print(json.dumps(expected, indent=2))