import os
for root, dirs, files in os.walk('.'):
    for f in files:
        if f in ('requirements.txt', 'setup.py', 'pyproject.toml', 'Pipfile', 'setup.cfg'):
            print(os.path.join(root, f))