import os
for root, dirs, files in os.walk('.'):
    for f in files:
        if 'yaml' in f.lower():
            print(os.path.join(root, f))