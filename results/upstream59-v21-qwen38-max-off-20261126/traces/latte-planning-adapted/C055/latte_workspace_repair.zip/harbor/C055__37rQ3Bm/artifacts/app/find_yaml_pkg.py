import sys
import os
for p in sys.path:
    if not os.path.isdir(p):
        continue
    for item in os.listdir(p):
        if 'yaml' in item.lower():
            full = os.path.join(p, item)
            print(full)