import os

def list_all(path, prefix=""):
    for item in sorted(os.listdir(path)):
        full = os.path.join(path, item)
        rel = os.path.join(prefix, item) if prefix else item
        if os.path.isdir(full):
            print(f"DIR:  {rel}/")
            list_all(full, rel)
        else:
            print(f"FILE: {rel}")

list_all(".")