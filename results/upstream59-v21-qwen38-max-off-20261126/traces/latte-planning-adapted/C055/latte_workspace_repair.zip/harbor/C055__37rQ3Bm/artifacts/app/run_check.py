import subprocess
result = subprocess.run(
    ["python", "-B", "component_runtime.py", "check", "external_bindings"],
    capture_output=True, text=True, cwd="/app"
)
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("Return code:", result.returncode)