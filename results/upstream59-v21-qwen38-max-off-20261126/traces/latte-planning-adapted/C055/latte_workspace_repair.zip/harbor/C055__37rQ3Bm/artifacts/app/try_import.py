try:
    import yaml
    print("yaml available:", yaml.__version__)
except ImportError as e:
    print("yaml not available:", e)