def compute(payload):
    """Compute cleanup clock triggers based on 16*TTL rule.
    
    Returns dict mapping get-position strings (event indices) to next_cleanup 
    values after triggered cleanups. Only includes positions where cleanup triggers.
    """
    ttl = payload["ttl"]
    events = payload["events"]
    
    next_cleanup = 16 * ttl
    result = {}
    
    for i, event in enumerate(events):
        if event.get("op") == "get":
            now = event["time"]
            if now >= next_cleanup:
                next_cleanup = now + 16 * ttl
                result[str(i)] = next_cleanup
    
    return result