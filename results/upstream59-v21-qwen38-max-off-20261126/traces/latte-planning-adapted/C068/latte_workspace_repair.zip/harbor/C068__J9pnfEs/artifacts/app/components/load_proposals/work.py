def compute(payload):
    """Generate load proposals for each get event.

    For every 'get' event in the payload, produce a proposal of the form
    [finished_at_if_started, value, error] where finished_at = time + delay.
    The result dict maps the event's positional index (as a string) to its
    proposal.  Non-get events are ignored.
    """
    events = payload["events"]
    result = {}

    for i, event in enumerate(events):
        if event.get("op") == "get":
            finished_at = event["time"] + event["delay"]
            value = event["value"]
            error = event.get("error")
            result[str(i)] = [finished_at, value, error]

    return result