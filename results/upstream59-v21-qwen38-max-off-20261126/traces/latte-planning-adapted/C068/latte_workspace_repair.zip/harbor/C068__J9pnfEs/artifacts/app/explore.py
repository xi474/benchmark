import os
for root, dirs, files in os.walk('/app'):
    for f in files:
        if f.endswith('.py') or f.endswith('.json'):
            print(os.path.join(root, f))