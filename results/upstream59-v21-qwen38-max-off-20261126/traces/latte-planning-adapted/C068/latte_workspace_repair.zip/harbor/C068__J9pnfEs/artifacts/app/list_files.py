import os
for root, dirs, files in os.walk('.'):
    for f in files:
        if not root.startswith('./.git'):
            print(os.path.join(root, f))