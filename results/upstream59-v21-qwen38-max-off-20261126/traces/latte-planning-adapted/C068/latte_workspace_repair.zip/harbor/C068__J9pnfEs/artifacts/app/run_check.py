import subprocess
result = subprocess.run(["python", "-B", "component_runtime.py", "check", "cleanup_clock"], capture_output=True, text=True)
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("Return code:", result.returncode)