def compute(payload):
    """按 response 位置记录 [原因,到期时间]；失败优先于陈旧，延迟分别为 2000/1000，正常相应用 null。"""
    result = {}
    events = payload.get("events", [])
    for idx, event in enumerate(events):
        if event.get("op") != "response":
            continue
        now = event.get("time", 0)
        # failed takes priority over stale ("失败优先于陈旧")
        if event.get("failed"):
            result[str(idx)] = ["failure", now + 2000]
        elif event.get("stale") == 1:
            result[str(idx)] = ["stale", now + 1000]
        else:
            # success (has items) or other non-failure/non-stale response
            result[str(idx)] = None
    return result