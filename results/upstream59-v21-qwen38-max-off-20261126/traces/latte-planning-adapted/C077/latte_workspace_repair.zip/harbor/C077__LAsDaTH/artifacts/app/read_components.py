import json
for comp in ['mutation_membership', 'response_deadlines']:
    print(f"=== {comp}/input.json ===")
    with open(f'components/{comp}/input.json') as f:
        print(json.dumps(json.load(f), indent=2))
    print(f"\n=== {comp}/expected.json ===")
    with open(f'components/{comp}/expected.json') as f:
        print(json.dumps(json.load(f), indent=2))
    print()