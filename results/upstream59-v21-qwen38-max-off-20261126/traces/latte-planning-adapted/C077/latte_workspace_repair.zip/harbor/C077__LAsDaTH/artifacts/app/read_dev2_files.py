import os
os.chdir('/app')

files = [
    'components/response_deadlines/README.md',
    'components/response_deadlines/work.py',
    'components/response_deadlines/check.py',
    'components/response_deadlines/run.py',
]

for f in files:
    print(f"{'='*60}")
    print(f"=== {f} ===")
    print(f"{'='*60}")
    try:
        with open(f) as fh:
            print(fh.read())
    except FileNotFoundError:
        print("[FILE NOT FOUND]")
    print()