for name in ['components/mutation_membership/work.py', 'components/response_deadlines/work.py', 'run_all.py', 'public_check.py']:
    print(f"=== {name} ===")
    try:
        with open(name) as f: print(f.read())
    except FileNotFoundError:
        print("NOT FOUND")
    print()