import json
with open('public_expected.json') as f:
    data = json.load(f)
print(json.dumps(data, indent=2))