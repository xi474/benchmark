import json
for name in ['components/mutation_membership/input.json', 'components/mutation_membership/expected.json',
             'components/response_deadlines/input.json', 'components/response_deadlines/expected.json',
             'public_input.json', 'public_expected.json']:
    print(f"=== {name} ===")
    with open(name) as f:
        print(json.dumps(json.load(f), indent=2))
    print()