import os
os.chdir('/app')

files = [
    'TASK.md',
    'components/mutation_membership/README.md',
    'components/mutation_membership/work.py',
    'integration.py',
    'solution.py',
    'test_suite.py',
    'component_runtime.py',
]

for f in files:
    print(f"{'='*60}")
    print(f"=== {f} ===")
    print(f"{'='*60}")
    try:
        with open(f) as fh:
            print(fh.read())
    except FileNotFoundError:
        print("[FILE NOT FOUND]")
    print()