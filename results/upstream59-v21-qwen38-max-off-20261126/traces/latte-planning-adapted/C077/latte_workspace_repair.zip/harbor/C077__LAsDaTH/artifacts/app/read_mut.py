with open('components/mutation_membership/work.py') as f: print(f.read())
print("---")
with open('components/mutation_membership/README.md') as f: print(f.read())