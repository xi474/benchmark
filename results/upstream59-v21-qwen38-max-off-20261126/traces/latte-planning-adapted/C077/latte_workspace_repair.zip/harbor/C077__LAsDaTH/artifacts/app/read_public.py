import json
with open('public_input.json') as f:
    data = json.load(f)
print(json.dumps(data, indent=2))