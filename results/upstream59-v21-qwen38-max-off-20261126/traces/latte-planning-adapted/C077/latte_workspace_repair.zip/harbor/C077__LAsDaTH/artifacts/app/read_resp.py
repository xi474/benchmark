with open('components/response_deadlines/work.py') as f: print(f.read())
print("---")
with open('components/response_deadlines/README.md') as f: print(f.read())