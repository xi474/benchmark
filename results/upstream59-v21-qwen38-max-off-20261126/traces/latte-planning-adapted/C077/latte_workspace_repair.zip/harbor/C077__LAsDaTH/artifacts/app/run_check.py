import subprocess, sys
result = subprocess.run([sys.executable, "-B", "component_runtime.py", "run", "response_deadlines"], capture_output=True, text=True, cwd="/app")
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("Return code:", result.returncode)