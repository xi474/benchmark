import subprocess, sys

# Run check
result = subprocess.run(
    [sys.executable, "-B", "component_runtime.py", "check", "response_deadlines"],
    capture_output=True, text=True, cwd="/app"
)
print("=== CHECK ===")
print("stdout:", result.stdout)
print("stderr:", result.stderr)
print("returncode:", result.returncode)

# Run
result2 = subprocess.run(
    [sys.executable, "-B", "component_runtime.py", "run", "response_deadlines"],
    capture_output=True, text=True, cwd="/app"
)
print("\n=== RUN ===")
print("stdout:", result2.stdout)
print("stderr:", result2.stderr)
print("returncode:", result2.returncode)