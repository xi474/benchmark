import json
with open("public_input.json") as f:
    data = json.load(f)
print("Topics:", data["topics"])
print("Num papers:", len(data["papers"]))
for p in data["papers"]:
    print(f"\n{p['id']} methods={p['methods']}")
    for c in p["claims"]:
        print(f"  {c}")