def compute(payload):
    """按主题输入顺序生成评分表；每行把具有效章节证据的论文 ID 映射到该主题最高质量分。"""
    topics = payload["topics"]
    papers = payload["papers"]

    result = []
    for topic in topics:
        scores = {}
        for paper in papers:
            pid = paper["id"]
            methods = paper.get("methods", [])
            claims = paper.get("claims", [])
            max_quality = None
            for claim in claims:
                # claim is [topic_name, section, quality]
                if claim[0] == topic and claim[1] in methods:
                    q = claim[2]
                    if max_quality is None or q > max_quality:
                        max_quality = q
            if max_quality is not None:
                scores[pid] = max_quality
        result.append(scores)
    return result