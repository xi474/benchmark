def compute(payload):
    """返回去重并按三元组字典序排列的已有图事实。"""
    graph = payload["graph"]
    
    # Deduplicate by converting to tuples, using a set
    seen = set()
    unique = []
    for triple in graph:
        key = (triple[0], triple[1], triple[2])
        if key not in seen:
            seen.add(key)
            unique.append(triple)
    
    # Sort lexicographically (case-sensitive string comparison)
    unique.sort(key=lambda t: (t[0], t[1], t[2]))
    
    return unique