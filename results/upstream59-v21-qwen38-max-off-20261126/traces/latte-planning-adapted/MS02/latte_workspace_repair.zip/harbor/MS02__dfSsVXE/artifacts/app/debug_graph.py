import json
with open("public_input.json") as f:
    payload = json.load(f)
print(json.dumps(payload.get("graph", []), indent=2))