import json
with open("public_input.json") as f:
    payload = json.load(f)

# Simulate evidence_scores compute
topics = payload["topics"]
papers = payload["papers"]
result = []
for topic in topics:
    scores = {}
    for paper in papers:
        pid = paper["id"]
        methods = paper.get("methods", [])
        claims = paper.get("claims", [])
        max_quality = None
        for claim in claims:
            if claim[0] == topic and claim[1] in methods:
                q = claim[2]
                if max_quality is None or q > max_quality:
                    max_quality = q
        if max_quality is not None:
            scores[pid] = max_quality
    result.append(scores)

print("LEFT (evidence_scores):")
for i, t in enumerate(topics):
    print(f"  {t}: {result[i]}")