def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    Args:
        payload: full input containing topics, papers, graph
        left: evidence_scores result - list of dicts (one per topic), mapping paper_id -> max_quality
        right: graph_facts result - deduplicated sorted existing graph triples
    
    Returns:
        {"review": [...], "graph": [...]} or None if no valid assignment exists
    """
    topics = payload["topics"]
    num_topics = len(topics)
    
    # If there are no topics, return empty review and just the existing graph
    if num_topics == 0:
        return {"review": [], "graph": right}
    
    # Backtracking search to find optimal assignment
    best_assignment = [None]  # Use list to allow mutation in nested function
    
    def backtrack(topic_idx, used_papers, current_assignment, current_min_quality, current_total_quality):
        if topic_idx == num_topics:
            # We have a complete assignment - check if it's better than the best so far
            if best_assignment[0] is None:
                best_assignment[0] = (list(current_assignment), current_min_quality, current_total_quality)
            else:
                best_min, best_total, best_pids = best_assignment[0][1], best_assignment[0][2], [a[1] for a in best_assignment[0][0]]
                curr_pids = [a[1] for a in current_assignment]
                
                # Compare: first maximize minimum quality
                if current_min_quality > best_min:
                    best_assignment[0] = (list(current_assignment), current_min_quality, current_total_quality)
                elif current_min_quality == best_min:
                    # Then maximize total quality
                    if current_total_quality > best_total:
                        best_assignment[0] = (list(current_assignment), current_min_quality, current_total_quality)
                    elif current_total_quality == best_total:
                        # Then pick lexicographically smallest sequence of paper IDs
                        if curr_pids < best_pids:
                            best_assignment[0] = (list(current_assignment), current_min_quality, current_total_quality)
            return
        
        scores_for_topic = left[topic_idx]
        
        # Get available papers sorted for deterministic lexicographic ordering
        available_papers = sorted([pid for pid in scores_for_topic if pid not in used_papers])
        
        for pid in available_papers:
            quality = scores_for_topic[pid]
            
            new_min = min(current_min_quality, quality) if current_min_quality is not None else quality
            
            # Pruning: if we already have a best assignment and this path can't beat 
            # its minimum quality, skip
            if best_assignment[0] is not None:
                if new_min < best_assignment[0][1]:
                    continue
            
            used_papers.add(pid)
            current_assignment.append((topics[topic_idx], pid, quality))
            
            backtrack(
                topic_idx + 1,
                used_papers,
                current_assignment,
                new_min,
                current_total_quality + quality
            )
            
            current_assignment.pop()
            used_papers.remove(pid)
    
    backtrack(0, set(), [], None, 0)
    
    if best_assignment[0] is None:
        return None
    
    assignment = best_assignment[0][0]
    
    # Build review: for each topic in input order, produce [topic, paper_id, quality]
    review = [[topic, pid, quality] for topic, pid, quality in assignment]
    
    # Build graph: union of right (existing edges) and new edges [paper_id, "supports", topic]
    graph_set = set()
    for triple in right:
        graph_set.add(tuple(triple))
    
    for topic, pid, quality in assignment:
        graph_set.add((pid, "supports", topic))
    
    # Deduplicate and sort all triples lexicographically
    graph = sorted(graph_set, key=lambda t: (t[0], t[1], t[2]))
    
    # Convert tuples back to lists
    graph = [list(triple) for triple in graph]
    
    return {"review": review, "graph": graph}