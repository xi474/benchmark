import subprocess
result = subprocess.run(["python", "-B", "component_runtime.py", "check", "graph_facts"], capture_output=True, text=True, cwd="/app")
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("Return code:", result.returncode)