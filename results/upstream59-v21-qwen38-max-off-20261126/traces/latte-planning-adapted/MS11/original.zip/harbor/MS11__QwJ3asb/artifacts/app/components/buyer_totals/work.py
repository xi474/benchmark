def compute(payload):
    """按买家 ID 汇总属于 Cameras 或 Electronics 的行金额，每行只计一次；无购买为零。"""
    buyers = payload.get("buyers", [])
    orders = payload.get("orders", [])
    
    totals = {b: 0 for b in buyers}
    
    for order in orders:
        buyer = order["buyer"]
        if buyer not in totals:
            totals[buyer] = 0
        for line in order.get("lines", []):
            categories = line[0]
            quantity = line[1]
            unit_price = line[2]
            # Check if any category is Electronics or Cameras
            if "Electronics" in categories or "Cameras" in categories:
                totals[buyer] += quantity * unit_price
    
    return totals