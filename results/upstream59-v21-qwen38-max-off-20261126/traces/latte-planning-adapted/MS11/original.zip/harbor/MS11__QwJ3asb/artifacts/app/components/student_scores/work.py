def compute(payload):
    """按学生 ID 输出课程 1、2 非空成绩的百分制整型均值（sum×100 整除数量）。"""
    grades = payload.get("grades", [])
    students = payload.get("students", None)

    # Collect valid scores per student (course 1 or 2, score not null)
    student_scores = {}
    for row in grades:
        student_id, course, score = row[0], row[1], row[2]
        if course in (1, 2) and score is not None:
            if student_id not in student_scores:
                student_scores[student_id] = []
            student_scores[student_id].append(score)

    # Determine which students to include in the result
    if students is not None:
        all_students = students
    else:
        all_students = list(student_scores.keys())

    # Compute result: sum*100 // count for each student; 0 if no valid grades
    result = {}
    for student_id in all_students:
        scores = student_scores.get(student_id, [])
        if scores:
            total = sum(scores)
            count = len(scores)
            result[student_id] = total * 100 // count
        else:
            result[student_id] = 0

    return result