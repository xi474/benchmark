import os
for root, dirs, files in os.walk('/app'):
    # skip venv and __pycache__
    dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', 'latte-venv')]
    level = root.replace('/app', '').count(os.sep)
    indent = ' ' * 2 * level
    print(f'{indent}{os.path.basename(root)}/')
    subindent = ' ' * 2 * (level + 1)
    for file in files:
        print(f'{subindent}{file}')