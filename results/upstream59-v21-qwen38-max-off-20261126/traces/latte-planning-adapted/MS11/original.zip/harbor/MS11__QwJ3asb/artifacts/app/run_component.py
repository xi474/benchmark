import subprocess, sys
subprocess.run([sys.executable, "-B", "component_runtime.py", "run", "buyer_totals"])