import subprocess, sys
result = subprocess.run([sys.executable, "-B", "component_runtime.py", "run", "student_scores"], capture_output=True, text=True)
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("Return code:", result.returncode)