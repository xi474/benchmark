import subprocess, sys
from pathlib import Path
def test_latte_root_check():
    root = Path('/app')
    result = subprocess.run([sys.executable, 'public_check.py'], cwd=root, capture_output=True, text=True, timeout=180)
    assert result.returncode == 0, result.stdout + result.stderr
