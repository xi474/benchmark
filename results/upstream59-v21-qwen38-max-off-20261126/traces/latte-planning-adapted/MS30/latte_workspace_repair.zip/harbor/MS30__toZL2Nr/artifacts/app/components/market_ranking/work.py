def compute(payload):
    """按最新市场日的 30 天窗口、相对绝对涨跌幅和代号打破平局，返回前 top 个房间代号（保持排名）。"""
    market = payload["market"]
    top = payload["top"]

    # Find L = maximum teaching_day across ALL market rows
    L = max(row[1] for row in market)

    # Keep only events where teaching_day is in [L-29, L] inclusive (30-day window)
    filtered = [row for row in market if L - 29 <= row[1] <= L]

    # For each kept event, compute relative absolute change = abs(close - open) / open
    scored = []
    for row in filtered:
        event_id = row[0]
        open_price = row[2]
        close_price = row[3]
        change = abs(close_price - open_price) / open_price
        scored.append((event_id, change))

    # Sort descending by change value, breaking ties by event_id ascending (lexicographic)
    scored.sort(key=lambda x: (-x[1], x[0]))

    # Return the first `top` event_ids as a list
    return [item[0] for item in scored[:top]]