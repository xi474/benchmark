from fractions import Fraction
from collections import defaultdict


def compute(payload):
    """使用 16、17 号课程非空成绩的精确分数比，按原门槛输出学生到 P/D/N 层级映射。"""
    student_ratios = defaultdict(list)

    for row in payload["grades"]:
        student_id, course_id, score, max_score = row[0], row[1], row[2], row[3]

        # Filter to only courses 16 and 17 where score is not null
        if course_id not in (16, 17):
            continue
        if score is None:
            continue

        # Compute ratio using exact Fraction arithmetic
        ratio = Fraction(score, max_score)
        student_ratios[student_id].append(ratio)

    result = {}
    threshold_n = Fraction(60, 100)   # 0.60
    threshold_d = Fraction(75, 100)   # 0.75

    for student_id, ratios in student_ratios.items():
        if not ratios:
            continue

        # Equal-weight average of all ratios
        avg = sum(ratios) / len(ratios)

        # Classify
        if avg < threshold_n:
            result[student_id] = "N"
        elif avg < threshold_d:
            result[student_id] = "D"
        else:
            result[student_id] = "P"

    return result