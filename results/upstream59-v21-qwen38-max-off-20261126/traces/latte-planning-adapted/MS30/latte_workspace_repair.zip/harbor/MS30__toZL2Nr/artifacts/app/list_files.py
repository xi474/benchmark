import os
for root, dirs, files in os.walk('/app'):
    for f in files:
        path = os.path.join(root, f)
        print(path)