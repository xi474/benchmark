import subprocess, sys
sys.exit(subprocess.call([sys.executable, "-B", "component_runtime.py", "check", "student_tiers"]))