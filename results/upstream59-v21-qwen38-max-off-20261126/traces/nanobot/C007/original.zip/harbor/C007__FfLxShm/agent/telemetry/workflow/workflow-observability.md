# Workflow 可观测性报告

- Trial：`C007__FfLxShm__env`
- Task：`C007`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（57 节点 / 56 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：57；执行边：56（observed=0，inferred=56）
- Execution Trace Graph：`observed`；temporal_next 边 56，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_8499cce48de14ea4a05a8fbe -> tool:nanobot-harness-v3:call_7ea9dbf302c34a86a426a92d -> tool:nanobot-harness-v3:call_2aa79675d83c4ea89e02d395 -> tool:nanobot-harness-v3:call_7facc964081a47e3bc4621d0 -> tool:nanobot-harness-v3:call_78e4c13638e74093bfcff7a1 -> tool:nanobot-harness-v3:call_32c91ddbe32348528b312726 -> tool:nanobot-harness-v3:call_20c39ffde05e4b65b64e0b52 -> tool:nanobot-harness-v3:call_8a6ce765d56a4771a57e6128 -> tool:nanobot-harness-v3:call_c937d572b61845868e791979 -> tool:nanobot-harness-v3:call_31d7576ddfb542d3b028d775 -> tool:nanobot-harness-v3:call_7a8a52024ad646be91368b07 -> tool:nanobot-harness-v3:call_059abfc997204d4499089200 -> tool:nanobot-harness-v3:call_ede3d542c2604b69a0369ae5 -> tool:nanobot-harness-v3:call_ec8917c01b6741a889b44b2e -> tool:nanobot-harness-v3:call_19065566ecfc479aa9dc5996 -> tool:nanobot-harness-v3:call_8a9e0e65687b475dba44eb3e -> tool:nanobot-harness-v3:call_a6266ad7379449019e295808 -> tool:nanobot-harness-v3:call_52d2534dbf514d70b4efa89c -> tool:nanobot-harness-v3:call_f85079506f1f4c7ebe0a99bd -> tool:nanobot-harness-v3:call_c7182afbd8c5468696b54589 -> tool:nanobot-harness-v3:call_41f832c1354946e88303e795 -> tool:nanobot-harness-v3:call_8a69f6d101d74d8890b54a81 -> tool:nanobot-harness-v3:call_3098f2a11ac44d15a1110fab -> tool:nanobot-harness-v3:call_8ed0b1414dff4acaa81e437a -> tool:nanobot-harness-v3:call_5c84fdd0dff948ec965b12e4 -> tool:nanobot-harness-v3:call_bf15c07477ba4dc18f6b5c6d -> tool:nanobot-harness-v3:call_0c72eb57f1294babbee8c27d -> tool:nanobot-harness-v3:call_4c8237663f0c48eb96b489c3 -> tool:nanobot-harness-v3:call_0a098e213764413091fe411e -> tool:nanobot-harness-v3:call_76750853ce154c0fad981706 -> tool:nanobot-harness-v3:call_9035aca5217a49a183bd66de -> tool:nanobot-harness-v3:call_36f94e969d2c4a64ba5c340d -> tool:nanobot-harness-v3:call_c2d2330da4a54a5484f5e97f -> tool:nanobot-harness-v3:call_271d3ebee04143bc88f67abb -> tool:nanobot-harness-v3:call_32d85917edfa4fb396df8c9d -> tool:nanobot-harness-v3:call_cda8e440332548e399f329a1 -> tool:nanobot-harness-v3:call_db634a57021249419e727968 -> tool:nanobot-harness-v3:call_689f2b1e18b948a6a3b34bc6 -> tool:nanobot-harness-v3:call_0c79cbff553b47f7a2a202c9 -> tool:nanobot-harness-v3:call_84234a498bee4d2eae4f7ad7 -> tool:nanobot-harness-v3:call_e9ffbe6163704c2198f0f98a -> tool:nanobot-harness-v3:call_b18690054d3a4c238d06c939 -> tool:nanobot-harness-v3:call_b82a5eadeb324d3a8517365a -> tool:nanobot-harness-v3:call_e35bb16363eb46ca82af2d8d -> tool:nanobot-harness-v3:call_2f4317c6c410494ea68b5cc8 -> tool:nanobot-harness-v3:call_3dd1fed1606942769399d15f -> tool:nanobot-harness-v3:call_d020bd32bbb04d3e9e48e88c -> tool:nanobot-harness-v3:call_d590d1e836264de6addc4bd4 -> tool:nanobot-harness-v3:call_d933cf69c950498a9f5fce16 -> tool:nanobot-harness-v3:call_5e9195356b214f669c59d566 -> tool:nanobot-harness-v3:call_cc9aaa30480a42018e3a10a5 -> tool:nanobot-harness-v3:call_bd469612b6d145078785740f -> tool:nanobot-harness-v3:call_36f8f66c2ee74315bd355fc1 -> tool:nanobot-harness-v3:call_6533b5c7f509410589040c09 -> tool:nanobot-harness-v3:call_7474222a731a41168fb079c8 -> tool:nanobot-harness-v3:call_21ea5d23733e4c9d9c04d56b
- 关键路径耗时：0.526771
- Makespan：553.802754
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
