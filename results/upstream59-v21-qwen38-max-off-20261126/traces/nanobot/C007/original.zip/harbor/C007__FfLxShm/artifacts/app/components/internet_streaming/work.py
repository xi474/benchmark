import re

_MONTHS = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _clean_text(s):
    if not s:
        return ''
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    if not s:
        return ''
    return re.sub(r'[^0-9]', '', s)


def _parse_internet_birth_date(s):
    # MM/DD/YYYY -> YYYY-MM-DD
    if not s:
        return ''
    parts = s.split('/')
    if len(parts) == 3:
        mm, dd, yyyy = parts
        return yyyy + '-' + mm.zfill(2) + '-' + dd.zfill(2)
    return s


def _parse_streaming_dob(s):
    # DD Mon YYYY -> YYYY-MM-DD
    if not s:
        return ''
    parts = s.strip().split()
    if len(parts) == 3:
        dd, mon, yyyy = parts
        mm = _MONTHS.get(mon.lower()[:3], '00')
        return yyyy + '-' + mm + '-' + dd.zfill(2)
    return s


def compute(payload):
    records = payload.get('records', [])
    result = []
    for idx, rec in enumerate(records):
        src = rec.get('source', '')
        if src not in ('internet', 'streaming'):
            continue
        fields = rec.get('fields', {})
        rid = rec['id']

        if src == 'internet':
            full_name = fields.get('full_name', '')
            name_parts = full_name.strip().split(None, 1)
            if len(name_parts) == 2:
                first = _clean_text(name_parts[0])
                last = _clean_text(name_parts[1])
            elif len(name_parts) == 1:
                first = _clean_text(name_parts[0])
                last = ''
            else:
                first = ''
                last = ''
            dob = _parse_internet_birth_date(fields.get('birth_date', ''))
            ssn = ''
            mail = _clean_text(fields.get('mail', ''))
            phone = _digits_only(fields.get('tel', ''))
            address = _clean_text(fields.get('street', ''))
        else:  # streaming
            customer = fields.get('customer', '')
            name_parts = customer.strip().split(None, 1)
            if len(name_parts) == 2:
                first = _clean_text(name_parts[0])
                last = _clean_text(name_parts[1])
            elif len(name_parts) == 1:
                first = _clean_text(name_parts[0])
                last = ''
            else:
                first = ''
                last = ''
            dob = _parse_streaming_dob(fields.get('date_of_birth', ''))
            ssn = ''
            mail = _clean_text(fields.get('email', ''))
            phone = _digits_only(fields.get('telephone', ''))
            address = _clean_text(fields.get('address', ''))

        obj = {
            'id': rid,
            'first': first,
            'last': last,
            'dob': dob,
            'ssn': ssn,
            'mail': mail,
            'phone': phone,
            'address': address,
        }
        result.append([idx, obj])
    return result
