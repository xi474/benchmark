import re

_MONTHS = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _clean_text(s):
    if not s:
        return ''
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    if not s:
        return ''
    return re.sub(r'[^0-9]', '', s)


def _parse_mobile_dob(s):
    # Already YYYY-MM-DD
    return s


def _parse_cable_birth(s):
    # YYYYMMDD -> YYYY-MM-DD
    if len(s) == 8:
        return s[:4] + '-' + s[4:6] + '-' + s[6:8]
    return s


def compute(payload):
    records = payload.get('records', [])
    result = []
    for idx, rec in enumerate(records):
        src = rec.get('source', '')
        if src not in ('mobile', 'cable'):
            continue
        fields = rec.get('fields', {})
        rid = rec['id']

        if src == 'mobile':
            first = _clean_text(fields.get('first', ''))
            last = _clean_text(fields.get('last', ''))
            dob = _parse_mobile_dob(fields.get('dob', ''))
            ssn = _digits_only(fields.get('ssn', ''))
            mail = _clean_text(fields.get('email', ''))
            phone = _digits_only(fields.get('phone', ''))
            address = _clean_text(fields.get('address', ''))
        else:  # cable
            lf = fields.get('last_first', '')
            parts = lf.split(',', 1)
            if len(parts) == 2:
                last = _clean_text(parts[0])
                first = _clean_text(parts[1])
            else:
                last = _clean_text(lf)
                first = ''
            dob = _parse_cable_birth(fields.get('birth', ''))
            ssn = _digits_only(fields.get('government_id', ''))
            mail = _clean_text(fields.get('contact', ''))
            phone = _digits_only(fields.get('phone', ''))
            address = _clean_text(fields.get('location', ''))

        obj = {
            'id': rid,
            'first': first,
            'last': last,
            'dob': dob,
            'ssn': ssn,
            'mail': mail,
            'phone': phone,
            'address': address,
        }
        result.append([idx, obj])
    return result
