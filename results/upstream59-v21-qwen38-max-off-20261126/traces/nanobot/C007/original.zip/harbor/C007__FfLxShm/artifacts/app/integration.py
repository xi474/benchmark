"""Entity resolution: combine standardized records into clusters."""


def _edit_distance_1(a, b):
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if a == b:
        return True
    if la == lb:
        diff = sum(1 for i in range(la) if a[i] != b[i])
        return diff <= 1
    if la > lb:
        a, b = b, a
        la, lb = lb, la
    i = j = 0
    skipped = False
    while i < la and j < lb:
        if a[i] != b[j]:
            if skipped:
                return False
            skipped = True
            j += 1
        else:
            i += 1
            j += 1
    return True


def _ssn_last4(ssn):
    return ssn[-4:] if len(ssn) >= 4 else ''


def _is_full_ssn(ssn):
    return len(ssn) == 9


def _is_partial_ssn(ssn):
    return 0 < len(ssn) < 9


def _first_names_compatible(fa, fb, ambig):
    if not fa or not fb:
        return True
    if fa == fb:
        return True
    if fa.startswith(fb) or fb.startswith(fa):
        return True
    # If either is an ambiguous nickname, they're compatible
    if fa in ambig or fb in ambig:
        return True
    return False


def _has_conflict(a, b, ambig):
    sa, sb = a['ssn'], b['ssn']
    if _is_full_ssn(sa) and _is_full_ssn(sb) and sa != sb:
        return True
    if _is_full_ssn(sa) and _is_partial_ssn(sb) and not sa.endswith(sb):
        return True
    if _is_full_ssn(sb) and _is_partial_ssn(sa) and not sb.endswith(sa):
        return True
    if a['dob'] and b['dob'] and a['dob'] != b['dob']:
        return True
    if a['first'] and b['first'] and not _first_names_compatible(a['first'], b['first'], ambig):
        return True
    return False


def _score_pair(a, b, ambig):
    score = 0.0
    if a['last'] and b['last'] and a['last'] == b['last']:
        score += 1.0
    if a['dob'] and b['dob'] and a['dob'] == b['dob']:
        score += 1.5
    if a['first'] and b['first'] and a['first'] == b['first']:
        score += 1.0
    elif a['first'] and b['first'] and _first_names_compatible(a['first'], b['first'], ambig):
        score += 0.3
    sa, sb = a['ssn'], b['ssn']
    if sa and sb:
        if sa == sb and _is_full_ssn(sa):
            score += 3.0
        elif _is_full_ssn(sa) and _is_partial_ssn(sb) and sa.endswith(sb):
            score += 2.0
        elif _is_full_ssn(sb) and _is_partial_ssn(sa) and sb.endswith(sa):
            score += 2.0
        elif _is_partial_ssn(sa) and _is_partial_ssn(sb) and sa == sb:
            score += 0.5
    ma, mb = a['mail'], b['mail']
    if ma and mb:
        if ma == mb:
            score += 0.5
        elif _edit_distance_1(ma, mb):
            score += 1.5
    if a['phone'] and b['phone'] and a['phone'] == b['phone']:
        score += 0.3
    if a['address'] and b['address'] and a['address'] == b['address']:
        score += 0.2
    return score


def combine(payload, left, right):
    all_records = [item[1] for item in left] + [item[1] for item in right]
    n = len(all_records)
    if n == 0:
        return {"clusters": []}

    ambig = set()
    for name in payload.get('ambiguous_names', []):
        import re
        ambig.add(re.sub(r'[^a-z0-9]', '', name.lower()))

    # Build candidate pairs via blocking
    last_dob = {}
    email_blk = {}
    phone_last = {}
    ssn4_last = {}
    for i, r in enumerate(all_records):
        k = (r['last'], r['dob'])
        if k[0] and k[1]:
            last_dob.setdefault(k, []).append(i)
        m = r['mail']
        if m:
            email_blk.setdefault(m, []).append(i)
        k2 = (r['phone'], r['last'])
        if k2[0] and k2[1]:
            phone_last.setdefault(k2, []).append(i)
        l4 = _ssn_last4(r['ssn'])
        if l4 and r['last']:
            ssn4_last.setdefault((l4, r['last']), []).append(i)

    cands = set()
    for blk in (last_dob, email_blk, phone_last, ssn4_last):
        for members in blk.values():
            for i in range(len(members)):
                for j in range(i + 1, len(members)):
                    cands.add((members[i], members[j]))

    mail_list = [(i, all_records[i]['mail']) for i in range(n) if all_records[i]['mail']]
    for i in range(len(mail_list)):
        for j in range(i + 1, len(mail_list)):
            ii, mi = mail_list[i]
            jj, mj = mail_list[j]
            if _edit_distance_1(mi, mj):
                cands.add((ii, jj))

    # Build scored non-conflicting edge list
    edges = []
    for (a, b) in cands:
        if _has_conflict(all_records[a], all_records[b], ambig):
            continue
        score = _score_pair(all_records[a], all_records[b], ambig)
        if score >= 3.0:
            edges.append((score, a, b))

    edges.sort(reverse=True)

    # Greedy seed-and-grow with pairwise conflict check
    assigned = [False] * n
    clusters = []  # list of sets of indices

    for score, a, b in edges:
        ca = cb = -1
        for ci, cl in enumerate(clusters):
            if a in cl:
                ca = ci
            if b in cl:
                cb = ci
        if ca >= 0 and cb >= 0:
            continue  # already same or different clusters
        if ca >= 0:
            ok = all(not _has_conflict(all_records[b], all_records[m], ambig) for m in clusters[ca])
            if ok:
                clusters[ca].add(b)
                assigned[b] = True
        elif cb >= 0:
            ok = all(not _has_conflict(all_records[a], all_records[m], ambig) for m in clusters[cb])
            if ok:
                clusters[cb].add(a)
                assigned[a] = True
        else:
            clusters.append({a, b})
            assigned[a] = True
            assigned[b] = True

    for i in range(n):
        if not assigned[i]:
            clusters.append({i})

    result = [[all_records[i]['id'] for i in cl] for cl in clusters]
    return {"clusters": result}
