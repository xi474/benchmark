# Workflow 可观测性报告

- Trial：`C008__XtpJxNP__env`
- Task：`C008`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_18195c3953d940f4824bf10b -> tool:nanobot-harness-v3:call_9191fc89dce24792bb7a4dd7 -> tool:nanobot-harness-v3:call_2c93928ec3074c5b92a27866 -> tool:nanobot-harness-v3:call_74e1f525b3364fc2b087d0cd -> tool:nanobot-harness-v3:call_abe9eb3b5af9429ea92a0715 -> tool:nanobot-harness-v3:call_fb43d9ade89248a7905002c4 -> tool:nanobot-harness-v3:call_44db55cf8f4b43d1be5989ea -> tool:nanobot-harness-v3:call_321c6c242a50404d94802b84 -> tool:nanobot-harness-v3:call_c1ddcc2d43ac44bfb2db74cf -> tool:nanobot-harness-v3:call_99083f85753f43799922a15c -> tool:nanobot-harness-v3:call_3c1c9c2e0a9b403985336091 -> tool:nanobot-harness-v3:call_40baf74a592f46ce9cff335b -> tool:nanobot-harness-v3:call_b56397c6c3e249ab801b27b0 -> tool:nanobot-harness-v3:call_666e6cbe2d2d42d08da760f6 -> tool:nanobot-harness-v3:call_c05d6a701768477dbd331fe0 -> tool:nanobot-harness-v3:call_2c162e0b9ec94ab8be5aeaa7 -> tool:nanobot-harness-v3:call_c604b58e051647808cfe5250 -> tool:nanobot-harness-v3:call_3fcda5ef28e141e5a8734893 -> tool:nanobot-harness-v3:call_5439de5208ce48939f3b18d5 -> tool:nanobot-harness-v3:call_fd9b9ad20c724cd3a55f9a4d -> tool:nanobot-harness-v3:call_ae49993a1c0849ab9a996c83 -> tool:nanobot-harness-v3:call_5c764bc9470a4fe1a8ac00b0 -> tool:nanobot-harness-v3:call_5197204bd25544ba91af3e8f -> tool:nanobot-harness-v3:call_5bf9a4ebc4bb42c9b8822075 -> tool:nanobot-harness-v3:call_81bdca6d9411404c8d96fd38 -> tool:nanobot-harness-v3:call_c37897bae3db4973a4d6c5a2 -> tool:nanobot-harness-v3:call_06ca0412256842e898a369c5 -> tool:nanobot-harness-v3:call_f61d77a81cef471eac50a684 -> tool:nanobot-harness-v3:call_d2bc776507594e539880c71b -> tool:nanobot-harness-v3:call_46799bcdcc4f4864a27650fe -> tool:nanobot-harness-v3:call_a467b79505784d65b4e4b0b4 -> tool:nanobot-harness-v3:call_1fc1a03ab36143c2be13d0cb -> tool:nanobot-harness-v3:call_59701417a7be4ad9be415de6 -> tool:nanobot-harness-v3:call_1615ffb4ee244827885ec5cd
- 关键路径耗时：0.330685
- Makespan：49.453118
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
