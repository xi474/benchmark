def compute(payload):
    """将链接和合并登记为 [起点,终点,生效时刻,失效时刻]。保留原顺序并补齐缺省区间。"""
    DEFAULT_TO = 1000000000000000000
    result = []
    for link in payload.get("links", []):
        a = link["a"]
        b = link["b"]
        frm = link.get("from", 0)
        to = link.get("to", DEFAULT_TO)
        result.append([a, b, frm, to])
    for merge in payload.get("merges", []):
        a = merge["a"]
        b = merge["b"]
        frm = merge.get("from", 0)
        to = merge.get("to", DEFAULT_TO)
        result.append([a, b, frm, to])
    return result
