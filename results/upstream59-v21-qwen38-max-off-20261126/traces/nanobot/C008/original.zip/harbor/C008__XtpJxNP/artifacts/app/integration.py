import json
import hashlib


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = relationship_windows result: [[a, b, from, to], ...]
    right = record_subjects result:      [[table, id, time, [tenant, subject]], ...]
    """
    seed = payload["seed"]
    windows = left   # list of [endpoint_a, endpoint_b, from_time, to_time]
    recs = right     # list of [table, id, time, [tenant, subject]]

    # For each record, find connected component at that record's time
    output_records = []
    for table, rid, t, subj in recs:
        tenant, subject = subj

        # Build adjacency for relationships active at time t
        # Collect all nodes that appear in any active relationship + this record's node
        adj = {}

        def add_edge(u, v):
            adj.setdefault(u, set()).add(v)
            adj.setdefault(v, set()).add(u)

        # Ensure this record's node is present even if isolated
        my_node = (tenant, subject)
        adj.setdefault(my_node, set())

        for w in windows:
            a_node = tuple(w[0])
            b_node = tuple(w[1])
            frm = w[2]
            to = w[3]
            # Left-closed, right-open interval
            if frm <= t < to:
                add_edge(a_node, b_node)

        # BFS/DFS to find connected component containing my_node
        visited = set()
        stack = [my_node]
        while stack:
            node = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            for neighbor in adj.get(node, set()):
                if neighbor not in visited:
                    stack.append(neighbor)

        # Canonical = lexicographically smallest (tenant, subject) tuple
        canonical = min(visited)
        canonical_tenant, canonical_subject = canonical

        # Build raw string and compute token
        raw = json.dumps(
            [str(seed), canonical_tenant, canonical_subject],
            ensure_ascii=True,
            separators=(',', ':')
        )
        raw_bytes = raw.encode('utf-8')
        sha = hashlib.sha256(raw_bytes).hexdigest()
        token = 'ref_' + sha[:12]

        output_records.append({
            "table": table,
            "id": rid,
            "time": t,
            "token": token
        })

    return {"records": output_records}
