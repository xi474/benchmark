# Workflow 可观测性报告

- Trial：`C009__rHi7iWE__env`
- Task：`C009`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_50c333d8f4164e489163bc1e -> tool:nanobot-harness-v3:call_91c81dc032634c1884b87d3a -> tool:nanobot-harness-v3:call_2196fdbfe0ce4a4babb7b7cb -> tool:nanobot-harness-v3:call_b95dea3ef7894862a0a34f02 -> tool:nanobot-harness-v3:call_e7d27aff761545c1a543156c -> tool:nanobot-harness-v3:call_80c4f67101aa41b1b6f4a0ed -> tool:nanobot-harness-v3:call_3432402c00004063984ef4c5 -> tool:nanobot-harness-v3:call_527c7bd511bd4c6fa7855674 -> tool:nanobot-harness-v3:call_8934ed0435724fa18668a8cf -> tool:nanobot-harness-v3:call_23e820c0cee0467aad69a3b7 -> tool:nanobot-harness-v3:call_4eff7a4721164677a8526036 -> tool:nanobot-harness-v3:call_9c84941187ad4507a394bd71 -> tool:nanobot-harness-v3:call_1efee6cdfe3040c7bb005932 -> tool:nanobot-harness-v3:call_1b9f2062ea9e490d8668cf82 -> tool:nanobot-harness-v3:call_f7765789cafa43f9a213a667 -> tool:nanobot-harness-v3:call_89901a6e4143421dbb08c56e -> tool:nanobot-harness-v3:call_d943a68ec5844e91ac01e25f -> tool:nanobot-harness-v3:call_91c25081232f40cdbdb261aa -> tool:nanobot-harness-v3:call_72b28d4e797344eb802bbeac -> tool:nanobot-harness-v3:call_01f861bf3b164038a00114aa -> tool:nanobot-harness-v3:call_c5fabee6d82f446182394e84 -> tool:nanobot-harness-v3:call_35e03a547b9a476da72e567e -> tool:nanobot-harness-v3:call_2226c5f46bfb4d03923c16b4 -> tool:nanobot-harness-v3:call_8a1fa1d307a9414882e50183 -> tool:nanobot-harness-v3:call_e7be8efbd1434ab384a7b477 -> tool:nanobot-harness-v3:call_3b252465940c48b58cd3c6bf -> tool:nanobot-harness-v3:call_daf3b7f5cc1448d1ba329b58 -> tool:nanobot-harness-v3:call_e9030560a7ee444bafb65a57 -> tool:nanobot-harness-v3:call_d233d357f8b541c6b8ac9b84 -> tool:nanobot-harness-v3:call_3c6f968fa32f47e78c6c44b4 -> tool:nanobot-harness-v3:call_f0c0d780410e4392a451b012 -> tool:nanobot-harness-v3:call_0d605cd7ac844fcda2f9556a -> tool:nanobot-harness-v3:call_b001b1946d7940d0bd14b1ca
- 关键路径耗时：0.37892
- Makespan：135.276951
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
