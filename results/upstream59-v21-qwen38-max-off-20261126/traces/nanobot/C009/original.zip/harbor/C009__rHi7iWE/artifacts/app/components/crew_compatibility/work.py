def compute(payload):
    """返回每辆车可使用的司机 ID 数组，保留司机声明顺序。"""
    vehicles = payload.get("vehicles", [])
    drivers = payload.get("drivers", [])
    result = {}
    for v in vehicles:
        vtype = v["type"]
        compatible = [d["id"] for d in drivers if vtype in d["types"]]
        result[v["id"]] = compatible
    return result
