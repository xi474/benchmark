def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    sorted_events = left  # sorted by (visible, id)
    compat = right  # vehicle_id -> [driver_ids]

    rounds_spec = payload["rounds"]
    committed = []
    cancelled_set = set()
    result_rounds = []

    for rnd in rounds_spec:
        cutoff = rnd["cutoff"]
        do_commit = rnd["commit"]
        visible_events = [e for e in sorted_events if e["visible"] <= cutoff]

        cancelled_this_round = []
        ignored_cancellations = []

        for ev in visible_events:
            if ev["kind"] == "cancel":
                job_id = ev["job"]
                if job_id in cancelled_set:
                    continue
                found_committed = None
                for a in committed:
                    if a["job"] == job_id:
                        found_committed = a
                        break
                if found_committed is not None:
                    if found_committed["start"] < cutoff:
                        ignored_cancellations.append(job_id)
                    else:
                        committed = [a for a in committed if a["job"] != job_id]
                        cancelled_set.add(job_id)
                        cancelled_this_round.append(job_id)
                else:
                    cancelled_set.add(job_id)
                    cancelled_this_round.append(job_id)

        cancelled_this_round = sorted(set(cancelled_this_round))
        ignored_cancellations = sorted(set(ignored_cancellations))

        pending_jobs = {}
        for ev in visible_events:
            if ev["kind"] == "request":
                jid = ev["job"]["id"]
                if jid not in cancelled_set:
                    already = any(a["job"] == jid for a in committed)
                    if not already:
                        pending_jobs[jid] = ev["job"]

        new_assignments = _optimize(
            pending_jobs, vehicles, drivers, suppliers, compat,
            committed, cutoff
        )

        if do_commit:
            committed.extend(new_assignments)

        if do_commit:
            all_assignments = list(committed)
        else:
            all_assignments = list(committed) + list(new_assignments)

        all_assignments.sort(
            key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])
        )
        total_profit = sum(a["profit"] for a in all_assignments)

        result_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments,
            "profit": total_profit,
            "cancelled": cancelled_this_round,
            "ignored_cancellations": ignored_cancellations,
        })

    return {"rounds": result_rounds}


def _optimize(pending_jobs, vehicles, drivers, suppliers, compat, committed, cutoff):
    """Find optimal new assignments: max profit, max count, min lex tuples."""
    if not pending_jobs:
        return []

    options_by_job = {}
    for jid, job in pending_jobs.items():
        opts = []
        jtype = job["type"]
        qty = job["quantity"]
        release = job["release"]
        deadline = job["deadline"]
        duration = job["duration"]
        revenue = job["revenue"]
        job_suppliers = job["suppliers"]
        earliest_start = max(cutoff, release)

        for vid, veh in vehicles.items():
            if veh["type"] != jtype or veh["capacity"] < qty:
                continue
            compatible_drivers = compat.get(vid, [])
            for did in compatible_drivers:
                for sid in job_suppliers:
                    sup = suppliers[sid]
                    min_s = earliest_start
                    max_s = min(deadline - duration, sup["close"])
                    if min_s > max_s:
                        continue
                    for start in range(min_s, max_s + 1):
                        end = start + duration
                        profit = revenue - qty * sup["unit_cost"] - veh["cost"] * duration
                        opts.append({
                            "job": jid, "vehicle": vid, "driver": did,
                            "supplier": sid, "start": start, "end": end,
                            "quantity": qty, "profit": profit,
                        })
        options_by_job[jid] = opts

    vehicle_intervals = {}
    driver_intervals = {}
    supplier_used = {}
    driver_tasks = {}

    for a in committed:
        vehicle_intervals.setdefault(a["vehicle"], []).append((a["start"], a["end"]))
        driver_intervals.setdefault(a["driver"], []).append((a["start"], a["end"]))
        supplier_used[a["supplier"]] = supplier_used.get(a["supplier"], 0) + a["quantity"]
        driver_tasks.setdefault(a["driver"], []).append((a["start"], a["end"]))

    job_ids = sorted(pending_jobs.keys())
    best = [None]  # [profit, count, tuples, assignments]

    def check_feasible(new_list):
        vi = {k: list(v) for k, v in vehicle_intervals.items()}
        di = {k: list(v) for k, v in driver_intervals.items()}
        su = dict(supplier_used)
        dt = {k: list(v) for k, v in driver_tasks.items()}

        for a in new_list:
            vid, did, sid = a["vehicle"], a["driver"], a["supplier"]
            s, e, qty = a["start"], a["end"], a["quantity"]
            for (cs, ce) in vi.get(vid, []):
                if s < ce and e > cs:
                    return False
            vi.setdefault(vid, []).append((s, e))
            for (cs, ce) in di.get(did, []):
                if s < ce and e > cs:
                    return False
            di.setdefault(did, []).append((s, e))
            sup = suppliers[sid]
            used = su.get(sid, 0) + qty
            if used > sup["stock"]:
                return False
            su[sid] = used
            dt.setdefault(did, []).append((s, e))

        for did, tasks in dt.items():
            drv = drivers[did]
            sorted_tasks = sorted(tasks)
            total_work = sum(e - s for s, e in sorted_tasks)
            if total_work > drv["max_work"]:
                return False
            cont = 0
            for i, (s, e) in enumerate(sorted_tasks):
                dur = e - s
                if i == 0:
                    cont = dur
                else:
                    gap = s - sorted_tasks[i - 1][1]
                    cont = dur if gap >= drv["break"] else cont + dur
                if cont > drv["max_continuous"]:
                    return False
        return True


    def update_best(current, current_profit):
        if not current:
            cp, cc = 0, 0
            ct = []
        else:
            cp = current_profit
            cc = len(current)
            ct = sorted(
                [(a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])
                 for a in current]
            )
        if best[0] is None:
            best[0] = (cp, cc, ct, list(current))
        else:
            bp, bc, bt, _ = best[0]
            if cp > bp:
                best[0] = (cp, cc, ct, list(current))
            elif cp == bp:
                if cc > bc:
                    best[0] = (cp, cc, ct, list(current))
                elif cc == bc and ct < bt:
                    best[0] = (cp, cc, ct, list(current))

    def search(idx, current, current_profit):
        if idx == len(job_ids):
            update_best(current, current_profit)
            return
        jid = job_ids[idx]
        opts = options_by_job.get(jid, [])
        # Skip this job
        search(idx + 1, current, current_profit)
        # Try each option
        for opt in opts:
            candidate = current + [opt]
            if check_feasible(candidate):
                search(idx + 1, candidate, current_profit + opt["profit"])

    search(0, [], 0)
    if best[0] is None:
        return []
    return best[0][3]
