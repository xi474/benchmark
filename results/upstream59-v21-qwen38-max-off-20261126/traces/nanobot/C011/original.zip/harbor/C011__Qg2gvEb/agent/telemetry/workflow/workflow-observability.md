# Workflow 可观测性报告

- Trial：`C011__Qg2gvEb__env`
- Task：`C011`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（48 节点 / 47 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：48；执行边：47（observed=0，inferred=47）
- Execution Trace Graph：`observed`；temporal_next 边 47，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_831954214fe34b70a9de0553 -> tool:nanobot-harness-v3:call_02e82e427e67454396ccd92d -> tool:nanobot-harness-v3:call_823ba7a505214bcf87bd22fe -> tool:nanobot-harness-v3:call_84458e3718cb41148f6a2730 -> tool:nanobot-harness-v3:call_7249afaedeae4aa79504b1b7 -> tool:nanobot-harness-v3:call_418072bfbd834262b3ebee64 -> tool:nanobot-harness-v3:call_e1ede51524a2405bb927aa70 -> tool:nanobot-harness-v3:call_e24f9198ce494e8f9010f27c -> tool:nanobot-harness-v3:call_c0a102afafc3432cbad25a32 -> tool:nanobot-harness-v3:call_2597a8b9d3ef4ad98b63576a -> tool:nanobot-harness-v3:call_c9f34bed3ba64c7b9b0196f3 -> tool:nanobot-harness-v3:call_f82c225367274ef4b21176e0 -> tool:nanobot-harness-v3:call_04263d8415dc473baef5c273 -> tool:nanobot-harness-v3:call_d232f17e9c144f86a587e744 -> tool:nanobot-harness-v3:call_ef8a7e1e064c4a0e8255b90c -> tool:nanobot-harness-v3:call_aa1647ed140f409d9c2b3726 -> tool:nanobot-harness-v3:call_7c7065919c124ec9943b7d9a -> tool:nanobot-harness-v3:call_1c455a4580f045eb8bda7b0a -> tool:nanobot-harness-v3:call_5c7fbbd8d8484d70a42672ca -> tool:nanobot-harness-v3:call_074752134a794572b47ea5f3 -> tool:nanobot-harness-v3:call_60dc67551b804f2a87c0903f -> tool:nanobot-harness-v3:call_e35331c0327243e49389de67 -> tool:nanobot-harness-v3:call_787ea7a52927427c895b31ac -> tool:nanobot-harness-v3:call_f914c3a3bbdc4d7d9f7deeac -> tool:nanobot-harness-v3:call_40a5845b518045919bfda7a0 -> tool:nanobot-harness-v3:call_18c40a9d4f1f438b810bdfd3 -> tool:nanobot-harness-v3:call_b97269eeb44c4ced89e60d6b -> tool:nanobot-harness-v3:call_303fe3a1f06f4bce9c472a7a -> tool:nanobot-harness-v3:call_c705b75d6c9647ed8ef28c91 -> tool:nanobot-harness-v3:call_ab2ec4db454e486db1a7f582 -> tool:nanobot-harness-v3:call_cd50c4e2c6cc41c1962bead7 -> tool:nanobot-harness-v3:call_d184c790a93746c5b77b0027 -> tool:nanobot-harness-v3:call_cd4f32bf36ea4d11bd67011e -> tool:nanobot-harness-v3:call_4d838fe0473c40fb848e406a -> tool:nanobot-harness-v3:call_27b5d8cc8285476a8ac0d799 -> tool:nanobot-harness-v3:call_3a67ecb88827428190b81551 -> tool:nanobot-harness-v3:call_340b01373c054faa972d41cf -> tool:nanobot-harness-v3:call_38287f1a2aeb416ba1a319be -> tool:nanobot-harness-v3:call_af6f7ca2467044b397cf18d2 -> tool:nanobot-harness-v3:call_0054610f712b4ad0ae05267e -> tool:nanobot-harness-v3:call_dadc385d00c146ab9b3461cd -> tool:nanobot-harness-v3:call_ed69c672b3e54360ba21cd9d -> tool:nanobot-harness-v3:call_8e1995ea083646c2883c7bf1 -> tool:nanobot-harness-v3:call_5cf1144acb554554a36ee92e -> tool:nanobot-harness-v3:call_0f4a4c22c2c444cea604206d -> tool:nanobot-harness-v3:call_6b476a1fe316420faf60413b -> tool:nanobot-harness-v3:call_41f1e540c4b04a178a86a3b6
- 关键路径耗时：0.603436
- Makespan：324.85227
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
