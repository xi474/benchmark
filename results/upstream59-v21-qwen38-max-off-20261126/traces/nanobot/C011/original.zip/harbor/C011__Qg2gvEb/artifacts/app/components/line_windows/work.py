def compute(payload):
    """按工单 ID 输出合格产线及可行起止窗口三元组，按产线及起点的原遍历顺序。"""
    orders = payload["orders"]
    released = set(payload["released"])
    routing = payload["routing"]
    lines = payload["lines"]
    wip_list = payload.get("wip", [])
    freeze = payload["freeze"]
    changeover = payload["changeover"]

    # Precompute per-line earliest start after all WIP on that line
    # WIP occupies first position; other tasks must start >= max(wip.end) + changeover
    line_wip_end = {}
    for w in wip_list:
        ln = w["line"]
        end = w["end"]
        if ln not in line_wip_end or end > line_wip_end[ln]:
            line_wip_end[ln] = end

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]

        if sku not in released:
            result[oid] = []
            continue

        rt = routing[sku]
        duration = rt["setup"] + rt["per_unit"] * qty

        triples = []
        for line in lines:
            lid = line["id"]
            if sku not in line["qualified"]:
                continue

            # Earliest start on this line considering freeze and WIP
            earliest = freeze
            if lid in line_wip_end:
                earliest = max(earliest, line_wip_end[lid] + changeover)

            for win_start, win_end in line["windows"]:
                # Task [start, start+duration) must fit in [win_start, win_end)
                # and start >= earliest, and start+duration <= due
                lo = max(win_start, earliest)
                hi = min(win_end - duration, due - duration)
                for s in range(lo, hi + 1):
                    e = s + duration
                    triples.append([lid, s, e])

        result[oid] = triples
    return result
