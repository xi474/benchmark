def compute(payload):
    """按工单 ID 输出递归展开后的基础物料需求映射。"""
    orders = payload["orders"]
    bom = payload["bom"]

    # A leaf is any material that does NOT appear as a key in bom.
    def expand(sku, multiplier, acc):
        if sku not in bom:
            # Leaf node
            acc[sku] = acc.get(sku, 0) + multiplier
        else:
            for child, qty in bom[sku].items():
                expand(child, multiplier * qty, acc)

    result = {}
    for order in orders:
        demand = {}
        expand(order["sku"], order["qty"], demand)
        result[order["id"]] = demand
    return result
