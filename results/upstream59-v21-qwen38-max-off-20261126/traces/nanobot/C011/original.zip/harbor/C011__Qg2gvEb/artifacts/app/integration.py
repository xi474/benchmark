def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    import itertools

    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    lines_info = {l["id"]: l for l in payload["lines"]}
    orders = {o["id"]: o for o in payload["orders"]}
    wip_list = payload.get("wip", [])
    lots = payload.get("lots", [])
    substitutes = payload.get("substitutes", {})

    # left = material_demand: {order_id: {component: qty}}
    # right = line_windows: {order_id: [[line, start, end], ...]}

    valid_lots = [l for l in lots if l["status"] == "PASS"]
    lots_by_material = {}
    for lt in valid_lots:
        mat = lt["material"]
        if mat not in lots_by_material:
            lots_by_material[mat] = []
        lots_by_material[mat].append(lt)
    for mat in lots_by_material:
        lots_by_material[mat].sort(key=lambda x: x["id"])

    def get_substitutes(component):
        return substitutes.get(component, [component])

    def _canon_alloc(alloc):
        items = []
        for comp in sorted(alloc.keys()):
            for lid, qty in sorted(alloc[comp]):
                if qty > 0:
                    items.append((comp, lid, qty))
        return items

    def _enum_splits(needed, lots_avail):
        """Enumerate all ways to allocate 'needed' units across lots_avail.
        lots_avail: list of (lot_id, max_qty). Returns list of [(lot_id, qty), ...]."""
        if needed == 0:
            return [[]]
        if not lots_avail:
            return []
        results = []
        lid, max_q = lots_avail[0]
        rest = lots_avail[1:]
        for take in range(0, min(needed, max_q) + 1):
            if take == 0:
                for sub in _enum_splits(needed, rest):
                    results.append(sub)
            else:
                for sub in _enum_splits(needed - take, rest):
                    results.append([(lid, take)] + sub)
        return results

    def try_allocate(demand, end_time, lot_remaining):
        components = sorted(demand.keys())
        # For each component, gather ALL eligible lots across all substitute materials
        comp_eligible = {}
        for comp in components:
            subs = get_substitutes(comp)
            eligible = []
            seen_lots = set()
            for mat in subs:
                for lt in lots_by_material.get(mat, []):
                    if lt["expiry"] >= end_time and lt["id"] not in seen_lots:
                        avail_qty = lot_remaining.get(lt["id"], lt["qty"])
                        if avail_qty > 0:
                            eligible.append((lt["id"], avail_qty))
                            seen_lots.add(lt["id"])
            comp_eligible[comp] = eligible

        # Enumerate splits per component
        per_comp_splits = []
        for comp in components:
            splits = _enum_splits(demand[comp], comp_eligible[comp])
            if not splits:
                return None
            per_comp_splits.append(splits)

        best_canon = None
        best_alloc = None
        best_remaining = None
        for split_combo in itertools.product(*per_comp_splits):
            lot_usage = {}
            alloc = {}
            feasible = True
            for ci, comp in enumerate(components):
                split = split_combo[ci]
                if split:
                    alloc[comp] = split
                for lid, qty in split:
                    lot_usage[lid] = lot_usage.get(lid, 0) + qty
            for lid, used in lot_usage.items():
                if used > lot_remaining.get(lid, 0):
                    feasible = False
                    break
            if not feasible:
                continue
            temp_remaining = dict(lot_remaining)
            for lid, used in lot_usage.items():
                temp_remaining[lid] = temp_remaining[lid] - used
            canon = _canon_alloc(alloc)
            if best_canon is None or canon < best_canon:
                best_canon = canon
                best_alloc = alloc
                best_remaining = dict(temp_remaining)
        if best_alloc is not None:
            return best_alloc, best_remaining
        return None

    order_ids = sorted(orders.keys())
    line_wip_end = {}
    for w in wip_list:
        ln = w["line"]
        end = w["end"]
        if ln not in line_wip_end or end > line_wip_end[ln]:
            line_wip_end[ln] = end

    order_slots = {}
    for oid in order_ids:
        order_slots[oid] = right.get(oid, [])

    best_result = None

    def score_solution(selected_set, assignments):
        pri_totals = [0, 0, 0]
        for oid in selected_set:
            o = orders[oid]
            pri_totals[o["priority"] - 1] += o["qty"]
        completion_order = sorted(order_ids, key=lambda x: (orders[x]["priority"], orders[x]["due"], x))
        completion_vec = tuple(1 if oid in selected_set else 0 for oid in completion_order)
        sched_entries = []
        for oid in sorted(selected_set):
            a = assignments[oid]
            alloc_canon = _canon_alloc(a["alloc"])
            sched_entries.append((oid, a["line"], a["start"], a["end"], alloc_canon))
        return (tuple(pri_totals), completion_vec, tuple(sched_entries))

    def is_better(new_score, old_score):
        if old_score is None:
            return True
        if new_score[0] != old_score[0]:
            return new_score[0] > old_score[0]
        if new_score[1] != old_score[1]:
            return new_score[1] > old_score[1]
        return new_score[2] < old_score[2]

    def check_line_conflict(line_id, start, end, assignments):
        for assigned_oid, asgn in assignments.items():
            if asgn["line"] == line_id:
                if start < asgn["end"] and end > asgn["start"]:
                    return True
                if not (end + changeover <= asgn["start"] or asgn["end"] + changeover <= start):
                    return True
        if line_id in line_wip_end:
            wip_end = line_wip_end[line_id]
            if start < wip_end + changeover:
                return True
            if start < wip_end:
                return True
        return False

    def search(idx, selected, assignments, lot_remaining, current_score):
        nonlocal best_result
        if idx == len(order_ids):
            if selected:
                sc = score_solution(selected, assignments)
                if is_better(sc, current_score):
                    current_score = sc
                    best_result = (set(selected), dict(assignments), dict(lot_remaining))
            return current_score
        oid = order_ids[idx]
        current_score = search(idx + 1, selected, assignments, lot_remaining, current_score)
        slots = order_slots.get(oid, [])
        demand = left.get(oid, {})
        if not demand:
            return current_score
        for slot in slots:
            line_id, start, end = slot
            if check_line_conflict(line_id, start, end, assignments):
                continue
            result = try_allocate(demand, end, lot_remaining)
            if result is None:
                continue
            alloc, new_remaining = result
            new_selected = selected + [oid]
            new_assignments = dict(assignments)
            new_assignments[oid] = {"line": line_id, "start": start, "end": end, "alloc": alloc}
            current_score = search(idx + 1, new_selected, new_assignments, new_remaining, current_score)
        return current_score

    init_remaining = {lt["id"]: lt["qty"] for lt in valid_lots}
    search(0, [], {}, init_remaining, None)

    if best_result is None:
        selected_ids = []
        assignments = {}
    else:
        selected_ids = sorted(best_result[0])
        assignments = best_result[1]

    # ERP view
    erp_orders = []
    for oid in selected_ids:
        o = orders[oid]
        a = assignments[oid]
        erp_orders.append({
            "wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
            "due": o["due"], "start": a["start"], "end": a["end"],
            "line": a["line"], "status": "PLANNED", "parent": oid
        })
    for w in wip_list:
        erp_orders.append({
            "wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
            "due": w["due"], "start": w["start"], "end": w["end"],
            "line": w["line"], "status": "WIP_CONT", "parent": None
        })
    erp_orders.sort(key=lambda x: x["wo"])

    # MES view
    mes_items = []
    for oid in selected_ids:
        a = assignments[oid]
        mes_items.append({
            "run": run_id, "line": a["line"], "wo": oid,
            "qty": orders[oid]["qty"], "start": a["start"],
            "end": a["end"], "status": "PLANNED"
        })
    for w in wip_list:
        mes_items.append({
            "run": run_id, "line": w["line"], "wo": w["id"],
            "qty": w["qty"], "start": w["start"],
            "end": w["end"], "status": "WIP_CONT"
        })
    mes_items.sort(key=lambda x: (x["line"], x["start"], x["wo"]))
    line_seq = {}
    for item in mes_items:
        ln = item["line"]
        line_seq[ln] = line_seq.get(ln, 0) + 1
        item["seq"] = line_seq[ln]
    mes_output = []
    for item in mes_items:
        mes_output.append({
            "run": item["run"], "line": item["line"], "seq": item["seq"],
            "wo": item["wo"], "qty": item["qty"], "start": item["start"],
            "end": item["end"], "status": item["status"]
        })

    # WMS view
    wms_items = []
    for oid in selected_ids:
        a = assignments[oid]
        alloc = a["alloc"]
        for comp in sorted(alloc.keys()):
            for lid, qty in sorted(alloc[comp]):
                if qty > 0:
                    wms_items.append({
                        "run": run_id, "wo": oid, "component": comp,
                        "lot": lid, "qty": qty, "status": "RESERVED"
                    })
    wms_items.sort(key=lambda x: (x["wo"], x["component"], x["lot"], x["qty"]))
    wms_output = []
    for i, item in enumerate(wms_items):
        wms_output.append({
            "reservation": f"r{i+1:04d}", "run": item["run"],
            "wo": item["wo"], "component": item["component"],
            "lot": item["lot"], "qty": item["qty"], "status": item["status"]
        })

    return {
        "selected": selected_ids,
        "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": erp_orders},
        "mes": mes_output,
        "wms": wms_output
    }
