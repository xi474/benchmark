# Workflow 可观测性报告

- Trial：`C017__fUkAw4k__env`
- Task：`C017`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f1edd3ee223f47b99a0e8e21 -> tool:nanobot-harness-v3:call_b8a035bf536642ae941724aa -> tool:nanobot-harness-v3:call_a3ebc3f41c274a569d38d912 -> tool:nanobot-harness-v3:call_ebe5438efea74c3fa3af4bf3 -> tool:nanobot-harness-v3:call_590dcb39ce624396babbf8a7 -> tool:nanobot-harness-v3:call_0ea3db3352a946c199f9bb07 -> tool:nanobot-harness-v3:call_5ee3405cc9784b2c8107cdff -> tool:nanobot-harness-v3:call_403e3846211f48c4bae8d313 -> tool:nanobot-harness-v3:call_3733335601ed48298dacbc9c -> tool:nanobot-harness-v3:call_beb3237788944fcf882760a5 -> tool:nanobot-harness-v3:call_05be285696ce41b8b19408ae -> tool:nanobot-harness-v3:call_21ab30f1399b45cc84b11264 -> tool:nanobot-harness-v3:call_02d2a4cbe3084bcf9c5c680f -> tool:nanobot-harness-v3:call_188057c1424a4cd5a1ffbb89 -> tool:nanobot-harness-v3:call_b6203124dc684561a1fac1bc -> tool:nanobot-harness-v3:call_7dc88702cf3b4cee86878a92 -> tool:nanobot-harness-v3:call_ebf7d239ff60446f8c33c7d5 -> tool:nanobot-harness-v3:call_7b5a7283933f433f80be395c -> tool:nanobot-harness-v3:call_e78bc4cc864d430cb38af034 -> tool:nanobot-harness-v3:call_00109b9b17374fba8d04cc12 -> tool:nanobot-harness-v3:call_c3d3f965974041ea99ac29d0 -> tool:nanobot-harness-v3:call_fd325a4cc9aa4268bf1b6ffb -> tool:nanobot-harness-v3:call_35cd0ca05bfb41aea151e99e -> tool:nanobot-harness-v3:call_188c8c9c474c46dbb517976b -> tool:nanobot-harness-v3:call_62df7a4a22a24799aaa5fd0b -> tool:nanobot-harness-v3:call_28b640c660424acbac8d546c -> tool:nanobot-harness-v3:call_805977fd0ed249378adb2441 -> tool:nanobot-harness-v3:call_7f1440ae32f54f25a8921193 -> tool:nanobot-harness-v3:call_0913709582fd4a35af8c3d82 -> tool:nanobot-harness-v3:call_431316888d7d46ddab7247a3 -> tool:nanobot-harness-v3:call_ffef487f9e0f43469d6e8221 -> tool:nanobot-harness-v3:call_a3159b8f24654c6389125782 -> tool:nanobot-harness-v3:call_78d8fbf13484431c93c19648
- 关键路径耗时：0.212889
- Makespan：75.180942
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
