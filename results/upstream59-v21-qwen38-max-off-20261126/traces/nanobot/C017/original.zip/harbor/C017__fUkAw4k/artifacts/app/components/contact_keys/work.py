import re

def compute(payload):
    """保留批次和行序，为每条记录生成清理首尾空白并转小写的邮箱。"""
    result = []
    for batch in payload["batches"]:
        batch_keys = []
        for record in batch:
            email = record["email"].strip().lower()
            batch_keys.append(email)
        result.append(batch_keys)
    return result
