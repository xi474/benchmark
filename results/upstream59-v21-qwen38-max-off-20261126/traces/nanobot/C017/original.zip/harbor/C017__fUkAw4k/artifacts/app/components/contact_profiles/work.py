import re

def _collapse_ws(s):
    """Compress consecutive whitespace to a single space, strip leading/trailing."""
    return re.sub(r'\s+', ' ', s).strip()

def compute(payload):
    """保留批次和行序，返回 name,city,source,time 对象；姓名与城市的空白折叠为单个空格。"""
    result = []
    for batch in payload["batches"]:
        batch_profiles = []
        for record in batch:
            profile = {
                "name": _collapse_ws(record.get("name", "")),
                "city": _collapse_ws(record.get("city", "")),
                "source": record["source"],
                "time": record["time"],
            }
            batch_profiles.append(profile)
        result.append(batch_profiles)
    return result
