def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = contact_keys result:    list of batches, each a list of normalized emails
    right = contact_profiles result: list of batches, each a list of {name,city,source,time}
    """
    # --- ledger state ---
    # For each canonical email we track:
    #   complete: bool
    #   name, city: str (may be empty if incomplete)
    #   first_contact: int
    #   sources: set of source strings
    records = {}  # email -> dict

    batch_results = []

    for bi, batch in enumerate(payload["batches"]):
        keys = left[bi]       # normalized emails for this batch
        profiles = right[bi]  # profile dicts for this batch

        # --- Phase 1: validate entire batch against existing ledger ---
        # Build a snapshot of what this batch would produce, checking conflicts.
        # We also need to consider intra-batch updates to the same email.
        # A conflict occurs when a new non-empty name/city contradicts an
        # existing non-empty name/city (from ledger OR earlier in this batch).

        # Temporary view: start from current ledger state, apply batch items sequentially
        temp = {}  # email -> {name, city, first_contact, sources, was_complete, is_new}
        conflict = False

        for idx in range(len(keys)):
            email = keys[idx]
            prof = profiles[idx]
            new_name = prof["name"]
            new_city = prof["city"]
            new_source = prof["source"]
            new_time = prof["time"]

            if email in temp:
                # Same email appears earlier in this batch
                existing = temp[email]
            elif email in records:
                # Copy from ledger
                rec = records[email]
                existing = {
                    "name": rec["name"],
                    "city": rec["city"],
                    "first_contact": rec["first_contact"],
                    "sources": set(rec["sources"]),
                    "was_complete": rec["complete"],
                    "is_new": False,
                }
                temp[email] = existing
            else:
                # Brand new email
                existing = {
                    "name": "",
                    "city": "",
                    "first_contact": new_time,
                    "sources": set(),
                    "was_complete": False,
                    "is_new": True,
                }
                temp[email] = existing

            # Conflict check: non-empty new field vs non-empty existing field that differs
            if new_name and existing["name"] and new_name != existing["name"]:
                conflict = True
                break
            if new_city and existing["city"] and new_city != existing["city"]:
                conflict = True
                break

            # Merge: non-empty new fields fill in empty existing fields
            if new_name and not existing["name"]:
                existing["name"] = new_name
            if new_city and not existing["city"]:
                existing["city"] = new_city

            # Track earliest first_contact
            if new_time < existing["first_contact"]:
                existing["first_contact"] = new_time

            # Accumulate source
            existing["sources"].add(new_source)

        if conflict:
            batch_results.append({"status": "rejected", "items": []})
            continue

        # --- Phase 2: commit batch ---
        items = []
        for idx in range(len(keys)):
            email = keys[idx]
            prof = profiles[idx]
            entry = temp[email]

            was_in_ledger = not entry["is_new"]
            was_complete_before = entry["was_complete"] if was_in_ledger else False

            # Determine status for this item
            now_complete = bool(entry["name"] and entry["city"])

            if was_in_ledger and was_complete_before:
                # Already complete record: duplicate submission
                # Don't change name/city/first_contact, but merge sources
                items.append("duplicate")
            elif was_in_ledger and not was_complete_before and now_complete:
                # Was incomplete, now promoted to complete
                items.append("promoted")
            elif was_in_ledger and not was_complete_before and not now_complete:
                # Still incomplete, accepted (additional info merged)
                items.append("accepted")
            elif not was_in_ledger and now_complete:
                # New record, immediately complete
                items.append("accepted")
            else:
                # New record, incomplete
                items.append("incomplete")

        # Apply temp state to ledger
        for email, entry in temp.items():
            now_complete = bool(entry["name"] and entry["city"])
            if email in records:
                rec = records[email]
                # Only update name/city if they were empty before
                if entry["name"] and not rec["name"]:
                    rec["name"] = entry["name"]
                if entry["city"] and not rec["city"]:
                    rec["city"] = entry["city"]
                # Keep earliest first_contact
                if entry["first_contact"] < rec["first_contact"]:
                    rec["first_contact"] = entry["first_contact"]
                # Merge sources
                rec["sources"] = sorted(set(rec["sources"]) | entry["sources"])
                rec["complete"] = now_complete
            else:
                records[email] = {
                    "name": entry["name"],
                    "city": entry["city"],
                    "first_contact": entry["first_contact"],
                    "sources": sorted(entry["sources"]),
                    "complete": now_complete,
                }

        batch_results.append({"status": "committed", "items": items})

    # --- Build output ---
    accepted = []
    incomplete = []
    for email in sorted(records.keys()):
        rec = records[email]
        entry = {
            "email": email,
            "name": rec["name"],
            "city": rec["city"],
            "first_contact": rec["first_contact"],
            "sources": rec["sources"],
        }
        if rec["complete"]:
            accepted.append(entry)
        else:
            incomplete.append(entry)

    # Build sources view: source -> sorted list of emails that have valid records with that source
    sources_view = {}
    for email in sorted(records.keys()):
        for src in records[email]["sources"]:
            if src not in sources_view:
                sources_view[src] = []
            sources_view[src].append(email)
    # Sort each source's email list (already sorted since we iterate sorted emails)
    # Sort sources keys
    sources_view = {k: sources_view[k] for k in sorted(sources_view.keys())}

    return {
        "batches": batch_results,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_view,
    }
