# Workflow 可观测性报告

- Trial：`C031__SLSAhkh__env`
- Task：`C031`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_23ff49f8318947adad1671fb -> tool:nanobot-harness-v3:call_2e2a97b341b44f6891d831b2 -> tool:nanobot-harness-v3:call_51805106b46f40bca975495b -> tool:nanobot-harness-v3:call_56f96a475d91413ea85403f8 -> tool:nanobot-harness-v3:call_0516951bea384ca4a7613ebc -> tool:nanobot-harness-v3:call_cc8bbdbeeda94f9794c1c393 -> tool:nanobot-harness-v3:call_a71a874e3c9b4cd5bd7a6833 -> tool:nanobot-harness-v3:call_8233058408824411947fb45e -> tool:nanobot-harness-v3:call_7d96dd3b59094af0aa9ea86b -> tool:nanobot-harness-v3:call_460f67ffdace4700aa2e3cd2 -> tool:nanobot-harness-v3:call_6970c718a2e342a4a63a729e -> tool:nanobot-harness-v3:call_bd93b0ce316646a7ad20d9fb -> tool:nanobot-harness-v3:call_e6b817d434c4428a86219c14 -> tool:nanobot-harness-v3:call_254b881911d94b4193858ef7 -> tool:nanobot-harness-v3:call_2934eb471aa5480b9becfca4 -> tool:nanobot-harness-v3:call_6b0861e7d15e4f64873978ec -> tool:nanobot-harness-v3:call_0eccdd09305d43559c8b05f9 -> tool:nanobot-harness-v3:call_9109e824dd3042d48a5dde96 -> tool:nanobot-harness-v3:call_174385c1059543a3a75646bf -> tool:nanobot-harness-v3:call_9765b5b744b147568a8d4423 -> tool:nanobot-harness-v3:call_ece92174dd55497fa262dc6c -> tool:nanobot-harness-v3:call_6c54bb2a19024a25b8e76403 -> tool:nanobot-harness-v3:call_8ff05c48c81c4b07ad123de3 -> tool:nanobot-harness-v3:call_61ab3a5a0b70483386cbf5d7 -> tool:nanobot-harness-v3:call_ae2cb4fd6140496f847ef574 -> tool:nanobot-harness-v3:call_b7cbd1cc0b1745fa94916919 -> tool:nanobot-harness-v3:call_446548e3f6684f51ad12bc8a -> tool:nanobot-harness-v3:call_8f402a1b44fd4c23ae4fbb1b -> tool:nanobot-harness-v3:call_bd0f043d63354a7586ee10b5 -> tool:nanobot-harness-v3:call_b017263ca2af4cdc9f7bc6bc -> tool:nanobot-harness-v3:call_7892ef5071704eabbbf786c6 -> tool:nanobot-harness-v3:call_48e07043783a4cffa632acc2 -> tool:nanobot-harness-v3:call_a878960c38f84899800bb0c1
- 关键路径耗时：0.461196
- Makespan：79.75074
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
