import os
import pty
import signal
import select
import time


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = key_sequences result (list of hex strings)
    right = session_config result (dict with rc, timeout, markers)
    """
    import tempfile
    import shutil

    # Extract component results
    hex_keys = left          # list of hex-encoded byte strings per step
    cfg = right              # dict: rc, timeout, markers

    rc_content = cfg["rc"]
    timeout_sec = cfg.get("timeout", 4) or 4
    markers = cfg.get("markers", [])

    # Create a temporary working directory for this transform
    tmpdir = tempfile.mkdtemp(prefix="c031_")
    try:
        # Create .hushlogin to suppress login messages
        open(os.path.join(tmpdir, ".hushlogin"), "w").close()

        # Write rc file
        rc_path = os.path.join(tmpdir, ".bashrc_c031")
        with open(rc_path, "w") as f:
            f.write(rc_content)

        # Fork a PTY bash session
        master_fd, slave_fd = pty.openpty()

        pid = os.fork()
        if pid == 0:
            # Child process
            os.close(master_fd)
            os.setsid()

            # Make slave the controlling terminal
            import fcntl
            import termios
            fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)

            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            if slave_fd > 2:
                os.close(slave_fd)

            env = os.environ.copy()
            env["HOME"] = tmpdir
            env["TERM"] = "dumb"
            env["LC_ALL"] = "C"
            env["HISTFILE"] = "/dev/null"

            os.chdir(tmpdir)
            os.execvpe("/bin/bash", ["/bin/bash", "--noprofile", "--rcfile", rc_path, "-i"], env)

        # Parent process
        os.close(slave_fd)

        chunks = []
        closed = False

        def read_until(marker, timeout):
            """Read from PTY until marker is found or timeout/EOF."""
            buf = b""
            deadline = time.monotonic() + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                try:
                    rlist, _, _ = select.select([master_fd], [], [], min(remaining, 0.1))
                except (OSError, ValueError):
                    break
                if rlist:
                    try:
                        data = os.read(master_fd, 65536)
                    except OSError:
                        break
                    if not data:
                        return buf, True  # EOF
                    buf += data
                    if marker is not None and marker.encode("utf-8") in buf:
                        return buf, False
            return buf, False

        def normalize(text_bytes):
            """Normalize CRLF/CR to LF, remove isolated CR."""
            text = text_bytes.decode("utf-8", errors="replace")
            text = text.replace("\r\n", "\n")
            text = text.replace("\r", "")
            return text

        # Step 0: Read initial prompt
        initial_data, eof = read_until("PROMPT> ", timeout_sec)
        chunks.append(normalize(initial_data))
        if eof:
            closed = True

        # Process each step
        for i, hex_str in enumerate(hex_keys):
            if closed:
                break

            # Decode hex to bytes and write to PTY
            step_bytes = bytes.fromhex(hex_str)
            try:
                os.write(master_fd, step_bytes)
            except OSError:
                closed = True
                break

            # Read until marker
            marker = markers[i] if i < len(markers) else None
            step_data, eof = read_until(marker, timeout_sec)
            chunks.append(normalize(step_data))
            if eof:
                closed = True

        # Cleanup: kill process group
        try:
            os.killpg(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        try:
            os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            pass
        # Give it a moment then force kill
        time.sleep(0.05)
        try:
            os.killpg(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        try:
            os.waitpid(pid, 0)
        except ChildProcessError:
            pass

        try:
            os.close(master_fd)
        except OSError:
            pass

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    return {
        "chunks": chunks,
        "closed": closed,
    }
