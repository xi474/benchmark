# Workflow 可观测性报告

- Trial：`C033__g8bqxHU__env`
- Task：`C033`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_bc73906af82543f99ca3dbf8 -> tool:nanobot-harness-v3:call_aca62b199ebf4913b462e6e3 -> tool:nanobot-harness-v3:call_0412851cad93477180854474 -> tool:nanobot-harness-v3:call_e890dc27ad79463096862575 -> tool:nanobot-harness-v3:call_fdb9661a553d462dbcd67e64 -> tool:nanobot-harness-v3:call_6f54edd02bf347dfaeba252c -> tool:nanobot-harness-v3:call_51a709390a82405aaa18f478 -> tool:nanobot-harness-v3:call_477252c2dcb049e4a4628793 -> tool:nanobot-harness-v3:call_76b36cc05b9b442bbb19076d -> tool:nanobot-harness-v3:call_dd568ede79c6463f95f804bb -> tool:nanobot-harness-v3:call_04ff8758f627438eac79eeb0 -> tool:nanobot-harness-v3:call_f826c5419b334c409c06dea4 -> tool:nanobot-harness-v3:call_3042f883bf96492e83c77d82 -> tool:nanobot-harness-v3:call_212c4e17821344af96cd31f9 -> tool:nanobot-harness-v3:call_1b7af5ea82a94233a98296ac -> tool:nanobot-harness-v3:call_01736ec46cb64375a9973f6c -> tool:nanobot-harness-v3:call_a7345784f461405c99a2c03e -> tool:nanobot-harness-v3:call_241578dd27ad42e1bed5ad83 -> tool:nanobot-harness-v3:call_b7ca15f7d1fb4b9fa4d74d90 -> tool:nanobot-harness-v3:call_9c00b72185b744109aa969ec -> tool:nanobot-harness-v3:call_af143de15e594e23b03209c8 -> tool:nanobot-harness-v3:call_7c8febf3023f4573a72d8ae3 -> tool:nanobot-harness-v3:call_01179ca321064e8b9fce952b -> tool:nanobot-harness-v3:call_b5957588db054744936fee60 -> tool:nanobot-harness-v3:call_f9a36c4559ab49299e3ce790 -> tool:nanobot-harness-v3:call_e3a3437b55734084bad4b4a9 -> tool:nanobot-harness-v3:call_a82166748eea4c46b15f1265 -> tool:nanobot-harness-v3:call_e11ff2badc8a441ea2c957b8 -> tool:nanobot-harness-v3:call_ca61b9d91da64d6f88bec233 -> tool:nanobot-harness-v3:call_f5718b9f0bbd472983018ea6 -> tool:nanobot-harness-v3:call_a85adf00a0af47028673b754 -> tool:nanobot-harness-v3:call_87bc8a7516a8460c8e4edad3 -> tool:nanobot-harness-v3:call_c3aef62c73c64c4eab6aaf1b -> tool:nanobot-harness-v3:call_f3016fa4931843da9794ca69 -> tool:nanobot-harness-v3:call_42e92bb128994dee8891b15b -> tool:nanobot-harness-v3:call_a0ba55a82d214ec096c149be -> tool:nanobot-harness-v3:call_074849574c8d466dba74f43f -> tool:nanobot-harness-v3:call_eb27f18fe3cf4dc1973a65ec -> tool:nanobot-harness-v3:call_73a9d818fc684c2e8eb1177d -> tool:nanobot-harness-v3:call_e65db4f27fbf4155a0ab1dd1 -> tool:nanobot-harness-v3:call_bf41790f92f746a987e98fc9
- 关键路径耗时：0.71028
- Makespan：506.958688
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
