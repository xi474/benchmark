"""ELF segment loader: parse ELF32 LE and produce [entry, [[addr, byte], ...]]."""
import struct


def compute(payload):
    elf_hex = payload["elf_hex"]
    elf = bytes.fromhex(elf_hex)

    # ELF32 little-endian header
    e_entry = struct.unpack_from('<I', elf, 24)[0]
    e_phoff = struct.unpack_from('<I', elf, 28)[0]
    e_phentsize = struct.unpack_from('<H', elf, 42)[0]
    e_phnum = struct.unpack_from('<H', elf, 44)[0]

    # Collect all loaded bytes keyed by address
    mem = {}

    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        p_type = struct.unpack_from('<I', elf, off)[0]
        if p_type != 1:  # PT_LOAD
            continue
        p_offset = struct.unpack_from('<I', elf, off + 4)[0]
        p_vaddr = struct.unpack_from('<I', elf, off + 8)[0]
        p_filesz = struct.unpack_from('<I', elf, off + 16)[0]
        p_memsz = struct.unpack_from('<I', elf, off + 20)[0]

        # Copy file content
        for j in range(p_filesz):
            mem[p_vaddr + j] = elf[p_offset + j]
        # BSS zero-fill
        for j in range(p_filesz, p_memsz):
            mem[p_vaddr + j] = 0

    # Sort by address ascending
    segments = sorted(mem.items(), key=lambda x: x[0])
    return [e_entry, [list(pair) for pair in segments]]
