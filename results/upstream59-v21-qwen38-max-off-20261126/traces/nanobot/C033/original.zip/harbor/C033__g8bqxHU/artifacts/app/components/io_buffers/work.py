"""IO buffers: convert files map and stdin_hex to byte arrays."""


def compute(payload):
    files_in = payload.get("files", {})
    stdin_hex = payload.get("stdin_hex", "")

    # Convert each file's hex string to a list of byte values
    files_out = {}
    for name, hex_str in files_in.items():
        raw = bytes.fromhex(hex_str)
        files_out[name] = list(raw)

    # Convert stdin hex to byte list
    if stdin_hex:
        stdin_bytes = list(bytes.fromhex(stdin_hex))
    else:
        stdin_bytes = []

    return [files_out, stdin_bytes]
