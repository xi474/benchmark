"""MIPS32 little-endian interpreter combining ELF segments and IO buffers."""


def combine(payload, elf_result, io_result):
    entry_addr, mem_pairs = elf_result
    files_map, stdin_bytes = io_result
    mem = {}
    for addr, bv in mem_pairs:
        mem[addr] = bv
    regs = [0] * 32
    regs[29] = payload.get("stack_pointer", 0x7fff0000)
    hi = 0
    lo = 0
    max_steps = payload.get("max_steps", 20000)
    inspect_list = payload.get("inspect", [])
    fc = {}
    for nm, bl in files_map.items():
        fc[nm] = bytearray(bl)
    fdt = {0: {"data": bytearray(stdin_bytes), "offset": 0},
           1: {"data": bytearray(), "offset": 0},
           2: {"data": bytearray(), "offset": 0}}
    nfd = 3
    slog = []
    pc = entry_addr
    steps = 0
    ec = None

    def r8(a):
        return mem.get(a & 0xFFFFFFFF, 0)

    def w8(a, v):
        mem[a & 0xFFFFFFFF] = v & 0xFF

    def r16(a):
        a &= 0xFFFFFFFF
        return (r8(a) | (r8(a+1) << 8)) & 0xFFFF

    def r32(a):
        a &= 0xFFFFFFFF
        return (r8(a)|(r8(a+1)<<8)|(r8(a+2)<<16)|(r8(a+3)<<24)) & 0xFFFFFFFF

    def w16(a, v):
        a &= 0xFFFFFFFF
        w8(a, v & 0xFF); w8(a+1, (v>>8) & 0xFF)

    def w32(a, v):
        a &= 0xFFFFFFFF
        w8(a, v&0xFF); w8(a+1,(v>>8)&0xFF); w8(a+2,(v>>16)&0xFF); w8(a+3,(v>>24)&0xFF)

    def s16(v):
        v &= 0xFFFF
        return (v & 0x7FFF) - (v & 0x8000)

    def ts(v):
        return v if v < 0x80000000 else v - 0x100000000

    def do_sc():
        nonlocal ec, nfd
        sn = regs[2]; a0,a1,a2 = regs[4],regs[5],regs[6]
        slog.append({"number": sn, "args": [a0, a1, a2]})
        if sn == 4001:
            ec = a0 & 0xFF
        elif sn == 4003:
            if a0 in fdt:
                e=fdt[a0]; d=e["data"]; o=e["offset"]
                av=max(0,len(d)-o); n=min(a2,av)
                for i in range(n): w8(a1+i, d[o+i])
                e["offset"]+=n; regs[2]=n; regs[7]=0
            else: regs[2]=0xFFFFFFFF; regs[7]=1
        elif sn == 4004:
            if a0 in fdt:
                wd=bytearray()
                for i in range(a2): wd.append(r8(a1+i))
                fdt[a0]["data"].extend(wd); regs[2]=a2; regs[7]=0
            else: regs[2]=0xFFFFFFFF; regs[7]=1
        elif sn == 4005:
            fb=bytearray(); ad=a0
            while True:
                b=r8(ad)
                if b==0: break
                fb.append(b); ad+=1
            fn=fb.decode("utf-8"); fd=nfd; nfd+=1
            if a1==0:
                dt=bytearray(fc[fn]) if fn in fc else bytearray()
                fdt[fd]={"data":dt,"offset":0}
            elif a1==1:
                fc[fn]=bytearray(); fdt[fd]={"data":bytearray(),"offset":0}
            elif a1==9:
                if fn not in fc: fc[fn]=bytearray()
                fdt[fd]={"data":bytearray(fc[fn]),"offset":len(fc[fn])}
            regs[2]=fd; regs[7]=0
        elif sn == 4006:
            if a0 in fdt and a0>=3: del fdt[a0]; regs[2]=0; regs[7]=0
            else: regs[2]=0xFFFFFFFF; regs[7]=1
        regs[0]=0

    def ex(w, npc):
        """Execute one instruction word w at implied PC. Returns (delayed_pc or None)."""
        nonlocal hi, lo
        op=(w>>26)&0x3F; rs=(w>>21)&0x1F; rt=(w>>16)&0x1F
        rd=(w>>11)&0x1F; sh=(w>>6)&0x1F; fn=w&0x3F
        im=w&0xFFFF; t26=w&0x3FFFFFF
        dp=None
        if op==0:
            if fn==0: regs[rd]=(regs[rt]<<sh)&0xFFFFFFFF
            elif fn==2: regs[rd]=(regs[rt]>>sh)&0xFFFFFFFF
            elif fn==3:
                v=regs[rt]
                if v&0x80000000: v|=0xFFFFFFFF00000000
                regs[rd]=(v>>sh)&0xFFFFFFFF
            elif fn==8: dp=regs[rs]&0xFFFFFFFF
            elif fn==9: dp=regs[rs]&0xFFFFFFFF; regs[31]=(npc+4)&0xFFFFFFFF
            elif fn==12: do_sc()
            elif fn==16: regs[rd]=hi
            elif fn==17: hi=regs[rs]&0xFFFFFFFF
            elif fn==18: regs[rd]=lo
            elif fn==19: lo=regs[rs]&0xFFFFFFFF
            elif fn==24:
                sa=ts(regs[rs]); sb=ts(regs[rt]); p=sa*sb
                lo=p&0xFFFFFFFF; hi=(p>>32)&0xFFFFFFFF
            elif fn==25:
                p=regs[rs]*regs[rt]; lo=p&0xFFFFFFFF; hi=(p>>32)&0xFFFFFFFF
            elif fn==26:
                ss=ts(regs[rs]); st=ts(regs[rt])
                if st!=0:
                    q=int(ss/st) if (ss<0)==(st<0) else -(abs(ss)//abs(st))
                    r=ss-q*st; lo=q&0xFFFFFFFF; hi=r&0xFFFFFFFF
            elif fn==27:
                if regs[rt]!=0: lo=(regs[rs]//regs[rt])&0xFFFFFFFF; hi=(regs[rs]%regs[rt])&0xFFFFFFFF
            elif fn==32: regs[rd]=(regs[rs]+regs[rt])&0xFFFFFFFF
            elif fn==33: regs[rd]=(regs[rs]+regs[rt])&0xFFFFFFFF
            elif fn==34: regs[rd]=(regs[rs]-regs[rt])&0xFFFFFFFF
            elif fn==35: regs[rd]=(regs[rs]-regs[rt])&0xFFFFFFFF
            elif fn==36: regs[rd]=regs[rs]&regs[rt]
            elif fn==37: regs[rd]=regs[rs]|regs[rt]
            elif fn==38: regs[rd]=regs[rs]^regs[rt]
            elif fn==39: regs[rd]=~(regs[rs]|regs[rt])&0xFFFFFFFF
            elif fn==42: regs[rd]=1 if ts(regs[rs])<ts(regs[rt]) else 0
            elif fn==43: regs[rd]=1 if regs[rs]<regs[rt] else 0
        elif op==2: dp=((npc)&0xF0000000)|(t26<<2)
        elif op==3: dp=((npc)&0xF0000000)|(t26<<2); regs[31]=(npc+4)&0xFFFFFFFF
        elif op==4:
            if regs[rs]==regs[rt]: dp=(npc+(s16(im)<<2))&0xFFFFFFFF
        elif op==5:
            if regs[rs]!=regs[rt]: dp=(npc+(s16(im)<<2))&0xFFFFFFFF
        elif op==6:
            if ts(regs[rs])<=0: dp=(npc+(s16(im)<<2))&0xFFFFFFFF
        elif op==7:
            if ts(regs[rs])>0: dp=(npc+(s16(im)<<2))&0xFFFFFFFF
        elif op==8: regs[rt]=(regs[rs]+s16(im))&0xFFFFFFFF
        elif op==9: regs[rt]=(regs[rs]+s16(im))&0xFFFFFFFF
        elif op==10: regs[rt]=1 if ts(regs[rs])<s16(im) else 0
        elif op==11: regs[rt]=1 if regs[rs]<(s16(im)&0xFFFFFFFF) else 0
        elif op==12: regs[rt]=regs[rs]&im
        elif op==13: regs[rt]=regs[rs]|im
        elif op==14: regs[rt]=regs[rs]^im
        elif op==15: regs[rt]=(im<<16)&0xFFFFFFFF
        elif op==32:
            b=(regs[rs]+s16(im))&0xFFFFFFFF; v=r8(b)
            regs[rt]=(v|0xFFFFFF00) if v&0x80 else v
        elif op==33:
            b=(regs[rs]+s16(im))&0xFFFFFFFF; v=r16(b)
            regs[rt]=(v|0xFFFF0000) if v&0x8000 else v
        elif op==35: regs[rt]=r32((regs[rs]+s16(im))&0xFFFFFFFF)
        elif op==36: regs[rt]=r8((regs[rs]+s16(im))&0xFFFFFFFF)
        elif op==37: regs[rt]=r16((regs[rs]+s16(im))&0xFFFFFFFF)
        elif op==40: w8((regs[rs]+s16(im))&0xFFFFFFFF, regs[rt]&0xFF)
        elif op==41: w16((regs[rs]+s16(im))&0xFFFFFFFF, regs[rt]&0xFFFF)
        elif op==43: w32((regs[rs]+s16(im))&0xFFFFFFFF, regs[rt])
        regs[0]=0
        return dp

    while ec is None and steps < max_steps:
        w = r32(pc)
        steps += 1
        npc = (pc + 4) & 0xFFFFFFFF
        dp = ex(w, npc)
        if dp is not None:
            # Execute delay slot
            dw = r32(npc)
            steps += 1
            dp2 = ex(dw, (npc + 4) & 0xFFFFFFFF)
            if dp2 is not None:
                pc = dp2 & 0xFFFFFFFF
            else:
                pc = dp & 0xFFFFFFFF
        else:
            pc = npc
        regs[0] = 0

    of = {}
    for nm, ct in fc.items():
        of[nm] = ct.hex()
    io = []
    for it in inspect_list:
        a = it["address"]; l = it["length"]
        h = ""
        for i in range(l):
            h += format(r8(a + i), '02x')
        io.append({"address": a, "hex": h})
    return {
        "exit_code": ec if ec is not None else 0,
        "registers": list(regs),
        "hi": hi, "lo": lo, "steps": steps,
        "stdout_hex": fdt[1]["data"].hex(),
        "stderr_hex": fdt[2]["data"].hex(),
        "files": of, "inspect": io, "syscalls": slog,
    }
