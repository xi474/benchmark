# Workflow 可观测性报告

- Trial：`C039__MYBkaP3__env`
- Task：`C039`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_2ea4fc2cc79b4181af47cf61 -> tool:nanobot-harness-v3:call_020a8a9663a9488aa27c691e -> tool:nanobot-harness-v3:call_8b16263655634b4884f95ee1 -> tool:nanobot-harness-v3:call_8144f26f89914a2fa0431b14 -> tool:nanobot-harness-v3:call_004020e7dddd421cbb893a02 -> tool:nanobot-harness-v3:call_2e325b7c291848bf9d29a8d4 -> tool:nanobot-harness-v3:call_42ca1e4a207f410d9bf778bf -> tool:nanobot-harness-v3:call_a862008dd4b54b1aac51dc6c -> tool:nanobot-harness-v3:call_99769a8eb33d41afaa40c4e5 -> tool:nanobot-harness-v3:call_5a1ac9b9905b480285113d49 -> tool:nanobot-harness-v3:call_5dbbc77e1a8941e18892b1ba -> tool:nanobot-harness-v3:call_d60ae5fcc24f49cda46518eb -> tool:nanobot-harness-v3:call_8404420899044a129f7a3d87 -> tool:nanobot-harness-v3:call_7cc3dfff7c9c43aa8893acaa -> tool:nanobot-harness-v3:call_c0a5b4f00db14b63ab2397a0 -> tool:nanobot-harness-v3:call_2a585cdcb5d9487ca46a2876 -> tool:nanobot-harness-v3:call_60821b98b499477182db98a7 -> tool:nanobot-harness-v3:call_fcda677896f74edba1391f29 -> tool:nanobot-harness-v3:call_ad521292c6704fbe8391fb6a -> tool:nanobot-harness-v3:call_afcf29fc555f47c68330b47c -> tool:nanobot-harness-v3:call_ea9bbbc2c21a4c7d9c5f19f5 -> tool:nanobot-harness-v3:call_6e040688bcc5482d971d3491 -> tool:nanobot-harness-v3:call_7ec6579dc078447e812d529d -> tool:nanobot-harness-v3:call_87a4941744624886990e3990 -> tool:nanobot-harness-v3:call_2b2918cec52745a7b663fa90 -> tool:nanobot-harness-v3:call_f4ee2c22d6c04689933e2df3 -> tool:nanobot-harness-v3:call_b7262b5eddf44d20a8d4577c -> tool:nanobot-harness-v3:call_3017b89abb5f4fff8c0d14e7 -> tool:nanobot-harness-v3:call_d015f01a3664479794de9deb -> tool:nanobot-harness-v3:call_e419ed0a15c64721908678fb -> tool:nanobot-harness-v3:call_39ba4a6c18b64b43b3c01f55 -> tool:nanobot-harness-v3:call_401636a49b1a4bde9edf3d9a -> tool:nanobot-harness-v3:call_e1d55b05d14144daa604bb14 -> tool:nanobot-harness-v3:call_e9a6ce6ff90b45ecb30a4476 -> tool:nanobot-harness-v3:call_bb2963136e4341bfb2736d19
- 关键路径耗时：0.431014
- Makespan：172.525093
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
