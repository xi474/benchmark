def compute(payload):
    """排除指向根的边，按 allowed 顺序返回节点下标对。"""
    nodes = payload["nodes"]
    allowed = payload["allowed"]
    root = payload["root"]
    node_idx = {name: i for i, name in enumerate(nodes)}
    root_idx = node_idx[root]
    result = []
    for parent_name, child_name in allowed:
        ci = node_idx[child_name]
        if ci == root_idx:
            continue
        pi = node_idx[parent_name]
        result.append([pi, ci])
    return result
