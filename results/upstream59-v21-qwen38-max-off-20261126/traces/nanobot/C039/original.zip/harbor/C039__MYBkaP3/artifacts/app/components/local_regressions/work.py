def compute(payload):
    """为每个节点及其容许的父集合计算未舍入回归系数；返回每节点一张表，以逗号分隔的升序父下标为键，空集用空字符串。"""
    nodes = payload["nodes"]
    cov = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload["max_parents"]
    n = len(nodes)
    node_idx = {name: i for i, name in enumerate(nodes)}
    root_idx = node_idx[root]

    # Build set of allowed parents per child (excluding edges into root)
    allowed_parents = [[] for _ in range(n)]
    for p_name, c_name in allowed:
        ci = node_idx[c_name]
        if ci == root_idx:
            continue
        pi = node_idx[p_name]
        allowed_parents[ci].append(pi)

    def solve_regression(child_idx, parent_indices):
        """Return list of regression coefficients (unrounded) for child given parents."""
        if not parent_indices:
            return []
        k = len(parent_indices)
        # CPP: k x k covariance submatrix among parents
        # CPy: k-vector of covariances between parents and child
        CPP = [[cov[parent_indices[i]][parent_indices[j]] for j in range(k)] for i in range(k)]
        CPy = [cov[parent_indices[i]][child_idx] for i in range(k)]
        # Solve CPP @ beta = CPy using Gaussian elimination
        # Augmented matrix
        aug = [CPP[i][:] + [CPy[i]] for i in range(k)]
        for col in range(k):
            # Partial pivoting
            max_row = col
            for row in range(col + 1, k):
                if abs(aug[row][col]) > abs(aug[max_row][col]):
                    max_row = row
            aug[col], aug[max_row] = aug[max_row], aug[col]
            pivot = aug[col][col]
            for row in range(k):
                if row == col:
                    continue
                factor = aug[row][col] / pivot
                for j in range(col, k + 1):
                    aug[row][j] -= factor * aug[col][j]
        beta = [aug[i][k] / aug[i][i] for i in range(k)]
        return beta

    from itertools import combinations

    result = []
    for node_i in range(n):
        table = {}
        # Empty parent set always included
        table[""] = []
        if node_i == root_idx:
            # Root has no allowed parents (edges into root excluded)
            result.append(table)
            continue
        parents = sorted(allowed_parents[node_i])
        for size in range(1, min(max_parents, len(parents)) + 1):
            for combo in combinations(parents, size):
                key = ",".join(str(p) for p in combo)
                coeffs = solve_regression(node_i, list(combo))
                table[key] = coeffs
        result.append(table)
    return result
