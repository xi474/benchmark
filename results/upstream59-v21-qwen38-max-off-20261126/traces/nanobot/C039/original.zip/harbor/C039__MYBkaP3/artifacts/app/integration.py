import math
from itertools import combinations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    nodes = payload["nodes"]
    cov = payload["covariance"]
    mean = payload["mean"]
    sample_size = payload["sample_size"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload["intervention"]
    n = len(nodes)
    node_idx = {name: i for i, name in enumerate(nodes)}
    root_idx = node_idx[payload["root"]]
    interv_node_idx = node_idx[intervention["node"]]
    interv_value = intervention["value"]

    # left = admissible edges as [parent_idx, child_idx] pairs
    admissible = [tuple(e) for e in left]

    # right = list of dicts per node: key="comma-sep parent indices", value=[coefficients]
    # Build a lookup: (child_idx, frozenset_of_parent_indices) -> coefficients list
    reg_lookup = {}
    for child_i in range(n):
        table = right[child_i]
        for key, coeffs in table.items():
            if key == "":
                pset = frozenset()
            else:
                pset = frozenset(int(x) for x in key.split(","))
            reg_lookup[(child_i, pset)] = coeffs

    # Precompute residual variances for each (child, parent_set)
    def residual_variance(child_i, parent_list):
        if not parent_list:
            return cov[child_i][child_i]
        k = len(parent_list)
        CPP = [[cov[parent_list[i]][parent_list[j]] for j in range(k)] for i in range(k)]
        CPy = [cov[parent_list[i]][child_i] for i in range(k)]
        # Solve CPP @ beta = CPy, then res_var = Cyy - beta^T CPP beta = Cyy - CPy^T beta
        # Actually res_var = Cyy - CPy^T @ CPP^{-1} @ CPy = Cyy - CPy^T @ beta
        aug = [CPP[i][:] + [CPy[i]] for i in range(k)]
        for col in range(k):
            max_row = col
            for row in range(col + 1, k):
                if abs(aug[row][col]) > abs(aug[max_row][col]):
                    max_row = row
            aug[col], aug[max_row] = aug[max_row], aug[col]
            pivot = aug[col][col]
            for row in range(k):
                if row == col:
                    continue
                factor = aug[row][col] / pivot
                for j in range(col, k + 1):
                    aug[row][j] -= factor * aug[col][j]
        beta = [aug[i][k] / aug[i][i] for i in range(k)]
        cyy = cov[child_i][child_i]
        explained = sum(CPy[i] * beta[i] for i in range(k))
        return cyy - explained

    # Precompute residual variances for all valid (child, parent_subset) combos
    res_var_cache = {}
    for child_i in range(n):
        table = right[child_i]
        for key in table:
            if key == "":
                plist = []
            else:
                plist = [int(x) for x in key.split(",")]
            rv = residual_variance(child_i, plist)
            res_var_cache[(child_i, frozenset(plist))] = rv

    # Build allowed parents per child from admissible edges
    allowed_parents_per_child = [[] for _ in range(n)]
    for pi, ci in admissible:
        allowed_parents_per_child[ci].append(pi)
    for ci in range(n):
        allowed_parents_per_child[ci].sort()

    # Enumerate all valid DAGs with exactly edge_count edges
    # Each node chooses a parent subset from its allowed parents (respecting max_parents)
    # Root must have empty parent set
    # Total edges must equal edge_count
    # Graph must be acyclic

    # Generate candidate parent sets per node
    node_parent_options = []
    for i in range(n):
        if i == root_idx:
            node_parent_options.append([frozenset()])
            continue
        opts = [frozenset()]  # empty parent set
        ap = allowed_parents_per_child[i]
        for sz in range(1, min(max_parents, len(ap)) + 1):
            for combo in combinations(ap, sz):
                opts.append(frozenset(combo))
        node_parent_options.append(opts)

    best_score = None
    best_edges = None
    best_coeffs = None
    ln_n = math.log(sample_size)

    def compute_score(parent_sets):
        """Compute total score given a list of parent frozensets per node."""
        total = 0.0
        for i in range(n):
            ps = parent_sets[i]
            rv = res_var_cache.get((i, ps))
            if rv is None:
                return None
            total += sample_size * math.log(rv) + len(ps) * ln_n
        return total

    def has_cycle(parent_sets):
        """Check if the graph defined by parent_sets has a directed cycle."""
        # Build adjacency: child -> parents means edges parent->child
        # Check for cycle using DFS/topological sort
        # in_degree approach: Kahn's algorithm
        in_deg = [0] * n
        adj = [[] for _ in range(n)]  # adj[p] = list of children
        for i in range(n):
            for p in parent_sets[i]:
                adj[p].append(i)
                in_deg[i] += 1
        queue = [i for i in range(n) if in_deg[i] == 0]
        visited = 0
        while queue:
            node = queue.pop()
            visited += 1
            for child in adj[node]:
                in_deg[child] -= 1
                if in_deg[child] == 0:
                    queue.append(child)
        return visited != n

    def edges_from_parent_sets(parent_sets):
        edges = []
        for child_i in range(n):
            for p in sorted(parent_sets[child_i]):
                edges.append((p, child_i))
        edges.sort()
        return edges

    # Recursive enumeration with pruning
    def enumerate_dags(node_i, current_parents, edge_so_far):
        nonlocal best_score, best_edges, best_coeffs
        if node_i == n:
            if edge_so_far != edge_count:
                return
            ps_list = list(current_parents)
            if has_cycle(ps_list):
                return
            sc = compute_score(ps_list)
            if sc is None:
                return
            sc_rounded = round(sc, 9)
            elist = edges_from_parent_sets(ps_list)
            if best_score is None or sc_rounded < best_score or (sc_rounded == best_score and elist < best_edges):
                best_score = sc_rounded
                best_edges = elist
                # Store unrounded coefficients
                best_coeffs = []
                for ci in range(n):
                    ps = ps_list[ci]
                    if ps:
                        plist = sorted(ps)
                        coeffs = reg_lookup[(ci, ps)]
                        for pi_pos, pi in enumerate(plist):
                            best_coeffs.append((pi, ci, coeffs[pi_pos]))
                best_coeffs.sort()
            return

        remaining_nodes = n - node_i - 1
        for ps in node_parent_options[node_i]:
            new_edge_count = edge_so_far + len(ps)
            # Pruning: can we still reach edge_count?
            if new_edge_count > edge_count:
                continue
            # Max possible additional edges from remaining nodes
            max_additional = 0
            for future_i in range(node_i + 1, n):
                if future_i == root_idx:
                    continue
                max_additional += min(max_parents, len(allowed_parents_per_child[future_i]))
            if new_edge_count + max_additional < edge_count:
                continue
            enumerate_dags(node_i + 1, current_parents + [ps], new_edge_count)

    enumerate_dags(0, [], 0)

    if best_edges is None:
        return {"feasible": False}

    # Format output
    edges_out = [[nodes[p], nodes[c]] for p, c in best_edges]
    coeffs_out = [[nodes[p], nodes[c], round(slope, 6)] for p, c, slope in best_coeffs]

    # Intervention computation
    # Reconstruct parent_sets from best_edges
    best_parent_sets = [set() for _ in range(n)]
    for p, c in best_edges:
        best_parent_sets[c].add(p)

    # Get unrounded coefficients for each node
    node_coeffs = {}  # child_i -> {parent_i: slope}
    for p, c, slope in best_coeffs:
        if c not in node_coeffs:
            node_coeffs[c] = {}
        node_coeffs[c][p] = slope

    # Under intervention: set intervened node to interv_value, cut its incoming edges
    # For other nodes: E[Y] = intercept + sum(slope_p * E[X_p])
    # intercept = mean_Y - sum(slope_p * mean_X_p) (from observational data)
    # Under intervention, replace mean of intervened node with interv_value
    # and remove contributions from cut edges

    # Compute intercepts from observational means
    intercepts = [0.0] * n
    for i in range(n):
        if i in node_coeffs:
            s = mean[i]
            for p, slope in node_coeffs[i].items():
                s -= slope * mean[p]
            intercepts[i] = s
        else:
            intercepts[i] = mean[i]

    # Under intervention, compute expected means
    # Topological order of the post-intervention graph
    # Post-intervention: remove all edges into interv_node_idx
    post_parents = [set(ps) for ps in best_parent_sets]
    post_parents[interv_node_idx] = set()  # cut incoming edges

    # Topological sort
    in_deg = [0] * n
    adj = [[] for _ in range(n)]
    for i in range(n):
        for p in post_parents[i]:
            adj[p].append(i)
            in_deg[i] += 1
    topo_order = []
    queue = [i for i in range(n) if in_deg[i] == 0]
    temp_in = in_deg[:]
    while queue:
        node = queue.pop(0)
        topo_order.append(node)
        for child in adj[node]:
            temp_in[child] -= 1
            if temp_in[child] == 0:
                queue.append(child)

    exp_mean = [0.0] * n
    for i in topo_order:
        if i == interv_node_idx:
            exp_mean[i] = interv_value
        else:
            val = intercepts[i]
            if i in node_coeffs:
                for p, slope in node_coeffs[i].items():
                    if p in post_parents[i]:  # only use non-cut edges
                        val += slope * exp_mean[p]
            exp_mean[i] = val

    # Intervened edges: edges remaining after cutting incoming edges to intervened node
    intervened_edges = []
    for p, c in best_edges:
        if c != interv_node_idx:
            intervened_edges.append([nodes[p], nodes[c]])
    intervened_edges.sort()

    mean_out = [round(exp_mean[i], 6) for i in range(n)]

    return {
        "feasible": True,
        "edges": edges_out,
        "score": round(best_score, 6),
        "coefficients": coeffs_out,
        "intervened_edges": intervened_edges,
        "mean": mean_out,
    }
