# Workflow 可观测性报告

- Trial：`C049__8KpB9cU__env`
- Task：`C049`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（34 节点 / 33 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：34；执行边：33（observed=0，inferred=33）
- Execution Trace Graph：`observed`；temporal_next 边 33，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_276fe7506828499ba8f31b41 -> tool:nanobot-harness-v3:call_e1adf97d140b4148bbb3ecc8 -> tool:nanobot-harness-v3:call_605411e7b3604a6fa47c77a4 -> tool:nanobot-harness-v3:call_220159f9038b43c999083dc9 -> tool:nanobot-harness-v3:call_9ffe920481ff4b9990223187 -> tool:nanobot-harness-v3:call_f5f09d4f821f4631b0295feb -> tool:nanobot-harness-v3:call_386ad55085f04fc7a15c9b72 -> tool:nanobot-harness-v3:call_4f02b4ab2ef94e8f8d9aa05e -> tool:nanobot-harness-v3:call_9ae1def1627b438ab69fe0d0 -> tool:nanobot-harness-v3:call_d650b02aad8f478e906e7ae8 -> tool:nanobot-harness-v3:call_4fe49fb91efb45a08416706a -> tool:nanobot-harness-v3:call_7c83cfb06b034da5a32cdd86 -> tool:nanobot-harness-v3:call_a71a03e39f1540d7a6eea258 -> tool:nanobot-harness-v3:call_bcefb36ac4e94681a880c54e -> tool:nanobot-harness-v3:call_fc987c816f3f4d41b387fb32 -> tool:nanobot-harness-v3:call_892ffa263b014d829f6b1974 -> tool:nanobot-harness-v3:call_b0f289cee44045c4ac616b36 -> tool:nanobot-harness-v3:call_14d76c216a8044aebaecec90 -> tool:nanobot-harness-v3:call_14e095ba8f0940e5a646baba -> tool:nanobot-harness-v3:call_0804bc53ac4a4c8cb85f1327 -> tool:nanobot-harness-v3:call_3c115b1e92234e74b5b5b8ca -> tool:nanobot-harness-v3:call_8e388ce0a5834163b0a88778 -> tool:nanobot-harness-v3:call_d92912c491e640c796c2b2fe -> tool:nanobot-harness-v3:call_433aa177f684414ea52eaa85 -> tool:nanobot-harness-v3:call_928993185a9244dd9492de5f -> tool:nanobot-harness-v3:call_13e63ed1c0b746be91cabaf4 -> tool:nanobot-harness-v3:call_33d03db8920747c2b9433464 -> tool:nanobot-harness-v3:call_9984ace7481a4b27a8631161 -> tool:nanobot-harness-v3:call_b53ce99d38a94683b4741d03 -> tool:nanobot-harness-v3:call_47bdb101cc374aa08f03ee1a -> tool:nanobot-harness-v3:call_a11ae524e17c4fc8a316a172 -> tool:nanobot-harness-v3:call_68006011cc4d49549aefdf61 -> tool:nanobot-harness-v3:call_b223221ca8f7496cbfc2c779
- 关键路径耗时：1.40317
- Makespan：124.61004
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
