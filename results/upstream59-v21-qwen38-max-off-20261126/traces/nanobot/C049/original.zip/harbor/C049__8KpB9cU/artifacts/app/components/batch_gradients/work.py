import numpy as np
import math


def compute(payload):
    """Compute loss and gradients using manual backprop with AFAB pipeline schedule."""
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]

    L = len(layers)
    W = world_size

    # Build partitions: rank r owns layers [floor(L*r/W), floor(L*(r+1)/W))
    partitions = []
    for r in range(W):
        start = (L * r) // W
        stop = (L * (r + 1)) // W
        if stop > start:
            partitions.append({"stage": r, "start": start, "stop": stop})

    num_stages = len(partitions)

    # Convert weights/biases to numpy float64
    weights = [np.array(lay["weight"], dtype=np.float64) for lay in layers]
    biases = [np.array(lay["bias"], dtype=np.float64) for lay in layers]

    # Initialize gradient accumulators
    grad_w = [np.zeros_like(w) for w in weights]
    grad_b = [np.zeros_like(b) for b in biases]

    total_loss = 0.0
    M = len(microbatches)

    # Store activations per microbatch per layer for backprop
    # activations[m][l] = output of layer l for microbatch m (after activation)
    # pre_activations[m][l] = pre-activation (before tanh) of layer l for microbatch m
    all_activations = []  # list over microbatches
    all_pre_activations = []

    # === FORWARD PASS: all microbatches forward through all stages ===
    for m_idx in range(M):
        mb = microbatches[m_idx]
        inputs = np.array(mb["inputs"], dtype=np.float64)  # [batch, in_dim]
        targets = mb["targets"]
        B = inputs.shape[0]

        mb_activations = []  # per-layer outputs for this microbatch
        mb_pre_activations = []

        x = inputs
        for l_idx in range(L):
            z = x @ weights[l_idx].T + biases[l_idx]  # [B, out_dim]
            mb_pre_activations.append(z)
            if l_idx < L - 1:
                # tanh activation
                a = np.tanh(z)
            else:
                # last layer: logits (no activation)
                a = z
            mb_activations.append(a)
            x = a

        all_activations.append(mb_activations)
        all_pre_activations.append(mb_pre_activations)

        # Compute cross-entropy loss for this microbatch
        logits = mb_activations[-1]  # [B, C]
        # Softmax
        log_sum_exp = np.log(np.sum(np.exp(logits - np.max(logits, axis=1, keepdims=True)), axis=1, keepdims=True)) + np.max(logits, axis=1, keepdims=True)
        log_probs = logits - log_sum_exp  # [B, C]
        # Cross-entropy: -mean of log_probs[target]
        ce = 0.0
        for i in range(B):
            ce -= log_probs[i, targets[i]]
        ce /= B
        total_loss += ce

    total_loss /= M

    # === BACKWARD PASS: reverse microbatch order, reverse stage order ===
    for m_idx in reversed(range(M)):
        mb = microbatches[m_idx]
        targets = mb["targets"]
        B = len(targets)
        mb_activations = all_activations[m_idx]
        mb_pre_activations = all_pre_activations[m_idx]

        # Gradient of loss w.r.t. logits (last layer output)
        logits = mb_activations[-1]  # [B, C]
        # Softmax
        exp_logits = np.exp(logits - np.max(logits, axis=1, keepdims=True))
        softmax = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)  # [B, C]

        # d(CE)/d(logits) = (softmax - one_hot) / B, then / M for equal weighting
        d_logits = softmax.copy()
        for i in range(B):
            d_logits[i, targets[i]] -= 1.0
        d_logits /= B
        d_logits /= M

        # Backprop through layers in reverse
        delta = d_logits  # gradient w.r.t. output of last layer

        for l_idx in reversed(range(L)):
            # delta is gradient w.r.t. output of layer l_idx
            # For non-last layers, we need to multiply by tanh derivative
            if l_idx < L - 1:
                # tanh derivative: 1 - tanh^2
                tanh_out = mb_activations[l_idx]
                delta = delta * (1.0 - tanh_out ** 2)

            # Now delta is gradient w.r.t. pre-activation z of layer l_idx
            # z = x @ W.T + b, where x is input to this layer
            if l_idx == 0:
                inp = np.array(microbatches[m_idx]["inputs"], dtype=np.float64)
            else:
                inp = mb_activations[l_idx - 1]

            # Gradient for weight: delta.T @ inp => [out, in]
            gw = delta.T @ inp  # [out_dim, in_dim]
            gb = np.sum(delta, axis=0)  # [out_dim]

            grad_w[l_idx] += gw
            grad_b[l_idx] += gb

            # Propagate gradient to previous layer's output
            if l_idx > 0:
                delta = delta @ weights[l_idx]  # [B, in_dim]

    # Format output
    gradients = []
    for l_idx in range(L):
        gradients.append({
            "weight": grad_w[l_idx].tolist(),
            "bias": grad_b[l_idx].tolist()
        })

    return {
        "loss": float(total_loss),
        "gradients": gradients
    }
