def compute(payload):
    """Output partitions and AFAB events for the pipeline schedule."""
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]

    L = len(layers)
    W = world_size
    M = len(microbatches)

    # Build partitions: rank r owns layers [floor(L*r/W), floor(L*(r+1)/W))
    partitions = []
    for r in range(W):
        start = (L * r) // W
        stop = (L * (r + 1)) // W
        if stop > start:
            partitions.append({"stage": r, "start": start, "stop": stop})

    num_stages = len(partitions)

    # Build events following AFAB schedule:
    # Forward: for each microbatch in order, for each stage in order
    #   - forward event
    #   - if not last stage: send_activation(source, target)
    # Backward: for each microbatch in reverse order, for each stage in reverse order
    #   - backward event
    #   - if not first stage: send_gradient(source, target)

    events = []

    # Forward pass
    for m_idx in range(M):
        for s_idx in range(num_stages):
            events.append({
                "kind": "forward",
                "microbatch": m_idx,
                "stage": partitions[s_idx]["stage"]
            })
            if s_idx < num_stages - 1:
                events.append({
                    "kind": "send_activation",
                    "source": partitions[s_idx]["stage"],
                    "target": partitions[s_idx + 1]["stage"]
                })

    # Backward pass: reverse microbatch order, reverse stage order
    for m_idx in reversed(range(M)):
        for s_idx in reversed(range(num_stages)):
            events.append({
                "kind": "backward",
                "microbatch": m_idx,
                "stage": partitions[s_idx]["stage"]
            })
            if s_idx > 0:
                events.append({
                    "kind": "send_gradient",
                    "source": partitions[s_idx]["stage"],
                    "target": partitions[s_idx - 1]["stage"]
                })

    return {
        "partitions": partitions,
        "events": events
    }
