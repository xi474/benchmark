def combine(payload, left, right):
    """Combine batch_gradients (left) and pipeline_schedule (right) results."""
    # left = {loss, gradients} from batch_gradients
    # right = {partitions, events} from pipeline_schedule
    return {
        "loss": left["loss"],
        "gradients": left["gradients"],
        "partitions": right["partitions"],
        "events": right["events"]
    }
