# Workflow 可观测性报告

- Trial：`C055__MjCUfwh__env`
- Task：`C055`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（44 节点 / 43 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：44；执行边：43（observed=0，inferred=43）
- Execution Trace Graph：`observed`；temporal_next 边 43，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f44fd30982274619b5abf47e -> tool:nanobot-harness-v3:call_844c68f37b1e41ba8c6e5a52 -> tool:nanobot-harness-v3:call_8dc8afdc774a404694617ed8 -> tool:nanobot-harness-v3:call_caf8f2e8e34a491693479662 -> tool:nanobot-harness-v3:call_c0756bb9b906413498017ec7 -> tool:nanobot-harness-v3:call_cdc0c46ffd39440db2db514e -> tool:nanobot-harness-v3:call_f98c59284d734743bb2feebf -> tool:nanobot-harness-v3:call_34237acafb7a410ea2bce616 -> tool:nanobot-harness-v3:call_bb2f143b36b04d41b5271b60 -> tool:nanobot-harness-v3:call_0354772b438948008ad49278 -> tool:nanobot-harness-v3:call_c9340792fa8b415d91ad3402 -> tool:nanobot-harness-v3:call_8cbae60ab6c744cb8dcf18cb -> tool:nanobot-harness-v3:call_3b523e7ff2b843a2bc4a1d5b -> tool:nanobot-harness-v3:call_c55af68b072744e898c5670b -> tool:nanobot-harness-v3:call_5190f203f298421dbf4d730a -> tool:nanobot-harness-v3:call_65f48f19e3ac494e91529c42 -> tool:nanobot-harness-v3:call_668c417189764b23b07ad257 -> tool:nanobot-harness-v3:call_dd87f894df374a0bb3f0b87b -> tool:nanobot-harness-v3:call_3e4872d6324943068a0db6ed -> tool:nanobot-harness-v3:call_679f37181a6d4390bc981fb8 -> tool:nanobot-harness-v3:call_cdbe8b5f73ac461796896cea -> tool:nanobot-harness-v3:call_ebeca7f008e1446c83116a75 -> tool:nanobot-harness-v3:call_678707a13f994b4086f1af5b -> tool:nanobot-harness-v3:call_2e7c7c5743dd4c6887655b7b -> tool:nanobot-harness-v3:call_ddb0c05eb047446bb17865db -> tool:nanobot-harness-v3:call_12fbd59bc3184197b692d32d -> tool:nanobot-harness-v3:call_84621b5eb7554e799ef0107a -> tool:nanobot-harness-v3:call_612859c979c84a21b8f59ff2 -> tool:nanobot-harness-v3:call_d61c41bb7b6a45bcb9692831 -> tool:nanobot-harness-v3:call_81117dc9a1fc45c19b9d76be -> tool:nanobot-harness-v3:call_a613ea5b0e9c4a4f86c63e21 -> tool:nanobot-harness-v3:call_ab7eaf2b7f6544e8957ddcd1 -> tool:nanobot-harness-v3:call_707b27a08774428dad94d995 -> tool:nanobot-harness-v3:call_779b6cd879364e0a850df875 -> tool:nanobot-harness-v3:call_5eda46acdfec4609b81dec3d -> tool:nanobot-harness-v3:call_75c73c72666746dabc8ed060 -> tool:nanobot-harness-v3:call_8a647dfc26d84d22aee8662e -> tool:nanobot-harness-v3:call_63be88638c9c4875bdfa50d9 -> tool:nanobot-harness-v3:call_ae5ea6e14b9341c7b8fb261a -> tool:nanobot-harness-v3:call_ced3e16ca1214557aebd2ba5 -> tool:nanobot-harness-v3:call_bc07c64328d14b648521704c -> tool:nanobot-harness-v3:call_5fd83476ac5d4b42b9527736 -> tool:nanobot-harness-v3:call_c66b20fc6ac945329d0f452a
- 关键路径耗时：0.637996
- Makespan：152.558953
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
