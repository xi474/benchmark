def compute(payload):
    """Parse trusted sources for key overrides and intra-document anchors.
    
    For each valid key defined in trusted sources, output:
    [original_source_index, declaration_position, [value_position, text, is_vault, source_trusted]]
    where positions are [source_name, line, column] (1-based).
    
    Only processes sources where trusted=true. Later trusted definitions override earlier ones.
    Anchors (&name) and aliases (*name) are resolved within the same document.
    """
    sources = payload["sources"]
    result = {}
    
    for src_idx, source in enumerate(sources):
        if not source["trusted"]:
            continue
        
        name = source["name"]
        yaml_text = source["yaml"]
        lines = yaml_text.split("\n")
        
        # Parse anchors within this document
        anchors = {}  # anchor_name -> (value_position, text, is_vault)
        
        for line_idx, line in enumerate(lines):
            line_num = line_idx + 1
            
            # Skip empty lines and document separators
            stripped = line.strip()
            if not stripped or stripped == "---":
                continue
            
            # Parse "key: value" format (exactly one space after colon)
            colon_pos = line.find(": ")
            if colon_pos == -1:
                # Check for "key:" at end of line (no value) - shouldn't happen per spec
                continue
            
            key = line[:colon_pos]
            # Validate key is lowercase letters only
            if not key.isalpha() or not key.islower():
                continue
            
            value_part = line[colon_pos + 2:]  # after ": "
            value_col = colon_pos + 2 + 1  # 1-based column of first char of value
            
            # Check for anchor definition: &name value
            anchor_name = None
            actual_value = value_part
            actual_value_col = value_col
            
            if value_part.startswith("&"):
                # &name followed by a space then the actual value
                space_pos = value_part.find(" ", 1)
                if space_pos != -1:
                    anchor_name = value_part[1:space_pos]
                    actual_value = value_part[space_pos + 1:]
                    actual_value_col = value_col  # position starts at &
            
            # Check for alias reference: *name
            is_alias = False
            alias_target = None
            if actual_value.startswith("*"):
                is_alias = True
                alias_target = actual_value[1:]
            
            # Check for vault: !vault id
            is_vault = False
            text = actual_value
            if actual_value.startswith("!vault "):
                is_vault = True
                text = actual_value[7:]  # the vault ID
            
            if is_alias and alias_target in anchors:
                # Alias resolves to the anchor's original position and value
                ref_pos, ref_text, ref_is_vault = anchors[alias_target]
                entry = [src_idx, [name, line_num, 1], [ref_pos, ref_text, ref_is_vault, True]]
            else:
                entry = [src_idx, [name, line_num, 1], [[name, line_num, actual_value_col], text, is_vault, True]]
            
            # Register anchor if defined
            if anchor_name is not None:
                if is_alias and alias_target in anchors:
                    ref_pos, ref_text, ref_is_vault = anchors[alias_target]
                    anchors[anchor_name] = (ref_pos, ref_text, ref_is_vault)
                else:
                    anchors[anchor_name] = ([name, line_num, actual_value_col], text, is_vault)
            
            # Override in result (later definitions win)
            result[key] = entry
    
    return result
