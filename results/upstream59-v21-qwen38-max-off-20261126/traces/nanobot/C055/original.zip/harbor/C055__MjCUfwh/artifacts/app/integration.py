import json
import re


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tags = payload.get("tags", True)
    keys = payload.get("keys", {})

    # Merge left (trusted) and right (external/untrusted) bindings.
    # Each is a dict: key -> [src_idx, decl_pos, [val_pos, text, is_vault, trusted]]
    # Later source index wins for override ordering.
    all_bindings = {}
    for key, val in left.items():
        all_bindings[key] = val
    for key, val in right.items():
        src_idx = val[0]
        if key not in all_bindings or src_idx >= all_bindings[key][0]:
            all_bindings[key] = val

    # Check vault key availability when tags=false
    if not tags:
        for key, binding in all_bindings.items():
            val_info = binding[2]
            is_vault = val_info[2]
            if is_vault and key not in keys:
                return {"status": "sealed"}

    # Build final entries and compute renders
    # First pass: collect raw info for each key
    key_data = {}
    for key, binding in all_bindings.items():
        src_idx, decl_pos, val_info = binding
        val_pos, text, is_vault, trusted = val_info
        key_data[key] = {
            "decl_pos": decl_pos,
            "val_pos": val_pos,
            "text": text,
            "is_vault": is_vault,
            "trusted": trusted,
        }

    # Compute render for each key
    renders = {}
    _render_cache = {}

    def compute_render(k):
        if k in _render_cache:
            return _render_cache[k]
        info = key_data[k]
        is_vault = info["is_vault"]
        trusted = info["trusted"]
        text = info["text"]

        if is_vault:
            if tags:
                r = "[sealed]"
            else:
                r = keys[k]
            _render_cache[k] = r
            return r

        if not trusted:
            _render_cache[k] = text
            return text

        # Trusted plain value: expand ${key} references
        # Use iterative approach to avoid infinite recursion (spec guarantees no cycles)
        # Mark as being computed to detect issues
        _render_cache[k] = None  # sentinel
        def expand(s):
            result = []
            i = 0
            while i < len(s):
                if s[i:i+2] == "${":
                    end = s.find("}", i+2)
                    if end != -1:
                        ref_key = s[i+2:end]
                        if ref_key in key_data:
                            ref_render = compute_render(ref_key)
                            if ref_render is None:
                                # Should not happen (no cycles guaranteed)
                                result.append(s[i:end+1])
                            else:
                                result.append(ref_render)
                        else:
                            result.append(s[i:end+1])
                        i = end + 1
                    else:
                        result.append(s[i])
                        i += 1
                else:
                    result.append(s[i])
                    i += 1
            return "".join(result)

        r = expand(text)
        _render_cache[k] = r
        return r

    for key in key_data:
        compute_render(key)

    # Determine effective trusted for each key
    def effective_trusted(k):
        info = key_data[k]
        if info["is_vault"]:
            if tags:
                return False
            else:
                return True  # decrypted vault is trusted
        return info["trusted"]

    # Build entries sorted by key
    sorted_keys = sorted(key_data.keys())
    entries = []
    for k in sorted_keys:
        info = key_data[k]
        t = effective_trusted(k)
        r = renders.get(k, _render_cache.get(k, ""))
        entries.append([k, info["decl_pos"], info["val_pos"], t, r])

    # Build dump string
    dump_lines = []
    for k in sorted_keys:
        info = key_data[k]
        text = info["text"]
        is_vault = info["is_vault"]

        if is_vault and tags:
            # vault preserved: key: !vault "id"
            line = k + ": " + "!vault " + json.dumps(text, ensure_ascii=False)
        else:
            # Plain text or decrypted vault: key: "text"
            line = k + ": " + json.dumps(text, ensure_ascii=False)
        dump_lines.append(line)

    dump = "\n".join(dump_lines) + "\n" if dump_lines else ""

    return {
        "status": "ok",
        "entries": entries,
        "dump": dump,
    }
