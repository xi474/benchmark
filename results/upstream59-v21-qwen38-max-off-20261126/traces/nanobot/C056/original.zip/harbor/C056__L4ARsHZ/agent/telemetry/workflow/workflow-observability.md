# Workflow 可观测性报告

- Trial：`C056__L4ARsHZ__env`
- Task：`C056`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_5379baaf15f0404b85b3cc32 -> tool:nanobot-harness-v3:call_f8d4366591a1453f8ad3d752 -> tool:nanobot-harness-v3:call_1da81682109d4c209352ab59 -> tool:nanobot-harness-v3:call_7675d2bf514f46e4b9c49f73 -> tool:nanobot-harness-v3:call_819aa75cd7864e07820011d7 -> tool:nanobot-harness-v3:call_eed6ce8e9f904cdb8d4a1f6e -> tool:nanobot-harness-v3:call_b42fca4544704a47a360df37 -> tool:nanobot-harness-v3:call_fe6f7282d66449df9d2b309e -> tool:nanobot-harness-v3:call_6eec02e7b15e442eab5e63c6 -> tool:nanobot-harness-v3:call_ec7b45302acd4191be1b1403 -> tool:nanobot-harness-v3:call_bf64de76ca9a4e07bae02cff -> tool:nanobot-harness-v3:call_fef611b2da764aebb13b5505 -> tool:nanobot-harness-v3:call_ab8721dac3b84e86b60306c7 -> tool:nanobot-harness-v3:call_b88d9996820e474d93cf0b70 -> tool:nanobot-harness-v3:call_80479cd4c0e448d4a7bd7934 -> tool:nanobot-harness-v3:call_a463e87a63d5401984133db2 -> tool:nanobot-harness-v3:call_6d6b22d8b81b49a3835a219a -> tool:nanobot-harness-v3:call_0635c5cb5e98484cbf78d53f -> tool:nanobot-harness-v3:call_0ceb4e672823465a978e0605 -> tool:nanobot-harness-v3:call_012fccd79ef24026a6c55c03 -> tool:nanobot-harness-v3:call_fa3138a517454befa7a844dd -> tool:nanobot-harness-v3:call_fd3c10814b204a7681bc8e84 -> tool:nanobot-harness-v3:call_3d055e256476431998376035 -> tool:nanobot-harness-v3:call_fc9d2142bea9453897602ffd -> tool:nanobot-harness-v3:call_f93f23481eb342da8468946a -> tool:nanobot-harness-v3:call_77f0db9a468f462694f317b6 -> tool:nanobot-harness-v3:call_164aa26ab74d48148710a9ff -> tool:nanobot-harness-v3:call_58e3db045278424584f86c13 -> tool:nanobot-harness-v3:call_1b32f341f4524d219db5c579 -> tool:nanobot-harness-v3:call_8217406c2ebd4323bbc8f9c8 -> tool:nanobot-harness-v3:call_14f2a9f94afb47b3b62fa9ed -> tool:nanobot-harness-v3:call_12ee26bc808a480895c2de56 -> tool:nanobot-harness-v3:call_9452f88b9ba44ced9f22e5ea -> tool:nanobot-harness-v3:call_26d4f3310b964f5594180e76 -> tool:nanobot-harness-v3:call_d5fa20793a4e4ba199416a4e -> tool:nanobot-harness-v3:call_efcbd42813034a0da5a472ca -> tool:nanobot-harness-v3:call_5ebed861d09a43f2995e219e -> tool:nanobot-harness-v3:call_7f57fa21eb804bc8ae6ecb6f -> tool:nanobot-harness-v3:call_a62b7e464459445eaa9f4ad4 -> tool:nanobot-harness-v3:call_e55a187c540c4a718468998c -> tool:nanobot-harness-v3:call_9ed16f60c489481884babae4
- 关键路径耗时：0.531404
- Makespan：151.23918
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
