def compute(payload):
    """返回各依赖批次，每批含按 ID 升序排列的任务 ID。同批共享同一事实快照。"""
    tasks = payload["tasks"]
    task_map = {t["id"]: t for t in tasks}
    # Build dependency graph
    remaining = set(task_map.keys())
    done = set()
    waves = []
    while remaining:
        wave = sorted([tid for tid in remaining
                       if all(dep in done for dep in task_map[tid]["needs"])])
        if not wave:
            break  # shouldn't happen for DAG
        waves.append(wave)
        for tid in wave:
            done.add(tid)
            remaining.discard(tid)
    return waves
