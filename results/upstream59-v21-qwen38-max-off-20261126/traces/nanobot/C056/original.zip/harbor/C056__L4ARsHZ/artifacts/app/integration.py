def combine(payload, waves, feed_stats):
    """Combine the two component JSON values under the business contract in TASK.md.

    waves: list of lists of task IDs (dependency batches, each sorted by ID)
    feed_stats: {host: {stream: [[items, count, sum], ...]}}
    """
    tasks_list = payload["tasks"]
    task_map = {t["id"]: t for t in tasks_list}
    pools = payload["pools"]
    feeds = payload["feeds"]
    initial = dict(payload["initial"])

    # State
    facts = dict(initial)
    pool_counters = {pname: 0 for pname in pools}
    feed_counters = {}  # (host, stream) -> counter
    for host in feeds:
        for stream in feeds[host]:
            feed_counters[(host, stream)] = 0

    pool_reads = {pname: 0 for pname in pools}
    feed_reads = {}
    for host in feeds:
        feed_reads[host] = {}
        for stream in feeds[host]:
            feed_reads[host][stream] = 0

    task_results = {}
    committed_deltas = {}  # task_id -> delta

    for wave in waves:
        # All tasks in this wave see the same fact snapshot (wave start)
        wave_base_snapshot = dict(facts)
        wave_deltas = {}  # host -> total delta from this wave

        # Process tasks in ID order (already sorted in wave)
        for tid in wave:
            task = task_map[tid]
            pool_name = task["pool"]
            stream = task["stream"]
            attempts_needed = task["attempts"]

            # Pool round-robin: pick host
            pool_hosts = pools[pool_name]
            idx = pool_counters[pool_name] % len(pool_hosts)
            host = pool_hosts[idx]
            pool_counters[pool_name] += 1
            pool_reads[pool_name] += 1

            # Feed round-robin: pick batch
            feed_batches = feeds[host][stream]
            fidx = feed_counters[(host, stream)] % len(feed_batches)
            items = list(feed_batches[fidx])
            feed_counters[(host, stream)] += 1
            feed_reads[host][stream] += 1

            # base = fact value of host at wave start
            base = wave_base_snapshot[host]

            # parent = sum of committed deltas of direct parents
            parent = sum(committed_deltas.get(dep, 0) for dep in task["needs"])

            # Compute delta: sum of (base + item) * (1 + parent) for each item
            delta = sum((base + item) * (1 + parent) for item in items)

            # Record result
            task_results[tid] = {
                "host": host,
                "items": items,
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": attempts_needed
            }
            committed_deltas[tid] = delta

            # Accumulate delta for host update at end of wave
            wave_deltas[host] = wave_deltas.get(host, 0) + delta

        # End of wave: update facts
        for host, d in wave_deltas.items():
            facts[host] = facts[host] + d

    return {
        "tasks": task_results,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads
    }
