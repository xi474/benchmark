# Workflow 可观测性报告

- Trial：`C058__iP3fj4s__env`
- Task：`C058`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（78 节点 / 77 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：78；执行边：77（observed=0，inferred=77）
- Execution Trace Graph：`observed`；temporal_next 边 77，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_33e5dbf284cb43bf81feeac8 -> tool:nanobot-harness-v3:call_6f05207a6c9c4bbe8e64e1dd -> tool:nanobot-harness-v3:call_5b7d5f82bf35441989aae29b -> tool:nanobot-harness-v3:call_2fc1494f5dd541eab4d769dd -> tool:nanobot-harness-v3:call_b9b510be17f2491eaab9a0c4 -> tool:nanobot-harness-v3:call_4d4a7cb5fdee458cba667bf4 -> tool:nanobot-harness-v3:call_3298ce3ebba44bf997f7e482 -> tool:nanobot-harness-v3:call_08a711e614844e76956a215a -> tool:nanobot-harness-v3:call_5ff4f728ba9d4cb8b2dad6e0 -> tool:nanobot-harness-v3:call_351cfdfc55614ec19bbf7131 -> tool:nanobot-harness-v3:call_b7ad3ec6fc094192b8ceee15 -> tool:nanobot-harness-v3:call_ffc3fcc35fd54b8f837d59b9 -> tool:nanobot-harness-v3:call_d7539cf55c8b497984ad250e -> tool:nanobot-harness-v3:call_cf068c1499e84e35a7dfd4cf -> tool:nanobot-harness-v3:call_90d1de6239b54df0882cb3a7 -> tool:nanobot-harness-v3:call_2399759569c34ded953616f5 -> tool:nanobot-harness-v3:call_d82daafa1e664cd5ac322021 -> tool:nanobot-harness-v3:call_6b593854974540ea9fac57b3 -> tool:nanobot-harness-v3:call_b10a8fe27f0a4589af0b2a84 -> tool:nanobot-harness-v3:call_390504fcc62948a4b2aa5281 -> tool:nanobot-harness-v3:call_3caa8f56d7874ee89ec6a384 -> tool:nanobot-harness-v3:call_6e0e16ea7a2a4fbf8d8bad17 -> tool:nanobot-harness-v3:call_768701476489413f9c04e27d -> tool:nanobot-harness-v3:call_7f078bd0f141471981dd5530 -> tool:nanobot-harness-v3:call_c979b838afcf4fd58c6bc191 -> tool:nanobot-harness-v3:call_81f026143ee94ad185427a2d -> tool:nanobot-harness-v3:call_0775305cfa8543699dc50165 -> tool:nanobot-harness-v3:call_a5fc9543b83b4cceb8fb446d -> tool:nanobot-harness-v3:call_96cd15a9c3fd479f9384e793 -> tool:nanobot-harness-v3:call_4e747051b0864924bc0f748f -> tool:nanobot-harness-v3:call_84916773486b4c948dffed33 -> tool:nanobot-harness-v3:call_201f9f41977b4d7697b4f4e1 -> tool:nanobot-harness-v3:call_62d9b3a9ace74725b7454032 -> tool:nanobot-harness-v3:call_a55f6333905840b6a3050135 -> tool:nanobot-harness-v3:call_9f106641f03543768c32226b -> tool:nanobot-harness-v3:call_d880ddaf303944aa865037c2 -> tool:nanobot-harness-v3:call_f8d3a55c86de4604b5321cc4 -> tool:nanobot-harness-v3:call_9e4128d8d5af41c79ac17cb3 -> tool:nanobot-harness-v3:call_81d761fe59fc4403a39993b1 -> tool:nanobot-harness-v3:call_583a8922bbdd48cab2fd8bcb -> tool:nanobot-harness-v3:call_22c921ceee9c4c0681879653 -> tool:nanobot-harness-v3:call_582ed232a44841648977a55f -> tool:nanobot-harness-v3:call_94f2319cd3c1477e927d433a -> tool:nanobot-harness-v3:call_95654b60b86f4603bfb4443b -> tool:nanobot-harness-v3:call_9e115f979e7e43478e1e2aa2 -> tool:nanobot-harness-v3:call_608aec8f28104ee3a1c96eae -> tool:nanobot-harness-v3:call_450dbbef30ba467eba47ac9e -> tool:nanobot-harness-v3:call_495e861dac5c453499813a28 -> tool:nanobot-harness-v3:call_c909a732c24849b99f73b45d -> tool:nanobot-harness-v3:call_61c7851cbf674487b8708a5b -> tool:nanobot-harness-v3:call_f83a0f8fecff468cb3fb4d33 -> tool:nanobot-harness-v3:call_046be6671f3c42768a2c6a88 -> tool:nanobot-harness-v3:call_9dd9f7fc914a4d83a8401d6e -> tool:nanobot-harness-v3:call_d62bc01df0574e5986477d97 -> tool:nanobot-harness-v3:call_436e79c7af1d4267ab2ae864 -> tool:nanobot-harness-v3:call_90db6d5da8dc4a4f8da7bf8d -> tool:nanobot-harness-v3:call_32db617e553d42e88ada4f2e -> tool:nanobot-harness-v3:call_0f90adfc2fd44ac8b7486610 -> tool:nanobot-harness-v3:call_7a44bfbe422944a8916044ac -> tool:nanobot-harness-v3:call_776363e234b5473e9b2bf003 -> tool:nanobot-harness-v3:call_19a30bf66f484590b01cdd2a -> tool:nanobot-harness-v3:call_b42b1498cfa348ddafcdd287 -> tool:nanobot-harness-v3:call_ced668f71d4a47e1ba4b5b97 -> tool:nanobot-harness-v3:call_07390c2629ca4c12b25f1570 -> tool:nanobot-harness-v3:call_dbeabf09fa21468e935dc377 -> tool:nanobot-harness-v3:call_0058dcf7d99c4f14bd96220c -> tool:nanobot-harness-v3:call_f50e3196395e4335bf54130a -> tool:nanobot-harness-v3:call_a05e7d646bc54d11882269dc -> tool:nanobot-harness-v3:call_daec55ac5be44826ac86a2be -> tool:nanobot-harness-v3:call_162289f99a0e4027b0ed73f1 -> tool:nanobot-harness-v3:call_97af5c3d90044c05bbd4d21b -> tool:nanobot-harness-v3:call_2bd13e7a7ea142d7bce26608 -> tool:nanobot-harness-v3:call_061c1da3191e497582c4828d -> tool:nanobot-harness-v3:call_5c3f55337d11468baa524c40 -> tool:nanobot-harness-v3:call_0d6eceec7ab44393b917f46d -> tool:nanobot-harness-v3:call_07cb94e01e3940708236265e -> tool:nanobot-harness-v3:call_b27e8e3ba54044db9a4e940f
- 关键路径耗时：0.817636
- Makespan：618.927919
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
