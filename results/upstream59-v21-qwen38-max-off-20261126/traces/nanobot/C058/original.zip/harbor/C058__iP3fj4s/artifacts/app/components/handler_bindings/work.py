"""handler_bindings component: handler order map and leaf-node notify lists."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from tree_utils import iter_program_nodes, is_task_node, get_notify_list


def compute(payload):
    """Return [handler_order_map, leaf_notify_map].

    handler_order_map: {handler_name: declaration_index}
    leaf_notify_map: {position: [handler_name, ...]} for leaf (task) nodes only.
      Notify names are deduplicated and ordered by handler declaration order.
      Includes tasks in rescue and always branches.
    """
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    # Build handler declaration order map
    handler_order = {}
    for idx, h in enumerate(handlers):
        handler_order[h] = idx

    # Build leaf notify map
    leaf_notify = {}
    for pos, node, phase_name, branch in iter_program_nodes(program):
        if is_task_node(node):
            notify = get_notify_list(node)
            if notify:
                # Deduplicate preserving handler declaration order
                seen = set()
                ordered = []
                for name in notify:
                    if name not in seen and name in handler_order:
                        seen.add(name)
                        ordered.append(name)
                # Sort by handler declaration order
                ordered.sort(key=lambda n: handler_order[n])
                if ordered:
                    leaf_notify[pos] = ordered

    return [handler_order, leaf_notify]
