"""host_conditions component: per-host node executability and failure prediction."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from tree_utils import (
    iter_program_nodes, get_only_set, get_fail_hosts, is_task_node, PHASE_ORDER
)


def compute(payload):
    """Return {host: {position: [executable, will_fail]}} for every node.

    A node is executable only if it and all ancestor blocks pass the 'only' filter.
    """
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})

    # Build ancestor-only constraints: for each position, collect all ancestor block 'only' sets
    # We need to know which positions are inside which blocks
    ancestor_only = {}  # pos -> list of only-sets from ancestor blocks
    _collect_ancestor_only(program, ancestor_only)

    result = {}
    for host in hosts:
        host_table = {}
        for pos, node, phase_name, branch in iter_program_nodes(program):
            # Check own 'only'
            own_only = get_only_set(node)
            executable = (own_only is None) or (host in own_only)
            # Check ancestor blocks' 'only'
            if executable:
                for anc_only in ancestor_only.get(pos, []):
                    if host not in anc_only:
                        executable = False
                        break
            if is_task_node(node):
                will_fail = host in get_fail_hosts(node)
            else:
                will_fail = False
            host_table[pos] = [executable, will_fail]
        result[host] = host_table

    return result


def _collect_ancestor_only(program, ancestor_only):
    """For each node position, record the 'only' sets of all ancestor blocks."""
    for phase_idx, phase_name in enumerate(PHASE_ORDER):
        phase_items = program.get(phase_name, [])
        if not phase_items:
            continue
        for item_idx, item in enumerate(phase_items):
            pos = f"{phase_idx}/{item_idx}"
            if isinstance(item, dict) and "block" in item:
                block_only = get_only_set(item)
                ancestors = []
                if block_only is not None:
                    ancestors.append(block_only)
                _collect_block_ancestors(item["block"], pos, ancestors, ancestor_only)


def _collect_block_ancestors(block, parent_pos, ancestors, ancestor_only):
    """Recursively collect ancestor 'only' sets for nodes inside a block."""
    for branch, branch_name in enumerate(["tasks", "rescue", "always"]):
        branch_items = block.get(branch_name, [])
        for sub_idx, sub_item in enumerate(branch_items):
            sub_pos = f"{parent_pos}/{branch}/{sub_idx}"
            # Record current ancestors for this node
            if ancestors:
                ancestor_only[sub_pos] = list(ancestors)
            # If this is a nested block, add its 'only' and recurse
            if isinstance(sub_item, dict) and "block" in sub_item:
                new_ancestors = list(ancestors)
                nested_only = get_only_set(sub_item)
                if nested_only is not None:
                    new_ancestors.append(nested_only)
                _collect_block_ancestors(sub_item["block"], sub_pos, new_ancestors, ancestor_only)
