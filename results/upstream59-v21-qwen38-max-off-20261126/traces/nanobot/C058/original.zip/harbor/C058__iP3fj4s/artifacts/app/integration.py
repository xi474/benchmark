"""Integration: combine host_conditions and handler_bindings into final output."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from tree_utils import (
    iter_program_nodes, parse_position, position_sort_key,
    is_task_node, get_task_id, get_only_set, get_fail_hosts,
    get_notify_list, PHASE_ORDER
)


def combine(payload, left, right):
    """Combine component results into {batches, final}.

    left = host_conditions result: {host: {pos: [executable, will_fail]}}
    right = handler_bindings result: [handler_order_map, leaf_notify_map]
    """
    hosts = payload.get("hosts", [])
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})

    handler_order = right[0]  # {name: index}
    leaf_notify = right[1]    # {pos: [handler_names]}

    if not hosts:
        return {"batches": [], "final": {}}

    # For each host, simulate execution and collect events
    host_events = {}
    host_final = {}

    for hi, host in enumerate(hosts):
        host_cond = left.get(host, {})
        events, is_failed = _simulate_host(host, hi, host_cond, handler_order, leaf_notify, program)
        host_events[host] = events
        host_final[host] = "failed" if is_failed else "ok"

    # Collect all events and sort by batch_key then host_idx
    all_events = []
    for host in hosts:
        for ev in host_events[host]:
            all_events.append(ev)
    all_events.sort(key=lambda e: (e["_batch_key"], e["_host_idx"]))

    # Group into batches by identical batch_key
    batches = []
    i = 0
    while i < len(all_events):
        current_key = all_events[i]["_batch_key"]
        batch = []
        while i < len(all_events) and all_events[i]["_batch_key"] == current_key:
            ev = all_events[i]
            entry = {"host": ev["host"], "task": ev["task"],
                     "kind": ev["kind"], "status": ev["status"]}
            if "handlers" in ev:
                entry["handlers"] = ev["handlers"]
            batch.append(entry)
            i += 1
        if batch:
            batches.append(batch)

    return {"batches": batches, "final": host_final}


# Sort key design: tuple of ints for consistent comparison
# (phase_idx, pos_part_0, pos_part_1, ..., kind_order, host_idx)
# kind_order: 0=task, 1=flush, 2+=handler
# Flush/handler use a large sentinel for position parts to sort after all tasks in phase
# We normalize all keys to same-length tuples by padding with -1

_MAX_DEPTH = 12  # max tree depth we support
_SENTINEL = 999999  # sorts after any real position index


def _make_task_keys(pos_str, host_idx):
    """Return (batch_key, host_idx) for a task event."""
    parts = [int(x) for x in pos_str.split("/")]
    padded = parts + [-1] * (_MAX_DEPTH - len(parts))
    batch_key = tuple(padded) + (0,)
    return batch_key, host_idx


def _make_flush_keys(phase_idx, host_idx):
    """Return (batch_key, host_idx) for flush at end of phase."""
    padded = [phase_idx] + [_SENTINEL] * (_MAX_DEPTH - 1)
    batch_key = tuple(padded) + (1,)
    return batch_key, host_idx


def _make_handler_keys(phase_idx, handler_sub_idx, host_idx):
    """Return (batch_key, host_idx) for handler execution."""
    padded = [phase_idx] + [_SENTINEL] * (_MAX_DEPTH - 1)
    batch_key = tuple(padded) + (2 + handler_sub_idx,)
    return batch_key, host_idx


def _simulate_host(host, host_idx, host_cond, handler_order, leaf_notify, program):
    """Simulate execution for a single host. Returns (events, is_failed)."""
    events = []
    failed_out = False

    for phase_idx, phase_name in enumerate(PHASE_ORDER):
        phase_items = program.get(phase_name, [])
        if not phase_items:
            continue
        if failed_out:
            break

        phase_notifications = {}
        phase_failed = _execute_phase_items(
            host, host_idx, host_cond, handler_order, leaf_notify,
            phase_items, str(phase_idx), events, phase_notifications
        )

        # Flush notifications at end of phase (even if phase failed)
        if phase_notifications:
            sorted_handlers = sorted(phase_notifications.keys(),
                                     key=lambda h: handler_order.get(h, 999999))
            fk, fhi = _make_flush_keys(phase_idx, host_idx)
            events.append({
                "host": host, "task": "", "kind": "flush", "status": "ok",
                "handlers": sorted_handlers,
                "_batch_key": fk, "_host_idx": fhi,
            })
            for hidx, hname in enumerate(sorted_handlers):
                hk, hhi = _make_handler_keys(phase_idx, hidx, host_idx)
                events.append({
                    "host": host, "task": hname, "kind": "handler", "status": "ok",
                    "_batch_key": hk, "_host_idx": hhi,
                })

        if phase_failed:
            failed_out = True

    return events, failed_out


def _execute_phase_items(host, host_idx, host_cond, handler_order, leaf_notify,
                         items, prefix, events, phase_notifications):
    """Execute a list of items. Returns True if uncaptured failure."""
    for item_idx, item in enumerate(items):
        pos = f"{prefix}/{item_idx}"
        if isinstance(item, dict) and "block" in item:
            if _execute_block(host, host_idx, host_cond, handler_order, leaf_notify,
                              item, pos, events, phase_notifications):
                return True
        else:
            if _execute_task(host, host_idx, host_cond, handler_order, leaf_notify,
                             item, pos, events, phase_notifications):
                return True
    return False


def _execute_task(host, host_idx, host_cond, handler_order, leaf_notify,
                  task, pos, events, phase_notifications):
    """Execute a single task. Returns True if task failed (uncaptured)."""
    cond = host_cond.get(pos, [True, False])
    executable, will_fail = cond[0], cond[1]
    if not executable:
        return False
    task_id = get_task_id(task)
    status = "failed" if will_fail else "ok"
    bk, bhi = _make_task_keys(pos, host_idx)
    events.append({
        "host": host, "task": task_id, "kind": "task", "status": status,
        "_batch_key": bk, "_host_idx": bhi,
    })
    if not will_fail:
        notify = leaf_notify.get(pos, [])
        for hname in notify:
            if hname not in phase_notifications:
                phase_notifications[hname] = True
    return will_fail


def _execute_block(host, host_idx, host_cond, handler_order, leaf_notify,
                   block_node, pos, events, phase_notifications):
    """Execute a block. Returns True if failure propagates out."""
    block = block_node["block"]
    block_only = get_only_set(block_node)
    if block_only is not None and host not in block_only:
        return False
    normal_tasks = block.get("tasks", [])
    rescue_tasks = block.get("rescue", [])
    always_tasks = block.get("always", [])
    normal_failed = False
    for sub_idx, task in enumerate(normal_tasks):
        sub_pos = f"{pos}/0/{sub_idx}"
        if _execute_item(host, host_idx, host_cond, handler_order, leaf_notify,
                         task, sub_pos, events, phase_notifications):
            normal_failed = True
            break
    rescue_failed = False
    if normal_failed:
        if rescue_tasks:
            for sub_idx, task in enumerate(rescue_tasks):
                sub_pos = f"{pos}/1/{sub_idx}"
                if _execute_item(host, host_idx, host_cond, handler_order, leaf_notify,
                                 task, sub_pos, events, phase_notifications):
                    rescue_failed = True
                    break
        else:
            rescue_failed = True
    block_recovered = not normal_failed or (not rescue_failed and len(rescue_tasks) > 0)
    always_failed = False
    for sub_idx, task in enumerate(always_tasks):
        sub_pos = f"{pos}/2/{sub_idx}"
        if _execute_item(host, host_idx, host_cond, handler_order, leaf_notify,
                         task, sub_pos, events, phase_notifications):
            always_failed = True
            break
    uncaptured = (normal_failed and not block_recovered) or always_failed
    return uncaptured


def _execute_item(host, host_idx, host_cond, handler_order, leaf_notify,
                  item, pos, events, phase_notifications):
    """Execute either a task or nested block. Returns True if failure."""
    if isinstance(item, dict) and "block" in item:
        return _execute_block(host, host_idx, host_cond, handler_order, leaf_notify,
                              item, pos, events, phase_notifications)
    else:
        return _execute_task(host, host_idx, host_cond, handler_order, leaf_notify,
                             item, pos, events, phase_notifications)
