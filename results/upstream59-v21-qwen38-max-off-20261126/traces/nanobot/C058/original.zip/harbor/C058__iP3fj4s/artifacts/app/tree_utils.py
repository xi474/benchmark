"""Shared tree traversal utilities for C058."""

PHASE_ORDER = ["pre", "roles", "includes", "tasks", "post"]


def iter_program_nodes(program):
    """Yield (position_string, node, phase_name, branch) for every node in the program tree.

    position_string uses '/' separated integers.
    For tasks: position like "3/0" means phase index 3, item index 0.
    For blocks: the block itself gets e.g. "3/1", and its children get
      "3/1/0/0" (branch 0=tasks, item 0), "3/1/1/2" (branch 1=rescue, item 2), etc.
    branch is None for non-block nodes, 0/1/2 for block sub-tasks/rescue/always items.
    """
    for phase_idx, phase_name in enumerate(PHASE_ORDER):
        phase_items = program.get(phase_name, [])
        if not phase_items:
            continue
        for item_idx, item in enumerate(phase_items):
            pos = f"{phase_idx}/{item_idx}"
            if isinstance(item, dict) and "block" in item:
                # This is a block node
                yield (pos, item, phase_name, None)
                block = item["block"]
                for branch, branch_name in enumerate(["tasks", "rescue", "always"]):
                    branch_items = block.get(branch_name, [])
                    for sub_idx, sub_item in enumerate(branch_items):
                        sub_pos = f"{pos}/{branch}/{sub_idx}"
                        # Sub-items could themselves be blocks (nested)
                        yield from _iter_block_child(sub_pos, sub_item, phase_name, branch)
            else:
                # Regular task
                yield (pos, item, phase_name, None)


def _iter_block_child(pos, item, phase_name, parent_branch):
    """Recursively handle items inside block branches (they can be nested blocks)."""
    if isinstance(item, dict) and "block" in item:
        yield (pos, item, phase_name, parent_branch)
        block = item["block"]
        for branch, branch_name in enumerate(["tasks", "rescue", "always"]):
            branch_items = block.get(branch_name, [])
            for sub_idx, sub_item in enumerate(branch_items):
                sub_pos = f"{pos}/{branch}/{sub_idx}"
                yield from _iter_block_child(sub_pos, sub_item, phase_name, branch)
    else:
        yield (pos, item, phase_name, parent_branch)


def parse_position(pos_str):
    """Parse a position string into a tuple of ints."""
    return tuple(int(x) for x in pos_str.split("/"))


def position_sort_key(pos_str):
    """Return a sort key for canonical ordering of positions."""
    return parse_position(pos_str)


def is_task_node(node):
    """Check if a node is a task (not a block)."""
    return not (isinstance(node, dict) and "block" in node)


def get_task_id(node):
    """Get the id field of a task node."""
    return node.get("id")


def get_only_set(node):
    """Get the 'only' set from a node (task or block). Returns None if not specified."""
    only = node.get("only")
    if only is None:
        return None
    return set(only)


def get_fail_hosts(node):
    """Get the fail_hosts set from a task node."""
    fh = node.get("fail_hosts")
    if fh is None:
        return set()
    return set(fh)


def get_notify_list(node):
    """Get the notify list from a task node."""
    return node.get("notify", [])
