# Workflow 可观测性报告

- Trial：`C062__w69kWFJ__env`
- Task：`C062`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3b1eaa8e8cc848b8baae0a92 -> tool:nanobot-harness-v3:call_6cb446da90d44e92b5c6f253 -> tool:nanobot-harness-v3:call_d4eb1b8dba7a47c5a408a7b3 -> tool:nanobot-harness-v3:call_50c5097fd541453eb8b20dd1 -> tool:nanobot-harness-v3:call_bbfe44b6fdc74392ac98e5fc -> tool:nanobot-harness-v3:call_b9156c7170574092b494aeb4 -> tool:nanobot-harness-v3:call_0d481d65686f4cde900ea443 -> tool:nanobot-harness-v3:call_40b2171a095b4552bbffa3dd -> tool:nanobot-harness-v3:call_0e0035135168406a9ada61c8 -> tool:nanobot-harness-v3:call_7b401f1e80ae40e699ee8b6e -> tool:nanobot-harness-v3:call_11c279653f1f4d2cba4fd3d7 -> tool:nanobot-harness-v3:call_04f0df800c4d41fb9dac145e -> tool:nanobot-harness-v3:call_36ee176b21f946e5ac341666 -> tool:nanobot-harness-v3:call_599feb9c1689480a8a65e172 -> tool:nanobot-harness-v3:call_8d09cf11342143828e52f99c -> tool:nanobot-harness-v3:call_363f30b84ae743c7977db5bd -> tool:nanobot-harness-v3:call_4c118af555544f86a629f5f6 -> tool:nanobot-harness-v3:call_a7cbe3e316ad4a1691224acd -> tool:nanobot-harness-v3:call_6ebd5636a4b44cc5b59ed1a7 -> tool:nanobot-harness-v3:call_faec685483604558b475cccb -> tool:nanobot-harness-v3:call_a816a5e0fa9d45f387ddaa02 -> tool:nanobot-harness-v3:call_c8860c8a184e406b8c2fece4 -> tool:nanobot-harness-v3:call_50c8b33e61624fa38a6770f9 -> tool:nanobot-harness-v3:call_dd94a95f789d459caae84435 -> tool:nanobot-harness-v3:call_85e369ef6c6f485e9b132c03 -> tool:nanobot-harness-v3:call_ac96ed2c654d4e8c90e2092d -> tool:nanobot-harness-v3:call_51c14e0aca3042a9b5c47cb9 -> tool:nanobot-harness-v3:call_b2fa071840244a48b057c5d9 -> tool:nanobot-harness-v3:call_251613bf260a40048b019cf3 -> tool:nanobot-harness-v3:call_e4d24f2160da428c8c6f8b12 -> tool:nanobot-harness-v3:call_50ad8d72eafe46809a0e5612 -> tool:nanobot-harness-v3:call_17f160fa96564c33b7bcd09e -> tool:nanobot-harness-v3:call_c83838ff1a174a15bc51deef -> tool:nanobot-harness-v3:call_a576c8877c3144038f50ba94 -> tool:nanobot-harness-v3:call_7466738ba0c9440b8bcd77a9 -> tool:nanobot-harness-v3:call_6e5272718f4c45fc8fd7fd2a -> tool:nanobot-harness-v3:call_da6e71193fd54516b4ff8795 -> tool:nanobot-harness-v3:call_78bb962a830d4fc590a21f7b -> tool:nanobot-harness-v3:call_14386517f6224b13bda0b695 -> tool:nanobot-harness-v3:call_218661916fa146d2aa13b60b -> tool:nanobot-harness-v3:call_63729373a5e045979f276931
- 关键路径耗时：0.422182
- Makespan：132.36378
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
