def compute(payload):
    """对每个 open 事件按其原始位置（十进制字符串）建立初始状态，字段同最终 stores 项。"""
    events = payload.get("events", [])
    result = {}
    for idx, ev in enumerate(events):
        if ev.get("op") == "open":
            result[str(idx)] = {
                "backend": ev.get("backend"),
                "state": "open",
                "job": None,
                "revision": ev.get("revision", 0),
                "closed_at": None,
                "updates": 0
            }
    return result
