def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = store_initializers result: {index_str: initial_store_state}
    right = completion_effects result: {index_str: [event_name, new_revision_or_null]}
    """
    events = payload.get("events", [])

    # Build a map from store name -> open event index for quick lookup
    store_open_idx = {}  # store_name -> index in events
    for idx, ev in enumerate(events):
        if ev.get("op") == "open":
            store_open_idx[ev["store"]] = idx

    # Initialize stores from left component
    stores = {}
    for idx_str, state in left.items():
        idx = int(idx_str)
        store_name = events[idx]["store"]
        stores[store_name] = dict(state)  # copy

    # Pre-parse completion effects from right component
    # right maps complete-event-index -> [normal_event_name, new_revision_or_null]
    completion_info = {}
    for idx_str, info in right.items():
        completion_info[int(idx_str)] = info

    audit_events = []

    # Track per-store state machine
    # States: "open", "closing", "closed"
    # Additional tracking: pending_job, coalesced flag, cancel_pending
    class StoreState:
        pass

    sm = {}  # store_name -> runtime state
    for sname, sdata in stores.items():
        s = StoreState()
        s.state = "open"
        s.job = None           # current in-flight job name or None
        s.coalesced = False    # whether a second poll was merged
        s.cancel_pending = False
        s.revision = sdata["revision"]
        s.updates = 0
        s.closed_at = None
        s.backend = sdata["backend"]
        sm[sname] = s

    def emit(time, store, event_name, **extra):
        entry = {"time": time, "store": store, "event": event_name}
        entry.update(extra)
        audit_events.append(entry)

    for idx, ev in enumerate(events):
        op = ev.get("op")
        store = ev.get("store")
        time = ev.get("time")
        s = sm.get(store)

        if op == "open":
            emit(time, store, "opened")
            # Store already initialized above

        elif op == "poll":
            job = ev.get("job")
            if s.state == "open":
                if s.job is None:
                    # Start new job
                    s.job = job
                    s.coalesced = False
                    emit(time, store, "poll_started", job=job)
                else:
                    # Coalesce: merge without replacing
                    s.coalesced = True
                    emit(time, store, "poll_coalesced")
            else:
                # closing or closed: reject
                emit(time, store, "poll_rejected")

        elif op == "complete":
            job = ev.get("job")
            changed = ev.get("changed", False)
            normal_event_name, new_rev = completion_info[idx]

            if s.cancel_pending:
                # This complete is for a cancelled job
                emit(time, store, "callback_cancelled", job=job)
                s.cancel_pending = False
                s.job = None
                # After callback_cancelled, the close that triggered this can proceed
                # The close_returned will be emitted when we handle the close barrier
                # But actually, close blocks until callback arrives.
                # We need to emit close_returned here since the close was waiting.
                emit(time, store, "close_returned")
                s.state = "closed"
                s.closed_at = time
                stores[store]["state"] = "closed"
                stores[store]["job"] = None
                stores[store]["closed_at"] = time
                stores[store]["revision"] = s.revision
                stores[store]["updates"] = s.updates
            else:
                # Normal completion (not cancelled)
                if changed:
                    s.revision = new_rev
                    s.updates += 1
                    emit(time, store, "snapshot_updated", job=job)
                else:
                    emit(time, store, "poll_unchanged", job=job)
                s.job = None
                # Update store snapshot
                stores[store]["revision"] = s.revision
                stores[store]["updates"] = s.updates
                stores[store]["job"] = None

        elif op == "close":
            if s.state == "closed":
                # Already closed, return immediately
                emit(time, store, "close_returned")
            elif s.state == "closing":
                # Already closing, wait on same barrier
                emit(time, store, "close_waiting")
            elif s.state == "open":
                if s.job is None:
                    # No in-flight job, close immediately
                    s.state = "closed"
                    s.closed_at = time
                    emit(time, store, "close_returned")
                    stores[store]["state"] = "closed"
                    stores[store]["closed_at"] = time
                    stores[store]["revision"] = s.revision
                    stores[store]["updates"] = s.updates
                    stores[store]["job"] = None
                else:
                    # Has in-flight job: send cancel, enter closing state
                    s.state = "closing"
                    s.cancel_pending = True
                    emit(time, store, "cancel_sent", job=s.job)
                    # close blocks; close_returned or callback_cancelled+close_returned
                    # will be emitted when the corresponding complete arrives

    # Build final stores output
    final_stores = {}
    for sname in stores:
        s = sm[sname]
        final_stores[sname] = {
            "backend": s.backend,
            "state": s.state,
            "job": s.job,
            "revision": s.revision,
            "closed_at": s.closed_at,
            "updates": s.updates
        }

    return {
        "events": audit_events,
        "stores": final_stores
    }
