# Workflow 可观测性报告

- Trial：`C066__i9nYjKC__env`
- Task：`C066`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_c6dd2cd754d54436bf1d4346 -> tool:nanobot-harness-v3:call_40602e47dd8f45709b45b9c3 -> tool:nanobot-harness-v3:call_5a7ff2c0842a4381b18f71d6 -> tool:nanobot-harness-v3:call_547e08741702420a9df71782 -> tool:nanobot-harness-v3:call_0c45aaa16a9c4611bdae4acd -> tool:nanobot-harness-v3:call_a5202d485cdc4690917c179a -> tool:nanobot-harness-v3:call_ad310f5e3bb54024a823db34 -> tool:nanobot-harness-v3:call_51d8834a129c4cefad11d4e2 -> tool:nanobot-harness-v3:call_70b2a59a52bf48649b9cb627 -> tool:nanobot-harness-v3:call_e4e443c34fb545418e0cfb45 -> tool:nanobot-harness-v3:call_e0420c61ad1c4df6aa494368 -> tool:nanobot-harness-v3:call_d8f47d104e5240a7b9135269 -> tool:nanobot-harness-v3:call_9e3990b4f8c0464093f0d1ef -> tool:nanobot-harness-v3:call_7ec3603e9af2450f9c3686a2 -> tool:nanobot-harness-v3:call_6a54448d8c1b40778d68a576 -> tool:nanobot-harness-v3:call_501bd61775ec413da1e96d0d -> tool:nanobot-harness-v3:call_0e7a048927de44fca6ed6fa2 -> tool:nanobot-harness-v3:call_85171e7a62c34b2cbd987885 -> tool:nanobot-harness-v3:call_100b092f08b14fb2920780b1 -> tool:nanobot-harness-v3:call_a7a97a8148fe4a7a892c5103 -> tool:nanobot-harness-v3:call_6477e2450304479f8475e5a1 -> tool:nanobot-harness-v3:call_f4770ea5685e44d1b25fcfab -> tool:nanobot-harness-v3:call_aaa063aa89ab419094cbc062 -> tool:nanobot-harness-v3:call_68395a1eb2f94bba94ea9c8d -> tool:nanobot-harness-v3:call_369d09051fba4b75b94c3d73 -> tool:nanobot-harness-v3:call_ad6cd9441e3a414db9e2f869 -> tool:nanobot-harness-v3:call_294f907dceef4ad49a29724f -> tool:nanobot-harness-v3:call_245509fe53a1493f8eabd89e -> tool:nanobot-harness-v3:call_48b3fc7e72ac455fb7fb7956 -> tool:nanobot-harness-v3:call_d8fe8d495af14c06b2c74a7a -> tool:nanobot-harness-v3:call_c35b0d39b3684c15b6f3a740 -> tool:nanobot-harness-v3:call_359b25e873fa476793efa90a -> tool:nanobot-harness-v3:call_8ed0d48844d348dc9d607e56 -> tool:nanobot-harness-v3:call_69b108f2ec81436ca8c15bc8 -> tool:nanobot-harness-v3:call_d89ddab4fd48477d8e9653bd -> tool:nanobot-harness-v3:call_2cb8f5e046c047dd98f6c749 -> tool:nanobot-harness-v3:call_7552ee2d777e4023ad394e5d -> tool:nanobot-harness-v3:call_df9023fe62884ab5b538786f -> tool:nanobot-harness-v3:call_3d86a7e463eb473595e8e7b9 -> tool:nanobot-harness-v3:call_2deb04f9217b4a2f9756a045
- 关键路径耗时：0.286105
- Makespan：104.847194
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
