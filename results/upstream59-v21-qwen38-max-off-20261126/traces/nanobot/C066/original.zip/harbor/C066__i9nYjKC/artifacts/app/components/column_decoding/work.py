# Expected types for each column
COL_TYPES = {
    "key": "text",
    "body": "text",
    "rank": "int",
}


def _decode_value(name, col_type, value):
    """Decode a column value according to its declared type.
    Returns (decoded_value, ok). ok=False means type mismatch."""
    expected = COL_TYPES.get(name)
    if expected is None:
        # Unknown column name – treat as type error
        return None, False
    if col_type != expected:
        return None, False
    if expected == "text":
        # value must be string or null
        if value is None or isinstance(value, str):
            return value, True
        return None, False
    elif expected == "int":
        # value must be a decimal integer string or null
        if value is None:
            return None, True
        if isinstance(value, str):
            try:
                return int(value), True
            except (ValueError, TypeError):
                return None, False
        return None, False
    return None, False


def compute(payload):
    """按事务、语句、行变更生成已解码的列映射。D 用空对象；类型错误用 null，使整合端按事务回滚。"""
    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        tx_decoded = []
        for stmt in tx.get("statements", []):
            stmt_decoded = []
            for op in stmt:
                op_type = op["op"]
                if op_type == "D":
                    stmt_decoded.append({})
                else:
                    # I or U
                    cols = op.get("cols", [])
                    col_map = {}
                    ok = True
                    for col in cols:
                        name = col["name"]
                        ctype = col["type"]
                        value = col["value"]
                        decoded, valid = _decode_value(name, ctype, value)
                        if not valid:
                            ok = False
                            break
                        col_map[name] = decoded
                    if not ok:
                        stmt_decoded.append(None)
                    else:
                        stmt_decoded.append(col_map)
            tx_decoded.append(stmt_decoded)
        result.append(tx_decoded)
    return result
