def compute(payload):
    """按事务、语句生成被消费旧主键的去重有序数组，I 不消耗旧主键。"""
    txs = payload.get("txs", [])
    result = []
    for tx in txs:
        tx_old_keys = []
        for stmt in tx.get("statements", []):
            seen = set()
            ordered = []
            for op in stmt:
                if op["op"] in ("U", "D"):
                    old_key = op["old"]
                    if old_key not in seen:
                        seen.add(old_key)
                        ordered.append(old_key)
            tx_old_keys.append(ordered)
        result.append(tx_old_keys)
    return result
