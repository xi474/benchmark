def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = row_identities result: per-tx, per-stmt list of consumed old keys
    right = column_decoding result: per-tx, per-stmt, per-op decoded col maps (None = type error)
    """
    initial = payload.get("initial", {})
    txs = payload.get("txs", [])

    # Deep copy initial state
    rows = {}
    for pk, data in initial.items():
        rows[pk] = {"body": data.get("body"), "rank": data.get("rank")}

    committed_lsns = set()
    log = []

    for tx_idx, tx in enumerate(txs):
        lsn = tx["lsn"]

        # REPLAY check
        if lsn in committed_lsns:
            log.append([lsn, "REPLAY"])
            continue

        statements = tx.get("statements", [])
        tx_old_keys = left[tx_idx]   # per-stmt old key lists
        tx_decoded = right[tx_idx]   # per-stmt, per-op decoded col maps

        aborted = False
        # Snapshot-based statement execution
        # We need to track state changes within the transaction
        # Each statement sees the snapshot at its start (which includes prior stmt effects in same tx)
        tx_rows = {k: dict(v) for k, v in rows.items()}

        for stmt_idx, stmt in enumerate(statements):
            old_keys = tx_old_keys[stmt_idx]
            decoded_ops = tx_decoded[stmt_idx]

            # Check for type errors (None in decoded_ops means abort)
            if any(d is None for d in decoded_ops):
                aborted = True
                break

            # Validate: all old keys must exist in current tx_rows
            for old_key in old_keys:
                if old_key not in tx_rows:
                    aborted = True
                    break
            if aborted:
                break

            # Build new rows for this statement
            # Step 1: Remove all U/D old identities
            new_rows = {k: dict(v) for k, v in tx_rows.items()}
            for old_key in old_keys:
                del new_rows[old_key]

            # Step 2: Place I/U new rows
            for op_idx, op in enumerate(stmt):
                op_type = op["op"]
                col_map = decoded_ops[op_idx]

                if op_type == "I":
                    # Must have key, body, rank
                    new_key = col_map.get("key")
                    if new_key is None or not isinstance(new_key, str):
                        aborted = True
                        break
                    if new_key in new_rows:
                        aborted = True
                        break
                    new_rows[new_key] = {
                        "body": col_map.get("body"),
                        "rank": col_map.get("rank"),
                    }
                elif op_type == "U":
                    old_key = op["old"]
                    # Get old row from snapshot (tx_rows, not new_rows)
                    old_row = tx_rows[old_key]
                    # Determine new key
                    new_key = col_map.get("key", old_key)
                    if not isinstance(new_key, str):
                        aborted = True
                        break
                    # Build updated row: inherit missing cols from old
                    new_body = col_map.get("body", old_row["body"])
                    new_rank = col_map.get("rank", old_row["rank"])
                    # Check collision: new_key must not already be in new_rows
                    # (unless it's the same as old_key which was already removed)
                    if new_key in new_rows:
                        aborted = True
                        break
                    new_rows[new_key] = {
                        "body": new_body,
                        "rank": new_rank,
                    }
                elif op_type == "D":
                    # Already removed via old_keys
                    pass

            if aborted:
                break

            # Commit this statement's changes into tx_rows
            tx_rows = new_rows

        if aborted:
            log.append([lsn, "ABORT"])
        else:
            rows = tx_rows
            committed_lsns.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": rows}
