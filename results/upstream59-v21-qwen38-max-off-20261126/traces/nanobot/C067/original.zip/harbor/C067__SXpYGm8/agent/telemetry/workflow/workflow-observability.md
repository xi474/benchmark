# Workflow 可观测性报告

- Trial：`C067__SXpYGm8__env`
- Task：`C067`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_6a59ddcc1c1642a2a5686744 -> tool:nanobot-harness-v3:call_f00902ab3f2541829aa7ea03 -> tool:nanobot-harness-v3:call_ad234ae94fa4471987005ce6 -> tool:nanobot-harness-v3:call_edfc88936f4e4f78babe9618 -> tool:nanobot-harness-v3:call_c3db6cb21d304996b8ff81ee -> tool:nanobot-harness-v3:call_607a15cb44604c4dbad62508 -> tool:nanobot-harness-v3:call_08967faa017e4fd48f33c0fe -> tool:nanobot-harness-v3:call_1fe89aa9fc3a419ab32f527f -> tool:nanobot-harness-v3:call_f5a20730aa724d5ca7c07ca9 -> tool:nanobot-harness-v3:call_46839f314c5849d1a7ff0847 -> tool:nanobot-harness-v3:call_34eaf6288ac44c9ea7dcd855 -> tool:nanobot-harness-v3:call_b58b137f11f14e8aaae82c8e -> tool:nanobot-harness-v3:call_b1bc1e16ef9e49f58b67fdb6 -> tool:nanobot-harness-v3:call_6b96af2c4eae4c6ba2a6abcf -> tool:nanobot-harness-v3:call_372b6c3331d84a75b023215f -> tool:nanobot-harness-v3:call_aa8e7c5e86b241ad998db59b -> tool:nanobot-harness-v3:call_f44121ae8d21475ba2f86893 -> tool:nanobot-harness-v3:call_71eed588d292446792ee9948 -> tool:nanobot-harness-v3:call_0b6de68d4f4346c595fc12ef -> tool:nanobot-harness-v3:call_78eff2466aab48caa25fe637 -> tool:nanobot-harness-v3:call_d188847d35474c88831a75ab -> tool:nanobot-harness-v3:call_ae866a5a672f46b6bcb07962 -> tool:nanobot-harness-v3:call_9a5c8f8a21104617864dc76a -> tool:nanobot-harness-v3:call_8bcce180907c4d36b31f3d10 -> tool:nanobot-harness-v3:call_e672999b14824ce89550368a -> tool:nanobot-harness-v3:call_c5669923a4cd4fa991c00a3c -> tool:nanobot-harness-v3:call_94f78322df11438db10be6e7 -> tool:nanobot-harness-v3:call_011cc31e9bb0433d8cbc5896 -> tool:nanobot-harness-v3:call_9dc518691034426b8900d741 -> tool:nanobot-harness-v3:call_9c4c1483c5ba4f2a94fc3e2d -> tool:nanobot-harness-v3:call_1376ca0a005442d3ba69ee87 -> tool:nanobot-harness-v3:call_c651c5aae26642a888d42c77 -> tool:nanobot-harness-v3:call_5d8b5929bfcf4ebbacbbf861 -> tool:nanobot-harness-v3:call_7a852735a598438c9144e4e0 -> tool:nanobot-harness-v3:call_0cb151ddd84f489c880c1924
- 关键路径耗时：0.371279
- Makespan：81.017054
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
