def compute(payload):
    """按事件位置返回请求当时的 [集群模式,服务是否可用]；合并端负责授权优先和实际计数。"""
    import copy
    clusters = copy.deepcopy(payload.get("clusters", {}))
    events = payload.get("events", [])
    result = {}
    req_index = 0
    for event in events:
        op = event.get("op")
        if op == "service":
            cluster = event["cluster"]
            service = event["service"]
            available = event.get("available", True)
            if cluster in clusters:
                clusters[cluster].setdefault("services", {})[service] = available
        elif op == "request":
            cluster_name = event.get("cluster", "")
            service_name = event.get("service", "")
            cluster_info = clusters.get(cluster_name, {})
            mode = cluster_info.get("mode", "unknown")
            services = cluster_info.get("services", {})
            available = bool(services.get(service_name, False))
            result[str(req_index)] = [mode, available]
            req_index += 1
    return result
