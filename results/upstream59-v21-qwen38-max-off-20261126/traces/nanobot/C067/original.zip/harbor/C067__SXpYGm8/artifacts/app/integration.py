def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload.get("ttl", 0)
    events = payload.get("events", [])

    # left = policy_decisions result: {"0": true/false, ...}
    # right = service_routes result: {"0": [mode, available], ...}

    replies = []
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0
    cert_counter = 0
    # cache key: (user, cluster, service) -> {"credential": ..., "expires": ...}
    cache = {}

    req_index = 0
    for event in events:
        if event.get("op") != "request":
            continue

        req_id = event["id"]
        user = event.get("user", "")
        cluster = event.get("cluster", "")
        service = event.get("service", "")
        now = event.get("time", 0)

        idx_key = str(req_index)
        authorized = left.get(idx_key, False)
        mode_available = right.get(idx_key, ["unknown", False])
        mode = mode_available[0]
        available = mode_available[1]

        authorizer_calls += 1

        if not authorized:
            replies.append({"id": req_id, "status": "denied"})
            req_index += 1
            continue

        # Authorized: must look up service
        service_lookups += 1

        if not available:
            replies.append({"id": req_id, "status": "not_found"})
            req_index += 1
            continue

        # Service is available
        if mode == "local":
            replies.append({
                "id": req_id,
                "status": "ok",
                "credential": "local",
                "route": "local"
            })
        else:
            # remote
            remote_routes += 1
            cache_key = (user, cluster, service)

            # Clean expired entries before cache access
            expired_keys = [k for k, v in cache.items() if v["expires"] <= now]
            for k in expired_keys:
                del cache[k]

            if cache_key in cache:
                cred = cache[cache_key]["credential"]
            else:
                cert_counter += 1
                cred = f"cert-{cert_counter}"
                certificates_issued += 1
                cache[cache_key] = {
                    "credential": cred,
                    "expires": now + ttl
                }

            replies.append({
                "id": req_id,
                "status": "ok",
                "credential": cred,
                "route": "reverse_tunnel"
            })

        req_index += 1

    # Build final cache sorted by user/cluster/service
    cache_list = []
    for key in sorted(cache.keys()):
        user, cluster, service = key
        entry = cache[key]
        cache_list.append({
            "user": user,
            "cluster": cluster,
            "service": service,
            "credential": entry["credential"],
            "expires": entry["expires"]
        })

    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": cache_list
    }
