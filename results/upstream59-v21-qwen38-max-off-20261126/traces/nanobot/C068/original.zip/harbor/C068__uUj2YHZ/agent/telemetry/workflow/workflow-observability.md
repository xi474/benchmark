# Workflow 可观测性报告

- Trial：`C068__uUj2YHZ__env`
- Task：`C068`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_a21e346db877415390576135 -> tool:nanobot-harness-v3:call_b334ea41a7a247899055209c -> tool:nanobot-harness-v3:call_c392f1f2d78b4a9c9bbb440c -> tool:nanobot-harness-v3:call_9ef967cd95cf43c0a4409d6c -> tool:nanobot-harness-v3:call_0b5b7cedbb23465089dd563e -> tool:nanobot-harness-v3:call_7892745c5b1b4af9ac634123 -> tool:nanobot-harness-v3:call_b7ab3b9c86074369b719f2f6 -> tool:nanobot-harness-v3:call_24e5ffe3510e441d9e3e6f8d -> tool:nanobot-harness-v3:call_e06d54e242434b0ca45a720b -> tool:nanobot-harness-v3:call_8e15576b0b0142f085cbe65b -> tool:nanobot-harness-v3:call_86941d5abeb44601864006a3 -> tool:nanobot-harness-v3:call_bdc139cbc8044441a669bd5b -> tool:nanobot-harness-v3:call_6ebd3c848e284a6eb74cd4b9 -> tool:nanobot-harness-v3:call_755b4b313f564088a2fc1c1b -> tool:nanobot-harness-v3:call_89fd67ed66cd4b4bb63addfb -> tool:nanobot-harness-v3:call_47d65c9b51c84cbfb7f1a2ca -> tool:nanobot-harness-v3:call_9dd0d3fa3be147509748bc73 -> tool:nanobot-harness-v3:call_1975bfaef4a14c0e990a3ce4 -> tool:nanobot-harness-v3:call_595a9e29df2b41a2a201135c -> tool:nanobot-harness-v3:call_59bf84cd5a5148188ec343b0 -> tool:nanobot-harness-v3:call_1fcb27f09072413f81895551 -> tool:nanobot-harness-v3:call_99596f3260194c2baa596fa8 -> tool:nanobot-harness-v3:call_e3fefdfcbb5c431ab7e4476d -> tool:nanobot-harness-v3:call_0f1af7a0c46242999f254f98 -> tool:nanobot-harness-v3:call_39ac43cb7be849248dc6d537 -> tool:nanobot-harness-v3:call_3add3f66add34ef3959dc6ef -> tool:nanobot-harness-v3:call_6e14476843e54fd1bdb83a20 -> tool:nanobot-harness-v3:call_e438366c553144948b40c53c -> tool:nanobot-harness-v3:call_0ad3e3fec7ba488b959dbe49 -> tool:nanobot-harness-v3:call_ddadc887d65147f7be0340df -> tool:nanobot-harness-v3:call_286b33510c7147b4b501fc73 -> tool:nanobot-harness-v3:call_2b0b4605c93b4576b1bd9e2b -> tool:nanobot-harness-v3:call_1feb7d33abea4b21b612c2b7 -> tool:nanobot-harness-v3:call_a5304722d5434aaeb8990b42 -> tool:nanobot-harness-v3:call_d244ce8ee2be4ca39658d497 -> tool:nanobot-harness-v3:call_f29805fb1fae4d4fb82fc203 -> tool:nanobot-harness-v3:call_d1ba10deb1fa432eb4db31d8
- 关键路径耗时：0.497036
- Makespan：171.526557
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
