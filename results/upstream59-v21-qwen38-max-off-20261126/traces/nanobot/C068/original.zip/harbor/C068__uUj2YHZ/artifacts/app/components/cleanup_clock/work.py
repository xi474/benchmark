def compute(payload):
    """按 get 驱动的 16×TTL 规则生成触发清理的 get 位置，以及下一次清理的时间。输出以位置字符串为键的映射。"""
    ttl = payload["ttl"]
    events = payload["events"]
    next_cleanup = 16 * ttl
    result = {}
    for i, evt in enumerate(events):
        if evt["op"] != "get":
            continue
        now = evt["time"]
        if now >= next_cleanup:
            result[str(i)] = now + 16 * ttl
            next_cleanup = now + 16 * ttl
    return result
