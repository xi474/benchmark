def compute(payload):
    """为每个 get 的原始位置生成 [若启动时的完成时刻,value,error]；只有命中未复用时才实际启动。"""
    events = payload["events"]
    result = {}
    for i, evt in enumerate(events):
        if evt["op"] != "get":
            continue
        now = evt["time"]
        delay = evt["delay"]
        value = evt["value"]
        error = evt.get("error", None)
        finished_at = now + delay
        result[str(i)] = [finished_at, value, error]
    return result
