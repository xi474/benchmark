def combine(payload, cleanup_clock_result, load_proposals_result):
    """Combine the two component JSON values under the business contract in TASK.md."""
    ttl = payload["ttl"]
    events = payload["events"]

    # State
    cache = {}  # key -> {"value": ..., "error": ..., "expires": ...}
    next_cleanup = 16 * ttl
    in_flight = {}  # key -> {"started_at": ..., "finished_at": ..., "waiters": [...], "value": ..., "error": ...}
    loads_started = []  # list of {"key": ..., "started_at": ..., "finished_at": ...}
    results = []  # in get order
    get_results = {}  # id -> result dict (filled when resolved)
    cancelled_ids = set()
    get_order = []  # ids in get order

    # Map get index to event info
    get_events = []  # list of (event_index, event)
    for i, evt in enumerate(events):
        if evt["op"] == "get":
            get_events.append((i, evt))

    def complete_loads_up_to(now):
        """Complete all in-flight loads with finished_at <= now, in launch order."""
        # Collect loads that are due, sorted by started_at (launch order)
        due = []
        for key, info in list(in_flight.items()):
            if info["finished_at"] <= now:
                due.append((info["started_at"], key, info))
        due.sort(key=lambda x: x[0])
        for _, key, info in due:
            finished_at = info["finished_at"]
            value = info["value"]
            error = info["error"]
            # Stamp cache
            cache[key] = {"value": value, "error": error, "expires": finished_at + ttl}
            # Resolve waiters
            for waiter_id in info["waiters"]:
                if waiter_id in cancelled_ids:
                    get_results[waiter_id] = {
                        "id": waiter_id,
                        "status": "cancelled",
                        "value": None,
                        "error": "cancelled",
                        "finished_at": finished_at
                    }
                else:
                    if error is not None:
                        get_results[waiter_id] = {
                            "id": waiter_id,
                            "status": "error",
                            "value": None,
                            "error": error,
                            "finished_at": finished_at
                        }
                    else:
                        get_results[waiter_id] = {
                            "id": waiter_id,
                            "status": "ok",
                            "value": value,
                            "error": None,
                            "finished_at": finished_at
                        }
            del in_flight[key]

    def evict_key_if_expired(key, now):
        """Immediately evict a specific key if expired."""
        if key in cache and cache[key]["expires"] <= now:
            del cache[key]

    def maybe_global_cleanup(now):
        """If now >= next_cleanup, remove all expired items and advance next_cleanup."""
        nonlocal next_cleanup
        if now >= next_cleanup:
            expired_keys = [k for k, v in cache.items() if v["expires"] <= now]
            for k in expired_keys:
                del cache[k]
            next_cleanup = now + 16 * ttl

    for evt_idx, evt in enumerate(events):
        op = evt["op"]
        now = evt["time"]

        if op == "advance":
            # Complete loads due up to now
            complete_loads_up_to(now)
        elif op == "cancel":
            cancel_id = evt["id"]
            # Complete loads due up to now first
            complete_loads_up_to(now)
            # Mark as cancelled
            cancelled_ids.add(cancel_id)
        elif op == "get":
            gid = evt["id"]
            key = evt["key"]
            delay = evt["delay"]

            # Before processing: complete due loads
            complete_loads_up_to(now)

            # Cleanup checks
            maybe_global_cleanup(now)
            evict_key_if_expired(key, now)

            # Check if there's an in-flight load for this key
            if key in in_flight:
                # Join existing in-flight load
                in_flight[key]["waiters"].append(gid)
                get_order.append(gid)
            elif key in cache:
                # Cache hit
                entry = cache[key]
                if entry["error"] is not None:
                    get_results[gid] = {
                        "id": gid,
                        "status": "error",
                        "value": None,
                        "error": entry["error"],
                        "finished_at": now
                    }
                else:
                    get_results[gid] = {
                        "id": gid,
                        "status": "ok",
                        "value": entry["value"],
                        "error": None,
                        "finished_at": now
                    }
                get_order.append(gid)
            else:
                # Cache miss - start a new load
                proposal = load_proposals_result[str(evt_idx)]
                finished_at = proposal[0]
                load_value = proposal[1]
                load_error = proposal[2]
                load_info = {
                    "started_at": now,
                    "finished_at": finished_at,
                    "waiters": [gid],
                    "value": load_value,
                    "error": load_error
                }
                in_flight[key] = load_info
                loads_started.append({
                    "key": key,
                    "started_at": now,
                    "finished_at": finished_at
                })
                get_order.append(gid)

                # If delay == 0, the load completes within this get call
                if delay == 0:
                    complete_loads_up_to(now)

    # Build results in get order
    for gid in get_order:
        results.append(get_results[gid])

    # Build cache output sorted by key
    cache_output = []
    for key in sorted(cache.keys()):
        entry = cache[key]
        cache_output.append({
            "key": key,
            "value": entry["value"],
            "error": entry["error"],
            "expires": entry["expires"]
        })

    return {
        "results": results,
        "loads": loads_started,
        "cache": cache_output,
        "next_cleanup": next_cleanup
    }
