# Workflow 可观测性报告

- Trial：`C069__yfT6LTG__env`
- Task：`C069`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（36 节点 / 35 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：36；执行边：35（observed=0，inferred=35）
- Execution Trace Graph：`observed`；temporal_next 边 35，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d0784e01bdfd4ff8810b11e4 -> tool:nanobot-harness-v3:call_94b0a69406f1448888c11606 -> tool:nanobot-harness-v3:call_c70070c98d5e489b8c004105 -> tool:nanobot-harness-v3:call_2d85c2ef24484cbfb0c4d2ee -> tool:nanobot-harness-v3:call_b502f5af5a2f4ec6a90f87d1 -> tool:nanobot-harness-v3:call_e6139a4fcd704e90a1919120 -> tool:nanobot-harness-v3:call_a7aaa6ef92324fb4b8f62af0 -> tool:nanobot-harness-v3:call_86d04eb48c7f4f9b9260f9f9 -> tool:nanobot-harness-v3:call_0aa64989a6cf4039849cee7a -> tool:nanobot-harness-v3:call_062db82f500a4194a1c576d1 -> tool:nanobot-harness-v3:call_76873462b1014b59ae70cb43 -> tool:nanobot-harness-v3:call_cb16127cf62e40a39eca4501 -> tool:nanobot-harness-v3:call_56f637b8776c4f4fbe5243c4 -> tool:nanobot-harness-v3:call_bbf5ef20c8f44975b18ee284 -> tool:nanobot-harness-v3:call_eaa07a2c0a8b417a99a1fec8 -> tool:nanobot-harness-v3:call_5f12c498700f45419c5700bc -> tool:nanobot-harness-v3:call_b33a6a7961d84fc9bb8d0191 -> tool:nanobot-harness-v3:call_1ede8d59747d416eb58ee8dd -> tool:nanobot-harness-v3:call_3e37bae4caa34b3eb48742ea -> tool:nanobot-harness-v3:call_13c99e9b1a624cf6b7a4e4ab -> tool:nanobot-harness-v3:call_89215d7180124daba884efff -> tool:nanobot-harness-v3:call_acfd4453e446453a8813469a -> tool:nanobot-harness-v3:call_d15ea6be29ee4f5598959f6a -> tool:nanobot-harness-v3:call_083b240c2a024feab01efe85 -> tool:nanobot-harness-v3:call_9dd3dda4e2144711b4dc98d8 -> tool:nanobot-harness-v3:call_9ef9c97a3ee7405d8c26369c -> tool:nanobot-harness-v3:call_5394817d6b584660a24333f0 -> tool:nanobot-harness-v3:call_9c9fbdfcb08d489fbf13cd48 -> tool:nanobot-harness-v3:call_28c8c10824b64c6aad50e151 -> tool:nanobot-harness-v3:call_2b4e289e7c0643548ae80948 -> tool:nanobot-harness-v3:call_ca2a04ad714a43e287368314 -> tool:nanobot-harness-v3:call_5663fb7450aa4c19bfebd19a -> tool:nanobot-harness-v3:call_dd1c8565741a416faaf0e90d -> tool:nanobot-harness-v3:call_889c95fe30c242bcbff9111b -> tool:nanobot-harness-v3:call_24686b3de73d43c0ab4a04ca
- 关键路径耗时：0.506004
- Makespan：142.284228
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
