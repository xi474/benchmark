import copy

def compute(payload):
    """Record user snapshots, replaying update_user ops on roles/traits.
    Keyed by original position as string. Position '0' is the initial user.
    update_user events create entries at their position."""
    user = copy.deepcopy(payload.get("user", {}))
    events = payload.get("events", [])
    result = {}
    # Position 0 is always the initial user state
    result["0"] = copy.deepcopy(user)
    for i, ev in enumerate(events):
        pos = str(i + 1)
        if ev.get("op") == "update_user":
            updates = ev.get("user", {})
            if "roles" in updates:
                user["roles"] = list(updates["roles"])
            if "traits" in updates:
                user["traits"] = copy.deepcopy(updates["traits"])
            result[pos] = copy.deepcopy(user)
    return result
