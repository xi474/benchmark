import base64
import copy
import json


def _b64url_encode(obj):
    """JSON-encode with sort_keys, compact separators, ensure_ascii=False, then base64url no-pad."""
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    raw = base64.urlsafe_b64encode(text.encode('utf-8')).decode('ascii')
    return raw.rstrip('=')


def _encode_ssh(session):
    obj = {
        'roles': session['roles'],
        'allowed_resources': session['resources'],
        'extensions': session['cached_user'].get('traits', {}),
        'login_time': session['login_time'],
        'expires': session['expiry'],
    }
    return 'SSH-MODEL1.' + _b64url_encode(obj)


def _encode_tls(session):
    obj = {
        'user': session['cached_user']['name'],
        'active_requests': sorted(session['active_request_ids']),
        'login_time': session['login_time'],
        'expires': session['expiry'],
    }
    return 'TLS-MODEL1.' + _b64url_encode(obj)


def combine(payload, left, right):
    """Combine user_history (left) and grant_catalog (right) into final output."""
    user = payload['user']
    start_time = payload['start_time']
    session_ttl = payload['session_ttl']
    access_requests = payload.get('access_requests', {})
    events = payload.get('events', [])
    initial_id = payload.get('initial_id', 's0')

    # grant_catalog gives normalized access requests
    grant_catalog = right  # dict keyed by request id

    # Create initial session s0
    sessions = {}
    s0 = {
        'id': initial_id,
        'login_time': start_time,
        'expiry': start_time + session_ttl,
        'cached_user': copy.deepcopy(user),
        'active_request_ids': [],  # list of active access request ids
    }
    sessions[initial_id] = s0
    session_order = [initial_id]
    replies = []

    for ev in events:
        op = ev.get('op')
        if op == 'update_user':
            # update_user modifies the backend user (not any session cache)
            updates = ev.get('user', {})
            if 'roles' in updates:
                user['roles'] = list(updates['roles'])
            if 'traits' in updates:
                user['traits'] = copy.deepcopy(updates['traits'])
            continue

        if op != 'renew':
            continue

        ev_id = ev['id']
        now = ev['time']
        prev_id = ev['prev']
        reload_user = ev.get('reload_user', False)
        switchback = ev.get('switchback', False)
        assume_req_id = ev.get('access_request', None)

        # prev must be a successfully created session
        if prev_id not in sessions:
            replies.append({'id': ev_id, 'status': 'error'})
            continue

        prev = sessions[prev_id]

        # Check if prev is expired
        if prev['expiry'] <= now:
            replies.append({'id': ev_id, 'status': 'expired'})
            continue

        # Determine cached user for new session
        if reload_user:
            cached_user = copy.deepcopy(user)
        else:
            cached_user = copy.deepcopy(prev['cached_user'])

        # Start with prev's active requests
        active_request_ids = list(prev['active_request_ids'])

        # Handle switchback: clear all temporary requests and resources
        if switchback:
            active_request_ids = []

        # Handle assume (access_request)
        if assume_req_id is not None:
            req = grant_catalog.get(assume_req_id)
            if req is None or not req['approved'] or req['expiry'] <= now:
                replies.append({'id': ev_id, 'status': 'request_unavailable'})
                continue

            # Check resource_already_active: if the chain already has any resource
            # request active, and the new request is also a resource request
            new_has_resources = len(req.get('resources', [])) > 0
            if new_has_resources:
                # Check if any currently active request is a resource request
                for ar_id in active_request_ids:
                    ar = grant_catalog.get(ar_id, {})
                    if len(ar.get('resources', [])) > 0:
                        replies.append({'id': ev_id, 'status': 'resource_already_active'})
                        break
                else:
                    # No conflict, proceed
                    pass
                # If we broke out of the loop (found conflict), skip
                if any(len(grant_catalog.get(ar_id, {}).get('resources', [])) > 0 for ar_id in active_request_ids):
                    continue

            # Add the request (deduplicate)
            if assume_req_id not in active_request_ids:
                active_request_ids.append(assume_req_id)

        # Filter out expired active requests - they become unavailable
        valid_active = []
        for ar_id in active_request_ids:
            ar = grant_catalog.get(ar_id, {})
            if ar.get('expiry', 0) <= now:
                # Expired request: if it was explicitly assumed and now expired,
                # that's request_unavailable
                # But per spec: "没有显式切回时，活跃request不得静默丢弃，到期则request_unavailable"
                replies.append({'id': ev_id, 'status': 'request_unavailable'})
                valid_active = None
                break
            valid_active.append(ar_id)

        if valid_active is None:
            continue

        active_request_ids = valid_active

        # Compute roles: cached user base roles union active request roles, sorted
        roles = set(cached_user.get('roles', []))
        resources = set()
        for ar_id in active_request_ids:
            ar = grant_catalog.get(ar_id, {})
            roles.update(ar.get('roles', []))
            resources.update(ar.get('resources', []))

        roles_sorted = sorted(roles)
        resources_sorted = sorted(resources)

        # Compute expiry
        if active_request_ids:
            min_req_expiry = min(grant_catalog[ar_id]['expiry'] for ar_id in active_request_ids)
            expiry = min(now + session_ttl, min_req_expiry)
        else:
            expiry = now + session_ttl

        new_session = {
            'id': ev_id,
            'login_time': prev['login_time'],
            'expiry': expiry,
            'cached_user': cached_user,
            'active_request_ids': active_request_ids,
            'roles': roles_sorted,
            'resources': resources_sorted,
        }
        sessions[ev_id] = new_session
        session_order.append(ev_id)

        reply = {
            'id': ev_id,
            'status': 'ok',
            'ssh_certificate': _encode_ssh(new_session),
            'tls_certificate': _encode_tls(new_session),
        }
        replies.append(reply)

    return {
        'replies': replies,
        'session_ids': session_order,
    }
