# Workflow 可观测性报告

- Trial：`C074__CBzLPqt__env`
- Task：`C074`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f951fa0f4f0c440aac714458 -> tool:nanobot-harness-v3:call_d2510ed150724d6193253de7 -> tool:nanobot-harness-v3:call_175729b7b6f9405691609715 -> tool:nanobot-harness-v3:call_4e9d0107e2e340f692635890 -> tool:nanobot-harness-v3:call_9c96ec5845b243cda4874cf9 -> tool:nanobot-harness-v3:call_9c4ae5144c964c91ae8585ed -> tool:nanobot-harness-v3:call_9d4ee9954bdf447d987dc5d9 -> tool:nanobot-harness-v3:call_fb799a085cb64057a545e077 -> tool:nanobot-harness-v3:call_fa39227730424ee7a2f59865 -> tool:nanobot-harness-v3:call_731e37b1c1f34a7b9cacaeeb -> tool:nanobot-harness-v3:call_300c96a6099648c7bad1f56e -> tool:nanobot-harness-v3:call_f3856bbeaeab4181af7136f3 -> tool:nanobot-harness-v3:call_abe6536fb87641ed9aa43c73 -> tool:nanobot-harness-v3:call_bf67b08e5456446b82125b53 -> tool:nanobot-harness-v3:call_6eacbaf7e67a4cd0996d03fb -> tool:nanobot-harness-v3:call_cd7274371d3e4d6a8994d04d -> tool:nanobot-harness-v3:call_52655fe8e27a489a95f2fa45 -> tool:nanobot-harness-v3:call_c4eb91ff1a3d4d7683eb763a -> tool:nanobot-harness-v3:call_dab298c302cc4e9b9706b5fc -> tool:nanobot-harness-v3:call_939c2a0299b84a9e80ac0f1b -> tool:nanobot-harness-v3:call_a3241893527c41d684df8d32 -> tool:nanobot-harness-v3:call_7e87168ea86e420589df3566 -> tool:nanobot-harness-v3:call_b1e4836e2e1343b28a78db8f -> tool:nanobot-harness-v3:call_c67b72df98324e779b6f1474 -> tool:nanobot-harness-v3:call_b1072b8b7a4c4d14b320fbdd -> tool:nanobot-harness-v3:call_4e1e11cd7c804bb68140ed45 -> tool:nanobot-harness-v3:call_ebdc4c5b419644ee9a8abdcf -> tool:nanobot-harness-v3:call_0de0d4bf66dc4d2fa38d7d42 -> tool:nanobot-harness-v3:call_c2c48944e8f148abb9e16ce9 -> tool:nanobot-harness-v3:call_d196a37dd1c84025b81f9303 -> tool:nanobot-harness-v3:call_deb9c855e35b45469625678b -> tool:nanobot-harness-v3:call_c1128a6fd4114c30af1f218d -> tool:nanobot-harness-v3:call_332f5fce417a445fa4f28c50 -> tool:nanobot-harness-v3:call_b219fb1963a143f99fd4127e -> tool:nanobot-harness-v3:call_c6583fe113974fdba10950c3 -> tool:nanobot-harness-v3:call_81b78c51eeb84fbeacb7b146 -> tool:nanobot-harness-v3:call_22b17721950f44fcad9adf33 -> tool:nanobot-harness-v3:call_caeda5d42d494dfba37f3407 -> tool:nanobot-harness-v3:call_ded621fb2f3247d78a5c5745 -> tool:nanobot-harness-v3:call_bad9b5fa563d4f079c782c3a
- 关键路径耗时：0.418058
- Makespan：172.980106
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
