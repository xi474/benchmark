import copy


def _resolve_node(path, mounts, nodes):
    """Resolve a logical path to its node id, walking through dirs.
    Returns None if unreachable."""
    parts = path.split("/")
    mount_name = parts[0]
    if mount_name not in mounts:
        return None
    node_id = mounts[mount_name]
    for part in parts[1:]:
        node = nodes[node_id]
        ignore_set = set(node.get("ignore", []))
        if part in ignore_set:
            return None
        dirs = node.get("dirs", {})
        if part not in dirs:
            return None
        node_id = dirs[part]
    return node_id


def _get_snapshot(node_id, nodes):
    """Get [filtered_files, sorted_visible_dir_names] for a node."""
    node = nodes[node_id]
    ignore_set = set(node.get("ignore", []))
    files = {k: v for k, v in node.get("files", {}).items() if k not in ignore_set}
    dir_names = sorted(k for k in node.get("dirs", {}) if k not in ignore_set)
    return [files, dir_names]


def compute(payload):
    """按扫描轮次生成映射，从每个完成目录的逻辑路径映射至 [保留文件映射,可见子目录名升序数组]。按轮累计替换节点。"""
    nodes = copy.deepcopy(payload["nodes"])
    mounts = payload["mounts"]
    scans = payload["scans"]
    results = []
    for scan in scans:
        # Apply replacements first
        replace = scan.get("replace", {})
        for nid, new_def in replace.items():
            nodes[nid] = copy.deepcopy(new_def)
        # Build snapshot for each finished path
        round_result = {}
        for fpath in scan["finish"]:
            node_id = _resolve_node(fpath, mounts, nodes)
            if node_id is not None:
                round_result[fpath] = _get_snapshot(node_id, nodes)
        results.append(round_result)
    return results
