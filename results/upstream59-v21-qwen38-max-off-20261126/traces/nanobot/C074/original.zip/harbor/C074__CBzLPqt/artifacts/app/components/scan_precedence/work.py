import copy


def compute(payload):
    """每轮返回完成的逻辑路径，按深度先父后子，同深度维持输入顺序。"""
    scans = payload["scans"]
    results = []
    for scan in scans:
        finish = scan["finish"]
        # Sort by depth (number of '/' separators), parent before child.
        # Same depth preserves input order (stable sort).
        ordered = sorted(finish, key=lambda p: p.count("/"))
        results.append(ordered)
    return results
