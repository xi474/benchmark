import copy


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left = directory_snapshots result: list of {logical_path: [files_map, sorted_dir_names]}
    right = scan_precedence result: list of [ordered_finished_paths]
    
    Returns list of {index, changed} per scan round.
    """
    initial = dict(payload.get("initial", {}))
    index = dict(initial)
    results = []

    for round_idx, scan in enumerate(payload["scans"]):
        snapshots = left[round_idx]  # {path: [files, dirs]}
        ordered_paths = right[round_idx]  # finished paths in precedence order

        old_index = dict(index)

        for fpath in ordered_paths:
            if fpath not in snapshots:
                continue
            files_map, visible_dirs = snapshots[fpath]
            prefix = fpath + "/"

            # Collect all current index entries directly under this path
            # Direct children are entries where the remainder after prefix has no '/'
            direct_entries = {}  # name -> track_id
            subtree_entries = {}  # full_path -> track_id (entries deeper than direct)
            for p, tid in list(index.items()):
                if p.startswith(prefix):
                    remainder = p[len(prefix):]
                    if "/" not in remainder:
                        direct_entries[remainder] = tid
                    else:
                        subtree_entries[p] = tid

            # Determine which direct names are currently visible (files or dirs)
            visible_files = set(files_map.keys())
            visible_dir_set = set(visible_dirs)
            all_visible = visible_files | visible_dir_set

            # Remove index entries for direct names that are no longer visible
            # (disappeared or ignored)
            for name in list(direct_entries.keys()):
                if name not in all_visible:
                    del index[prefix + name]

            # For direct names that were files but are now dirs (or vice versa),
            # clear the old entry
            for name in list(direct_entries.keys()):
                if name in visible_dir_set and name not in visible_files:
                    # Was a file, now a dir - remove old file entry
                    if prefix + name in index:
                        del index[prefix + name]
                elif name in visible_files and name not in visible_dir_set:
                    # Was potentially a dir with subtree entries - those should be cleared
                    pass  # handled below

            # Clear subtree entries under subdirs that are no longer visible
            for p in list(subtree_entries.keys()):
                remainder = p[len(prefix):]
                first_part = remainder.split("/")[0]
                if first_part not in visible_dir_set:
                    del index[p]

            # Add/update files from current snapshot
            for fname, tid in files_map.items():
                index[prefix + fname] = tid

        # Compute changed
        changed = {}
        all_paths = set(old_index.keys()) | set(index.keys())
        # Group by track id
        old_by_tid = {}
        for p, tid in old_index.items():
            old_by_tid.setdefault(tid, []).append(p)
        new_by_tid = {}
        for p, tid in index.items():
            new_by_tid.setdefault(tid, []).append(p)

        affected_tids = set(old_by_tid.keys()) | set(new_by_tid.keys())
        for tid in affected_tids:
            old_paths = sorted(old_by_tid.get(tid, []))
            new_paths = sorted(new_by_tid.get(tid, []))
            if old_paths != new_paths:
                changed[tid] = [old_paths, new_paths]

        results.append({"index": dict(index), "changed": changed})

    return results
