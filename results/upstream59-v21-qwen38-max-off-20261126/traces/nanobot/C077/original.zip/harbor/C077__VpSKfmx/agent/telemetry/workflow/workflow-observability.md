# Workflow 可观测性报告

- Trial：`C077__VpSKfmx__env`
- Task：`C077`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（65 节点 / 64 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：65；执行边：64（observed=0，inferred=64）
- Execution Trace Graph：`observed`；temporal_next 边 64，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_0affc34eff4d415caff59f33 -> tool:nanobot-harness-v3:call_4f1acec1b1a745d292c655e0 -> tool:nanobot-harness-v3:call_9f6b7268e79a4838abffb183 -> tool:nanobot-harness-v3:call_32111cef813343e4ba494df5 -> tool:nanobot-harness-v3:call_c4eacee4f97c4877a44832b0 -> tool:nanobot-harness-v3:call_f9bfcad2b4684aefafac3dbc -> tool:nanobot-harness-v3:call_664723528f1f472285a7f127 -> tool:nanobot-harness-v3:call_dd880e68738a4fe1b4b500e0 -> tool:nanobot-harness-v3:call_55c3d7830a22465cb4ce14b7 -> tool:nanobot-harness-v3:call_433cf318c7ed48038517ddd9 -> tool:nanobot-harness-v3:call_7cfd5e09e57949a180ab7ff0 -> tool:nanobot-harness-v3:call_8b7a8ee6cbb54fc99de32ec0 -> tool:nanobot-harness-v3:call_df95f209c77e42ee8295d5b8 -> tool:nanobot-harness-v3:call_4de8a6fb400946d69e668a27 -> tool:nanobot-harness-v3:call_c388104ccda34e5ebe9d231d -> tool:nanobot-harness-v3:call_20a12c18bb244b30ac2691ac -> tool:nanobot-harness-v3:call_70708a07400c4fccb284c3e7 -> tool:nanobot-harness-v3:call_7d654f1def6f452bb1c472cd -> tool:nanobot-harness-v3:call_c56bc1f700954d528b5c72a8 -> tool:nanobot-harness-v3:call_250f9094f3354e96ab54325a -> tool:nanobot-harness-v3:call_8745f758125b47ae95d9d958 -> tool:nanobot-harness-v3:call_f156e8f517404f348a3a9f0c -> tool:nanobot-harness-v3:call_6816b821a76b4cfb9960812e -> tool:nanobot-harness-v3:call_b1970541367b4b5196decc48 -> tool:nanobot-harness-v3:call_dbb947a9704c48b78e78790f -> tool:nanobot-harness-v3:call_3371bd9a7c4549ff83e9aa05 -> tool:nanobot-harness-v3:call_faae099d5c704c36832b0ffc -> tool:nanobot-harness-v3:call_a54da1fe55584d4bb92a412c -> tool:nanobot-harness-v3:call_44838900014c4af481e725d3 -> tool:nanobot-harness-v3:call_16e1e092f64e462790128844 -> tool:nanobot-harness-v3:call_afe921d0c0f44a0881ef0870 -> tool:nanobot-harness-v3:call_028085228b2a4f3ca322c717 -> tool:nanobot-harness-v3:call_74df715540b44af184222ca2 -> tool:nanobot-harness-v3:call_011f329821ef490c95aeb3a7 -> tool:nanobot-harness-v3:call_6bf3e3309c1d40e78be54369 -> tool:nanobot-harness-v3:call_ecf7b3601f284cc98a0c2716 -> tool:nanobot-harness-v3:call_9de203432cbd42af90d041ab -> tool:nanobot-harness-v3:call_8c7c2a7af5154c0da88941ee -> tool:nanobot-harness-v3:call_37e3beee677c4034b9f6fe87 -> tool:nanobot-harness-v3:call_666a8db7b2c5493a835aafbe -> tool:nanobot-harness-v3:call_1c5ea79bb2214ea280717d0d -> tool:nanobot-harness-v3:call_fee3d649ecbc4b49bbc9153e -> tool:nanobot-harness-v3:call_47f4afa899c240edbe5a0b2c -> tool:nanobot-harness-v3:call_17998845fc634aa5a7a8042f -> tool:nanobot-harness-v3:call_f1f3c18d0b3440b9af31637c -> tool:nanobot-harness-v3:call_0616a93ccfe0427a82a270dc -> tool:nanobot-harness-v3:call_b44a45fbf6a241059c2a5ee2 -> tool:nanobot-harness-v3:call_a3de405906f84c36a8b8720d -> tool:nanobot-harness-v3:call_8cc798d915b34c7182e7d69c -> tool:nanobot-harness-v3:call_f617844a0b1e4c7c8cc7f2f6 -> tool:nanobot-harness-v3:call_e441011b28564648b9f86e89 -> tool:nanobot-harness-v3:call_a26bd858b1584ce0ad4ed2de -> tool:nanobot-harness-v3:call_de52a990f25f4272af866008 -> tool:nanobot-harness-v3:call_457e2ca700514a5c81ddcc31 -> tool:nanobot-harness-v3:call_6ded5a1ed99b4dd59eb3c028 -> tool:nanobot-harness-v3:call_8ca7fcfcfb5e4f9f8ff1be87 -> tool:nanobot-harness-v3:call_023f2d76798949a5ba73efd7 -> tool:nanobot-harness-v3:call_df87363dfa664c7b8ff661f9 -> tool:nanobot-harness-v3:call_f306946b43f6413ab4e5a7c4 -> tool:nanobot-harness-v3:call_8595e9010a3f4b8c9a82dc8b -> tool:nanobot-harness-v3:call_d20bd4fd3bb34eb289e73af3 -> tool:nanobot-harness-v3:call_5473ca7789694ee0a243e5b2 -> tool:nanobot-harness-v3:call_8bd4c123350e474298bf7384 -> tool:nanobot-harness-v3:call_d363e35c2df84862abfff238
- 关键路径耗时：1.28765
- Makespan：235.083143
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
