def compute(payload):
    """对 start/finish 事件按输入位置给出处理后仍活动的修改 ID 有序列表。

    Returns a dict mapping event index (as string) to the ordered list of
    active modification IDs after processing that event.
    Only events that are start or finish operations produce entries.
    """
    events = payload.get("events", [])
    active = []  # ordered list of active modification IDs
    result = {}

    for idx, ev in enumerate(events):
        op = ev.get("op")
        if op == "start":
            mid = ev["id"]
            if mid not in active:
                active.append(mid)
        elif op == "finish":
            mid = ev["id"]
            if mid in active:
                active.remove(mid)
        # For every event, record the active list after processing
        # But per contract: only start/finish events produce entries
        if op in ("start", "finish"):
            result[str(idx)] = list(active)

    return result
