def compute(payload):
    """按 response 位置记录 [原因,到期时间]；失败优先于陈旧，延迟分别为 2000/1000，正常相应用 null。

    Returns a dict mapping response event index (as string) to:
      - null for successful responses (has items, not failed, not stale)
      - ["failure", time+2000] for failed responses
      - ["stale", time+1000] for stale=1 responses
    Failed takes priority over stale.
    """
    events = payload.get("events", [])
    result = {}

    for idx, ev in enumerate(events):
        op = ev.get("op")
        if op != "response":
            continue
        t = ev["time"]
        failed = ev.get("failed", False)
        stale = ev.get("stale", 0)
        has_items = "items" in ev

        if failed:
            result[str(idx)] = ["failure", t + 2000]
        elif stale == 1:
            result[str(idx)] = ["stale", t + 1000]
        else:
            # Successful response
            result[str(idx)] = None

    return result
