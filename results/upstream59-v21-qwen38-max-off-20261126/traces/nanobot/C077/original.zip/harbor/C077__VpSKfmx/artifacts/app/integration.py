def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = mutation_membership result: {event_idx_str: [active_ids...]}
    right = response_deadlines result:  {event_idx_str: [reason, deadline] | null}
    """
    events = payload.get("events", [])

    # --- Simulation state ---
    active = []          # ordered list of active modification IDs
    owed = False         # refresh obligation
    in_flight = None     # current fetch ID or None
    retry_at = None      # scheduled retry time or None
    items = []           # committed items
    fetch_counter = 0    # for generating fetch-N IDs

    fetches = []         # output: [{id, time}]
    commits = []         # output: [{time, items}]
    audit = []           # output: audit events

    def is_loading():
        return (in_flight is not None) or (retry_at is not None) or owed

    def do_fetch(t):
        """Issue a new fetch at time t. Returns the fetch id."""
        nonlocal fetch_counter, in_flight
        fetch_counter += 1
        fid = f"fetch-{fetch_counter}"
        in_flight = fid
        fetches.append({"id": fid, "time": t})
        audit.append({"time": t, "event": "fetch", "id": fid})
        return fid

    def try_fetch(t):
        """Attempt to issue a fetch if conditions allow."""
        nonlocal owed
        if len(active) > 0:
            # Modification in progress, cannot fetch
            return
        if in_flight is not None:
            # Already have a request in flight
            return
        if owed:
            owed = False
            do_fetch(t)

    # Build a timeline: collect timer events and external events
    # Timer events need to be interleaved with external events at the same time
    # "计时器在同刻外部事件之前触发" - timers fire before external events at same time

    # We'll process events one by one, but before each event we check if any
    # timer should fire first.

    # Collect all response deadlines from the right component
    # right maps event index (str) to [reason, deadline] or null
    response_info = {}  # idx -> (reason, deadline) or None
    for k, v in right.items():
        response_info[int(k)] = v

    # Process events
    for idx, ev in enumerate(events):
        op = ev.get("op")
        t = ev["time"]

        # Before processing this event, fire any pending timers that are <= t
        # Timers fire before external events at the same time
        while retry_at is not None and retry_at <= t:
            fire_time = retry_at
            retry_at = None
            # Clear old request mark
            in_flight = None
            # Attempt retry
            if len(active) > 0:
                # Modification still active, keep obligation
                owed = True
            else:
                # Retry fetch; also consumes any merged obligation
                owed = False
                do_fetch(fire_time)

        # Now process the external event
        if op == "start":
            mid = ev["id"]
            if mid not in active:
                active.append(mid)
            audit.append({"time": t, "event": "modification_started", "id": mid})

        elif op == "finish":
            mid = ev["id"]
            if mid in active:
                active.remove(mid)
            audit.append({"time": t, "event": "modification_finished", "id": mid})
            # Finish creates a refresh obligation
            owed = True
            # If no other fetch/timer pending, try to fetch now
            if retry_at is None and in_flight is None:
                try_fetch(t)

        elif op == "refresh":
            owed = True
            # If no fetch/timer pending, try to fetch
            if retry_at is None and in_flight is None:
                try_fetch(t)

        elif op == "response":
            fid = ev["id"]
            info = response_info.get(idx)

            if info is not None and info[0] == "failure":
                # Failed response
                reason, deadline = info
                in_flight = None  # clear the failed request
                retry_at = deadline
                audit.append({"time": t, "event": "retry_scheduled", "due": deadline, "reason": "failure"})

            elif info is not None and info[0] == "stale":
                # Stale response - keep in_flight until timer fires
                reason, deadline = info
                # in_flight stays as-is (the original request mark remains)
                retry_at = deadline
                audit.append({"time": t, "event": "retry_scheduled", "due": deadline, "reason": "stale"})

            else:
                # Successful response
                new_items = ev.get("items", [])
                items = list(new_items)  # commit items
                commits.append({"time": t, "items": list(new_items)})
                audit.append({"time": t, "event": "committed", "id": fid})
                in_flight = None  # clear completed request

                # If still owed and no blocking modification, fetch again
                if owed and len(active) == 0:
                    owed = False
                    do_fetch(t)

        elif op == "advance":
            # advance is a no-op for the simulation state
            pass

    # After all events, fire any remaining timers
    while retry_at is not None:
        fire_time = retry_at
        retry_at = None
        in_flight = None
        if len(active) > 0:
            owed = True
        else:
            owed = False
            do_fetch(fire_time)

    # Build final state
    state = {
        "active": sorted(active),
        "owed": owed,
        "loading": is_loading(),
        "placeholders": is_loading(),
        "in_flight": in_flight,
        "retry_at": retry_at,
        "items": items,
    }

    return {
        "fetches": fetches,
        "commits": commits,
        "events": audit,
        "state": state,
    }
