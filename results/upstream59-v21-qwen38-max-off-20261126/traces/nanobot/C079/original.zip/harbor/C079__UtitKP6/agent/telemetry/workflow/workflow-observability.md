# Workflow 可观测性报告

- Trial：`C079__UtitKP6__env`
- Task：`C079`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_e10e2bf40ee242f5851d3db6 -> tool:nanobot-harness-v3:call_2dfa7ba244c74257a3d03ac3 -> tool:nanobot-harness-v3:call_aab3cfacd9fc4f8895120c7d -> tool:nanobot-harness-v3:call_78c0640a38fe4e6e9dc8fb8d -> tool:nanobot-harness-v3:call_a3680781082048f3b7a6fae0 -> tool:nanobot-harness-v3:call_40ca59fcb2b7482fa807a90e -> tool:nanobot-harness-v3:call_4628dea6df864be784848b56 -> tool:nanobot-harness-v3:call_2889278a1cd74efa9aad9e10 -> tool:nanobot-harness-v3:call_e9604a34f90c4518b1db52fe -> tool:nanobot-harness-v3:call_98baf8815abc4ad8ac1fae4e -> tool:nanobot-harness-v3:call_d0b3de35a6584b2a8f11afde -> tool:nanobot-harness-v3:call_4a15e46082194de7ae2d7f23 -> tool:nanobot-harness-v3:call_836d0eb87ca24b78a04e1ebe -> tool:nanobot-harness-v3:call_36592cd31446476f89b217ad -> tool:nanobot-harness-v3:call_df67cc112b64420c9223ba1c -> tool:nanobot-harness-v3:call_3368422edd7947d99b6a4b7d -> tool:nanobot-harness-v3:call_b0cb9d301f794d01b6a1f93c -> tool:nanobot-harness-v3:call_584171f2111640e79bb983db -> tool:nanobot-harness-v3:call_f81054de94b9469ca9a7c534 -> tool:nanobot-harness-v3:call_d3855853f3eb4c729bcc56fd -> tool:nanobot-harness-v3:call_f3eab08d45a4447ba35972b2 -> tool:nanobot-harness-v3:call_2426dc913ddd4924a68635b7 -> tool:nanobot-harness-v3:call_0c084b7f0a694a29bc77677b -> tool:nanobot-harness-v3:call_0468841a40214c6696c6afab -> tool:nanobot-harness-v3:call_15c95cd31177428a8bcd9aad -> tool:nanobot-harness-v3:call_4c7db6b637f34481aa55abe6 -> tool:nanobot-harness-v3:call_05b8bcc9c5be43cc82f0a830 -> tool:nanobot-harness-v3:call_b0080b6aaa8c4cce858cac8f -> tool:nanobot-harness-v3:call_05c492f85cf743b3ad083338 -> tool:nanobot-harness-v3:call_d0a1c995e5d6448da61eb327 -> tool:nanobot-harness-v3:call_f08f0195bd354b669989a803 -> tool:nanobot-harness-v3:call_9234081801e24e9aa62dc372 -> tool:nanobot-harness-v3:call_ea79ebfc525944d396daf0bd -> tool:nanobot-harness-v3:call_54e034c32d3846f191f6a7e8 -> tool:nanobot-harness-v3:call_c905bc215a804013bf4afa82 -> tool:nanobot-harness-v3:call_dce7e4e165794e1ca507a50d -> tool:nanobot-harness-v3:call_04f4c3a0ef5f4547a4ed95af
- 关键路径耗时：0.301403
- Makespan：78.98558
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
