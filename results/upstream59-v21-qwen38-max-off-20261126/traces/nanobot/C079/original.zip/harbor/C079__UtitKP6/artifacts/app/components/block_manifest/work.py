def compute(payload):
    """返回 [kind,index,hex] 列表；若有缩略图则排首，再按块大小顺序切出文件块。"""
    file_hex = payload.get("file_hex", "")
    chunk_size = payload["chunk_size"]
    thumbnail_hex = payload.get("thumbnail_hex")

    blocks = []

    # Thumbnail first if present (even if empty)
    if thumbnail_hex is not None:
        blocks.append(["thumbnail", 0, thumbnail_hex])

    # Split file into chunks
    file_bytes_hex = file_hex
    offset = 0
    index = 0
    while offset < len(file_bytes_hex):
        chunk_hex = file_bytes_hex[offset:offset + chunk_size * 2]
        blocks.append(["file", index, chunk_hex])
        offset += chunk_size * 2
        index += 1

    return blocks
