def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = block_manifest result: list of [kind, index, hex]
    right = retry_faults result: dict mapping block label -> sorted list of corrupt attempt numbers
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    import hashlib

    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce = int.from_bytes(bytes.fromhex(payload["base_nonce_hex"]), "big")
    max_retries = payload.get("max_retries", 0)

    aesgcm = AESGCM(session_key)

    blocks_out = []
    attempts_out = []
    notifications_out = []
    failed_block = None

    # Track global attempt sequence number for nonce computation
    global_attempt_seq = 0

    # SHA256 hasher for file plaintext only (not thumbnail)
    file_sha = hashlib.sha256()

    for block_info in left:
        kind, index, data_hex = block_info
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(data_hex)
        aad = f"{kind}:{index}".encode("utf-8")

        # Determine which attempts are corrupted for this block
        corrupt_set = set(right.get(label, []))

        verified = False
        block_failed = False

        for attempt in range(1 + max_retries):
            # Compute nonce: base_nonce + global_attempt_seq, as 12-byte big-endian
            nonce_val = base_nonce + global_attempt_seq
            nonce_bytes = nonce_val.to_bytes(12, "big")
            global_attempt_seq += 1

            # Encrypt
            ciphertext_with_tag = aesgcm.encrypt(nonce_bytes, plaintext, aad)

            # Apply corruption if this attempt is in the corrupt set
            if attempt in corrupt_set:
                ct_bytes = bytearray(ciphertext_with_tag)
                # Flip the lowest bit of the last byte
                ct_bytes[-1] ^= 0x01
                ciphertext_with_tag = bytes(ct_bytes)

            # Verify by decrypting and comparing
            try:
                decrypted = aesgcm.decrypt(nonce_bytes, ciphertext_with_tag, aad)
                if decrypted == plaintext:
                    verified = True
                else:
                    verified = False
            except Exception:
                verified = False

            attempts_out.append({
                "block": label,
                "attempt": attempt,
                "verified": verified
            })

            if verified:
                # Publish this block
                blocks_out.append({
                    "kind": kind,
                    "index": index,
                    "nonce_hex": nonce_bytes.hex(),
                    "ciphertext_hex": ciphertext_with_tag.hex(),
                    "plaintext_sha256": hashlib.sha256(plaintext).hexdigest()
                })
                # Update file SHA256 only for file blocks
                if kind == "file":
                    file_sha.update(plaintext)
                break
            else:
                # Only first failure generates notification
                if attempt == 0:
                    notifications_out.append({
                        "block": label,
                        "error": "verification_failed"
                    })

        if not verified:
            failed_block = label
            break

    status = "ok" if failed_block is None else "verification_failed"

    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks_out,
        "attempts": attempts_out,
        "notifications": notifications_out,
        "file_sha256": file_sha.hexdigest()
    }
