# Workflow 可观测性报告

- Trial：`MP01__nk3ymJV__env`
- Task：`MP01`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（76 节点 / 75 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：76；执行边：75（observed=0，inferred=75）
- Execution Trace Graph：`observed`；temporal_next 边 75，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_ae85b89390c642d194acfa37 -> tool:nanobot-harness-v3:call_eabe204ae0db4a2e9b3db17b -> tool:nanobot-harness-v3:call_771a50dcade042a58f64c10a -> tool:nanobot-harness-v3:call_b3323b4faa0341669099fd22 -> tool:nanobot-harness-v3:call_6c008b12ec03456b9a54ae12 -> tool:nanobot-harness-v3:call_6edde66cc9784194920885d3 -> tool:nanobot-harness-v3:call_4a63d8c65dd4402490935297 -> tool:nanobot-harness-v3:call_88693bf9ef2a4a66b660b303 -> tool:nanobot-harness-v3:call_82c360a6dcd24299926e0e94 -> tool:nanobot-harness-v3:call_66902f00e3d44c729b3bca61 -> tool:nanobot-harness-v3:call_e58d8a310b2f4948b201d670 -> tool:nanobot-harness-v3:call_b0e23f94ed3b4eb797582feb -> tool:nanobot-harness-v3:call_f08af824fb244a65879fd7d5 -> tool:nanobot-harness-v3:call_ff55c0ddc6bf49f58372ca62 -> tool:nanobot-harness-v3:call_39797cf985fa4621a44aa5ff -> tool:nanobot-harness-v3:call_42b90d1aaf8a4c13a366c049 -> tool:nanobot-harness-v3:call_56ff4bbf71fa490fb7cf9416 -> tool:nanobot-harness-v3:call_ce766adc8cca47df9ecf883e -> tool:nanobot-harness-v3:call_d95b10057dea4057a2a2ad91 -> tool:nanobot-harness-v3:call_5c7fc0a481944412aa2100b9 -> tool:nanobot-harness-v3:call_7ff576520fee4ca2b77494bf -> tool:nanobot-harness-v3:call_8be5395ac39e4c6cabc3e61f -> tool:nanobot-harness-v3:call_3cabcd07ee7a4b95b08ec500 -> tool:nanobot-harness-v3:call_369fd80c94c749e88f5e66ed -> tool:nanobot-harness-v3:call_cf8014a0dfa141dba129317c -> tool:nanobot-harness-v3:call_cfe57bcd5fad4f199f8b756f -> tool:nanobot-harness-v3:call_15f05b6bbd7e4b8998a84146 -> tool:nanobot-harness-v3:call_f4deded253704e07bb28966a -> tool:nanobot-harness-v3:call_ff0a9d13e2244eea8f5bfeb1 -> tool:nanobot-harness-v3:call_26229cc0df414964af0e3f2e -> tool:nanobot-harness-v3:call_aeb29a4dad614e0887346195 -> tool:nanobot-harness-v3:call_b73ce3c2d45348eba739ee77 -> tool:nanobot-harness-v3:call_6eacae61e74a42e3a72d7943 -> tool:nanobot-harness-v3:call_206370ffda7547c4a46c8fba -> tool:nanobot-harness-v3:call_d61c76eaa68449d6b524eb30 -> tool:nanobot-harness-v3:call_c5aa65351f034a17b8593f6b -> tool:nanobot-harness-v3:call_8734e101a1b04451809501da -> tool:nanobot-harness-v3:call_dfd72ebadd484e9c92073b2d -> tool:nanobot-harness-v3:call_e146e3bbaf6f464788935cdc -> tool:nanobot-harness-v3:call_37c67c18c0564732af321658 -> tool:nanobot-harness-v3:call_7620bf98bba4450ebf8a794d -> tool:nanobot-harness-v3:call_15f45b317cfc41b9a110204f -> tool:nanobot-harness-v3:call_3d4afccacfb54ec1bc561758 -> tool:nanobot-harness-v3:call_82b85d54ca20447bb8f25e9a -> tool:nanobot-harness-v3:call_a31f0b6b2f6e47e28993e3e8 -> tool:nanobot-harness-v3:call_6b3ff6dc69034440bf9bbdcf -> tool:nanobot-harness-v3:call_b1a0c81779194ab185b05cab -> tool:nanobot-harness-v3:call_80e749b4f7e741c7805d8297 -> tool:nanobot-harness-v3:call_be794b0df4b0461c944cef1d -> tool:nanobot-harness-v3:call_12618da9077b455e96a816b7 -> tool:nanobot-harness-v3:call_d96dbf5982c94c73bfb9f41a -> tool:nanobot-harness-v3:call_ceb5a245a3464671b334b112 -> tool:nanobot-harness-v3:call_d1e4d38793a44660bff9e9d8 -> tool:nanobot-harness-v3:call_fd76bc0a35fb46d2b1215897 -> tool:nanobot-harness-v3:call_9b50481007f7449e9c525488 -> tool:nanobot-harness-v3:call_d7649ecb35e14737926cda0e -> tool:nanobot-harness-v3:call_82e65ea4dc9a476f95f0e2f0 -> tool:nanobot-harness-v3:call_58b7ee4995704da98dddfaff -> tool:nanobot-harness-v3:call_31e4863c45f346e3811f85d7 -> tool:nanobot-harness-v3:call_d130b52630c24accb93168ce -> tool:nanobot-harness-v3:call_81c71a12d236498884d31476 -> tool:nanobot-harness-v3:call_91eef126d18345a591f9440d -> tool:nanobot-harness-v3:call_c40f94868fb643769cc708a0 -> tool:nanobot-harness-v3:call_81495e9bacb74a05abeff9a7 -> tool:nanobot-harness-v3:call_a765a8da0147497e87667a33 -> tool:nanobot-harness-v3:call_78195a5ba2044bec9c1d0ae3 -> tool:nanobot-harness-v3:call_4d012f619cab4992878144e5 -> tool:nanobot-harness-v3:call_66f9b2a4bb2747419f8ec207 -> tool:nanobot-harness-v3:call_5e83ec1a1dcb479787adef2d -> tool:nanobot-harness-v3:call_25300054b8b94276ae6d6907 -> tool:nanobot-harness-v3:call_9259e23a025d466caeda99d6 -> tool:nanobot-harness-v3:call_2386fdef1bcd471fb337b10c -> tool:nanobot-harness-v3:call_54f5c152b66e4eed852888ec -> tool:nanobot-harness-v3:call_ad487c2400954c10a3fbbad8 -> tool:nanobot-harness-v3:call_9153ccca5a5443b996c7e551
- 关键路径耗时：1.323044
- Makespan：335.298939
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
