import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)

    # Load contract
    from model import load_payload
    contract = load_payload(contract_path)

    # Load input payloads in contract.inputs order
    payloads = [load_payload(root / p) for p in contract["inputs"]]

    # Import transform from the same directory as contract
    comp_dir = contract_path.parent
    sys.path.insert(0, str(comp_dir))
    try:
        import importlib
        transform_mod = importlib.import_module("transform")
        result = transform_mod.transform(payloads, contract)
    finally:
        sys.path.pop(0)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    return result


if __name__ == "__main__":
    # Determine workspace root: go up from this script's directory to find README.md
    here = Path(__file__).resolve().parent
    # The component dir is here; workspace root is two levels up for domains/fit
    # But we need to handle arbitrary cwd. Use contract.json location.
    contract_path = here / "contract.json"
    if not contract_path.exists():
        print("ERROR: contract.json not found", file=sys.stderr)
        sys.exit(1)

    # Find root by looking for README.md going upward
    root = here
    while root != root.parent:
        if (root / "README.md").exists() and (root / "inputs").exists():
            break
        root = root.parent
    else:
        # Fallback: use cwd
        root = Path.cwd()

    try:
        build_component(root, contract_path)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
