import copy
import math


def _is_finite_number(v):
    """Check v is a finite number (int or float), not bool."""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return math.isfinite(v)
    return False


def _is_non_negative_number(v):
    return _is_finite_number(v) and v >= 0


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    # Validate required fields
    for field in ("classes", "sample_weight", "members"):
        if field not in data:
            raise ValueError(f"missing field: {field}")

    classes = data["classes"]
    sample_weight = data["sample_weight"]
    members = data["members"]

    # classes: list of unique non-empty strings
    if not isinstance(classes, list):
        raise ValueError("classes must be list")
    if len(classes) == 0:
        raise ValueError("classes must be non-empty")
    seen_classes = set()
    for c in classes:
        if not isinstance(c, str) or not c.strip():
            raise ValueError("class must be non-empty string")
        if c in seen_classes:
            raise ValueError(f"duplicate class: {c}")
        seen_classes.add(c)

    global_classes = list(classes)
    global_class_set = set(global_classes)

    # sample_weight: list of non-negative numbers
    if not isinstance(sample_weight, list):
        raise ValueError("sample_weight must be list")
    sample_count = len(sample_weight)
    for sw in sample_weight:
        if not _is_non_negative_number(sw):
            raise ValueError("sample_weight entries must be non-negative numbers")

    # members: list of member objects
    if not isinstance(members, list):
        raise ValueError("members must be list")

    seen_ids = set()
    active_members = []

    for m in members:
        if not isinstance(m, dict):
            raise ValueError("member must be object")
        if "id" not in m:
            raise ValueError("member missing id")
        if "active" not in m:
            raise ValueError("member missing active")

        mid = m["id"]
        active = m["active"]

        if not isinstance(active, bool):
            raise ValueError("active must be bool")

        if mid in seen_ids:
            raise ValueError(f"duplicate member id: {mid}")
        seen_ids.add(mid)

        if not active:
            # Inactive: only validate id and active
            continue

        # Active member: validate all fields
        if "weight" not in m:
            raise ValueError("active member missing weight")
        if "predictions" not in m:
            raise ValueError("active member missing predictions")
        if "classes" not in m:
            raise ValueError("active member missing classes")
        if "probabilities" not in m:
            raise ValueError("active member missing probabilities")

        w = m["weight"]
        if not _is_non_negative_number(w):
            raise ValueError("member weight must be non-negative number")

        preds = m["predictions"]
        if not isinstance(preds, list):
            raise ValueError("predictions must be list")
        if len(preds) != sample_count:
            raise ValueError("predictions length must equal sample count")
        for p in preds:
            if not isinstance(p, str):
                raise ValueError("prediction must be string")
            if p not in global_class_set:
                raise ValueError(f"prediction '{p}' not in global classes")

        m_classes = m["classes"]
        if not isinstance(m_classes, list):
            raise ValueError("member classes must be list")
        if set(m_classes) != global_class_set:
            raise ValueError("member classes must be a permutation of global classes")
        if len(m_classes) != len(global_classes):
            raise ValueError("member classes must be a permutation of global classes")
        mc_seen = set()
        for mc in m_classes:
            if mc in mc_seen:
                raise ValueError("duplicate in member classes")
            mc_seen.add(mc)

        probs = m["probabilities"]
        if not isinstance(probs, list):
            raise ValueError("probabilities must be list")
        if len(probs) != sample_count:
            raise ValueError("probabilities rows must equal sample count")
        n_classes = len(global_classes)
        for row in probs:
            if not isinstance(row, list):
                raise ValueError("probability row must be list")
            if len(row) != len(m_classes):
                raise ValueError("probability row length must match member classes")
            row_sum = 0.0
            for val in row:
                if not _is_finite_number(val):
                    raise ValueError("probability must be finite number")
                if val < 0:
                    raise ValueError("probability must be >= 0")
                row_sum += val
            if abs(row_sum - 1.0) > 1e-9:
                raise ValueError("probability row must sum to 1")

        active_members.append(m)

    if len(active_members) == 0:
        raise ValueError("at least one active member required")

    total_weight = sum(m["weight"] for m in active_members)
    if total_weight <= 0:
        raise ValueError("active member weight sum must be > 0")

    # Build result: deep copy active members, add fit_weight = sample_weight
    result_members = []
    for m in active_members:
        mc = copy.deepcopy(m)
        mc["fit_weight"] = list(sample_weight)
        result_members.append(mc)

    result = {
        "classes": list(global_classes),
        "sample_count": sample_count,
        "members": result_members,
    }

    return {"name": contract["name"], "result": result}
