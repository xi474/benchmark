"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    if not core_path.exists():
        raise FileNotFoundError("core_manifest.json not found")

    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core["components"]

    # SHA256 of the complete core object
    canonical = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    sha = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    # Attention: components with specific conditions
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != "" and val != {}:
                if isinstance(val, (list, str, dict)) and len(val) > 0:
                    attention.add(name)

    report = {
        "title": "可关闭成员的硬/软加权投票",
        "component_count": len(components),
        "sha256": sha,
        "attention": sorted(attention),
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
