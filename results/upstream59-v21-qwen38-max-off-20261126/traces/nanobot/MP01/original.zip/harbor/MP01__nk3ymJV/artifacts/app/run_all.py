"""Orchestrate all components based on contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable if sys.executable else "python3"


def find_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def topo_sort(contracts):
    """Topological sort based on input dependencies."""
    # Map output paths to contract paths
    output_to_contract = {}
    contract_map = {}
    for cp in contracts:
        c = load_contract(cp)
        contract_map[cp] = c
        output_to_contract[c["output"]] = cp

    # Build dependency graph
    deps = {}
    for cp in contracts:
        c = contract_map[cp]
        dep_set = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep_set.add(output_to_contract[inp])
        deps[cp] = dep_set

    # Kahn's algorithm
    in_degree = {cp: 0 for cp in contracts}
    for cp, dep_set in deps.items():
        for d in dep_set:
            pass  # d depends on nothing from cp perspective
    # Actually: if cp depends on d, then d must come before cp
    # in_degree[cp] = number of deps cp has that are in our contract set
    for cp in contracts:
        in_degree[cp] = len(deps[cp])

    queue = [cp for cp in contracts if in_degree[cp] == 0]
    queue.sort()  # deterministic
    result = []

    while queue:
        cp = queue.pop(0)
        result.append(cp)
        # Find all contracts that depend on cp
        for other in contracts:
            if cp in deps[other]:
                deps[other].discard(cp)
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)
        queue.sort()

    if len(result) != len(contracts):
        raise ValueError("dependency cycle detected")

    return result


def main():
    contracts = find_contracts()
    if not contracts:
        print("ERROR: no contracts found", file=sys.stderr)
        sys.exit(1)

    ordered = topo_sort(contracts)

    for cp in ordered:
        render_py = cp.parent / "render.py"
        if not render_py.exists():
            print(f"ERROR: {render_py} not found", file=sys.stderr)
            sys.exit(1)

        proc = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=str(ROOT),
            timeout=60,
        )
        if proc.returncode != 0:
            print(f"ERROR: {render_py} failed with code {proc.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        proc = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=str(ROOT),
            timeout=60,
        )
        if proc.returncode != 0:
            print(f"ERROR: integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.exists():
        proc = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=str(ROOT),
            timeout=60,
        )
        if proc.returncode != 0:
            print(f"ERROR: final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
