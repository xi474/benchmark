import copy


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    fit_result = payloads[0]

    # When input has name/result keys, extract result
    if isinstance(fit_result, dict) and set(fit_result.keys()) == {"name", "result"}:
        fit_result = fit_result["result"]

    classes = fit_result["classes"]
    members = fit_result["members"]
    sample_count = fit_result["sample_count"]

    n_classes = len(classes)
    class_index = {c: i for i, c in enumerate(classes)}

    # Initialize scores: [sample][class] = 0
    scores = [[0.0] * n_classes for _ in range(sample_count)]

    for m in members:
        w = m["weight"]
        preds = m["predictions"]
        for s in range(sample_count):
            cls = preds[s]
            idx = class_index[cls]
            scores[s][idx] += w

    # Predictions: argmax per sample, tie-break by global class order (first)
    predictions = []
    for s in range(sample_count):
        best_idx = 0
        best_val = scores[s][0]
        for i in range(1, n_classes):
            if scores[s][i] > best_val:
                best_val = scores[s][i]
                best_idx = i
        predictions.append(classes[best_idx])

    return {
        "name": contract["name"],
        "result": {
            "predictions": predictions,
            "scores": scores,
        },
    }
