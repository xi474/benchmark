import copy


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    fit_result = payloads[0]

    # When input has name/result keys, extract result
    if isinstance(fit_result, dict) and set(fit_result.keys()) == {"name", "result"}:
        fit_result = fit_result["result"]

    classes = fit_result["classes"]
    members = fit_result["members"]
    sample_count = fit_result["sample_count"]

    n_classes = len(classes)
    global_class_index = {c: i for i, c in enumerate(classes)}

    # Weighted average of probabilities mapped to global class order
    total_weight = 0.0
    avg_probs = [[0.0] * n_classes for _ in range(sample_count)]

    for m in members:
        w = m["weight"]
        m_classes = m["classes"]
        probs = m["probabilities"]

        # Build mapping from member class index to global class index
        m_to_global = [global_class_index[c] for c in m_classes]

        for s in range(sample_count):
            row = probs[s]
            for j, val in enumerate(row):
                g_idx = m_to_global[j]
                avg_probs[s][g_idx] += w * val

        total_weight += w

    # Normalize by total weight
    if total_weight > 0:
        for s in range(sample_count):
            for i in range(n_classes):
                avg_probs[s][i] /= total_weight

    # Predictions: argmax per sample, tie-break by global class order (first)
    predictions = []
    for s in range(sample_count):
        best_idx = 0
        best_val = avg_probs[s][0]
        for i in range(1, n_classes):
            if avg_probs[s][i] > best_val:
                best_val = avg_probs[s][i]
                best_idx = i
        predictions.append(classes[best_idx])

    return {
        "name": contract["name"],
        "result": {
            "predictions": predictions,
            "probabilities": avg_probs,
        },
    }
