# Workflow 可观测性报告

- Trial：`MP02__dS7m2cT__env`
- Task：`MP02`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（98 节点 / 97 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：98；执行边：97（observed=0，inferred=97）
- Execution Trace Graph：`observed`；temporal_next 边 97，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f1427a814c5a47639dc262cf -> tool:nanobot-harness-v3:call_5bbc3ba6b25047a48546547e -> tool:nanobot-harness-v3:call_cfc5201c7fcc47159691dba5 -> tool:nanobot-harness-v3:call_db3c5bada253432081eb2dca -> tool:nanobot-harness-v3:call_61e9915df2ce40bfb5fe238f -> tool:nanobot-harness-v3:call_2c9cfbb290554c70a8c3954d -> tool:nanobot-harness-v3:call_23929747dcaa4fa290c9294f -> tool:nanobot-harness-v3:call_ab0061b31ca64c06b88e04f6 -> tool:nanobot-harness-v3:call_57b87665b858423fabba0976 -> tool:nanobot-harness-v3:call_e1ed438420514e33b6183d03 -> tool:nanobot-harness-v3:call_62ef666423134a3f9096233b -> tool:nanobot-harness-v3:call_3980315c5c2247ff8acde6d5 -> tool:nanobot-harness-v3:call_53d6174b910c497fa3a5d71d -> tool:nanobot-harness-v3:call_b8cefc1820644b7c82d5c677 -> tool:nanobot-harness-v3:call_388090ba60a54676b8077e9f -> tool:nanobot-harness-v3:call_09d7317463f3416eb8345cf0 -> tool:nanobot-harness-v3:call_20a957720df749f69f66b77e -> tool:nanobot-harness-v3:call_1920b60b0500474584797b96 -> tool:nanobot-harness-v3:call_f6fc9c978b294da9b9c7933f -> tool:nanobot-harness-v3:call_1f96842ad347490987e0da75 -> tool:nanobot-harness-v3:call_1b2de4902e7244b59ad95c2e -> tool:nanobot-harness-v3:call_7a2017255cea4b43be9c7b4c -> tool:nanobot-harness-v3:call_8408ff7c17b24a898fff7cbb -> tool:nanobot-harness-v3:call_0337cdfd89b44251aa90cd42 -> tool:nanobot-harness-v3:call_8acb5bce1f4f496da5ed149e -> tool:nanobot-harness-v3:call_4f9aa223c293478bb6c2485f -> tool:nanobot-harness-v3:call_3f971b886a164e8cb612ef5d -> tool:nanobot-harness-v3:call_dde1d9a4297b4a04af8982bf -> tool:nanobot-harness-v3:call_721e5462d2c04372930aa719 -> tool:nanobot-harness-v3:call_d2bb1fae8a2645fe80ac82f8 -> tool:nanobot-harness-v3:call_8d08241427ef4d1f8dae4d7a -> tool:nanobot-harness-v3:call_1381b4ea66064dce818a2cf0 -> tool:nanobot-harness-v3:call_323ae40d68da4de1bba999b7 -> tool:nanobot-harness-v3:call_d00be3a646bb483cbf894eb8 -> tool:nanobot-harness-v3:call_5557516d0e1b43a49737fa5d -> tool:nanobot-harness-v3:call_c08eafeec5bb4b48bacf981f -> tool:nanobot-harness-v3:call_472cca44ff524565918aa18d -> tool:nanobot-harness-v3:call_804fb8a0ebe14342ae716a56 -> tool:nanobot-harness-v3:call_be23536feee84d95a90ddae2 -> tool:nanobot-harness-v3:call_15d6237177a04044aea33129 -> tool:nanobot-harness-v3:call_e6336851c8e0482ab85d723b -> tool:nanobot-harness-v3:call_ab142dd43df3451fba95dcba -> tool:nanobot-harness-v3:call_03ffe8e9677f48cebd58132a -> tool:nanobot-harness-v3:call_72e40bda70b046b691f65746 -> tool:nanobot-harness-v3:call_e51bbc96da1b4ccf93456699 -> tool:nanobot-harness-v3:call_ecf61c8c9fbc452f8dd110d1 -> tool:nanobot-harness-v3:call_37c73d8d6e2c49518da2825c -> tool:nanobot-harness-v3:call_cc8b7cbf0780417893d6b6cb -> tool:nanobot-harness-v3:call_71021259559045a5a54f8b97 -> tool:nanobot-harness-v3:call_799692b8e141425c831259ce -> tool:nanobot-harness-v3:call_b6ef028fa9da40e58468586d -> tool:nanobot-harness-v3:call_2b23d95587694706a8191fb1 -> tool:nanobot-harness-v3:call_4832fc1ca1cf46ba8d275b3a -> tool:nanobot-harness-v3:call_169c7777dde34540b189a0ff -> tool:nanobot-harness-v3:call_3b0d5bed65f14a58b8148068 -> tool:nanobot-harness-v3:call_d06a39953ec74d69a7cdefdf -> tool:nanobot-harness-v3:call_6031f36286864c2abed114b7 -> tool:nanobot-harness-v3:call_0631c3ae3b6541d2846fd83c -> tool:nanobot-harness-v3:call_9691825452224d7ea417ca5b -> tool:nanobot-harness-v3:call_247aa6778c4a442da7bf3469 -> tool:nanobot-harness-v3:call_a5b81569d1aa4478b5d6bf47 -> tool:nanobot-harness-v3:call_34d5a68308914c4fac89118e -> tool:nanobot-harness-v3:call_c2e4ca745b934359813fd7bf -> tool:nanobot-harness-v3:call_446f1377ad8141c39bafdab0 -> tool:nanobot-harness-v3:call_ff4a6b3cb12946228bc14496 -> tool:nanobot-harness-v3:call_2d217ed1e9754e6d89a8c5b4 -> tool:nanobot-harness-v3:call_99a19a54d4694a05bb7a7504 -> tool:nanobot-harness-v3:call_a21acfddb35541babba588ff -> tool:nanobot-harness-v3:call_0f3ec84f7fa949ea9fc296b4 -> tool:nanobot-harness-v3:call_bbaab0c4818c41919ad70e5a -> tool:nanobot-harness-v3:call_544f31c03a074a3a92181418 -> tool:nanobot-harness-v3:call_f8afeb8bded84a29804cf6b0 -> tool:nanobot-harness-v3:call_8fb2345fe86341d7a1b7c7a3 -> tool:nanobot-harness-v3:call_1059df1114474a00bd2fe351 -> tool:nanobot-harness-v3:call_92785b55e3864aef80bd6a5c -> tool:nanobot-harness-v3:call_c36ff5b3e8754ecfa4f1f958 -> tool:nanobot-harness-v3:call_f43dbdc010814fbf8a8b6ee1 -> tool:nanobot-harness-v3:call_1f0539249df74e699f9793c7 -> tool:nanobot-harness-v3:call_d03e6d95c8b9490c8cf9c87a -> tool:nanobot-harness-v3:call_42b00869f73749c7a3348fa4 -> tool:nanobot-harness-v3:call_38f0bd6b40184e66bc98f610 -> tool:nanobot-harness-v3:call_f2d4bb6df42f48d2855a2f7a -> tool:nanobot-harness-v3:call_46d87d40b7dd46fa840af187 -> tool:nanobot-harness-v3:call_44490829a10a404fa858b548 -> tool:nanobot-harness-v3:call_d8969c9c5cb44ac28ac106a2 -> tool:nanobot-harness-v3:call_a1280e8effeb4d6e8e449d44 -> tool:nanobot-harness-v3:call_c2ec9446123f4862b7b73718 -> tool:nanobot-harness-v3:call_a4c3ab2411234366822286ce -> tool:nanobot-harness-v3:call_eff50e556c3341d2ab0dcc80 -> tool:nanobot-harness-v3:call_e71678f4729a4ec3aa041eb7 -> tool:nanobot-harness-v3:call_4214b6130f974d3bbf15a2c0 -> tool:nanobot-harness-v3:call_cb24080278b74c589bae3a6d -> tool:nanobot-harness-v3:call_117b13499ace46969fbc66e1 -> tool:nanobot-harness-v3:call_445aa89bebd440ebb712dbc8 -> tool:nanobot-harness-v3:call_a26f2017f0364511ace1c5fe -> tool:nanobot-harness-v3:call_a4e96a8c0a924f4682c935e1 -> tool:nanobot-harness-v3:call_57df44429e694c6aaf432b58
- 关键路径耗时：1.055092
- Makespan：390.041056
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
