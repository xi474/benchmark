import json
import sys
from pathlib import Path

# Ensure we can import sibling modules
_dir = Path(__file__).resolve().parent
if str(_dir) not in sys.path:
    sys.path.insert(0, str(_dir))

from model import load_payload
from transform import transform


def _write_json(path, data):
    """Write JSON with standard formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    path.write_text(text + '\n', encoding='utf-8')


def build_component(root, contract_path):
    """Read inputs per contract, run transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    return result


if __name__ == "__main__":
    # When run as script, write output to contract.output
    contract_path = Path(__file__).resolve().with_name('contract.json')
    root = Path(__file__).resolve().parents[2]
    result = build_component(root, contract_path)
    contract = load_payload(contract_path)
    out_path = root / contract['output']
    _write_json(out_path, result)
