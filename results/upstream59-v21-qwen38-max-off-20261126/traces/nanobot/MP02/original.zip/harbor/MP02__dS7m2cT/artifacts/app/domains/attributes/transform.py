import json


def _deep_equal(a, b):
    """JSON deep equality comparison."""
    return json.dumps(a, sort_keys=True, ensure_ascii=False) == json.dumps(b, sort_keys=True, ensure_ascii=False)


def transform(payloads, contract):
    """segment_attributes: merge piece attributes according to policy."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("Input must be an object")

    for field in ('columns', 'pieces', 'attribute_policy'):
        if field not in inp:
            raise ValueError(f"Missing required field: {field}")

    pieces = inp['pieces']
    attribute_policy = inp['attribute_policy']

    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if attribute_policy not in ('drop_conflicts', 'first'):
        raise ValueError(f"Invalid attribute_policy: {attribute_policy}")

    # Collect all keys and their values per piece (in original order)
    # key -> list of values from pieces that have this key
    key_values = {}  # key -> [(piece_index, value)]
    for pi, piece in enumerate(pieces):
        if not isinstance(piece, dict):
            raise ValueError("Each piece must be an object")
        if 'attrs' not in piece:
            raise ValueError("Piece missing attrs")
        attrs = piece['attrs']
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be an object")
        for k, v in attrs.items():
            if k not in key_values:
                key_values[k] = []
            key_values[k].append((pi, v))

    merged = {}
    conflicts = []

    if attribute_policy == 'first':
        # For each key, pick the value from the first piece (in original order) that has it
        for k, vals in key_values.items():
            # vals are already in piece order since we iterate pieces in order
            merged[k] = vals[0][1]
            # Check if there are conflicting values
            first_val = vals[0][1]
            has_conflict = False
            for _, v in vals[1:]:
                if not _deep_equal(first_val, v):
                    has_conflict = True
                    break
            if has_conflict:
                conflicts.append(k)
    elif attribute_policy == 'drop_conflicts':
        # Only keep keys where all present values are the same
        for k, vals in key_values.items():
            first_val = vals[0][1]
            all_same = True
            for _, v in vals[1:]:
                if not _deep_equal(first_val, v):
                    all_same = False
                    break
            if all_same:
                merged[k] = first_val
            else:
                conflicts.append(k)

    conflicts.sort()

    result = {
        "attrs": merged,
        "conflicts": conflicts
    }

    return {"name": contract["name"], "result": result}
