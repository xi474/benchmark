def _is_finite_number(v):
    """Check if v is a finite number (int or float, not bool)."""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        import math
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    """segment_index: build coordinate-sorted order from pieces."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("Input must be an object")

    # Validate required fields
    for field in ('columns', 'pieces', 'attribute_policy'):
        if field not in inp:
            raise ValueError(f"Missing required field: {field}")

    columns = inp['columns']
    pieces = inp['pieces']
    attribute_policy = inp['attribute_policy']

    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if attribute_policy not in ('drop_conflicts', 'first'):
        raise ValueError(f"Invalid attribute_policy: {attribute_policy}")

    # Validate column names are unique strings
    col_names = []
    for c in columns:
        if not isinstance(c, str):
            raise ValueError("Column names must be strings")
        if c in col_names:
            raise ValueError(f"Duplicate column name: {c}")
        col_names.append(c)

    # Validate pieces
    seen_ids = set()
    all_coords = set()
    entries = []  # (coordinate, piece_id, row_index)

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("Each piece must be an object")
        for field in ('id', 'coordinates', 'data', 'attrs'):
            if field not in piece:
                raise ValueError(f"Piece missing required field: {field}")

        pid = piece['id']
        if not isinstance(pid, str):
            raise ValueError("Piece id must be string")
        if pid in seen_ids:
            raise ValueError(f"Duplicate piece id: {pid}")
        seen_ids.add(pid)

        coords = piece['coordinates']
        data = piece['data']
        attrs = piece['attrs']

        if not isinstance(coords, list):
            raise ValueError("coordinates must be a list")
        if not isinstance(data, list):
            raise ValueError("data must be a list")
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be an object")

        if len(coords) != len(data):
            raise ValueError(f"Piece {pid}: coordinates length != data length")

        # Check coordinate uniqueness across all pieces
        for coord in coords:
            if not _is_finite_number(coord):
                raise ValueError(f"Non-finite coordinate in piece {pid}")
            if coord in all_coords:
                raise ValueError(f"Duplicate coordinate {coord} across pieces")
            all_coords.add(coord)

        # Validate data rows
        for i, row in enumerate(data):
            if not isinstance(row, list):
                raise ValueError(f"Data row must be a list")
            if len(row) != len(columns):
                raise ValueError(f"Row width {len(row)} != columns length {len(columns)}")
            for val in row:
                if not _is_finite_number(val):
                    raise ValueError(f"Non-finite data value in piece {pid}")

        for i, coord in enumerate(coords):
            entries.append((coord, pid, i))

    # Sort by coordinate ascending
    entries.sort(key=lambda e: e[0])

    order = [{"coordinate": e[0], "piece": e[1], "row": e[2]} for e in entries]

    result = {
        "columns": columns,
        "order": order
    }

    return {"name": contract["name"], "result": result}
