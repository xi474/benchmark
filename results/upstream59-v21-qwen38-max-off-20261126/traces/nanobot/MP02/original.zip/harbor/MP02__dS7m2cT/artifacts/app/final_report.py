import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core['components']

    # Compute sha256 of the full core object
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # Check blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # Check complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                # Non-empty check: for lists/dicts/strings, check truthiness
                # But we need to be careful: 0 and null don't count
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    # numeric non-zero counts as non-empty? 
                    # The spec says "non-empty" which typically applies to collections
                    # Let's be conservative: only list/dict/str
                    pass

    attention_sorted = sorted(attention)

    report = {
        "title": "\u5355\u53d8\u5316\u8f74\u7684\u6570\u636e\u5206\u7247\u62fc\u63a5",
        "component_count": len(components),
        "sha256": sha256,
        "attention": attention_sorted
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
