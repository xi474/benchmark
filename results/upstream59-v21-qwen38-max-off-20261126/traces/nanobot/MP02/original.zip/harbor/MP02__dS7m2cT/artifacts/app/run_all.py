import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Handle environments where sys.executable is empty
import shutil
PYTHON = sys.executable or shutil.which('python3') or 'python3'


def main():
    """Discover all contract.json files, resolve dependencies, execute in order."""
    # Find all contract.json files (excluding outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: contract -> set of contracts it depends on
    # A contract depends on another if any of its inputs references that contract's output
    contract_by_output = {}  # output_path -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_by_output[c['output']] = cp

    deps = {}  # contract_path -> set of contract_paths it depends on
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        dep_set = set()
        for inp in c['inputs']:
            if inp in contract_by_output:
                dep_set.add(contract_by_output[inp])
        deps[cp] = dep_set

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(cp):
        if cp in visiting:
            print(f"Circular dependency detected involving {cp}", file=sys.stderr)
            sys.exit(1)
        if cp in visited:
            return
        visiting.add(cp)
        for dep in sorted(deps[cp]):
            visit(dep)
        visiting.remove(cp)
        visited.add(cp)
        ordered.append(cp)

    for cp in sorted(contracts):
        visit(cp)

    # Execute each component via its render.py
    for cp in ordered:
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.is_file():
        result = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
