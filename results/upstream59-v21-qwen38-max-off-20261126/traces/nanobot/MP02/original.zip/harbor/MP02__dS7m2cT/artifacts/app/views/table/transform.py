def transform(payloads, contract):
    """segment_assemble: combine original input with index and attributes results."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    original = payloads[0]   # original input (case.json)
    index_result = payloads[1]   # segment_index output
    attrs_result = payloads[2]   # segment_attributes output

    # Unwrap if wrapped in {name, result}
    if isinstance(index_result, dict) and 'result' in index_result and 'name' in index_result:
        index_data = index_result['result']
    else:
        index_data = index_result

    if isinstance(attrs_result, dict) and 'result' in attrs_result and 'name' in attrs_result:
        attrs_data = attrs_result['result']
    else:
        attrs_data = attrs_result

    # Build piece lookup from original input
    if not isinstance(original, dict):
        raise ValueError("Original input must be an object")
    if 'pieces' not in original:
        raise ValueError("Original input missing pieces")
    if 'columns' not in original:
        raise ValueError("Original input missing columns")

    columns = original['columns']
    pieces_by_id = {}
    for piece in original['pieces']:
        pieces_by_id[piece['id']] = piece

    # Use index order to assemble data
    order = index_data['order']
    out_columns = index_data['columns']

    coordinates = []
    data = []
    for entry in order:
        coord = entry['coordinate']
        piece_id = entry['piece']
        row_idx = entry['row']
        coordinates.append(coord)
        piece = pieces_by_id[piece_id]
        data.append(piece['data'][row_idx])

    result = {
        "coordinates": coordinates,
        "columns": out_columns,
        "data": data,
        "attrs": attrs_data['attrs'],
        "attribute_conflicts": attrs_data['conflicts']
    }

    return {"name": contract["name"], "result": result}
