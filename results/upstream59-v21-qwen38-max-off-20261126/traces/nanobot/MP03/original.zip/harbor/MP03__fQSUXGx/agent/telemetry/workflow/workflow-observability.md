# Workflow 可观测性报告

- Trial：`MP03__fQSUXGx__env`
- Task：`MP03`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（108 节点 / 107 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：108；执行边：107（observed=0，inferred=107）
- Execution Trace Graph：`observed`；temporal_next 边 107，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_fd164b6e8af94c80b07ff8b6 -> tool:nanobot-harness-v3:call_3fa33701457243d7a38939c9 -> tool:nanobot-harness-v3:call_f72f9c760af34ae1be3da58f -> tool:nanobot-harness-v3:call_8ae49847e7e54954a14029ea -> tool:nanobot-harness-v3:call_9313ecb2295c445fad8c02b2 -> tool:nanobot-harness-v3:call_06013df7383545a6ab7aec20 -> tool:nanobot-harness-v3:call_38e2cadba43b4101bff8f154 -> tool:nanobot-harness-v3:call_69dc497681314a91a4263224 -> tool:nanobot-harness-v3:call_0daf5d019fa04d068b806ff7 -> tool:nanobot-harness-v3:call_9094b512e7a04bfca20d12b1 -> tool:nanobot-harness-v3:call_444135dce42140c9bb2f862f -> tool:nanobot-harness-v3:call_736a9537f1ce4c1a9c104231 -> tool:nanobot-harness-v3:call_89068e6b02654ce3a454239c -> tool:nanobot-harness-v3:call_063938a301a84f8a8f21faa2 -> tool:nanobot-harness-v3:call_b55fc273701b445085048285 -> tool:nanobot-harness-v3:call_6462aeed5787413ba1ca8eef -> tool:nanobot-harness-v3:call_8c418092064d4ba2a552c422 -> tool:nanobot-harness-v3:call_5f36b66b01064d3cb702e8bb -> tool:nanobot-harness-v3:call_ec0a968997674faa9da1d322 -> tool:nanobot-harness-v3:call_42bfa1f73eed4c1f9239c5c0 -> tool:nanobot-harness-v3:call_7685ab3e2a0848bd901f2f6c -> tool:nanobot-harness-v3:call_6c29e0c7b95c4d5e936a9ef8 -> tool:nanobot-harness-v3:call_8fbb6287958b43a7be267146 -> tool:nanobot-harness-v3:call_21251113c22d4980b2a49900 -> tool:nanobot-harness-v3:call_abf6c6ebf4dd4d23b91a1fd9 -> tool:nanobot-harness-v3:call_fdd1645ef22846c1bc66411e -> tool:nanobot-harness-v3:call_6919618fb5e342109db26a57 -> tool:nanobot-harness-v3:call_ee8212396fce42a2a83c3fe0 -> tool:nanobot-harness-v3:call_0099aeb1b4d04dfe94d12799 -> tool:nanobot-harness-v3:call_5e04a160dc3d4e59932d4a1f -> tool:nanobot-harness-v3:call_15af4fdecfe645f2bd18935b -> tool:nanobot-harness-v3:call_f7e4ca5457dd40ccaff4f01c -> tool:nanobot-harness-v3:call_b874024017e146ebba8fec6d -> tool:nanobot-harness-v3:call_db66e7fcd4d84d14ab8fe97e -> tool:nanobot-harness-v3:call_d727b78b51bf45c9a945f656 -> tool:nanobot-harness-v3:call_477bfa32e5bc42eda60ce915 -> tool:nanobot-harness-v3:call_e4a499c4c0d5460bb5952722 -> tool:nanobot-harness-v3:call_6b05138c139e4a7c9c74e405 -> tool:nanobot-harness-v3:call_830d945394a54d1f827bf187 -> tool:nanobot-harness-v3:call_509f7e5d801747ecba10119c -> tool:nanobot-harness-v3:call_e68bbb2c5b9e4c0daaefec6a -> tool:nanobot-harness-v3:call_78c883a4c5ba41c2bdfd0af1 -> tool:nanobot-harness-v3:call_78f176f575ac405d964f226c -> tool:nanobot-harness-v3:call_3098e9b7ddfe40238e5798e2 -> tool:nanobot-harness-v3:call_f00dd8f5d4f24ababd77f822 -> tool:nanobot-harness-v3:call_5b36234403f649f8b4007a19 -> tool:nanobot-harness-v3:call_f9cfc5ee343745ccb642d222 -> tool:nanobot-harness-v3:call_665170e2436142b089661b1a -> tool:nanobot-harness-v3:call_a2fdf1b3d1d84cc497c95650 -> tool:nanobot-harness-v3:call_bd526be626084d4ea20b8287 -> tool:nanobot-harness-v3:call_0299cf8fc38048a8b5ffcd4e -> tool:nanobot-harness-v3:call_f4de37a3b5d64ba88e867f53 -> tool:nanobot-harness-v3:call_273059cc00e0467794fc47a1 -> tool:nanobot-harness-v3:call_87d08f6ce89d454ab06ec5b1 -> tool:nanobot-harness-v3:call_f72ef003dbad48f88d6159d9 -> tool:nanobot-harness-v3:call_191f2b214867407ea4ca50fc -> tool:nanobot-harness-v3:call_7712107529a341a6bdbe6fca -> tool:nanobot-harness-v3:call_3a14cc579cfa4859a1c634e9 -> tool:nanobot-harness-v3:call_84de7f5b3df64079b9312452 -> tool:nanobot-harness-v3:call_0d15af6ae6214684b5ce52bd -> tool:nanobot-harness-v3:call_bc81885a269f4466921e1488 -> tool:nanobot-harness-v3:call_1e24b319ad7748949b96ae52 -> tool:nanobot-harness-v3:call_2c5bfc9f54ad4f988b2dd3c4 -> tool:nanobot-harness-v3:call_a46a843fdc2241f489e61c68 -> tool:nanobot-harness-v3:call_7e398b373f5c41f5be7ee11a -> tool:nanobot-harness-v3:call_a8e488a9036d4df19293a20c -> tool:nanobot-harness-v3:call_59d2b9aedcf6463dbb07b427 -> tool:nanobot-harness-v3:call_552cdaaf00be4ee7a776467c -> tool:nanobot-harness-v3:call_08ba8cf75f12416eb4d26da1 -> tool:nanobot-harness-v3:call_e5be9a26cb7546138dab6771 -> tool:nanobot-harness-v3:call_9478121cb9a04eb8b582c5df -> tool:nanobot-harness-v3:call_a245ce0b60bc46c9b64702f0 -> tool:nanobot-harness-v3:call_9823bb81fcd44eaa8ffe1595 -> tool:nanobot-harness-v3:call_e3b2aca30d464597b5fbdaa7 -> tool:nanobot-harness-v3:call_d665953c3c5a491ca7fa9906 -> tool:nanobot-harness-v3:call_b10b660c3b7f4bf895f4191e -> tool:nanobot-harness-v3:call_fe70870b6efa41638d12fe1e -> tool:nanobot-harness-v3:call_3b1fe09e933946cf9e51dc16 -> tool:nanobot-harness-v3:call_53bed2b10cb5410ca555d0aa -> tool:nanobot-harness-v3:call_629ab7ad77c84064846477c7 -> tool:nanobot-harness-v3:call_6b4466e6b76940119a0c71cc -> tool:nanobot-harness-v3:call_f559f66e3e494708aa0a3f84 -> tool:nanobot-harness-v3:call_66200e326be74bd9838b3f7b -> tool:nanobot-harness-v3:call_787c8ce1d1564117a5bc234f -> tool:nanobot-harness-v3:call_3cdaafb34cad450db97200df -> tool:nanobot-harness-v3:call_94caa9c3da294a74b97773c5 -> tool:nanobot-harness-v3:call_bb150bda59e24d7f981a5004 -> tool:nanobot-harness-v3:call_cb4580b3839f4ede864ab956 -> tool:nanobot-harness-v3:call_b886157e39a747389919cfa6 -> tool:nanobot-harness-v3:call_17c3b94bddc9474494e2498a -> tool:nanobot-harness-v3:call_6d67a985a807490d9f2b18b6 -> tool:nanobot-harness-v3:call_081642a489c7481b92c37ead -> tool:nanobot-harness-v3:call_bd1accfc1864459592073d1d -> tool:nanobot-harness-v3:call_cf0536f363b342ff996c72fb -> tool:nanobot-harness-v3:call_d2af9c3e28c14c9194b45a53 -> tool:nanobot-harness-v3:call_2a8fd9027d864e90b4956020 -> tool:nanobot-harness-v3:call_af6e0a2e5cda4077ba0bea68 -> tool:nanobot-harness-v3:call_34f2fa660cfb45b2a062076d -> tool:nanobot-harness-v3:call_306bd776dd984be89b65a38b -> tool:nanobot-harness-v3:call_68be5a4646bc4c3a983bc93c -> tool:nanobot-harness-v3:call_e3832821e1f9473f9960c5e7 -> tool:nanobot-harness-v3:call_089e2d914e664a998db23844 -> tool:nanobot-harness-v3:call_55f3749149ce4af58ae5abb5 -> tool:nanobot-harness-v3:call_be24df37f77d4d4eb6570368 -> tool:nanobot-harness-v3:call_89c02a0fe97d420a9ab7e0e7 -> tool:nanobot-harness-v3:call_e26985e9c10a435fb5b97ca8 -> tool:nanobot-harness-v3:call_7190f21044234365ad15753f
- 关键路径耗时：1.590129
- Makespan：430.136004
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
