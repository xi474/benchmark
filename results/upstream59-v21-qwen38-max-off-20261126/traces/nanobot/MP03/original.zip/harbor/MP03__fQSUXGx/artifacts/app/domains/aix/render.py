import json
import sys
from pathlib import Path

_comp_dir = str(Path(__file__).resolve().parent)
if _comp_dir not in sys.path:
    sys.path.insert(0, _comp_dir)

from model import load_payload
from transform import transform

def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result

if __name__ == '__main__':
    root = Path.cwd()
    contract_path = Path(__file__).resolve().parent / 'contract.json'
    build_component(root, contract_path)
