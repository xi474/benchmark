def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    if 'aix' not in payload:
        raise ValueError('missing aix field')
    aix_str = payload['aix']
    if not isinstance(aix_str, str):
        raise ValueError('aix must be string')
    records = []
    current_mount = None
    current_attrs = {}
    known_keys = {'dev', 'vfs', 'options'}

    def flush():
        nonlocal current_mount, current_attrs
        if current_mount is not None:
            if 'dev' not in current_attrs:
                raise ValueError(f'missing dev for mount {current_mount}')
            vfs = current_attrs.get('vfs', 'jfs2')
            options = current_attrs.get('options', 'rw')
            opts = sorted(set(options.split(',')))
            records.append({
                'device': current_attrs['dev'],
                'mount': current_mount,
                'fstype': vfs,
                'options': ','.join(opts)
            })
        current_mount = None
        current_attrs = {}

    for line in aix_str.split('\n'):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        # Check if this is a mount point header (non-indented, ends with ':')
        if not line[0:1].isspace() and stripped.endswith(':'):
            flush()
            current_mount = stripped[:-1]
            if not current_mount:
                raise ValueError('empty mount point')
            continue
        # Must be inside a paragraph
        if current_mount is None:
            raise ValueError('attribute outside of paragraph')
        if '=' not in stripped:
            raise ValueError(f'invalid attribute line: {stripped}')
        key, _, value = stripped.partition('=')
        key = key.strip()
        value = value.strip()
        if key not in known_keys:
            raise ValueError(f'unknown key: {key}')
        if key in current_attrs:
            raise ValueError(f'duplicate key: {key}')
        current_attrs[key] = value

    flush()
    return {'name': contract['name'], 'result': {'records': records}}
