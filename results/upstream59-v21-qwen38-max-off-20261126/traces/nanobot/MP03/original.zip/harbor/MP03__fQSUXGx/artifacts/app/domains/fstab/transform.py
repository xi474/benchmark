def _unescape(s):
    s = s.replace('\\040', ' ')
    s = s.replace('\\011', '\t')
    s = s.replace('\\134', '\\')
    return s

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    if 'fstab' not in payload:
        raise ValueError('missing fstab field')
    fstab_str = payload['fstab']
    if not isinstance(fstab_str, str):
        raise ValueError('fstab must be string')
    records = []
    for line in fstab_str.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        if len(parts) < 4 or len(parts) > 6:
            raise ValueError(f'invalid fstab line: expected 4-6 fields, got {len(parts)}')
        device = _unescape(parts[0])
        mount = _unescape(parts[1])
        fstype = _unescape(parts[2])
        options_raw = _unescape(parts[3])
        opts = sorted(set(options_raw.split(',')))
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': ','.join(opts)
        })
    return {'name': contract['name'], 'result': {'records': records}}
