import re

def _unescape(s):
    s = s.replace('\\040', ' ')
    return s

def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError('payload must be object')
    if 'mount' not in payload:
        raise ValueError('missing mount field')
    mount_str = payload['mount']
    if not isinstance(mount_str, str):
        raise ValueError('mount must be string')
    records = []
    # Pattern: device on mountpoint type fstype (options)
    pattern = re.compile(r'^(\S+)\s+on\s+(\S+)\s+type\s+(\S+)\s+\(([^)]+)\)$')
    for line in mount_str.split('\n'):
        line = line.strip()
        if not line:
            continue
        m = pattern.match(line)
        if not m:
            raise ValueError(f'invalid mount line: {line}')
        device = _unescape(m.group(1))
        mount = _unescape(m.group(2))
        fstype = m.group(3)
        options_raw = m.group(4).strip()
        if not options_raw:
            raise ValueError('empty options in mount line')
        opts = sorted(set(options_raw.split(',')))
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': ','.join(opts)
        })
    return {'name': contract['name'], 'result': {'records': records}}
