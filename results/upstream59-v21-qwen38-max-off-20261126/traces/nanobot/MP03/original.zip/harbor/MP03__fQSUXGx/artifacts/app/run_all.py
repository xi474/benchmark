import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def _python():
    exe = sys.executable
    if exe:
        return exe
    found = shutil.which('python3') or shutil.which('python')
    if found:
        return found
    raise RuntimeError('cannot locate python interpreter')

def main():
    # Find all contract.json files, excluding outputs
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print('no contracts found', file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: component output -> contract_path
    # and contract inputs -> what they depend on
    contract_map = {}  # contract_path -> contract dict
    output_to_contract = {}  # output_rel_path -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[cp] = c
        output_to_contract[c['output']] = cp

    # Topological sort based on dependencies
    # A contract depends on another if any of its inputs is an output of another contract
    deps = {}  # contract_path -> set of contract_paths it depends on
    for cp, c in contract_map.items():
        deps[cp] = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_cp = output_to_contract[inp]
                if dep_cp != cp:
                    deps[cp].add(dep_cp)

    # Detect cycles and topological sort
    order = []
    visited = set()
    in_stack = set()

    def visit(cp):
        if cp in in_stack:
            print(f'cycle detected involving {cp}', file=sys.stderr)
            sys.exit(1)
        if cp in visited:
            return
        in_stack.add(cp)
        for dep in sorted(deps[cp]):
            visit(dep)
        in_stack.remove(cp)
        visited.add(cp)
        order.append(cp)

    for cp in sorted(contract_map.keys()):
        visit(cp)

    # Execute each component in order via render.py
    for cp in order:
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f'missing render.py for {cp}', file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [_python(), str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f'render.py failed for {cp}', file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [_python(), str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print('integrate.py failed', file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [_python(), str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print('final_report.py failed', file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()
