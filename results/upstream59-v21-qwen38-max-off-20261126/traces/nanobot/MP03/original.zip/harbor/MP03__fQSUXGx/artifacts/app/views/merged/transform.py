def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    # payloads are in order: fstab, aix, mount results
    sources = ['fstab', 'aix', 'mount']
    # Collect all records with source tags
    all_records = []  # list of (source_index, record_index, record_with_source)
    for src_idx, src_name in enumerate(sources):
        payload = payloads[src_idx]
        if not isinstance(payload, dict):
            raise ValueError(f'{src_name} payload must be object')
        if 'name' not in payload or 'result' not in payload:
            raise ValueError(f'{src_name} payload missing name/result')
        result = payload['result']
        if not isinstance(result, dict) or 'records' not in result:
            raise ValueError(f'{src_name} result missing records')
        for rec_idx, rec in enumerate(result['records']):
            tagged = {
                'device': rec['device'],
                'mount': rec['mount'],
                'fstype': rec['fstype'],
                'options': rec['options'],
                'source': src_name
            }
            all_records.append((src_idx, rec_idx, tagged))

    # Group by mount point
    from collections import OrderedDict
    mount_groups = OrderedDict()
    for src_idx, rec_idx, tagged in all_records:
        mp = tagged['mount']
        if mp not in mount_groups:
            mount_groups[mp] = []
        mount_groups[mp].append(tagged)

    # For each mount, pick winner by source priority then original order
    winners = {}
    conflicts = []
    for mp, entries in mount_groups.items():
        winner = entries[0]  # first by source priority, then record order
        winners[mp] = winner
        # Check for conflicts: any difference in device/fstype/options
        has_conflict = False
        for e in entries[1:]:
            if (e['device'] != winner['device'] or
                e['fstype'] != winner['fstype'] or
                e['options'] != winner['options']):
                has_conflict = True
                break
        if has_conflict:
            conflicts.append({
                'mount': mp,
                'evidence': entries
            })

    # Sort winners by mount key
    sorted_records = [winners[mp] for mp in sorted(winners.keys())]
    # Sort conflicts by mount key
    conflicts.sort(key=lambda c: c['mount'])

    return {
        'name': contract['name'],
        'result': {
            'records': sorted_records,
            'conflicts': conflicts
        }
    }
