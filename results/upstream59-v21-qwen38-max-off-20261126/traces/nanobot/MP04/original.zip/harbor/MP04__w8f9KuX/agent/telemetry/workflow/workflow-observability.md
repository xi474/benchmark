# Workflow 可观测性报告

- Trial：`MP04__w8f9KuX__env`
- Task：`MP04`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（89 节点 / 88 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：89；执行边：88（observed=0，inferred=88）
- Execution Trace Graph：`observed`；temporal_next 边 88，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3242151674904f4b93f9f9c0 -> tool:nanobot-harness-v3:call_0e80249972e94eda8bc7ae2a -> tool:nanobot-harness-v3:call_1e746ea7119342b3981c11e0 -> tool:nanobot-harness-v3:call_1644bc52470d41e5b6045775 -> tool:nanobot-harness-v3:call_28cd1846f62a42f2b34a694a -> tool:nanobot-harness-v3:call_db6702efba6c4637959a6e8f -> tool:nanobot-harness-v3:call_41ec7c98cd4e4b11ba3a6053 -> tool:nanobot-harness-v3:call_7fe1ad27fe8e4d8d8c3a7760 -> tool:nanobot-harness-v3:call_469b24bec68e400997f5b85a -> tool:nanobot-harness-v3:call_fe4348ef98204c2ab3a777c4 -> tool:nanobot-harness-v3:call_4bcf7f5c44534b3d935fd327 -> tool:nanobot-harness-v3:call_ae127c9c44124f02a9df483a -> tool:nanobot-harness-v3:call_f4e426a8f0144529a1d609be -> tool:nanobot-harness-v3:call_3bf8a0651fdd44788a6cf0cb -> tool:nanobot-harness-v3:call_e09ec94003fb4db889dda006 -> tool:nanobot-harness-v3:call_8a045045ad4e4b5ebb96d242 -> tool:nanobot-harness-v3:call_f205187dbe2e45968f76e829 -> tool:nanobot-harness-v3:call_52d3b6d2e0234bb2a5316922 -> tool:nanobot-harness-v3:call_d8d8280ad1904532a8c86341 -> tool:nanobot-harness-v3:call_6b72ae9184c749998e041d0f -> tool:nanobot-harness-v3:call_4b5df72276494633ae7a15bb -> tool:nanobot-harness-v3:call_58fb1bb7c1d540ba97ebe163 -> tool:nanobot-harness-v3:call_0940004eb71c4031b2f19def -> tool:nanobot-harness-v3:call_0a73146ebe5343a3998f3504 -> tool:nanobot-harness-v3:call_5a5321c91d4c4781942d8566 -> tool:nanobot-harness-v3:call_f474bcf8347b4dc4a04fa2c6 -> tool:nanobot-harness-v3:call_46b161f0f7ef45ccb704e1c4 -> tool:nanobot-harness-v3:call_6ca3380e52b248ad89189965 -> tool:nanobot-harness-v3:call_7128365b49c0440a8405305a -> tool:nanobot-harness-v3:call_15da4a39b8fc4a61ba657412 -> tool:nanobot-harness-v3:call_f543017f4ad04e0e92def35b -> tool:nanobot-harness-v3:call_e6320af8cfa44a589443bea4 -> tool:nanobot-harness-v3:call_397bd4c2962b4302ac095417 -> tool:nanobot-harness-v3:call_8fda86ea374b4ebd87e6c356 -> tool:nanobot-harness-v3:call_8eb157c0713d44c9a47a743e -> tool:nanobot-harness-v3:call_5440449c96944a0cb7566881 -> tool:nanobot-harness-v3:call_67750531c7ee4bbb837bacd6 -> tool:nanobot-harness-v3:call_127fd2b3b1144d12854d36c4 -> tool:nanobot-harness-v3:call_aa7c9cc9a0e7410ab6934a8b -> tool:nanobot-harness-v3:call_b71a4cface7944d8b307cd3a -> tool:nanobot-harness-v3:call_6d73a0ee6ac24cdebdaff7ac -> tool:nanobot-harness-v3:call_91eeb71bea71422286d0f3b8 -> tool:nanobot-harness-v3:call_a2238fdda14343f7b55d35a9 -> tool:nanobot-harness-v3:call_b0acad9af74d49a291aae5ff -> tool:nanobot-harness-v3:call_0a3ec324385649b99a3c8a1d -> tool:nanobot-harness-v3:call_ee003d588c72488487dcf853 -> tool:nanobot-harness-v3:call_133d5f776a364e40912dae87 -> tool:nanobot-harness-v3:call_3c0f61ab0cc84f8db9bab192 -> tool:nanobot-harness-v3:call_a62332f123a74bc891339ddb -> tool:nanobot-harness-v3:call_4bdb4837be7b48cc80df7302 -> tool:nanobot-harness-v3:call_a4604dcce16249439ee1498f -> tool:nanobot-harness-v3:call_aa8acf5dd90d489ead6ba303 -> tool:nanobot-harness-v3:call_0b6600cf920c40cf971ec6f7 -> tool:nanobot-harness-v3:call_e924ee19e84f4b9ab3580f67 -> tool:nanobot-harness-v3:call_56425ae852744a658f18d398 -> tool:nanobot-harness-v3:call_30cd081d10d046beac406a8c -> tool:nanobot-harness-v3:call_6d976062f74e44feb68e4883 -> tool:nanobot-harness-v3:call_62183137e8b94acc98f0a6d1 -> tool:nanobot-harness-v3:call_63b0283bcb024a998c648e66 -> tool:nanobot-harness-v3:call_ff36d83facbd476ebb87c530 -> tool:nanobot-harness-v3:call_330281dbf02b44ec9bb5e923 -> tool:nanobot-harness-v3:call_7efd635ca9854075abe02cc2 -> tool:nanobot-harness-v3:call_ee4aa31173db48f5af995e27 -> tool:nanobot-harness-v3:call_fccaac4396af4fa9bc22475a -> tool:nanobot-harness-v3:call_6950b1a54c574d6b90a0aac7 -> tool:nanobot-harness-v3:call_284e14e9f1774407aee73569 -> tool:nanobot-harness-v3:call_697832dc9b9b46bfb60e41fe -> tool:nanobot-harness-v3:call_f22df7c18fee4595b6e201dc -> tool:nanobot-harness-v3:call_cd5d6ee4ae2f4475b3a959a6 -> tool:nanobot-harness-v3:call_6ce4b24b273d4c0d92eca79a -> tool:nanobot-harness-v3:call_c66baa3b354346f19ddda5fe -> tool:nanobot-harness-v3:call_12543c1feb70478a88e1993b -> tool:nanobot-harness-v3:call_bec9a9974bfe4d1d8d123c52 -> tool:nanobot-harness-v3:call_cb6aff2140d049a88c8524fd -> tool:nanobot-harness-v3:call_c00a6f6dd7714cbdb5438c83 -> tool:nanobot-harness-v3:call_c2bd4fb842d04d6aa821edfa -> tool:nanobot-harness-v3:call_e141fcde41e54359b96e2840 -> tool:nanobot-harness-v3:call_12d42e6e4c6942f4974eca0b -> tool:nanobot-harness-v3:call_77edf0a246f04be2a85f87d6 -> tool:nanobot-harness-v3:call_465be58608d34ef4854ed9a1 -> tool:nanobot-harness-v3:call_c1b8a49af6e5403183e5e321 -> tool:nanobot-harness-v3:call_d34bd461e35a4919939f897a -> tool:nanobot-harness-v3:call_69df7722f33b427f931c35b1 -> tool:nanobot-harness-v3:call_68457a5dd9c54adab0fcc3aa -> tool:nanobot-harness-v3:call_ec2ac556561046c283dde8fc -> tool:nanobot-harness-v3:call_22e73efbf3524b7e81cc761d -> tool:nanobot-harness-v3:call_9af1432863c8495c92191f31 -> tool:nanobot-harness-v3:call_b0b28887d0864b24a43d799e
- 关键路径耗时：1.640563
- Makespan：597.245839
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
