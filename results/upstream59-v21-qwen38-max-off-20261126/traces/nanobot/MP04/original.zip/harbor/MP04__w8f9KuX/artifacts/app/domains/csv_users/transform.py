import csv
import io
import re
from datetime import datetime


def _parse_date(s):
    if not isinstance(s, str):
        raise ValueError(f"joined must be string, got {type(s).__name__}")
    s_stripped = s.strip()
    if not s_stripped:
        return None
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s_stripped)
    if m:
        try:
            dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            raise ValueError(f"Invalid date: {s}")
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s_stripped)
    if m:
        try:
            dt = datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            raise ValueError(f"Invalid date: {s}")
    raise ValueError(f"Invalid date format: {s}")


def _normalize_id(raw_id):
    if isinstance(raw_id, bool):
        raise ValueError("ID cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        result = raw_id.strip()
        if not result:
            raise ValueError("ID cannot be empty after strip")
        return result
    raise ValueError(f"ID must be str or int, got {type(raw_id).__name__}")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("Payload must be object")
    if 'csv_text' not in payload:
        raise ValueError("Missing csv_text field")
    csv_text = payload['csv_text']
    if not isinstance(csv_text, str):
        raise ValueError("csv_text must be string")

    # Empty text -> empty records
    if not csv_text.strip():
        return {'name': contract['name'], 'result': {'records': []}}

    reader = csv.DictReader(io.StringIO(csv_text))
    headers = reader.fieldnames
    if headers is None:
        return {'name': contract['name'], 'result': {'records': []}}

    # Check for id or user_id column
    has_id = 'id' in headers
    has_user_id = 'user_id' in headers
    if not has_id and not has_user_id:
        raise ValueError("CSV must have id or user_id column")

    # Check unique column names
    if len(headers) != len(set(headers)):
        raise ValueError("Duplicate column names")

    users = {}
    for row in reader:
        # Determine ID: user_id takes priority over id
        if has_user_id:
            raw_id = row.get('user_id', '')
        else:
            raw_id = row.get('id', '')

        # CSV empty cell = missing value (skip, don't clear)
        if raw_id is None or raw_id.strip() == '':
            continue

        uid = _normalize_id(raw_id)
        if uid not in users:
            users[uid] = {'id': uid}

        # name/full_name
        for col in ['name', 'full_name']:
            if col in row and row[col] is not None and row[col] != '':
                users[uid]['name'] = row[col]
                break

        # email/mail
        for col in ['email', 'mail']:
            if col in row and row[col] is not None and row[col] != '':
                users[uid]['email'] = row[col]
                break

        # joined/joined_at
        for col in ['joined', 'joined_at']:
            if col in row and row[col] is not None and row[col] != '':
                parsed = _parse_date(row[col])
                if parsed is not None:
                    users[uid]['joined'] = parsed
                break

    result_records = []
    for uid in sorted(users.keys()):
        entry = {'id': users[uid]['id']}
        if 'name' in users[uid]:
            entry['name'] = users[uid]['name']
        if 'email' in users[uid]:
            entry['email'] = users[uid]['email']
        if 'joined' in users[uid]:
            entry['joined'] = users[uid]['joined']
        result_records.append(entry)

    return {'name': contract['name'], 'result': {'records': result_records}}
