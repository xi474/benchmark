import json
import sys
from pathlib import Path

# Add root and component dir to path
_comp_dir = Path(__file__).resolve().parent
_root = _comp_dir.parents[1]
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_comp_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result


if __name__ == "__main__":
    # Workspace root is where inputs/ and outputs/ live
    root = Path(__file__).resolve().parents[2]
    contract_path = Path(__file__).resolve().with_name('contract.json')
    build_component(root, contract_path)
