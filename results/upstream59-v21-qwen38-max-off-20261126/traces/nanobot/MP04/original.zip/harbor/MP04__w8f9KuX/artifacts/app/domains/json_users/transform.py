import json
import re
from datetime import datetime


def _parse_date(s):
    """Parse YYYY-MM-DD or DD/MM/YYYY to ISO date string."""
    if not isinstance(s, str):
        raise ValueError(f"joined must be string, got {type(s).__name__}")
    s_stripped = s.strip()
    if not s_stripped:
        return None
    # Try YYYY-MM-DD
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s_stripped)
    if m:
        try:
            dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            raise ValueError(f"Invalid date: {s}")
    # Try DD/MM/YYYY
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s_stripped)
    if m:
        try:
            dt = datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            raise ValueError(f"Invalid date: {s}")
    raise ValueError(f"Invalid date format: {s}")


def _normalize_id(raw_id):
    """Normalize user ID: str or int (not bool), return stripped str."""
    if isinstance(raw_id, bool):
        raise ValueError("ID cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        result = raw_id.strip()
        if not result:
            raise ValueError("ID cannot be empty after strip")
        return result
    raise ValueError(f"ID must be str or int, got {type(raw_id).__name__}")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    payload = payloads[0]
    # payload is the case.json object with json_text field
    if not isinstance(payload, dict):
        raise ValueError("Payload must be object")
    if 'json_text' not in payload:
        raise ValueError("Missing json_text field")
    json_text = payload['json_text']
    if not isinstance(json_text, str):
        raise ValueError("json_text must be string")
    try:
        records_raw = json.loads(json_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid json_text JSON: {e}")
    if not isinstance(records_raw, list):
        raise ValueError("json_text must contain array")

    # Process records: deduplicate by ID, last value wins per field
    users = {}  # id -> {id, name?, email?, joined?}
    for rec in records_raw:
        if not isinstance(rec, dict):
            raise ValueError("Each record must be object")
        # Determine ID: user_id takes priority over id
        if 'user_id' in rec:
            raw_id = rec['user_id']
        elif 'id' in rec:
            raw_id = rec['id']
        else:
            raise ValueError("Record missing id/user_id")
        uid = _normalize_id(raw_id)

        if uid not in users:
            users[uid] = {'id': uid}

        # name/full_name: new field exists priority
        if 'name' in rec:
            val = rec['name']
            if val is not None:
                users[uid]['name'] = val
        elif 'full_name' in rec:
            val = rec['full_name']
            if val is not None:
                users[uid]['name'] = val

        # email/mail
        if 'email' in rec:
            val = rec['email']
            if val is not None:
                users[uid]['email'] = val
        elif 'mail' in rec:
            val = rec['mail']
            if val is not None:
                users[uid]['email'] = val

        # joined/joined_at
        if 'joined' in rec:
            val = rec['joined']
            if val is not None:
                users[uid]['joined'] = _parse_date(val)
        elif 'joined_at' in rec:
            val = rec['joined_at']
            if val is not None:
                users[uid]['joined'] = _parse_date(val)

    # Build output records sorted by id (string dict order)
    result_records = []
    for uid in sorted(users.keys()):
        entry = {'id': users[uid]['id']}
        if 'name' in users[uid]:
            entry['name'] = users[uid]['name']
        if 'email' in users[uid]:
            entry['email'] = users[uid]['email']
        if 'joined' in users[uid]:
            entry['joined'] = users[uid]['joined']
        result_records.append(entry)

    return {'name': contract['name'], 'result': {'records': result_records}}
