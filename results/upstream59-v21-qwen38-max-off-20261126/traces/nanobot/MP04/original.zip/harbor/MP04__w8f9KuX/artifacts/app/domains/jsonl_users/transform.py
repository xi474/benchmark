import json
import re
from datetime import datetime


def _parse_date(s):
    if not isinstance(s, str):
        raise ValueError(f"joined must be string, got {type(s).__name__}")
    s_stripped = s.strip()
    if not s_stripped:
        return None
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s_stripped)
    if m:
        try:
            dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            raise ValueError(f"Invalid date: {s}")
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s_stripped)
    if m:
        try:
            dt = datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            raise ValueError(f"Invalid date: {s}")
    raise ValueError(f"Invalid date format: {s}")


def _normalize_id(raw_id):
    if isinstance(raw_id, bool):
        raise ValueError("ID cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        result = raw_id.strip()
        if not result:
            raise ValueError("ID cannot be empty after strip")
        return result
    raise ValueError(f"ID must be str or int, got {type(raw_id).__name__}")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("Payload must be object")
    if 'jsonl_text' not in payload:
        raise ValueError("Missing jsonl_text field")
    jsonl_text = payload['jsonl_text']
    if not isinstance(jsonl_text, str):
        raise ValueError("jsonl_text must be string")

    users = {}
    for line in jsonl_text.split('\n'):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSONL line: {e}")
        if not isinstance(rec, dict):
            raise ValueError("Each JSONL line must be object")

        # user_id takes priority over id
        if 'user_id' in rec:
            raw_id = rec['user_id']
        elif 'id' in rec:
            raw_id = rec['id']
        else:
            raise ValueError("Record missing id/user_id")
        uid = _normalize_id(raw_id)

        if uid not in users:
            users[uid] = {'id': uid}

        # name/full_name
        if 'name' in rec:
            val = rec['name']
            if val is not None:
                users[uid]['name'] = val
        elif 'full_name' in rec:
            val = rec['full_name']
            if val is not None:
                users[uid]['name'] = val

        # email/mail
        if 'email' in rec:
            val = rec['email']
            if val is not None:
                users[uid]['email'] = val
        elif 'mail' in rec:
            val = rec['mail']
            if val is not None:
                users[uid]['email'] = val

        # joined/joined_at
        if 'joined' in rec:
            val = rec['joined']
            if val is not None:
                users[uid]['joined'] = _parse_date(val)
        elif 'joined_at' in rec:
            val = rec['joined_at']
            if val is not None:
                users[uid]['joined'] = _parse_date(val)

    result_records = []
    for uid in sorted(users.keys()):
        entry = {'id': users[uid]['id']}
        if 'name' in users[uid]:
            entry['name'] = users[uid]['name']
        if 'email' in users[uid]:
            entry['email'] = users[uid]['email']
        if 'joined' in users[uid]:
            entry['joined'] = users[uid]['joined']
        result_records.append(entry)

    return {'name': contract['name'], 'result': {'records': result_records}}
