import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Find python executable reliably
PYTHON = sys.executable if sys.executable else shutil.which('python3') or 'python3'


def main():
    # Find all contract.json files (excluding outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: component output -> contract path
    # We need to run components in topological order
    # Domains first (they read from inputs/), then views (they read from outputs/)

    # Separate into layers
    domain_contracts = []
    view_contracts = []
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        # Check if any input starts with "outputs/"
        needs_output = any(inp.startswith('outputs/') for inp in c['inputs'])
        if needs_output:
            view_contracts.append(cp)
        else:
            domain_contracts.append(cp)

    # Run domain components first
    for cp in domain_contracts:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed", file=sys.stderr)
            sys.exit(1)

    # Run view components
    for cp in view_contracts:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
