def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")

    # payloads[0] = json_users result, payloads[1] = csv_users result, payloads[2] = jsonl_users result
    # Each is {"name": ..., "result": {"records": [...]}}
    # Source priority: json > csv > jsonl
    sources = [
        ('json', payloads[0]),
        ('csv', payloads[1]),
        ('jsonl', payloads[2]),
    ]

    # Collect all user IDs and their field values per source
    # user_data[id][field] = [(source, value), ...]
    user_data = {}

    for source_name, payload in sources:
        records = payload['result']['records']
        for rec in records:
            uid = rec['id']
            if uid not in user_data:
                user_data[uid] = {}
            for field in ['name', 'email', 'joined']:
                if field in rec:
                    if field not in user_data[uid]:
                        user_data[uid][field] = []
                    user_data[uid][field].append((source_name, rec[field]))

    # Build merged users and conflicts
    users = []
    conflicts = []

    for uid in sorted(user_data.keys()):
        merged = {'id': uid}
        for field in ['name', 'email', 'joined']:
            if field not in user_data[uid]:
                continue
            entries = user_data[uid][field]
            # Pick first source with a value (priority order: json, csv, jsonl)
            chosen_value = None
            for source_name, value in entries:
                chosen_value = value
                break  # first in priority order
            merged[field] = chosen_value

            # Check for conflicts: different sources with different values
            if len(entries) >= 2:
                unique_values = set()
                for _, v in entries:
                    unique_values.add(v)
                if len(unique_values) >= 2:
                    conflict_entry = {
                        'id': uid,
                        'field': field,
                        'values': [{'source': s, 'value': v} for s, v in entries]
                    }
                    conflicts.append(conflict_entry)

        users.append(merged)

    # Sort conflicts by (id, field)
    conflicts.sort(key=lambda c: (c['id'], c['field']))

    return {
        'name': contract['name'],
        'result': {
            'users': users,
            'conflicts': conflicts
        }
    }
