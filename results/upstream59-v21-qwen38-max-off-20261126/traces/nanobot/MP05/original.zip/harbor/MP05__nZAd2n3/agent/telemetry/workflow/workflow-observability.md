# Workflow 可观测性报告

- Trial：`MP05__nZAd2n3__env`
- Task：`MP05`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（89 节点 / 88 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：89；执行边：88（observed=0，inferred=88）
- Execution Trace Graph：`observed`；temporal_next 边 88，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_04d24e05b9244d2c84c31337 -> tool:nanobot-harness-v3:call_bd849d0ee3784f1b80d79c71 -> tool:nanobot-harness-v3:call_93c33f61ee1e488aaf542f4c -> tool:nanobot-harness-v3:call_fb0229ac10164a8598d07b75 -> tool:nanobot-harness-v3:call_1302cc38d7644c529eed1fb9 -> tool:nanobot-harness-v3:call_e8cb6fd5c50b48efb9e08662 -> tool:nanobot-harness-v3:call_2aa0f229b26e4e528a088eb6 -> tool:nanobot-harness-v3:call_32607945d4474df5ad88472a -> tool:nanobot-harness-v3:call_4c59b511c9df4f1b9c8b3c36 -> tool:nanobot-harness-v3:call_49bc74b9adc445f9a8ada5e0 -> tool:nanobot-harness-v3:call_018a4ad0c74d409f8d938f90 -> tool:nanobot-harness-v3:call_c0772be8d0b049f98fb188fd -> tool:nanobot-harness-v3:call_e2b4f6eed852458e823e0c4c -> tool:nanobot-harness-v3:call_088d050679834d6a90d6114a -> tool:nanobot-harness-v3:call_f5ac25834e4e4800b26ae66c -> tool:nanobot-harness-v3:call_bd0f7d1507c9460494bed188 -> tool:nanobot-harness-v3:call_ac1de82ab39a47beb9ea9711 -> tool:nanobot-harness-v3:call_7b7e38acd65a42da9fab072a -> tool:nanobot-harness-v3:call_da27fa2e5a9c4c4292e03aac -> tool:nanobot-harness-v3:call_bb81b4a96c03444c8e97db1a -> tool:nanobot-harness-v3:call_b5802fc82ff944c8b4da9eca -> tool:nanobot-harness-v3:call_b133b0a878a1478a8a2a92b9 -> tool:nanobot-harness-v3:call_1d3808b4ae2a4732859427c2 -> tool:nanobot-harness-v3:call_8caa39f8edbc4074bbe58f64 -> tool:nanobot-harness-v3:call_601bdb27c7cc46f0bc302617 -> tool:nanobot-harness-v3:call_465600a5bc4d4546b197ccee -> tool:nanobot-harness-v3:call_88c5bff95d0043b0a2b54914 -> tool:nanobot-harness-v3:call_50bb69471246411e96835e09 -> tool:nanobot-harness-v3:call_a2ca165d96184617b7c41694 -> tool:nanobot-harness-v3:call_84461902544548c6bdf20eef -> tool:nanobot-harness-v3:call_a865b1d6ae5a421b879f49ee -> tool:nanobot-harness-v3:call_6e74f402a0c84f85ae40986f -> tool:nanobot-harness-v3:call_9528176d80bf4400b2e3626e -> tool:nanobot-harness-v3:call_cf90f6bbfbd544a59da52b40 -> tool:nanobot-harness-v3:call_0048b42b343d47bfad1605a2 -> tool:nanobot-harness-v3:call_bb44dd27993249398ce6dab1 -> tool:nanobot-harness-v3:call_eede955fa8de4726b45eedc7 -> tool:nanobot-harness-v3:call_a85c1e3730f44006a4c08f38 -> tool:nanobot-harness-v3:call_6bdd1322d3174486b5949302 -> tool:nanobot-harness-v3:call_7d955f4661524d0db61622ef -> tool:nanobot-harness-v3:call_aab9f30e5fa84d9996f59d66 -> tool:nanobot-harness-v3:call_e1bbc55de5514233afac3d06 -> tool:nanobot-harness-v3:call_d962aa3fdaca4091bd54d600 -> tool:nanobot-harness-v3:call_abb1259dea85465198facd3c -> tool:nanobot-harness-v3:call_d9476122bc3e431e9f99c75f -> tool:nanobot-harness-v3:call_744fcb01977444f0bf31ec8d -> tool:nanobot-harness-v3:call_684a601f6b964903b4dd6aa1 -> tool:nanobot-harness-v3:call_b404febf4b434e64b45d5767 -> tool:nanobot-harness-v3:call_ce4ef50a08844368b3aaba9f -> tool:nanobot-harness-v3:call_a3a9150c96024523abb94832 -> tool:nanobot-harness-v3:call_3192de820ea54119a9bdd70a -> tool:nanobot-harness-v3:call_8da51f7d92b54509b9b5c33e -> tool:nanobot-harness-v3:call_a423d7edb5f040ffb4c4b9e6 -> tool:nanobot-harness-v3:call_f714c6618c7949ca803b72a1 -> tool:nanobot-harness-v3:call_5aa12c16cfe248e5b693f2b6 -> tool:nanobot-harness-v3:call_ad95828a198b4ddaa0148b2a -> tool:nanobot-harness-v3:call_27798fbea408418a9823c351 -> tool:nanobot-harness-v3:call_7440a1c077724eb69d7e18fc -> tool:nanobot-harness-v3:call_e79f3b2123f941cb96a8c3f5 -> tool:nanobot-harness-v3:call_77990a595ed34502815c271f -> tool:nanobot-harness-v3:call_612145a2cbde403a81910ddd -> tool:nanobot-harness-v3:call_1b67df6f5aaf4c1fb7eee11e -> tool:nanobot-harness-v3:call_d8a3089284f4473181b3ddde -> tool:nanobot-harness-v3:call_59f25f464d0648a3896b85b2 -> tool:nanobot-harness-v3:call_1a58e479fb934ada9a6f1775 -> tool:nanobot-harness-v3:call_e3cd80b156e149f6af7ac634 -> tool:nanobot-harness-v3:call_4f70f273fd8144e094ea1381 -> tool:nanobot-harness-v3:call_b776251d61ce422ea727eebd -> tool:nanobot-harness-v3:call_471beb403c4445019b83d4f4 -> tool:nanobot-harness-v3:call_fd7d7129e4274bafb4b4b22f -> tool:nanobot-harness-v3:call_43ce253cd77b4eb1802c2ba5 -> tool:nanobot-harness-v3:call_0c26b91edbb5430fae9a3086 -> tool:nanobot-harness-v3:call_3c2db13c14684b75abf307f4 -> tool:nanobot-harness-v3:call_e5ba61a946a24243a4a9cbb0 -> tool:nanobot-harness-v3:call_a3bb95a242be45628c25ed99 -> tool:nanobot-harness-v3:call_8e572859e91f497597bf264e -> tool:nanobot-harness-v3:call_032c7ac654b642f0a85cfeaa -> tool:nanobot-harness-v3:call_42aff6f1d8984c87a4bc2bdf -> tool:nanobot-harness-v3:call_e41203286ca24f67a380a669 -> tool:nanobot-harness-v3:call_1c9274120c10477d8fc387ef -> tool:nanobot-harness-v3:call_776a70624e154f19b4fa9c89 -> tool:nanobot-harness-v3:call_ebbab9c4747f49c8a79f7134 -> tool:nanobot-harness-v3:call_4be16487ce4d42f7be2aa74f -> tool:nanobot-harness-v3:call_368c5a765d2445ddadc85e99 -> tool:nanobot-harness-v3:call_4262fd07a99f4b5e9a71daf0 -> tool:nanobot-harness-v3:call_e7455625d14948a4aa4a8f2f -> tool:nanobot-harness-v3:call_380755ce81cc45d0b0d56e69 -> tool:nanobot-harness-v3:call_2de2a8a04f3e445c96277ebd
- 关键路径耗时：1.289855
- Makespan：436.525224
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
