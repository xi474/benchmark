def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]

    for field in ("contacts", "self_id", "window", "events"):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    contacts = case["contacts"]
    self_id = case["self_id"]
    window = case["window"]
    events = case["events"]

    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")
    if not isinstance(window, list) or len(window) != 2:
        raise ValueError("window must be [start, end]")

    win_start, win_end = window
    if not isinstance(win_start, (int, float)) or isinstance(win_start, bool):
        raise ValueError("window start must be number")
    if not isinstance(win_end, (int, float)) or isinstance(win_end, bool):
        raise ValueError("window end must be number")

    contact_map = {}
    for c in contacts:
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError(f"invalid age for {cid}")
        if cid in contact_map:
            raise ValueError(f"duplicate contact id: {cid}")
        contact_map[cid] = age

    if self_id not in contact_map:
        raise ValueError("self_id not in contacts")

    # Initialize minutes for all non-self contacts
    minutes = {}
    for cid in contact_map:
        if cid != self_id:
            minutes[cid] = 0

    for ev in events:
        if "id" not in ev or "start" not in ev or "end" not in ev or "attendees" not in ev:
            raise ValueError("event missing required fields")

        ev_start = ev["start"]
        ev_end = ev["end"]

        if not isinstance(ev_start, (int, float)) or isinstance(ev_start, bool):
            raise ValueError("event start must be number")
        if not isinstance(ev_end, (int, float)) or isinstance(ev_end, bool):
            raise ValueError("event end must be number")
        if ev_end <= ev_start:
            raise ValueError("event end must be > start")

        attendees = ev["attendees"]

        # Check if self is in attendees
        has_self = False
        unique_attendees = set()
        for a in attendees:
            if a not in contact_map:
                raise ValueError(f"unknown attendee: {a}")
            if a == self_id:
                has_self = True
            unique_attendees.add(a)

        if not has_self:
            continue

        # Clip to window [win_start, win_end) - half-open
        clipped_start = max(ev_start, win_start)
        clipped_end = min(ev_end, win_end)
        duration = clipped_end - clipped_start
        if duration <= 0:
            continue

        # Add duration to each unique non-self attendee
        for a in unique_attendees:
            if a != self_id:
                minutes[a] += duration

    return {"name": contract["name"], "result": {"minutes": minutes}}
