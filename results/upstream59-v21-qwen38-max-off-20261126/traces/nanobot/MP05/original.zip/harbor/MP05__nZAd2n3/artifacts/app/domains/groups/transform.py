def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]

    # Validate required fields
    for field in ("contacts", "self_id", "keyword", "groups"):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    contacts = case["contacts"]
    self_id = case["self_id"]
    keyword = case["keyword"]
    groups = case["groups"]

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")

    # Build contact map
    contact_map = {}
    for c in contacts:
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError(f"invalid age for {cid}")
        if cid in contact_map:
            raise ValueError(f"duplicate contact id: {cid}")
        contact_map[cid] = age

    if self_id not in contact_map:
        raise ValueError("self_id not in contacts")

    keyword_lower = keyword.casefold()
    candidate_ids = set()

    for g in groups:
        if "id" not in g or "members" not in g or "messages" not in g:
            raise ValueError("group missing required fields")
        members = g["members"]
        messages = g["messages"]

        # Validate all members exist
        for m in members:
            if m not in contact_map:
                raise ValueError(f"unknown member: {m}")

        # Check if any message contains keyword (case-insensitive)
        matched = False
        for msg in messages:
            if not isinstance(msg, str):
                raise ValueError("message must be string")
            if keyword_lower in msg.casefold():
                matched = True
                break

        if matched:
            for m in members:
                if m != self_id:
                    candidate_ids.add(m)

    return {"name": contract["name"], "result": {"ids": sorted(candidate_ids)}}
