def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]

    for field in ("contacts", "self_id", "keyword", "emails"):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    contacts = case["contacts"]
    self_id = case["self_id"]
    keyword = case["keyword"]
    emails = case["emails"]

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")
    if not isinstance(self_id, str):
        raise ValueError("self_id must be string")

    contact_map = {}
    for c in contacts:
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError(f"invalid age for {cid}")
        if cid in contact_map:
            raise ValueError(f"duplicate contact id: {cid}")
        contact_map[cid] = age

    if self_id not in contact_map:
        raise ValueError("self_id not in contacts")

    keyword_lower = keyword.casefold()
    candidate_ids = set()

    for e in emails:
        if "id" not in e or "sender" not in e or "subject" not in e:
            raise ValueError("email missing required fields")
        sender = e["sender"]
        subject = e["subject"]

        if sender not in contact_map:
            raise ValueError(f"unknown sender: {sender}")

        if not isinstance(subject, str):
            raise ValueError("subject must be string")

        if keyword_lower in subject.casefold():
            if sender != self_id:
                candidate_ids.add(sender)

    return {"name": contract["name"], "result": {"ids": sorted(candidate_ids)}}
