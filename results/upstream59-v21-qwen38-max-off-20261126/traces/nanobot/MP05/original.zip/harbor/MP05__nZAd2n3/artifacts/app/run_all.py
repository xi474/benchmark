import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Resolve python executable (sys.executable may be empty in some environments)
PYTHON = sys.executable if sys.executable else shutil.which("python3") or "python3"


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: each contract may depend on other contract outputs
    # We need to topologically sort them
    contract_map = {}  # output_path -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        out = c["output"]
        contract_map[out] = cp

    # Topological sort based on input dependencies
    visited = set()
    order = []
    visiting = set()

    def visit(cp):
        key = str(cp)
        if key in visited:
            return
        if key in visiting:
            print(f"Circular dependency detected involving {cp}", file=sys.stderr)
            sys.exit(1)
        visiting.add(key)
        c = json.loads(cp.read_text(encoding="utf-8"))
        for inp in c["inputs"]:
            if inp in contract_map:
                dep_cp = contract_map[inp]
                visit(dep_cp)
        visiting.discard(key)
        visited.add(key)
        order.append(cp)

    for cp in contracts:
        visit(cp)

    # Execute each component in order via its render.py
    for cp in order:
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component failed: {cp}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=ROOT,
            timeout=30
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.is_file():
        result = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=ROOT,
            timeout=30
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
