def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    # payloads order: case.json, groups.json, mail.json, calendar.json
    case = payloads[0]
    groups_result = payloads[1]
    mail_result = payloads[2]
    calendar_result = payloads[3]

    # Extract result from upstream outputs (they have {name, result} wrapper)
    if isinstance(groups_result, dict) and "result" in groups_result:
        groups_data = groups_result["result"]
    else:
        groups_data = groups_result

    if isinstance(mail_result, dict) and "result" in mail_result:
        mail_data = mail_result["result"]
    else:
        mail_data = mail_result

    if isinstance(calendar_result, dict) and "result" in calendar_result:
        calendar_data = calendar_result["result"]
    else:
        calendar_data = calendar_result

    # Validate case
    for field in ("contacts", "self_id"):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    contacts = case["contacts"]
    self_id = case["self_id"]

    contact_map = {}
    for c in contacts:
        if "id" not in c or "age" not in c:
            raise ValueError("contact missing id or age")
        cid = c["id"]
        age = c["age"]
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError(f"invalid age for {cid}")
        if cid in contact_map:
            raise ValueError(f"duplicate contact id: {cid}")
        contact_map[cid] = age

    if self_id not in contact_map:
        raise ValueError("self_id not in contacts")

    # Get candidate union from groups and mail
    group_ids = set(groups_data.get("ids", []))
    mail_ids = set(mail_data.get("ids", []))
    candidate_ids = group_ids | mail_ids  # Union, not intersection

    # Get minutes from calendar
    cal_minutes = calendar_data.get("minutes", {})

    # Build ranking list
    ranking = []
    for cid in candidate_ids:
        if cid not in contact_map:
            raise ValueError(f"candidate {cid} not in contacts")
        m = cal_minutes.get(cid, 0)
        age = contact_map[cid]
        ranking.append({"id": cid, "minutes": m, "age": age})

    # Sort: minutes desc, age desc, id asc
    ranking.sort(key=lambda x: (-x["minutes"], -x["age"], x["id"]))

    winner = ranking[0]["id"] if ranking else None

    return {
        "name": contract["name"],
        "result": {"ranking": ranking, "winner": winner}
    }
