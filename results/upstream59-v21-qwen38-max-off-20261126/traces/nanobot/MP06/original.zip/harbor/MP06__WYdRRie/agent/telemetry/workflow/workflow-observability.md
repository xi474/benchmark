# Workflow 可观测性报告

- Trial：`MP06__WYdRRie__env`
- Task：`MP06`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（97 节点 / 96 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：97；执行边：96（observed=0，inferred=96）
- Execution Trace Graph：`observed`；temporal_next 边 96，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_380fd57a9d9242c0bbfb08d3 -> tool:nanobot-harness-v3:call_105e4fd138504635a0227888 -> tool:nanobot-harness-v3:call_2c43e036fe9a4a9eb60beff7 -> tool:nanobot-harness-v3:call_b5f11411da1f494c9d44209e -> tool:nanobot-harness-v3:call_f1e91476346b497bb51b5410 -> tool:nanobot-harness-v3:call_eb63f9393ffc4b6fa8f5b777 -> tool:nanobot-harness-v3:call_941008c4917242a397236f04 -> tool:nanobot-harness-v3:call_c91a0b563c954a12be42072c -> tool:nanobot-harness-v3:call_82139138ea564e788d6950f6 -> tool:nanobot-harness-v3:call_5382b7e000bc403589c4eb8a -> tool:nanobot-harness-v3:call_abb2cc089dbb4fb8801d0f0f -> tool:nanobot-harness-v3:call_79ce660822c74989ace4585f -> tool:nanobot-harness-v3:call_4d64a8bc92ac41e6b003f7ed -> tool:nanobot-harness-v3:call_a6b3817112a8471e8eaaf882 -> tool:nanobot-harness-v3:call_d5fe3e05eeca4fd185cc21ba -> tool:nanobot-harness-v3:call_3111b698ac7f48f69d18d012 -> tool:nanobot-harness-v3:call_109c6ee6d8c24225a6a4baed -> tool:nanobot-harness-v3:call_9589f0222abf4ffbb7b286da -> tool:nanobot-harness-v3:call_324f3852a80b43b8a194afa5 -> tool:nanobot-harness-v3:call_05bb66e4627d459ca1066130 -> tool:nanobot-harness-v3:call_dca5c9f776ed426485da94a4 -> tool:nanobot-harness-v3:call_f6f4dd000fdb49e9ac567e70 -> tool:nanobot-harness-v3:call_69b59fa2a1084606ac4161df -> tool:nanobot-harness-v3:call_8116f683601846f2b81e40ff -> tool:nanobot-harness-v3:call_e4b57639ab514173896656c2 -> tool:nanobot-harness-v3:call_683a1497da80416eb4db58b8 -> tool:nanobot-harness-v3:call_dffb8c5fb86b4dea892eb8bd -> tool:nanobot-harness-v3:call_7777081d5db446a6a93e176e -> tool:nanobot-harness-v3:call_b833f8f2a2684012bdd5f5f0 -> tool:nanobot-harness-v3:call_09e1e689e10a4ebe93836188 -> tool:nanobot-harness-v3:call_4ddf4ac5441b41de98012fd9 -> tool:nanobot-harness-v3:call_1d76c06693484985b9ed291f -> tool:nanobot-harness-v3:call_3c9ad2b90a5f44caab1b7d64 -> tool:nanobot-harness-v3:call_f140122b72424266bc1906f2 -> tool:nanobot-harness-v3:call_80bc4ed82cd14f9691ab8206 -> tool:nanobot-harness-v3:call_77e54bafa9ff44eab6098c7b -> tool:nanobot-harness-v3:call_32f3de5763ed4213837fbadf -> tool:nanobot-harness-v3:call_4af8c1b784f34b90a1a7752a -> tool:nanobot-harness-v3:call_2cfe40940ef9400897b85653 -> tool:nanobot-harness-v3:call_3758e769a9a542b1b26bc5c9 -> tool:nanobot-harness-v3:call_e02af10931074346bc4cf55a -> tool:nanobot-harness-v3:call_a1c5bb4a08d14707b69e4e45 -> tool:nanobot-harness-v3:call_5f7674d3b5334a518cbcfa43 -> tool:nanobot-harness-v3:call_db716cf9ab584d259d01851f -> tool:nanobot-harness-v3:call_d25aedc0a25b49e4aa4cc116 -> tool:nanobot-harness-v3:call_612c73a27bc345c583a1546e -> tool:nanobot-harness-v3:call_aadb8e44fe3c4ee0ae18c470 -> tool:nanobot-harness-v3:call_4774f9bd2fb046c28b52d51b -> tool:nanobot-harness-v3:call_c748be622f524cab83b69fc4 -> tool:nanobot-harness-v3:call_b14c8c0ea9254684b573dcf4 -> tool:nanobot-harness-v3:call_949700dbe8504a149b16c252 -> tool:nanobot-harness-v3:call_9747ccfed88d4d2abb463ccb -> tool:nanobot-harness-v3:call_6ea794301bd04533b40a701c -> tool:nanobot-harness-v3:call_b58e96fb2085479ab88af4ef -> tool:nanobot-harness-v3:call_678bd43257744dcc9395871a -> tool:nanobot-harness-v3:call_7aafc6f5082f48f589140da1 -> tool:nanobot-harness-v3:call_868a07b0dbe947beb42e1f2f -> tool:nanobot-harness-v3:call_57d8f44469944fb28f2d1526 -> tool:nanobot-harness-v3:call_25da129bd4264aa8807dad9a -> tool:nanobot-harness-v3:call_c76db2d5814048e7a505d2c8 -> tool:nanobot-harness-v3:call_4d02463c11fd4580ae08e0c3 -> tool:nanobot-harness-v3:call_3826549744594e8ab4257ff3 -> tool:nanobot-harness-v3:call_9d8b80e3dd884b3ba425107d -> tool:nanobot-harness-v3:call_0c240eeca05b44f2961c8f8c -> tool:nanobot-harness-v3:call_68ec07aaef084c32b7416c04 -> tool:nanobot-harness-v3:call_15ab252aa56a47829e8b48bc -> tool:nanobot-harness-v3:call_3ab3f9f355db4db59be88893 -> tool:nanobot-harness-v3:call_c2ac92feec114c26971298ed -> tool:nanobot-harness-v3:call_610a8be3580c4fc0938a9d0f -> tool:nanobot-harness-v3:call_5112c94356e04ffe805ba5b9 -> tool:nanobot-harness-v3:call_88235c7d545b4757a723ba2a -> tool:nanobot-harness-v3:call_b11a6079837441f1b92e937f -> tool:nanobot-harness-v3:call_21627cf3c41f47669d8ffb7e -> tool:nanobot-harness-v3:call_8704855ca2fc47ee9e1aa636 -> tool:nanobot-harness-v3:call_9174bfd2a8d441f2937c5be9 -> tool:nanobot-harness-v3:call_2c7350f5674c439fae2ecce1 -> tool:nanobot-harness-v3:call_dc622fcc006043f39deec89f -> tool:nanobot-harness-v3:call_9790a57d05e54f81837f79bc -> tool:nanobot-harness-v3:call_bb19084b8c374011a2f52355 -> tool:nanobot-harness-v3:call_812b9290daaa44ebadf02522 -> tool:nanobot-harness-v3:call_f4d0bdfa3a8d4f499be95714 -> tool:nanobot-harness-v3:call_784845289d5e4c0cb9ac25fb -> tool:nanobot-harness-v3:call_f14fa0710d954510b4cd9aea -> tool:nanobot-harness-v3:call_be9b5bb6860c4b7c8b7fe243 -> tool:nanobot-harness-v3:call_6d8f8e376c8b41548a9d3c72 -> tool:nanobot-harness-v3:call_5b137e26b70b4f6da196d2bf -> tool:nanobot-harness-v3:call_8381d4d8ac374a69a18636d0 -> tool:nanobot-harness-v3:call_f112dd1220e64b2c96067954 -> tool:nanobot-harness-v3:call_5b299ccc12cc4c0a8e959feb -> tool:nanobot-harness-v3:call_e9ad50746cad4b6baa1d0dae -> tool:nanobot-harness-v3:call_6acca29228a04b41bb9a73c9 -> tool:nanobot-harness-v3:call_a2f1e05378a84e9dbd936cde -> tool:nanobot-harness-v3:call_b694f71b16b9436f92747202 -> tool:nanobot-harness-v3:call_3ad1ba7dc25b4022908241ba -> tool:nanobot-harness-v3:call_6e3778fba021410098540124 -> tool:nanobot-harness-v3:call_cb446af7e6734bf28afd012f
- 关键路径耗时：1.135716
- Makespan：433.890523
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
