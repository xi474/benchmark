def transform(payloads, contract):
    """cancel_morning: select morning social uncancelled events and cancel them."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError('input must be object')

    for key in ('events', 'day', 'contacts'):
        if key not in data:
            raise ValueError(f'missing field: {key}')

    events = data['events']
    day = data['day']
    contacts = data['contacts']

    if not isinstance(events, list):
        raise ValueError('events must be array')
    if not isinstance(day, int) or isinstance(day, bool):
        raise ValueError('day must be integer')
    if day < 0:
        raise ValueError('day must be >= 0')
    if not isinstance(contacts, list):
        raise ValueError('contacts must be array')

    # Validate events
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError('event must be object')
        for k in ('id', 'start', 'end', 'social', 'cancelled', 'attendees'):
            if k not in ev:
                raise ValueError(f'event missing field: {k}')
        if not isinstance(ev['id'], str):
            raise ValueError('event id must be string')
        if not isinstance(ev['start'], int) or isinstance(ev['start'], bool):
            raise ValueError('event start must be integer')
        if not isinstance(ev['end'], int) or isinstance(ev['end'], bool):
            raise ValueError('event end must be integer')
        if not isinstance(ev['social'], bool):
            raise ValueError('event social must be bool')
        if not isinstance(ev['cancelled'], bool):
            raise ValueError('event cancelled must be bool')
        if not isinstance(ev['attendees'], list):
            raise ValueError('event attendees must be array')

    # Validate contacts
    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError('contact must be object')
        for k in ('id', 'email', 'message', 'chat'):
            if k not in c:
                raise ValueError(f'contact missing field: {k}')

    day_start = day * 1440
    day_morning_end = day_start + 720

    cancelled_ids = []
    snapshots = {}
    remaining = {}

    for ev in events:
        eid = ev['id']
        start = ev['start']
        end = ev['end']
        social = ev['social']
        already_cancelled = ev['cancelled']

        is_target = (
            day_start <= start < day_morning_end
            and social
            and not already_cancelled
            and end > start
        )

        if is_target:
            cancelled_ids.append(eid)
            snapshots[eid] = dict(ev)
        else:
            remaining[eid] = dict(ev)

    cancelled_ids.sort()

    result = {
        'cancelled': cancelled_ids,
        'snapshots': snapshots,
        'remaining': remaining,
    }

    return {'name': contract['name'], 'result': result}
