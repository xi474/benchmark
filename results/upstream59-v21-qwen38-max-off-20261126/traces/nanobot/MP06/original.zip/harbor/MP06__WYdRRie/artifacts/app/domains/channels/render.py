import json
import sys
from pathlib import Path

# Ensure the component directory is on sys.path for local imports
_comp_dir = str(Path(__file__).resolve().parent)
if _comp_dir not in sys.path:
    sys.path.insert(0, _comp_dir)

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read all inputs from root, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with standard formatting."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    comp_dir = Path(__file__).resolve().parent
    root = comp_dir.parents[1]  # workspace root
    contract_path = comp_dir / 'contract.json'
    result = build_component(root, contract_path)
    contract = load_payload(contract_path)
    output_path = root / contract['output']
    _write_json(output_path, result)
