def transform(payloads, contract):
    """channel_directory: build contact channel directory."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError('input must be object')

    for key in ('events', 'day', 'contacts'):
        if key not in data:
            raise ValueError(f'missing field: {key}')

    contacts = data['contacts']
    if not isinstance(contacts, list):
        raise ValueError('contacts must be array')

    seen_ids = set()
    result_contacts = {}

    for c in contacts:
        if not isinstance(c, dict):
            raise ValueError('contact must be object')
        for k in ('id', 'email', 'message', 'chat'):
            if k not in c:
                raise ValueError(f'contact missing field: {k}')

        cid = c['id']
        email = c['email']
        message = c['message']
        chat = c['chat']

        if not isinstance(cid, str):
            raise ValueError('contact id must be string')
        if cid in seen_ids:
            raise ValueError(f'duplicate contact id: {cid}')
        seen_ids.add(cid)

        # Validate email/message/chat: must be null or non-empty string
        for field_name, val in [('email', email), ('message', message), ('chat', chat)]:
            if val is not None:
                if not isinstance(val, str):
                    raise ValueError(f'{field_name} must be null or string')
                if val.strip() == '':
                    raise ValueError(f'{field_name} must be non-empty when present')

        # Primary channel: prefer message, then chat; email independent
        primary = None
        address = None
        if message is not None:
            primary = 'message'
            address = message
        elif chat is not None:
            primary = 'chat'
            address = chat

        result_contacts[cid] = {
            'email': email,
            'primary': primary,
            'address': address,
        }

    return {'name': contract['name'], 'result': {'contacts': result_contacts}}
