"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core['components']
    title = '取消日程后多渠道通知'
    component_count = len(components)

    # SHA256 of the complete core object
    core_bytes = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False,
    ).encode('utf-8')
    sha256 = hashlib.sha256(core_bytes).hexdigest()

    # Attention: components with specific conditions
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for flag in ('complete', 'checkout', 'committed', 'ok'):
            if flag in result and result[flag] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for field in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(field)
            if val is not None and val != [] and val != {} and val != '':
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention_list,
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out_path.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
