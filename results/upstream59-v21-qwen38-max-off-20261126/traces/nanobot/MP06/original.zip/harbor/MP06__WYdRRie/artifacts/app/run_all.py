"""Orchestrate all components based on contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Handle environments where sys.executable is empty
PYTHON = sys.executable if sys.executable else 'python3'


def main():
    # Find all contract.json files (excluding outputs directory)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print('No contracts found', file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: component name -> contract path
    comp_contracts = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_contracts[c['name']] = cp

    # Topological sort based on input dependencies
    # A component depends on another if any of its inputs reference that component's output
    comp_outputs = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_outputs[c['output']] = c['name']

    # Build adjacency: component -> set of components it depends on
    deps = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        deps[name] = set()
        for inp in c['inputs']:
            if inp in comp_outputs:
                deps[name].add(comp_outputs[inp])

    # Topological sort (Kahn's algorithm)
    in_degree = {name: 0 for name in deps}
    for name, dep_set in deps.items():
        for d in dep_set:
            pass  # we count incoming edges below

    # Recompute in-degree properly
    in_degree = {name: 0 for name in deps}
    reverse_deps = {name: set() for name in deps}
    for name, dep_set in deps.items():
        for d in dep_set:
            reverse_deps[d].add(name)
            in_degree[name] += 1

    queue = sorted([n for n in in_degree if in_degree[n] == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for dependent in sorted(reverse_deps[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
                queue.sort()

    if len(order) != len(deps):
        print('Circular dependency detected', file=sys.stderr)
        sys.exit(1)

    # Execute components in topological order
    for name in order:
        cp = comp_contracts[name]
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f'Missing render.py for {name}', file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print(f'Component {name} failed:', file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print('integrate.py failed:', file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py to produce final_report.json
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [PYTHON, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print('final_report.py failed:', file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
