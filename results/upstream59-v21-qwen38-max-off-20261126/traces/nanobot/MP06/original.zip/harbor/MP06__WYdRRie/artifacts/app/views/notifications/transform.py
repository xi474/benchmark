def transform(payloads, contract):
    """cancel_notifications: build notification outbox from calendar and channel results."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')

    cal_result = payloads[0]
    chan_result = payloads[1]

    # When input object has keys exactly name/result, only result is business input
    if isinstance(cal_result, dict) and set(cal_result.keys()) == {'name', 'result'}:
        cal_result = cal_result['result']
    if isinstance(chan_result, dict) and set(chan_result.keys()) == {'name', 'result'}:
        chan_result = chan_result['result']

    cancelled_ids = cal_result['cancelled']
    snapshots = cal_result['snapshots']
    contacts_dir = chan_result['contacts']

    # Collect all attendees from target snapshots (union, dedup)
    all_attendees = set()
    for eid in cancelled_ids:
        ev = snapshots[eid]
        for aid in ev['attendees']:
            all_attendees.add(aid)

    # Validate all attendee IDs exist in contacts directory
    for aid in all_attendees:
        if aid not in contacts_dir:
            raise ValueError(f'unknown contact id: {aid}')

    requires = sorted(cancelled_ids)

    outbox = []
    unreachable = []
    group_members = []

    for aid in sorted(all_attendees):
        cinfo = contacts_dir[aid]
        email_addr = cinfo['email']
        primary = cinfo['primary']
        address = cinfo['address']

        has_email = email_addr is not None
        has_primary = primary is not None

        # Each contact with email gets an independent email
        if has_email:
            outbox.append({
                'channel': 'email',
                'to': aid,
                'recipients': [aid],
                'requires': requires,
            })

        # Primary channel handling
        if primary == 'message':
            # message preferred -> join group
            group_members.append(aid)
        elif primary == 'chat':
            # chat fallback -> individual chat message
            outbox.append({
                'channel': 'chat',
                'to': aid,
                'recipients': [aid],
                'requires': requires,
            })

        # If neither email nor any primary channel -> unreachable
        if not has_email and not has_primary:
            unreachable.append(aid)

    unreachable.sort()

    # Build group if there are message-preferred members
    group = None
    if group_members:
        group_members.sort()
        group_id = 'cancelled-social'
        group = {
            'id': group_id,
            'members': group_members,
            'requires': requires,
        }
        outbox.append({
            'channel': 'message_group',
            'to': group_id,
            'recipients': group_members,
            'requires': requires,
        })

    # Sort outbox by (channel, to)
    outbox.sort(key=lambda x: (x['channel'], x['to']))

    result = {
        'outbox': outbox,
        'unreachable': unreachable,
        'group': group,
    }

    return {'name': contract['name'], 'result': result}
