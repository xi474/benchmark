# Workflow 可观测性报告

- Trial：`MP07__SXbtAFu__env`
- Task：`MP07`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（82 节点 / 81 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：82；执行边：81（observed=0，inferred=81）
- Execution Trace Graph：`observed`；temporal_next 边 81，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_fb318064f80a41588d72bd48 -> tool:nanobot-harness-v3:call_08f724a29ffb44d2b402a02e -> tool:nanobot-harness-v3:call_83a3b921a340437ab30c9984 -> tool:nanobot-harness-v3:call_e568c3b1927748c5bf7bcd20 -> tool:nanobot-harness-v3:call_3eb48314fa914b26baff95a6 -> tool:nanobot-harness-v3:call_11458467f0da4ab3b29312ab -> tool:nanobot-harness-v3:call_bb913fbd59894a0c98242ea0 -> tool:nanobot-harness-v3:call_351872d3064c427f83251d45 -> tool:nanobot-harness-v3:call_051dc4a19f454d3b921830b1 -> tool:nanobot-harness-v3:call_7d64a40b92d942318b932a58 -> tool:nanobot-harness-v3:call_287c6d6fbcbe49669256c4a3 -> tool:nanobot-harness-v3:call_c7cc075f6f6243438f5bc145 -> tool:nanobot-harness-v3:call_0bf9fee0fcbd4c17918df215 -> tool:nanobot-harness-v3:call_ffff1681adcc4c6f8b125abf -> tool:nanobot-harness-v3:call_84ccafd8a58746c38dec71a4 -> tool:nanobot-harness-v3:call_24c62cca077b45b6af0e4f33 -> tool:nanobot-harness-v3:call_e38247da94a5445299e49fce -> tool:nanobot-harness-v3:call_937848447858493b8be5d9df -> tool:nanobot-harness-v3:call_16bb2cf506c240c4bca8b1e3 -> tool:nanobot-harness-v3:call_9628e5a4f76e49d4aff9cb8a -> tool:nanobot-harness-v3:call_e140a4bc879541baa3d6d620 -> tool:nanobot-harness-v3:call_f994af52a19149dab077e2a9 -> tool:nanobot-harness-v3:call_6b1ce356752242739d68e8c5 -> tool:nanobot-harness-v3:call_b39d34e46eb54c88b3d60b52 -> tool:nanobot-harness-v3:call_c837b11b28bd46a4aa67e59b -> tool:nanobot-harness-v3:call_a022306bb987424eaa66d118 -> tool:nanobot-harness-v3:call_39a610c05fbb464489366b38 -> tool:nanobot-harness-v3:call_753fa4ea21ea40f6b80d6036 -> tool:nanobot-harness-v3:call_5ca1c41dc9ed475386a59014 -> tool:nanobot-harness-v3:call_2e44dc004d2b4e4297c6bc94 -> tool:nanobot-harness-v3:call_39c2c68f51bc40daadb75711 -> tool:nanobot-harness-v3:call_263fba5ca31f48589fa732d9 -> tool:nanobot-harness-v3:call_59fb272ca56c4fdb85ad795d -> tool:nanobot-harness-v3:call_124f02e4c9b146bd9d77714e -> tool:nanobot-harness-v3:call_f67d6a1690b44eb1a451f540 -> tool:nanobot-harness-v3:call_ef0765054270490088ca689d -> tool:nanobot-harness-v3:call_97e97ec383234c12ab59e453 -> tool:nanobot-harness-v3:call_33bc645b9494443485bb9cd3 -> tool:nanobot-harness-v3:call_cf6b5c3ce23b4e56b2b75c0e -> tool:nanobot-harness-v3:call_0b647ff549d244b4aaa998bb -> tool:nanobot-harness-v3:call_783fced10a914d1883df04de -> tool:nanobot-harness-v3:call_28d183081f99478ea3ded775 -> tool:nanobot-harness-v3:call_492e2439596d4744800204d3 -> tool:nanobot-harness-v3:call_7ef3e14ace164f47938d2d4f -> tool:nanobot-harness-v3:call_dc56bcbfa7b545e6b8f41b85 -> tool:nanobot-harness-v3:call_2e260239d9e74347914d65c2 -> tool:nanobot-harness-v3:call_982ee21779a64a7bb748750b -> tool:nanobot-harness-v3:call_3f855622df3a419684d5d4b2 -> tool:nanobot-harness-v3:call_1b7d1331f1a842bb94560b68 -> tool:nanobot-harness-v3:call_ac279f41a1064d68b8006fa9 -> tool:nanobot-harness-v3:call_1f995aee85ff4aed905b4d21 -> tool:nanobot-harness-v3:call_6d5764923713453aa7268a56 -> tool:nanobot-harness-v3:call_d1e6e701abe64a78823210dd -> tool:nanobot-harness-v3:call_ce15e0552100475fa4c2fe98 -> tool:nanobot-harness-v3:call_2cde1debaffc414eb8f83232 -> tool:nanobot-harness-v3:call_16f3ecace5364e8c92511431 -> tool:nanobot-harness-v3:call_01af41b08d8a4e718d2cc637 -> tool:nanobot-harness-v3:call_082a563ccbde46a1a8a0ce9a -> tool:nanobot-harness-v3:call_eb6265211ee84db581d1f9f9 -> tool:nanobot-harness-v3:call_77e2d7076d0e4161a25e2cdf -> tool:nanobot-harness-v3:call_de77404493c0402eac019fe7 -> tool:nanobot-harness-v3:call_3252c2d990384d228b1b996a -> tool:nanobot-harness-v3:call_cfe51cf8df97430190609629 -> tool:nanobot-harness-v3:call_cabd140255894623977666bf -> tool:nanobot-harness-v3:call_6d4961b430234a6a8ec1ada3 -> tool:nanobot-harness-v3:call_50db2847531941519dabf0e3 -> tool:nanobot-harness-v3:call_ac4cf35ac2244fb9bdc043e4 -> tool:nanobot-harness-v3:call_6eb9223e96864594a8251898 -> tool:nanobot-harness-v3:call_e1de6e8821234905853caecb -> tool:nanobot-harness-v3:call_d05a22974ffa481997cd67ba -> tool:nanobot-harness-v3:call_5b750b78eb544c0b9a66307a -> tool:nanobot-harness-v3:call_624ea90e507745a3913a594f -> tool:nanobot-harness-v3:call_419462ffdc4f4ea79695cdcb -> tool:nanobot-harness-v3:call_523b9805048a4e2185a9f947 -> tool:nanobot-harness-v3:call_c271391fcbff495eb68ac818 -> tool:nanobot-harness-v3:call_8eb656c2e57143b2864724d3 -> tool:nanobot-harness-v3:call_b4dc4413b66a41a4b7458ec7 -> tool:nanobot-harness-v3:call_a9d91df6b34c46b2a2af311d -> tool:nanobot-harness-v3:call_274fa425b43f4634858aa5e9 -> tool:nanobot-harness-v3:call_933753a5cb82438db4572a39 -> tool:nanobot-harness-v3:call_7b580626c7f9438dbfe0c346
- 关键路径耗时：1.426073
- Makespan：414.227581
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
