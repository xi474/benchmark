#!/usr/bin/env python3
"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)
    
    # title is fixed
    title = "附件发送后归档与独立清理"
    
    # component_count is number of keys in components
    components = core.get("components", {})
    component_count = len(components)
    
    # sha256 of the complete core object serialized compactly
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    sha256 = hashlib.sha256(canonical).hexdigest()
    
    # attention: component names where any trigger condition is met
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0:
                # Non-empty check: list/dict/string must be non-empty
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)
    
    attention_list = sorted(attention)
    
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_list,
    }
    
    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    out_path.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    main()
