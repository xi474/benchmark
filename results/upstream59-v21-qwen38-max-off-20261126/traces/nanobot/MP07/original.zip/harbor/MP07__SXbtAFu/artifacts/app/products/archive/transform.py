def _validate_safe_path(p):
    """Validate a safe relative POSIX path."""
    if not isinstance(p, str):
        raise ValueError(f"path must be string: {p!r}")
    if not p or "\\" in p or ":" in p:
        raise ValueError(f"unsafe path: {p!r}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"unsafe path segment in: {p!r}")
    if p.startswith("/"):
        raise ValueError(f"absolute path: {p!r}")


def transform(payloads, contract):
    """archive_after_send operation.
    
    Inputs (in order): case, receipts_result, cleanup_result
    - case: original input with files, attachments, archive_prefix, etc.
    - receipts_result: {"name":"receipts","result":{"attachments":[...],"receipts":[...]}}
    - cleanup_result: {"name":"cleanup","result":{"delete":[...]}}
    
    Only move attachments to archive_prefix/ if ALL receipts.ok are true AND at least one recipient.
    Cleanup delete always executes.
    Duplicate targets, target already exists, cleanup/move source overlap => ValueError.
    
    Output: {moves:[{from,to}], deleted:[path], blocked:bool, files:[{path,hex}]}
    moves sorted by from, files sorted by path. Bytes unchanged.
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    case = payloads[0]
    receipts_payload = payloads[1]
    cleanup_payload = payloads[2]
    
    # Extract results from upstream component outputs
    # When input object keys are exactly name/result, only result is business input
    if isinstance(receipts_payload, dict) and set(receipts_payload.keys()) == {"name", "result"}:
        receipts_data = receipts_payload["result"]
    else:
        receipts_data = receipts_payload
    
    if isinstance(cleanup_payload, dict) and set(cleanup_payload.keys()) == {"name", "result"}:
        cleanup_data = cleanup_payload["result"]
    else:
        cleanup_data = cleanup_payload
    
    # Validate case fields
    for field in ("files", "attachments", "archive_prefix"):
        if field not in case:
            raise ValueError(f"missing field: {field}")
    
    files = case["files"]
    attachments = case["attachments"]
    archive_prefix = case["archive_prefix"]
    
    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be list")
    if not isinstance(archive_prefix, str):
        raise ValueError("archive_prefix must be string")
    _validate_safe_path(archive_prefix)
    
    # Build file map
    file_map = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path or hex")
        fp = f["path"]
        _validate_safe_path(fp)
        if fp in file_map:
            raise ValueError(f"duplicate file path: {fp}")
        file_map[fp] = f["hex"]
    
    # Get receipts info
    receipts_list = receipts_data.get("receipts", [])
    all_ok = len(receipts_list) > 0 and all(r.get("ok", False) is True for r in receipts_list)
    
    # Get cleanup delete list
    delete_paths = cleanup_data.get("delete", [])
    
    # Determine unique sorted attachments (same logic as receipts)
    seen_att = set()
    unique_attachments = []
    for a in attachments:
        if not isinstance(a, str):
            raise ValueError("attachment must be string")
        _validate_safe_path(a)
        if a not in file_map:
            raise ValueError(f"attachment not in files: {a}")
        if a not in seen_att:
            seen_att.add(a)
            unique_attachments.append(a)
    unique_attachments.sort()
    
    # Check for overlaps between cleanup delete sources and move sources
    delete_set = set(delete_paths)
    move_sources = set(unique_attachments) if all_ok else set()
    
    if delete_set & move_sources:
        raise ValueError("cleanup and move sources overlap")
    
    # Build moves
    moves = []
    if all_ok:
        target_set = set()
        for apath in unique_attachments:
            target = archive_prefix + "/" + apath
            _validate_safe_path(target)
            if target in target_set:
                raise ValueError(f"duplicate move target: {target}")
            # Target must not already exist as a file in our file map
            if target in file_map:
                raise ValueError(f"move target already exists: {target}")
            target_set.add(target)
            moves.append({"from": apath, "to": target})
    
    # Sort moves by from
    moves.sort(key=lambda m: m["from"])
    
    # Deleted paths sorted
    deleted = sorted(delete_paths)
    
    # Files: all original files with their hex, sorted by path
    files_out = []
    for f in files:
        files_out.append({"path": f["path"], "hex": f["hex"]})
    files_out.sort(key=lambda x: x["path"])
    
    blocked = not all_ok
    
    result = {
        "moves": moves,
        "deleted": deleted,
        "blocked": blocked,
        "files": files_out,
    }
    
    return {"name": contract["name"], "result": result}
