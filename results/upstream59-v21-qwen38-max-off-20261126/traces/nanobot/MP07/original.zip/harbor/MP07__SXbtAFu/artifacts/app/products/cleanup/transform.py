def _validate_safe_path(p):
    """Validate a safe relative POSIX path."""
    if not isinstance(p, str):
        raise ValueError(f"path must be string: {p!r}")
    if not p or "\\" in p or ":" in p:
        raise ValueError(f"unsafe path: {p!r}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"unsafe path segment in: {p!r}")
    if p.startswith("/"):
        raise ValueError(f"absolute path: {p!r}")


def _is_under_prefix(filepath, prefix):
    """Check if filepath is under the given prefix directory.
    
    Uses path segment boundary matching: home/tmp should NOT match home/tmp-old.
    The file must start with prefix + '/' and end with .tmp.
    """
    # filepath must start with prefix followed by /
    if not filepath.startswith(prefix + "/"):
        return False
    # Must end with .tmp
    if not filepath.endswith(".tmp"):
        return False
    return True


def transform(payloads, contract):
    """independent_cleanup operation.
    
    Input: same as attachment_receipts case object.
    Select all files under cleanup_prefix that end with .tmp (by path segment boundary).
    Output: {delete:[sorted paths]}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    case = payloads[0]
    
    for field in ("files", "cleanup_prefix"):
        if field not in case:
            raise ValueError(f"missing field: {field}")
    
    files = case["files"]
    cleanup_prefix = case["cleanup_prefix"]
    
    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(cleanup_prefix, str):
        raise ValueError("cleanup_prefix must be string")
    _validate_safe_path(cleanup_prefix)
    
    delete_list = []
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f:
            raise ValueError("file entry missing path")
        fp = f["path"]
        _validate_safe_path(fp)
        if _is_under_prefix(fp, cleanup_prefix):
            delete_list.append(fp)
    
    delete_list.sort()
    
    result = {"delete": delete_list}
    return {"name": contract["name"], "result": result}
