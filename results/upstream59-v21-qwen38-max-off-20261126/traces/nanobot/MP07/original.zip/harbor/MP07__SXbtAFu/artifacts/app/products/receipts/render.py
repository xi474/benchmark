import json
import sys
from pathlib import Path

# Ensure local imports work when run as script
_dir = Path(__file__).resolve().parent
if str(_dir) not in sys.path:
    sys.path.insert(0, str(_dir))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, call transform, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


def _write_json(path, data):
    """Write JSON with standard formatting."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    path.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    cp = Path(__file__).resolve().with_name("contract.json")
    # Support arbitrary cwd: resolve root from contract location
    root = cp.resolve().parents[2]
    result = build_component(root, cp)
    contract = load_payload(cp)
    out_path = root / contract["output"]
    _write_json(out_path, result)
