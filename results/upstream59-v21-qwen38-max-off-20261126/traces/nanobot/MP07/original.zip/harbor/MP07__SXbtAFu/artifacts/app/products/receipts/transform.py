import hashlib


def _validate_safe_path(p):
    """Validate a safe relative POSIX path."""
    if not isinstance(p, str):
        raise ValueError(f"path must be string: {p!r}")
    if not p or "\\" in p or ":" in p:
        raise ValueError(f"unsafe path: {p!r}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"unsafe path segment in: {p!r}")
    if p.startswith("/"):
        raise ValueError(f"absolute path: {p!r}")


def transform(payloads, contract):
    """attachment_receipts operation.
    
    Input: {files:[{path,hex}], attachments:[path], recipients:[id], send_ok:{id:bool}, cleanup_prefix:str, archive_prefix:str}
    Output: {attachments:[{path,sha256}], receipts:[{recipient,ok}]}
    """
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    
    case = payloads[0]
    
    # Validate required fields
    for field in ("files", "attachments", "recipients", "send_ok", "cleanup_prefix", "archive_prefix"):
        if field not in case:
            raise ValueError(f"missing field: {field}")
    
    files = case["files"]
    attachments = case["attachments"]
    recipients = case["recipients"]
    send_ok = case["send_ok"]
    
    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be list")
    if not isinstance(recipients, list):
        raise ValueError("recipients must be list")
    if not isinstance(send_ok, dict):
        raise ValueError("send_ok must be object")
    
    # Build file map: path -> hex
    file_map = {}
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if "path" not in f or "hex" not in f:
            raise ValueError("file entry missing path or hex")
        fp = f["path"]
        _validate_safe_path(fp)
        if fp in file_map:
            raise ValueError(f"duplicate file path: {fp}")
        file_map[fp] = f["hex"]
    
    # Attachments: deduplicate and sort, must exist in files
    seen_attachments = set()
    unique_attachments = []
    for a in attachments:
        if not isinstance(a, str):
            raise ValueError("attachment must be string")
        _validate_safe_path(a)
        if a not in file_map:
            raise ValueError(f"attachment not in files: {a}")
        if a not in seen_attachments:
            seen_attachments.add(a)
            unique_attachments.append(a)
    unique_attachments.sort()
    
    # Compute sha256 for each attachment from original bytes (hex decoded)
    att_results = []
    for apath in unique_attachments:
        raw_bytes = bytes.fromhex(file_map[apath])
        sha = hashlib.sha256(raw_bytes).hexdigest()
        att_results.append({"path": apath, "sha256": sha})
    
    # Recipients: unique non-empty ids
    seen_recipients = set()
    for r in recipients:
        if not isinstance(r, str):
            raise ValueError("recipient must be string")
        if not r.strip():
            raise ValueError("recipient empty after strip")
        if r in seen_recipients:
            raise ValueError(f"duplicate recipient: {r}")
        seen_recipients.add(r)
    
    # send_ok values must be bool
    for rid, val in send_ok.items():
        if not isinstance(val, bool):
            raise ValueError(f"send_ok value must be bool for {rid}")
    
    # Build receipts sorted by recipient id
    receipt_list = []
    for r in sorted(recipients):
        if r not in send_ok:
            raise ValueError(f"recipient {r} not in send_ok")
        receipt_list.append({"recipient": r, "ok": send_ok[r]})
    
    result = {
        "attachments": att_results,
        "receipts": receipt_list,
    }
    
    return {"name": contract["name"], "result": result}
