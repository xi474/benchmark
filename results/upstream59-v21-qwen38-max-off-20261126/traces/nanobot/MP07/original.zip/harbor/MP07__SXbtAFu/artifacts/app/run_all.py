#!/usr/bin/env python3
"""Run all components in dependency order, then integrate."""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _python():
    """Return a working python executable path."""
    if sys.executable:
        return sys.executable
    # Fallback: try to find python3 via /proc or PATH
    try:
        return os.readlink("/proc/self/exe")
    except (OSError, AttributeError):
        pass
    for d in os.environ.get("PATH", "").split(":"):
        c = os.path.join(d, "python3")
        if os.path.isfile(c):
            return c
    return "python3"


def run_component(component_dir):
    """Run a component's render.py as a subprocess."""
    render_py = component_dir / "render.py"
    if not render_py.is_file():
        raise FileNotFoundError(f"render.py not found in {component_dir}")
    result = subprocess.run(
        [_python(), str(render_py)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0:
        print(f"FAILED: {render_py}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)


def main():
    # Determine execution order from contracts
    # receipts and cleanup depend only on inputs/case.json
    # archive depends on outputs/receipts.json and outputs/cleanup.json
    
    # Phase 1: independent components
    run_component(ROOT / "products" / "receipts")
    run_component(ROOT / "products" / "cleanup")
    
    # Phase 2: dependent components
    run_component(ROOT / "products" / "archive")
    
    # Phase 3: integrate
    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        result = subprocess.run(
            [_python(), str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print("FAILED: integrate.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
    
    # Phase 4: final report
    final_report_py = ROOT / "final_report.py"
    if final_report_py.is_file():
        result = subprocess.run(
            [_python(), str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print("FAILED: final_report.py", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
