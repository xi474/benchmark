#!/usr/bin/env python3
"""Wrapper to fix sys.executable and run check.py"""
import sys
import os

# Fix sys.executable if empty
if not sys.executable:
    sys.executable = "python3"

# Now run check.py
import runpy
runpy.run_path("check.py", run_name="__main__")
