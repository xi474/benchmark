# Workflow 可观测性报告

- Trial：`MP08__Ss6wv3D__env`
- Task：`MP08`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（78 节点 / 77 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：78；执行边：77（observed=0，inferred=77）
- Execution Trace Graph：`observed`；temporal_next 边 77，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_4ee9ce33b7674c25a0473213 -> tool:nanobot-harness-v3:call_a6a0228ab5bc468eb97248d8 -> tool:nanobot-harness-v3:call_3e288c806e864cc4acf7e0a5 -> tool:nanobot-harness-v3:call_9869ca8f690849088dd891ce -> tool:nanobot-harness-v3:call_3ec2ce79daed4b7e9befd55a -> tool:nanobot-harness-v3:call_90d295b343af40e78bf7b4b2 -> tool:nanobot-harness-v3:call_b9b36707b8254b2d82d0955f -> tool:nanobot-harness-v3:call_86cfbc5672a64dbb806a8678 -> tool:nanobot-harness-v3:call_76e65cd2def24d5f8770dcfd -> tool:nanobot-harness-v3:call_1f68203028594f29be3ee8ab -> tool:nanobot-harness-v3:call_1f1c448fd53d41f3a0cefbb0 -> tool:nanobot-harness-v3:call_9533189657fb49d7b200f970 -> tool:nanobot-harness-v3:call_d5577e949e0d4b018bd14fb7 -> tool:nanobot-harness-v3:call_86ecbe7cf6324603aa18517f -> tool:nanobot-harness-v3:call_0aaa56ac8ac1414a92292b45 -> tool:nanobot-harness-v3:call_d59652b6f6ec481ab9f40e2e -> tool:nanobot-harness-v3:call_eab4f24f7ec4454abb1008ed -> tool:nanobot-harness-v3:call_c4db370ce5b54abfaf91ed12 -> tool:nanobot-harness-v3:call_93ee1d2a29f64e7699afbb57 -> tool:nanobot-harness-v3:call_721231251d3342ff850a623e -> tool:nanobot-harness-v3:call_963a1a959af8469783b9de07 -> tool:nanobot-harness-v3:call_986324fafc544e6983d5d42d -> tool:nanobot-harness-v3:call_beb9b649bc744164a9897983 -> tool:nanobot-harness-v3:call_3b0907be64eb444495d9a3cc -> tool:nanobot-harness-v3:call_5c0450ca627e43799d7acf66 -> tool:nanobot-harness-v3:call_8395cc4511ef4f369e6fd484 -> tool:nanobot-harness-v3:call_5a9fbd7900a449a193288200 -> tool:nanobot-harness-v3:call_65260d1eccf3498fbc727e21 -> tool:nanobot-harness-v3:call_9ab06115f7d8460e92b6b1b8 -> tool:nanobot-harness-v3:call_a41aacfb44594339b6892630 -> tool:nanobot-harness-v3:call_0074fa1512ae41bba02abfaa -> tool:nanobot-harness-v3:call_2116383a50cf43eca4cb0232 -> tool:nanobot-harness-v3:call_ddfeb8dee26e4f329b91059e -> tool:nanobot-harness-v3:call_dd161cba9eed49a2b38123f9 -> tool:nanobot-harness-v3:call_557d99a623af4719aede048d -> tool:nanobot-harness-v3:call_09771c0c8a95462c8007c2ba -> tool:nanobot-harness-v3:call_8387423310cd4c1ca3b20c2c -> tool:nanobot-harness-v3:call_e51a929f985e442cb65130e9 -> tool:nanobot-harness-v3:call_240e289e98624f72a6eee6b0 -> tool:nanobot-harness-v3:call_43e410e0ab1f4ff0a2936bea -> tool:nanobot-harness-v3:call_05c756a24a6944eba92ff140 -> tool:nanobot-harness-v3:call_fa1f4bfd91954f7e8bb8e97a -> tool:nanobot-harness-v3:call_80eb4135770740738e167014 -> tool:nanobot-harness-v3:call_caf6eefb5eb94f658aa2e0a1 -> tool:nanobot-harness-v3:call_183bcc7284404633896d4893 -> tool:nanobot-harness-v3:call_3047b0eeb59b452389fcf910 -> tool:nanobot-harness-v3:call_4eac764df6a6406a94e99409 -> tool:nanobot-harness-v3:call_5cd509b05c3a4de48b47ed72 -> tool:nanobot-harness-v3:call_b4dfdecd3cbb49d1b852365c -> tool:nanobot-harness-v3:call_2675b0a89a0747948b0af9da -> tool:nanobot-harness-v3:call_4f856b83555f468fa2e5dcff -> tool:nanobot-harness-v3:call_4feaa9fab9ca4fc58fee0d1d -> tool:nanobot-harness-v3:call_2411d91fd37f45b587b38e7f -> tool:nanobot-harness-v3:call_dff42c524bb14c2fb9375c2a -> tool:nanobot-harness-v3:call_57dd46f5ae8d44668a50763c -> tool:nanobot-harness-v3:call_3ffab84f4733497bb7724310 -> tool:nanobot-harness-v3:call_7ade31711d64410c972b5bef -> tool:nanobot-harness-v3:call_86e3059465ac4aae97272b76 -> tool:nanobot-harness-v3:call_57d009ac5d114a198c2efbeb -> tool:nanobot-harness-v3:call_2e32d8881c0f483ea87ccce3 -> tool:nanobot-harness-v3:call_cb7d38de5a664ffd85ce9407 -> tool:nanobot-harness-v3:call_990895986e624a96b54963ed -> tool:nanobot-harness-v3:call_dd4553a58fc24537b07ec2a3 -> tool:nanobot-harness-v3:call_234ac384c9df4809a7efa285 -> tool:nanobot-harness-v3:call_fea3986e8bb547dbb2ae9389 -> tool:nanobot-harness-v3:call_94de43ff754b4c0589a014a4 -> tool:nanobot-harness-v3:call_9f6dcdc667af42538dab1df1 -> tool:nanobot-harness-v3:call_e9064c48d48b4a62883eb54a -> tool:nanobot-harness-v3:call_7f8fa41ad6f942cdb8c48f6a -> tool:nanobot-harness-v3:call_fc54c0617c1340229894c0e7 -> tool:nanobot-harness-v3:call_be74d12ba61644e29f0fa265 -> tool:nanobot-harness-v3:call_d02f5c6ac0b4491abf36406b -> tool:nanobot-harness-v3:call_1c3ed546db0a44a899ee7e90 -> tool:nanobot-harness-v3:call_8fd99eadacd64eacb30d9552 -> tool:nanobot-harness-v3:call_46e24807db7241e685eeb886 -> tool:nanobot-harness-v3:call_410739251c9b4765bba9a60f -> tool:nanobot-harness-v3:call_7c9c2aeb4cc847018a0e9c01
- 关键路径耗时：1.261848
- Makespan：429.65946
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
