import json
import math
from pathlib import Path


def _reject_non_finite(value):
    """Called by json.loads parse_constant for NaN/Infinity tokens."""
    raise ValueError(f"Non-finite JSON value: {value}")


def load_payload(path):
    """Read UTF-8 JSON file. Top-level must be object or array. Reject NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text, parse_constant=_reject_non_finite)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError(f"Top-level must be object or array, got {type(data).__name__}")
    return data
