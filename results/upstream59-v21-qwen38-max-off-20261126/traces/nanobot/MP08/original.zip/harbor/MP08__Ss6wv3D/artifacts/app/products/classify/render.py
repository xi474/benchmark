import json
import sys
from pathlib import Path

# Ensure the component directory is on sys.path for local imports
_component_dir = str(Path(__file__).resolve().parent)
if _component_dir not in sys.path:
    sys.path.insert(0, _component_dir)

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, write output, return envelope."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract["output"]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    return result


if __name__ == "__main__":
    # CLI: python3 render.py <root> <contract_path>
    if len(sys.argv) != 3:
        print("Usage: python3 render.py <root> <contract_path>", file=sys.stderr)
        sys.exit(1)
    root = Path(sys.argv[1]).resolve()
    contract_path = Path(sys.argv[2]).resolve()
    try:
        build_component(root, contract_path)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
