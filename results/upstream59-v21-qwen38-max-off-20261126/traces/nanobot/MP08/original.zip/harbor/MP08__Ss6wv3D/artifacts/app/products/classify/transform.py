def _validate_safe_relative_path(p):
    """Validate that p is a safe relative path using /."""
    if not isinstance(p, str) or not p:
        raise ValueError(f"Invalid path: {p!r}")
    if "\\" in p or ":" in p:
        raise ValueError(f"Unsafe path characters: {p!r}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"Unsafe path segment in: {p!r}")
    if p.startswith("/"):
        raise ValueError(f"Absolute path not allowed: {p!r}")


def _validate_non_empty_str(val, name):
    if not isinstance(val, str):
        raise ValueError(f"{name} must be a string")
    if not val.strip():
        raise ValueError(f"{name} must be non-empty after strip")


def transform(payloads, contract):
    """photo_classification: select photos by festival, report missing festivals."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("Payload count mismatch")

    case = payloads[0]

    # Validate required fields
    for field in ("files", "photos", "festivals", "destination", "recipient"):
        if field not in case:
            raise ValueError(f"Missing required field: {field}")

    files = case["files"]
    photos = case["photos"]
    festivals = case["festivals"]
    destination = case["destination"]
    recipient = case["recipient"]

    # Validate types
    if not isinstance(files, list):
        raise ValueError("files must be a list")
    if not isinstance(photos, list):
        raise ValueError("photos must be a list")
    if not isinstance(festivals, list):
        raise ValueError("festivals must be a list")

    _validate_safe_relative_path(destination)
    _validate_non_empty_str(recipient, "recipient")

    # Validate festivals: unique non-empty strings
    seen_festivals = set()
    for f in festivals:
        if not isinstance(f, str):
            raise ValueError("Festival must be a string")
        if not f.strip():
            raise ValueError("Festival must be non-empty")
        if f in seen_festivals:
            raise ValueError(f"Duplicate festival: {f}")
        seen_festivals.add(f)

    # Validate files: each has path and hex
    file_paths = set()
    for fi in files:
        if not isinstance(fi, dict):
            raise ValueError("File entry must be an object")
        if "path" not in fi or "hex" not in fi:
            raise ValueError("File entry must have path and hex")
        if not isinstance(fi["path"], str) or not isinstance(fi["hex"], str):
            raise ValueError("File path and hex must be strings")
        _validate_safe_relative_path(fi["path"])
        # Validate hex is valid
        try:
            bytes.fromhex(fi["hex"])
        except ValueError:
            raise ValueError(f"Invalid hex: {fi['hex']}")
        file_paths.add(fi["path"])

    # Validate photos: each has path and festival, path unique and in files
    photo_paths_seen = set()
    for ph in photos:
        if not isinstance(ph, dict):
            raise ValueError("Photo entry must be an object")
        if "path" not in ph or "festival" not in ph:
            raise ValueError("Photo entry must have path and festival")
        if not isinstance(ph["path"], str) or not isinstance(ph["festival"], str):
            raise ValueError("Photo path and festival must be strings")
        if ph["path"] in photo_paths_seen:
            raise ValueError(f"Duplicate photo path: {ph['path']}")
        photo_paths_seen.add(ph["path"])
        if ph["path"] not in file_paths:
            raise ValueError(f"Photo path not in files: {ph['path']}")
        if not ph["festival"].strip():
            raise ValueError("Photo festival must be non-empty")

    # Select photos whose festival is in the festivals list
    selected = []
    for ph in photos:
        if ph["festival"] in seen_festivals:
            selected.append({"path": ph["path"], "festival": ph["festival"]})

    # Sort selected by (festival, path)
    selected.sort(key=lambda x: (x["festival"], x["path"]))

    # Find missing festivals (those with no photos)
    festivals_with_photos = set(ph["festival"] for ph in selected)
    missing = sorted([f for f in festivals if f not in festivals_with_photos])

    result = {
        "selected": selected,
        "missing": missing,
    }

    return {"name": contract["name"], "result": result}
