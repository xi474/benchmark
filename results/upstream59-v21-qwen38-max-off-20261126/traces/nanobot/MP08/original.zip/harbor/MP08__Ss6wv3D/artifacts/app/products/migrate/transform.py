def _validate_safe_relative_path(p):
    """Validate that p is a safe relative path using /."""
    if not isinstance(p, str) or not p:
        raise ValueError(f"Invalid path: {p!r}")
    if "\\" in p or ":" in p:
        raise ValueError(f"Unsafe path characters: {p!r}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"Unsafe path segment in: {p!r}")
    if p.startswith("/"):
        raise ValueError(f"Absolute path not allowed: {p!r}")


def transform(payloads, contract):
    """photo_migration: move selected photos to destination, preserving hex."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("Payload count mismatch")

    case = payloads[0]
    classify_result = payloads[1]

    # Handle name/result envelope from upstream
    if isinstance(classify_result, dict) and set(classify_result.keys()) == {"name", "result"}:
        classify_result = classify_result["result"]

    # Validate case fields
    for field in ("files", "destination"):
        if field not in case:
            raise ValueError(f"Missing required field: {field}")

    files = case["files"]
    destination = case["destination"]

    if not isinstance(files, list):
        raise ValueError("files must be a list")
    _validate_safe_relative_path(destination)

    # Build file lookup by path
    file_map = {}
    for fi in files:
        if not isinstance(fi, dict):
            raise ValueError("File entry must be an object")
        if "path" not in fi or "hex" not in fi:
            raise ValueError("File entry must have path and hex")
        file_map[fi["path"]] = fi["hex"]

    # Get selected photos from classify result
    selected = classify_result.get("selected", [])
    if not isinstance(selected, list):
        raise ValueError("selected must be a list")

    # Build moves and new files list
    moves = []
    new_files = []
    target_paths_seen = set()

    for sel in selected:
        src_path = sel["path"]
        festival = sel["festival"]

        if src_path not in file_map:
            raise ValueError(f"Selected photo not in files: {src_path}")

        hex_val = file_map[src_path]
        # Target: destination/original_path
        to_path = destination + "/" + src_path
        _validate_safe_relative_path(to_path)

        if to_path in target_paths_seen:
            raise ValueError(f"Duplicate target path: {to_path}")
        target_paths_seen.add(to_path)

        moves.append({"from": src_path, "to": to_path, "festival": festival})
        new_files.append({"path": to_path, "hex": hex_val})

    # Sort moves by (from, to)
    moves.sort(key=lambda x: (x["from"], x["to"]))
    # Sort files by path
    new_files.sort(key=lambda x: x["path"])

    result = {
        "moves": moves,
        "files": new_files,
    }

    return {"name": contract["name"], "result": result}
