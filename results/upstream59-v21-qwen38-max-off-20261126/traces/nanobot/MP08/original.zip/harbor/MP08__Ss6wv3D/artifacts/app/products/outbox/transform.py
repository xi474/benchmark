def transform(payloads, contract):
    """photo_outbox: build send list with migrated paths and missing report."""
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("Payload count mismatch")

    case = payloads[0]
    classify_result = payloads[1]
    migrate_result = payloads[2]

    # Handle name/result envelopes from upstream
    if isinstance(classify_result, dict) and set(classify_result.keys()) == {"name", "result"}:
        classify_result = classify_result["result"]
    if isinstance(migrate_result, dict) and set(migrate_result.keys()) == {"name", "result"}:
        migrate_result = migrate_result["result"]

    # Validate case
    if "recipient" not in case:
        raise ValueError("Missing required field: recipient")
    recipient = case["recipient"]
    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be a non-empty string")

    # Get missing from classify
    missing = classify_result.get("missing", [])
    if not isinstance(missing, list):
        raise ValueError("missing must be a list")

    # Get all migrated file paths from migrate result
    migrated_files = migrate_result.get("files", [])
    if not isinstance(migrated_files, list):
        raise ValueError("files must be a list")

    # attachments = sorted list of all migrated paths
    attachments = sorted([f["path"] for f in migrated_files])

    # Build message
    if not missing:
        message = "Photos ready"
    else:
        message = "Missing: " + ", ".join(missing)

    result = {
        "to": recipient,
        "attachments": attachments,
        "missing": missing,
        "message": message,
    }

    return {"name": contract["name"], "result": result}
