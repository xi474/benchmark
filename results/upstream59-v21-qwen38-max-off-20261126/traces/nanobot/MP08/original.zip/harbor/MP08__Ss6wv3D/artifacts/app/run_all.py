#!/usr/bin/env python3
"""Orchestrate all components in dependency order, then integrate."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

# Fix sys.executable if empty (some environments)
if not sys.executable:
    sys.executable = shutil.which("python3") or "python3"

ROOT = Path(__file__).resolve().parent


def find_contracts():
    """Find all contract.json files outside outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    """Load a contract JSON file."""
    return json.loads(path.read_text(encoding="utf-8"))


def topological_sort(contracts):
    """Sort contracts by dependency order based on input references to outputs/."""
    # Build name -> contract_path mapping
    name_to_path = {}
    name_to_contract = {}
    for cp in contracts:
        c = load_contract(cp)
        name_to_path[c["name"]] = cp
        name_to_contract[c["name"]] = c

    # Build dependency graph
    deps = {}
    for name, c in name_to_contract.items():
        dep_names = set()
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                # This input is an output from another component
                # Find which component produces this output
                for other_name, other_c in name_to_contract.items():
                    if other_c["output"] == inp:
                        dep_names.add(other_name)
        deps[name] = dep_names

    # Topological sort (Kahn's algorithm)
    in_degree = {name: 0 for name in name_to_contract}
    for name, dep_set in deps.items():
        for d in dep_set:
            in_degree[name] += 1  # name depends on d

    # Wait, in_degree should count incoming edges. Let me redo.
    # Actually: if name depends on d, then d must come before name.
    # in_degree[name] = number of dependencies name has
    in_degree = {name: len(dep_set) for name, dep_set in deps.items()}

    queue = [name for name, deg in in_degree.items() if deg == 0]
    queue.sort()  # deterministic order
    result = []

    while queue:
        node = queue.pop(0)
        result.append(node)
        # Find nodes that depend on this node
        for name, dep_set in deps.items():
            if node in dep_set:
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)
        queue.sort()

    if len(result) != len(name_to_contract):
        raise ValueError("Dependency cycle detected")

    return [name_to_path[name] for name in result]


def run_component(contract_path):
    """Run a component's render.py via subprocess."""
    render_py = contract_path.with_name("render.py")
    if not render_py.exists():
        print(f"Error: {render_py} not found", file=sys.stderr)
        sys.exit(1)

    cmd = [sys.executable, str(render_py), str(ROOT), str(contract_path)]
    proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=60)
    if proc.returncode != 0:
        print(f"Component failed: {contract_path}", file=sys.stderr)
        print(proc.stderr, file=sys.stderr)
        sys.exit(1)


def main():
    contracts = find_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Sort by dependency order
    ordered = topological_sort(contracts)

    # Run each component
    for cp in ordered:
        run_component(cp)

    # Run integrate.py
    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        proc = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if proc.returncode != 0:
            print("Integration failed", file=sys.stderr)
            print(proc.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        proc = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if proc.returncode != 0:
            print("Final report generation failed", file=sys.stderr)
            print(proc.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
