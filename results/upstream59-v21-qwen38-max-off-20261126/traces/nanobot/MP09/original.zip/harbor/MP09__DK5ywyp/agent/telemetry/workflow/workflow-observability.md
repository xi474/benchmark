# Workflow 可观测性报告

- Trial：`MP09__DK5ywyp__env`
- Task：`MP09`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（70 节点 / 69 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：70；执行边：69（observed=0，inferred=69）
- Execution Trace Graph：`observed`；temporal_next 边 69，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_4046cd3b7d3e4e3e811c26ce -> tool:nanobot-harness-v3:call_d15283ba208c444fb024ab6b -> tool:nanobot-harness-v3:call_634441a56a194db498eb0a7e -> tool:nanobot-harness-v3:call_2a800dcbf0874d2c8f059e24 -> tool:nanobot-harness-v3:call_fbbaa6d5717c4e36ac2b7b4d -> tool:nanobot-harness-v3:call_54782a75641f4b6a9728f570 -> tool:nanobot-harness-v3:call_282366fe778a48ecb48fe4f5 -> tool:nanobot-harness-v3:call_afc868f2e37549af8847d9c3 -> tool:nanobot-harness-v3:call_fbbaa4298fc540efb275e213 -> tool:nanobot-harness-v3:call_84381cc39ac74886ba6de023 -> tool:nanobot-harness-v3:call_4e10e18a25174c37913cbbab -> tool:nanobot-harness-v3:call_82a63162dbb443aea3f629fc -> tool:nanobot-harness-v3:call_fb2e692d092c4aa5b243eb6c -> tool:nanobot-harness-v3:call_c9070a4894994eaabee97469 -> tool:nanobot-harness-v3:call_fe3222d17e0141f78268defa -> tool:nanobot-harness-v3:call_797546105e754ab18fd9f223 -> tool:nanobot-harness-v3:call_9a2dcc9469704c3fa1aa2724 -> tool:nanobot-harness-v3:call_f6ede2cf7e4849618e4f59a8 -> tool:nanobot-harness-v3:call_d0359260c0994374a764c0d4 -> tool:nanobot-harness-v3:call_62e50ea0dbc74cc9887e838f -> tool:nanobot-harness-v3:call_afae04e0227a43ac9a9236e7 -> tool:nanobot-harness-v3:call_dee77e2cce0d4140a6547428 -> tool:nanobot-harness-v3:call_5cf50bbb9ba24369841e674d -> tool:nanobot-harness-v3:call_064c1c6920014729a603f00f -> tool:nanobot-harness-v3:call_7b48ff4a3a344b4fb89cbe1f -> tool:nanobot-harness-v3:call_287f493fb807460baffe5a77 -> tool:nanobot-harness-v3:call_b63ea45797d84dda87a847f9 -> tool:nanobot-harness-v3:call_e86a105e7d9545239e36cb56 -> tool:nanobot-harness-v3:call_93ff22f70f6240ae8dca5e02 -> tool:nanobot-harness-v3:call_11b7fa9bcd314f90a72db041 -> tool:nanobot-harness-v3:call_0a71d935e20846e9a43b5ea7 -> tool:nanobot-harness-v3:call_f816a47104ee436fa79fac82 -> tool:nanobot-harness-v3:call_32eef49983f548a7bb1c127a -> tool:nanobot-harness-v3:call_665adcd6ae7a42ab935d14a0 -> tool:nanobot-harness-v3:call_fb8460065c074a6789f3263c -> tool:nanobot-harness-v3:call_4a7606bdadac48acaf8ff9c3 -> tool:nanobot-harness-v3:call_7023febe1ed442d99fbc4f05 -> tool:nanobot-harness-v3:call_5817918fa666493782945774 -> tool:nanobot-harness-v3:call_b444d30c781e49eb91f891ba -> tool:nanobot-harness-v3:call_064e3eb19f26449d80febbfa -> tool:nanobot-harness-v3:call_8b6729b2f2c24e849bf9a5c4 -> tool:nanobot-harness-v3:call_0392b76d322a480cae1bc878 -> tool:nanobot-harness-v3:call_cd7bb58f8111464faec3496b -> tool:nanobot-harness-v3:call_b7bd0a18a6bb4ade930dc07c -> tool:nanobot-harness-v3:call_08ce77b0dd744f5cb959c47c -> tool:nanobot-harness-v3:call_c79d2f6127a74bba88170893 -> tool:nanobot-harness-v3:call_33ba5df3f2634149bd8f4eba -> tool:nanobot-harness-v3:call_369a17d127c44c34bca9b516 -> tool:nanobot-harness-v3:call_2a55feab7dc04db385af0837 -> tool:nanobot-harness-v3:call_84b0bf76d22c4055943aa3ad -> tool:nanobot-harness-v3:call_23c79157184143b99423963a -> tool:nanobot-harness-v3:call_4c6d175d0dcf4bc1b718463e -> tool:nanobot-harness-v3:call_ea4bed469a414213aa5f3de9 -> tool:nanobot-harness-v3:call_133a101954c248549657845e -> tool:nanobot-harness-v3:call_f52191fbdddb4e5c8664b390 -> tool:nanobot-harness-v3:call_50da90fedd7d4376a97d1345 -> tool:nanobot-harness-v3:call_a864358377514b2dac023bf9 -> tool:nanobot-harness-v3:call_d51daa0244c34993aa9cd72e -> tool:nanobot-harness-v3:call_e670aea3cf524e4d8b1a1df8 -> tool:nanobot-harness-v3:call_c2badd550d3640abbd0b7f9f -> tool:nanobot-harness-v3:call_86fa3d26c26a48d08da8a37e -> tool:nanobot-harness-v3:call_803caa4f1f4c47e196300d02 -> tool:nanobot-harness-v3:call_c5a3a52832de428ba3d84ccb -> tool:nanobot-harness-v3:call_a9dea9f5b4af4054b24a9eb7 -> tool:nanobot-harness-v3:call_1aa8c4d1cc4a451cafffc828 -> tool:nanobot-harness-v3:call_b0ecbe95f1594e8dbbbf2358 -> tool:nanobot-harness-v3:call_3c1901aff8d6404ea94c4c1b -> tool:nanobot-harness-v3:call_ceacf6e9a1d34443b968904e -> tool:nanobot-harness-v3:call_5d46fb89472c4f2fa732b9c8
- 关键路径耗时：1.027269
- Makespan：309.019928
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
