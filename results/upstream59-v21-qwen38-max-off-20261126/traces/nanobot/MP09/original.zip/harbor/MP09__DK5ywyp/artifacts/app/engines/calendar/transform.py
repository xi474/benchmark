def _validate_int(val, name):
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be int, got {type(val).__name__}")
    return val


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    now = _validate_int(data.get("now"), "now")
    duration = _validate_int(data.get("duration"), "duration")
    gap = _validate_int(data.get("gap"), "gap")
    if duration < 1:
        raise ValueError("duration must be >= 1")
    if gap < 0:
        raise ValueError("gap must be >= 0")

    windows = data.get("windows")
    if not isinstance(windows, list):
        raise ValueError("windows must be list")
    busy = data.get("busy")
    if not isinstance(busy, list):
        raise ValueError("busy must be list")

    # Build available intervals from windows union minus busy minus before now
    # Collect all window intervals
    intervals = []
    for w in windows:
        s = _validate_int(w.get("start"), "window.start")
        e = _validate_int(w.get("end"), "window.end")
        if e <= s:
            raise ValueError("window end must be > start")
        intervals.append((s, e))

    # Sort and merge overlapping intervals
    intervals.sort()
    merged = []
    for s, e in intervals:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    # Clip to after now
    clipped = []
    for s, e in merged:
        cs = max(s, now)
        if cs < e:
            clipped.append((cs, e))

    # Subtract busy intervals
    busy_sorted = []
    for b in busy:
        bs = _validate_int(b.get("start"), "busy.start")
        be = _validate_int(b.get("end"), "busy.end")
        if be <= bs:
            raise ValueError("busy end must be > start")
        busy_sorted.append((bs, be))
    busy_sorted.sort()

    available = []
    for s, e in clipped:
        cur_s = s
        for bs, be in busy_sorted:
            if be <= cur_s:
                continue
            if bs >= e:
                break
            if bs > cur_s:
                available.append((cur_s, min(bs, e)))
            cur_s = max(cur_s, be)
        if cur_s < e:
            available.append((cur_s, e))

    # Greedy select earliest two slots
    slots = []
    first_end = None
    i = 0
    while i < len(available) and len(slots) < 2:
        s, e = available[i]
        if len(slots) == 0:
            if e - s >= duration:
                slots.append({"start": s, "end": s + duration})
                first_end = s + duration
                # Don't advance i; the same interval might hold the second slot
            else:
                i += 1
        else:
            needed_start = first_end + gap
            actual_start = max(s, needed_start)
            if actual_start < e and e - actual_start >= duration:
                slots.append({"start": actual_start, "end": actual_start + duration})
                break
            else:
                i += 1

    complete = len(slots) == 2
    result = {"slots": slots, "complete": complete}
    return {"name": contract["name"], "result": result}
