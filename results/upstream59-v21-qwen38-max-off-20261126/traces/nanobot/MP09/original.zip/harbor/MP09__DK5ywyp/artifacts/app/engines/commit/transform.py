def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    # payloads[0] = calendar result (wrapped or raw)
    # payloads[1] = invitees result (wrapped or raw)
    # payloads[2] = supplies result (wrapped or raw)
    def extract(p):
        if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
            return p["result"]
        return p

    cal = extract(payloads[0])
    inv = extract(payloads[1])
    sup = extract(payloads[2])

    if not isinstance(cal, dict):
        raise ValueError("calendar input must be object")
    if not isinstance(inv, dict):
        raise ValueError("invitees input must be object")
    if not isinstance(sup, dict):
        raise ValueError("supplies input must be object")

    complete = cal.get("complete")
    if not isinstance(complete, bool):
        raise ValueError("complete must be bool")
    slots = cal.get("slots")
    if not isinstance(slots, list):
        raise ValueError("slots must be list")

    members = inv.get("members")
    if not isinstance(members, list):
        raise ValueError("members must be list")
    group_id = inv.get("group_id")
    if not isinstance(group_id, str):
        raise ValueError("group_id must be string")

    if complete and len(slots) == 2:
        events = [
            {"id": group_id + "-1", "start": slots[0]["start"], "end": slots[0]["end"], "members": members},
            {"id": group_id + "-2", "start": slots[1]["start"], "end": slots[1]["end"], "members": members}
        ]
        event_ids = [e["id"] for e in events]
        notification = {"group_id": group_id, "members": members, "event_ids": event_ids}
    else:
        events = []
        notification = None

    result = {
        "events": events,
        "notification": notification,
        "purchase": sup
    }
    return {"name": contract["name"], "result": result}
