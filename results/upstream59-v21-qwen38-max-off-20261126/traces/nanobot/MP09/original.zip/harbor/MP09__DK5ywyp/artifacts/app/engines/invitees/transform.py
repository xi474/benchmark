def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    groups = data.get("groups")
    if not isinstance(groups, list):
        raise ValueError("groups must be list")
    invite_groups = data.get("invite_groups")
    if not isinstance(invite_groups, list):
        raise ValueError("invite_groups must be list")
    exclude = data.get("exclude")
    if not isinstance(exclude, list):
        raise ValueError("exclude must be list")
    namespace = data.get("namespace")
    if not isinstance(namespace, str) or not namespace.strip():
        raise ValueError("namespace must be non-empty string")

    # Build group lookup
    group_map = {}
    for g in groups:
        gid = g.get("id")
        if not isinstance(gid, str):
            raise ValueError("group id must be string")
        members = g.get("members")
        if not isinstance(members, list) or len(members) == 0:
            raise ValueError("group members must be non-empty list")
        for m in members:
            if not isinstance(m, str):
                raise ValueError("member id must be string")
        group_map[gid] = members

    # Validate invite_groups exist
    for ig in invite_groups:
        if not isinstance(ig, str):
            raise ValueError("invite_group id must be string")
        if ig not in group_map:
            raise ValueError(f"unknown group: {ig}")

    # Union members from invited groups
    member_set = set()
    for ig in invite_groups:
        for m in group_map[ig]:
            member_set.add(m)

    # Exclude
    exclude_set = set()
    for e in exclude:
        if not isinstance(e, str):
            raise ValueError("exclude id must be string")
        exclude_set.add(e)

    final_members = sorted(member_set - exclude_set)
    group_id = namespace + "-panel"

    result = {"members": final_members, "group_id": group_id}
    return {"name": contract["name"], "result": result}
