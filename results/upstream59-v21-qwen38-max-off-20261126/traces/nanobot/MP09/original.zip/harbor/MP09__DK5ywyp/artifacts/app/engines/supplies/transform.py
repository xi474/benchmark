def _validate_int_nonneg(val, name):
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be int")
    if val < 0:
        raise ValueError(f"{name} must be >= 0")
    return val


def _validate_int_pos(val, name):
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be int")
    if val < 1:
        raise ValueError(f"{name} must be >= 1")
    return val


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    products = data.get("products")
    if not isinstance(products, list):
        raise ValueError("products must be list")
    requirements = data.get("requirements")
    if not isinstance(requirements, list):
        raise ValueError("requirements must be list")

    # Validate products
    prods = []
    for p in products:
        pid = p.get("id")
        if not isinstance(pid, str):
            raise ValueError("product id must be string")
        cat = p.get("category")
        if not isinstance(cat, str):
            raise ValueError("product category must be string")
        stock = _validate_int_nonneg(p.get("stock"), "stock")
        price = _validate_int_nonneg(p.get("price_cents"), "price_cents")
        rating = _validate_int_nonneg(p.get("rating"), "rating")
        prods.append({"id": pid, "category": cat, "stock": stock, "price_cents": price, "rating": rating})

    # Validate requirements - each category only one requirement
    req_map = {}
    for r in requirements:
        cat = r.get("category")
        if not isinstance(cat, str):
            raise ValueError("requirement category must be string")
        qty = _validate_int_pos(r.get("quantity"), "quantity")
        if cat in req_map:
            raise ValueError(f"duplicate category: {cat}")
        req_map[cat] = qty

    items = []
    unavailable = []

    for cat in sorted(req_map.keys()):
        qty = req_map[cat]
        # Filter products with enough stock
        candidates = [p for p in prods if p["category"] == cat and p["stock"] >= qty]
        if not candidates:
            unavailable.append(cat)
        else:
            # Select by rating desc, price_cents asc, id asc
            best = min(candidates, key=lambda p: (-p["rating"], p["price_cents"], p["id"]))
            items.append({
                "category": cat,
                "id": best["id"],
                "quantity": qty,
                "total_cents": best["price_cents"] * qty
            })

    result = {"items": items, "unavailable": sorted(unavailable)}
    return {"name": contract["name"], "result": result}
