import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core.get("components", {})
    component_count = len(components)

    # SHA256 of the full core object serialized compactly
    canonical = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(canonical).hexdigest()

    # Attention: components with specific conditions
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if isinstance(val, list) and len(val) > 0:
                attention.add(name)

    report = {
        "title": "两场座谈会、群邀请与物资采购",
        "component_count": component_count,
        "sha256": sha256,
        "attention": sorted(attention)
    }

    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    out.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
