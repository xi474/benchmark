import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or shutil.which("python3") or "python3"


def main():
    # Discover all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: component name -> contract path, and output -> component
    comp_info = {}
    output_to_comp = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        comp_info[name] = {"contract": cp, "inputs": c["inputs"], "output": c["output"]}
        output_to_comp[c["output"]] = name

    # Topological sort based on input dependencies
    # A component depends on another if any of its inputs is an output of another component
    deps = {}
    for name, info in comp_info.items():
        deps[name] = set()
        for inp in info["inputs"]:
            if inp in output_to_comp:
                dep = output_to_comp[inp]
                if dep != name:
                    deps[name].add(dep)

    # Kahn's algorithm
    order = []
    in_degree = {n: len(d) for n, d in deps.items()}
    queue = sorted([n for n, d in in_degree.items() if d == 0])
    while queue:
        node = queue.pop(0)
        order.append(node)
        for n, d in deps.items():
            if node in d:
                in_degree[n] -= 1
                if in_degree[n] == 0:
                    queue.append(n)
                    queue.sort()

    if len(order) != len(comp_info):
        print("Dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute components in order
    for name in order:
        cp = comp_info[name]["contract"]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report = ROOT / "final_report.py"
    if report.exists():
        result = subprocess.run(
            [PYTHON, str(report)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
