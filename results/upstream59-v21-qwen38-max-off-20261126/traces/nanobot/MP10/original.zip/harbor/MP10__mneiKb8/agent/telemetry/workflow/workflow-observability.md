# Workflow 可观测性报告

- Trial：`MP10__mneiKb8__env`
- Task：`MP10`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（90 节点 / 89 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：90；执行边：89（observed=0，inferred=89）
- Execution Trace Graph：`observed`；temporal_next 边 89，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_06ef0271f61e44afa332a618 -> tool:nanobot-harness-v3:call_e1276fb8337043518bdc225d -> tool:nanobot-harness-v3:call_4c14f8cac5b54d56af8fd127 -> tool:nanobot-harness-v3:call_4326f11c1525430fabe8652e -> tool:nanobot-harness-v3:call_d175af96afe441e18011acf3 -> tool:nanobot-harness-v3:call_d53c18cacd1141209df567f5 -> tool:nanobot-harness-v3:call_08f7927636494039a39e8650 -> tool:nanobot-harness-v3:call_ba36125df2f04791b3786cb7 -> tool:nanobot-harness-v3:call_9a2d7b67d0e743f1a12e17e1 -> tool:nanobot-harness-v3:call_8fec89321f014e4d999713bc -> tool:nanobot-harness-v3:call_a28db643a70e4b06a476520e -> tool:nanobot-harness-v3:call_44e92eb1361347789353b095 -> tool:nanobot-harness-v3:call_97656d31bf0a4287909ac8db -> tool:nanobot-harness-v3:call_43a175b5056f487f98a6457e -> tool:nanobot-harness-v3:call_82586fe38a634796a02f1af3 -> tool:nanobot-harness-v3:call_890e9f531ad44911964f9ba7 -> tool:nanobot-harness-v3:call_72269c1c6b534f0da49abb68 -> tool:nanobot-harness-v3:call_9529b5f2b04b4270995f74ad -> tool:nanobot-harness-v3:call_83d34f55cdc24ac8af2a4b74 -> tool:nanobot-harness-v3:call_73c4745a8d78428b902f23d5 -> tool:nanobot-harness-v3:call_1462fa9958d443df81346c79 -> tool:nanobot-harness-v3:call_6112125d78584904a071608a -> tool:nanobot-harness-v3:call_13282d1964194e699acffa78 -> tool:nanobot-harness-v3:call_9d53db5428da431cafaf6457 -> tool:nanobot-harness-v3:call_ba9316ed7ef64e3c8206ae1b -> tool:nanobot-harness-v3:call_043e624a4d054ddd8957263d -> tool:nanobot-harness-v3:call_be84081c84f04011aad91d38 -> tool:nanobot-harness-v3:call_8e38fbcb2dbb449b816f7a60 -> tool:nanobot-harness-v3:call_4177771c218041bcb08b2617 -> tool:nanobot-harness-v3:call_b902052344b04da6bb02536c -> tool:nanobot-harness-v3:call_a966f3ae1f3b46b5a063f79d -> tool:nanobot-harness-v3:call_5bd731265d1748588562faba -> tool:nanobot-harness-v3:call_0231cfa1f72f47899fdf5e10 -> tool:nanobot-harness-v3:call_7a6790aaa4664578ba06fe5d -> tool:nanobot-harness-v3:call_1e3e97112c2a4bd38b673c38 -> tool:nanobot-harness-v3:call_ab7e3a67110945929151033e -> tool:nanobot-harness-v3:call_940e2a5106954fa381b0903c -> tool:nanobot-harness-v3:call_bf6e75af2b41446699fc7be5 -> tool:nanobot-harness-v3:call_fd8dc0420698437a8b6d17b9 -> tool:nanobot-harness-v3:call_f0bcfbfff9794a759206e8ad -> tool:nanobot-harness-v3:call_7a9cdad0bef94336b191d80c -> tool:nanobot-harness-v3:call_cf77a967e9b7487b9d6240d8 -> tool:nanobot-harness-v3:call_5dd83e26783a4a629e5f9366 -> tool:nanobot-harness-v3:call_9e8a46dad41e41399754d8b2 -> tool:nanobot-harness-v3:call_0885586b81da4fb591166dfc -> tool:nanobot-harness-v3:call_099e23220851422fb10594e9 -> tool:nanobot-harness-v3:call_68b01bc9beb6422c8652749b -> tool:nanobot-harness-v3:call_04fb72940c334c919da29fd3 -> tool:nanobot-harness-v3:call_6450cbadcd1d48c581c05c3f -> tool:nanobot-harness-v3:call_9f3f7806262544868aeeef98 -> tool:nanobot-harness-v3:call_552db952163f4ebda1b3e1f9 -> tool:nanobot-harness-v3:call_e9fae3d301d74fb7b2c396e8 -> tool:nanobot-harness-v3:call_29b3851dff8c4fd2817ba0d3 -> tool:nanobot-harness-v3:call_4488405724ba407db511194f -> tool:nanobot-harness-v3:call_9fe5cad4d49142fba8b4a6a0 -> tool:nanobot-harness-v3:call_83a61af3449b4d208b4f9432 -> tool:nanobot-harness-v3:call_78f33b3c311b4ba4b7a0623f -> tool:nanobot-harness-v3:call_4bdc58e062fd4f6396326b3b -> tool:nanobot-harness-v3:call_082b3d8b5ee24ae993e4c07b -> tool:nanobot-harness-v3:call_e6f79c8286d24d16ae5ff788 -> tool:nanobot-harness-v3:call_39bbfd3556724dabb7e12008 -> tool:nanobot-harness-v3:call_c2a4e4f6568749edb4bc3442 -> tool:nanobot-harness-v3:call_7e65b4a60dbf43239a247721 -> tool:nanobot-harness-v3:call_2293ba72690d48f5a356c97d -> tool:nanobot-harness-v3:call_d908b44c4803472fad7b5e83 -> tool:nanobot-harness-v3:call_e13ad21aab03483c9f5d4fe3 -> tool:nanobot-harness-v3:call_fa00bf97fd444fcca81c24ac -> tool:nanobot-harness-v3:call_ace42ce9ab684b619688ad6f -> tool:nanobot-harness-v3:call_8da07033beca405f921902c8 -> tool:nanobot-harness-v3:call_85a2d18f1644453e90e23483 -> tool:nanobot-harness-v3:call_a42eb8a09a21410ca45d0de9 -> tool:nanobot-harness-v3:call_130ed186fd8f4ece8d42f877 -> tool:nanobot-harness-v3:call_67c75343ea414539906e5d56 -> tool:nanobot-harness-v3:call_8803e6f8bfd9412cb9b807d0 -> tool:nanobot-harness-v3:call_d493fb4915aa49b1b1287454 -> tool:nanobot-harness-v3:call_5442a1a4b1a84e699b56c3f8 -> tool:nanobot-harness-v3:call_258c075c7f414494ae61e163 -> tool:nanobot-harness-v3:call_572cfbf3187d4cfba47ec1c7 -> tool:nanobot-harness-v3:call_900a064ac3c44cf8af329947 -> tool:nanobot-harness-v3:call_004dccf1db794e91b80c7481 -> tool:nanobot-harness-v3:call_44f1c0c7dc28424f8dbc5956 -> tool:nanobot-harness-v3:call_2bd3b9f51e42421e8fe3d9a0 -> tool:nanobot-harness-v3:call_1d4e792d84cf4c26908fa632 -> tool:nanobot-harness-v3:call_797197ee883448af988a3819 -> tool:nanobot-harness-v3:call_ec85fde0076741da8b49cf7b -> tool:nanobot-harness-v3:call_e486ab1cbf06419da0d60414 -> tool:nanobot-harness-v3:call_d2d92dac8d3049f2b401b86e -> tool:nanobot-harness-v3:call_24c2d149f01549bc976f8642 -> tool:nanobot-harness-v3:call_2307d4cfe1164fa687e65356
- 关键路径耗时：1.538041
- Makespan：490.266623
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
