import json
import math
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON from path. Only object/array top-level allowed.
    Rejects non-standard JSON (NaN/Infinity) and non-object/array top-level."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError(f"Top-level must be object or array, got {type(data).__name__}")
    _check_finite(data)
    return data


def _check_finite(obj):
    """Recursively check that all float values are finite."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError(f"Non-finite number found: {obj}")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
