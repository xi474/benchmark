import json
import sys
from pathlib import Path

_this_dir = Path(__file__).resolve().parent
_root = _this_dir.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from contact.model import load_payload
from contact.transform import transform


def _write_json(path, data):
    """Write JSON with required formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    path.write_text(text + '\n', encoding='utf-8')


def build_component(root, contract_path):
    root = Path(root).resolve()
    contract_path = Path(contract_path).resolve()
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out_path = root / contract['output']
    _write_json(out_path, result)
    return result


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    contract_path = here / 'contract.json'
    build_component(root, contract_path)
