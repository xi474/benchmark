def _validate_str(val, name):
    """Validate that val is a non-empty stripped string."""
    if not isinstance(val, str):
        raise ValueError(f"{name} must be a string, got {type(val).__name__}")
    if not val.strip():
        raise ValueError(f"{name} must be non-empty after strip")
    return val


def _validate_int(val, name):
    """Validate that val is an int (not bool)."""
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be an integer, got {type(val).__name__}")
    return val


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("Input must be an object")

    for field in ('conversations', 'topic'):
        if field not in case:
            raise ValueError(f"Missing required field: {field}")

    conversations = case['conversations']
    if not isinstance(conversations, list):
        raise ValueError("conversations must be an array")

    topic = _validate_str(case['topic'], 'topic')
    topic_lower = topic.casefold()

    best = None  # (ts, id, contact_id)

    for conv in conversations:
        if not isinstance(conv, dict):
            raise ValueError("Each conversation must be an object")
        for f in ('id', 'contact_id', 'ts', 'topic'):
            if f not in conv:
                raise ValueError(f"Conversation missing field: {f}")

        conv_topic = conv['topic']
        if not isinstance(conv_topic, str):
            raise ValueError("conversation.topic must be a string")

        # Substring match using casefold
        if topic_lower not in conv_topic.casefold():
            continue

        ts = conv['ts']
        _validate_int(ts, 'conversation.ts')
        conv_id = conv['id']
        if not isinstance(conv_id, str):
            raise ValueError("conversation.id must be a string")
        contact_id = conv['contact_id']
        if not isinstance(contact_id, str):
            raise ValueError("conversation.contact_id must be a string")

        # Select max ts, then min id for ties
        if best is None or ts > best[0] or (ts == best[0] and conv_id < best[1]):
            best = (ts, conv_id, contact_id)

    if best is None:
        result = {"contact_id": None, "conversation_id": None}
    else:
        result = {"contact_id": best[2], "conversation_id": best[1]}

    return {"name": contract["name"], "result": result}
