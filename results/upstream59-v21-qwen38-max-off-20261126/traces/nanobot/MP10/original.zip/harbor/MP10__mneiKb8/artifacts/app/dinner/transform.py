from datetime import date, timedelta


def _validate_int(val, name, min_val=None, max_val=None):
    """Validate that val is an int (not bool) within optional bounds."""
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be an integer, got {type(val).__name__}")
    if min_val is not None and val < min_val:
        raise ValueError(f"{name} must be >= {min_val}, got {val}")
    if max_val is not None and val > max_val:
        raise ValueError(f"{name} must be <= {max_val}, got {val}")
    return val


def _validate_str(val, name):
    """Validate that val is a non-empty stripped string."""
    if not isinstance(val, str):
        raise ValueError(f"{name} must be a string, got {type(val).__name__}")
    if not val.strip():
        raise ValueError(f"{name} must be non-empty after strip")
    return val


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("Input must be an object")

    # Validate required fields
    for field in ('today', 'weekday', 'hour', 'guest_count'):
        if field not in case:
            raise ValueError(f"Missing required field: {field}")

    today_str = _validate_str(case['today'], 'today')
    try:
        today = date.fromisoformat(today_str)
    except ValueError as e:
        raise ValueError(f"Invalid ISO date for today: {e}") from e

    weekday = _validate_int(case['weekday'], 'weekday', 0, 6)
    hour = _validate_int(case['hour'], 'hour', 0, 23)
    guest_count = _validate_int(case['guest_count'], 'guest_count', 1)

    # Find next date strictly after today with the given weekday
    # Python weekday: Monday=0 ... Sunday=6 (matches spec)
    days_ahead = weekday - today.weekday()
    if days_ahead <= 0:
        days_ahead += 7
    dinner_date = today + timedelta(days=days_ahead)

    start = f"{dinner_date.isoformat()}T{hour:02d}:00"

    result = {
        "start": start,
        "guest_count": guest_count
    }

    return {"name": contract["name"], "result": result}
