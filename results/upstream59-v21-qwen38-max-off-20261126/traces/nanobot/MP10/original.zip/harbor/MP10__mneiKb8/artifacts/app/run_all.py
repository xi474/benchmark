import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _python_exe():
    """Find a working python3 executable."""
    if sys.executable:
        return sys.executable
    for name in ('python3', 'python'):
        found = shutil.which(name)
        if found:
            return found
    raise RuntimeError("Cannot find python executable")


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: parse each contract to find input dependencies
    dep_map = {}  # contract_path -> list of contract_paths it depends on
    output_to_contract = {}  # output path -> contract_path

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        output_to_contract[c['output']] = cp
        deps = []
        for inp in c['inputs']:
            if inp in output_to_contract:
                deps.append(output_to_contract[inp])
            elif str(inp).startswith('outputs/'):
                # This is a dependency on another component's output
                # Find which contract produces it
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                    if other_c['output'] == inp:
                        deps.append(other_cp)
                        break
        dep_map[cp] = deps

    # Topological sort
    ordered = []
    visited = set()
    visiting = set()

    def visit(cp):
        if cp in visited:
            return
        if cp in visiting:
            print(f"Circular dependency detected involving {cp}", file=sys.stderr)
            sys.exit(1)
        visiting.add(cp)
        for dep in dep_map.get(cp, []):
            visit(dep)
        visiting.remove(cp)
        visited.add(cp)
        ordered.append(cp)

    for cp in contracts:
        visit(cp)

    py = _python_exe()

    # Execute each component in order
    for cp in ordered:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [py, str(render_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [py, str(integrate_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_py = ROOT / 'final_report.py'
    if report_py.exists():
        result = subprocess.run(
            [py, str(report_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
