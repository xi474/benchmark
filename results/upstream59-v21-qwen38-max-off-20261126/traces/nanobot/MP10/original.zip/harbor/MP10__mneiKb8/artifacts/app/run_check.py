import sys
sys.executable = '/usr/local/bin/python3'
exec(open('check.py').read())
