def _validate_int(val, name, min_val=None):
    """Validate that val is an int (not bool) within optional bounds."""
    if isinstance(val, bool) or not isinstance(val, int):
        raise ValueError(f"{name} must be an integer, got {type(val).__name__}")
    if min_val is not None and val < min_val:
        raise ValueError(f"{name} must be >= {min_val}, got {val}")
    return val


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError(f"Expected {len(contract['inputs'])} payloads, got {len(payloads)}")

    # payloads[0] = original case/snapshot
    # payloads[1] = dinner result {name, result: {start, guest_count}}
    # payloads[2] = contact result {name, result: {contact_id, conversation_id}}
    snapshot = payloads[0]
    dinner_payload = payloads[1]
    contact_payload = payloads[2]

    if not isinstance(snapshot, dict):
        raise ValueError("Snapshot must be an object")

    # Extract dinner result
    if isinstance(dinner_payload, dict) and 'result' in dinner_payload:
        dinner = dinner_payload['result']
    else:
        dinner = dinner_payload

    # Extract contact result
    if isinstance(contact_payload, dict) and 'result' in contact_payload:
        contact = contact_payload['result']
    else:
        contact = contact_payload

    for field in ('variants', 'wanted'):
        if field not in snapshot:
            raise ValueError(f"Missing required field: {field}")

    variants = snapshot['variants']
    wanted = snapshot['wanted']

    if not isinstance(variants, list):
        raise ValueError("variants must be an array")
    if not isinstance(wanted, list):
        raise ValueError("wanted must be an array")

    guest_count = dinner['guest_count']
    start = dinner['start']
    recipient = contact.get('contact_id', None)

    # Validate variants
    parsed_variants = []
    for v in variants:
        if not isinstance(v, dict):
            raise ValueError("Each variant must be an object")
        for f in ('id', 'kind', 'attributes', 'stock', 'price_cents'):
            if f not in v:
                raise ValueError(f"Variant missing field: {f}")
        vid = v['id']
        kind = v['kind']
        attrs = v['attributes']
        stock = _validate_int(v['stock'], 'variant.stock', 0)
        price_cents = _validate_int(v['price_cents'], 'variant.price_cents', 0)
        if not isinstance(attrs, dict):
            raise ValueError("variant.attributes must be an object")
        parsed_variants.append({
            'id': vid, 'kind': kind, 'attributes': attrs,
            'stock': stock, 'price_cents': price_cents
        })

    # Process each wanted kind
    items = []
    unavailable = []

    for w in wanted:
        if not isinstance(w, dict):
            raise ValueError("Each wanted must be an object")
        for f in ('kind', 'attributes'):
            if f not in w:
                raise ValueError(f"Wanted missing field: {f}")
        w_kind = w['kind']
        w_attrs = w['attributes']
        if not isinstance(w_attrs, dict):
            raise ValueError("wanted.attributes must be an object")

        # Find candidates: same kind, exact attribute match, sufficient stock
        candidates = [
            v for v in parsed_variants
            if v['kind'] == w_kind and v['attributes'] == w_attrs and v['stock'] >= guest_count
        ]

        if not candidates:
            unavailable.append(w_kind)
            continue

        # Select lowest price_cents, then lowest id
        best = min(candidates, key=lambda v: (v['price_cents'], v['id']))
        items.append({
            'id': best['id'],
            'kind': w_kind,
            'quantity': guest_count
        })

    # Sort items by kind (string lexicographic)
    items.sort(key=lambda x: x['kind'])
    # Sort unavailable by kind (string lexicographic), deduplicate
    unavailable = sorted(set(unavailable))

    total_cents = sum(item['quantity'] * next(
        v['price_cents'] for v in parsed_variants if v['id'] == item['id']
    ) for item in items)

    # checkout requires all categories available AND recipient non-null
    checkout = len(unavailable) == 0 and recipient is not None

    result = {
        "items": items,
        "total_cents": total_cents,
        "checkout": checkout,
        "recipient": recipient,
        "start": start,
        "unavailable": unavailable
    }

    return {"name": contract["name"], "result": result}
