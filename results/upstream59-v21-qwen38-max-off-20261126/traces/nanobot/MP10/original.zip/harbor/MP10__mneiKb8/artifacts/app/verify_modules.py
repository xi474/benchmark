import copy, importlib, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

for comp_name in ['dinner', 'contact', 'shopping']:
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / comp_name))

    cp = ROOT / comp_name / 'contract.json'

    # Use the component's own load_payload
    mod_model = importlib.import_module(f'{comp_name}.model')
    lp = mod_model.load_payload

    c = lp(cp)
    payloads = [lp(ROOT / p) for p in c['inputs']]
    before = copy.deepcopy(payloads)
    cc = copy.deepcopy(c)

    mod_transform = importlib.import_module(f'{comp_name}.transform')
    result = mod_transform.transform(payloads, c)

    assert payloads == before and c == cc, f'{comp_name}: inputs/contract mutated'
    assert type(result) is dict and set(result) == {'name', 'result'}
    assert result['name'] == c['name'] and type(result['result']) is dict

    mod_render = importlib.import_module(f'{comp_name}.render')
    assert mod_render.build_component(ROOT, cp) == result

    output_data = json.loads((ROOT / c['output']).read_text(encoding='utf-8'))
    assert output_data == result

    mod_parser = importlib.import_module(f'{comp_name}.parser')
    assert mod_parser.parse(copy.deepcopy(before), copy.deepcopy(cc)) == result

    print(f'MODULE_OK {comp_name}')

print('ALL MODULE CHECKS PASSED')
