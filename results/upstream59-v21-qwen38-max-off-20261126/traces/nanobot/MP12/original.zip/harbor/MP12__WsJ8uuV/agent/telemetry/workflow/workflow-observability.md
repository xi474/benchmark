# Workflow 可观测性报告

- Trial：`MP12__WsJ8uuV__env`
- Task：`MP12`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（54 节点 / 53 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：54；执行边：53（observed=0，inferred=53）
- Execution Trace Graph：`observed`；temporal_next 边 53，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3e2f36d17f894e0fa600b8e7 -> tool:nanobot-harness-v3:call_8ea1a09e00204c1da25cdfbb -> tool:nanobot-harness-v3:call_8abe3439ca174fc0a253fe94 -> tool:nanobot-harness-v3:call_74db23dbb6bc4fd790166869 -> tool:nanobot-harness-v3:call_4ae2c3a9511a4c5d8fd563b7 -> tool:nanobot-harness-v3:call_e71dbfe74bc7431faca456d9 -> tool:nanobot-harness-v3:call_5c542773239d47f7b552009b -> tool:nanobot-harness-v3:call_548ac1f3584c4a33b6c5c6c8 -> tool:nanobot-harness-v3:call_5ccc46b94c8f4b819ea45ec9 -> tool:nanobot-harness-v3:call_57deeca7de1e44acac54361d -> tool:nanobot-harness-v3:call_17317d1dde07484fa6e32ae5 -> tool:nanobot-harness-v3:call_a1bddd067ce04950bb98ebee -> tool:nanobot-harness-v3:call_09b478db222946329094367e -> tool:nanobot-harness-v3:call_42f9da17044f4c34b0bdd215 -> tool:nanobot-harness-v3:call_d752124dde194dc8b19404aa -> tool:nanobot-harness-v3:call_4be34b73e9514498a4d1b923 -> tool:nanobot-harness-v3:call_15095829bb9f45039ccfd210 -> tool:nanobot-harness-v3:call_3ce10b1c78c84096a3082832 -> tool:nanobot-harness-v3:call_eabc8cdd6e2943adbdb146c6 -> tool:nanobot-harness-v3:call_76e2aa584cef4a7ab06a7d23 -> tool:nanobot-harness-v3:call_ff8fa6084f9e425eab7c7a83 -> tool:nanobot-harness-v3:call_acb70fa19f904958b7bf0707 -> tool:nanobot-harness-v3:call_387054ac48e0488d8c71551d -> tool:nanobot-harness-v3:call_41ed3a955e0f4d01ab1b731d -> tool:nanobot-harness-v3:call_41c185b0e57e4605a74bf382 -> tool:nanobot-harness-v3:call_d0d3b065bbe74611b1bdd6b4 -> tool:nanobot-harness-v3:call_4f3d2ee069fd47b9b1c6f27b -> tool:nanobot-harness-v3:call_685053a9e7074da9a1e76c02 -> tool:nanobot-harness-v3:call_5af35d3d151c4ac6962b06dd -> tool:nanobot-harness-v3:call_902e7484e6dc4b4a8ccd3701 -> tool:nanobot-harness-v3:call_ac8adc91807d4b1eaf5501f0 -> tool:nanobot-harness-v3:call_4acb9e9bf1044626950f6d74 -> tool:nanobot-harness-v3:call_1d9c75bbba534d9b898b683a -> tool:nanobot-harness-v3:call_2609d09a75fd47f88996cc1e -> tool:nanobot-harness-v3:call_ffd9d5c27ebb4683906afddb -> tool:nanobot-harness-v3:call_0466e22a3e4d4f8aaf9c3859 -> tool:nanobot-harness-v3:call_33d7ef0f9ded4cd0b78e6290 -> tool:nanobot-harness-v3:call_532ca6dd06c84367b90a04ab -> tool:nanobot-harness-v3:call_53432a04c68f4252b4bf5fb2 -> tool:nanobot-harness-v3:call_2bad8bf4dc324b1ebb41e78c -> tool:nanobot-harness-v3:call_b462d8bab26e4235a49d7661 -> tool:nanobot-harness-v3:call_d3bfa045934744a9a90b3e21 -> tool:nanobot-harness-v3:call_bb86d53233a942b1a115d66d -> tool:nanobot-harness-v3:call_4723ad3422d948ccb2cfb7e3 -> tool:nanobot-harness-v3:call_76430b771d48476285025f6a -> tool:nanobot-harness-v3:call_8f3634dc7ec94c35a01f4dc0 -> tool:nanobot-harness-v3:call_2568f5b0e941473891b0bf3b -> tool:nanobot-harness-v3:call_cd3b733428534c7c870abab9 -> tool:nanobot-harness-v3:call_db1389f3f1fb4fa0b76ee345 -> tool:nanobot-harness-v3:call_5fb5521fd020401690f758a6 -> tool:nanobot-harness-v3:call_c8330fe044524ac587ef354a -> tool:nanobot-harness-v3:call_5273d384e88e4d3fb7bdca3c -> tool:nanobot-harness-v3:call_4ecac7b0ea8c4270ba8bdaf4
- 关键路径耗时：1.057505
- Makespan：353.496372
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
