#!/usr/bin/env python3
"""Generate final_report.json from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core['components']

    # Compute sha256 of the complete core object
    core_bytes = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(core_bytes).hexdigest()

    # Determine attention list
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        flagged = False

        # blocked explicitly true
        if result.get('blocked') is True:
            flagged = True

        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                flagged = True
                break

        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0 and val is not False:
                # Non-empty check: lists/dicts with len > 0, non-empty strings
                if isinstance(val, (list, dict)) and len(val) > 0:
                    flagged = True
                    break
                elif isinstance(val, str) and len(val) > 0:
                    flagged = True
                    break

        if flagged:
            attention.append(name)

    attention.sort()

    report = {
        "title": "下载目录归档、邮件清理与目标回复",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    print("FINAL_REPORT_OK")


if __name__ == '__main__':
    main()
