def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]       # original snapshot
    files_result = payloads[1]  # download_archive result
    mail_result = payloads[2]   # mail_trash result
    reply_result = payloads[3]  # manager_reply result

    # Extract results - handle both wrapped and unwrapped
    if isinstance(files_result, dict) and 'result' in files_result:
        files_data = files_result['result']
    else:
        files_data = files_result

    if isinstance(mail_result, dict) and 'result' in mail_result:
        mail_data = mail_result['result']
    else:
        mail_data = mail_result

    if isinstance(reply_result, dict) and 'result' in reply_result:
        reply_data = reply_result['result']
    else:
        reply_data = reply_result

    trash_ids = set(mail_data.get('trash_ids', []))
    moves = files_data.get('moves', [])

    # Check conflict: reply email in trash_ids
    reply_email_id = reply_data['email_id']
    if reply_email_id in trash_ids:
        raise ValueError(f"reply email {reply_email_id} is in trash_ids - commit conflict")

    # Start with original files and emails
    original_files = case['files']
    original_emails = case['emails']

    # Build move map: from -> to
    move_map = {}
    for m in moves:
        move_map[m['from']] = m['to']

    # Apply moves to files
    new_files = []
    for f in original_files:
        fpath = f['path']
        if fpath in move_map:
            new_files.append({"path": move_map[fpath], "hex": f['hex']})
        else:
            new_files.append({"path": fpath, "hex": f['hex']})

    # Sort files by path
    new_files.sort(key=lambda x: x['path'])

    # Apply trash to emails
    new_emails = []
    for email in original_emails:
        e = dict(email)  # shallow copy
        if e['id'] in trash_ids:
            e['folder'] = 'TRASH'
        new_emails.append(e)

    # Sort emails by id
    new_emails.sort(key=lambda x: x['id'])

    return {
        "name": contract["name"],
        "result": {
            "files": new_files,
            "emails": new_emails,
            "reply": reply_data
        }
    }
