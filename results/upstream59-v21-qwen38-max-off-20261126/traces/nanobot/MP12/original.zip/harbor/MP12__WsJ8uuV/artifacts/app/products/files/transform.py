import os
from pathlib import PurePosixPath


def _validate_safe_path(p):
    """Validate that a path is safe: relative, no backslash, no colon, no empty segments, no . or .."""
    s = str(p)
    if not s or s.startswith('/') or '\\' in s or ':' in s:
        raise ValueError(f"unsafe path: {s}")
    parts = PurePosixPath(s).parts
    for part in parts:
        if part in ('', '.', '..'):
            raise ValueError(f"unsafe path segment: {part}")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]

    files = case['files']
    download_prefix = case['download_prefix']
    archive_prefix = case['archive_prefix']
    extensions = case['extensions']

    # Build lowercase extension map
    ext_map = {}
    for ext, subdir in extensions.items():
        ext_map[ext.lower()] = subdir

    moves = []
    for f in files:
        fpath = f['path']
        _validate_safe_path(fpath)

        pp = PurePosixPath(fpath)
        parent = str(pp.parent)

        # Only process direct children of download_prefix
        if parent != download_prefix:
            continue

        basename = pp.name
        # Get extension case-insensitively
        dot_idx = basename.rfind('.')
        if dot_idx == -1:
            continue
        ext_lower = basename[dot_idx:].lower()

        if ext_lower not in ext_map:
            continue

        subdir = ext_map[ext_lower]
        to_path = f"{archive_prefix}/{subdir}/{basename}"
        _validate_safe_path(to_path)

        moves.append({"from": fpath, "to": to_path})

    # Sort by from
    moves.sort(key=lambda m: m["from"])

    return {"name": contract["name"], "result": {"moves": moves}}
