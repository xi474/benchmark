def _validate_date(date_str):
    """Validate YYYY-MM-DD format and that it's a real date."""
    if not isinstance(date_str, str):
        raise ValueError("date must be string")
    parts = date_str.split('-')
    if len(parts) != 3:
        raise ValueError(f"invalid date format: {date_str}")
    try:
        y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
    except ValueError:
        raise ValueError(f"invalid date format: {date_str}")
    if m < 1 or m > 12:
        raise ValueError(f"invalid month in date: {date_str}")
    # Days per month (handle leap year)
    days_in_month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0):
        days_in_month[2] = 29
    if d < 1 or d > days_in_month[m]:
        raise ValueError(f"invalid day in date: {date_str}")
    return y, m


def _validate_month(month_str):
    """Validate YYYY-MM format."""
    if not isinstance(month_str, str):
        raise ValueError("month must be string")
    parts = month_str.split('-')
    if len(parts) != 2:
        raise ValueError(f"invalid month format: {month_str}")
    try:
        y, m = int(parts[0]), int(parts[1])
    except ValueError:
        raise ValueError(f"invalid month format: {month_str}")
    if m < 1 or m > 12:
        raise ValueError(f"invalid month: {month_str}")
    return y, m


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]

    emails = case['emails']
    month = case['month']
    trash_keyword = case['trash_keyword']

    target_y, target_m = _validate_month(month)
    keyword_lower = trash_keyword.casefold()

    trash_ids = []
    for email in emails:
        # Validate date
        ey, em = _validate_date(email['date'])

        # Check month match
        if ey != target_y or em != target_m:
            continue

        # Check subject contains keyword (casefold)
        if keyword_lower not in email['subject'].casefold():
            continue

        # Check folder is not TRASH
        if email['folder'] == 'TRASH':
            continue

        trash_ids.append(email['id'])

    trash_ids.sort()

    return {"name": contract["name"], "result": {"trash_ids": trash_ids}}
