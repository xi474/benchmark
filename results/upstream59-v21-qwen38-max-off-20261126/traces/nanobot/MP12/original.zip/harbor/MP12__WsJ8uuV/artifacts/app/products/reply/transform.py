def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]

    emails = case['emails']
    reply_email_id = case['reply_email_id']
    manager = case['manager']
    reply_text = case['reply_text']

    # Find target email
    target = None
    for email in emails:
        if email['id'] == reply_email_id:
            target = email
            break

    if target is None:
        raise ValueError(f"reply_email_id {reply_email_id} not found")

    if target['sender'] != manager:
        raise ValueError(f"email {reply_email_id} sender {target['sender']} != manager {manager}")

    return {
        "name": contract["name"],
        "result": {
            "email_id": reply_email_id,
            "thread_id": target['thread_id'],
            "to": manager,
            "text": reply_text
        }
    }
