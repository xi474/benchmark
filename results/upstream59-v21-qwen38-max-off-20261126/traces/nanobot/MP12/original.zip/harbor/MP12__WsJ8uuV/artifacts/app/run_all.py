#!/usr/bin/env python3
"""Run all components in dependency order, then integrate."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_component(component_dir):
    """Run a component's render.py from the workspace root."""
    render_py = ROOT / 'products' / component_dir / 'render.py'
    if not render_py.exists():
        print(f"ERROR: {render_py} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run(
        [sys.executable, str(render_py)],
        cwd=str(ROOT),
        timeout=60
    )
    if result.returncode != 0:
        print(f"ERROR: {component_dir} render.py failed with code {result.returncode}", file=sys.stderr)
        sys.exit(result.returncode)


def main():
    # Ensure outputs directory exists
    (ROOT / 'outputs').mkdir(parents=True, exist_ok=True)

    # Run independent components first (order among them doesn't matter)
    run_component('files')
    run_component('mail')
    run_component('reply')

    # Run commit (depends on files, mail, reply outputs)
    run_component('commit')

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    result = subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=str(ROOT),
        timeout=60
    )
    if result.returncode != 0:
        print("ERROR: integrate.py failed", file=sys.stderr)
        sys.exit(result.returncode)

    # Run final_report.py
    final_report_py = ROOT / 'final_report.py'
    result = subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=str(ROOT),
        timeout=60
    )
    if result.returncode != 0:
        print("ERROR: final_report.py failed", file=sys.stderr)
        sys.exit(result.returncode)

    print("ALL_COMPONENTS_OK")


if __name__ == '__main__':
    main()
