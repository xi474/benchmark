import sys, shutil
if not sys.executable:
    p = shutil.which('python3')
    if p:
        sys.executable = p
