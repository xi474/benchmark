# Workflow 可观测性报告

- Trial：`MP13__8taqwei__env`
- Task：`MP13`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（61 节点 / 60 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：61；执行边：60（observed=0，inferred=60）
- Execution Trace Graph：`observed`；temporal_next 边 60，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_5b98c5185c2e42b0b14c374b -> tool:nanobot-harness-v3:call_ad4a6eab63a94492b96736d2 -> tool:nanobot-harness-v3:call_f6042e4ed24049b4b85778d9 -> tool:nanobot-harness-v3:call_c6d336ed5b524f17a58618ac -> tool:nanobot-harness-v3:call_aee4ac99bcef429b8eb2051e -> tool:nanobot-harness-v3:call_e32df36636174ebdb6acb150 -> tool:nanobot-harness-v3:call_0de0c1de06a24d7085f09078 -> tool:nanobot-harness-v3:call_64648d57c04348128f1175f0 -> tool:nanobot-harness-v3:call_c8691de96f5b444488342fd6 -> tool:nanobot-harness-v3:call_c9a94ac97201481fa3a4d7d3 -> tool:nanobot-harness-v3:call_e611fc83c9c74164b5daf0d3 -> tool:nanobot-harness-v3:call_52d5d6f0624242b6b6b2a718 -> tool:nanobot-harness-v3:call_0a34c239829f482da2c4d748 -> tool:nanobot-harness-v3:call_42874b906cfc4aedad0250e2 -> tool:nanobot-harness-v3:call_7d3d75b18b044bd99e74afcd -> tool:nanobot-harness-v3:call_4701448698094356891a72f1 -> tool:nanobot-harness-v3:call_6f2f2f4d299f469f9e8d08f3 -> tool:nanobot-harness-v3:call_866d6e8d620f41d795a1095c -> tool:nanobot-harness-v3:call_5835bf684da04940ba9ade14 -> tool:nanobot-harness-v3:call_7a5171c9d6fb48aab8a1c4fc -> tool:nanobot-harness-v3:call_9b2d61f8b5624e47b3d846c0 -> tool:nanobot-harness-v3:call_cace9ea97eab45e09c1f0cdd -> tool:nanobot-harness-v3:call_5d6331b72f5b49b0973c55a1 -> tool:nanobot-harness-v3:call_725513fd466a40fba38f77f7 -> tool:nanobot-harness-v3:call_2f74783afafe401c9c5d8315 -> tool:nanobot-harness-v3:call_75743c93843043e6bfe149f5 -> tool:nanobot-harness-v3:call_b3600690e15b4278a2f9a10a -> tool:nanobot-harness-v3:call_b9b7fe2759b94377949d48dc -> tool:nanobot-harness-v3:call_e01a3400bceb4889a4191a20 -> tool:nanobot-harness-v3:call_fce162fbaae2401099136d12 -> tool:nanobot-harness-v3:call_74763e06479342ce80cb59a9 -> tool:nanobot-harness-v3:call_06143f678d984d0881b0dfec -> tool:nanobot-harness-v3:call_fb6d06859deb42c9b2b8869e -> tool:nanobot-harness-v3:call_c9cede5c3cc94ff19226f206 -> tool:nanobot-harness-v3:call_50b074ba45094c93adb964dc -> tool:nanobot-harness-v3:call_4985b5866b5c4150a4e4a96c -> tool:nanobot-harness-v3:call_f96d3e335ab043d785e1f2e8 -> tool:nanobot-harness-v3:call_c2af7445d3a44c24ba7811e1 -> tool:nanobot-harness-v3:call_ff63f5d108d74fb993d97878 -> tool:nanobot-harness-v3:call_affcb49e705a400f9c8353e9 -> tool:nanobot-harness-v3:call_0237e1e3385541a7a1a16322 -> tool:nanobot-harness-v3:call_a4baad2584b44392bec2efbf -> tool:nanobot-harness-v3:call_184a8701026b4950aea98d13 -> tool:nanobot-harness-v3:call_49e5aa1e465842688f755974 -> tool:nanobot-harness-v3:call_ea9192f3a5f74f8284df0661 -> tool:nanobot-harness-v3:call_ac0fa9b805294e5f9ef90b3b -> tool:nanobot-harness-v3:call_a8a986065f1b45e583ac203d -> tool:nanobot-harness-v3:call_b941254c911b4ae9966b4b37 -> tool:nanobot-harness-v3:call_dde63004a505498f86f66eca -> tool:nanobot-harness-v3:call_5cceb761d008484fa7101d58 -> tool:nanobot-harness-v3:call_53c311aa2b2c4a74bb66bd2e -> tool:nanobot-harness-v3:call_dce31bfa6bf948dd97b575e5 -> tool:nanobot-harness-v3:call_d739092902f840eea13d5e74 -> tool:nanobot-harness-v3:call_48df13c9c7aa4ff4b5e8ebdc -> tool:nanobot-harness-v3:call_b74fa2dbd3a84d008cbead03 -> tool:nanobot-harness-v3:call_2c174c92133e43a98d21f339 -> tool:nanobot-harness-v3:call_0f9b608f635c43c6bc6f8deb -> tool:nanobot-harness-v3:call_22bbc58808cf450d91d638f7 -> tool:nanobot-harness-v3:call_14b9ee36518a4589b38e3e8d -> tool:nanobot-harness-v3:call_1b79e356499246e3bfdb36ae
- 关键路径耗时：0.892811
- Makespan：239.327748
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
