def transform(payloads, contract):
    """Compute category features: boolean columns per vocabulary term per key group."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    data = payloads[0]
    records = data.get('records')
    vocabulary = data.get('vocabulary')
    if records is None or vocabulary is None:
        raise ValueError('missing required fields')
    if not isinstance(records, list) or not isinstance(vocabulary, list):
        raise ValueError('invalid field types')

    # Validate vocabulary: unique non-empty strings
    seen_vocab = set()
    for v in vocabulary:
        if not isinstance(v, str) or not v.strip():
            raise ValueError('vocabulary items must be non-empty strings')
        if v in seen_vocab:
            raise ValueError(f'duplicate vocabulary item: {v}')
        seen_vocab.add(v)

    # Group by key, collect non-null categories
    groups = {}
    for rec in records:
        key = rec.get('key')
        cat = rec.get('category')
        if key not in groups:
            groups[key] = []
        if cat is not None:
            if not isinstance(cat, str):
                raise ValueError('category must be string or null')
            groups[key].append(cat)

    rows = []
    for key in sorted(groups.keys()):
        cats = groups[key]
        if not cats:
            # All-null group: skip this key
            continue
        values = {}
        for term in vocabulary:
            values[term] = term in cats
        rows.append({
            'key': key,
            'values': values
        })

    return {'name': contract['name'], 'result': {'rows': rows}}
