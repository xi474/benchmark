def transform(payloads, contract):
    """Compute numeric features: count, sum, mean per key group."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    data = payloads[0]
    records = data.get('records')
    vocabulary = data.get('vocabulary')
    if records is None or vocabulary is None:
        raise ValueError('missing required fields')
    if not isinstance(records, list) or not isinstance(vocabulary, list):
        raise ValueError('invalid field types')

    # Validate record IDs are unique
    seen_ids = set()
    for rec in records:
        rid = rec.get('id')
        if rid in seen_ids:
            raise ValueError(f'duplicate record id: {rid}')
        seen_ids.add(rid)

    # Group by key, collect non-null values
    groups = {}
    for rec in records:
        key = rec.get('key')
        value = rec.get('value')
        if key not in groups:
            groups[key] = []
        if value is not None:
            # Validate finite number (not bool)
            if isinstance(value, bool):
                raise ValueError('bool not allowed as value')
            if not isinstance(value, (int, float)):
                raise ValueError('value must be finite number or null')
            groups[key].append(value)

    rows = []
    for key in sorted(groups.keys()):
        vals = groups[key]
        count = len(vals)
        s = sum(vals) if count > 0 else 0
        mean = s / count if count > 0 else None
        rows.append({
            'key': key,
            'values': {
                'count': count,
                'sum': s,
                'mean': mean
            }
        })

    return {'name': contract['name'], 'result': {'rows': rows}}
