def transform(payloads, contract):
    """Compute time features: first, last, span per key group."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')
    data = payloads[0]
    records = data.get('records')
    vocabulary = data.get('vocabulary')
    if records is None or vocabulary is None:
        raise ValueError('missing required fields')
    if not isinstance(records, list) or not isinstance(vocabulary, list):
        raise ValueError('invalid field types')

    # Group by key, collect non-null integer times
    groups = {}
    for rec in records:
        key = rec.get('key')
        t = rec.get('time')
        if key not in groups:
            groups[key] = []
        if t is not None:
            if isinstance(t, bool) or not isinstance(t, int):
                raise ValueError('time must be integer or null')
            groups[key].append(t)

    rows = []
    for key in sorted(groups.keys()):
        times = groups[key]
        if not times:
            # All-null time group: omit
            continue
        first = min(times)
        last = max(times)
        span = last - first
        rows.append({
            'key': key,
            'values': {
                'first': first,
                'last': last,
                'span': span
            }
        })

    return {'name': contract['name'], 'result': {'rows': rows}}
