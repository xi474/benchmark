def transform(payloads, contract):
    """Feature union: outer join of numeric, category, time features by key."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError('payload count mismatch')

    numeric_data = payloads[0]  # {rows:[{key,values:{count,sum,mean}}]}
    category_data = payloads[1]  # {rows:[{key,values:{vocab:bool}}]}
    time_data = payloads[2]  # {rows:[{key,values:{first,last,span}}]}

    # Extract rows from each, handling both raw result and envelope formats
    def get_rows(data):
        if 'result' in data and isinstance(data['result'], dict) and 'rows' in data['result']:
            return data['result']['rows']
        if 'rows' in data:
            return data['rows']
        raise ValueError('cannot find rows in input')

    num_rows = get_rows(numeric_data)
    cat_rows = get_rows(category_data)
    time_rows = get_rows(time_data)

    # Build dicts keyed by key
    num_dict = {r['key']: r['values'] for r in num_rows}
    cat_dict = {r['key']: r['values'] for r in cat_rows}
    time_dict = {r['key']: r['values'] for r in time_rows}

    # Collect all keys (outer join)
    all_keys = sorted(set(list(num_dict.keys()) + list(cat_dict.keys()) + list(time_dict.keys())))

    # Determine column names with prefixes
    num_cols = set()
    for v in num_dict.values():
        num_cols.update(v.keys())
    cat_cols = set()
    for v in cat_dict.values():
        cat_cols.update(v.keys())
    time_cols = set()
    for v in time_dict.values():
        time_cols.update(v.keys())

    prefixed_num = ['num.' + c for c in sorted(num_cols)]
    prefixed_cat = ['cat.' + c for c in sorted(cat_cols)]
    prefixed_time = ['time.' + c for c in sorted(time_cols)]

    all_columns = sorted(set(prefixed_num + prefixed_cat + prefixed_time))

    # Build data rows
    data = []
    for key in all_keys:
        row = {}
        nv = num_dict.get(key, {})
        cv = cat_dict.get(key, {})
        tv = time_dict.get(key, {})
        for col in all_columns:
            if col.startswith('num.'):
                orig = col[4:]
                row[col] = nv.get(orig) if orig in nv else None
            elif col.startswith('cat.'):
                orig = col[4:]
                row[col] = cv.get(orig) if orig in cv else None
            elif col.startswith('time.'):
                orig = col[5:]
                row[col] = tv.get(orig) if orig in tv else None
        data.append([row[c] for c in all_columns])

    return {
        'name': contract['name'],
        'result': {
            'index': all_keys,
            'columns': all_columns,
            'data': data
        }
    }
