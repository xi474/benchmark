import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core_text = core_path.read_text(encoding='utf-8')
    core = json.loads(core_text)

    components = core.get('components', {})

    # Compute sha256 of the full core object
    canonical = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256_hex = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for flag in ('complete', 'checkout', 'committed', 'ok'):
            if flag in result and result[flag] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for field in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(field)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # Non-empty check: any truthy value that isn't empty collection
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)
                elif isinstance(val, bool) and val is True:
                    attention.add(comp_name)

    report = {
        'title': '\u805a\u5408\u7279\u5f81\u7684\u884c\u952e\u4fdd\u771f\u4e0e\u7279\u5f81\u5408\u5e76',
        'component_count': len(components),
        'sha256': sha256_hex,
        'attention': sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
