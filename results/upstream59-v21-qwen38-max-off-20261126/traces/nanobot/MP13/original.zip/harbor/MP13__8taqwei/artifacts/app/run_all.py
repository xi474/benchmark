import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or 'python3'


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' not in rel.parts:
            contracts.append(cp)

    if not contracts:
        print('No contracts found', file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: contract output -> contract path
    # and contract inputs -> list of required outputs
    contract_map = {}  # output_path -> contract_path
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['output']] = cp

    # Topological sort based on input dependencies
    visited = set()
    order = []

    def visit(output_path):
        if output_path in visited:
            return
        if output_path in contract_map:
            cp = contract_map[output_path]
            c = json.loads(cp.read_text(encoding='utf-8'))
            for inp in c['inputs']:
                visit(inp)
            visited.add(output_path)
            order.append(cp)

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        visit(c['output'])

    # Execute each component in order via its render.py
    for cp in order:
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f'Missing render.py for {cp}', file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f'Component failed: {cp}', file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.exists():
        result = subprocess.run(
            [PYTHON, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print('integrate.py failed', file=sys.stderr)
            sys.exit(1)

    # Run final_report.py to produce final_report.json
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.exists():
        result = subprocess.run(
            [PYTHON, str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print('final_report.py failed', file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
