# Workflow 可观测性报告

- Trial：`MP14__uvM5bVG__env`
- Task：`MP14`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（73 节点 / 72 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：73；执行边：72（observed=0，inferred=72）
- Execution Trace Graph：`observed`；temporal_next 边 72，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d3b66048a47a4cc5a8918a1d -> tool:nanobot-harness-v3:call_d023cb2ce89d4cdfbf1c2d62 -> tool:nanobot-harness-v3:call_ff4eb88959664f05b69babeb -> tool:nanobot-harness-v3:call_208def5224af4be9987d9920 -> tool:nanobot-harness-v3:call_4bbd18bdd20e49e195aa5384 -> tool:nanobot-harness-v3:call_ba86d4605d8442ecb7ebfb09 -> tool:nanobot-harness-v3:call_a3a91415765d4703b2b1aa41 -> tool:nanobot-harness-v3:call_19ddb5b5280b410b85c9e3ad -> tool:nanobot-harness-v3:call_ee811ec7c9b1496b85100ef2 -> tool:nanobot-harness-v3:call_f83c9e791b324c5bb01384f4 -> tool:nanobot-harness-v3:call_250be4bf810c416ab678e878 -> tool:nanobot-harness-v3:call_34609791c83844df8ce092d8 -> tool:nanobot-harness-v3:call_0b776c68ab5c4abbac069053 -> tool:nanobot-harness-v3:call_f9d02402e4b64144b19196ac -> tool:nanobot-harness-v3:call_fa317f9900534ea386bf8815 -> tool:nanobot-harness-v3:call_5c10f75ad89241d19d27a62a -> tool:nanobot-harness-v3:call_927ac1f55496406eb61cdae8 -> tool:nanobot-harness-v3:call_ee3ca4af43a04610b8d2beff -> tool:nanobot-harness-v3:call_4b8e491797e7435c807ab39d -> tool:nanobot-harness-v3:call_c01243b7146b44a4ac30680a -> tool:nanobot-harness-v3:call_601b87c7eec14e9ba909a9da -> tool:nanobot-harness-v3:call_1ff568b8cb46455998f2dca1 -> tool:nanobot-harness-v3:call_4c1990cb06844b7388eeecd9 -> tool:nanobot-harness-v3:call_6ff58eee22da44c694540749 -> tool:nanobot-harness-v3:call_b058c56df2734b1aa479dc4c -> tool:nanobot-harness-v3:call_81df5ace104b4b1c841719ed -> tool:nanobot-harness-v3:call_4c29c7a0d941489ba9812a81 -> tool:nanobot-harness-v3:call_2c775ccc83234c5592596adc -> tool:nanobot-harness-v3:call_dc2cf8b11d1b4fa3b7dda07b -> tool:nanobot-harness-v3:call_0a9f1c12b2f84877989da3d1 -> tool:nanobot-harness-v3:call_05f0d33042f3473a8dbfbc89 -> tool:nanobot-harness-v3:call_60161f715ecf46149703fa0c -> tool:nanobot-harness-v3:call_0fa2991146df4627933fecf7 -> tool:nanobot-harness-v3:call_5fa9df966858445ba28d7259 -> tool:nanobot-harness-v3:call_0b2ef389e7a94347b79c630d -> tool:nanobot-harness-v3:call_f092b08410a14925a58d6625 -> tool:nanobot-harness-v3:call_e8845802e9f74e4d89c34c2b -> tool:nanobot-harness-v3:call_b026c01e24d84496b15ffae0 -> tool:nanobot-harness-v3:call_649fc31d4edc4439a2191d0e -> tool:nanobot-harness-v3:call_58029feedb6c4e36b7934f59 -> tool:nanobot-harness-v3:call_eceab66adb4142b0a6d3d2fb -> tool:nanobot-harness-v3:call_ad6e4198f22046d699bc42db -> tool:nanobot-harness-v3:call_b58e395c570b441699ae0793 -> tool:nanobot-harness-v3:call_ae7c00c25aa141e4af2eb135 -> tool:nanobot-harness-v3:call_d6814fe3111e4b9995e8d39b -> tool:nanobot-harness-v3:call_114ee89910c04bb389479048 -> tool:nanobot-harness-v3:call_ddbcaa4c059a462fb64f6738 -> tool:nanobot-harness-v3:call_7e84f394963a49ef91f1da5d -> tool:nanobot-harness-v3:call_22bac8a2717b4d0e87516262 -> tool:nanobot-harness-v3:call_e43e3c043d0445cf903f576f -> tool:nanobot-harness-v3:call_492d06b40f77484e8a195406 -> tool:nanobot-harness-v3:call_694b136739e848eab4b81e2a -> tool:nanobot-harness-v3:call_7691e4b9442849ab8cfcb896 -> tool:nanobot-harness-v3:call_cef7322ac2bc423c98ce9eb0 -> tool:nanobot-harness-v3:call_61cbf4f6e530429eb82e0f06 -> tool:nanobot-harness-v3:call_c9a44e5f3fd746a18d975ce1 -> tool:nanobot-harness-v3:call_47067fd8a3824012ac523112 -> tool:nanobot-harness-v3:call_88ec1c375baa441cba5c2ef5 -> tool:nanobot-harness-v3:call_5ae29ce341374f3aa1009633 -> tool:nanobot-harness-v3:call_706dc3bbbfd04663a6e6529a -> tool:nanobot-harness-v3:call_7788b6de52964742a0918c11 -> tool:nanobot-harness-v3:call_877abae45df64e36816feba4 -> tool:nanobot-harness-v3:call_93ab2b33ec1c46e2bf3d1a64 -> tool:nanobot-harness-v3:call_1b8ef3a13dbd4bac88384636 -> tool:nanobot-harness-v3:call_8955b1a2de244b369fa8d59d -> tool:nanobot-harness-v3:call_5970789ee0014536a8f83491 -> tool:nanobot-harness-v3:call_16e742b2cec343279a262274 -> tool:nanobot-harness-v3:call_6023c7144d4641c499955e8a -> tool:nanobot-harness-v3:call_4aa497d5028a403cab3c7f1b -> tool:nanobot-harness-v3:call_46018735522b45cba6843bb0 -> tool:nanobot-harness-v3:call_9c61b6640ad64029a920042b -> tool:nanobot-harness-v3:call_3873f2551dc34377b69fd664
- 关键路径耗时：1.31847
- Makespan：330.931479
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
