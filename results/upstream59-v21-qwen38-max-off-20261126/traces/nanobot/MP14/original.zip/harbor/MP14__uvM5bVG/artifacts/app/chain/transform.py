def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    # Handle name/result wrapper
    if set(data.keys()) == {"name", "result"}:
        data = data["result"]

    required = {"root", "nodes"}
    for k in required:
        if k not in data:
            raise ValueError(f"missing field: {k}")

    root_id = data["root"]
    nodes_list = data["nodes"]
    if not isinstance(root_id, str):
        raise ValueError("root must be string")
    if not isinstance(nodes_list, list):
        raise ValueError("nodes must be list")

    node_map = {}
    for n in nodes_list:
        if not isinstance(n, dict):
            raise ValueError("node must be object")
        for f in ("id", "type", "message", "cause", "context", "suppress_context", "frames"):
            if f not in n:
                raise ValueError(f"node missing field: {f}")
        nid = n["id"]
        if not isinstance(nid, str) or not nid.strip():
            raise ValueError("node id must be non-empty string")
        if not isinstance(n["type"], str) or not n["type"].strip():
            raise ValueError("node type must be non-empty string")
        if not isinstance(n["message"], str):
            raise ValueError("node message must be string")
        if n["cause"] is not None and not isinstance(n["cause"], str):
            raise ValueError("cause must be string or null")
        if n["context"] is not None and not isinstance(n["context"], str):
            raise ValueError("context must be string or null")
        if not isinstance(n["suppress_context"], bool):
            raise ValueError("suppress_context must be bool")
        if not isinstance(n["frames"], list):
            raise ValueError("frames must be list")
        # Validate frames
        for fr in n["frames"]:
            if not isinstance(fr, dict):
                raise ValueError("frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in fr:
                    raise ValueError(f"frame missing field: {ff}")
            if not isinstance(fr["file"], str):
                raise ValueError("frame file must be string")
            if not isinstance(fr["line"], int) or isinstance(fr["line"], bool) or fr["line"] < 1:
                raise ValueError("frame line must be positive int")
            if not isinstance(fr["function"], str) or not fr["function"].strip():
                raise ValueError("frame function must be non-empty string")
            if not isinstance(fr["locals"], dict):
                raise ValueError("frame locals must be object")
        if nid in node_map:
            raise ValueError(f"duplicate node id: {nid}")
        node_map[nid] = n

    if root_id not in node_map:
        raise ValueError(f"root id not found: {root_id}")

    # Build chain from root following cause/context links
    chain = []
    visited = set()
    current_id = root_id
    while current_id is not None:
        if current_id in visited:
            raise ValueError("cycle detected in exception chain")
        if len(chain) >= 8:
            raise ValueError("chain length exceeds limit of 8")
        visited.add(current_id)
        node = node_map[current_id]
        chain.append(node)
        # Determine next: prefer cause, else context if not suppressed
        next_id = None
        link_type = None
        if node["cause"] is not None:
            next_id = node["cause"]
            link_type = "cause"
        elif not node["suppress_context"] and node["context"] is not None:
            next_id = node["context"]
            link_type = "context"
        if next_id is not None and next_id not in node_map:
            raise ValueError(f"referenced node not found: {next_id}")
        current_id = next_id

    # Reverse: innermost first, root last
    chain.reverse()
    result_chain = []
    for i, node in enumerate(chain):
        if i == 0:
            link = None
        else:
            # link is how this node connects to previous (inner) node
            # The outer node's cause/context pointed to the inner node
            # So we need to find what link the NEXT node (toward root) used
            # Actually: chain is innermost..root. chain[i] links to chain[i-1].
            # The link for chain[i] is determined by what field in chain[i] points to chain[i-1]
            prev_node = chain[i]
            inner_id = chain[i - 1]["id"]
            if prev_node["cause"] == inner_id:
                link = "cause"
            elif prev_node["context"] == inner_id:
                link = "context"
            else:
                link = None
        result_chain.append({
            "id": node["id"],
            "type": node["type"],
            "message": node["message"],
            "link": link
        })

    return {"name": contract["name"], "result": {"chain": result_chain}}
