import json
import os


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    # Handle name/result wrapper
    if set(data.keys()) == {"name", "result"}:
        data = data["result"]

    required = {"root", "nodes"}
    for k in required:
        if k not in data:
            raise ValueError(f"missing field: {k}")

    nodes_list = data["nodes"]
    if not isinstance(nodes_list, list):
        raise ValueError("nodes must be list")

    frames_result = {}
    seen_ids = set()
    for n in nodes_list:
        if not isinstance(n, dict):
            raise ValueError("node must be object")
        for f in ("id", "type", "message", "cause", "context", "suppress_context", "frames"):
            if f not in n:
                raise ValueError(f"node missing field: {f}")
        nid = n["id"]
        if not isinstance(nid, str) or not nid.strip():
            raise ValueError("node id must be non-empty string")
        if not isinstance(n["type"], str) or not n["type"].strip():
            raise ValueError("node type must be non-empty string")
        if not isinstance(n["message"], str):
            raise ValueError("node message must be string")
        if n["cause"] is not None and not isinstance(n["cause"], str):
            raise ValueError("cause must be string or null")
        if n["context"] is not None and not isinstance(n["context"], str):
            raise ValueError("context must be string or null")
        if not isinstance(n["suppress_context"], bool):
            raise ValueError("suppress_context must be bool")
        if not isinstance(n["frames"], list):
            raise ValueError("frames must be list")
        if nid in seen_ids:
            raise ValueError(f"duplicate node id: {nid}")
        seen_ids.add(nid)

        processed_frames = []
        for fr in n["frames"]:
            if not isinstance(fr, dict):
                raise ValueError("frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in fr:
                    raise ValueError(f"frame missing field: {ff}")
            if not isinstance(fr["file"], str):
                raise ValueError("frame file must be string")
            if not isinstance(fr["line"], int) or isinstance(fr["line"], bool) or fr["line"] < 1:
                raise ValueError("frame line must be positive int")
            if not isinstance(fr["function"], str) or not fr["function"].strip():
                raise ValueError("frame function must be non-empty string")
            if not isinstance(fr["locals"], dict):
                raise ValueError("frame locals must be object")

            # Normalize file path: backslash to /, then basename only
            normalized_file = fr["file"].replace("\\", "/")
            basename = os.path.basename(normalized_file)

            # Serialize locals values as canonical JSON strings
            locals_serialized = {}
            for var_name in sorted(fr["locals"].keys()):
                val = fr["locals"][var_name]
                locals_serialized[var_name] = json.dumps(
                    val, ensure_ascii=False, sort_keys=True,
                    separators=(",", ":")
                )

            processed_frames.append({
                "file": basename,
                "line": fr["line"],
                "function": fr["function"],
                "locals": locals_serialized
            })

        frames_result[nid] = processed_frames

    return {"name": contract["name"], "result": {"frames": frames_result}}
