def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    chain_data = payloads[0]
    frames_data = payloads[1]

    # Handle name/result wrappers
    if isinstance(chain_data, dict) and set(chain_data.keys()) == {"name", "result"}:
        chain_data = chain_data["result"]
    if isinstance(frames_data, dict) and set(frames_data.keys()) == {"name", "result"}:
        frames_data = frames_data["result"]

    if not isinstance(chain_data, dict) or "chain" not in chain_data:
        raise ValueError("chain input must have 'chain' field")
    if not isinstance(frames_data, dict) or "frames" not in frames_data:
        raise ValueError("frames input must have 'frames' field")

    chain_list = chain_data["chain"]
    frames_map = frames_data["frames"]

    if not isinstance(chain_list, list):
        raise ValueError("chain must be list")
    if not isinstance(frames_map, dict):
        raise ValueError("frames must be object")

    lines = []
    nodes_out = []

    for i, entry in enumerate(chain_list):
        if not isinstance(entry, dict):
            raise ValueError("chain entry must be object")
        for f in ("id", "type", "message", "link"):
            if f not in entry:
                raise ValueError(f"chain entry missing field: {f}")

        nid = entry["id"]
        ntype = entry["type"]
        nmsg = entry["message"]
        link = entry["link"]

        # Add separator before non-first items
        if i > 0:
            if link == "cause":
                lines.append("--- direct cause ---")
            elif link == "context":
                lines.append("--- during handling ---")

        # Get frames for this exception
        node_frames = frames_map.get(nid, [])

        # Add frame lines
        for fr in node_frames:
            lines.append(f"  {fr['file']}:{fr['line']} in {fr['function']}")

        # Add type: message line
        lines.append(f"{ntype}: {nmsg}")

        nodes_out.append({
            "id": nid,
            "type": ntype,
            "message": nmsg,
            "link": link,
            "frames": node_frames
        })

    # Build text: join with newline, add trailing newline if non-empty
    text = "\n".join(lines)
    if text:
        text += "\n"

    return {
        "name": contract["name"],
        "result": {
            "nodes": nodes_out,
            "text": text
        }
    }
