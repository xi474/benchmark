import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or os.environ.get("PYTHON", "python3")


def main():
    # Find all contract.json files (not in outputs)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency order: components whose inputs reference other outputs
    # must run after those components
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = (cp, c)

    # Topological sort based on input dependencies
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"Circular dependency detected: {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        cp, c = contract_map[name]
        for inp in c["inputs"]:
            # Check if this input is an output of another component
            for other_name, (other_cp, other_c) in contract_map.items():
                if other_c["output"] == inp:
                    visit(other_name)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in contract_map:
        visit(name)

    # Execute each component in order
    for name in ordered:
        cp, c = contract_map[name]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        result = subprocess.run(
            [PYTHON, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        result = subprocess.run(
            [PYTHON, str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
