import sys
if not sys.executable:
    import shutil
    sys.executable = shutil.which("python3") or "python3"
