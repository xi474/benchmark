# Workflow 可观测性报告

- Trial：`MP15__8mxuPp6__env`
- Task：`MP15`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（83 节点 / 82 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：83；执行边：82（observed=0，inferred=82）
- Execution Trace Graph：`observed`；temporal_next 边 82，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_5c4f2fa566854e79a8b719bf -> tool:nanobot-harness-v3:call_e5076c01f03246d084a8962f -> tool:nanobot-harness-v3:call_922082d389eb4bc1a58ee23c -> tool:nanobot-harness-v3:call_cba13bd3c9944410be85a5bd -> tool:nanobot-harness-v3:call_6d79abf177354a219701b377 -> tool:nanobot-harness-v3:call_bad7047aac884718aa414916 -> tool:nanobot-harness-v3:call_8bd4d72f39fd4a4494f5303f -> tool:nanobot-harness-v3:call_08e6b9df92d64902b1c8f606 -> tool:nanobot-harness-v3:call_cab4dcaa70e541eab0ca2dc1 -> tool:nanobot-harness-v3:call_94f4a73f183b46ada5163562 -> tool:nanobot-harness-v3:call_bba271e2ebb7457e9081fab8 -> tool:nanobot-harness-v3:call_b4b0560e3feb446ba4b4dedb -> tool:nanobot-harness-v3:call_b5932d2e2e90442e99141b19 -> tool:nanobot-harness-v3:call_34efd8dc396a433ab664f5d9 -> tool:nanobot-harness-v3:call_4dc500c8ead54ae288bb67ca -> tool:nanobot-harness-v3:call_d8138780062740b6a7c5d14d -> tool:nanobot-harness-v3:call_81b463ea10504997bcf78438 -> tool:nanobot-harness-v3:call_652c1a6580764ed98e6888b0 -> tool:nanobot-harness-v3:call_7bf32bcc5b104d63bda1c4ec -> tool:nanobot-harness-v3:call_3b74b62dc5f44ba493df5fa8 -> tool:nanobot-harness-v3:call_5bf6271077c54d45bd6033e5 -> tool:nanobot-harness-v3:call_a3ba508d19474b1193870fe9 -> tool:nanobot-harness-v3:call_2af8d1a5d67142318d07ecfe -> tool:nanobot-harness-v3:call_d582ec4cf23c4d04be066e9f -> tool:nanobot-harness-v3:call_8b22fff0289a49918f6f5154 -> tool:nanobot-harness-v3:call_9752b87a289743948c546501 -> tool:nanobot-harness-v3:call_cbd36cfff37e48cd8474f762 -> tool:nanobot-harness-v3:call_8d478cefd2e94c669deb5708 -> tool:nanobot-harness-v3:call_a1263404d7524b19a12a5c79 -> tool:nanobot-harness-v3:call_a583b7708fa9471b8983c181 -> tool:nanobot-harness-v3:call_fa8e971a8db74d8eb9f47285 -> tool:nanobot-harness-v3:call_c0a4bb080ab645de90b5389c -> tool:nanobot-harness-v3:call_4e0436d0998b4c72ab84ba40 -> tool:nanobot-harness-v3:call_1a43ad5ca68b417cb7ab570d -> tool:nanobot-harness-v3:call_9d220a29673f453d894de7b3 -> tool:nanobot-harness-v3:call_da52e81f3d264644be144ffe -> tool:nanobot-harness-v3:call_8e2dcbbe738d428b84c381b9 -> tool:nanobot-harness-v3:call_150f7c3b00504663bc49e663 -> tool:nanobot-harness-v3:call_d23d5d409f264597911ae292 -> tool:nanobot-harness-v3:call_a1b230a9cd024e8d95e99d1e -> tool:nanobot-harness-v3:call_b3f1e17e53b04136bd333aae -> tool:nanobot-harness-v3:call_1fbb622bdcaa4ed8ab245e9f -> tool:nanobot-harness-v3:call_5dd593f42baa4174905f90e5 -> tool:nanobot-harness-v3:call_b6bc2ea935484bba9dbc8bf5 -> tool:nanobot-harness-v3:call_8696dbfc4f6640ca9894ea2c -> tool:nanobot-harness-v3:call_c7ab34808eee4b0e8609eb1a -> tool:nanobot-harness-v3:call_638bdbdde7de4fa7ad46fe3b -> tool:nanobot-harness-v3:call_0a10cede608b447199e79993 -> tool:nanobot-harness-v3:call_a60ef66716904e67a3b6d345 -> tool:nanobot-harness-v3:call_26b9e2ec7e6a4acb92399230 -> tool:nanobot-harness-v3:call_ec37a97aca2b4050b13e81e3 -> tool:nanobot-harness-v3:call_fd82fa4b066e473e91a09a94 -> tool:nanobot-harness-v3:call_f3bac4eca72c4555a2e9d143 -> tool:nanobot-harness-v3:call_407793dc5ef5475ea51d02db -> tool:nanobot-harness-v3:call_d46b75d7adfd432db5f54b57 -> tool:nanobot-harness-v3:call_a948be9fd134497a9a6f6d8f -> tool:nanobot-harness-v3:call_b30216a67cf544b59ae3bd2f -> tool:nanobot-harness-v3:call_b3b903098a434a8490732fd9 -> tool:nanobot-harness-v3:call_d2ebabb804564009a1ea11c5 -> tool:nanobot-harness-v3:call_87e58ed77ea84752b13d8b01 -> tool:nanobot-harness-v3:call_17a74c60a4af416481397693 -> tool:nanobot-harness-v3:call_248bacacc14b4b6580694a87 -> tool:nanobot-harness-v3:call_5184c630064e49b6968e949d -> tool:nanobot-harness-v3:call_42e97116ea09491598451b14 -> tool:nanobot-harness-v3:call_157291bb8f28490280fe8a2b -> tool:nanobot-harness-v3:call_e4a963fa4e804884a47c30a4 -> tool:nanobot-harness-v3:call_cc7c519eb79a45c8b0d7afa2 -> tool:nanobot-harness-v3:call_e6e61190db3e40e7bbebd4a1 -> tool:nanobot-harness-v3:call_7b123f86a27d46ca9b1411bd -> tool:nanobot-harness-v3:call_77a9a35108904d99b53bfd65 -> tool:nanobot-harness-v3:call_3628c206f80d4b088096a571 -> tool:nanobot-harness-v3:call_29f063f6f97e4d6fa5846e4c -> tool:nanobot-harness-v3:call_dad74490c00e4ccf9b1b5e27 -> tool:nanobot-harness-v3:call_904ad7342cc144e0b0122969 -> tool:nanobot-harness-v3:call_b9911dfd5e6043db9af75296 -> tool:nanobot-harness-v3:call_5fbdf869fe134f0a89163f1b -> tool:nanobot-harness-v3:call_84523320f241417086ef7ade -> tool:nanobot-harness-v3:call_c36b0dd1cbdf48d78547760b -> tool:nanobot-harness-v3:call_14989f29ad7844138ac29304 -> tool:nanobot-harness-v3:call_8a09857313944ec6bfd2db63 -> tool:nanobot-harness-v3:call_f63b1d5deac24e6db40ccd6f -> tool:nanobot-harness-v3:call_bd505419b10c40bebe5b4d2c
- 关键路径耗时：0.605667
- Makespan：588.422566
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
