import ast


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    ordinary_data = payloads[1]
    annotation_data = payloads[2]
    comment_data = payloads[3]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing 'source' field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("'source' must be string")
    ordinary_uses = _extract_uses(ordinary_data, "ordinary")
    annotation_uses = _extract_uses(annotation_data, "annotation")
    comment_uses = _extract_uses(comment_data, "comment")
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e
    module_imports, func_imports = _collect_imports(tree)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            raise ValueError("global/nonlocal not supported")
    func_locals = _collect_func_locals(tree)
    all_imports = []
    for name, info in module_imports.items():
        ub = _check_module_used(name, ordinary_uses, annotation_uses,
                                comment_uses, func_locals, func_imports)
        all_imports.append({"scope": "module", "name": name,
                           "module": info["module"], "line": info["line"],
                           "used_by": ub})
    for fn, limps in func_imports.items():
        for name, info in limps.items():
            ub = _check_func_used(fn, name, ordinary_uses,
                                  annotation_uses, comment_uses)
            all_imports.append({"scope": fn, "name": name,
                               "module": info["module"], "line": info["line"],
                               "used_by": ub})
    all_imports.sort(key=lambda x: (x["scope"], x["line"], x["name"]))
    unused = sorted(
        f"{i['scope']}:{i['name']}" for i in all_imports if not i["used_by"])
    return {"name": contract["name"],
            "result": {"imports": all_imports, "unused": unused}}


def _extract_uses(data, kind):
    if not isinstance(data, dict):
        raise ValueError(f"{kind} data must be dict")
    if "name" not in data or "result" not in data:
        raise ValueError(f"{kind} data missing name/result")
    result = data["result"]
    if not isinstance(result, dict) or "uses" not in result:
        raise ValueError(f"{kind} result missing uses")
    return result["uses"]


def _collect_imports(tree):
    module_imports = {}
    func_imports = {}
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "*":
                    raise ValueError("wildcard import not supported")
                bound = alias.asname if alias.asname else alias.name.split(".")[0]
                if bound in module_imports:
                    raise ValueError(f"duplicate import '{bound}'")
                module_imports[bound] = {
                    "module": alias.name, "line": node.lineno}
        elif isinstance(node, ast.ImportFrom):
            if node.level > 0:
                raise ValueError("relative import not supported")
            for alias in node.names:
                if alias.name == "*":
                    raise ValueError("wildcard import not supported")
                bound = alias.asname if alias.asname else alias.name
                if bound in module_imports:
                    raise ValueError(f"duplicate import '{bound}'")
                module_imports[bound] = {
                    "module": node.module, "line": node.lineno}
        elif isinstance(node, ast.FunctionDef):
            fn = node.name
            li = {}
            for stmt in ast.walk(node):
                if isinstance(stmt, ast.Import):
                    for a in stmt.names:
                        if a.name == "*":
                            raise ValueError("wildcard import")
                        b = a.asname if a.asname else a.name.split(".")[0]
                        if b in li:
                            raise ValueError(f"duplicate import '{b}'")
                        li[b] = {"module": a.name, "line": stmt.lineno}
                elif isinstance(stmt, ast.ImportFrom):
                    if stmt.level > 0:
                        raise ValueError("relative import")
                    for a in stmt.names:
                        if a.name == "*":
                            raise ValueError("wildcard import")
                        b = a.asname if a.asname else a.name
                        if b in li:
                            raise ValueError(f"duplicate import '{b}'")
                        li[b] = {"module": stmt.module, "line": stmt.lineno}
            if li:
                func_imports[fn] = li
    return module_imports, func_imports


def _collect_func_locals(tree):
    func_locals = {}
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            fn = node.name
            ls = set()
            args = node.args
            for a in (args.posonlyargs + args.args + args.kwonlyargs):
                ls.add(a.arg)
            if args.vararg:
                ls.add(args.vararg.arg)
            if args.kwarg:
                ls.add(args.kwarg.arg)
            for stmt in node.body:
                for child in ast.walk(stmt):
                    if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                        ls.add(child.id)
            func_locals[fn] = ls
    return func_locals


def _check_module_used(name, ord_u, ann_u, cmt_u, func_locals, func_imports):
    ub = []
    for u in ord_u:
        if u["name"] != name:
            continue
        if u["scope"] == "module":
            if "ordinary" not in ub:
                ub.append("ordinary")
        elif u["scope"] in func_locals:
            if name in func_locals[u["scope"]]:
                continue  # shadowed by local
            if u["scope"] in func_imports and name in func_imports[u["scope"]]:
                continue  # uses local import
            if "ordinary" not in ub:
                ub.append("ordinary")
    for u in ann_u:
        if u["name"] != name:
            continue
        if u["scope"] == "module":
            if "annotation" not in ub:
                ub.append("annotation")
        elif u["scope"] in func_locals:
            if name in func_locals[u["scope"]]:
                continue
            if u["scope"] in func_imports and name in func_imports[u["scope"]]:
                continue
            if "annotation" not in ub:
                ub.append("annotation")
    for u in cmt_u:
        if u["name"] != name:
            continue
        if u["scope"] == "module":
            if "comment" not in ub:
                ub.append("comment")
        elif u["scope"] in func_locals:
            if name in func_locals[u["scope"]]:
                continue
            if u["scope"] in func_imports and name in func_imports[u["scope"]]:
                continue
            if "comment" not in ub:
                ub.append("comment")
    return ub


def _check_func_used(fn, name, ord_u, ann_u, cmt_u):
    ub = []
    for u in ord_u:
        if u["scope"] == fn and u["name"] == name and "ordinary" not in ub:
            ub.append("ordinary")
    for u in ann_u:
        if u["scope"] == fn and u["name"] == name and "annotation" not in ub:
            ub.append("annotation")
    for u in cmt_u:
        if u["scope"] == fn and u["name"] == name and "comment" not in ub:
            ub.append("comment")
    return ub


def _collect_store_names(node, names_set):
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
            names_set.add(child.id)
