import ast


def _collect_load_names(node, scope, results):
    """Collect all Name(Load) from an AST node."""
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            results.append((scope, child.id, child.lineno))


def _fix_lineno(node, lineno):
    """Set lineno on all nodes that have it."""
    for child in ast.walk(node):
        if hasattr(child, 'lineno'):
            child.lineno = lineno


def _parse_string_annotation(s, lineno):
    """Parse a string annotation as a Python expression. Raise ValueError on bad expr."""
    try:
        tree = ast.parse(s, mode='eval')
    except SyntaxError as e:
        raise ValueError(f"bad string annotation at line {lineno}: {e}") from e
    body = tree.body
    _fix_lineno(body, lineno)
    return body


def _process_annotation(ann, scope, uses):
    """Process a single annotation node, handling string forward refs."""
    if isinstance(ann, ast.Constant) and isinstance(ann.value, str):
        parsed = _parse_string_annotation(ann.value, ann.lineno)
        _collect_load_names(parsed, scope, uses)
    else:
        _collect_load_names(ann, scope, uses)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing 'source' field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.AnnAssign):
            # Module-level annotated assignment
            _process_annotation(node.annotation, "module", uses)
        elif isinstance(node, ast.FunctionDef):
            func_name = node.name
            # Function signature annotations belong to module scope
            all_args = (node.args.posonlyargs + node.args.args +
                        node.args.kwonlyargs)
            for arg in all_args:
                if arg.annotation is not None:
                    _process_annotation(arg.annotation, "module", uses)
            if node.args.vararg and node.args.vararg.annotation:
                _process_annotation(node.args.vararg.annotation, "module", uses)
            if node.args.kwarg and node.args.kwarg.annotation:
                _process_annotation(node.args.kwarg.annotation, "module", uses)
            if node.returns is not None:
                _process_annotation(node.returns, "module", uses)

            # Function body: AnnAssign annotations belong to function scope
            for i, stmt in enumerate(node.body):
                if (i == 0 and isinstance(stmt, ast.Expr) and
                        isinstance(stmt.value, ast.Constant) and
                        isinstance(stmt.value.value, str)):
                    continue  # skip docstring
                if isinstance(stmt, ast.AnnAssign):
                    _process_annotation(stmt.annotation, func_name, uses)

    # Deduplicate and sort by (scope, line, name)
    unique = sorted(set(uses), key=lambda x: (x[0], x[2], x[1]))
    result_uses = [{"scope": s, "name": n, "line": l} for s, n, l in unique]
    return {"name": contract["name"], "result": {"uses": result_uses}}
