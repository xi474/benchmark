import ast


def _collect_load_names_with_line(node, scope, lineno, results):
    """Collect all Name(Load) from an AST node, using given lineno."""
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            results.append((scope, child.id, lineno))


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing 'source' field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    # Parse with type_comments=True to get type comments
    try:
        tree = ast.parse(source, type_comments=True)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []

    # Check for unsupported type comments
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.type_comment is not None:
                raise ValueError("function signature type_comment not supported")
        if isinstance(node, (ast.For, ast.AsyncFor)):
            if node.type_comment is not None:
                raise ValueError("for type_comment not supported")
        if isinstance(node, (ast.With, ast.AsyncWith)):
            if node.type_comment is not None:
                raise ValueError("with type_comment not supported")

    # Build a map of which function each node belongs to
    func_map = {}  # id(node) -> function name
    for top_node in ast.iter_child_nodes(tree):
        if isinstance(top_node, ast.FunctionDef):
            for child in ast.walk(top_node):
                func_map[id(child)] = top_node.name

    # Process Assign nodes with type_comment
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and node.type_comment is not None:
            tc = node.type_comment.strip()
            # # type: ignore should not produce references
            if tc == "ignore" or tc.startswith("ignore["):
                continue
            # Parse the type comment as an expression
            try:
                expr_tree = ast.parse(tc, mode='eval')
            except SyntaxError as e:
                raise ValueError(
                    f"bad type comment at line {node.lineno}: {e}"
                ) from e
            # Determine scope
            scope = func_map.get(id(node), "module")
            _collect_load_names_with_line(expr_tree.body, scope, node.lineno, uses)

    # Deduplicate and sort by (scope, line, name)
    unique = sorted(set(uses), key=lambda x: (x[0], x[2], x[1]))
    result_uses = [{"scope": s, "name": n, "line": l} for s, n, l in unique]
    return {"name": contract["name"], "result": {"uses": result_uses}}
