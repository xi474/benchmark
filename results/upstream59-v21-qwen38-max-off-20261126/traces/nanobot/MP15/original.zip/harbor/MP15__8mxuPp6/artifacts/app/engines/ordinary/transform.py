import ast


def _collect_ordinary_loads(node, scope, results):
    """Collect Name(Load) from node, excluding annotation subtrees and string constants."""
    if isinstance(node, ast.AnnAssign):
        # Skip annotation; only process value and target
        if node.value is not None:
            _collect_ordinary_loads(node.value, scope, results)
        # target is typically Store but may contain Load in subscripts
        _collect_ordinary_loads(node.target, scope, results)
        return
    if isinstance(node, ast.arguments):
        # Skip annotations on arguments; process defaults
        for d in node.defaults:
            _collect_ordinary_loads(d, scope, results)
        for d in node.kw_defaults:
            if d is not None:
                _collect_ordinary_loads(d, scope, results)
        # Do NOT walk into arg.annotation
        return
    if isinstance(node, ast.arg):
        # Skip annotation
        return
    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
        results.append((scope, node.id, node.lineno))
        return
    if isinstance(node, ast.Constant):
        # String constants are not Load names
        return
    for child in ast.iter_child_nodes(node):
        _collect_ordinary_loads(child, scope, results)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    source_data = payloads[0]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing 'source' field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("'source' must be string")

    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e}") from e

    uses = []

    # Validate: no classes, no async functions, no nested/conditional functions
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            raise ValueError("class definition not supported")
        if isinstance(node, ast.AsyncFunctionDef):
            raise ValueError("async function not supported")

    # Check for nested or conditional function definitions
    top_funcs = set()
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            top_funcs.add(id(node))

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and id(node) not in top_funcs:
            raise ValueError("nested or conditional function definition not supported")

    # Process module-level statements
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef):
            func_name = node.name
            # Decorators and defaults are at module scope
            for dec in node.decorator_list:
                _collect_ordinary_loads(dec, "module", uses)
            _collect_ordinary_loads(node.args, "module", uses)
            # Return annotation is annotation, skip for ordinary
            # Function body is at function scope
            for i, stmt in enumerate(node.body):
                # Skip docstring (first statement if it's a string constant expression)
                if (i == 0 and isinstance(stmt, ast.Expr) and
                        isinstance(stmt.value, ast.Constant) and
                        isinstance(stmt.value.value, str)):
                    continue
                _collect_ordinary_loads(stmt, func_name, uses)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            pass  # import statements don't produce Load names
        else:
            _collect_ordinary_loads(node, "module", uses)

    # Deduplicate by (scope, line, name) and sort by (scope, line, name)
    unique = sorted(set(uses), key=lambda x: (x[0], x[2], x[1]))
    result_uses = [{"scope": s, "name": n, "line": l} for s, n, l in unique]
    return {"name": contract["name"], "result": {"uses": result_uses}}
