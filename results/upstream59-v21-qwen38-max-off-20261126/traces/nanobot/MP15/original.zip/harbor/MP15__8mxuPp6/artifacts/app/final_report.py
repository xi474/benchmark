import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    if not core_path.exists():
        raise ValueError("core_manifest.json not found")

    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    # Compute sha256 of the canonical serialization
    canonical = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha = hashlib.sha256(canonical).hexdigest()

    # Determine attention list
    attention = set()
    components = core.get("components", {})
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # Check blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)
        # Check complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # Check unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != "" and val != {}:
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)

    report = {
        "title": "普通引用、注解和类型注释的导入分析",
        "component_count": len(components),
        "sha256": sha,
        "attention": sorted(attention)
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True,
                      indent=2, allow_nan=False)
    out_path.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
