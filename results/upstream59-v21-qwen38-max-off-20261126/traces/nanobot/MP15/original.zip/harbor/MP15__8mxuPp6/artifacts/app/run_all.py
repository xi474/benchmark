import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or "python3"


def main():
    # Find all contract.json files (excluding outputs)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    # Build dependency order: components whose inputs don't depend on
    # other outputs come first
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = {"path": cp, "contract": c}

    # Topological sort based on output dependencies
    ordered = _topo_sort(contract_map)

    # Execute each component in order
    for name in ordered:
        info = contract_map[name]
        cp = info["path"]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            raise ValueError(f"render.py not found for {name}")
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT, capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED {name}: {result.stderr}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=ROOT, capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED integrate: {result.stderr}", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.exists():
        result = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=ROOT, capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            print(f"FAILED final_report: {result.stderr}", file=sys.stderr)
            sys.exit(1)


def _topo_sort(contract_map):
    """Topological sort of components based on output file dependencies."""
    # Map output paths to component names
    output_to_name = {}
    for name, info in contract_map.items():
        out = info["contract"]["output"]
        output_to_name[out] = name

    # Build adjacency: component depends on components whose outputs it uses
    deps = {}
    for name, info in contract_map.items():
        deps[name] = set()
        for inp in info["contract"]["inputs"]:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                if dep_name != name:
                    deps[name].add(dep_name)

    # Kahn's algorithm
    in_degree = {n: 0 for n in deps}
    for n, d in deps.items():
        for dep in d:
            in_degree[dep] = in_degree.get(dep, 0)
    # Recount
    in_degree = {n: 0 for n in deps}
    reverse = {n: set() for n in deps}
    for n, d in deps.items():
        for dep in d:
            reverse[dep].add(n)
            in_degree[n] += 1

    queue = sorted([n for n, deg in in_degree.items() if deg == 0])
    result = []
    while queue:
        node = queue.pop(0)
        result.append(node)
        for dependent in sorted(reverse[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
        queue.sort()

    if len(result) != len(deps):
        raise ValueError("circular dependency detected")
    return result


if __name__ == "__main__":
    main()
