# Workflow 可观测性报告

- Trial：`MP16__cTzzE9G__env`
- Task：`MP16`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（96 节点 / 95 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：96；执行边：95（observed=0，inferred=95）
- Execution Trace Graph：`observed`；temporal_next 边 95，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_43c1899bc3ec4a7f97fd0ff9 -> tool:nanobot-harness-v3:call_f82a9797b84644029f72c17c -> tool:nanobot-harness-v3:call_7f6b11ab180f47ca8c6d8bb4 -> tool:nanobot-harness-v3:call_476644ca9a294103935f2fc7 -> tool:nanobot-harness-v3:call_6ed1f7ca89d2443cad7f8385 -> tool:nanobot-harness-v3:call_65e5271e15c84c7f912bc226 -> tool:nanobot-harness-v3:call_baa8f96b908d484a8d1cf9ae -> tool:nanobot-harness-v3:call_8bf6b63aad114ab580032afd -> tool:nanobot-harness-v3:call_acf879a17b1b43419d04d2e7 -> tool:nanobot-harness-v3:call_d87bf06405874c2687780d86 -> tool:nanobot-harness-v3:call_546f1298b91847378b1c38a9 -> tool:nanobot-harness-v3:call_5672b3e77fd24bb1825c9f16 -> tool:nanobot-harness-v3:call_019f06a26b1345dca6a5ab7c -> tool:nanobot-harness-v3:call_4d7408991bbc4effae277ff8 -> tool:nanobot-harness-v3:call_7584518499ec48e19e6bff6d -> tool:nanobot-harness-v3:call_982827cc5acd41a9a6321b69 -> tool:nanobot-harness-v3:call_121dc20163944de89e3a9238 -> tool:nanobot-harness-v3:call_4c2f55c1b8a249ea84db66b5 -> tool:nanobot-harness-v3:call_89ce5e081fc8408fa7ba8495 -> tool:nanobot-harness-v3:call_f9fc3deeee524767aeb253ce -> tool:nanobot-harness-v3:call_13113a05e06b4024991f68d8 -> tool:nanobot-harness-v3:call_38580b22483d45528db2016d -> tool:nanobot-harness-v3:call_0a70850babd14cb695fdcc24 -> tool:nanobot-harness-v3:call_c3a3519c86f347fbb156fc48 -> tool:nanobot-harness-v3:call_b2f8da88fe214999b6975b2f -> tool:nanobot-harness-v3:call_563d828d126a44b3b1d7c0f7 -> tool:nanobot-harness-v3:call_95370313831348b2aa69e1e4 -> tool:nanobot-harness-v3:call_153fc15e3ca648efbb22168a -> tool:nanobot-harness-v3:call_cde6daa24c5448a084edde5d -> tool:nanobot-harness-v3:call_d38d13dda805475886c3785e -> tool:nanobot-harness-v3:call_357163f39fd040f7a20fe0ef -> tool:nanobot-harness-v3:call_3d9152cef2c540ca932b3120 -> tool:nanobot-harness-v3:call_bf0aa71d06904958aad6ecdc -> tool:nanobot-harness-v3:call_de4cfa03c80c43428085cb51 -> tool:nanobot-harness-v3:call_eb70eb809fcd4b3580b0e27a -> tool:nanobot-harness-v3:call_37cde61de38548a08d6944d9 -> tool:nanobot-harness-v3:call_695f0de729b9439e9ae983f5 -> tool:nanobot-harness-v3:call_4e290f3cdc6043f2b053f1b1 -> tool:nanobot-harness-v3:call_c2ceac79ae3d4895b0e83e66 -> tool:nanobot-harness-v3:call_d0269d7f3be34fce8cea52db -> tool:nanobot-harness-v3:call_f788a0cf618f4db3804fb1f9 -> tool:nanobot-harness-v3:call_de0ef50e83e6472083845894 -> tool:nanobot-harness-v3:call_af0d6ada61fa48b88bc21231 -> tool:nanobot-harness-v3:call_5fe1ec3491144022be14c2c5 -> tool:nanobot-harness-v3:call_9b2c81de608c4158acd6ddaa -> tool:nanobot-harness-v3:call_2710e15c6e0d4b03b127b9b5 -> tool:nanobot-harness-v3:call_0bd186a598a4442bae34deae -> tool:nanobot-harness-v3:call_593942ddbe474e18a1080d90 -> tool:nanobot-harness-v3:call_16dab14135e74c8a99920726 -> tool:nanobot-harness-v3:call_eac616754c1a4493846d7307 -> tool:nanobot-harness-v3:call_e600aae704b348bcac59293e -> tool:nanobot-harness-v3:call_24da1c89483c436d901744a6 -> tool:nanobot-harness-v3:call_104a71efbb9b4047947c176a -> tool:nanobot-harness-v3:call_e8447c9566224864afc944f4 -> tool:nanobot-harness-v3:call_160aaca352284d4881401c1b -> tool:nanobot-harness-v3:call_02ce13e58b7b400184d6d9b8 -> tool:nanobot-harness-v3:call_1cd491b85ab646f387fbdad2 -> tool:nanobot-harness-v3:call_72a67ae545d04ac4ac8b878e -> tool:nanobot-harness-v3:call_0ad4acb998894c599b01ba57 -> tool:nanobot-harness-v3:call_3ccb567eb0fb4c55b1012069 -> tool:nanobot-harness-v3:call_5479ba42a732413780aadadc -> tool:nanobot-harness-v3:call_ee0e7e7720064db2817d547f -> tool:nanobot-harness-v3:call_92b71c5d11fe4ebd9e250191 -> tool:nanobot-harness-v3:call_4391e334bf3542b38abaf139 -> tool:nanobot-harness-v3:call_693d960e01534e9aa4844d7c -> tool:nanobot-harness-v3:call_9969be212cdc4383bda8671b -> tool:nanobot-harness-v3:call_6d14bcab99854a20bd285dee -> tool:nanobot-harness-v3:call_45dbcd13e2e3495a939730d0 -> tool:nanobot-harness-v3:call_846d69aaeb7e4ba98f7eb98f -> tool:nanobot-harness-v3:call_dc7d0e09557c42b1ac21b12e -> tool:nanobot-harness-v3:call_961fb838eff046d0bf27c466 -> tool:nanobot-harness-v3:call_9f70cb9a22d8442f84218a2b -> tool:nanobot-harness-v3:call_c94c1a3765d047ba9c47ea0f -> tool:nanobot-harness-v3:call_60959a3ba2be437c8ca203b0 -> tool:nanobot-harness-v3:call_1282d32a30d54d699b8fac6e -> tool:nanobot-harness-v3:call_6327ac2a3bf042dd8f58825a -> tool:nanobot-harness-v3:call_e2f94c1c28a84a7cb0b610bd -> tool:nanobot-harness-v3:call_4cedf52eeb1d4d23bd06bae5 -> tool:nanobot-harness-v3:call_4788536991284f798e8a3478 -> tool:nanobot-harness-v3:call_429efd52a3454d9ab1f628f4 -> tool:nanobot-harness-v3:call_5a063a6b0cdb46e0b290d676 -> tool:nanobot-harness-v3:call_8172e270da004edc9c5ac614 -> tool:nanobot-harness-v3:call_62fadcf5e4fb4f96b4521478 -> tool:nanobot-harness-v3:call_42cf17ed7c6b4a93b316b2f8 -> tool:nanobot-harness-v3:call_3dcdca04dfb74f168046283a -> tool:nanobot-harness-v3:call_a84d498c712f48a99f08c8e8 -> tool:nanobot-harness-v3:call_40a300e32bf34b8a982ec72d -> tool:nanobot-harness-v3:call_72fef3eee13e4c28841c759d -> tool:nanobot-harness-v3:call_94ed08f8a3a243b4b1b27bc7 -> tool:nanobot-harness-v3:call_e44f55dc34564fd4ad357b1a -> tool:nanobot-harness-v3:call_2dab10744a6e41ee82eb3543 -> tool:nanobot-harness-v3:call_327dac04697a46f893f3106b -> tool:nanobot-harness-v3:call_c5a4a4daa7ad42699034394f -> tool:nanobot-harness-v3:call_ec126795b4134ad89b4cb45e -> tool:nanobot-harness-v3:call_411c4592f92f4089ba482db5
- 关键路径耗时：1.204383
- Makespan：497.510878
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
