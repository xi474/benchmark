import re


def _replace_aliases_in_type(type_str, aliases):
    """Replace standalone identifiers in type string with alias qualified names.
    
    Only replace identifiers that are NOT immediately preceded or followed by a dot.
    """
    if type_str is None or not aliases:
        return type_str

    def replacer(m):
        ident = m.group(0)
        # Check context: char before and after the match
        start = m.start()
        end = m.end()
        # If preceded by '.', don't replace (already qualified)
        if start > 0 and type_str[start - 1] == '.':
            return ident
        # If followed by '.', don't replace (it's a qualifier prefix)
        if end < len(type_str) and type_str[end] == '.':
            return ident
        if ident in aliases:
            return aliases[ident]
        return ident

    # Match Python identifiers
    result = re.sub(r'[A-Za-z_]\w*', replacer, type_str)
    return result


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    # payloads[0] = overload_signatures result
    # payloads[1] = parameter_docs result  
    # payloads[2] = inherited_doc result
    sig_result = payloads[0]
    param_result = payloads[1]
    inherit_result = payloads[2]

    if not isinstance(sig_result, dict):
        raise ValueError("signatures payload must be object")
    if not isinstance(param_result, dict):
        raise ValueError("parameters payload must be object")
    if not isinstance(inherit_result, dict):
        raise ValueError("inheritance payload must be object")

    # Extract data from upstream results
    # Each upstream payload has {name, result} structure when read from file
    # But when called via parser.parse, they get the raw transform output
    # The inputs to document are the output files which have {name, result}
    
    # Get overloads from signatures
    if "result" in sig_result and "overloads" in sig_result.get("result", {}):
        overloads = sig_result["result"]["overloads"]
    elif "overloads" in sig_result:
        overloads = sig_result["overloads"]
    else:
        raise ValueError("cannot find overloads in signatures input")

    # Get docs from parameters
    if "result" in param_result and "docs" in param_result.get("result", {}):
        docs = param_result["result"]["docs"]
    elif "docs" in param_result:
        docs = param_result["docs"]
    else:
        raise ValueError("cannot find docs in parameters input")

    # Get inheritance info
    if "result" in inherit_result:
        inh = inherit_result["result"]
    else:
        inh = inherit_result

    provider = inh.get("provider")
    namespace = inh.get("namespace")
    aliases = inh.get("aliases", {})

    # Select provider's parameter docs
    if provider is not None and provider in docs:
        provider_params = docs[provider]
    else:
        provider_params = []

    # Apply alias replacement to types
    result_params = []
    for p in provider_params:
        new_type = _replace_aliases_in_type(p.get("type"), aliases)
        result_params.append({
            "name": p["name"],
            "type": new_type,
            "description": p.get("description", ""),
        })

    return {
        "name": contract["name"],
        "result": {
            "overloads": overloads,
            "provider": provider,
            "namespace": namespace,
            "parameters": result_params,
        },
    }
