import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core.get("components", {})

    # title
    title = "API 文档的签名、参数与继承信息聚合"

    # component_count
    component_count = len(components)

    # sha256: serialize the full core object with compact separators, no trailing newline
    canonical = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    sha256 = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    # attention: components matching any of the conditions
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # result.blocked explicitly true
        if result.get("blocked") is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0:
                # Non-empty check: for lists/dicts/strings, check truthiness
                # But 0/null should not trigger. The spec says "non-empty"
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)
                elif isinstance(val, bool):
                    pass  # bools handled above

    attention_sorted = sorted(attention)

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention_sorted,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
