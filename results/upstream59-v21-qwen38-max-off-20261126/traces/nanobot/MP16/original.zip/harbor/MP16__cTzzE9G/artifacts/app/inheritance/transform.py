def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    objects = payload.get("objects")
    if objects is None:
        raise ValueError("missing required field: objects")
    if not isinstance(objects, list):
        raise ValueError("objects must be array")

    target = payload.get("target")
    if target is None:
        raise ValueError("missing required field: target")

    # Build lookup by id
    obj_map = {}
    for obj in objects:
        if not isinstance(obj, dict):
            raise ValueError("object must be dict")
        obj_id = obj.get("id")
        if obj_id is None:
            raise ValueError("missing required field: id")
        obj_map[obj_id] = obj

    if target not in obj_map:
        raise ValueError(f"target {target} not found in objects")

    target_obj = obj_map[target]
    mro = target_obj.get("mro", [])

    # Candidate order: target first, then its mro
    candidates = [target] + list(mro)

    provider_id = None
    provider_namespace = None
    provider_aliases = {}

    for cand_id in candidates:
        if cand_id not in obj_map:
            raise ValueError(f"MRO reference {cand_id} not found")
        cand = obj_map[cand_id]
        doc = cand.get("doc", "")
        if not isinstance(doc, str):
            raise ValueError("doc must be string")
        if doc.strip():
            provider_id = cand_id
            provider_namespace = cand.get("namespace")
            aliases_raw = cand.get("aliases", {})
            if not isinstance(aliases_raw, dict):
                raise ValueError("aliases must be object")
            provider_aliases = dict(aliases_raw)
            break

    return {
        "name": contract["name"],
        "result": {
            "provider": provider_id,
            "namespace": provider_namespace,
            "aliases": provider_aliases,
        },
    }
