import re


def _parse_doc(doc_str):
    """Parse a docstring for :param and :type directives."""
    params = {}  # name -> {"type": ..., "description": ...}
    param_order = []  # track order of first appearance

    lines = doc_str.split("\n")
    for line in lines:
        stripped = line.strip()

        # Try :param TYPE name: description  or  :param name: description
        m = re.match(r'^:param\s+(.+?):\s*(.*)', stripped)
        if m:
            rest = m.group(1).strip()
            description = m.group(2)

            # Determine if there's a type prefix
            # The name is the last token (Python identifier)
            # TYPE can contain spaces, brackets etc.
            # We need to find the last identifier as the name
            # Split from the right: the last whitespace-separated token that is a valid identifier
            parts = rest.rsplit(None, 1)
            if len(parts) == 2:
                candidate_name = parts[1]
                candidate_type = parts[0]
                if re.match(r'^[A-Za-z_]\w*$', candidate_name):
                    param_name = candidate_name
                    param_type = candidate_type
                else:
                    # entire rest is the name (no type)
                    param_name = rest
                    param_type = None
            else:
                param_name = rest
                param_type = None

            if not re.match(r'^[A-Za-z_]\w*$', param_name):
                raise ValueError(f"invalid param name: {param_name}")

            if param_name in params:
                raise ValueError(f"duplicate param: {param_name}")

            params[param_name] = {
                "type": param_type,
                "description": description,
            }
            param_order.append(param_name)
            continue

        # Try :type name: TYPE
        m = re.match(r'^:type\s+(\w+):\s*(.*)', stripped)
        if m:
            param_name = m.group(1)
            type_str = m.group(2).strip()

            if param_name in params:
                # Override type
                params[param_name]["type"] = type_str
            else:
                # type without param - still keep it
                params[param_name] = {
                    "type": type_str,
                    "description": "",
                }
                param_order.append(param_name)
            continue

        # Non-directive lines are ignored

    return params


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    objects = payload.get("objects")
    if objects is None:
        raise ValueError("missing required field: objects")
    if not isinstance(objects, list):
        raise ValueError("objects must be array")

    docs = {}
    for obj in objects:
        if not isinstance(obj, dict):
            raise ValueError("object must be dict")
        obj_id = obj.get("id")
        if obj_id is None:
            raise ValueError("missing required field: id")
        doc_str = obj.get("doc")
        if doc_str is None:
            raise ValueError("missing required field: doc")
        if not isinstance(doc_str, str):
            raise ValueError("doc must be string")

        parsed = _parse_doc(doc_str)
        # Sort by name (Python default string sort)
        sorted_params = []
        for name in sorted(parsed.keys()):
            entry = parsed[name]
            sorted_params.append({
                "name": name,
                "type": entry["type"],
                "description": entry["description"],
            })
        docs[obj_id] = sorted_params

    return {
        "name": contract["name"],
        "result": {
            "docs": docs,
        },
    }
