import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or "python3"


def main():
    # Find all contracts
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: read each contract's inputs to determine order
    # Components whose inputs are only from inputs/ can run first
    # Components whose inputs reference outputs/ need those outputs first
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = {"path": cp, "contract": c}

    # Topological sort based on input dependencies
    # A component depends on another if any of its inputs is an output of that component
    output_to_component = {}
    for name, info in contract_map.items():
        out = info["contract"]["output"]
        output_to_component[out] = name

    # Build adjacency
    deps = {}
    for name, info in contract_map.items():
        deps[name] = set()
        for inp in info["contract"]["inputs"]:
            if inp in output_to_component:
                dep_name = output_to_component[inp]
                if dep_name != name:
                    deps[name].add(dep_name)

    # Topological sort (Kahn's algorithm)
    in_degree = {n: 0 for n in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            pass  # we count incoming edges below

    # Recompute in_degree properly
    in_degree = {n: 0 for n in contract_map}
    reverse_deps = {n: set() for n in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            reverse_deps[d].add(name)
            in_degree[name] += 1

    queue = sorted([n for n in contract_map if in_degree[n] == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for dependent in sorted(reverse_deps[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
        queue.sort()

    if len(order) != len(contract_map):
        print("dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute components in order
    for name in order:
        info = contract_map[name]
        render_py = info["path"].parent / "render.py"
        if not render_py.is_file():
            print(f"render.py not found for {name}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.is_file():
        result = subprocess.run(
            [PYTHON, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report.py failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
