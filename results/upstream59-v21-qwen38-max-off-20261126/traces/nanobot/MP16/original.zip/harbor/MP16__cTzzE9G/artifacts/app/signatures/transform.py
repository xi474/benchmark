import ast


def _parse_signature(sig_str):
    """Parse a single Python function signature string into structured form."""
    # Wrap in a def statement so ast can parse it
    wrapped = f"def {sig_str}: pass"
    try:
        tree = ast.parse(wrapped)
    except SyntaxError as e:
        raise ValueError(f"invalid signature: {sig_str}") from e

    func_def = tree.body[0]
    if not isinstance(func_def, ast.FunctionDef):
        raise ValueError(f"not a function definition: {sig_str}")

    name = func_def.name

    # Parse return annotation
    returns = None
    if func_def.returns is not None:
        returns = ast.unparse(func_def.returns)

    # Parse parameters
    args = func_def.args
    parameters = []

    # Count positional-only args
    posonlyargs = getattr(args, 'posonlyargs', [])
    num_posonly = len(posonlyargs)

    # All regular args (posonly + positional)
    all_args = list(posonlyargs) + list(args.args)
    num_all = len(all_args)

    # defaults are right-aligned to all_args
    num_defaults = len(args.defaults)
    default_offset = num_all - num_defaults

    for i, arg in enumerate(all_args):
        param_name = arg.arg
        annotation = ast.unparse(arg.annotation) if arg.annotation else None

        # Determine kind
        if i < num_posonly:
            kind = "posonly"
        else:
            kind = "positional"

        # Check for default
        default_idx = i - default_offset
        if default_idx >= 0 and default_idx < len(args.defaults):
            default = ast.unparse(args.defaults[default_idx])
        else:
            default = None

        parameters.append({
            "name": param_name,
            "kind": kind,
            "annotation": annotation,
            "default": default,
        })

    # *args (vararg)
    if args.vararg is not None:
        varg = args.vararg
        annotation = ast.unparse(varg.annotation) if varg.annotation else None
        parameters.append({
            "name": varg.arg,
            "kind": "vararg",
            "annotation": annotation,
            "default": None,
        })

    # keyword-only args
    for i, arg in enumerate(args.kwonlyargs):
        annotation = ast.unparse(arg.annotation) if arg.annotation else None
        default = None
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            default = ast.unparse(args.kw_defaults[i])
        parameters.append({
            "name": arg.arg,
            "kind": "kwonly",
            "annotation": annotation,
            "default": default,
        })

    # **kwargs (kwarg)
    if args.kwarg is not None:
        kw = args.kwarg
        annotation = ast.unparse(kw.annotation) if kw.annotation else None
        parameters.append({
            "name": kw.arg,
            "kind": "kwarg",
            "annotation": annotation,
            "default": None,
        })

    return {
        "name": name,
        "parameters": parameters,
        "returns": returns,
    }


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    payload = payloads[0]
    if not isinstance(payload, dict):
        raise ValueError("payload must be object")

    overloads_raw = payload.get("overloads")
    if overloads_raw is None:
        raise ValueError("missing required field: overloads")
    if not isinstance(overloads_raw, list):
        raise ValueError("overloads must be array")

    parsed_overloads = []
    for sig in overloads_raw:
        if not isinstance(sig, str):
            raise ValueError("overload must be string")
        parsed_overloads.append(_parse_signature(sig))

    return {
        "name": contract["name"],
        "result": {
            "overloads": parsed_overloads,
        },
    }
