# Workflow 可观测性报告

- Trial：`MP17__ZhsQV96__env`
- Task：`MP17`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（81 节点 / 80 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：81；执行边：80（observed=0，inferred=80）
- Execution Trace Graph：`observed`；temporal_next 边 80，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3fddb6cb6ca9484faaa6f7c1 -> tool:nanobot-harness-v3:call_944cea35a8754fc2a5871e7a -> tool:nanobot-harness-v3:call_c483bf4639894b269d6aec84 -> tool:nanobot-harness-v3:call_e5b0c90b4e6b4ee7ae0ab598 -> tool:nanobot-harness-v3:call_5cb5a9e8df3b4685b6b5d252 -> tool:nanobot-harness-v3:call_568bad02b44f4d0abed442f9 -> tool:nanobot-harness-v3:call_b798708f431a4f4fab60526f -> tool:nanobot-harness-v3:call_a9ff91d47c8b4bce8d6c6d14 -> tool:nanobot-harness-v3:call_7f877df1b0ec4f27b29c2b23 -> tool:nanobot-harness-v3:call_db89a978ddcc480c9eeb42ec -> tool:nanobot-harness-v3:call_4d4053284cd441e0a3a44e9c -> tool:nanobot-harness-v3:call_3307394e0ed74e16be2e5e89 -> tool:nanobot-harness-v3:call_a535d5f749b549cf99cba6ea -> tool:nanobot-harness-v3:call_4aa2012c58124bada48181f1 -> tool:nanobot-harness-v3:call_6e684b50b5a54dccad890e47 -> tool:nanobot-harness-v3:call_a2735907286f4025a12c9bbc -> tool:nanobot-harness-v3:call_2837baaa55b1426f8520c6a6 -> tool:nanobot-harness-v3:call_124ed7bb04354bcc93777132 -> tool:nanobot-harness-v3:call_b68705777a6748eea2bfda68 -> tool:nanobot-harness-v3:call_d7d1636efef546f69ff8d286 -> tool:nanobot-harness-v3:call_e677120adba5401d9483a5ac -> tool:nanobot-harness-v3:call_f7ddca71ec6d4835829779ad -> tool:nanobot-harness-v3:call_8585be1a80944f7b86e6f3f4 -> tool:nanobot-harness-v3:call_fbbb2a0facfc40b6998b0352 -> tool:nanobot-harness-v3:call_9f7fa4a8417d4a4784f1de3e -> tool:nanobot-harness-v3:call_7a11572819f54820bbe304cd -> tool:nanobot-harness-v3:call_78f4fd91d7984ba3bc721a78 -> tool:nanobot-harness-v3:call_d545701f74824da9bd703c30 -> tool:nanobot-harness-v3:call_c07cf056630349c9a613742b -> tool:nanobot-harness-v3:call_65aca1d779f54a5fb4c12371 -> tool:nanobot-harness-v3:call_36b3ba51d6a342078e94d8b8 -> tool:nanobot-harness-v3:call_6670828564bd44df94f356ce -> tool:nanobot-harness-v3:call_dcd59d61faf54820b45cee36 -> tool:nanobot-harness-v3:call_136087ff0b834f1aa97651de -> tool:nanobot-harness-v3:call_87e3e538e25843b1b5c35212 -> tool:nanobot-harness-v3:call_1619f4638c9c49739c3614a9 -> tool:nanobot-harness-v3:call_7c580b6d8cd844958d55efde -> tool:nanobot-harness-v3:call_9b1bad9a4b2c4ddf90b631e6 -> tool:nanobot-harness-v3:call_161e9a9030114065809f6d30 -> tool:nanobot-harness-v3:call_dd9c0c04a3814ecc8995e4fd -> tool:nanobot-harness-v3:call_37ab62e6157d456c8a7a858d -> tool:nanobot-harness-v3:call_4f6485143d554a8690d5e6b3 -> tool:nanobot-harness-v3:call_38823b3aa2a649d594b25f0c -> tool:nanobot-harness-v3:call_fe89c1335a124fc09e43d3ee -> tool:nanobot-harness-v3:call_1fa4f925902741e3892a4509 -> tool:nanobot-harness-v3:call_284fb623a9ba4f38a64456ed -> tool:nanobot-harness-v3:call_fb24e01e97684a9588549248 -> tool:nanobot-harness-v3:call_e09f1b3e9c6c47b18f2131e7 -> tool:nanobot-harness-v3:call_9d1edb4bf95f440c903ce3cb -> tool:nanobot-harness-v3:call_fce481d64f7a46a38b7da025 -> tool:nanobot-harness-v3:call_e7e9be850d2740e480916dd6 -> tool:nanobot-harness-v3:call_54397b974e33499a8734b933 -> tool:nanobot-harness-v3:call_5da32edc99184a4e852bfa33 -> tool:nanobot-harness-v3:call_4779174410b34a31afdad65c -> tool:nanobot-harness-v3:call_565828db6cc04154b103271f -> tool:nanobot-harness-v3:call_612babe9c86a4820bd9ff8e7 -> tool:nanobot-harness-v3:call_fbfe96cc949642fea0f07318 -> tool:nanobot-harness-v3:call_fb51a66694904418b96b83e6 -> tool:nanobot-harness-v3:call_b7279e9cd4e04df3ae49bdc5 -> tool:nanobot-harness-v3:call_a1584f20aeb24033bf2767da -> tool:nanobot-harness-v3:call_5870efa2ba9846af9889dc66 -> tool:nanobot-harness-v3:call_e38d01999e7547c0a5dd8489 -> tool:nanobot-harness-v3:call_15f818aaf17747c38d02cbc1 -> tool:nanobot-harness-v3:call_aaf14c9cf1de4269946710f5 -> tool:nanobot-harness-v3:call_82f42df181184a1e961cba61 -> tool:nanobot-harness-v3:call_621ee13b2fb8466294da6e48 -> tool:nanobot-harness-v3:call_3837babf39ca42c89ac8dfe4 -> tool:nanobot-harness-v3:call_1b62be13d1ea4b68b1274c55 -> tool:nanobot-harness-v3:call_89c8b392eedc4ae3b21449fe -> tool:nanobot-harness-v3:call_490c4ce15a4a40ce9d281a12 -> tool:nanobot-harness-v3:call_951a2b74a3f04867b0ac337d -> tool:nanobot-harness-v3:call_e3fbcda898564e99b5dee237 -> tool:nanobot-harness-v3:call_4eb5a4b64b59449ba261754f -> tool:nanobot-harness-v3:call_3a443b6cae114063b77fbd2a -> tool:nanobot-harness-v3:call_bf0c8a5a1a0e4b6f931f02bd -> tool:nanobot-harness-v3:call_863342d7a1d14c81ac0fe3c3 -> tool:nanobot-harness-v3:call_976f90458b824af8b305ded5 -> tool:nanobot-harness-v3:call_6434c51b89e7498a9fa2255a -> tool:nanobot-harness-v3:call_c8869cdffe1046e39c2280f6 -> tool:nanobot-harness-v3:call_840be9a2d1354aedb991246d
- 关键路径耗时：1.376375
- Makespan：325.603563
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
