import re


def _unwrap(obj):
    """If obj is a dict with exactly keys {name, result}, return result; else return obj."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != 2:
        raise ValueError(f"Expected 2 payloads, got {len(payloads)}")
    snapshot = payloads[0]  # original input (case.json) - not wrapped
    encoding_result = _unwrap(payloads[1])  # multipart_encoding result - may be wrapped

    if not isinstance(snapshot, dict):
        raise ValueError("Snapshot must be object")
    if not isinstance(encoding_result, dict):
        raise ValueError("Encoding result must be object")

    # Get boundary from snapshot
    if 'boundary' not in snapshot:
        raise ValueError("Missing 'boundary' in snapshot")
    boundary = snapshot['boundary']
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("'boundary' must be non-empty string")
    if not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError(f"Invalid boundary chars: {boundary}")

    # Check boundary bytes don't appear in any payload
    boundary_bytes = boundary.encode('ascii')
    if 'parts' not in encoding_result:
        raise ValueError("Missing 'parts' in encoding result")
    enc_parts = encoding_result['parts']
    if not isinstance(enc_parts, list):
        raise ValueError("'parts' must be array")

    for part in enc_parts:
        payload_hex = part.get('payload_hex')
        if not isinstance(payload_hex, str):
            raise ValueError("Part 'payload_hex' must be string")
        payload_bytes = bytes.fromhex(payload_hex)
        if boundary_bytes in payload_bytes:
            raise ValueError(f"Boundary appears in payload of part: {part.get('name')}")

    # Build multipart body
    body_chunks = []
    for part in enc_parts:
        name = part['name']
        filename = part.get('filename')
        mimetype = part['mimetype']
        encoding = part['encoding']
        payload_hex = part['payload_hex']
        payload_bytes = bytes.fromhex(payload_hex)

        # Start delimiter
        body_chunks.append(f'--{boundary}\r\n'.encode('ascii'))

        # Content-Transfer-Encoding header for base64
        if encoding == 'base64':
            body_chunks.append(b'Content-Transfer-Encoding: base64\r\n')

        # Content-Type header
        body_chunks.append(f'Content-Type: {mimetype}\r\n'.encode('ascii'))

        # Content-Disposition header
        disp = f'form-data; name="{name}"'
        if filename is not None:
            disp += f'; filename="{filename}"'
        body_chunks.append(f'Content-Disposition: {disp}\r\n'.encode('ascii'))

        # Empty line separator
        body_chunks.append(b'\r\n')

        # Payload
        body_chunks.append(payload_bytes)

        # CRLF after payload
        body_chunks.append(b'\r\n')

    # Closing delimiter
    body_chunks.append(f'--{boundary}--\r\n'.encode('ascii'))

    body_bytes = b''.join(body_chunks)
    content_type = f'multipart/form-data; boundary={boundary}'

    return {
        'name': contract['name'],
        'result': {
            'content_type': content_type,
            'body_hex': body_bytes.hex(),
        }
    }
