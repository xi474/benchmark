import base64


def _unwrap(obj):
    """If obj is a dict with exactly keys {name, result}, return result; else return obj."""
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != 1:
        raise ValueError(f"Expected 1 payload, got {len(payloads)}")
    inp = _unwrap(payloads[0])
    if not isinstance(inp, dict):
        raise ValueError("Input must be object")
    if 'parts' not in inp:
        raise ValueError("Missing 'parts'")
    parts_in = inp['parts']
    if not isinstance(parts_in, list):
        raise ValueError("'parts' must be array")

    result_parts = []
    for part in parts_in:
        if not isinstance(part, dict):
            raise ValueError("Each part must be object")
        encoding = part.get('encoding')
        hex_str = part.get('hex')
        if not isinstance(hex_str, str):
            raise ValueError("Part 'hex' must be string")
        raw_bytes = bytes.fromhex(hex_str)

        if encoding == 'raw':
            payload_hex = raw_bytes.hex()
        elif encoding == 'base64':
            # Base64 encode, then fold at 76 chars with CRLF between lines, no trailing CRLF
            b64_bytes = base64.b64encode(raw_bytes)
            b64_str = b64_bytes.decode('ascii')
            # Fold at 76 characters
            lines = []
            for i in range(0, len(b64_str), 76):
                lines.append(b64_str[i:i+76])
            folded = '\r\n'.join(lines)
            payload_hex = folded.encode('ascii').hex()
        else:
            raise ValueError(f"Unknown encoding: {encoding}")

        # Copy all original fields and add payload_hex
        new_part = {}
        for k, v in part.items():
            new_part[k] = v
        new_part['payload_hex'] = payload_hex
        result_parts.append(new_part)

    return {'name': contract['name'], 'result': {'parts': result_parts}}
