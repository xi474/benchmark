import re
import base64

_FIELD_NAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_SAFE_BASENAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_MIME_RE = re.compile(r'^[A-Za-z0-9!#$&\-^_]+/[A-Za-z0-9!#$&\-^_]+$')
_EXT_MAP = {
    '.txt': 'text/plain',
    '.json': 'application/json',
    '.jpg': 'image/jpeg',
}


def _safe_relative_path(p):
    """Validate safe relative path: no absolute, no backslash, no colon, no empty segments, no . or .."""
    if not p or '/' != '/' and '\\' in p:
        raise ValueError(f"Unsafe path: {p}")
    if ':' in p:
        raise ValueError(f"Unsafe path (colon): {p}")
    if p.startswith('/'):
        raise ValueError(f"Absolute path: {p}")
    parts = p.split('/')
    for seg in parts:
        if seg == '' or seg == '.' or seg == '..':
            raise ValueError(f"Unsafe path segment in: {p}")
    return p


def transform(payloads, contract):
    if len(payloads) != 1:
        raise ValueError(f"Expected 1 payload, got {len(payloads)}")
    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("Input must be object")

    # Extract fields
    if 'fields' not in inp:
        raise ValueError("Missing 'fields'")
    fields = inp['fields']
    if not isinstance(fields, dict):
        raise ValueError("'fields' must be object")

    # Extract files
    if 'files' not in inp:
        raise ValueError("Missing 'files'")
    files = inp['files']
    if not isinstance(files, dict):
        raise ValueError("'files' must be object")

    # Validate files keys are safe relative paths
    files_bytes = {}
    for fpath, hexval in files.items():
        _safe_relative_path(fpath)
        if not isinstance(hexval, str):
            raise ValueError(f"File hex must be string: {fpath}")
        try:
            files_bytes[fpath] = bytes.fromhex(hexval)
        except ValueError as e:
            raise ValueError(f"Invalid hex for {fpath}: {e}") from e

    # Extract boundary
    if 'boundary' not in inp:
        raise ValueError("Missing 'boundary'")
    boundary = inp['boundary']
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("'boundary' must be non-empty string")
    if not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError(f"Invalid boundary chars: {boundary}")

    parts_list = []
    for name, value in fields.items():
        if not _FIELD_NAME_RE.match(name):
            raise ValueError(f"Invalid field name: {name}")

        if isinstance(value, str):
            # Pure string field: text/plain, no filename
            content_bytes = value.encode('utf-8')
            parts_list.append({
                'name': name,
                'filename': None,
                'mimetype': 'text/plain',
                'encoding': 'raw',
                'hex': content_bytes.hex(),
            })
        elif isinstance(value, dict):
            if not value:
                raise ValueError(f"Empty field object for: {name}")

            explicit_mimetype = value.get('mimetype')
            content_str = value.get('content')
            filename_val = value.get('filename')

            # Determine content bytes and filename
            if content_str is not None:
                # content takes priority
                if not isinstance(content_str, str):
                    raise ValueError(f"'content' must be str for field: {name}")
                content_bytes = content_str.encode('utf-8')
                if filename_val is not None:
                    if not isinstance(filename_val, str):
                        raise ValueError(f"'filename' must be str for field: {name}")
                    basename = filename_val
                    if not _SAFE_BASENAME_RE.match(basename):
                        raise ValueError(f"Unsafe filename: {basename}")
                    fname = basename
                else:
                    fname = None
            elif filename_val is not None:
                # Read from files map
                if not isinstance(filename_val, str):
                    raise ValueError(f"'filename' must be str for field: {name}")
                _safe_relative_path(filename_val)
                if filename_val not in files_bytes:
                    raise ValueError(f"File not found: {filename_val}")
                content_bytes = files_bytes[filename_val]
                # Use basename of the path
                basename = filename_val.rsplit('/', 1)[-1]
                if not _SAFE_BASENAME_RE.match(basename):
                    raise ValueError(f"Unsafe basename: {basename}")
                fname = basename
                # base64 encoding for file-sourced content
                encoding = 'base64'
            else:
                raise ValueError(f"Field object must have 'content' or 'filename': {name}")

            # Determine mimetype
            if explicit_mimetype is not None:
                if not isinstance(explicit_mimetype, str):
                    raise ValueError(f"'mimetype' must be str for field: {name}")
                if not _MIME_RE.match(explicit_mimetype):
                    raise ValueError(f"Invalid mimetype: {explicit_mimetype}")
                mimetype = explicit_mimetype
            else:
                # Infer from filename extension
                if fname is not None:
                    dot_pos = fname.rfind('.')
                    if dot_pos >= 0:
                        ext = fname[dot_pos:].lower()
                        mimetype = _EXT_MAP.get(ext, 'application/octet-stream')
                    else:
                        mimetype = 'application/octet-stream'
                else:
                    mimetype = 'application/octet-stream'

            # Determine encoding
            if content_str is not None:
                encoding = 'raw'
            else:
                encoding = 'base64'

            parts_list.append({
                'name': name,
                'filename': fname,
                'mimetype': mimetype,
                'encoding': encoding,
                'hex': content_bytes.hex(),
            })
        else:
            raise ValueError(f"Field value must be str or object: {name}")

    # Sort by name
    parts_list.sort(key=lambda p: p['name'])

    return {'name': contract['name'], 'result': {'parts': parts_list}}
