import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable if sys.executable else 'python3'


def main():
    # Discover all contract.json files (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency order: topological sort based on input dependencies
    # Each contract has inputs that may reference other contract outputs
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = {'path': cp, 'contract': c}

    # Determine execution order via topological sort
    # A component depends on another if any of its inputs is an output of that component
    output_to_component = {}
    for name, info in contract_map.items():
        out = info['contract']['output']
        output_to_component[out] = name

    deps = {name: set() for name in contract_map}
    for name, info in contract_map.items():
        for inp in info['contract']['inputs']:
            if inp in output_to_component:
                dep_name = output_to_component[inp]
                if dep_name != name:
                    deps[name].add(dep_name)

    # Topological sort (Kahn's algorithm)
    in_degree = {name: len(d) for name, d in deps.items()}
    queue = [n for n in contract_map if in_degree[n] == 0]
    queue.sort()
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for name in sorted(contract_map):
            if node in deps[name]:
                deps[name].discard(node)
                in_degree[name] -= 1
                if in_degree[name] == 0:
                    queue.append(name)
                    queue.sort()

    if len(order) != len(contract_map):
        print("Dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute each component in order
    for name in order:
        info = contract_map[name]
        render_py = info['path'].with_name('render.py')
        if not render_py.is_file():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_py = ROOT / 'final_report.py'
    if report_py.is_file():
        result = subprocess.run(
            [PYTHON, str(report_py)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
