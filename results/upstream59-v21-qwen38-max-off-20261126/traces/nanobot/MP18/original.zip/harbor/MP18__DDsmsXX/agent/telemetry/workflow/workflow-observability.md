# Workflow 可观测性报告

- Trial：`MP18__DDsmsXX__env`
- Task：`MP18`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（82 节点 / 81 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：82；执行边：81（observed=0，inferred=81）
- Execution Trace Graph：`observed`；temporal_next 边 81，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_9e7611ddc6d34553a19b50bd -> tool:nanobot-harness-v3:call_22542ff5356c4e0b9997635b -> tool:nanobot-harness-v3:call_13c44c6269624feda2bbc594 -> tool:nanobot-harness-v3:call_99cf4a48a5af40ef98b5b811 -> tool:nanobot-harness-v3:call_4ba51bf8e2f74734a669198f -> tool:nanobot-harness-v3:call_bf8f685f607842f5b87473d9 -> tool:nanobot-harness-v3:call_9c4830ca7d8a425a8a1a890c -> tool:nanobot-harness-v3:call_fcb891f01c5447d1ad7d0e31 -> tool:nanobot-harness-v3:call_0cd356607fd648c49a620fe8 -> tool:nanobot-harness-v3:call_bed391ae527a460f9989bcee -> tool:nanobot-harness-v3:call_a0462bb7633c4e189a4dfca4 -> tool:nanobot-harness-v3:call_8c186581b4cc4c6bb809bf35 -> tool:nanobot-harness-v3:call_96a88814fadd4dcbba99f035 -> tool:nanobot-harness-v3:call_f5d4e5c3971a4871a792f772 -> tool:nanobot-harness-v3:call_e9992d22a260461192fb3f73 -> tool:nanobot-harness-v3:call_b929dd74defc4b21849be27d -> tool:nanobot-harness-v3:call_d83f529f8d004e02a9651bc0 -> tool:nanobot-harness-v3:call_37fd16101cf84281aacce8c2 -> tool:nanobot-harness-v3:call_2968917ad8d24274a7def4d0 -> tool:nanobot-harness-v3:call_b991b4d82dea458a94d495a9 -> tool:nanobot-harness-v3:call_708b63ef289e4f6a9adf939b -> tool:nanobot-harness-v3:call_043a84858b124da59046a34a -> tool:nanobot-harness-v3:call_f775512137224ced86d19fe1 -> tool:nanobot-harness-v3:call_1e3c7cef416f4178901b20d9 -> tool:nanobot-harness-v3:call_59152101cbb64b368007f890 -> tool:nanobot-harness-v3:call_6576d1f519f047d9a7fd9290 -> tool:nanobot-harness-v3:call_0de7b95c272a4056bc1bc8d5 -> tool:nanobot-harness-v3:call_45834de3d55140ebbc44bd60 -> tool:nanobot-harness-v3:call_383d073915224c5697629441 -> tool:nanobot-harness-v3:call_d88ef17cd8174e2d871c3e67 -> tool:nanobot-harness-v3:call_6cfc1177f7a041b8b597a397 -> tool:nanobot-harness-v3:call_435056958b7b4bc3b80b5b94 -> tool:nanobot-harness-v3:call_f142f13c79094e338d072758 -> tool:nanobot-harness-v3:call_7c0c09186994412189655d68 -> tool:nanobot-harness-v3:call_531b211280cd4a9f96cb3edd -> tool:nanobot-harness-v3:call_958648ae1d9249fe8f1f01cd -> tool:nanobot-harness-v3:call_8c54f569553e4700b671d62c -> tool:nanobot-harness-v3:call_a542b9c4f7764cf08367b387 -> tool:nanobot-harness-v3:call_45e6ffa72bf64ac782764d2b -> tool:nanobot-harness-v3:call_7a247a45e05e480e822fa2fd -> tool:nanobot-harness-v3:call_38dbe5b327c447d0b695fe7c -> tool:nanobot-harness-v3:call_a81dec4e93544e2e8d7068c3 -> tool:nanobot-harness-v3:call_8ded887d59a644a9bd254cf3 -> tool:nanobot-harness-v3:call_64f320f7f60e41048b323b2b -> tool:nanobot-harness-v3:call_dfb6cc5deafa42aa8d9447cb -> tool:nanobot-harness-v3:call_643d93c47a5f44b7933ccd42 -> tool:nanobot-harness-v3:call_7cb9e50c2cbb4cefa93645ca -> tool:nanobot-harness-v3:call_691c63a72c4a4ef8b7f0c985 -> tool:nanobot-harness-v3:call_02e3bbbea6bd45199f45bb8f -> tool:nanobot-harness-v3:call_f14cb09d5e33486baf5f3645 -> tool:nanobot-harness-v3:call_a5d862e81e8845f396186de7 -> tool:nanobot-harness-v3:call_ef8ba001ccd34d2f9d186e48 -> tool:nanobot-harness-v3:call_94e15548042e429f93727a21 -> tool:nanobot-harness-v3:call_0db87329cbe940c4abb1f2bb -> tool:nanobot-harness-v3:call_4b03894acd6a427d98e26265 -> tool:nanobot-harness-v3:call_6b594563e8a84f73a81e0cc3 -> tool:nanobot-harness-v3:call_f821bf1b94b4425297c8c031 -> tool:nanobot-harness-v3:call_185f6bf6c1524295b0f48ecc -> tool:nanobot-harness-v3:call_233509e70c754daaa45a00f4 -> tool:nanobot-harness-v3:call_1b73bd68b99c4273a8faef88 -> tool:nanobot-harness-v3:call_e71ed6e64fd943b1b401e317 -> tool:nanobot-harness-v3:call_94961a4a8f54498fb37ea2c2 -> tool:nanobot-harness-v3:call_39b200b03bfc4d92ade951f5 -> tool:nanobot-harness-v3:call_82122ef47b6848cd871f5045 -> tool:nanobot-harness-v3:call_e9064dac8e2849b09ca8ec05 -> tool:nanobot-harness-v3:call_c324d3f6f2c04f479cbbbf43 -> tool:nanobot-harness-v3:call_d5072a18ef6b4303bb74a010 -> tool:nanobot-harness-v3:call_cf505c9f1b8a4a0c81f26bea -> tool:nanobot-harness-v3:call_cb2b210b067d4001b73d9cb7 -> tool:nanobot-harness-v3:call_1f89fb0dc51f45e288902d96 -> tool:nanobot-harness-v3:call_a1d9cc722d3b41829824e81d -> tool:nanobot-harness-v3:call_3bd5f391aa124194a6112b1a -> tool:nanobot-harness-v3:call_0718787085be42668d649cba -> tool:nanobot-harness-v3:call_5217c6af38694e319c2a848d -> tool:nanobot-harness-v3:call_1989d3f6abf946adb16c6f27 -> tool:nanobot-harness-v3:call_0f44a52a45a54ec2a5c3db98 -> tool:nanobot-harness-v3:call_3b376f81c5234961aa57d9cb -> tool:nanobot-harness-v3:call_241b95a997954015899cc92a -> tool:nanobot-harness-v3:call_c39f9219a5db4c108ee6b823 -> tool:nanobot-harness-v3:call_29a24b2ad3724dcba7dd7ca5 -> tool:nanobot-harness-v3:call_bb652c0c2ccd4137a1ec62cf
- 关键路径耗时：0.931512
- Makespan：417.97712
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
