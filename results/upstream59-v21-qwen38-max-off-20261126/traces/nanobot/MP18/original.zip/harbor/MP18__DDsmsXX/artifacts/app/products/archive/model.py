import json
import math
from pathlib import Path


def _check_finite(obj, path=""):
    """Recursively check for NaN/Infinity in nested structures."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError(f"non-finite number at {path}")
    elif isinstance(obj, dict):
        for k, v in obj.items():
            _check_finite(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _check_finite(v, f"{path}[{i}]")


def load_payload(path):
    """Read UTF-8 JSON from path. Only object/array top-level allowed.
    Raises ValueError for invalid JSON, non-object/array top-level, or NaN/Infinity."""
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError(f"top-level must be object or array, got {type(data).__name__}")
    _check_finite(data)
    return data
