import hashlib


def transform(payloads, contract):
    """manifest_archive operation.
    
    Inputs: [manifest_inventory result, manifest_selection result]
    Output: {entries: [{path, size, sha256}], total_bytes}
    """
    if len(payloads) != 2:
        raise ValueError(f"expected 2 payloads, got {len(payloads)}")
    
    inventory_result = payloads[0]
    selection_result = payloads[1]
    
    # Extract files from inventory
    if not isinstance(inventory_result, dict):
        raise ValueError("inventory result must be object")
    
    inv_res = inventory_result.get("result", inventory_result)
    if isinstance(inv_res, dict) and "files" in inv_res:
        inv_files = inv_res["files"]
    else:
        raise ValueError("invalid inventory result structure")
    
    # Build lookup: path -> hex
    file_lookup = {}
    for f in inv_files:
        file_lookup[f["path"]] = f["hex"]
    
    # Extract selected paths from selection
    if not isinstance(selection_result, dict):
        raise ValueError("selection result must be object")
    
    sel_res = selection_result.get("result", selection_result)
    if isinstance(sel_res, dict) and "selected" in sel_res:
        selected = sel_res["selected"]
    else:
        raise ValueError("invalid selection result structure")
    
    if not isinstance(selected, list):
        raise ValueError("selected must be array")
    
    # Validate no duplicates
    seen = set()
    for p in selected:
        if p in seen:
            raise ValueError(f"duplicate in selected: {p}")
        seen.add(p)
    
    # Validate each selected is in regular files
    for p in selected:
        if p not in file_lookup:
            raise ValueError(f"selected path not in inventory: {p}")
    
    entries = []
    total_bytes = 0
    
    for p in selected:
        hex_val = file_lookup[p]
        raw_bytes = bytes.fromhex(hex_val)
        size = len(raw_bytes)
        sha256_hash = hashlib.sha256(raw_bytes).hexdigest()
        entries.append({
            "path": p,
            "size": size,
            "sha256": sha256_hash
        })
        total_bytes += size
    
    return {
        "name": contract["name"],
        "result": {
            "entries": entries,
            "total_bytes": total_bytes
        }
    }
