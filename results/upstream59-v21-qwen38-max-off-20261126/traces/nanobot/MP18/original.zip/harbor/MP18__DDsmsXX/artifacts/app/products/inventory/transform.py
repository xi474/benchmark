import re


def _validate_path(p):
    """Validate a safe relative path."""
    if not isinstance(p, str):
        raise ValueError(f"path must be string, got {type(p).__name__}")
    if not p:
        raise ValueError("empty path")
    if "\\" in p or ":" in p:
        raise ValueError(f"unsafe path characters in: {p}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"unsafe path segment in: {p}")
    # Must be relative (no leading /)
    if p.startswith("/"):
        raise ValueError(f"absolute path: {p}")


def _validate_hex(h):
    """Validate hex string is valid."""
    if not isinstance(h, str):
        raise ValueError(f"hex must be string, got {type(h).__name__}")
    try:
        bytes.fromhex(h)
    except ValueError as e:
        raise ValueError(f"invalid hex: {h}") from e


def transform(payloads, contract):
    """manifest_inventory operation.
    
    Input: {files:[{path,kind:file/symlink,hex:str,target:str|null}], manifest:str|null, build_ignore:[glob]|null}
    Output: {files:[{path,hex}] sorted by path, symlinks:[paths sorted]}
    """
    if len(payloads) != 1:
        raise ValueError(f"expected 1 payload, got {len(payloads)}")
    
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    
    # Validate required fields
    if "files" not in data:
        raise ValueError("missing 'files' field")
    files = data["files"]
    if not isinstance(files, list):
        raise ValueError("'files' must be array")
    
    # manifest and build_ignore validation
    if "manifest" not in data:
        raise ValueError("missing 'manifest' field")
    if "build_ignore" not in data:
        raise ValueError("missing 'build_ignore' field")
    
    manifest = data["manifest"]
    build_ignore = data["build_ignore"]
    
    if manifest is not None and not isinstance(manifest, str):
        raise ValueError("'manifest' must be string or null")
    if build_ignore is not None and not isinstance(build_ignore, list):
        raise ValueError("'build_ignore' must be array or null")
    
    seen_paths = set()
    regular_files = []
    symlinks = []
    
    for entry in files:
        if not isinstance(entry, dict):
            raise ValueError("each file entry must be object")
        
        for field in ("path", "kind", "hex", "target"):
            if field not in entry:
                raise ValueError(f"missing '{field}' in file entry")
        
        path = entry["path"]
        kind = entry["kind"]
        hex_val = entry["hex"]
        target = entry["target"]
        
        if not isinstance(path, str):
            raise ValueError("path must be string")
        if not isinstance(kind, str):
            raise ValueError("kind must be string")
        if kind not in ("file", "symlink"):
            raise ValueError(f"kind must be 'file' or 'symlink', got '{kind}'")
        
        _validate_path(path)
        
        if path in seen_paths:
            raise ValueError(f"duplicate path: {path}")
        seen_paths.add(path)
        
        if kind == "file":
            _validate_hex(hex_val)
            if target is not None:
                raise ValueError(f"file entry must have null target, got {target}")
            regular_files.append({"path": path, "hex": hex_val})
        elif kind == "symlink":
            if not isinstance(target, str):
                raise ValueError(f"symlink target must be string, got {type(target).__name__}")
            _validate_path(target)
            # hex for symlink - the spec says symlink hex can be empty string
            # but we still validate it's a valid hex string
            if not isinstance(hex_val, str):
                raise ValueError("hex must be string")
            try:
                bytes.fromhex(hex_val)
            except ValueError as e:
                raise ValueError(f"invalid hex for symlink: {hex_val}") from e
            symlinks.append(path)
    
    # Sort files by path
    regular_files.sort(key=lambda x: x["path"])
    symlinks.sort()
    
    return {
        "name": contract["name"],
        "result": {
            "files": regular_files,
            "symlinks": symlinks
        }
    }
