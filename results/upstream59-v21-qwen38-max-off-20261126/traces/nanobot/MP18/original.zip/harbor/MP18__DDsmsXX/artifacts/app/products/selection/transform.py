import fnmatch


def _is_under_git(path):
    """Check if path is inside a .git directory at any level."""
    parts = path.split("/")
    for part in parts:
        if part == ".git":
            return True
    return False


def transform(payloads, contract):
    """manifest_selection operation.
    
    Inputs: [original_snapshot (case.json), manifest_inventory result]
    Output: {selected: [sorted paths]}
    """
    if len(payloads) != 2:
        raise ValueError(f"expected 2 payloads, got {len(payloads)}")
    
    case_data = payloads[0]
    inventory_result = payloads[1]
    
    # Extract from case_data
    if not isinstance(case_data, dict):
        raise ValueError("case data must be object")
    
    manifest = case_data.get("manifest")
    build_ignore = case_data.get("build_ignore")
    
    # manifest and build_ignore cannot both be non-null
    if manifest is not None and build_ignore is not None:
        raise ValueError("manifest and build_ignore cannot both be non-null")
    
    # Get regular files from inventory result
    # inventory_result is {"name": ..., "result": {"files": [...], "symlinks": [...]}}
    if not isinstance(inventory_result, dict):
        raise ValueError("inventory result must be object")
    
    inv_res = inventory_result.get("result", inventory_result)
    if isinstance(inv_res, dict) and "files" in inv_res:
        inv_files = inv_res["files"]
    else:
        raise ValueError("invalid inventory result structure")
    
    all_regular_paths = [f["path"] for f in inv_files]
    
    # Always exclude: .git dirs, *.pyc, MANIFEST.in
    def always_excluded(path):
        if _is_under_git(path):
            return True
        if path.endswith(".pyc"):
            return True
        basename = path.split("/")[-1]
        if basename == "MANIFEST.in":
            return True
        return False
    
    if manifest is None:
        # Default: select all regular files, then apply build_ignore exclusions
        selected = set()
        for p in all_regular_paths:
            if not always_excluded(p):
                selected.add(p)
        
        if build_ignore is not None:
            for pattern in build_ignore:
                if not isinstance(pattern, str):
                    raise ValueError("build_ignore patterns must be strings")
                selected = {p for p in selected if not fnmatch.fnmatchcase(p, pattern)}
    else:
        # Parse manifest instructions
        if not isinstance(manifest, str):
            raise ValueError("manifest must be string")
        
        selected = set()
        lines = manifest.split("\n")
        
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            
            parts = stripped.split()
            cmd = parts[0]
            
            if cmd == "include":
                if len(parts) != 2:
                    raise ValueError(f"include requires exactly 1 pattern: {stripped}")
                pattern = parts[1]
                for p in all_regular_paths:
                    if fnmatch.fnmatchcase(p, pattern):
                        selected.add(p)
            
            elif cmd == "exclude":
                if len(parts) != 2:
                    raise ValueError(f"exclude requires exactly 1 pattern: {stripped}")
                pattern = parts[1]
                selected = {p for p in selected if not fnmatch.fnmatchcase(p, pattern)}
            
            elif cmd == "recursive-include":
                if len(parts) != 3:
                    raise ValueError(f"recursive-include requires DIR and PATTERN: {stripped}")
                dir_prefix = parts[1]
                pattern = parts[2]
                for p in all_regular_paths:
                    # Must be under DIR/ at any depth, match basename against pattern
                    if p.startswith(dir_prefix + "/"):
                        basename = p.split("/")[-1]
                        if fnmatch.fnmatchcase(basename, pattern):
                            selected.add(p)
            
            elif cmd == "global-exclude":
                if len(parts) != 2:
                    raise ValueError(f"global-exclude requires exactly 1 pattern: {stripped}")
                pattern = parts[1]
                selected = {p for p in selected if not fnmatch.fnmatchcase(p.split("/")[-1], pattern)}
            
            else:
                raise ValueError(f"unknown manifest command: {cmd}")
        
        # Apply always-excluded filter unconditionally
        selected = {p for p in selected if not always_excluded(p)}
    
    return {
        "name": contract["name"],
        "result": {
            "selected": sorted(selected)
        }
    }
