#!/usr/bin/env python3
"""Run all components in dependency order, then integrate."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _get_python():
    """Get the python executable path, handling empty sys.executable."""
    if sys.executable:
        return sys.executable
    # Fallback: find python3 on PATH
    found = shutil.which("python3")
    if found:
        return found
    raise RuntimeError("Cannot find python3 executable")


def main():
    # Find all contracts (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs
    # Each contract's inputs may reference other contract outputs
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = {"path": cp, "contract": c}

    # Topological sort based on dependencies
    # A component depends on another if any of its inputs is another component's output
    output_to_name = {}
    for name, info in contract_map.items():
        out = info["contract"]["output"]
        output_to_name[out] = name

    deps = {}
    for name, info in contract_map.items():
        dep_names = set()
        for inp in info["contract"]["inputs"]:
            if inp in output_to_name:
                dep_names.add(output_to_name[inp])
        deps[name] = dep_names

    # Topological sort
    order = []
    visited = set()
    temp = set()

    def visit(name):
        if name in temp:
            raise ValueError(f"circular dependency involving {name}")
        if name in visited:
            return
        temp.add(name)
        for d in deps.get(name, set()):
            visit(d)
        temp.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(contract_map.keys()):
        visit(name)

    # Execute each component's render.py in order
    for name in order:
        info = contract_map[name]
        render_py = info["path"].with_name("render.py")
        if not render_py.exists():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [_get_python(), str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py
    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        result = subprocess.run(
            [_get_python(), str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"integrate.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        result = subprocess.run(
            [_get_python(), str(final_report_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"final_report.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == "__main__":
    main()
