import sys
import shutil

if not sys.executable:
    found = shutil.which("python3")
    if found:
        sys.executable = found
