import sys
print(repr(sys.executable))
