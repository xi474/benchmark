# Workflow 可观测性报告

- Trial：`MP19__pQbYkkh__env`
- Task：`MP19`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（92 节点 / 91 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：92；执行边：91（observed=0，inferred=91）
- Execution Trace Graph：`observed`；temporal_next 边 91，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_a2d6235d139e426aa2455628 -> tool:nanobot-harness-v3:call_f8e8b05d71c840699a9e1b09 -> tool:nanobot-harness-v3:call_a23ef23b9e70458da28d9faa -> tool:nanobot-harness-v3:call_2d65ae891992474e809358d1 -> tool:nanobot-harness-v3:call_03e9c68803d04cca93e74899 -> tool:nanobot-harness-v3:call_e258caee85c949439d1cca4e -> tool:nanobot-harness-v3:call_c17e08a48b4746a9b4318eb5 -> tool:nanobot-harness-v3:call_0899650fe80e40cd8cf3c5a0 -> tool:nanobot-harness-v3:call_b69bc7e2b1db40e8b8770def -> tool:nanobot-harness-v3:call_ef7f44358cc74831b0158c96 -> tool:nanobot-harness-v3:call_137c163b72b142188de9ddcb -> tool:nanobot-harness-v3:call_743f4e5efd9a404194513d70 -> tool:nanobot-harness-v3:call_a6a6a53d385b4aea8ad402cb -> tool:nanobot-harness-v3:call_bdd68ac5d2fa4d1fab59e35d -> tool:nanobot-harness-v3:call_f0c87851e1434dcf859f9da5 -> tool:nanobot-harness-v3:call_e935e94fa4874df1ae8089ca -> tool:nanobot-harness-v3:call_822ea7e8be5f471a96cdb8f3 -> tool:nanobot-harness-v3:call_7a015c2148a9453fbd7f3830 -> tool:nanobot-harness-v3:call_7ff175898a2e4200b9272937 -> tool:nanobot-harness-v3:call_cdb089a7b34c4950aa9b3e99 -> tool:nanobot-harness-v3:call_412720a9ec304eda942cc8e4 -> tool:nanobot-harness-v3:call_70fc0ec590194ed789083d41 -> tool:nanobot-harness-v3:call_4fb3229f266a416391d8f602 -> tool:nanobot-harness-v3:call_cf6a4fdba8cb4b9a825fb827 -> tool:nanobot-harness-v3:call_b13872b0e9134ad6a0198179 -> tool:nanobot-harness-v3:call_d8ea806b4ebd43fc8965dcef -> tool:nanobot-harness-v3:call_77fcd578840f4b8fb1e5cff5 -> tool:nanobot-harness-v3:call_f6b53efc04364c6ba475370d -> tool:nanobot-harness-v3:call_5c1269e107b740e38bb5c062 -> tool:nanobot-harness-v3:call_ff62bcbc8a0e431fb9df7233 -> tool:nanobot-harness-v3:call_d23087a7a82541e4a4c70218 -> tool:nanobot-harness-v3:call_93b572cc8cb2415ba53eb09f -> tool:nanobot-harness-v3:call_aa866a951469497e831459dc -> tool:nanobot-harness-v3:call_b0883a8b3c6e4a119eb12b83 -> tool:nanobot-harness-v3:call_8985337327e74c328e33e8ae -> tool:nanobot-harness-v3:call_b03f45e5185842f991ebc754 -> tool:nanobot-harness-v3:call_dfb4fb733c924d9e94d24f4b -> tool:nanobot-harness-v3:call_e0165bedea0a4fd7ace7bfa4 -> tool:nanobot-harness-v3:call_084f394724a54ab0a02e40b0 -> tool:nanobot-harness-v3:call_174bd045cbfc4944866adb3a -> tool:nanobot-harness-v3:call_c3dd165031a94b89aaca0b2d -> tool:nanobot-harness-v3:call_7f391bedaeb946e6828f87c3 -> tool:nanobot-harness-v3:call_5fd1a86611cf44118b0e67b4 -> tool:nanobot-harness-v3:call_fb4faf6bd5d141e49382e03d -> tool:nanobot-harness-v3:call_b6ec3c523b5b4e609772fb77 -> tool:nanobot-harness-v3:call_af3f7f00662347cfa766b12b -> tool:nanobot-harness-v3:call_ac3c4811204d4dd9b3a01368 -> tool:nanobot-harness-v3:call_78bdc9cb14724e8781d0f516 -> tool:nanobot-harness-v3:call_29a58cebecc147aa850d0db6 -> tool:nanobot-harness-v3:call_11cfe6c980294b75bd5e6e34 -> tool:nanobot-harness-v3:call_5b43ffbafccc4442ab7c604c -> tool:nanobot-harness-v3:call_eef2f6aadbbd45d59d71e428 -> tool:nanobot-harness-v3:call_59fc311bc8fc4cf5b9329366 -> tool:nanobot-harness-v3:call_c71629ee4c51413cb29dac7f -> tool:nanobot-harness-v3:call_e6970f3863ff445d8d35b56c -> tool:nanobot-harness-v3:call_09f2649ad3d4493fac57a3d3 -> tool:nanobot-harness-v3:call_ad59ced0c7f24a6c80b8ce65 -> tool:nanobot-harness-v3:call_152b55ce062a45889909389e -> tool:nanobot-harness-v3:call_d79b0ed18afd43f485d15cc5 -> tool:nanobot-harness-v3:call_4ab4ef1cfb114beab64a2c1c -> tool:nanobot-harness-v3:call_c63760de9a374390ade83ff1 -> tool:nanobot-harness-v3:call_e2b046453ac6416abce2aba1 -> tool:nanobot-harness-v3:call_26db612f79f1429cbf4ac488 -> tool:nanobot-harness-v3:call_93ec9f9a193c441ab37db3b3 -> tool:nanobot-harness-v3:call_63e2b9383fd1463bb24dfd1e -> tool:nanobot-harness-v3:call_c871bed155914d17adf8586a -> tool:nanobot-harness-v3:call_927480d06ecc49cca86abc50 -> tool:nanobot-harness-v3:call_2ebf839c15cd439f918b8f83 -> tool:nanobot-harness-v3:call_5af3953810f54b60bb27606b -> tool:nanobot-harness-v3:call_a5f55d8fcf79431fb12fc7e1 -> tool:nanobot-harness-v3:call_16ebd36a35f3472883825852 -> tool:nanobot-harness-v3:call_a98ca68557544b5ba1637b17 -> tool:nanobot-harness-v3:call_f7d01241a7c94ecd97defb2c -> tool:nanobot-harness-v3:call_8a2d44fb9e9141c8a7fbd223 -> tool:nanobot-harness-v3:call_f4a1987c2c52419ea7ea69e8 -> tool:nanobot-harness-v3:call_bda318654d1a4e2cbfb313e2 -> tool:nanobot-harness-v3:call_a64d5114f43b4b5ebb118380 -> tool:nanobot-harness-v3:call_2ce72f50a8094bfa9e840144 -> tool:nanobot-harness-v3:call_bf24f315d0424a618c46b8d8 -> tool:nanobot-harness-v3:call_c6f73f9caa014b6c987095b3 -> tool:nanobot-harness-v3:call_75cbc56b517b415aa2bad2ac -> tool:nanobot-harness-v3:call_692477fdbde24e22be9fa09f -> tool:nanobot-harness-v3:call_e69a427dd3564eb4b1586af2 -> tool:nanobot-harness-v3:call_953e9a6b45e6400a811f192c -> tool:nanobot-harness-v3:call_b0809cd62b7b4c1f906de181 -> tool:nanobot-harness-v3:call_d9ffe56d212e4646baa31c79 -> tool:nanobot-harness-v3:call_8a15ee843aa549c9b1122093 -> tool:nanobot-harness-v3:call_1a841ce357c14cfdb90ab204 -> tool:nanobot-harness-v3:call_b8c452b464114234a8f7dc57 -> tool:nanobot-harness-v3:call_67ea1c64e96d4ec5a9bc5a85 -> tool:nanobot-harness-v3:call_440cd8f413e246228839fa78
- 关键路径耗时：0.880137
- Makespan：481.809505
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
