from collections import deque


def _module_name_from_path(rel_path):
    from pathlib import PurePosixPath
    p = PurePosixPath(rel_path)
    parts = list(p.parts)
    if parts[-1] == '__init__.py':
        parts = parts[:-1]
        if not parts:
            return ''
        return '.'.join(parts)
    else:
        last = parts[-1]
        if last.endswith('.py'):
            parts[-1] = last[:-3]
        return '.'.join(parts)


def transform(payloads, contract):
    case = payloads[0]
    scan_result = payloads[1]['result']

    modules = case['modules']
    entry = case['entry']
    externals = set(case.get('externals', []))
    aliases = case.get('aliases', {})

    imports_map = scan_result['imports']  # path -> [dep module names]
    module_paths = scan_result['module_paths']  # module_name -> path

    # Build reverse: path -> module_name
    path_to_mod = {v: k for k, v in module_paths.items()}

    # Set of all local module names
    local_mod_names = set(module_paths.keys())

    # BFS from entry
    visited_paths = set()
    queue = deque()
    external_used = set()

    # Start with entry
    if entry not in modules:
        raise ValueError(f"entry {entry} not found in modules")
    queue.append(entry)

    def add_parent_inits(path):
        """Add all parent package __init__.py files for a given path."""
        from pathlib import PurePosixPath
        p = PurePosixPath(path)
        parts = list(p.parts)
        # For pkg/sub/a.py, we need pkg/__init__.py and pkg/sub/__init__.py
        # For main.py, no parents
        for i in range(1, len(parts)):
            init_path = '/'.join(parts[:i]) + '/__init__.py'
            if init_path in modules and init_path not in visited_paths:
                visited_paths.add(init_path)
                queue.append(init_path)

    while queue:
        current_path = queue.popleft()
        if current_path in visited_paths:
            continue
        visited_paths.add(current_path)

        # Add parent __init__.py files
        add_parent_inits(current_path)

        # Get dependencies for this path
        deps = imports_map.get(current_path, [])
        for dep_name in deps:
            # Apply alias first
            resolved = aliases.get(dep_name, dep_name)

            # Check if it's a local module
            if resolved in local_mod_names:
                dep_path = module_paths[resolved]
                if dep_path not in visited_paths:
                    queue.append(dep_path)
            else:
                # Check if first segment matches a local module/package
                first_seg = resolved.split('.')[0]
                is_local = False
                if first_seg in local_mod_names:
                    is_local = True
                    dep_path = module_paths[first_seg]
                    if dep_path not in visited_paths:
                        queue.append(dep_path)
                elif any(m.startswith(first_seg + '.') for m in local_mod_names):
                    is_local = True
                    # Find the matching local module
                    for m in local_mod_names:
                        if m == first_seg or m.startswith(first_seg + '.'):
                            dp = module_paths[m]
                            if dp not in visited_paths:
                                queue.append(dp)

                if not is_local:
                    # External module - validate
                    # Check exact match or first-segment match in externals
                    if resolved in externals or first_seg in externals:
                        external_used.add(resolved)
                    else:
                        raise ValueError(f"unknown module: {resolved}")

    result_paths = sorted(visited_paths)
    result_external = sorted(external_used)

    return {
        'name': contract['name'],
        'result': {
            'paths': result_paths,
            'external': result_external
        }
    }
