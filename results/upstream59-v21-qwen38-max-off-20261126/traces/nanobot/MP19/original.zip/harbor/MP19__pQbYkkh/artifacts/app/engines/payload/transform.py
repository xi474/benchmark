import hashlib
import io
import zipfile


def transform(payloads, contract):
    case = payloads[0]
    dep_result = payloads[1]['result']

    modules = case['modules']
    paths = dep_result['paths']
    external = dep_result['external']

    # Check for duplicate paths
    if len(paths) != len(set(paths)):
        raise ValueError("duplicate paths in dependency closure")

    # Check all paths exist in modules
    for p in paths:
        if p not in modules:
            raise ValueError(f"source path not found: {p}")

    # Build ZIP
    zip_paths = sorted(paths)

    # If root __init__.py is missing, add it
    has_root_init = '__init__.py' in zip_paths
    if not has_root_init:
        zip_paths.insert(0, '__init__.py')

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_STORED) as zf:
        for zp in zip_paths:
            if zp == '__init__.py' and not has_root_init:
                data = b''
            else:
                data = modules[zp].encode('utf-8')

            info = zipfile.ZipInfo(filename=zp)
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.create_system = 3
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_STORED
            zf.writestr(info, data)

    zip_bytes = buf.getvalue()
    zip_hex = zip_bytes.hex()
    sha256 = hashlib.sha256(zip_bytes).hexdigest()

    return {
        'name': contract['name'],
        'result': {
            'paths': zip_paths,
            'zip_hex': zip_hex,
            'sha256': sha256,
            'external': external
        }
    }
