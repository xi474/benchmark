import ast
from pathlib import PurePosixPath


def _module_name_from_path(rel_path):
    """Convert a relative .py path to a module name.
    pkg/__init__.py -> 'pkg'
    pkg/a.py -> 'pkg.a'
    __init__.py -> ''
    main.py -> 'main'
    """
    p = PurePosixPath(rel_path)
    parts = list(p.parts)
    if parts[-1] == '__init__.py':
        parts = parts[:-1]
        if not parts:
            return ''
        return '.'.join(parts)
    else:
        # strip .py
        last = parts[-1]
        if last.endswith('.py'):
            parts[-1] = last[:-3]
        return '.'.join(parts)


def _package_of(module_name):
    """Return the package containing this module.
    'pkg.a' -> 'pkg'
    'pkg' (if it's a package i.e. has __init__) -> 'pkg'
    'main' -> ''
    '' -> ''
    """
    if '.' in module_name:
        return module_name.rsplit('.', 1)[0]
    return ''


def transform(payloads, contract):
    case = payloads[0]
    modules = case['modules']
    entry = case['entry']
    externals = case.get('externals', [])
    aliases = case.get('aliases', {})

    # Build set of known local module names and their paths
    local_modules = {}  # module_name -> path
    for rel_path in modules:
        mod_name = _module_name_from_path(rel_path)
        local_modules[mod_name] = rel_path

    # Also build reverse: path -> module_name
    path_to_mod = {v: k for k, v in local_modules.items()}

    imports = {}  # path -> set of canonical dep module names
    
    for rel_path, source in modules.items():
        try:
            tree = ast.parse(source, filename=rel_path)
        except SyntaxError:
            imports[rel_path] = []
            continue

        current_mod = path_to_mod.get(rel_path, '')
        current_package = _package_of(current_mod) if current_mod != '' else ''
        # For root __init__.py, current_mod is '', package is ''
        # For pkg/__init__.py, current_mod is 'pkg', package should be 'pkg' itself
        # Actually for __init__.py files, the module IS the package
        is_init = rel_path.endswith('/__init__.py') or rel_path == '__init__.py'
        if is_init:
            current_package = current_mod  # the module name IS the package
        else:
            current_package = _package_of(current_mod)

        deps = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    dep_name = alias.name
                    # Check if it's a local module
                    if dep_name in local_modules:
                        deps.add(dep_name)
                    else:
                        # Check if first segment is local
                        first_seg = dep_name.split('.')[0]
                        if first_seg in local_modules or any(
                            m.startswith(first_seg + '.') for m in local_modules
                        ):
                            deps.add(dep_name)
                        else:
                            # External dependency - use the full name
                            deps.add(dep_name)

            elif isinstance(node, ast.ImportFrom):
                if node.level is None or node.level == 0:
                    # Absolute import: from X import y
                    if node.module is None:
                        raise ValueError("from * not allowed")
                    base_module = node.module
                    # Check each imported name
                    for alias in node.names:
                        if alias.name == '*':
                            raise ValueError("from * not allowed")
                        # Try X.y as local module first
                        candidate = base_module + '.' + alias.name
                        if candidate in local_modules:
                            deps.add(candidate)
                        elif base_module in local_modules:
                            deps.add(base_module)
                        else:
                            # Check if base_module is external
                            deps.add(base_module)
                else:
                    # Relative import: from . import y or from .x import y
                    level = node.level
                    # Resolve the base package
                    if is_init:
                        # For __init__.py, level=1 means current package
                        pkg_parts = current_mod.split('.') if current_mod else []
                    else:
                        pkg_parts = current_package.split('.') if current_package else []

                    # Go up (level-1) levels from the package
                    if level - 1 > len(pkg_parts):
                        raise ValueError(f"relative import beyond root in {rel_path}")
                    if level - 1 > 0:
                        base_parts = pkg_parts[:-(level - 1)]
                    else:
                        base_parts = pkg_parts

                    if node.module:
                        base_module = '.'.join(base_parts + [node.module]) if base_parts else node.module
                    else:
                        base_module = '.'.join(base_parts) if base_parts else ''

                    for alias in node.names:
                        if alias.name == '*':
                            raise ValueError("from * not allowed")
                        # Try base_module.name as local module
                        if base_module:
                            candidate = base_module + '.' + alias.name
                        else:
                            candidate = alias.name
                        if candidate in local_modules:
                            deps.add(candidate)
                        elif base_module and base_module in local_modules:
                            deps.add(base_module)
                        else:
                            # Could be external or error
                            if base_module:
                                deps.add(base_module)
                            else:
                                deps.add(alias.name)

        imports[rel_path] = sorted(deps)

    # Build module_paths: module_name -> path for all local modules
    module_paths = {}
    for mod_name, rel_path in sorted(local_modules.items()):
        module_paths[mod_name] = rel_path

    result = {
        'imports': {k: imports[k] for k in sorted(imports.keys())},
        'module_paths': module_paths
    }
    return {'name': contract['name'], 'result': result}
