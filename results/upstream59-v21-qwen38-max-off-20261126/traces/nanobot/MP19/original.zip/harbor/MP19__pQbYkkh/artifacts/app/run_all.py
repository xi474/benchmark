#!/usr/bin/env python3
"""Orchestrate all components based on their contract.json files."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or '/usr/local/bin/python3'


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency order: topological sort based on input dependencies
    # Each contract may depend on outputs of other contracts
    contract_map = {}  # name -> contract_path
    contract_data = {}  # name -> parsed contract
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = cp
        contract_data[c['name']] = c

    # Topological sort
    visited = set()
    order = []
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"Circular dependency detected involving {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        c = contract_data[name]
        for inp in c['inputs']:
            # Check if this input is an output of another component
            for other_name, other_c in contract_data.items():
                if other_c['output'] == inp and other_name != name:
                    visit(other_name)
        visiting.discard(name)
        visited.add(name)
        order.append(name)

    for name in sorted(contract_data.keys()):
        visit(name)

    # Execute each component in order via its render.py
    for name in order:
        cp = contract_map[name]
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            print(f"No render.py for component {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
