#!/usr/bin/env python3
"""Wrapper to fix sys.executable and run check.py"""
import sys
import shutil

if not sys.executable:
    sys.executable = shutil.which('python3') or '/bin/python3'

# Now run check.py
exec(open('check.py').read())
