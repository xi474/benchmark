import sys
if not sys.executable:
    import shutil
    p = shutil.which('python3')
    if p:
        sys.executable = p
