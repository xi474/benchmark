# Workflow 可观测性报告

- Trial：`MP20__VNNac5d__env`
- Task：`MP20`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（99 节点 / 98 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：99；执行边：98（observed=0，inferred=98）
- Execution Trace Graph：`observed`；temporal_next 边 98，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_5325e35e4c4344fb80343b04 -> tool:nanobot-harness-v3:call_49823d097b5444c4bc8cf44e -> tool:nanobot-harness-v3:call_4fa104ca8df641c4849e9df0 -> tool:nanobot-harness-v3:call_4ac3865b6e574550abcaf6a1 -> tool:nanobot-harness-v3:call_b21aff87c5f247eb91dd926c -> tool:nanobot-harness-v3:call_03286334d60446c3a13b1092 -> tool:nanobot-harness-v3:call_c2a1533829d9495a84fde821 -> tool:nanobot-harness-v3:call_d87fb5b4a7534a82888a4ce9 -> tool:nanobot-harness-v3:call_c81d45acb64546f9b70615a4 -> tool:nanobot-harness-v3:call_d0294c4b0ba14fd5919962db -> tool:nanobot-harness-v3:call_b1fc063365f54be7be79c676 -> tool:nanobot-harness-v3:call_93285008237c4047a094e917 -> tool:nanobot-harness-v3:call_b7ca368514d84b00a2ea4ce8 -> tool:nanobot-harness-v3:call_4c0f54e7217a43838352dbcd -> tool:nanobot-harness-v3:call_3c3682523c7c45b69545937d -> tool:nanobot-harness-v3:call_83696cde511d493f85b48078 -> tool:nanobot-harness-v3:call_d121164d90ae4085925a7d73 -> tool:nanobot-harness-v3:call_61e1d1510ac04578b0c7cd6b -> tool:nanobot-harness-v3:call_c4aead9559ee43e4bd22301f -> tool:nanobot-harness-v3:call_4b44d72172b44395b1f505ef -> tool:nanobot-harness-v3:call_ee48f8d2a6cd4fe080969efe -> tool:nanobot-harness-v3:call_8fe2e8da75a443a2be0ac4d5 -> tool:nanobot-harness-v3:call_ac1ec45e4717456fb2799289 -> tool:nanobot-harness-v3:call_34b8c3900b384d63af2291a9 -> tool:nanobot-harness-v3:call_8972124f6fdd40969bc0d6ad -> tool:nanobot-harness-v3:call_67ad203968ff454cbded760f -> tool:nanobot-harness-v3:call_9d45e238c9aa4d9388783bc2 -> tool:nanobot-harness-v3:call_623e2b5f29b24cbd96502bec -> tool:nanobot-harness-v3:call_a1fd57e1042e4e8fb5798e86 -> tool:nanobot-harness-v3:call_d85b90eeb1714138ad3400c9 -> tool:nanobot-harness-v3:call_ce9920ff898645c4b2062836 -> tool:nanobot-harness-v3:call_3679ccd114e54801a571c888 -> tool:nanobot-harness-v3:call_dd2c37afbffe4782a28b05ae -> tool:nanobot-harness-v3:call_14e6600686ab46b9b27611bf -> tool:nanobot-harness-v3:call_88b39ece069a42679363e285 -> tool:nanobot-harness-v3:call_56c30323d3b54ed5bef19ad9 -> tool:nanobot-harness-v3:call_af4d222e94974087a4aa13b6 -> tool:nanobot-harness-v3:call_8040a1e577614f3b908bfedc -> tool:nanobot-harness-v3:call_8e2cd84dc38149788c0ac900 -> tool:nanobot-harness-v3:call_f4269bc6c2a741588b747e2e -> tool:nanobot-harness-v3:call_266f44bc5e3b42fdbcfde3d2 -> tool:nanobot-harness-v3:call_03cda7be99a54f1784abe7d2 -> tool:nanobot-harness-v3:call_8db8b600d0ff4073bef8f9a4 -> tool:nanobot-harness-v3:call_8d38281ab73144ee9b150536 -> tool:nanobot-harness-v3:call_9e757bce773b46789343efe8 -> tool:nanobot-harness-v3:call_5f44f2c6a63445ed8cfb4828 -> tool:nanobot-harness-v3:call_bbb49041466c490ca8d3ea64 -> tool:nanobot-harness-v3:call_d5de9d4857b34f10858edbba -> tool:nanobot-harness-v3:call_14be1d6b74384f01adbde4d7 -> tool:nanobot-harness-v3:call_56a0fdad8d8549668d4f9cd9 -> tool:nanobot-harness-v3:call_cb9aeebc5d2745e7abdff9dc -> tool:nanobot-harness-v3:call_5cbe1db6d6ea430985c35731 -> tool:nanobot-harness-v3:call_70941b4825f14d69b386dc0b -> tool:nanobot-harness-v3:call_abcd2dd0a43741af85f72df8 -> tool:nanobot-harness-v3:call_169bcbd13a8446a58821a110 -> tool:nanobot-harness-v3:call_420bd0b8f5f04c72aafbd6cd -> tool:nanobot-harness-v3:call_90fccbe0c1494b2e95b1849d -> tool:nanobot-harness-v3:call_7ef8fc7ef53e4fc8810707ad -> tool:nanobot-harness-v3:call_75891d9c4e3a472ba43cec77 -> tool:nanobot-harness-v3:call_c09b7e706258467cafe89610 -> tool:nanobot-harness-v3:call_3372c3781db54aca831c2b90 -> tool:nanobot-harness-v3:call_c0f2bea058dc447c830277de -> tool:nanobot-harness-v3:call_fa89baaaab654cb192ecdb34 -> tool:nanobot-harness-v3:call_24e62299b70b4a8e8249b91f -> tool:nanobot-harness-v3:call_a06a2943425c413c82785afa -> tool:nanobot-harness-v3:call_5a1e2d5801ae48c89a7e12cf -> tool:nanobot-harness-v3:call_e7ee52c83e204355b5e1d120 -> tool:nanobot-harness-v3:call_67796f4c0cd04a7ba7cf9b19 -> tool:nanobot-harness-v3:call_e2b4c12329e04cd2818f7487 -> tool:nanobot-harness-v3:call_d0f27ea0855843e89f594a87 -> tool:nanobot-harness-v3:call_61d459c1940f480bbeeed47d -> tool:nanobot-harness-v3:call_0ed39a6df7bc491083f98e64 -> tool:nanobot-harness-v3:call_3e0dbf2d2d6a4051af1c7903 -> tool:nanobot-harness-v3:call_ecb384bc45fc4158a26bd78f -> tool:nanobot-harness-v3:call_dfc45afb4dbf41db900d07b5 -> tool:nanobot-harness-v3:call_d31ec69a867c4fc396cc421f -> tool:nanobot-harness-v3:call_c3e0af26992c43e9b0babf24 -> tool:nanobot-harness-v3:call_0b3d2cb6e2014464a5655070 -> tool:nanobot-harness-v3:call_44a3316e27564b62a189fa13 -> tool:nanobot-harness-v3:call_124582ee6f4c4b178ba1e615 -> tool:nanobot-harness-v3:call_3fb001667f2a4e859d2277e1 -> tool:nanobot-harness-v3:call_ed31285ad53a47d39db77e4d -> tool:nanobot-harness-v3:call_409e286e548a42cb90d9dfe9 -> tool:nanobot-harness-v3:call_494abfe93a0d4012877b2063 -> tool:nanobot-harness-v3:call_b39d6f27fe6b41afbed1910d -> tool:nanobot-harness-v3:call_10919e72927e4c8cb78a0beb -> tool:nanobot-harness-v3:call_c6b2415d2ff441f69e6cd62a -> tool:nanobot-harness-v3:call_07e8595ef27f4710ba3fcc48 -> tool:nanobot-harness-v3:call_a89ceaec33a444e3961e7266 -> tool:nanobot-harness-v3:call_1566f9f6f756449d8f89c3a7 -> tool:nanobot-harness-v3:call_4d9eb42f20734981a059468f -> tool:nanobot-harness-v3:call_b55bbb965c034dee94fd3b0f -> tool:nanobot-harness-v3:call_21b8c0cf9623470aa0dee9d4 -> tool:nanobot-harness-v3:call_e0c7725d308744c3a194e4f3 -> tool:nanobot-harness-v3:call_44cd884119a749e28ed78ea0 -> tool:nanobot-harness-v3:call_fc7428821d9c480a9b347190 -> tool:nanobot-harness-v3:call_2a7464bf9c614dacb48bf8a8 -> tool:nanobot-harness-v3:call_ac25a713ed68416e88409ce1
- 关键路径耗时：0.964043
- Makespan：422.223118
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
