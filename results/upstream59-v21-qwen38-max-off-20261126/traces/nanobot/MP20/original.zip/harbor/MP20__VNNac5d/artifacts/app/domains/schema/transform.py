import copy


def _validate_input(data):
    """Validate feature_schema input structure."""
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    for key in ("flags", "segments", "old_snapshot"):
        if key not in data:
            raise ValueError(f"missing required field: {key}")
    if not isinstance(data["flags"], list):
        raise ValueError("flags must be array")
    if not isinstance(data["segments"], list):
        raise ValueError("segments must be array")
    if not isinstance(data["old_snapshot"], dict):
        raise ValueError("old_snapshot must be object")

    flag_ids = set()
    for flag in data["flags"]:
        if not isinstance(flag, dict):
            raise ValueError("flag must be object")
        if "id" not in flag:
            raise ValueError("flag missing id")
        fid = flag["id"]
        if not isinstance(fid, str) or not fid.strip():
            raise ValueError("flag id must be non-empty string")
        if fid in flag_ids:
            raise ValueError(f"duplicate flag id: {fid}")
        flag_ids.add(fid)

        if "variants" not in flag:
            raise ValueError(f"flag {fid} missing variants")
        if not isinstance(flag["variants"], list):
            raise ValueError(f"flag {fid} variants must be array")
        variant_ids = set()
        for v in flag["variants"]:
            if not isinstance(v, dict):
                raise ValueError("variant must be object")
            if "id" not in v:
                raise ValueError("variant missing id")
            vid = v["id"]
            if not isinstance(vid, str) or not vid.strip():
                raise ValueError("variant id must be non-empty string")
            if vid in variant_ids:
                raise ValueError(f"duplicate variant id {vid} in flag {fid}")
            variant_ids.add(vid)
            if "attachment" not in v:
                raise ValueError(f"variant {vid} missing attachment")

        if "rules" not in flag:
            raise ValueError(f"flag {fid} missing rules")
        if not isinstance(flag["rules"], list):
            raise ValueError(f"flag {fid} rules must be array")
        rule_ids = set()
        for r in flag["rules"]:
            if not isinstance(r, dict):
                raise ValueError("rule must be object")
            if "id" not in r:
                raise ValueError("rule missing id")
            rid = r["id"]
            if not isinstance(rid, str) or not rid.strip():
                raise ValueError("rule id must be non-empty string")
            if rid in rule_ids:
                raise ValueError(f"duplicate rule id {rid} in flag {fid}")
            rule_ids.add(rid)
            if "segment" not in r:
                raise ValueError(f"rule {rid} missing segment")
            if not isinstance(r["segment"], str):
                raise ValueError(f"rule {rid} segment must be string")
            if "variant" not in r:
                raise ValueError(f"rule {rid} missing variant")
            if not isinstance(r["variant"], str):
                raise ValueError(f"rule {rid} variant must be string")

    seg_ids = set()
    for s in data["segments"]:
        if not isinstance(s, dict):
            raise ValueError("segment must be object")
        if "id" not in s:
            raise ValueError("segment missing id")
        sid = s["id"]
        if not isinstance(sid, str) or not sid.strip():
            raise ValueError("segment id must be non-empty string")
        if sid in seg_ids:
            raise ValueError(f"duplicate segment id: {sid}")
        seg_ids.add(sid)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    # If wrapped with name/result, extract result
    if isinstance(data, dict) and set(data.keys()) == {"name", "result"}:
        data = data["result"]
    _validate_input(data)
    return {
        "name": contract["name"],
        "result": {
            "flags": copy.deepcopy(data["flags"]),
            "segments": copy.deepcopy(data["segments"]),
        },
    }
