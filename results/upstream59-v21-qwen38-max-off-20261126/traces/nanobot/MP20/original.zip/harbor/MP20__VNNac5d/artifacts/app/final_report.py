import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core["components"]
    component_count = len(components)

    # SHA256 of the full core object
    core_bytes = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(core_bytes).hexdigest()

    # Attention: components matching any trigger condition
    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        # blocked explicitly true
        if result.get("blocked") is True:
            attention.add(name)
        # complete/checkout/committed/ok explicitly false
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0 and val is not False:
                # Non-empty check: list/dict must be non-empty, string non-empty
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(name)
                elif not isinstance(val, (list, dict, str, bool, int, float, type(None))):
                    attention.add(name)

    attention_sorted = sorted(attention)

    report = {
        "title": "\u7279\u6027\u914d\u7f6e\u7684\u6a21\u5f0f\u3001\u9644\u4ef6\u4e0e\u5f15\u7528\u4e00\u81f4\u6027",
        "component_count": component_count,
        "sha256": sha256_hex,
        "attention": attention_sorted,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        report, ensure_ascii=False, sort_keys=True,
        indent=2, allow_nan=False,
    )
    out_path.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
