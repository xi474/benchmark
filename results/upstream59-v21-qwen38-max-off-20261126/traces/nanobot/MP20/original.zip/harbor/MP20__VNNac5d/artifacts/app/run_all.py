import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    # Discover all contract.json files (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("ERROR: no contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: each contract's inputs may reference other outputs
    # We need topological order. Parse all contracts first.
    contract_map = {}  # name -> {contract_data, path}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = {"data": c, "path": cp}

    # Build adjacency: component A depends on B if A's input references B's output
    output_to_name = {}
    for name, info in contract_map.items():
        out_rel = info["data"]["output"]
        output_to_name[out_rel] = name

    deps = {}  # name -> set of dependency names
    for name, info in contract_map.items():
        deps[name] = set()
        for inp in info["data"]["inputs"]:
            if inp in output_to_name:
                dep_name = output_to_name[inp]
                if dep_name != name:
                    deps[name].add(dep_name)

    # Topological sort (Kahn's algorithm)
    in_degree = {n: 0 for n in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            pass  # we count incoming edges below
    # Recompute in_degree properly
    in_degree = {n: 0 for n in contract_map}
    reverse_deps = {n: set() for n in contract_map}
    for name, dep_set in deps.items():
        for d in dep_set:
            reverse_deps[d].add(name)
            in_degree[name] += 1

    queue = sorted([n for n, deg in in_degree.items() if deg == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for dependent in sorted(reverse_deps[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
        queue.sort()

    if len(order) != len(contract_map):
        print("ERROR: dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute components in topological order via render.py
    for name in order:
        info = contract_map[name]
        comp_dir = info["path"].parent
        render_script = comp_dir / "render.py"
        if not render_script.exists():
            print(f"ERROR: missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_script)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print(f"ERROR: {name} render failed", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_script = ROOT / "integrate.py"
    result = subprocess.run(
        [sys.executable, str(integrate_script)],
        cwd=str(ROOT),
        timeout=60,
    )
    if result.returncode != 0:
        print("ERROR: integrate.py failed", file=sys.stderr)
        sys.exit(1)

    # Run final_report.py
    report_script = ROOT / "final_report.py"
    result = subprocess.run(
        [sys.executable, str(report_script)],
        cwd=str(ROOT),
        timeout=60,
    )
    if result.returncode != 0:
        print("ERROR: final_report.py failed", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
