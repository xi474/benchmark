def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    # Input is feature_schema result: {flags:[...], segments:[...]}
    if isinstance(data, dict) and set(data.keys()) == {"name", "result"}:
        data = data["result"]

    flags = data["flags"]
    segments = data["segments"]
    segment_ids = {s["id"] for s in segments}

    # Check segment references first, sorted by flag id then rule id
    sorted_flags = sorted(flags, key=lambda f: f["id"])
    for flag in sorted_flags:
        fid = flag["id"]
        sorted_rules = sorted(flag["rules"], key=lambda r: r["id"])
        for rule in sorted_rules:
            rid = rule["id"]
            target = rule["segment"]
            if target not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": fid,
                            "rule": rid,
                            "target": target,
                        },
                    },
                }

    # All segments valid; now check variant references within each flag
    for flag in sorted_flags:
        fid = flag["id"]
        variant_ids = {v["id"] for v in flag["variants"]}
        sorted_rules = sorted(flag["rules"], key=lambda r: r["id"])
        for rule in sorted_rules:
            rid = rule["id"]
            target = rule["variant"]
            if target not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": fid,
                            "rule": rid,
                            "target": target,
                        },
                    },
                }

    return {
        "name": contract["name"],
        "result": {"ok": True, "error": None},
    }
