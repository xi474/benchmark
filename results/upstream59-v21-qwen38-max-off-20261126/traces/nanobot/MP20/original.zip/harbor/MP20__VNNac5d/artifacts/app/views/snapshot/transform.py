import copy
import json


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    raw_input = payloads[0]
    schema_result = payloads[1]
    attachments_result = payloads[2]
    references_result = payloads[3]

    # Unwrap name/result wrappers
    if isinstance(raw_input, dict) and set(raw_input.keys()) == {"name", "result"}:
        raw_input = raw_input["result"]
    if isinstance(schema_result, dict) and set(schema_result.keys()) == {"name", "result"}:
        schema_result = schema_result["result"]
    if isinstance(attachments_result, dict) and set(attachments_result.keys()) == {"name", "result"}:
        attachments_result = attachments_result["result"]
    if isinstance(references_result, dict) and set(references_result.keys()) == {"name", "result"}:
        references_result = references_result["result"]

    old_snapshot = raw_input["old_snapshot"]

    # If references failed, atomic rollback
    if not references_result.get("ok", False):
        return {
            "name": contract["name"],
            "result": {
                "committed": False,
                "snapshot": copy.deepcopy(old_snapshot),
                "error": references_result.get("error"),
                "export": None,
            },
        }

    # Build snapshot from schema + attachments
    att_map = attachments_result["attachments"]
    snap_flags = []
    for flag in schema_result["flags"]:
        fid = flag["id"]
        variants = []
        for v in flag["variants"]:
            vid = v["id"]
            att_value = att_map[fid][vid]["value"]
            variants.append({"id": vid, "attachment": copy.deepcopy(att_value)})
        variants.sort(key=lambda x: x["id"])
        rules_sorted = sorted(
            [copy.deepcopy(r) for r in flag["rules"]],
            key=lambda r: r["id"],
        )
        snap_flags.append({
            "id": fid,
            "variants": variants,
            "rules": rules_sorted,
        })
    snap_flags.sort(key=lambda f: f["id"])

    snap_segments = sorted(
        [copy.deepcopy(s) for s in schema_result["segments"]],
        key=lambda s: s["id"],
    )

    snapshot = {"flags": snap_flags, "segments": snap_segments}
    export_str = json.dumps(
        snapshot, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False,
    )

    return {
        "name": contract["name"],
        "result": {
            "committed": True,
            "snapshot": snapshot,
            "error": None,
            "export": export_str,
        },
    }
