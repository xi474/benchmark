# Workflow 可观测性报告

- Trial：`MP21__KCSysnL__env`
- Task：`MP21`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（65 节点 / 64 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：65；执行边：64（observed=0，inferred=64）
- Execution Trace Graph：`observed`；temporal_next 边 64，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_58ec8237dc084e1bbf5886fb -> tool:nanobot-harness-v3:call_02264b94452a4bb989f628c4 -> tool:nanobot-harness-v3:call_4a47b24457a548aea93bf2f8 -> tool:nanobot-harness-v3:call_5eaef8ec4dd548d29e6990da -> tool:nanobot-harness-v3:call_d33e6021f182463694786bc5 -> tool:nanobot-harness-v3:call_16dacd0892e141d086f99c33 -> tool:nanobot-harness-v3:call_ba10eacc3f7e40c0b495351e -> tool:nanobot-harness-v3:call_b6ff062d221341eb91d2ff7e -> tool:nanobot-harness-v3:call_7a4cb79d77d343c098eb2ed6 -> tool:nanobot-harness-v3:call_7849e1373e1745a090c73bbf -> tool:nanobot-harness-v3:call_386ffd42dd78475a8560b96a -> tool:nanobot-harness-v3:call_4cc4f4cbfaea4020ad115fd2 -> tool:nanobot-harness-v3:call_f52872ddf8034c39827d090a -> tool:nanobot-harness-v3:call_6ac6e581d9cf4b1ca22f2e3e -> tool:nanobot-harness-v3:call_e651f24809014f8795e44fff -> tool:nanobot-harness-v3:call_567affc4aa4949f89f8bdeb0 -> tool:nanobot-harness-v3:call_155bbe92c50e475c84ef9c8b -> tool:nanobot-harness-v3:call_b96c732938bb490fac21415a -> tool:nanobot-harness-v3:call_aa6bd1be56814ffc95ac0e3d -> tool:nanobot-harness-v3:call_bb6814b5691e4c2c8e0ab594 -> tool:nanobot-harness-v3:call_27e7ae02a5e242f59c6b3724 -> tool:nanobot-harness-v3:call_fd89f726773541b4a83fc530 -> tool:nanobot-harness-v3:call_bd71d1afb4eb4a5e9c03de63 -> tool:nanobot-harness-v3:call_7fd71822bd3c49a791c67499 -> tool:nanobot-harness-v3:call_50b1c8e8c455464d8873abb9 -> tool:nanobot-harness-v3:call_0f5100bf91474f128e8a4bd5 -> tool:nanobot-harness-v3:call_2daaba1dcc7241999d304bfb -> tool:nanobot-harness-v3:call_49cf615c395f4dfb8835a1dc -> tool:nanobot-harness-v3:call_ab4456b704eb43cbacc279b9 -> tool:nanobot-harness-v3:call_9d101c6affa8496f96b10de9 -> tool:nanobot-harness-v3:call_3e9a7fe6f2854099bad47173 -> tool:nanobot-harness-v3:call_59a064e9f56e402b939acf03 -> tool:nanobot-harness-v3:call_8df5924c4c934f42a415ce7e -> tool:nanobot-harness-v3:call_0b5a4180580b4114a0cd6cff -> tool:nanobot-harness-v3:call_ff4073611b6b47da90240007 -> tool:nanobot-harness-v3:call_3f7f7b18fa954fefb28b2dc5 -> tool:nanobot-harness-v3:call_50512dee0bff4eef84791c76 -> tool:nanobot-harness-v3:call_7e5dea629f6d4b20a9d9b976 -> tool:nanobot-harness-v3:call_2c86ff71d25c4411ae72b830 -> tool:nanobot-harness-v3:call_e7056baeb8ef419593834bfc -> tool:nanobot-harness-v3:call_5ee538c9242c4058b321e125 -> tool:nanobot-harness-v3:call_296cd6de98b34fdda794f2bd -> tool:nanobot-harness-v3:call_b38384cc90fa452d922fddb6 -> tool:nanobot-harness-v3:call_74f9aa44c1ca41f68d1fe577 -> tool:nanobot-harness-v3:call_f245b0da5a1043b1a8000c9c -> tool:nanobot-harness-v3:call_3a925f5dcc5d4170aaf2e808 -> tool:nanobot-harness-v3:call_d1757e3e438f422a902efb26 -> tool:nanobot-harness-v3:call_668ea2708ce84e638f3771b8 -> tool:nanobot-harness-v3:call_fc6a6d17271845138ae20738 -> tool:nanobot-harness-v3:call_e5a07e8c2e834783bbfbb457 -> tool:nanobot-harness-v3:call_cc6c3123c16646aa918e4ee6 -> tool:nanobot-harness-v3:call_294f937411b64ee18c1883e6 -> tool:nanobot-harness-v3:call_f84a80244e994081bc97f5af -> tool:nanobot-harness-v3:call_fd4b62f5f85b4f85afae329b -> tool:nanobot-harness-v3:call_8f87593b885044f89f37e49f -> tool:nanobot-harness-v3:call_0ed0031d294945aca70a805b -> tool:nanobot-harness-v3:call_16208fb924b144b2a3c0eae4 -> tool:nanobot-harness-v3:call_78dbf025917d458d8f87a6a7 -> tool:nanobot-harness-v3:call_586695f9e9a64fe488a29b2a -> tool:nanobot-harness-v3:call_782a560c89034f08a2d0cf6c -> tool:nanobot-harness-v3:call_63b83bb24134445ba9a26935 -> tool:nanobot-harness-v3:call_e90249d520424fad9100054e -> tool:nanobot-harness-v3:call_4c0b9eee47cc49089e779d7f -> tool:nanobot-harness-v3:call_ff69900c482f4357adf9dcfb
- 关键路径耗时：0.803839
- Makespan：257.132086
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
