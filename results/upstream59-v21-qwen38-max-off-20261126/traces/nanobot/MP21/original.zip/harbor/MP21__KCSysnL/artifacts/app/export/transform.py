from decimal import Decimal, ROUND_HALF_UP


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    # data is the playlist_replace result: {name, result: {playlist, tracks}}
    if 'result' not in data:
        raise ValueError("missing result in playlist input")
    inner = data['result']
    if 'playlist' not in inner or 'tracks' not in inner:
        raise ValueError("missing playlist or tracks")
    playlist = inner['playlist']
    tracks = inner['tracks']
    name = playlist['name']
    # Validate no CR/LF in name
    if '\r' in name or '\n' in name:
        raise ValueError("playlist name contains CR/LF")
    lines = ['#EXTM3U', f'#PLAYLIST:{name}']
    for t in tracks:
        dur = t['duration']
        # Use Decimal for ROUND_HALF_UP
        d = Decimal(str(dur)).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
        seconds = int(d)
        artist = t.get('artist', '')
        title = t.get('title', '')
        path = t.get('path', '')
        # Validate no CR/LF in path or artist-title line
        info_line = f'#EXTINF:{seconds},{artist} - {title}'
        if '\r' in info_line or '\n' in info_line:
            raise ValueError("track info contains CR/LF")
        if '\r' in path or '\n' in path:
            raise ValueError("track path contains CR/LF")
        lines.append(info_line)
        lines.append(path)
    m3u = '\n'.join(lines) + '\n'
    return {
        'name': contract['name'],
        'result': {
            'm3u': m3u
        }
    }
