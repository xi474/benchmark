import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    title = '\u64ad\u653e\u5217\u8868\u91cd\u5199\u3001\u6761\u4ef6\u67e5\u8be2\u4e0e M3U \u5bfc\u51fa'
    components = core.get('components', {})
    component_count = len(components)

    # SHA256 of the full core object
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # Attention: components with specific conditions
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        # blocked explicitly true
        if result.get('blocked') is True:
            triggered = True
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                triggered = True
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # Non-empty check: list/dict/str must be non-empty; other truthy values count
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    triggered = True
                elif not isinstance(val, (list, dict, str)) and val:
                    triggered = True
        if triggered:
            attention.append(name)
    attention = sorted(set(attention))

    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
