def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    # Validate required fields
    for key in ('tracks', 'playlist', 'replacement', 'criteria'):
        if key not in data:
            raise ValueError(f"missing field: {key}")
    tracks = data['tracks']
    playlist = data['playlist']
    replacement = data['replacement']
    # Build track lookup
    track_map = {}
    for t in tracks:
        for f in ('id', 'title', 'artist', 'path', 'duration'):
            if f not in t:
                raise ValueError(f"track missing field: {f}")
        tid = t['id']
        if tid in track_map:
            raise ValueError(f"duplicate track id: {tid}")
        dur = t['duration']
        if isinstance(dur, bool):
            raise ValueError("duration must not be bool")
        if not isinstance(dur, (int, float)):
            raise ValueError("duration must be numeric")
        import math
        if math.isnan(dur) or math.isinf(dur):
            raise ValueError("duration must be finite")
        if dur < 0:
            raise ValueError("duration must be non-negative")
        track_map[tid] = t
    # Validate replacement IDs
    for rid in replacement:
        if rid not in track_map:
            raise ValueError(f"unknown replacement track id: {rid}")
    # Build new playlist
    new_track_ids = list(replacement)
    new_tracks = [track_map[rid] for rid in new_track_ids]
    total_duration = sum(track_map[rid]['duration'] for rid in new_track_ids)
    result_playlist = {
        'id': playlist['id'],
        'name': playlist['name'],
        'track_ids': new_track_ids,
        'track_count': len(new_track_ids),
        'duration': total_duration
    }
    return {
        'name': contract['name'],
        'result': {
            'playlist': result_playlist,
            'tracks': new_tracks
        }
    }
