import json
import sys
from pathlib import Path

_pkg_dir = Path(__file__).resolve().parent
_root = _pkg_dir.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from query.model import load_payload
from query.transform import transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    contract_path = Path(__file__).resolve().with_name('contract.json')
    build_component(root, contract_path)
