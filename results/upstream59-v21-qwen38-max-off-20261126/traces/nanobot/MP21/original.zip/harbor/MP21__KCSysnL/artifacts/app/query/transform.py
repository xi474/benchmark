import math


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if 'criteria' not in data:
        raise ValueError("missing criteria")
    criteria = data['criteria']
    if 'filters' not in criteria:
        raise ValueError("missing filters")
    if 'limit' not in criteria:
        raise ValueError("missing limit")
    filters = criteria['filters']
    limit = criteria['limit']
    # Validate limit
    if isinstance(limit, bool):
        raise ValueError("limit must not be bool")
    if not isinstance(limit, int):
        raise ValueError("limit must be int")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be 1..100")
    # Valid fields and ops
    str_fields = {'id', 'name'}
    num_fields = {'track_count', 'duration'}
    valid_ops = {'eq', 'ne', 'gt', 'ge', 'lt', 'le'}
    str_ops = {'eq', 'ne'}
    op_map = {
        'eq': '=', 'ne': '!=', 'gt': '>', 'ge': '>=', 'lt': '<', 'le': '<='
    }
    clauses = []
    params = []
    for f in filters:
        if 'field' not in f or 'op' not in f or 'value' not in f:
            raise ValueError("filter missing field/op/value")
        field = f['field']
        op = f['op']
        value = f['value']
        if field not in str_fields | num_fields:
            raise ValueError(f"invalid field: {field}")
        if op not in valid_ops:
            raise ValueError(f"invalid op: {op}")
        if field in str_fields:
            if not isinstance(value, str):
                raise ValueError(f"value for {field} must be str")
            if op not in str_ops:
                raise ValueError(f"op {op} not allowed for {field}")
        else:
            if isinstance(value, bool):
                raise ValueError("numeric value must not be bool")
            if not isinstance(value, (int, float)):
                raise ValueError(f"value for {field} must be numeric")
            if math.isnan(value) or math.isinf(value):
                raise ValueError("numeric value must be finite")
            if value < 0:
                raise ValueError("numeric value must be non-negative")
        clauses.append(f"{field} {op_map[op]} ?")
        params.append(value)
    sql = "SELECT id FROM playlists"
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)
    return {
        'name': contract['name'],
        'result': {
            'sql': sql,
            'params': params
        }
    }
