import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _python():
    """Return a usable python interpreter path."""
    if sys.executable:
        return sys.executable
    return shutil.which('python3') or shutil.which('python') or 'python3'


def main():
    # Discover all contract.json files (excluding outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        raise ValueError('no contracts found')

    # Build dependency graph: component name -> contract info
    comp_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        comp_map[c['name']] = {'contract': c, 'path': cp}

    # Topological sort based on input dependencies
    # An input like "outputs/playlist.json" means it depends on that component
    output_to_comp = {}
    for name, info in comp_map.items():
        out = info['contract']['output']
        output_to_comp[out] = name

    # Build adjacency: comp -> set of deps
    deps = {}
    for name, info in comp_map.items():
        d = set()
        for inp in info['contract']['inputs']:
            if inp in output_to_comp:
                d.add(output_to_comp[inp])
        deps[name] = d

    # Kahn's algorithm
    order = []
    remaining = dict(deps)
    while remaining:
        ready = [n for n, d in remaining.items() if not d]
        if not ready:
            raise ValueError('circular dependency detected')
        ready.sort()
        for n in ready:
            order.append(n)
            del remaining[n]
        for n in remaining:
            remaining[n] -= set(ready)

    # Execute components in order
    for name in order:
        info = comp_map[name]
        cp = info['path']
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError(f'render.py not found for {name}')
        result = subprocess.run(
            [_python(), str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(f'Component {name} failed:', file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / 'integrate.py'
    if integrate.is_file():
        result = subprocess.run(
            [_python(), str(integrate)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print('integrate.py failed:', file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report = ROOT / 'final_report.py'
    if report.is_file():
        result = subprocess.run(
            [_python(), str(report)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print('final_report.py failed:', file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
