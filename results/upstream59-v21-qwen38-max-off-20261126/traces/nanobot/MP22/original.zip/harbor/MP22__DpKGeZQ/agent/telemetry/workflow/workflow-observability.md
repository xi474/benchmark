# Workflow 可观测性报告

- Trial：`MP22__DpKGeZQ__env`
- Task：`MP22`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（102 节点 / 101 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：102；执行边：101（observed=0，inferred=101）
- Execution Trace Graph：`observed`；temporal_next 边 101，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_a100344cfbd1481981e76200 -> tool:nanobot-harness-v3:call_c0e6a57a3f274da79a67c59a -> tool:nanobot-harness-v3:call_dfc9b5c1300545d4a48946ad -> tool:nanobot-harness-v3:call_304f73f675c54b4396ce9ac1 -> tool:nanobot-harness-v3:call_18c594c583574070aab5ed62 -> tool:nanobot-harness-v3:call_42a545f269fd4758b95dacea -> tool:nanobot-harness-v3:call_efc75896f2034acfa4da2ff6 -> tool:nanobot-harness-v3:call_e461509b3544438dab090d05 -> tool:nanobot-harness-v3:call_1b9f1e970a5840f3900f193d -> tool:nanobot-harness-v3:call_ecc689f53b1446b3bf595a1a -> tool:nanobot-harness-v3:call_be511903522c4d93842ca2fc -> tool:nanobot-harness-v3:call_dc782593f0ec4019b35a7d89 -> tool:nanobot-harness-v3:call_768abd5c29a24333b7bd98bb -> tool:nanobot-harness-v3:call_e396089a0be84fff99d5b7ed -> tool:nanobot-harness-v3:call_1d64e24b0f1d43289b901c76 -> tool:nanobot-harness-v3:call_ba98c8381716437c960ccb54 -> tool:nanobot-harness-v3:call_96ce67a4557840d6805c93a8 -> tool:nanobot-harness-v3:call_53f14c59b9db470ea36b18d2 -> tool:nanobot-harness-v3:call_fdd08b5f93a14a0abc0bc0f9 -> tool:nanobot-harness-v3:call_4182196417c3434eab3b7f4c -> tool:nanobot-harness-v3:call_ca05d7fbace8495fb3db3b38 -> tool:nanobot-harness-v3:call_c89ca8410e9f41f5abf19111 -> tool:nanobot-harness-v3:call_17905f65dd10441890995776 -> tool:nanobot-harness-v3:call_d583b0f946d741a89340f9b5 -> tool:nanobot-harness-v3:call_c9100abc36f341559315d4af -> tool:nanobot-harness-v3:call_3bad7239a85d4b4d95f20756 -> tool:nanobot-harness-v3:call_b253fbb9055e4aae90a5ea7a -> tool:nanobot-harness-v3:call_706296d668ca4a1ba45ebc95 -> tool:nanobot-harness-v3:call_9620e5d1382541bc95f6f422 -> tool:nanobot-harness-v3:call_e74cae9600064016a36af98f -> tool:nanobot-harness-v3:call_16d4ddcb1d4e438e88f0baae -> tool:nanobot-harness-v3:call_41c9c1cb41034f9698b07a08 -> tool:nanobot-harness-v3:call_a0513bf7d07e48eb8a533ec7 -> tool:nanobot-harness-v3:call_d59d411e269f4dc6811f8a3b -> tool:nanobot-harness-v3:call_f88c8b9bdf2a4f1fa88cd76a -> tool:nanobot-harness-v3:call_d8fa75f939ec4c94a9779551 -> tool:nanobot-harness-v3:call_74ab1c9e4f7f4553a0a0de24 -> tool:nanobot-harness-v3:call_3269e439c8354400904cb94e -> tool:nanobot-harness-v3:call_ec40434a850245ff8aabc835 -> tool:nanobot-harness-v3:call_ab32739eeba74a3fa1de455d -> tool:nanobot-harness-v3:call_3fce9525018b4acabe6ded5b -> tool:nanobot-harness-v3:call_bc4ef7758f774448ad518139 -> tool:nanobot-harness-v3:call_92c206d5425444aa9004f19c -> tool:nanobot-harness-v3:call_4882e7c7f2934434ab9de635 -> tool:nanobot-harness-v3:call_e2da0afc4cc14c91888c80be -> tool:nanobot-harness-v3:call_b88ad5aaec054b45bd17ee10 -> tool:nanobot-harness-v3:call_48701f450bf94db49c45dc05 -> tool:nanobot-harness-v3:call_1fb9f8eadb9e4678b034229a -> tool:nanobot-harness-v3:call_8dd3001463f141bca1c21343 -> tool:nanobot-harness-v3:call_6b96b85be0e5452bab169565 -> tool:nanobot-harness-v3:call_9b4a7f6576cb424086d27919 -> tool:nanobot-harness-v3:call_999836d6b4c44b49a8771aed -> tool:nanobot-harness-v3:call_070fd8d85aa54158aaaadbf4 -> tool:nanobot-harness-v3:call_1416785f7cd9421c89dfde15 -> tool:nanobot-harness-v3:call_baccf2c229ab422ba61603a2 -> tool:nanobot-harness-v3:call_6e859874539b433c88d79baf -> tool:nanobot-harness-v3:call_7f3fff008b5043bd8c27d365 -> tool:nanobot-harness-v3:call_1fbacaa784ac417cba34b181 -> tool:nanobot-harness-v3:call_fa41ba98f7324498a8f6fcec -> tool:nanobot-harness-v3:call_ec5c83fef09a482bb670fdb4 -> tool:nanobot-harness-v3:call_f44e708481934d17a6a37b77 -> tool:nanobot-harness-v3:call_b3a9da43ff6c4ad7aabf57a5 -> tool:nanobot-harness-v3:call_afd472822b344b3aad9351da -> tool:nanobot-harness-v3:call_4816bb1a49044480939bc005 -> tool:nanobot-harness-v3:call_838165bfa4c3402282b7ccb2 -> tool:nanobot-harness-v3:call_30b124b8969645cebf381fad -> tool:nanobot-harness-v3:call_e7e845374ce2456c9dc76b6a -> tool:nanobot-harness-v3:call_179e938b785a4a5ea7fbd2e0 -> tool:nanobot-harness-v3:call_4a1f93c210394db3ba9727ae -> tool:nanobot-harness-v3:call_ef79f93908e84b97bd6eaa2b -> tool:nanobot-harness-v3:call_77ee96d82b1341b487fc70c8 -> tool:nanobot-harness-v3:call_acb7504b5fff4db0b0727c75 -> tool:nanobot-harness-v3:call_5e503e3e9a9b4fb6ad0fc5e0 -> tool:nanobot-harness-v3:call_697ac906881640dab2fd1868 -> tool:nanobot-harness-v3:call_bfa11462f44e47c49deca2a9 -> tool:nanobot-harness-v3:call_b0d1dabf1bb546bca8965c7f -> tool:nanobot-harness-v3:call_2ffe4c722d884acbb7f9fba3 -> tool:nanobot-harness-v3:call_f331f839d2254fbd8daeba16 -> tool:nanobot-harness-v3:call_458abbf8f3654460aac386ba -> tool:nanobot-harness-v3:call_45c80aeaee994bfdb3e82461 -> tool:nanobot-harness-v3:call_7910d743358744829b20ac19 -> tool:nanobot-harness-v3:call_b7bfed7afb6140fe85765ff3 -> tool:nanobot-harness-v3:call_2ccb1304f5ae4d479053c67b -> tool:nanobot-harness-v3:call_90ada6eebe71435e89cfbdec -> tool:nanobot-harness-v3:call_9105a59c0fff4e5ca072fc47 -> tool:nanobot-harness-v3:call_8cbf4f9999d14539884baf1a -> tool:nanobot-harness-v3:call_5ae5526123de41ae99c4d544 -> tool:nanobot-harness-v3:call_42cf2cc4940345fea0925ee3 -> tool:nanobot-harness-v3:call_22dc7855d429492a87da0766 -> tool:nanobot-harness-v3:call_130225f4799747adaf95d9b9 -> tool:nanobot-harness-v3:call_a2a95fa1d71e4f9db096deec -> tool:nanobot-harness-v3:call_b089301d256e4eb891e90896 -> tool:nanobot-harness-v3:call_f84012011e67493db1c65d10 -> tool:nanobot-harness-v3:call_f3ef79a7fbf84861bb1e9e8b -> tool:nanobot-harness-v3:call_3e8328ffca98448baa991f7d -> tool:nanobot-harness-v3:call_da3fc3577e3d4c2c9c2d24ae -> tool:nanobot-harness-v3:call_d129def1d15b4b9e9cf488e1 -> tool:nanobot-harness-v3:call_0527c742c00b4f01b3ddbae4 -> tool:nanobot-harness-v3:call_75b0c10c360040d09adb6af0 -> tool:nanobot-harness-v3:call_9e4531186ac5404493930389 -> tool:nanobot-harness-v3:call_b8f466aa7b3b4a4a9ebb95a2
- 关键路径耗时：1.512045
- Makespan：439.859535
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
