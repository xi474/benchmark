import re


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    reader_result = payloads[1]

    if not isinstance(case, dict):
        raise ValueError("case input must be object")
    if 'language_codes' not in case:
        raise ValueError("missing language_codes")
    valid_codes = case['language_codes']
    if not isinstance(valid_codes, list):
        raise ValueError("language_codes must be array")
    for c in valid_codes:
        if not isinstance(c, str) or not re.fullmatch(r'[a-z]{3}', c):
            raise ValueError(f"invalid language code: {c}")
    # Check uniqueness
    if len(set(valid_codes)) != len(valid_codes):
        raise ValueError("duplicate language codes")

    valid_set = set(valid_codes)

    if not isinstance(reader_result, dict):
        raise ValueError("reader result must be object")
    if isinstance(reader_result, dict) and set(reader_result.keys()) == {'name', 'result'}:
        reader_result = reader_result['result']

    records_in = reader_result.get('records', [])
    out_records = []

    for rec in records_in:
        rec_id = rec['id']
        controls = rec.get('controls', {})
        fields = rec.get('fields', [])
        langs = []

        # 008: positions 35-37
        if '008' in controls:
            field_008 = controls['008']
            if len(field_008) >= 38:
                code_008 = field_008[35:38]
                if code_008 in valid_set and code_008 not in langs:
                    langs.append(code_008)

        # 041 $a/$d/$h
        for f in fields:
            if f['tag'] == '041':
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'd', 'h'):
                        val = sf['value'].strip()
                        if len(val) % 3 != 0:
                            raise ValueError(f"041 subfield length not multiple of 3: '{val}'")
                        for i in range(0, len(val), 3):
                            code = val[i:i+3]
                            if code in valid_set and code not in langs:
                                langs.append(code)

        langs = sorted(set(langs))
        out_records.append({'id': rec_id, 'languages': langs})

    out_records.sort(key=lambda r: r['id'])
    return {'name': contract['name'], 'result': {'records': out_records}}
