import re


def _clean_name(text):
    """Collapse internal whitespace, strip leading/trailing spaces/slashes/commas/colons/semicolons. Keep periods."""
    # Collapse internal whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # Strip leading/trailing: space, slash, comma, colon, semicolon
    text = text.strip(' /,;:')
    return text


def _parse_link_code(val):
    """Parse $6 value like '880-01' or '100-01/r' -> (tag, nn, suffix).
    Returns None if invalid format."""
    val = val.strip()
    m = re.fullmatch(r'(\d{3})-(\d+)(/.*)?', val)
    if not m:
        return None
    return m.group(1), m.group(2), m.group(3) or ''


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    reader_result = payloads[0]
    if not isinstance(reader_result, dict):
        raise ValueError("input must be object")
    # When input object keys are exactly {name, result}, use result
    if isinstance(reader_result, dict) and set(reader_result.keys()) == {'name', 'result'}:
        reader_result = reader_result['result']

    records_in = reader_result.get('records', [])
    out_records = []

    for rec in records_in:
        rec_id = rec['id']
        fields = rec.get('fields', [])

        # Build index of 880 fields by their $6 link
        # 880 $6 should be like '100-01' or '245-01'
        alt_map = {}  # (target_tag, nn) -> list of subfield lists
        for f in fields:
            if f['tag'] == '880':
                sf6 = None
                for sf in f['subfields']:
                    if sf['code'] == '6':
                        sf6 = sf['value']
                        break
                if sf6 is None:
                    continue
                parsed = _parse_link_code(sf6)
                if parsed is None:
                    continue
                target_tag, nn, suffix = parsed
                if target_tag in ('100', '245'):
                    key = (target_tag, nn)
                    if key not in alt_map:
                        alt_map[key] = []
                    alt_map[key].append(f['subfields'])

        authors = []
        titles = []

        for f in fields:
            if f['tag'] == '100':
                # Extract $a and $b for author name
                parts = []
                sf6_val = None
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'b'):
                        parts.append(sf['value'])
                    elif sf['code'] == '6':
                        sf6_val = sf['value']
                name = _clean_name(' '.join(parts))
                alternates = []
                if sf6_val is not None:
                    parsed = _parse_link_code(sf6_val)
                    if parsed is not None:
                        src_tag, nn, suffix = parsed
                        if src_tag == '880':
                            key = ('100', nn)
                            if key in alt_map:
                                for alt_sfs in alt_map[key]:
                                    alt_parts = []
                                    for sf in alt_sfs:
                                        if sf['code'] in ('a', 'b'):
                                            alt_parts.append(sf['value'])
                                    alt_name = _clean_name(' '.join(alt_parts))
                                    if alt_name and alt_name not in alternates:
                                        alternates.append(alt_name)
                alternates = sorted(set(alternates))
                authors.append({'name': name, 'alternates': alternates})

            elif f['tag'] == '245':
                parts = []
                sf6_val = None
                for sf in f['subfields']:
                    if sf['code'] in ('a', 'b'):
                        parts.append(sf['value'])
                    elif sf['code'] == '6':
                        sf6_val = sf['value']
                title = _clean_name(' '.join(parts))
                alternates = []
                if sf6_val is not None:
                    parsed = _parse_link_code(sf6_val)
                    if parsed is not None:
                        src_tag, nn, suffix = parsed
                        if src_tag == '880':
                            key = ('245', nn)
                            if key in alt_map:
                                for alt_sfs in alt_map[key]:
                                    alt_parts = []
                                    for sf in alt_sfs:
                                        if sf['code'] in ('a', 'b'):
                                            alt_parts.append(sf['value'])
                                    alt_title = _clean_name(' '.join(alt_parts))
                                    if alt_title and alt_title not in alternates:
                                        alternates.append(alt_title)
                alternates = sorted(set(alternates))
                titles.append({'title': title, 'alternates': alternates})

        out_records.append({
            'id': rec_id,
            'authors': authors,
            'titles': titles
        })

    out_records.sort(key=lambda r: r['id'])
    return {'name': contract['name'], 'result': {'records': out_records}}
