import re
import xml.etree.ElementTree as ET


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("input must be object")
    if 'xml' not in case:
        raise ValueError("missing xml field")
    if 'language_codes' not in case:
        raise ValueError("missing language_codes field")
    xml_str = case['xml']
    if not isinstance(xml_str, str):
        raise ValueError("xml must be string")

    # Reject DOCTYPE/ENTITY
    if re.search(r'<!\s*(DOCTYPE|ENTITY)', xml_str, re.IGNORECASE):
        raise ValueError("DOCTYPE/ENTITY not allowed")

    # Parse XML
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError as e:
        raise ValueError(f"bad XML: {e}") from e

    # Handle namespace
    ns = ''
    tag_root = root.tag
    if tag_root.startswith('{'):
        ns = tag_root.split('}')[0] + '}'

    def strip_ns(tag):
        if tag.startswith('{'):
            return tag.split('}')[1]
        return tag

    local_root = strip_ns(root.tag)
    if local_root not in ('collection', 'record'):
        raise ValueError(f"root must be collection or record, got {local_root}")

    # Gather records
    if local_root == 'collection':
        record_elems = [c for c in root if strip_ns(c.tag) == 'record']
    else:
        record_elems = [root]

    seen_ids = set()
    records = []

    for rec_elem in record_elems:
        controls = {}
        fields = []
        rec_id = None

        for child in rec_elem:
            local = strip_ns(child.tag)
            if local == 'controlfield':
                tag = child.get('tag')
                if tag is None:
                    raise ValueError("controlfield missing tag")
                if not re.fullmatch(r'\d{3}', tag):
                    raise ValueError(f"controlfield tag must be 3 digits: {tag}")
                if tag in controls:
                    raise ValueError(f"duplicate controlfield tag {tag}")
                text = child.text or ''
                if tag == '001':
                    if not text.strip():
                        raise ValueError("001 must be non-empty")
                    rec_id = text
                controls[tag] = text
            elif local == 'datafield':
                tag = child.get('tag')
                if tag is None:
                    raise ValueError("datafield missing tag")
                if not re.fullmatch(r'\d{3}', tag):
                    raise ValueError(f"datafield tag must be 3 digits: {tag}")
                subfields = []
                for sf in child:
                    sf_local = strip_ns(sf.tag)
                    if sf_local != 'subfield':
                        raise ValueError(f"unknown element in datafield: {sf_local}")
                    code = sf.get('code')
                    if code is None:
                        raise ValueError("subfield missing code")
                    if not re.fullmatch(r'[A-Za-z0-9]', code):
                        raise ValueError(f"subfield code must be single alnum: {code}")
                    value = sf.text or ''
                    subfields.append({'code': code, 'value': value})
                fields.append({'tag': tag, 'subfields': subfields})
            else:
                raise ValueError(f"unknown element in record: {local}")

        if rec_id is None:
            raise ValueError("record missing 001 controlfield")
        if rec_id in seen_ids:
            raise ValueError(f"duplicate record id: {rec_id}")
        seen_ids.add(rec_id)
        records.append({'id': rec_id, 'controls': controls, 'fields': fields})

    # Sort by id
    records.sort(key=lambda r: r['id'])

    return {'name': contract['name'], 'result': {'records': records}}
