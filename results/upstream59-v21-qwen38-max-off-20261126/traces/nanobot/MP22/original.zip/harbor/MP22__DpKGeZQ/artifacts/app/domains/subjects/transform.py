import re
from collections import OrderedDict


TAG_CATEGORY = {
    '600': 'people',
    '610': 'organizations',
    '611': 'meetings',
    '630': 'works',
    '650': 'topics',
    '651': 'places',
}

ALL_CATEGORIES = ['people', 'organizations', 'meetings', 'works', 'topics', 'places']


def _clean_segment(text):
    """Collapse whitespace, strip leading/trailing spaces/slashes/commas/colons/semicolons. Keep periods."""
    text = re.sub(r'\s+', ' ', text).strip()
    text = text.strip(' /,;:')
    return text


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    reader_result = payloads[0]
    if not isinstance(reader_result, dict):
        raise ValueError("input must be object")
    if isinstance(reader_result, dict) and set(reader_result.keys()) == {'name', 'result'}:
        reader_result = reader_result['result']

    records_in = reader_result.get('records', [])
    out_records = []

    for rec in records_in:
        rec_id = rec['id']
        fields = rec.get('fields', [])

        # Count subjects per category
        # Key: (category, full_heading_string) -> count
        counts = {}

        for f in fields:
            tag = f['tag']
            if tag not in TAG_CATEGORY:
                continue
            category = TAG_CATEGORY[tag]

            # Build main heading from $a/$b
            main_parts = []
            subdivisions = []
            for sf in f['subfields']:
                if sf['code'] in ('a', 'b'):
                    main_parts.append(sf['value'])
                elif sf['code'] in ('v', 'x', 'y', 'z'):
                    subdivisions.append(sf['value'])

            main_heading = _clean_segment(' '.join(main_parts))
            segments = [main_heading] if main_heading else []
            for sd in subdivisions:
                cleaned = _clean_segment(sd)
                if cleaned:
                    segments.append(cleaned)

            full_heading = ' -- '.join(segments)
            if not full_heading:
                continue

            key = (category, full_heading)
            counts[key] = counts.get(key, 0) + 1

        subjects = {}
        for cat in ALL_CATEGORIES:
            items = []
            for (c, val), cnt in counts.items():
                if c == cat:
                    items.append({'value': val, 'count': cnt})
            items.sort(key=lambda x: x['value'])
            subjects[cat] = items

        out_records.append({'id': rec_id, 'subjects': subjects})

    out_records.sort(key=lambda r: r['id'])
    return {'name': contract['name'], 'result': {'records': out_records}}
