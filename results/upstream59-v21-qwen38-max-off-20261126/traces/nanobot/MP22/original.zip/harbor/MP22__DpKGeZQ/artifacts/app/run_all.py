import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Find a working python interpreter
PYTHON = sys.executable if sys.executable else shutil.which('python3') or 'python3'


def main():
    # Find all contract.json files (excluding outputs)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: output -> component render script
    # Each contract specifies inputs and output
    # We need to topologically sort by dependencies
    contract_map = {}  # contract_path -> contract dict
    output_to_render = {}  # output_rel_path -> (contract_path, render_script)

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[cp] = c
        render_script = cp.with_name('render.py')
        if not render_script.is_file():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        output_to_render[c['output']] = (cp, render_script)

    # Topological sort based on input dependencies
    visited = set()
    order = []

    def visit(output_path):
        if output_path in visited:
            return
        if output_path not in output_to_render:
            # It's an external input (like inputs/case.json), skip
            return
        cp, render_script = output_to_render[output_path]
        c = contract_map[cp]
        for inp in c['inputs']:
            visit(inp)
        visited.add(output_path)
        order.append((cp, render_script))

    for cp in contracts:
        c = contract_map[cp]
        visit(c['output'])

    # Execute each component in order
    for cp, render_script in order:
        result = subprocess.run(
            [PYTHON, str(render_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.is_file():
        result = subprocess.run(
            [PYTHON, str(report_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
