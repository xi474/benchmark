def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    names_result = payloads[0]
    languages_result = payloads[1]
    subjects_result = payloads[2]

    # Unwrap name/result if present
    for r in [names_result, languages_result, subjects_result]:
        if not isinstance(r, dict):
            raise ValueError("input must be object")

    def unwrap(r):
        if 'name' in r and 'result' in r:
            return r['result']
        return r

    names_data = unwrap(names_result)
    languages_data = unwrap(languages_result)
    subjects_data = unwrap(subjects_result)

    # Build maps by id
    names_map = {}
    for rec in names_data.get('records', []):
        rid = rec['id']
        if rid in names_map:
            raise ValueError(f"duplicate id in names: {rid}")
        names_map[rid] = rec

    languages_map = {}
    for rec in languages_data.get('records', []):
        rid = rec['id']
        if rid in languages_map:
            raise ValueError(f"duplicate id in languages: {rid}")
        languages_map[rid] = rec

    subjects_map = {}
    for rec in subjects_data.get('records', []):
        rid = rec['id']
        if rid in subjects_map:
            raise ValueError(f"duplicate id in subjects: {rid}")
        subjects_map[rid] = rec

    # Check ID sets are identical
    ids_names = set(names_map.keys())
    ids_langs = set(languages_map.keys())
    ids_subjs = set(subjects_map.keys())

    if ids_names != ids_langs or ids_names != ids_subjs:
        raise ValueError("record ID sets differ across components")

    records = []
    for rid in sorted(ids_names):
        n = names_map[rid]
        l = languages_map[rid]
        s = subjects_map[rid]
        records.append({
            'id': rid,
            'authors': n.get('authors', []),
            'titles': n.get('titles', []),
            'languages': l.get('languages', []),
            'subjects': s.get('subjects', {})
        })

    return {
        'name': contract['name'],
        'result': {
            'records': records,
            'record_count': len(records)
        }
    }
