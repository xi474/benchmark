# Workflow 可观测性报告

- Trial：`MP23__zLAEFiX__env`
- Task：`MP23`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（68 节点 / 67 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：68；执行边：67（observed=0，inferred=67）
- Execution Trace Graph：`observed`；temporal_next 边 67，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_428ad0f2589b43e08846eff7 -> tool:nanobot-harness-v3:call_8d4f55efa13044189a39f2da -> tool:nanobot-harness-v3:call_1459830eac4d44588c8e587b -> tool:nanobot-harness-v3:call_09729f8ea48d4c989900a39d -> tool:nanobot-harness-v3:call_029552fa6837408082dfe58b -> tool:nanobot-harness-v3:call_25be8c6b5c7a43348f1bc8e0 -> tool:nanobot-harness-v3:call_cb2bb2ab771b48aa96b1683d -> tool:nanobot-harness-v3:call_2df3173e11a442db8614672b -> tool:nanobot-harness-v3:call_c4cd0c0107c548a894de5547 -> tool:nanobot-harness-v3:call_b80d79bca5864101bc69fe8e -> tool:nanobot-harness-v3:call_3f3bd114b24b42e898869ae3 -> tool:nanobot-harness-v3:call_1782bdfcb6524c248133b087 -> tool:nanobot-harness-v3:call_8b99b478c9e74cbc991fe886 -> tool:nanobot-harness-v3:call_af026d5647d4468b96a91535 -> tool:nanobot-harness-v3:call_5a95a73d0bdc4f91bb3e0254 -> tool:nanobot-harness-v3:call_22997ab1726a44d089426558 -> tool:nanobot-harness-v3:call_612ec2aebae34edfb54c1183 -> tool:nanobot-harness-v3:call_30bef32efadc4c7d9b434028 -> tool:nanobot-harness-v3:call_0c3aaa4f214243f48b4757f4 -> tool:nanobot-harness-v3:call_19ac8dc72fcf41f4b2d8bec9 -> tool:nanobot-harness-v3:call_078ffa87e72d4527a2368bd6 -> tool:nanobot-harness-v3:call_2e38e03767d448a6aa1289a1 -> tool:nanobot-harness-v3:call_84c16a151aef46c58497882a -> tool:nanobot-harness-v3:call_8f4caf3be933468e829cb0ab -> tool:nanobot-harness-v3:call_74034ae0a2d44a4b98246fc8 -> tool:nanobot-harness-v3:call_25a0cf16a4784ec08aa9290a -> tool:nanobot-harness-v3:call_258d498ce63e440789753262 -> tool:nanobot-harness-v3:call_862dc9306fbd4b79b0e73e6a -> tool:nanobot-harness-v3:call_65fc15643f4a4f668ab42213 -> tool:nanobot-harness-v3:call_84a874edfb5b49bf8254c271 -> tool:nanobot-harness-v3:call_8b207018160641f08d386a8f -> tool:nanobot-harness-v3:call_0820b9e5d2bb4ab7807e8a00 -> tool:nanobot-harness-v3:call_de4c6e7db8a64075afcd52ab -> tool:nanobot-harness-v3:call_29ed0b02ecc94d33954bbe1e -> tool:nanobot-harness-v3:call_cc30fd02cc1a4394bf262547 -> tool:nanobot-harness-v3:call_609cf56ae6674d4d8119cdd7 -> tool:nanobot-harness-v3:call_c91f1a744a5d44659e5b6888 -> tool:nanobot-harness-v3:call_8530da03b28248e9841a5822 -> tool:nanobot-harness-v3:call_ee20dc4abd784264a971f86b -> tool:nanobot-harness-v3:call_3f7ed63045ef40deb05af790 -> tool:nanobot-harness-v3:call_1d282d337af04d07859faee4 -> tool:nanobot-harness-v3:call_06a9abcbe04e4d4f9a526a2b -> tool:nanobot-harness-v3:call_7b6d2f4f9b474668a548f0f2 -> tool:nanobot-harness-v3:call_f336439722bb4caca8f05686 -> tool:nanobot-harness-v3:call_a2c48e25df394305882a6109 -> tool:nanobot-harness-v3:call_8473caeb0bd84c5795a0d3f2 -> tool:nanobot-harness-v3:call_2a97320f728441a98acddfb7 -> tool:nanobot-harness-v3:call_c8751c8cc3074d40816ae40f -> tool:nanobot-harness-v3:call_015ca89570484c7aaad478b1 -> tool:nanobot-harness-v3:call_93ee7485b122416eb2b51135 -> tool:nanobot-harness-v3:call_dcffc73adfea41cdb1b5b282 -> tool:nanobot-harness-v3:call_5dacb3c7935444af9a810550 -> tool:nanobot-harness-v3:call_efbc33aa401a416bb1aa5410 -> tool:nanobot-harness-v3:call_8332abb31b4740c1810c42ed -> tool:nanobot-harness-v3:call_dd78f28f650548149eb5273e -> tool:nanobot-harness-v3:call_999752f34053424192fb047f -> tool:nanobot-harness-v3:call_ea17f7097b1841d280c5dcb7 -> tool:nanobot-harness-v3:call_41cc492681044c14818a8d2b -> tool:nanobot-harness-v3:call_6b94bad228034fc2987b729f -> tool:nanobot-harness-v3:call_df585de692ec486e807ed25c -> tool:nanobot-harness-v3:call_d5e5b51afa624c64b1d58bce -> tool:nanobot-harness-v3:call_1b9b932500f049de81e3306f -> tool:nanobot-harness-v3:call_071f0625de194d71b7fbdbb8 -> tool:nanobot-harness-v3:call_4c4aef07545b4635b17c69bc -> tool:nanobot-harness-v3:call_4bf375ce37f340b1ae84fc95 -> tool:nanobot-harness-v3:call_569f73d0dad94e89abc07bf4 -> tool:nanobot-harness-v3:call_38e38b8933304b53b967518a
- 关键路径耗时：1.187472
- Makespan：477.466741
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
