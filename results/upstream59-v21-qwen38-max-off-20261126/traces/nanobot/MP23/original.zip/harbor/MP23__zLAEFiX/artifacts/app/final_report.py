#!/usr/bin/env python3
"""Generate final report from core_manifest.json."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core['components']

    # Compute sha256 of the complete core object
    core_str = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False
    )
    sha = hashlib.sha256(core_str.encode('utf-8')).hexdigest()

    # Determine attention list
    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        needs_attention = False
        # blocked explicitly true
        if result.get('blocked') is True:
            needs_attention = True
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                needs_attention = True
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {}:
                if isinstance(val, (list, str, dict)) and len(val) > 0:
                    needs_attention = True
        if needs_attention:
            attention.append(name)

    attention.sort()

    report = {
        'title': '受目录容量限制的可逆文件重分片',
        'component_count': len(components),
        'sha256': sha,
        'attention': attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
    out_path.write_text(text, encoding='utf-8')


if __name__ == '__main__':
    main()
