import json
from pathlib import Path


def load_payload(path):
    """Read UTF-8 JSON from path. Only object/array top-level allowed.
    Raises ValueError for invalid JSON, non-object/array top-level,
    or any NaN/Infinity in nested values."""
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(obj, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(obj)
    return obj


def _check_finite(obj):
    """Recursively check for NaN/Infinity in float values."""
    if isinstance(obj, float):
        import math
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("non-finite number in JSON")
    elif isinstance(obj, dict):
        for v in obj.values():
            _check_finite(v)
    elif isinstance(obj, list):
        for v in obj:
            _check_finite(v)
