import hashlib


def transform(payloads, contract):
    """reshard_chunks: split files into max_file_bytes chunks."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]

    # Validate required fields
    if not isinstance(inp, dict):
        raise ValueError("input must be object")
    for key in ('files', 'max_file_bytes', 'max_entries'):
        if key not in inp:
            raise ValueError(f"missing field: {key}")

    files = inp['files']
    max_file_bytes = inp['max_file_bytes']
    max_entries = inp['max_entries']

    if not isinstance(files, list):
        raise ValueError("files must be array")
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    # Validate and sort files by path
    seen_paths = set()
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("file entry must be object")
        if 'path' not in f or 'hex' not in f:
            raise ValueError("file entry missing path or hex")
        path = f['path']
        hex_str = f['hex']
        if not isinstance(path, str) or not isinstance(hex_str, str):
            raise ValueError("path and hex must be strings")
        _validate_safe_path(path)
        if path in seen_paths:
            raise ValueError(f"duplicate path: {path}")
        seen_paths.add(path)
        # Validate hex
        try:
            bytes.fromhex(hex_str)
        except ValueError:
            raise ValueError(f"invalid hex for path {path}")

    sorted_files = sorted(files, key=lambda x: x['path'])

    all_chunks = []
    manifest_files = []
    global_chunk_idx = 0

    for f in sorted_files:
        path = f['path']
        raw = bytes.fromhex(f['hex'])
        size = len(raw)
        sha = hashlib.sha256(raw).hexdigest()
        parts = []

        if size == 0:
            # Empty file: no chunks
            pass
        else:
            offset = 0
            while offset < size:
                end = min(offset + max_file_bytes, size)
                chunk_data = raw[offset:end]
                chunk_name = f"d{global_chunk_idx:07d}.bin"
                all_chunks.append({
                    'name': chunk_name,
                    'hex': chunk_data.hex()
                })
                parts.append(chunk_name)
                global_chunk_idx += 1
                offset = end

        manifest_files.append({
            'path': path,
            'size': size,
            'sha256': sha,
            'parts': parts
        })

    result = {
        'chunks': all_chunks,
        'manifest': {
            'files': manifest_files
        }
    }

    return {'name': contract['name'], 'result': result}


def _validate_safe_path(path):
    """Validate that path is a safe relative path."""
    if not path or not isinstance(path, str):
        raise ValueError("empty or invalid path")
    if '\\' in path or ':' in path:
        raise ValueError("unsafe characters in path")
    if path.startswith('/'):
        raise ValueError("absolute path not allowed")
    parts = path.split('/')
    for part in parts:
        if not part or part == '.' or part == '..':
            raise ValueError(f"unsafe path segment: {part}")
