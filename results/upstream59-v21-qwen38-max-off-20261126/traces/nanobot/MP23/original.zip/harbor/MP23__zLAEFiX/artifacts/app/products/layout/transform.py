import json
import math


def transform(payloads, contract):
    """reshard_layout: organize chunks into a directory tree."""
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    original_input = payloads[0]
    chunks_result = payloads[1]

    # Extract parameters from original input
    max_file_bytes = original_input['max_file_bytes']
    max_entries = original_input['max_entries']

    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError("max_file_bytes must be int >= 16")
    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError("max_entries must be int >= 2")

    # Get chunks and manifest from chunks result
    if 'result' in chunks_result and 'name' in chunks_result:
        cr = chunks_result['result']
    else:
        cr = chunks_result

    chunks_list = cr['chunks']
    manifest = cr['manifest']

    # Serialize manifest as compact canonical JSON (UTF-8 bytes)
    manifest_json = json.dumps(
        manifest, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False
    ).encode('utf-8')

    # Split manifest into max_file_bytes chunks named m000000.bin, etc.
    meta_chunks = []
    offset = 0
    meta_idx = 0
    while offset < len(manifest_json):
        end = min(offset + max_file_bytes, len(manifest_json))
        chunk_data = manifest_json[offset:end]
        chunk_name = f"m{meta_idx:07d}.bin"
        meta_chunks.append({
            'name': chunk_name,
            'hex': chunk_data.hex()
        })
        meta_idx += 1
        offset = end

    # Combine data chunks and metadata chunks, sort by name lexicographically
    all_items = list(chunks_list) + list(meta_chunks)
    all_items.sort(key=lambda x: x['name'])
    n = len(all_items)

    if n == 0:
        return {'name': contract['name'], 'result': {
            'tree': [],
            'max_entries': max_entries,
            'max_file_bytes': max_file_bytes
        }}

    # Find minimum h >= 1 such that max_entries^h >= n
    h = 1
    while max_entries ** h < n:
        h += 1

    # Build tree entries
    tree = []
    for i, item in enumerate(all_items):
        # Convert index i to h-digit base-max_entries number
        digits = _to_base(i, max_entries, h)
        # First h-1 digits become directory names n<digit>
        dir_parts = [f"n{d}" for d in digits[:-1]]
        # File keeps its original name
        if dir_parts:
            path = '/'.join(dir_parts) + '/' + item['name']
        else:
            path = item['name']
        tree.append({
            'path': path,
            'hex': item['hex']
        })

    # Sort tree by path
    tree.sort(key=lambda x: x['path'])

    return {'name': contract['name'], 'result': {
        'tree': tree,
        'max_entries': max_entries,
        'max_file_bytes': max_file_bytes
    }}


def _to_base(value, base, num_digits):
    """Convert value to a list of digits in given base with exactly num_digits."""
    digits = []
    v = value
    for _ in range(num_digits):
        digits.append(v % base)
        v //= base
    digits.reverse()
    return digits
