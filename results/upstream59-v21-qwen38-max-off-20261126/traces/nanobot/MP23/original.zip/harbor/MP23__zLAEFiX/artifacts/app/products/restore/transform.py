import hashlib
import json
import re


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    lr = payloads[0]
    if 'result' in lr and 'name' in lr:
        lr = lr['result']
    tree = lr['tree']
    me = lr['max_entries']
    mfb = lr['max_file_bytes']
    if not isinstance(tree, list):
        raise ValueError("tree must be array")
    if not isinstance(me, int) or isinstance(me, bool) or me < 2:
        raise ValueError("max_entries invalid")
    if not isinstance(mfb, int) or isinstance(mfb, bool) or mfb < 16:
        raise ValueError("max_file_bytes invalid")
    pd = re.compile(r'^d(\d+)\.bin$')
    pm = re.compile(r'^m(\d+)\.bin$')
    bn_set = set()
    dc = {}
    mc = {}
    sp = set()
    de = {}
    for e in tree:
        if not isinstance(e, dict):
            raise ValueError("entry must be object")
        p = e['path']; h = e['hex']
        if not isinstance(p, str) or not isinstance(h, str):
            raise ValueError("path/hex must be str")
        _vsp(p)
        if p in sp:
            raise ValueError("dup path")
        sp.add(p)
        raw = bytes.fromhex(h)
        if len(raw) > mfb:
            raise ValueError("exceeds max_file_bytes")
        pts = p.split('/'); bn = pts[-1]
        if not (pd.match(bn) or pm.match(bn)):
            raise ValueError("invalid basename")
        if bn in bn_set:
            raise ValueError("dup basename")
        bn_set.add(bn)
        dp = '/'.join(pts[:-1]) if len(pts) > 1 else ''
        de.setdefault(dp, set()).add(bn)
        for i in range(1, len(pts) - 1):
            par = '/'.join(pts[:i])
            de.setdefault(par, set()).add(pts[i])
        if pd.match(bn):
            dc[bn] = h
        elif pm.match(bn):
            mc[bn] = h
    for _, ents in de.items():
        if len(ents) > me:
            raise ValueError("dir exceeds max_entries")
    mi = sorted(int(pm.match(n).group(1)) for n in mc)
    if mi and mi != list(range(len(mi))):
        raise ValueError("m chunks not consecutive")
    mb = b''
    for idx in mi:
        mb += bytes.fromhex(mc[f"m{idx:07d}.bin"])
    try:
        mf = json.loads(mb.decode('utf-8'))
    except Exception as ex:
        raise ValueError(f"invalid manifest: {ex}") from ex
    if not isinstance(mf, dict) or 'files' not in mf:
        raise ValueError("manifest missing files")
    ref = set(); res = []; tb = 0
    for fi in mf['files']:
        asm = b''
        for pn in fi['parts']:
            if pn not in dc:
                raise ValueError(f"missing chunk {pn}")
            if pn in ref:
                raise ValueError(f"dup ref {pn}")
            ref.add(pn)
            asm += bytes.fromhex(dc[pn])
        if len(asm) != fi['size']:
            raise ValueError("size mismatch")
        if hashlib.sha256(asm).hexdigest() != fi['sha256']:
            raise ValueError("sha256 mismatch")
        res.append({'path': fi['path'], 'hex': asm.hex()})
        tb += len(asm)
    extra = set(dc.keys()) - ref
    if extra:
        raise ValueError("unreferenced chunks")
    res.sort(key=lambda x: x['path'])
    return {'name': contract['name'], 'result': {
        'files': res, 'total_bytes': tb
    }}


def _vsp(path):
    if not path or not isinstance(path, str):
        raise ValueError("empty path")
    if '\\' in path or ':' in path:
        raise ValueError("unsafe chars")
    if path.startswith('/'):
        raise ValueError("absolute path")
    for pt in path.split('/'):
        if not pt or pt == '.' or pt == '..':
            raise ValueError("unsafe segment")
