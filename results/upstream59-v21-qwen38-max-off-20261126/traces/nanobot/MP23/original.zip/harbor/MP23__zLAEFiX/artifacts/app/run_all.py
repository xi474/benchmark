#!/usr/bin/env python3
"""Run all components in dependency order."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def _python():
    """Find a working python3 executable."""
    if sys.executable:
        return sys.executable
    return shutil.which('python3') or 'python3'


def main():
    # Discover all contracts (excluding outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs
    # Each contract's inputs may reference outputs of other contracts
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = (cp, c)

    # Topological sort based on input dependencies
    resolved = set()
    order = []

    def resolve(name):
        if name in resolved:
            return
        cp, c = contract_map[name]
        for inp in c['inputs']:
            # Check if this input is an output of another component
            for other_cp in contracts:
                other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                if other_c['output'] == inp and other_c['name'] != name:
                    resolve(other_c['name'])
        resolved.add(name)
        order.append(name)

    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        resolve(c['name'])

    # Execute each component's render.py in order
    for name in order:
        cp, c = contract_map[name]
        render_py = cp.parent / 'render.py'
        if not render_py.exists():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [_python(), str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py to produce core_manifest.json
    integrate = ROOT / 'integrate.py'
    if integrate.exists():
        result = subprocess.run(
            [_python(), str(integrate)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / 'final_report.py'
    if final_report.exists():
        result = subprocess.run(
            [_python(), str(final_report)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
