#!/usr/bin/env python3
"""Wrapper to run check.py with sys.executable fixed."""
import shutil
import sys

# Fix sys.executable if empty
if not sys.executable:
    sys.executable = shutil.which('python3') or 'python3'

# Run check.py as __main__
import runpy
runpy.run_path('check.py', run_name='__main__')
