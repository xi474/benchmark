# Workflow 可观测性报告

- Trial：`MP24__4LMtYHE__env`
- Task：`MP24`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（84 节点 / 83 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：84；执行边：83（observed=0，inferred=83）
- Execution Trace Graph：`observed`；temporal_next 边 83，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_69cdedcf88ca4422aec9ffe5 -> tool:nanobot-harness-v3:call_4afd93b8530449fc8ac6b45d -> tool:nanobot-harness-v3:call_cfd27f36d79a4421bd9b3ef4 -> tool:nanobot-harness-v3:call_e6f42bfd65c94a3ebbd903a2 -> tool:nanobot-harness-v3:call_5e4aea6887454c93abb97290 -> tool:nanobot-harness-v3:call_7006419f98b1409984804184 -> tool:nanobot-harness-v3:call_1d49404f34b44556b86026cf -> tool:nanobot-harness-v3:call_5081b8c04cb349d3844c31fc -> tool:nanobot-harness-v3:call_a958613f70104543a31a0d16 -> tool:nanobot-harness-v3:call_470e3453ace440c8abd829a7 -> tool:nanobot-harness-v3:call_26c5fa9e7750457088aef4c3 -> tool:nanobot-harness-v3:call_8731d6c5dba34a058d906053 -> tool:nanobot-harness-v3:call_573cbce5f71246a29bf4d594 -> tool:nanobot-harness-v3:call_6c78a7cac5aa4693b1159a68 -> tool:nanobot-harness-v3:call_c0174d8e6a9341a099f255cc -> tool:nanobot-harness-v3:call_9b7783dc62c9404397d0de60 -> tool:nanobot-harness-v3:call_2065ace714ac404680d1d22e -> tool:nanobot-harness-v3:call_6ae82185835b42a7a7c02649 -> tool:nanobot-harness-v3:call_c5a86bffcef8472a8e516ffe -> tool:nanobot-harness-v3:call_3778f80b3e084f0aa46a6be5 -> tool:nanobot-harness-v3:call_4eef2163cfa6416db04a3273 -> tool:nanobot-harness-v3:call_2c90fcfb87e04c559ff5e262 -> tool:nanobot-harness-v3:call_73215950b9644387bcfcad29 -> tool:nanobot-harness-v3:call_35b5753d8dd047bebf63dfc6 -> tool:nanobot-harness-v3:call_5b69ba44f12448b4b639381a -> tool:nanobot-harness-v3:call_f4471ad0be484a7ba3fe04e2 -> tool:nanobot-harness-v3:call_02194e79710b4048b268079b -> tool:nanobot-harness-v3:call_188d08d569184a4aa002fee1 -> tool:nanobot-harness-v3:call_17a2a101f1d347c8ac87f50b -> tool:nanobot-harness-v3:call_19a8afe201374a0c94cff1f3 -> tool:nanobot-harness-v3:call_a2354b6fa2a04a459dc557d5 -> tool:nanobot-harness-v3:call_9eb94647a64449f29bfa87e3 -> tool:nanobot-harness-v3:call_b1612af3f50f440887684345 -> tool:nanobot-harness-v3:call_5a9ecedbb4f743dfb65e5146 -> tool:nanobot-harness-v3:call_e24cf3e090d04d28a2308f4c -> tool:nanobot-harness-v3:call_3130e90ee71a4da38fcc53f5 -> tool:nanobot-harness-v3:call_bbf2d351508746f796f93a1e -> tool:nanobot-harness-v3:call_c5121d750afa46d49e04f714 -> tool:nanobot-harness-v3:call_2af8809c9a11406aaaf8ccb4 -> tool:nanobot-harness-v3:call_0d46e284d51845cdbff6cf9e -> tool:nanobot-harness-v3:call_1e560c1a93284f30a7a01cc3 -> tool:nanobot-harness-v3:call_27e3fc5aa01648728155612c -> tool:nanobot-harness-v3:call_9f35bd5b198e4d5fa0c730ca -> tool:nanobot-harness-v3:call_1f4d27b5fab6460f88ff609f -> tool:nanobot-harness-v3:call_1c721424bbb34060aa78b63a -> tool:nanobot-harness-v3:call_eba38415f1b34a45b1a697ca -> tool:nanobot-harness-v3:call_44c59fe3f03548308eeed93a -> tool:nanobot-harness-v3:call_975a300472a648e4af20a43e -> tool:nanobot-harness-v3:call_b7ab6803aa5a4a509aa84607 -> tool:nanobot-harness-v3:call_4e371970fe544e648723a6d0 -> tool:nanobot-harness-v3:call_a2b36ee3623747fc921ed8cd -> tool:nanobot-harness-v3:call_04024d380efe4fd78b43a6be -> tool:nanobot-harness-v3:call_483522f3662a4db795c7a9cf -> tool:nanobot-harness-v3:call_9ef9eba250bf4ed0bec874b6 -> tool:nanobot-harness-v3:call_bc21ea6065e7459bbe562e41 -> tool:nanobot-harness-v3:call_60c2669e7692412db8ad3f21 -> tool:nanobot-harness-v3:call_d8f7ff0e25da499881033604 -> tool:nanobot-harness-v3:call_e6fd11c49f594d2589b5a304 -> tool:nanobot-harness-v3:call_e25a28a9410245cdb0fefb38 -> tool:nanobot-harness-v3:call_42a19657405a4d708ef873ce -> tool:nanobot-harness-v3:call_94644461ac95476fa5a3fc8f -> tool:nanobot-harness-v3:call_bea06e94ccb84d9e9f85a749 -> tool:nanobot-harness-v3:call_a2ed1d10246746c79ab01369 -> tool:nanobot-harness-v3:call_dbcafb5b3c17415c92974caa -> tool:nanobot-harness-v3:call_1211df9a6aba4b74b8e94b9b -> tool:nanobot-harness-v3:call_6f9fb7dd20a24e0694c05079 -> tool:nanobot-harness-v3:call_344c340b43ad4e9ea729e096 -> tool:nanobot-harness-v3:call_7a9e4a3af6644dcaa1f90a35 -> tool:nanobot-harness-v3:call_c3aef53310934d508b925713 -> tool:nanobot-harness-v3:call_0ae957cc4d0e4129b77957fa -> tool:nanobot-harness-v3:call_3ad20778bae145dca13cbea4 -> tool:nanobot-harness-v3:call_c150ad521766430db64bd19f -> tool:nanobot-harness-v3:call_9cc38266b4594640805a75f5 -> tool:nanobot-harness-v3:call_8f94395ff9a24d82b85dc2ea -> tool:nanobot-harness-v3:call_a1c869e3d67c4697a07cde52 -> tool:nanobot-harness-v3:call_511a8172779f415da31ac262 -> tool:nanobot-harness-v3:call_1f8252e1ab97449aa22e73b5 -> tool:nanobot-harness-v3:call_6a648efb25f342ab84362de8 -> tool:nanobot-harness-v3:call_c9053804c65b4d4fa83dd332 -> tool:nanobot-harness-v3:call_f6d815c1ae0a409d89e6305b -> tool:nanobot-harness-v3:call_fcc0fdf65a294866a9205c3d -> tool:nanobot-harness-v3:call_5073555d4f6f4ceb8c790cbc -> tool:nanobot-harness-v3:call_f2bb5980f4d04e738ac31228
- 关键路径耗时：1.025881
- Makespan：454.743958
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
