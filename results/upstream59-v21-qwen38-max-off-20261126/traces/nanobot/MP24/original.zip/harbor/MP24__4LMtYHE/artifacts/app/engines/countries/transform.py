def transform(payloads, contract):
    """employment_countries: for each professor, list all employment countries.

    Input: single payload = {departments, professors, students, as_of, eu}
    Output: {"name": "countries", "result": {"countries": {prof_id: [sorted unique countries]}}}
    Returns ALL countries of employment, not just EU ones.
    Professor with no departments gets empty list.
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    for field in ('departments', 'professors'):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    departments = case['departments']
    professors = case['professors']

    # Build department -> country map
    dept_country = {}
    for d in departments:
        if 'id' not in d or 'country' not in d:
            raise ValueError("department missing id or country")
        dept_country[d['id']] = d['country']

    # For each professor, collect all unique countries
    result_countries = {}
    for prof in professors:
        if 'id' not in prof or 'departments' not in prof:
            raise ValueError("professor missing id or departments")
        prof_depts = set(prof['departments'])  # deduplicate
        countries = set()
        for dept_id in prof_depts:
            if dept_id not in dept_country:
                raise ValueError(f"department {dept_id} not found")
            countries.add(dept_country[dept_id])
        result_countries[prof['id']] = sorted(countries)

    return {"name": contract['name'], "result": {"countries": result_countries}}
