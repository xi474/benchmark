import json
import sys
from pathlib import Path

# Add parent dir to path so we can import sibling modules
sys.path.insert(0, str(Path(__file__).resolve().parent))

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    """Read inputs per contract, run transform, write output, return result."""
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)

    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)

    # Write output
    out_path = root / contract['output']
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )

    return result


if __name__ == "__main__":
    # Determine workspace root: go up from this script's directory to find the workspace
    # The script is at engines/<component>/render.py, so root is two levels up
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parents[1]
    contract_path = script_dir / 'contract.json'
    build_component(root, contract_path)
