def transform(payloads, contract):
    """eu_professors: find professors with at least one department in EU countries.

    Input: single payload = {departments, professors, students, as_of, eu}
    Output: {"name": "eu", "result": {"ids": [sorted professor IDs]}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    # Validate required fields
    for field in ('departments', 'professors', 'eu'):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    departments = case['departments']
    professors = case['professors']
    eu_countries = set(case['eu'])

    # Build department -> country map
    dept_country = {}
    for d in departments:
        if 'id' not in d or 'country' not in d:
            raise ValueError("department missing id or country")
        dept_country[d['id']] = d['country']

    # Find EU-eligible professors
    eligible_ids = []
    for prof in professors:
        if 'id' not in prof or 'departments' not in prof:
            raise ValueError("professor missing id or departments")
        prof_depts = set(prof['departments'])  # deduplicate
        # Check if at least one department is in EU
        for dept_id in prof_depts:
            if dept_id not in dept_country:
                raise ValueError(f"department {dept_id} not found")
            if dept_country[dept_id] in eu_countries:
                eligible_ids.append(prof['id'])
                break

    eligible_ids.sort()

    return {"name": contract['name'], "result": {"ids": eligible_ids}}
