def transform(payloads, contract):
    """university_query: find EU-eligible professors with at least one dept having >10 students.

    Inputs (in order per contract):
      0: original case.json {departments, professors, students, as_of, eu}
      1: eu.json result {"ids": [...]}
      2: students.json result {"counts": {dept_id: count}}
      3: countries.json result {"countries": {prof_id: [countries]}}

    Output: {"name": "query", "result": {"professors": [
        {"id": ..., "countries": [...], "eligible_departments": [...]},
        ...sorted by id
    ]}}

    A professor qualifies if:
      - They are in the EU-eligible list (eu.json)
      - At least one of their individual departments has student count > 10
    The eligible_departments are those with count > 10 (can differ from EU-qualifying dept).
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]
    eu_result = payloads[1]
    students_result = payloads[2]
    countries_result = payloads[3]

    # Handle name/result wrapping: when input object keys are exactly name/result,
    # only result is the business input
    if isinstance(eu_result, dict) and set(eu_result.keys()) == {'name', 'result'}:
        eu_data = eu_result['result']
    else:
        eu_data = eu_result

    if isinstance(students_result, dict) and set(students_result.keys()) == {'name', 'result'}:
        students_data = students_result['result']
    else:
        students_data = students_result

    if isinstance(countries_result, dict) and set(countries_result.keys()) == {'name', 'result'}:
        countries_data = countries_result['result']
    else:
        countries_data = countries_result

    eu_ids = set(eu_data['ids'])
    dept_counts = students_data['counts']
    prof_countries = countries_data['countries']

    # Get professor department info from original case
    professors = case['professors']

    result_professors = []
    for prof in professors:
        pid = prof['id']
        if pid not in eu_ids:
            continue

        # Check which departments have > 10 students
        prof_depts = set(prof['departments'])
        eligible_depts = sorted([d for d in prof_depts if dept_counts.get(d, 0) > 10])

        if not eligible_depts:
            continue

        result_professors.append({
            "id": pid,
            "countries": prof_countries.get(pid, []),
            "eligible_departments": eligible_depts
        })

    # Sort by id
    result_professors.sort(key=lambda x: x['id'])

    return {"name": contract['name'], "result": {"professors": result_professors}}
