def transform(payloads, contract):
    """department_students: count active students per department.

    Input: single payload = {departments, professors, students, as_of, eu}
    Active enrolment: start <= as_of AND (end is null OR as_of < end).
    If end is not null, must have end > start.
    Per department, count DISTINCT student IDs.
    Output: {"name": "students", "result": {"counts": {dept_id: count}}}
    """
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    case = payloads[0]

    for field in ('departments', 'students', 'as_of'):
        if field not in case:
            raise ValueError(f"missing field: {field}")

    departments = case['departments']
    students = case['students']
    as_of = case['as_of']

    # Collect all department IDs
    dept_ids = set()
    for d in departments:
        if 'id' not in d:
            raise ValueError("department missing id")
        dept_ids.add(d['id'])

    # Count active students per department
    # dept -> set of student IDs
    dept_students = {d_id: set() for d_id in dept_ids}

    for student in students:
        if 'id' not in student or 'enrolments' not in student:
            raise ValueError("student missing id or enrolments")
        sid = student['id']
        for enr in student['enrolments']:
            if 'department' not in enr or 'start' not in enr:
                raise ValueError("enrolment missing department or start")
            dept_id = enr['department']
            start = enr['start']
            end = enr.get('end')  # may be null/None

            # Validate: if end is not null, end > start
            if end is not None and end <= start:
                raise ValueError(f"end must be > start for student {sid}")

            # Check active: start <= as_of AND (end is null OR as_of < end)
            if start <= as_of and (end is None or as_of < end):
                if dept_id in dept_students:
                    dept_students[dept_id].add(sid)

    counts = {d_id: len(sids) for d_id, sids in dept_students.items()}

    return {"name": contract['name'], "result": {"counts": counts}}
