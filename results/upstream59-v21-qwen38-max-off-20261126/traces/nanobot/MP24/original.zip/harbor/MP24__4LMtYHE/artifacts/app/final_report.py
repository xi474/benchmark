"""Generate final_report.json from core_manifest.json.

Fields:
  title: '大学任职、在读人数与国家集合查询'
  component_count: number of components in core
  sha256: SHA-256 hex of the compact JSON serialization of the full core object
  attention: sorted list of component names with issues
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    # Compute SHA-256 of compact JSON (no trailing newline)
    compact = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256_hex = hashlib.sha256(compact).hexdigest()

    # Determine attention list
    attention = set()
    components = core.get('components', {})
    for comp_name, comp_result in components.items():
        if not isinstance(comp_result, dict):
            continue

        # result.blocked explicitly true
        if comp_result.get('blocked') is True:
            attention.add(comp_name)

        # complete/checkout/committed/ok explicitly false
        for flag in ('complete', 'checkout', 'committed', 'ok'):
            if flag in comp_result and comp_result[flag] is False:
                attention.add(comp_name)

        # unavailable/missing/conflicts/unreachable non-empty
        for field in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = comp_result.get(field)
            if val is not None and val != [] and val != {} and val != '' and val != 0:
                # Non-empty check: list/dict/string with content, or truthy value
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, (int, float)) and val != 0:
                    attention.add(comp_name)
                elif isinstance(val, bool) and val:
                    attention.add(comp_name)

    report = {
        "title": "大学任职、在读人数与国家集合查询",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": sorted(attention)
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
