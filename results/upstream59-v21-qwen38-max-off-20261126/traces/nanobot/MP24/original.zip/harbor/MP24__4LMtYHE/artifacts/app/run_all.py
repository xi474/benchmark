"""Orchestrate all components based on contract.json files.

Discovers all contract.json files, resolves dependencies from input paths,
and executes components in topological order. Each component is run as a
subprocess: python3 <component_dir>/render.py
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def get_python():
    """Get the Python interpreter path."""
    import shutil
    exe = sys.executable
    if exe and Path(exe).is_file():
        return exe
    # Fallback: find python3 on PATH
    found = shutil.which('python3')
    if found:
        return found
    found = shutil.which('python')
    if found:
        return found
    raise RuntimeError("Cannot find Python interpreter")


PYTHON = get_python()


def discover_contracts():
    """Find all contract.json files not under outputs/."""
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    return contracts


def load_contract(path):
    """Load a contract JSON file."""
    return json.loads(path.read_text(encoding='utf-8'))


def resolve_order(contracts):
    """Topological sort of components based on input dependencies.

    A component depends on another if any of its inputs references an output
    produced by that other component.
    """
    # Map output path -> contract path
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        c = load_contract(cp)
        contract_info[cp] = c
        output_to_contract[c['output']] = cp

    # Build dependency graph
    deps = {}  # cp -> set of cp it depends on
    for cp in contracts:
        c = contract_info[cp]
        dep_set = set()
        for inp in c['inputs']:
            if inp in output_to_contract:
                dep_set.add(output_to_contract[inp])
        deps[cp] = dep_set

    # Topological sort (Kahn's algorithm)
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    queue.sort()  # deterministic order
    order = []

    while queue:
        cp = queue.pop(0)
        order.append(cp)
        for other in contracts:
            if cp in deps[other]:
                deps[other].discard(cp)
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)
        queue.sort()

    if len(order) != len(contracts):
        raise ValueError("dependency cycle detected")

    return order


def main():
    contracts = discover_contracts()
    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    order = resolve_order(contracts)

    for cp in order:
        render_script = cp.with_name('render.py')
        if not render_script.exists():
            print(f"Missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)

        result = subprocess.run(
            [PYTHON, str(render_script)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {cp} failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run integrate.py to produce core_manifest.json
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.exists():
        result = subprocess.run(
            [PYTHON, str(integrate_script)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"integrate.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.exists():
        result = subprocess.run(
            [PYTHON, str(report_script)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"final_report.py failed with exit code {result.returncode}", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == '__main__':
    main()
