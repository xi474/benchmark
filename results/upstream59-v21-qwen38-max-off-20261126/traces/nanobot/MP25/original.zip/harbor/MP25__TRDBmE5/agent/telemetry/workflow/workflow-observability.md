# Workflow 可观测性报告

- Trial：`MP25__TRDBmE5__env`
- Task：`MP25`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（67 节点 / 66 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：67；执行边：66（observed=0，inferred=66）
- Execution Trace Graph：`observed`；temporal_next 边 66，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_bbc6ebdb05744e56910b6327 -> tool:nanobot-harness-v3:call_4586aef5d57a49b9be2a1ece -> tool:nanobot-harness-v3:call_c1c55d4ea7b64b24836bbbcb -> tool:nanobot-harness-v3:call_ad753491bbab4665beab8eb9 -> tool:nanobot-harness-v3:call_02a9d186a4594a0a9b57788a -> tool:nanobot-harness-v3:call_6f794b69c2ab43d98350ab22 -> tool:nanobot-harness-v3:call_bab3a407add84eea8d26936c -> tool:nanobot-harness-v3:call_6686fadbadd945068c0e4e8e -> tool:nanobot-harness-v3:call_d486fc1ce0c648c69793993f -> tool:nanobot-harness-v3:call_2d36f8fed75d4379a232fe06 -> tool:nanobot-harness-v3:call_279d805f4d5141ad96998c5e -> tool:nanobot-harness-v3:call_d477e69ec94d48739d4374ab -> tool:nanobot-harness-v3:call_54dbceccfb7e4f379c7b1a55 -> tool:nanobot-harness-v3:call_234aeeead31b41919e39c6a6 -> tool:nanobot-harness-v3:call_9d5f053266424faf9ee6e9cd -> tool:nanobot-harness-v3:call_c4f8207a1fde41b09b47c924 -> tool:nanobot-harness-v3:call_5c55338d77214ac1a7f625b1 -> tool:nanobot-harness-v3:call_d768c377ee0841b39a39a3ec -> tool:nanobot-harness-v3:call_a87907df0ec9495f95960620 -> tool:nanobot-harness-v3:call_ba3f6b0d720b4a9fafaf7a55 -> tool:nanobot-harness-v3:call_f82915ea3c98477c92319a59 -> tool:nanobot-harness-v3:call_82bf2f899b9c4da2b6e0e3d3 -> tool:nanobot-harness-v3:call_2fede80249d24323bde98b47 -> tool:nanobot-harness-v3:call_4a4b9572088b42749467aec1 -> tool:nanobot-harness-v3:call_b7f199f104da4a7f9705f6f4 -> tool:nanobot-harness-v3:call_8235c6f56eb54825aac97ff2 -> tool:nanobot-harness-v3:call_645c5090551749a5a9a4407d -> tool:nanobot-harness-v3:call_6a70cc9e003744c48342197a -> tool:nanobot-harness-v3:call_a5c22076384843278d2d81fa -> tool:nanobot-harness-v3:call_01e01d7483d84cf3bd60988e -> tool:nanobot-harness-v3:call_4cb433f9707041d593bfa6ab -> tool:nanobot-harness-v3:call_74efe42956794ffea7cd7026 -> tool:nanobot-harness-v3:call_85b64fe209c442719561b655 -> tool:nanobot-harness-v3:call_d986fe5b08b74d7790fdeced -> tool:nanobot-harness-v3:call_293878df31e446d989c1d23b -> tool:nanobot-harness-v3:call_eef151815dd943f6a788c564 -> tool:nanobot-harness-v3:call_9cf2f7e5b68241ea8871056e -> tool:nanobot-harness-v3:call_0c98f4b8d2544229874091ea -> tool:nanobot-harness-v3:call_bd0871e5328c483cb8a0f3b2 -> tool:nanobot-harness-v3:call_48bef78206c148ae9e5d956b -> tool:nanobot-harness-v3:call_0fc9abb83ab849cbb27a8b5a -> tool:nanobot-harness-v3:call_93542785a05243e4bd732143 -> tool:nanobot-harness-v3:call_1f073ce7399f4fe6b102ba78 -> tool:nanobot-harness-v3:call_005fa98ee22a4570b9072ae4 -> tool:nanobot-harness-v3:call_e47ff6de2ec246038cc93825 -> tool:nanobot-harness-v3:call_e62951b9da4944248bfc9bda -> tool:nanobot-harness-v3:call_f1364d04dedb4820869e04cd -> tool:nanobot-harness-v3:call_fa00f86711e94472a76f77c9 -> tool:nanobot-harness-v3:call_d2386d76185c466494eb3df4 -> tool:nanobot-harness-v3:call_b6e190f8110b42c7b7e16d18 -> tool:nanobot-harness-v3:call_fd79234d0fff482a8d6ae22b -> tool:nanobot-harness-v3:call_fb0b9526fe2442a991d5f58f -> tool:nanobot-harness-v3:call_6379e6f9bb9845319c71f9fb -> tool:nanobot-harness-v3:call_7e46a820bb68456f96007b61 -> tool:nanobot-harness-v3:call_310adc44ef054ff29bfcb0c7 -> tool:nanobot-harness-v3:call_0cfee71846ee4b74b01d7777 -> tool:nanobot-harness-v3:call_32b12d51cf2946659088b8e8 -> tool:nanobot-harness-v3:call_a68aeefb3e5247019a54ee0a -> tool:nanobot-harness-v3:call_fbf70a263b7447a8a3cd1349 -> tool:nanobot-harness-v3:call_c5da6c123060492cb6e82eaf -> tool:nanobot-harness-v3:call_bda3908dba154e4e947a0f20 -> tool:nanobot-harness-v3:call_d1bcca5cb26549eaae88a3be -> tool:nanobot-harness-v3:call_36be5b294a474d4ebc79fd7e -> tool:nanobot-harness-v3:call_7aa9e6130387484db80a8c48 -> tool:nanobot-harness-v3:call_93a2ef73a8db46b68ad656ba -> tool:nanobot-harness-v3:call_fa15f2154533431c8824fa95
- 关键路径耗时：0.855249
- Makespan：279.043546
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
