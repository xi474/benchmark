import re


def _parse_amount(s):
    """Parse a monetary amount string. Returns string with 2 decimals or raises ValueError."""
    s = s.strip()
    # Optional USD prefix
    if s.upper().startswith('USD'):
        s = s[3:].strip()
    # Remove thousands separators (commas)
    # Validate format: optional digits with commas, then dot and exactly 2 decimals
    # Pattern: optional comma-separated integer part, mandatory .XX
    m = re.match(r'^(\d{1,3}(?:,\d{3})*|\d+)\.\d{2}$', s)
    if not m:
        raise ValueError(f"Invalid amount format: {s}")
    # Check non-negative (no minus sign allowed by pattern above)
    # Return normalized two-decimal string
    numeric = s.replace(',', '')
    # Verify it's a valid non-negative number
    val = float(numeric)
    if val < 0:
        raise ValueError(f"Negative amount: {s}")
    # Return as two-decimal string
    parts = numeric.split('.')
    return f"{parts[0]}.{parts[1]}"


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    docs_payload = payloads[0]
    if not isinstance(docs_payload, dict) or 'documents' not in docs_payload:
        raise ValueError("Missing documents field")
    documents = docs_payload['documents']
    if not isinstance(documents, list):
        raise ValueError("documents must be a list")
    seen_ids = set()
    amounts = {}
    for doc in documents:
        if not isinstance(doc, dict):
            raise ValueError("Each document must be an object")
        for key in ('id', 'filename', 'text'):
            if key not in doc:
                raise ValueError(f"Missing field: {key}")
        did = doc['id']
        if not isinstance(did, str):
            raise ValueError("id must be string")
        if did in seen_ids:
            raise ValueError(f"Duplicate id: {did}")
        seen_ids.add(did)
        text = doc['text']
        total_val = None
        vat_val = None
        has_total = False
        has_amount_due = False
        has_vat = False
        for line in text.split('\n'):
            stripped = line.strip()
            lower = stripped.lower()
            # Match "Total: <amount>"
            m = re.match(r'^total\s*:\s*(.+)$', lower)
            if m:
                if has_total:
                    raise ValueError(f"Duplicate Total for {did}")
                raw_amount = stripped[len('total'):].lstrip(':').strip()
                # Extract from original case line
                orig_m = re.match(r'^[Tt][Oo][Tt][Aa][Ll]\s*:\s*(.+)$', stripped)
                if orig_m:
                    raw_amount = orig_m.group(1).strip()
                try:
                    total_val = _parse_amount(raw_amount)
                except ValueError:
                    raise ValueError(f"Invalid Total amount for {did}: {raw_amount}")
                has_total = True
                continue
            # Match "Amount Due: <amount>"
            m = re.match(r'^amount\s+due\s*:\s*(.+)$', lower)
            if m:
                if has_amount_due:
                    raise ValueError(f"Duplicate Amount Due for {did}")
                orig_m = re.match(r'^[Aa][Mm][Oo][Uu][Nn][Tt]\s+[Dd][Uu][Ee]\s*:\s*(.+)$', stripped)
                if orig_m:
                    raw_amount = orig_m.group(1).strip()
                else:
                    raw_amount = m.group(1).strip()
                try:
                    ad_val = _parse_amount(raw_amount)
                except ValueError:
                    raise ValueError(f"Invalid Amount Due for {did}: {raw_amount}")
                if not has_total:
                    total_val = ad_val
                has_amount_due = True
                continue
            # Match "VAT: <amount>"
            m = re.match(r'^vat\s*:\s*(.+)$', lower)
            if m:
                if has_vat:
                    raise ValueError(f"Duplicate VAT for {did}")
                orig_m = re.match(r'^[Vv][Aa][Tt]\s*:\s*(.+)$', stripped)
                if orig_m:
                    raw_amount = orig_m.group(1).strip()
                else:
                    raw_amount = m.group(1).strip()
                try:
                    vat_val = _parse_amount(raw_amount)
                except ValueError:
                    raise ValueError(f"Invalid VAT for {did}: {raw_amount}")
                has_vat = True
                continue
        amounts[did] = {
            'total': total_val,
            'vat': vat_val if vat_val is not None else '0.00'
        }
    return {'name': contract['name'], 'result': {'amounts': amounts}}
