import re


def _classify_doc(text):
    """Classify a document by case-insensitive whole-word matching."""
    words = set(re.findall(r'[A-Za-z]+', text))
    words_lower = {w.lower() for w in words}
    if 'invoice' in words_lower:
        return 'invoice'
    elif 'receipt' in words_lower:
        return 'receipt'
    else:
        return 'other'


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    docs_payload = payloads[0]
    if not isinstance(docs_payload, dict) or 'documents' not in docs_payload:
        raise ValueError("Missing documents field")
    documents = docs_payload['documents']
    if not isinstance(documents, list):
        raise ValueError("documents must be a list")
    seen_ids = set()
    classes = {}
    for doc in documents:
        if not isinstance(doc, dict):
            raise ValueError("Each document must be an object")
        for key in ('id', 'filename', 'text'):
            if key not in doc:
                raise ValueError(f"Missing field: {key}")
        did = doc['id']
        if not isinstance(did, str):
            raise ValueError("id must be string")
        if did in seen_ids:
            raise ValueError(f"Duplicate id: {did}")
        seen_ids.add(did)
        if not isinstance(doc['filename'], str):
            raise ValueError("filename must be string")
        if not isinstance(doc['text'], str):
            raise ValueError("text must be string")
        classes[did] = _classify_doc(doc['text'])
    return {'name': contract['name'], 'result': {'classes': classes}}
