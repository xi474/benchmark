import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core.get('components', {})
    component_count = len(components)

    # SHA256 of the complete core object
    serialized = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    # Attention: components with specific conditions
    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        # result.blocked explicitly true
        if result.get('blocked') is True:
            attention.add(comp_name)
        # complete/checkout/committed/ok explicitly false
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(comp_name)
        # unavailable/missing/conflicts/unreachable non-empty
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != '' and val != {} and val != 0 and val is not False:
                # Non-empty check: list/dict/string must be non-empty; other truthy values count
                if isinstance(val, (list, dict, str)):
                    if len(val) > 0:
                        attention.add(comp_name)
                elif val is not None and val is not False and val != 0:
                    attention.add(comp_name)

    attention_list = sorted(attention)

    report = {
        'title': '\u6587\u672c\u7968\u636e\u5206\u7c7b\u3001\u91d1\u989d\u63d0\u53d6\u4e0e\u5f52\u6863\u6c47\u603b',
        'component_count': component_count,
        'sha256': sha256,
        'attention': attention_list
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
