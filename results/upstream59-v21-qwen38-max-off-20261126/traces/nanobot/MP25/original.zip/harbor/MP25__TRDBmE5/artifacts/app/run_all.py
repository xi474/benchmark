import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# Find python3 executable reliably
PYTHON = sys.executable if sys.executable else shutil.which('python3') or 'python3'


def main():
    # Find all contract.json files (not in outputs/)
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("No contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph: parse each contract to find inputs that are outputs of other components
    # We need topological ordering
    comp_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        output = c['output']
        inputs = c['inputs']
        comp_info[name] = {
            'contract_path': cp,
            'output': output,
            'inputs': inputs,
            'render_py': cp.with_name('render.py')
        }

    # Topological sort based on dependencies
    # A component depends on another if any of its inputs matches another's output
    output_to_name = {}
    for name, info in comp_info.items():
        output_to_name[info['output']] = name

    deps = {}
    for name, info in comp_info.items():
        dep_names = set()
        for inp in info['inputs']:
            if inp in output_to_name:
                dep_names.add(output_to_name[inp])
        deps[name] = dep_names

    # Kahn's algorithm
    in_degree = {n: 0 for n in comp_info}
    for n, d in deps.items():
        for dep in d:
            in_degree[n] += 0  # ensure exists
    # Recount
    in_degree = {n: 0 for n in comp_info}
    reverse_deps = {n: set() for n in comp_info}
    for n, d in deps.items():
        for dep in d:
            reverse_deps[dep].add(n)
            in_degree[n] += 1

    queue = sorted([n for n, deg in in_degree.items() if deg == 0])
    order = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for dependent in sorted(reverse_deps[node]):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)
        queue.sort()

    if len(order) != len(comp_info):
        print("Circular dependency detected", file=sys.stderr)
        sys.exit(1)

    # Execute each component in order via its render.py
    for name in order:
        info = comp_info[name]
        render_script = info['render_py']
        if not render_script.is_file():
            print(f"Missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {name} failed with code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate_script = ROOT / 'integrate.py'
    if integrate_script.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    report_script = ROOT / 'final_report.py'
    if report_script.is_file():
        result = subprocess.run(
            [PYTHON, str(report_script)],
            cwd=str(ROOT),
            timeout=60
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
