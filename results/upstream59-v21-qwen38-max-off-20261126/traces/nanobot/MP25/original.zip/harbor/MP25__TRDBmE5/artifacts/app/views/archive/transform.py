import csv
import io


def _is_safe_path_segment(s):
    """Check if s is a safe single path segment."""
    if not s or not isinstance(s, str):
        return False
    if '/' in s or '\\' in s or ':' in s:
        return False
    if s in ('.', '..'):
        return False
    if not s.strip():
        return False
    return True


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("Payload count mismatch")
    docs_payload = payloads[0]
    class_result = payloads[1]
    amounts_result = payloads[2]
    # Extract business data: when input object has keys name/result, use result
    if isinstance(class_result, dict) and set(class_result.keys()) >= {'name', 'result'}:
        class_data = class_result['result']
    else:
        class_data = class_result
    if isinstance(amounts_result, dict) and set(amounts_result.keys()) >= {'name', 'result'}:
        amounts_data = amounts_result['result']
    else:
        amounts_data = amounts_result
    if not isinstance(docs_payload, dict) or 'documents' not in docs_payload:
        raise ValueError("Missing documents field")
    documents = docs_payload['documents']
    classes = class_data.get('classes', {})
    amounts = amounts_data.get('amounts', {})
    archives = []
    rows = []
    for doc in documents:
        did = doc['id']
        filename = doc['filename']
        text = doc['text']
        kind = classes.get(did, 'other')
        amt = amounts.get(did, {})
        total = amt.get('total')
        vat = amt.get('vat', '0.00')
        # Validate: invoice/receipt must have total
        if kind in ('invoice', 'receipt') and total is None:
            raise ValueError(f"{kind} document {did} missing total")
        # id must be safe path segment
        if not _is_safe_path_segment(did):
            raise ValueError(f"Unsafe id as path segment: {did}")
        # Build archive path: classified/<kind>/<id>/<filename>
        archive_path = f"classified/{kind}/{did}/{filename}"
        # hex of UTF-8 bytes of text
        text_hex = text.encode('utf-8').hex()
        archives.append({'path': archive_path, 'hex': text_hex})
        rows.append({
            'id': did,
            'filename': filename,
            'kind': kind,
            'total': total,
            'vat': vat
        })
    # Sort archives by path
    archives.sort(key=lambda x: x['path'])
    # Sort rows by id
    rows.sort(key=lambda x: x['id'])
    # Generate CSV
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator='\n')
    writer.writerow(['id', 'filename', 'kind', 'total', 'vat'])
    for row in rows:
        writer.writerow([
            row['id'],
            row['filename'],
            row['kind'],
            row['total'] if row['total'] is not None else '',
            row['vat']
        ])
    csv_str = buf.getvalue()
    # Compute totals: sum of total for invoice and receipt separately
    invoice_total = 0
    receipt_total = 0
    for row in rows:
        if row['total'] is not None:
            val = int(row['total'].replace('.', ''))  # cents
            if row['kind'] == 'invoice':
                invoice_total += val
            elif row['kind'] == 'receipt':
                receipt_total += val
    def cents_to_str(c):
        sign = ''
        if c < 0:
            sign = '-'
            c = -c
        return f"{sign}{c // 100}.{c % 100:02d}"
    totals = {
        'invoice': cents_to_str(invoice_total),
        'receipt': cents_to_str(receipt_total)
    }
    return {
        'name': contract['name'],
        'result': {
            'archives': archives,
            'rows': rows,
            'csv': csv_str,
            'totals': totals
        }
    }
