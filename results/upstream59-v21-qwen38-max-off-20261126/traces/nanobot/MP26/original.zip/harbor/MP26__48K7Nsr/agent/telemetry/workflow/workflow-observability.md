# Workflow 可观测性报告

- Trial：`MP26__48K7Nsr__env`
- Task：`MP26`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（96 节点 / 95 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：96；执行边：95（observed=0，inferred=95）
- Execution Trace Graph：`observed`；temporal_next 边 95，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_8a17ad025433474d953557df -> tool:nanobot-harness-v3:call_3586c68decc84f878c52ec7f -> tool:nanobot-harness-v3:call_5e4440dd09144dd296ae0fe8 -> tool:nanobot-harness-v3:call_761c822199f1425bb45bf29f -> tool:nanobot-harness-v3:call_2288ff6cb3974e26ba107981 -> tool:nanobot-harness-v3:call_f0d4175d29e04d90905680af -> tool:nanobot-harness-v3:call_1726b894193c4a3182d604aa -> tool:nanobot-harness-v3:call_9b1ba0f0197048e9ad608eac -> tool:nanobot-harness-v3:call_64516cacfa0d4c2994d8caf0 -> tool:nanobot-harness-v3:call_dccead77947b44549bb731d7 -> tool:nanobot-harness-v3:call_3f07d82428624dee8a581360 -> tool:nanobot-harness-v3:call_630a13086b3c4f39a06f41ce -> tool:nanobot-harness-v3:call_95e6fbdca11946dba9fdf7a9 -> tool:nanobot-harness-v3:call_a7ee57c95cc74acba9ec6dcc -> tool:nanobot-harness-v3:call_fbd7f3f8af734fe4b82188ef -> tool:nanobot-harness-v3:call_9af5430860ce40e094db7cc8 -> tool:nanobot-harness-v3:call_e5f7849b0fbf4d1c9ee757fe -> tool:nanobot-harness-v3:call_68b3dcfdc13243c887533918 -> tool:nanobot-harness-v3:call_24c7e6fea638481f9dbc879c -> tool:nanobot-harness-v3:call_0c3ec91068b640d6b3cf0799 -> tool:nanobot-harness-v3:call_38d71a5d471e45a6945bae75 -> tool:nanobot-harness-v3:call_c6be52d366614fc4a0ad0238 -> tool:nanobot-harness-v3:call_1ccab36c54cc4bfebca7f476 -> tool:nanobot-harness-v3:call_5e74dfdb790844bcbb4adcbf -> tool:nanobot-harness-v3:call_fbebb8ccc5754e49bb59b92b -> tool:nanobot-harness-v3:call_4eb53cd6085544bf9829b88f -> tool:nanobot-harness-v3:call_b1f1de4bf72a4f03a91e9423 -> tool:nanobot-harness-v3:call_3f59d57b6c24435d9964e24e -> tool:nanobot-harness-v3:call_67f502d4f55048e6820f08ca -> tool:nanobot-harness-v3:call_5b8522d0742545fc9d2796d0 -> tool:nanobot-harness-v3:call_f4378eef512e4d15ba458013 -> tool:nanobot-harness-v3:call_0d1b5cc122a64ca4ac58a4bb -> tool:nanobot-harness-v3:call_fabe19a6289744ac85cfb081 -> tool:nanobot-harness-v3:call_71323568679f4a58a2cf7440 -> tool:nanobot-harness-v3:call_94e58593c35544818f0b94a3 -> tool:nanobot-harness-v3:call_4868c533eab047ff985dd9e4 -> tool:nanobot-harness-v3:call_962b8a20ec2b4ca8b0207309 -> tool:nanobot-harness-v3:call_409494259c39483aaf4d7204 -> tool:nanobot-harness-v3:call_ad99519da0f943d18479c392 -> tool:nanobot-harness-v3:call_f8e12c2fd8fc4806a22c5000 -> tool:nanobot-harness-v3:call_169ba57d023540d29bd57ae7 -> tool:nanobot-harness-v3:call_134c0149d3a74f96b8169c95 -> tool:nanobot-harness-v3:call_37b397090bbf4b219fdc913f -> tool:nanobot-harness-v3:call_b0e4feb37a4c46ed928e4c69 -> tool:nanobot-harness-v3:call_652d0978f29c42c7aa9fbb7a -> tool:nanobot-harness-v3:call_9bb5a62a1f13445390859121 -> tool:nanobot-harness-v3:call_c660dbaf507a445fb2441659 -> tool:nanobot-harness-v3:call_b2c8cf221add4c9ab6e5ad49 -> tool:nanobot-harness-v3:call_cedd5cf68b684cffa3117ab8 -> tool:nanobot-harness-v3:call_4a9d01dfece04084911da3cd -> tool:nanobot-harness-v3:call_2506119992cc49238d29bb15 -> tool:nanobot-harness-v3:call_96cc4f4575eb4c5988cc2944 -> tool:nanobot-harness-v3:call_ab39aa06468445638f089781 -> tool:nanobot-harness-v3:call_47cfc8b5c7b74f6e833691f5 -> tool:nanobot-harness-v3:call_75fa557e0fa64e59b8be0e62 -> tool:nanobot-harness-v3:call_b8511567a84345c585420149 -> tool:nanobot-harness-v3:call_6b08aec8756c4c43bda4c0fb -> tool:nanobot-harness-v3:call_9fe90bf2e05048798a8b9b7d -> tool:nanobot-harness-v3:call_33506dd85bbd4e8687cef45c -> tool:nanobot-harness-v3:call_54dfa014096b4b59b6e92f2a -> tool:nanobot-harness-v3:call_f855feb519e04126ad85865b -> tool:nanobot-harness-v3:call_fa0666f4226f40f19a7592c8 -> tool:nanobot-harness-v3:call_156bfa372957454c90aa8cba -> tool:nanobot-harness-v3:call_9101ebd73e084efe82209acc -> tool:nanobot-harness-v3:call_fd9793e8fa30428eb351b426 -> tool:nanobot-harness-v3:call_77de430919e643ce889c8e32 -> tool:nanobot-harness-v3:call_8cd3cded59cc4cce9df1c82b -> tool:nanobot-harness-v3:call_089ff98eee0748b280afe2ed -> tool:nanobot-harness-v3:call_2f43f8ba3ce34da7bcf56187 -> tool:nanobot-harness-v3:call_8f3ec510951047918c31398a -> tool:nanobot-harness-v3:call_9fb6e0a6ffbd413eb95b179e -> tool:nanobot-harness-v3:call_fc8883677b17497c9b97618c -> tool:nanobot-harness-v3:call_4d33c4e6d37b40d983437882 -> tool:nanobot-harness-v3:call_d9188402a47b455ab55e022a -> tool:nanobot-harness-v3:call_55069c8dc7cc46608d180b24 -> tool:nanobot-harness-v3:call_5f4dc47bd6f449a7ae93ae7e -> tool:nanobot-harness-v3:call_4ef3ef20039d429aa7a578a0 -> tool:nanobot-harness-v3:call_51cf74b172ec4e7b95315cc8 -> tool:nanobot-harness-v3:call_ad3045ef6e8f499c93d9cf80 -> tool:nanobot-harness-v3:call_212261c50e25422389b46832 -> tool:nanobot-harness-v3:call_a9b422c81f8e42f99d35d22b -> tool:nanobot-harness-v3:call_8a8dd8b74d3c4f18a5cf6146 -> tool:nanobot-harness-v3:call_5ab315d738204545ae3b93f7 -> tool:nanobot-harness-v3:call_dbbc1b8c70a8445da6920a99 -> tool:nanobot-harness-v3:call_05e5344229454b7d82ef9729 -> tool:nanobot-harness-v3:call_a835611a0cc54d2e9523b709 -> tool:nanobot-harness-v3:call_75364cc8906f4ca6887dffe5 -> tool:nanobot-harness-v3:call_1d8975a24f26485cb7f1ce96 -> tool:nanobot-harness-v3:call_78818b22780d45afa38fd05b -> tool:nanobot-harness-v3:call_e38fe3ade602463e9ad24c7a -> tool:nanobot-harness-v3:call_fa413f6922fb44b08579b754 -> tool:nanobot-harness-v3:call_fb38cc808dbd46029860c4de -> tool:nanobot-harness-v3:call_69dd0da8b2194cf7aa647618 -> tool:nanobot-harness-v3:call_c6bdf3180b8d4965a1cbbb80 -> tool:nanobot-harness-v3:call_e670eed8ef814197a92fd143
- 关键路径耗时：1.796657
- Makespan：400.065776
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
