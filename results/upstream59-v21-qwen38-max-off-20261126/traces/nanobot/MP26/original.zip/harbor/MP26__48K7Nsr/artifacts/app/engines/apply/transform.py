def _unwrap(p):
    if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    calendar_data = _unwrap(payloads[0])
    plan_data = _unwrap(payloads[1])
    notifications_data = _unwrap(payloads[2])
    if not isinstance(calendar_data, dict):
        raise ValueError("calendar input must be object")
    if not isinstance(plan_data, dict):
        raise ValueError("plan input must be object")
    if not isinstance(notifications_data, dict):
        raise ValueError("notifications input must be object")
    if "events" not in calendar_data:
        raise ValueError("missing events in calendar")
    if "cancelled" not in plan_data or "added" not in plan_data:
        raise ValueError("missing fields in plan")
    if "outbox" not in notifications_data:
        raise ValueError("missing outbox in notifications")
    cancelled_set = set(plan_data["cancelled"])
    # Remove cancelled events from old events
    remaining = [ev for ev in calendar_data["events"] if ev["id"] not in cancelled_set]
    # Add new events
    final_events = remaining + list(plan_data["added"])
    # Sort by id
    final_events.sort(key=lambda e: e["id"])
    return {
        "name": contract["name"],
        "result": {
            "events": final_events,
            "outbox": notifications_data["outbox"],
        },
    }
