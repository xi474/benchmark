from datetime import datetime


def _unwrap(p):
    if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    for k in ("today", "events", "contacts"):
        if k not in data:
            raise ValueError(f"missing field: {k}")
    contacts = data["contacts"]
    if not isinstance(contacts, list):
        raise ValueError("contacts must be list")
    contact_set = set()
    for c in contacts:
        if not isinstance(c, str):
            raise ValueError("contact id must be string")
        if c in contact_set:
            raise ValueError(f"duplicate contact: {c}")
        contact_set.add(c)
    events = data["events"]
    if not isinstance(events, list):
        raise ValueError("events must be list")
    seen_ids = set()
    parsed_events = []
    for ev in events:
        if not isinstance(ev, dict):
            raise ValueError("event must be object")
        for k in ("id", "start", "end", "kind", "attendees"):
            if k not in ev:
                raise ValueError(f"event missing field: {k}")
        eid = ev["id"]
        if not isinstance(eid, str):
            raise ValueError("event id must be string")
        if eid in seen_ids:
            raise ValueError(f"duplicate event id: {eid}")
        seen_ids.add(eid)
        kind = ev["kind"]
        if not isinstance(kind, str) or not kind.strip():
            raise ValueError("kind must be non-empty string")
        start_str = ev["start"]
        end_str = ev["end"]
        if not isinstance(start_str, str) or not isinstance(end_str, str):
            raise ValueError("start/end must be strings")
        start_dt = datetime.strptime(start_str, "%Y-%m-%dT%H:%M")
        end_dt = datetime.strptime(end_str, "%Y-%m-%dT%H:%M")
        if end_dt <= start_dt:
            raise ValueError(f"end must be > start for event {eid}")
        attendees = ev["attendees"]
        if not isinstance(attendees, list):
            raise ValueError("attendees must be list")
        for a in attendees:
            if not isinstance(a, str):
                raise ValueError("attendee must be string")
            if a not in contact_set:
                raise ValueError(f"attendee {a} not in contacts")
        # Deduplicate attendees preserving order
        seen_a = set()
        deduped = []
        for a in attendees:
            if a not in seen_a:
                seen_a.add(a)
                deduped.append(a)
        parsed_events.append({
            "id": eid,
            "start": start_str,
            "end": end_str,
            "kind": kind,
            "attendees": deduped,
        })
    # Sort events by id then attendees (deduplicated)
    # "按id,attendees去重排序" - sort by id
    parsed_events.sort(key=lambda e: e["id"])
    # Find existing dinners: start time exactly 19:00 and kind="dinner"
    existing_dinner_dates = set()
    for ev in parsed_events:
        if ev["kind"] == "dinner":
            start_dt = datetime.strptime(ev["start"], "%Y-%m-%dT%H:%M")
            if start_dt.hour == 19 and start_dt.minute == 0:
                date_str = start_dt.strftime("%Y-%m-%d")
                existing_dinner_dates.add(date_str)
    existing_dinners = sorted(existing_dinner_dates)
    return {
        "name": contract["name"],
        "result": {
            "events": parsed_events,
            "existing_dinners": existing_dinners,
        },
    }
