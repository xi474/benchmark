from datetime import datetime, timedelta


def _unwrap(p):
    """If payload is {name, result}, return result; else return as-is."""
    if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = _unwrap(payloads[0])
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    for k in ("today", "events", "contacts"):
        if k not in data:
            raise ValueError(f"missing field: {k}")
    today_str = data["today"]
    if not isinstance(today_str, str):
        raise ValueError("today must be string")
    today = datetime.strptime(today_str, "%Y-%m-%d").date()
    # Find next natural week Friday (Monday is week start)
    # weekday(): Monday=0 ... Sunday=6
    # We need the Friday of the current or next week
    # "from today to next natural week Friday, both inclusive"
    # If today is Monday(0), Friday is +4 days
    # If today is Friday(4), that's today
    # If today is Saturday(5), next Friday is +6 days
    # If today is Sunday(6), next Friday is +5 days
    wd = today.weekday()  # 0=Mon
    if wd <= 4:  # Mon-Fri
        days_to_friday = 4 - wd
    else:  # Sat-Sun
        days_to_friday = 4 + (7 - wd)
    end_date = today + timedelta(days=days_to_friday)
    dates = []
    d = today
    while d <= end_date:
        dates.append(d.strftime("%Y-%m-%d"))
        d += timedelta(days=1)
    return {"name": contract["name"], "result": {"dates": dates}}
