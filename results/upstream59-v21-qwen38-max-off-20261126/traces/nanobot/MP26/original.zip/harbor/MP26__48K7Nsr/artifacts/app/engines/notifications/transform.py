def _unwrap(p):
    if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    plan_data = _unwrap(payloads[0])
    if not isinstance(plan_data, dict):
        raise ValueError("input must be object")
    if "snapshots" not in plan_data:
        raise ValueError("missing snapshots field")
    snapshots = plan_data["snapshots"]
    # For each cancelled event snapshot, collect affected attendees
    # Build mapping: contact_id -> set of cancelled event ids
    contact_events = {}
    for snap in snapshots:
        eid = snap["id"]
        attendees = snap.get("attendees", [])
        for a in attendees:
            if a not in contact_events:
                contact_events[a] = set()
            contact_events[a].add(eid)
    # Build outbox sorted by to, with event_ids deduplicated and sorted
    outbox = []
    for to_id in sorted(contact_events.keys()):
        eids = sorted(contact_events[to_id])
        outbox.append({"to": to_id, "event_ids": eids})
    return {
        "name": contract["name"],
        "result": {"outbox": outbox},
    }
