from datetime import datetime


def _unwrap(p):
    if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    dates_data = _unwrap(payloads[0])
    calendar_data = _unwrap(payloads[1])
    if not isinstance(dates_data, dict) or not isinstance(calendar_data, dict):
        raise ValueError("inputs must be objects")
    if "dates" not in dates_data:
        raise ValueError("missing dates field")
    if "events" not in calendar_data or "existing_dinners" not in calendar_data:
        raise ValueError("missing calendar fields")
    all_dates = dates_data["dates"]
    existing_dinners = set(calendar_data["existing_dinners"])
    events = calendar_data["events"]
    # Build new dinner reminders for dates not in existing_dinners
    added = []
    old_event_ids = set()
    for ev in events:
        old_event_ids.add(ev["id"])
    for date_str in all_dates:
        if date_str in existing_dinners:
            continue
        new_id = f"dinner-{date_str}"
        if new_id in old_event_ids:
            raise ValueError(f"new dinner id {new_id} conflicts with existing event")
        added.append({
            "id": new_id,
            "start": f"{date_str}T19:00",
            "end": f"{date_str}T20:00",
            "kind": "dinner",
            "attendees": [],
        })
    # Sort added by start
    added.sort(key=lambda e: e["start"])
    # Find cancelled events: any old event whose half-open interval intersects
    # any new reminder's half-open interval.
    # Half-open [start, end): intersection if a.start < b.end and b.start < a.end
    # "恰19点结束不冲突" means ending exactly at 19:00 does not conflict
    # So for new dinner [19:00, 20:00), an old event ending at 19:00 does NOT conflict
    # because old.end <= new.start means no overlap in half-open
    cancelled_ids = set()
    snapshots = []
    for ev in events:
        ev_start = datetime.strptime(ev["start"], "%Y-%m-%dT%H:%M")
        ev_end = datetime.strptime(ev["end"], "%Y-%m-%dT%H:%M")
        for new_ev in added:
            new_start = datetime.strptime(new_ev["start"], "%Y-%m-%dT%H:%M")
            new_end = datetime.strptime(new_ev["end"], "%Y-%m-%dT%H:%M")
            # Half-open intersection: ev_start < new_end AND new_start < ev_end
            if ev_start < new_end and new_start < ev_end:
                cancelled_ids.add(ev["id"])
                break
    # Build snapshots of cancelled events (original events)
    for ev in events:
        if ev["id"] in cancelled_ids:
            snapshots.append(dict(ev))
    # Sort snapshots by id
    snapshots.sort(key=lambda e: e["id"])
    cancelled_sorted = sorted(cancelled_ids)
    return {
        "name": contract["name"],
        "result": {
            "added": added,
            "cancelled": cancelled_sorted,
            "snapshots": snapshots,
        },
    }
