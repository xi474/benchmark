import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable or shutil.which("python3") or "python3"


def main():
    # Discover all contracts
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)

    # Build dependency graph from contract inputs/outputs
    # Map output path -> contract path
    output_to_contract = {}
    contract_info = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        out = c["output"]
        output_to_contract[out] = cp
        contract_info[cp] = c

    # Topological sort based on dependencies
    # A contract depends on another if any of its inputs is an output of another
    deps = {}  # cp -> set of cp it depends on
    for cp in contracts:
        c = contract_info[cp]
        dep_set = set()
        for inp in c["inputs"]:
            if inp in output_to_contract:
                dep_set.add(output_to_contract[inp])
        deps[cp] = dep_set

    # Kahn's algorithm
    in_degree = {cp: len(deps[cp]) for cp in contracts}
    queue = [cp for cp in contracts if in_degree[cp] == 0]
    order = []
    while queue:
        queue.sort()  # deterministic
        cp = queue.pop(0)
        order.append(cp)
        for other in contracts:
            if cp in deps[other]:
                in_degree[other] -= 1
                if in_degree[other] == 0:
                    queue.append(other)
    if len(order) != len(contracts):
        print("dependency cycle detected", file=sys.stderr)
        sys.exit(1)

    # Execute each component in order
    for cp in order:
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            print(f"missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [PYTHON, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"component {cp} failed with code {result.returncode}", file=sys.stderr)
            sys.exit(1)

    # Run integrate.py
    integrate = ROOT / "integrate.py"
    if integrate.is_file():
        result = subprocess.run(
            [PYTHON, str(integrate)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)

    # Run final_report.py
    final_report = ROOT / "final_report.py"
    if final_report.is_file():
        result = subprocess.run(
            [PYTHON, str(final_report)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
