# Workflow 可观测性报告

- Trial：`MS02__b2qieYx__env`
- Task：`MS02`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_fde48183ebd2446eb1649d50 -> tool:nanobot-harness-v3:call_661d59c9c62b4e76942de190 -> tool:nanobot-harness-v3:call_17c7b6cf5a2742728b9a38d9 -> tool:nanobot-harness-v3:call_943ef1fe5cd041618b1b0dab -> tool:nanobot-harness-v3:call_c2542b2eb0a64289be3e480b -> tool:nanobot-harness-v3:call_e138e9eb23bc42feacf1ef5f -> tool:nanobot-harness-v3:call_1c2607230ae14edcb7a1bfdf -> tool:nanobot-harness-v3:call_bf6fb607c4eb45bfb0d4f9b2 -> tool:nanobot-harness-v3:call_8a8523e3976c4660b2a1187b -> tool:nanobot-harness-v3:call_034361f0a42f43afac834573 -> tool:nanobot-harness-v3:call_4fb92685ecbc4f6796c80dd7 -> tool:nanobot-harness-v3:call_27832462dbe046928d2ba187 -> tool:nanobot-harness-v3:call_8c8fcdf419b74afa84b8407b -> tool:nanobot-harness-v3:call_16a404d20d9c41f8bebee9fb -> tool:nanobot-harness-v3:call_7481c1fa85b7446283d520a0 -> tool:nanobot-harness-v3:call_d8291980b58a49b8bcc60de4 -> tool:nanobot-harness-v3:call_bf4f3a8e356447089ed9fc30 -> tool:nanobot-harness-v3:call_1caa91a7a84e4281baad2523 -> tool:nanobot-harness-v3:call_73d176aba98645ddaf96d2af -> tool:nanobot-harness-v3:call_ecfae22727af49e2b0e84cbd -> tool:nanobot-harness-v3:call_8c7244fe89fd471f9cd267ff -> tool:nanobot-harness-v3:call_da99e44513ae4d7098202481 -> tool:nanobot-harness-v3:call_04ad313e56494a849550869a -> tool:nanobot-harness-v3:call_95f12c590e3b4b8ba5550e23 -> tool:nanobot-harness-v3:call_da73b0eb677045a784d2396a -> tool:nanobot-harness-v3:call_eddf8d36273d495a9fce9ad4 -> tool:nanobot-harness-v3:call_16a857e1cd3546a2b40bff7c -> tool:nanobot-harness-v3:call_69aa993197574d899498f6c8 -> tool:nanobot-harness-v3:call_f50191b338bf4a37954139ee -> tool:nanobot-harness-v3:call_fec22dc173ce4e36888f3217 -> tool:nanobot-harness-v3:call_4f3bb65750e847198bcceb00 -> tool:nanobot-harness-v3:call_e0622c95454046b99c5ca5e2 -> tool:nanobot-harness-v3:call_a4029d90607844d897162b69 -> tool:nanobot-harness-v3:call_8702caef89df4d00bbf95b9c -> tool:nanobot-harness-v3:call_a922c7c1edf4455cb9975e9c -> tool:nanobot-harness-v3:call_35f1f20e751440b58ea07d85 -> tool:nanobot-harness-v3:call_a6831ed3d08b420c9f5457ed
- 关键路径耗时：0.328625
- Makespan：111.585273
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
