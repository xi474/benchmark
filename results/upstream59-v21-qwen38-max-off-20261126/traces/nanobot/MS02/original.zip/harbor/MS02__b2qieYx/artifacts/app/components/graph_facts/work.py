def compute(payload):
    """返回去重并按三元组字典序排列的已有图事实。"""
    graph = payload.get("graph", [])
    # Convert to tuples for dedup and sorting, then back to lists
    seen = set()
    unique = []
    for edge in graph:
        key = tuple(edge)
        if key not in seen:
            seen.add(key)
            unique.append(list(edge))
    unique.sort()
    return unique
