from itertools import product as _product


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left  = evidence_scores result: list of dicts (one per topic in order)
    right = graph_facts result: sorted deduplicated edge list
    """
    topics = payload["topics"]
    n = len(topics)

    # If no topics, empty review + just the existing graph edges
    if n == 0:
        return {"review": [], "graph": right}

    # Build candidate lists per topic: list of (paper_id, quality) sorted for determinism
    candidates = []
    for i, topic in enumerate(topics):
        score_map = left[i]
        cands = sorted(score_map.items(), key=lambda x: x[0])  # sort by paper id
        if not cands:
            return None  # no paper can cover this topic
        candidates.append(cands)

    # We need to assign one paper per topic, no reuse.
    # Optimize: maximize min quality, then maximize total quality,
    # then lexicographically smallest paper-id sequence (by topic order).
    #
    # With at most 8 topics and 12 papers, we use branch-and-bound / backtracking.

    best_assignment = [None]  # list of paper_ids in topic order
    best_min_q = [-1]
    best_total_q = [-1]

    def _assign(ti, used, assignment, current_min, current_total):
        if ti == n:
            # Check if this is better
            if (current_min > best_min_q[0] or
                (current_min == best_min_q[0] and current_total > best_total_q[0]) or
                (current_min == best_min_q[0] and current_total == best_total_q[0] and
                 assignment < best_assignment[0])):
                best_min_q[0] = current_min
                best_total_q[0] = current_total
                best_assignment[0] = list(assignment)
            return

        for paper_id, quality in candidates[ti]:
            if paper_id in used:
                continue
            new_min = min(current_min, quality)
            # Pruning: if new_min already worse than best, skip
            if new_min < best_min_q[0]:
                continue
            # Upper bound on total: even if remaining topics get max possible quality
            # This is optional but helps
            assignment.append(paper_id)
            used.add(paper_id)
            _assign(ti + 1, used, assignment, new_min, current_total + quality)
            used.remove(paper_id)
            assignment.pop()

    _assign(0, set(), [], float('inf'), 0)

    if best_assignment[0] is None:
        return None

    # Build review
    review = []
    for i, topic in enumerate(topics):
        pid = best_assignment[0][i]
        q = left[i][pid]
        review.append([topic, pid, q])

    # Build graph: merge existing edges with new supports edges
    edge_set = set()
    for edge in right:
        edge_set.add(tuple(edge))
    for i, topic in enumerate(topics):
        pid = best_assignment[0][i]
        edge_set.add((pid, "supports", topic))

    merged_graph = sorted(edge_set)
    # Convert tuples back to lists
    merged_graph = [list(e) for e in merged_graph]

    return {"review": review, "graph": merged_graph}
