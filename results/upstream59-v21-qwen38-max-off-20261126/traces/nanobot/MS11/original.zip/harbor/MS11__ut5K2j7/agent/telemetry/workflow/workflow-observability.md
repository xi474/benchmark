# Workflow 可观测性报告

- Trial：`MS11__ut5K2j7__env`
- Task：`MS11`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（44 节点 / 43 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：44；执行边：43（observed=0，inferred=43）
- Execution Trace Graph：`observed`；temporal_next 边 43，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_f0097cab9e3d495aa2a05e7d -> tool:nanobot-harness-v3:call_fa63fa8517bf463aadbae918 -> tool:nanobot-harness-v3:call_ffef47fb5b1a45a0a5b68f2c -> tool:nanobot-harness-v3:call_7893eb3cc66f4c04a5c07783 -> tool:nanobot-harness-v3:call_0e628809d8214f95bb6ca576 -> tool:nanobot-harness-v3:call_17cf714cf7814712a5857330 -> tool:nanobot-harness-v3:call_cf4dfba3f7624bffb8a0dcd0 -> tool:nanobot-harness-v3:call_274ed607cd25478d8674a495 -> tool:nanobot-harness-v3:call_22a092761a2640658566a369 -> tool:nanobot-harness-v3:call_6fc0dc56b24e45888ad4aab3 -> tool:nanobot-harness-v3:call_0af89af463a8457e98a0ef43 -> tool:nanobot-harness-v3:call_523b711f0112473e948843b8 -> tool:nanobot-harness-v3:call_1971473ef1904119b48abdf6 -> tool:nanobot-harness-v3:call_08bdcf7d13204f21b4a25881 -> tool:nanobot-harness-v3:call_8e44df2abd3a41518d91ab43 -> tool:nanobot-harness-v3:call_704b7c0532924dba9367beae -> tool:nanobot-harness-v3:call_abb6233270a44ca5a763cc12 -> tool:nanobot-harness-v3:call_816a83e76e6f4e918b2bf90b -> tool:nanobot-harness-v3:call_70046cd4f7274322a67d8572 -> tool:nanobot-harness-v3:call_80a2db1a06a44d41b0859e0f -> tool:nanobot-harness-v3:call_b29dff54d34e4769900040fb -> tool:nanobot-harness-v3:call_dd222afa1ae74095a227f54d -> tool:nanobot-harness-v3:call_18480a53033f488bb566643d -> tool:nanobot-harness-v3:call_de799134658b4ea08bf7e399 -> tool:nanobot-harness-v3:call_cc5cba57e63c43c49c52b108 -> tool:nanobot-harness-v3:call_5f14270935d14d66b8c2aa0c -> tool:nanobot-harness-v3:call_c6ef9c756be242d298c9f2dd -> tool:nanobot-harness-v3:call_e57e766fea064b159bb8e9ae -> tool:nanobot-harness-v3:call_3c0f33fe64a449de8770c6d4 -> tool:nanobot-harness-v3:call_96137bb71d814001bbb89301 -> tool:nanobot-harness-v3:call_5405281ec9aa4f5aa79eb07b -> tool:nanobot-harness-v3:call_9ec942f5ee5b4e168c74ca9e -> tool:nanobot-harness-v3:call_99cddd135cfd49a186057c65 -> tool:nanobot-harness-v3:call_e13663350409448ebee7e139 -> tool:nanobot-harness-v3:call_f430c9677ffd4e2ba0316ee2 -> tool:nanobot-harness-v3:call_31fe660524544fdab2f4421e -> tool:nanobot-harness-v3:call_dc23c3f1bc3d449ab9b183ae -> tool:nanobot-harness-v3:call_cc23c9e723fd4fe4b5015f46 -> tool:nanobot-harness-v3:call_ccb1906f2f7a40679322ffd6 -> tool:nanobot-harness-v3:call_bf130048ac914a37804e88f4 -> tool:nanobot-harness-v3:call_647a60ed968f4a3a9780caab -> tool:nanobot-harness-v3:call_db7489e452b04d3f90568108 -> tool:nanobot-harness-v3:call_3e109ac0c85d4e6b9dd19313
- 关键路径耗时：0.387017
- Makespan：159.205611
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
