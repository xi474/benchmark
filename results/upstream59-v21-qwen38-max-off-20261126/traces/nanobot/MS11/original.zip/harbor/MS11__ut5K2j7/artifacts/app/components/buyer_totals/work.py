def compute(payload):
    """按买家 ID 汇总属于 Cameras 或 Electronics 的行金额，每行只计一次；无购买为零。"""
    buyers = payload["buyers"]
    orders = payload["orders"]
    # Initialize all buyers to 0
    totals = {b: 0 for b in buyers}
    target_categories = {"Electronics", "Cameras"}
    for order in orders:
        buyer = order["buyer"]
        for line in order["lines"]:
            categories, qty, unit_price = line[0], line[1], line[2]
            # Check if any category matches
            if any(c in target_categories for c in categories):
                totals[buyer] += qty * unit_price
    return totals
