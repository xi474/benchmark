def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    students = payload["students"]
    buyers = payload["buyers"]
    evidence_raw = payload["evidence"]
    drop_list = payload["drop"]

    # left = student_scores dict {student_id: X}
    # right = buyer_totals dict {buyer_id: Y}
    student_scores = left   # {student: int}
    buyer_totals = right    # {buyer: int}

    results = []
    for drop_source in drop_list:
        result = _solve_one(students, buyers, evidence_raw, student_scores, buyer_totals, drop_source)
        results.append({"drop": drop_source, "result": result})
    return results


def _solve_one(students, buyers, evidence_raw, student_scores, buyer_totals, drop_source):
    """Solve for one drop scenario. Returns result dict or None."""
    n = len(students)

    # Filter evidence: remove rows whose source == drop_source (if not null)
    if drop_source is not None:
        filtered = [e for e in evidence_raw if e[0] != drop_source]
    else:
        filtered = evidence_raw

    # Build confidence map: for each source, keep max per (student, buyer); then sum across sources
    # Step 1: group by (source, student, buyer) -> max strength
    source_pair_max = {}  # (source, student, buyer) -> max_strength
    for row in filtered:
        src, stu, buy, strength = row[0], row[1], row[2], row[3]
        key = (src, stu, buy)
        if key not in source_pair_max or strength > source_pair_max[key]:
            source_pair_max[key] = strength

    # Step 2: sum across sources for each (student, buyer)
    confidence = {}  # (student, buyer) -> total_confidence
    for (src, stu, buy), val in source_pair_max.items():
        key = (stu, buy)
        confidence[key] = confidence.get(key, 0) + val

    # Build adjacency: which (student, buyer) pairs have evidence
    # Students and buyers are identified by their IDs
    student_set = set(students)
    buyer_set = set(buyers)

    # Build bipartite graph as adjacency lists
    # adj_s[student] = list of (buyer, confidence)
    adj_s = {s: [] for s in students}
    adj_b = {b: [] for b in buyers}
    for (s, b), c in confidence.items():
        if s in student_set and b in buyer_set:
            adj_s[s].append((b, c))
            adj_b[b].append((s, c))

    # Find connected components using BFS on the bipartite graph
    visited_s = set()
    visited_b = set()
    components = []  # list of (set_of_students, set_of_buyers)

    for s in students:
        if s in visited_s:
            continue
        # BFS
        comp_s = set()
        comp_b = set()
        queue_s = [s]
        visited_s.add(s)
        while queue_s:
            cs = queue_s.pop()
            comp_s.add(cs)
            for (b, c) in adj_s[cs]:
                if b not in visited_b:
                    visited_b.add(b)
                    comp_b.add(b)
                    # From this buyer, explore other students
                    for (s2, c2) in adj_b[b]:
                        if s2 not in visited_s:
                            visited_s.add(s2)
                            queue_s.append(s2)
        # Check if component has equal students and buyers
        if len(comp_s) != len(comp_b):
            return None  # No perfect matching possible
        components.append((comp_s, comp_b))

    # Check all students and buyers are covered
    if len(visited_s) != n or len(visited_b) != n:
        return None

    # For each component, enumerate all perfect matchings
    # Each matching is a list of (student, buyer, confidence)
    # Component size <= 14 per side, so we can use backtracking

    def enumerate_matchings(comp_students, comp_buyers, conf_map):
        """Enumerate all perfect matchings in a component.
        Returns list of matchings, each matching is list of (student, buyer, confidence)."""
        s_list = sorted(comp_students)
        b_list = sorted(comp_buyers)
        sz = len(s_list)
        if sz == 0:
            return [[]]

        # Build adjacency for this component
        adj = {}
        for s in s_list:
            adj[s] = [(b, c) for (b, c) in conf_map.get(s, []) if b in comp_buyers]

        matchings = []
        used = set()
        current = []

        def backtrack(idx):
            if idx == sz:
                matchings.append(list(current))
                return
            s = s_list[idx]
            for (b, c) in adj[s]:
                if b not in used:
                    used.add(b)
                    current.append((s, b, c))
                    backtrack(idx + 1)
                    current.pop()
                    used.remove(b)

        backtrack(0)
        return matchings

    # Build confidence lookup per component
    comp_matchings = []
    for (comp_s, comp_b) in components:
        conf_map = {}
        for s in comp_s:
            conf_map[s] = [(b, c) for (b, c) in adj_s[s] if b in comp_b]
        ms = enumerate_matchings(comp_s, comp_b, conf_map)
        if not ms:
            return None
        comp_matchings.append(ms)

    # Combine matchings across components
    # We need to find global matchings that maximize (min_conf, total_conf)
    # Since components are independent, we can combine them

    # First, find the best (floor, total) achievable
    # For each component, compute (min_conf, total_conf) for each matching
    # Then combine across components

    # Actually, since we want to maximize min first, then total,
    # and components are independent, we need to be careful.
    # The global min is the min across all components' matchings.
    # The global total is the sum across all components' matchings.

    # Strategy: try all combinations? With multiple components this could explode.
    # But each component has <=14 vertices, and the number of components is limited.
    # Let's compute per-component stats and combine smartly.

    # For efficiency, let's just generate all global matchings by combining
    # But that could be exponential. Instead, let's be smarter.

    # Per component, get list of (min_c, total_c, matching)
    comp_stats = []
    for ms in comp_matchings:
        stats = []
        for m in ms:
            confs = [c for (_, _, c) in m]
            min_c = min(confs)
            total_c = sum(confs)
            stats.append((min_c, total_c, m))
        comp_stats.append(stats)

    # Find global optimum: maximize floor, then total
    # Global floor = min of per-component floors
    # Global total = sum of per-component totals

    # To maximize global floor: we need each component's matching to have floor >= some threshold
    # Binary search or iterate over possible floor values

    # Collect all possible floor values
    all_floors = set()
    for stats in comp_stats:
        for (mc, tc, m) in stats:
            all_floors.add(mc)
    all_floors = sorted(all_floors, reverse=True)

    best_floor = None
    best_total = None
    for floor_candidate in all_floors:
        # Check if every component has at least one matching with min_c >= floor_candidate
        feasible = True
        max_total_for_floor = 0
        for stats in comp_stats:
            candidates = [(tc, m) for (mc, tc, m) in stats if mc >= floor_candidate]
            if not candidates:
                feasible = False
                break
            # For this floor, we want to maximize total within each component independently
            best_tc = max(tc for (tc, m) in candidates)
            max_total_for_floor += best_tc
        if feasible:
            best_floor = floor_candidate
            best_total = max_total_for_floor
            break

    if best_floor is None:
        return None

    # Now collect all global matchings achieving (best_floor, best_total)
    # For each component, filter to matchings with min_c >= best_floor
    # Then among those, only keep ones where the combination achieves best_total
    # This means each component must contribute its max possible total given floor constraint

    # Per component, find the max total achievable with min_c >= best_floor
    comp_max_totals = []
    for stats in comp_stats:
        candidates = [(tc, m) for (mc, tc, m) in stats if mc >= best_floor]
        max_tc = max(tc for (tc, m) in candidates)
        comp_max_totals.append(max_tc)

    # Verify sum equals best_total
    assert sum(comp_max_totals) == best_total

    # For each component, filter matchings that achieve both:
    # min_c >= best_floor AND total_c == comp_max_totals[i]
    # Wait, that's too restrictive. We need the SUM to equal best_total,
    # but individual components don't all need to be at their max.
    # Actually, since we're maximizing total, and each component contributes independently,
    # the only way to achieve the global max total is if EACH component achieves its own max.
    # Because if any component is below its max, the total would be less.
    # So yes, each component must be at its max total for the given floor.

    # Hmm wait, that's only true if we're maximizing total. Let me reconsider.
    # We want matchings where:
    # 1. Every pair has confidence >= best_floor (global min = best_floor)
    # 2. Sum of all confidences = best_total
    # Since best_total = sum of per-component max totals (given floor constraint),
    # each component MUST achieve its max total. Otherwise the sum would be less.
    # So yes, filter each component to matchings with min_c >= best_floor AND total_c == comp_max_totals[i].

    comp_optimal = []
    for i, stats in enumerate(comp_stats):
        target_tc = comp_max_totals[i]
        optimal = [m for (mc, tc, m) in stats if mc >= best_floor and tc == target_tc]
        comp_optimal.append(optimal)

    # Count total optimal matchings
    count = 1
    for opts in comp_optimal:
        count *= len(opts)

    # Generate all optimal global matchings to compute numerators
    # We need to enumerate all combinations
    # For large counts this could be expensive, but problem constraints should keep it manageable

    # Build student->X and buyer->Y lookups
    X = {}  # student -> score
    for s in students:
        X[s] = student_scores[s]
    Y = {}  # buyer -> total
    for b in buyers:
        Y[b] = buyer_totals[b]

    # Enumerate all combinations of per-component optimal matchings
    num_components = len(comp_optimal)

    # Use iterative approach to enumerate
    all_global_matchings = []

    def combine_components(comp_idx, current_matching):
        if comp_idx == num_components:
            all_global_matchings.append(list(current_matching))
            return
        for m in comp_optimal[comp_idx]:
            current_matching.extend(m)
            combine_components(comp_idx + 1, current_matching)
            del current_matching[-len(m):]

    combine_components(0, [])

    # Compute numerators
    numerators = []
    buyer_vectors = []  # list of (numerator, buyer_vector_as_tuple)
    sorted_students = sorted(students)

    for gm in all_global_matchings:
        # gm is list of (student, buyer, confidence)
        mapping = {s: b for (s, b, c) in gm}
        # Compute numerator: n * sum(X*Y) - sum(X) * sum(Y)
        sum_xy = 0
        sum_x = 0
        sum_y = 0
        for s in students:
            b = mapping[s]
            x = X[s]
            y = Y[b]
            sum_xy += x * y
            sum_x += x
            sum_y += y
        num = n * sum_xy - sum_x * sum_y
        # Buyer vector: sorted by student ID ascending
        bv = tuple(mapping[s] for s in sorted_students)
        numerators.append(num)
        buyer_vectors.append((num, bv))

    min_num = min(numerators)
    max_num = max(numerators)

    # Lex-smallest buyer vector for min_num
    min_candidates = [bv for (num, bv) in buyer_vectors if num == min_num]
    min_buyers = list(min(min_candidates))

    # Lex-smallest buyer vector for max_num
    max_candidates = [bv for (num, bv) in buyer_vectors if num == max_num]
    max_buyers = list(min(max_candidates))

    # Forced pairs: pairs that appear in ALL optimal matchings
    # A pair (s, b) is forced if it appears in every global optimal matching
    forced_set = None
    for gm in all_global_matchings:
        pairs = {(s, b) for (s, b, c) in gm}
        if forced_set is None:
            forced_set = pairs
        else:
            forced_set &= pairs
    forced = sorted([[s, b] for (s, b) in forced_set], key=lambda x: x[0])

    return {
        "floor": best_floor,
        "total": best_total,
        "count": count,
        "min_num": min_num,
        "max_num": max_num,
        "min_buyers": min_buyers,
        "max_buyers": max_buyers,
        "forced": forced
    }
