# Workflow 可观测性报告

- Trial：`MS12__bDnGCGB__env`
- Task：`MS12`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（39 节点 / 38 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：39；执行边：38（observed=0，inferred=38）
- Execution Trace Graph：`observed`；temporal_next 边 38，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_29128448993f409496e3ce11 -> tool:nanobot-harness-v3:call_0efe8f82be4c44c991539878 -> tool:nanobot-harness-v3:call_92c5965fe9a04f95ac8b9e17 -> tool:nanobot-harness-v3:call_3f8daa4f5a4d4f7a8d0685e4 -> tool:nanobot-harness-v3:call_dcdbb30d3bcc4139af76b939 -> tool:nanobot-harness-v3:call_9f49a5a5d2484519b84eb0ba -> tool:nanobot-harness-v3:call_d5765482cebf439989c8621b -> tool:nanobot-harness-v3:call_ca64c753f7d842f1b1a38fba -> tool:nanobot-harness-v3:call_b27208982a6640678c274b4e -> tool:nanobot-harness-v3:call_8eceb4c1aa8f439c89b2023a -> tool:nanobot-harness-v3:call_440aab75ddf84d43a240ad1b -> tool:nanobot-harness-v3:call_cfe82c40fb054e058e0d6bca -> tool:nanobot-harness-v3:call_3a725196be5244a48799a75c -> tool:nanobot-harness-v3:call_ac96226b130348f084a84599 -> tool:nanobot-harness-v3:call_e31e77e9ad63499aaa639757 -> tool:nanobot-harness-v3:call_f5cf5a9c8c004f55b52cba63 -> tool:nanobot-harness-v3:call_9e9d4178e4c24e43a69bb0af -> tool:nanobot-harness-v3:call_99bc9c70af144a9497277267 -> tool:nanobot-harness-v3:call_8c3fec866ac84fe081f35b46 -> tool:nanobot-harness-v3:call_e78d40fc17d345cd8089c162 -> tool:nanobot-harness-v3:call_53a28599f7d749dd93b2dfb6 -> tool:nanobot-harness-v3:call_56abd2650695433da34d7277 -> tool:nanobot-harness-v3:call_56ec5d696e0f4afb8acfd125 -> tool:nanobot-harness-v3:call_8e79b43176f04e808446aaec -> tool:nanobot-harness-v3:call_0a8b0c486d4a46d99789d9af -> tool:nanobot-harness-v3:call_8671c8d4939545909ede1375 -> tool:nanobot-harness-v3:call_fbd4db91855d410d8dc7b9da -> tool:nanobot-harness-v3:call_687199fa2c734f85a65cb6b4 -> tool:nanobot-harness-v3:call_f76ecfec5cd74b12b4c7f001 -> tool:nanobot-harness-v3:call_75c9b455098c4ccf84f5dd57 -> tool:nanobot-harness-v3:call_c05dd771f538468797348cab -> tool:nanobot-harness-v3:call_3b7c2e9f99b64745b94cbd38 -> tool:nanobot-harness-v3:call_a347bd66ae374fce814dbfbb -> tool:nanobot-harness-v3:call_d57e7ec155504b6698cf44bf -> tool:nanobot-harness-v3:call_d9542030c0b545cea61131e9 -> tool:nanobot-harness-v3:call_9fc419cf4c444ab8aaef6b51 -> tool:nanobot-harness-v3:call_d2df09559e174474b6dec114 -> tool:nanobot-harness-v3:call_2d677f97d9aa4f74b91467df
- 关键路径耗时：0.462777
- Makespan：200.809841
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
