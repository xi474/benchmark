def compute(payload):
    """每个到货信号映射至可供菜品 ID，保持 recipes 顺序，检查难度、原料可得性和过敏限制。"""
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]

    # Collect all forbidden ingredients across all groups
    # A recipe is unavailable if ANY group forbids ANY of its ingredients
    forbidden_ingredients = set()
    for g in groups:
        for ing in g[2]:  # g[2] is the forbidden ingredients list
            forbidden_ingredients.add(ing)

    result = {}
    for signal, available_ingredients in delivery.items():
        avail_set = set(available_ingredients)
        eligible = []
        for r in recipes:
            # Check difficulty <= 4
            if r["difficulty"] > 4:
                continue
            # Check all ingredients available
            if not all(ing in avail_set for ing in r["ingredients"]):
                continue
            # Check no forbidden ingredient
            if any(ing in forbidden_ingredients for ing in r["ingredients"]):
                continue
            eligible.append(r["id"])
        result[signal] = eligible
    return result
