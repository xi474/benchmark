def compute(payload):
    """输出 [信号历史,该完整叶的权重或 null]，去重生成所有非空前缀，按历史字典序排列。"""
    scenarios = payload["scenarios"]
    # Build a set of full paths mapped to their weights
    leaf_weights = {}
    for sc in scenarios:
        key = tuple(sc["signals"])
        leaf_weights[key] = sc["weight"]

    # Collect all non-empty prefixes
    prefix_set = set()
    for sc in scenarios:
        sigs = sc["signals"]
        for i in range(1, len(sigs) + 1):
            prefix_set.add(tuple(sigs[:i]))

    # Sort lexicographically (shorter before its extensions naturally via tuple comparison)
    sorted_prefixes = sorted(prefix_set)

    result = []
    for p in sorted_prefixes:
        w = leaf_weights.get(p, None)
        result.append([list(p), w])
    return result
