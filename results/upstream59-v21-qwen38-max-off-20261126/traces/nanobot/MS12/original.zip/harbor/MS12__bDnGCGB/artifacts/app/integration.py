def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    recipes = payload["recipes"]
    groups = payload["groups"]
    budget = payload["budget"]
    scenarios = payload["scenarios"]

    recipe_map = {r["id"]: r for r in recipes}

    # Parse prefixes from left: list of [history, weight_or_null]
    prefixes = []
    for item in left:
        prefixes.append((tuple(item[0]), item[1]))
    prefix_to_idx = {p[0]: i for i, p in enumerate(prefixes)}
    num_prefixes = len(prefixes)

    # Eligible dishes per prefix (based on last signal's delivery)
    prefix_eligible = {}
    for hist, _ in prefixes:
        signal = hist[-1]
        prefix_eligible[hist] = right.get(signal, [])

    # Scenario paths as prefix index sequences
    scenario_paths = []
    for sc in scenarios:
        sigs = tuple(sc["signals"])
        indices = [prefix_to_idx[sigs[:d]] for d in range(1, len(sigs) + 1)]
        scenario_paths.append((indices, sc["weight"]))

    # Group data
    group_likes = [set(g[3]) for g in groups]
    group_sizes = [g[1] for g in groups]
    num_groups = len(groups)

    def dish_sat(dish_id):
        cat = recipe_map[dish_id]["cat"]
        return [1 if cat in gl else 0 for gl in group_likes]

    # Which scenarios pass through each prefix
    prefix_to_scenarios = {}
    for si, (indices, _) in enumerate(scenario_paths):
        for idx in indices:
            prefix_to_scenarios.setdefault(idx, []).append(si)

    def compute_stats(assign):
        floor_val = float('inf')
        total_util = 0
        total_cost = 0
        for indices, weight in scenario_paths:
            gsat = [0] * num_groups
            pcost = 0
            for idx in indices:
                d = assign[idx]
                s = dish_sat(d)
                for gi in range(num_groups):
                    gsat[gi] += s[gi]
                pcost += recipe_map[d]["cost"]
            service = min(gsat)
            util = sum(gsat[gi] * group_sizes[gi] for gi in range(num_groups))
            floor_val = min(floor_val, service)
            total_util += weight * util
            total_cost += weight * pcost
        return floor_val, total_util, total_cost

    def feasible_partial(assign, idx):
        dish = assign[idx]
        r = recipe_map[dish]
        for si in prefix_to_scenarios.get(idx, []):
            indices = scenario_paths[si][0]
            for prev_idx in indices:
                if prev_idx == idx:
                    break
                if assign[prev_idx] is not None and assign[prev_idx] == dish:
                    return False
            pos_in_path = indices.index(idx)
            if pos_in_path > 0:
                prev_idx = indices[pos_in_path - 1]
                if assign[prev_idx] is not None:
                    if recipe_map[assign[prev_idx]]["cat"] == r["cat"]:
                        return False
            total = 0
            for pi in indices:
                if assign[pi] is not None:
                    total += recipe_map[assign[pi]]["cost"]
                else:
                    break
            if total > budget:
                return False
        return True

    # Backtracking search for optimal policies
    assignment = [None] * num_prefixes
    best = [-1, -1, float('inf')]  # floor, utility, cost
    best_assign = None
    count_optimal = 0
    allowed_sets = [set() for _ in range(num_prefixes)]

    def is_better(fl, ut, co):
        if fl > best[0]:
            return True
        if fl == best[0] and ut > best[1]:
            return True
        if fl == best[0] and ut == best[1] and co < best[2]:
            return True
        return False

    def is_optimal(fl, ut, co):
        return fl == best[0] and ut == best[1] and co == best[2]

    def backtrack(pos):
        nonlocal best, best_assign, count_optimal
        if pos == num_prefixes:
            fl, ut, co = compute_stats(assignment)
            if is_better(fl, ut, co):
                best = [fl, ut, co]
                best_assign = list(assignment)
                count_optimal = 1
                for i in range(num_prefixes):
                    allowed_sets[i] = {assignment[i]}
            elif is_optimal(fl, ut, co):
                count_optimal += 1
                for i in range(num_prefixes):
                    allowed_sets[i].add(assignment[i])
                # Update best_assign to lex smallest menu vector
                cur_menu = [assignment[i] for i in range(num_prefixes)]
                old_menu = [best_assign[i] for i in range(num_prefixes)]
                if cur_menu < old_menu:
                    best_assign = list(assignment)
            return

        hist = prefixes[pos][0]
        eligible = prefix_eligible[hist]
        for dish_id in eligible:
            assignment[pos] = dish_id
            if feasible_partial(assignment, pos):
                backtrack(pos + 1)
            assignment[pos] = None

    backtrack(0)

    histories_out = [list(p[0]) for p in prefixes]

    if best_assign is None:
        return {"histories": histories_out, "optimal": None}

    menu_vec = [best_assign[i] for i in range(num_prefixes)]
    allowed_out = [sorted(list(s)) for s in allowed_sets]

    return {
        "histories": histories_out,
        "optimal": {
            "floor": best[0],
            "utility": best[1],
            "cost": best[2],
            "count": count_optimal,
            "menu": menu_vec,
            "allowed": allowed_out
        }
    }
