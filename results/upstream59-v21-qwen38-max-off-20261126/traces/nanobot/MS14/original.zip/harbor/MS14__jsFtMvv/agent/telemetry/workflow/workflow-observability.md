# Workflow 可观测性报告

- Trial：`MS14__jsFtMvv__env`
- Task：`MS14`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_805c1639fec8479ab4abbeed -> tool:nanobot-harness-v3:call_e1db80f1f77e46ec9ad4e02b -> tool:nanobot-harness-v3:call_a0491c1a047644c4babbc659 -> tool:nanobot-harness-v3:call_374875c40ee54b54b9803239 -> tool:nanobot-harness-v3:call_7ed0522464224d399b5fb343 -> tool:nanobot-harness-v3:call_453b5751630d44ddb6f54400 -> tool:nanobot-harness-v3:call_1f3bfb3bc2ce4daf8bdd40d3 -> tool:nanobot-harness-v3:call_ee5186d038844b78a7a84bd4 -> tool:nanobot-harness-v3:call_30d0d3b56af5433ea2a365cb -> tool:nanobot-harness-v3:call_b8fe1348acab4d93a9ef0b7f -> tool:nanobot-harness-v3:call_7069b4abe4aa455782d2ddd9 -> tool:nanobot-harness-v3:call_71e7d7898c4b45cbaf025f17 -> tool:nanobot-harness-v3:call_51afe06f7d4d4dfb84d6b600 -> tool:nanobot-harness-v3:call_d2e25d6d7b64485e96a55c75 -> tool:nanobot-harness-v3:call_50d39a19f91f4385ad6f2638 -> tool:nanobot-harness-v3:call_1b246cb280a24a4bbd0395ca -> tool:nanobot-harness-v3:call_3b5832fc50464e32a03b01aa -> tool:nanobot-harness-v3:call_6d377050fadf449a8ac75c0b -> tool:nanobot-harness-v3:call_5903604d35f74ea9b4a2642e -> tool:nanobot-harness-v3:call_53bcecab03ed4498b98d4890 -> tool:nanobot-harness-v3:call_6b5aff314de24ca49a22cf04 -> tool:nanobot-harness-v3:call_81960b3032a24475a56801e7 -> tool:nanobot-harness-v3:call_502cb1bb11b74f43a874022b -> tool:nanobot-harness-v3:call_98f7ea25b73544aa84b65f7a -> tool:nanobot-harness-v3:call_31f8be6a98c74442b9be84b5 -> tool:nanobot-harness-v3:call_1640fe9c467d4711ac79ae42 -> tool:nanobot-harness-v3:call_20f0f2246d484cc1bc578f13 -> tool:nanobot-harness-v3:call_958d8fab3a3549ffbf196bef -> tool:nanobot-harness-v3:call_6f7635d5adf049739b2c393f -> tool:nanobot-harness-v3:call_ca7e4a2d882842bf96091c33 -> tool:nanobot-harness-v3:call_1540b96a944342089a28e9cf -> tool:nanobot-harness-v3:call_748f3b620005452889f7a592 -> tool:nanobot-harness-v3:call_43e72014dc284d2bbfae1923 -> tool:nanobot-harness-v3:call_260b68ff918e46a5b0ce45da -> tool:nanobot-harness-v3:call_240191b18ec54dc08ca3b59b -> tool:nanobot-harness-v3:call_0d43aaa52b904c128c048876 -> tool:nanobot-harness-v3:call_e9f53da6b2544ebf81f282dc -> tool:nanobot-harness-v3:call_e356fdac374549c483799bcc -> tool:nanobot-harness-v3:call_c552dc52c49e4f379bae35ba -> tool:nanobot-harness-v3:call_6c63fa3ce34144aab3ecd1fe
- 关键路径耗时：0.428124
- Makespan：227.652759
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
