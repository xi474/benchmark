def compute(payload):
    """For each query, for each time slot in [start,end), list domains that are
    unavailable (down or degraded) as observed at as_of, sorted ascending.
    Selection rule: among log records with ingest_time <= as_of and effective_time <= t,
    pick the one with largest effective_time; ties broken by largest ingest_time."""
    queries = payload["queries"]
    log = payload["log"]
    result = []
    for q in queries:
        start = q["start"]
        end = q["end"]
        as_of = q["as_of"]
        # Filter log records visible at as_of
        visible = [(rec[0], rec[1], rec[2], rec[3]) for rec in log if rec[2] <= as_of]
        # Group by domain
        from collections import defaultdict
        domain_records = defaultdict(list)
        for dom, eff, ing, status in visible:
            domain_records[dom].append((eff, ing, status))
        # For each time slot, determine domain states
        slots = []
        for t in range(start, end):
            down_domains = []
            for dom, records in domain_records.items():
                # Find latest record with effective_time <= t
                # Sort by (effective_time, ingest_time) descending, pick first with eff <= t
                best = None
                for eff, ing, status in records:
                    if eff <= t:
                        if best is None or (eff, ing) > (best[0], best[1]):
                            best = (eff, ing, status)
                if best is not None and best[2] != "up":
                    down_domains.append(dom)
            down_domains.sort()
            slots.append(down_domains)
        result.append(slots)
    return result
