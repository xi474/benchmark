def compute(payload):
    """Map service ID to [need, inputs], preserving input order."""
    services = payload["services"]
    result = {}
    for svc in services:
        result[svc["id"]] = [svc["need"], list(svc["inputs"])]
    return result
