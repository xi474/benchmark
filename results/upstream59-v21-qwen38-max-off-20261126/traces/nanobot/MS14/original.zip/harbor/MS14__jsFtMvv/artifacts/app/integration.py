from itertools import combinations


def _eval_service(svc_id, domain_avail, svc_map, cache):
    """Recursively evaluate whether a service or domain is available."""
    if svc_id in cache:
        return cache[svc_id]
    if svc_id not in svc_map:
        # It's a domain
        result = domain_avail.get(svc_id, True)
        cache[svc_id] = result
        return result
    need, inputs = svc_map[svc_id]
    count = 0
    for inp in inputs:
        if _eval_service(inp, domain_avail, svc_map, cache):
            count += 1
            if count >= need:
                cache[svc_id] = True
                return True
    cache[svc_id] = False
    return False


def _check_targets_available(targets, domain_avail, svc_map):
    """Check if all targets are available given domain availability."""
    cache = {}
    for t in targets:
        if not _eval_service(t, domain_avail, svc_map, cache):
            return False
    return True


def _compute_domain_availability_at_slot(t, domain_records, all_domains):
    """Compute which domains are available at time slot t."""
    avail = {}
    for dom in all_domains:
        if dom in domain_records:
            best = None
            for eff, ing, status in domain_records[dom]:
                if eff <= t:
                    if best is None or (eff, ing) > (best[0], best[1]):
                        best = (eff, ing, status)
            if best is not None:
                avail[dom] = (best[2] == "up")
            else:
                avail[dom] = True  # initially up
        else:
            avail[dom] = True
    return avail


def combine(payload, left, right):
    """Combine observed_outages (left) and service_quorums (right) to produce
    incidents and minimal repair sets per query."""
    domains = payload["domains"]
    queries = payload["queries"]
    log = payload["log"]
    svc_map = right  # {svc_id: [need, inputs]}

    results = []
    for qi, q in enumerate(queries):
        start = q["start"]
        end = q["end"]
        as_of = q["as_of"]
        targets = q["targets"]

        # Build domain records filtered by as_of
        from collections import defaultdict
        domain_records = defaultdict(list)
        for rec in log:
            dom, eff, ing, status = rec
            if ing <= as_of:
                domain_records[dom].append((eff, ing, status))

        # Compute per-slot domain availability
        slot_domain_avail = []
        for t in range(start, end):
            avail = {}
            for dom in domains:
                if dom in domain_records:
                    best = None
                    for eff, ing, status in domain_records[dom]:
                        if eff <= t:
                            if best is None or (eff, ing) > (best[0], best[1]):
                                best = (eff, ing, status)
                    if best is not None:
                        avail[dom] = (best[2] == "up")
                    else:
                        avail[dom] = True
                else:
                    avail[dom] = True
            slot_domain_avail.append(avail)

        # Compute per-slot target availability
        slot_target_avail = []
        for si in range(end - start):
            cache = {}
            tgt_avail = {}
            for tgt in targets:
                tgt_avail[tgt] = _eval_service(tgt, slot_domain_avail[si], svc_map, cache)
            slot_target_avail.append(tgt_avail)

        # Compute incidents per target
        incidents = []
        for tgt in sorted(targets):
            i = 0
            while i < end - start:
                if not slot_target_avail[i][tgt]:
                    j = i
                    while j < end - start and not slot_target_avail[j][tgt]:
                        j += 1
                    incidents.append([tgt, start + i, start + j])
                    i = j
                else:
                    i += 1

        # Sort incidents by target ID then start
        incidents.sort(key=lambda x: (x[0], x[1]))

        # Compute minimal repair sets
        # Identify candidate domains: those that are ever unavailable in the window
        # AND are relevant (transitively affect some target)
        def get_relevant_domains(target, svc_m, visited=None):
            if visited is None:
                visited = set()
            if target in visited:
                return set()
            visited.add(target)
            result = set()
            if target not in svc_m:
                result.add(target)
            else:
                _, inputs = svc_m[target]
                for inp in inputs:
                    result |= get_relevant_domains(inp, svc_m, visited)
            return result

        relevant = set()
        for tgt in targets:
            relevant |= get_relevant_domains(tgt, svc_map)

        # Candidate domains: relevant domains that are ever unavailable in window
        candidate_domains = set()
        for si in range(end - start):
            for dom in relevant:
                if dom in slot_domain_avail[si] and not slot_domain_avail[si][dom]:
                    candidate_domains.add(dom)
        candidate_domains = sorted(candidate_domains)

        # Check if no repair needed
        all_ok = all(
            all(slot_target_avail[si][tgt] for tgt in targets)
            for si in range(end - start)
        )
        if all_ok:
            repairs = [[]]
        else:
            # Find all inclusion-minimal repair sets
            # Try increasing sizes
            found_minimal = []
            max_size = len(candidate_domains)

            def is_valid_repair(repair_set):
                """Check if forcing these domains UP makes all targets available at all slots."""
                for si in range(end - start):
                    modified_avail = dict(slot_domain_avail[si])
                    for dom in repair_set:
                        modified_avail[dom] = True
                    cache = {}
                    for tgt in targets:
                        if not _eval_service(tgt, modified_avail, svc_map, cache):
                            return False
                return True

            def has_subset_in(subset_list, candidate):
                """Check if any set in subset_list is a subset of candidate."""
                cand_set = set(candidate)
                for s in subset_list:
                    if all(x in cand_set for x in s):
                        return True
                return False

            for k in range(1, max_size + 1):
                new_found = []
                for combo in combinations(candidate_domains, k):
                    combo_list = list(combo)
                    # Skip if any already-found minimal set is a subset
                    if has_subset_in(found_minimal, combo_list):
                        continue
                    if is_valid_repair(combo_list):
                        new_found.append(combo_list)
                found_minimal.extend(new_found)
                # If we found any at this size, larger supersets containing them
                # won't be minimal, but other combos might still be minimal
                # We must continue checking larger sizes for sets that don't
                # contain any found minimal set as subset
                # Optimization: if all remaining candidates would contain a found
                # minimal set, we can stop. But that's hard to check, so just continue.

            # Sort: by size first, then lexicographically
            found_minimal.sort(key=lambda x: (len(x), x))
            repairs = found_minimal

        results.append({
            "incidents": incidents,
            "repairs": repairs
        })

    return results
