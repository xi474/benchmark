# Workflow 可观测性报告

- Trial：`MS23__Lg83H9Q__env`
- Task：`MS23`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（66 节点 / 65 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：66；执行边：65（observed=0，inferred=65）
- Execution Trace Graph：`observed`；temporal_next 边 65，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_0038597dd70b4bb0bc52b965 -> tool:nanobot-harness-v3:call_0415c678abe6428682ee6468 -> tool:nanobot-harness-v3:call_41633c21fe8c4e40b841b091 -> tool:nanobot-harness-v3:call_96dbe6cc031a4126b13e371b -> tool:nanobot-harness-v3:call_008bdfc53cd04882910c6136 -> tool:nanobot-harness-v3:call_7bcf8ee201594618bc988093 -> tool:nanobot-harness-v3:call_77bfd906f9944a96a0251f89 -> tool:nanobot-harness-v3:call_2d729faf214f4960b5cc429b -> tool:nanobot-harness-v3:call_c4ee5565069f439797fdb063 -> tool:nanobot-harness-v3:call_fe6f7545d61545bc9cda68b7 -> tool:nanobot-harness-v3:call_04703329ab104e789f86cec9 -> tool:nanobot-harness-v3:call_d8a481f292514c25a92919de -> tool:nanobot-harness-v3:call_df876f98c6504dcaaa3157db -> tool:nanobot-harness-v3:call_3fbac5eb636b45028d6c02b7 -> tool:nanobot-harness-v3:call_b37cdb073d42470fb519da6d -> tool:nanobot-harness-v3:call_b43e0bf90c344cc8858df51d -> tool:nanobot-harness-v3:call_47f02865b8474dc1bddf5343 -> tool:nanobot-harness-v3:call_ca722b25334b46a187b3da38 -> tool:nanobot-harness-v3:call_9300d0a28fd845ffb662be48 -> tool:nanobot-harness-v3:call_1be11af4e4734350ac64f14a -> tool:nanobot-harness-v3:call_8f80d03fadd24dc3bde30790 -> tool:nanobot-harness-v3:call_247a6b0b0f254628952e092d -> tool:nanobot-harness-v3:call_99593e3eb7ca45aba3b96230 -> tool:nanobot-harness-v3:call_8e553a473566405ca1f8991b -> tool:nanobot-harness-v3:call_dfe0ac6e08024ff1a1a76885 -> tool:nanobot-harness-v3:call_304a0dc1dad94627b8b36734 -> tool:nanobot-harness-v3:call_66557107994343eda21f189e -> tool:nanobot-harness-v3:call_6e961f9027534195bfaabd31 -> tool:nanobot-harness-v3:call_c4a23c11e2aa4755b3937ada -> tool:nanobot-harness-v3:call_5d7f86ad6b504a799f1c6ac0 -> tool:nanobot-harness-v3:call_c3265709f9bf48d7a28c95de -> tool:nanobot-harness-v3:call_eef4d07b7159488f864ad6f2 -> tool:nanobot-harness-v3:call_ca8ec323ddfc4897b34974f5 -> tool:nanobot-harness-v3:call_8ce8d0d13a964ca197f95adc -> tool:nanobot-harness-v3:call_47553a442e5f46d19e942d61 -> tool:nanobot-harness-v3:call_652010e217fb46e0b6745829 -> tool:nanobot-harness-v3:call_12c5d23a3b7e441ebe37c7c8 -> tool:nanobot-harness-v3:call_b9974a797691461f873eb9f4 -> tool:nanobot-harness-v3:call_5587b58ce0084fccac3fef65 -> tool:nanobot-harness-v3:call_ab6c1b110dfb4cc29d73b7dd -> tool:nanobot-harness-v3:call_2bb75f8201fb4137964f94a1 -> tool:nanobot-harness-v3:call_afc19d2f16c446a984fc9013 -> tool:nanobot-harness-v3:call_dbf2228fd6c24a8ebd6a0552 -> tool:nanobot-harness-v3:call_45ee483d14bf4f15a5001243 -> tool:nanobot-harness-v3:call_4e57906f4a0f41998dfc84a0 -> tool:nanobot-harness-v3:call_0af9327c46e14df19b2b5da8 -> tool:nanobot-harness-v3:call_fe1fde7c24774957bc7b7d89 -> tool:nanobot-harness-v3:call_7e743c81bded41b7a0c48d3f -> tool:nanobot-harness-v3:call_fdda587e10214a91ae5590a2 -> tool:nanobot-harness-v3:call_a0dfadce2a89405cbc3a6882 -> tool:nanobot-harness-v3:call_f882d3de694b4f22b655a087 -> tool:nanobot-harness-v3:call_9a234a6465f74b66a2053291 -> tool:nanobot-harness-v3:call_a8c1515c024d4084a1ba82e4 -> tool:nanobot-harness-v3:call_67506a7d9bc54d6c9eb9fd7e -> tool:nanobot-harness-v3:call_d4dff1ba020047618d5b2fd8 -> tool:nanobot-harness-v3:call_0d9a2916a1394508bc82a03b -> tool:nanobot-harness-v3:call_df018e29e03d450885d383b0 -> tool:nanobot-harness-v3:call_dca3213ded24471695214f90 -> tool:nanobot-harness-v3:call_34d637b63ba24215ad9e55c7 -> tool:nanobot-harness-v3:call_d3360744dde6410a929fc7db -> tool:nanobot-harness-v3:call_b3b728bf967b4759bb5e1e9d -> tool:nanobot-harness-v3:call_e57e52f380f5406b927e1627 -> tool:nanobot-harness-v3:call_6289765776714450a8b22570 -> tool:nanobot-harness-v3:call_2f3adc4f77c14178967899ea -> tool:nanobot-harness-v3:call_5861b435bf3742db80d44015
- 关键路径耗时：0.955755
- Makespan：288.722918
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
