def compute(payload):
    """为每个快照按 b 生成候选层数组。每层候选为 [按 a,c 行优先的计数向量,该层的中位数净分]，满足边际、禁止格和 ac 上限；按向量字典序。"""
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)

        # Build forbidden set
        forb = set()
        for f in forbidden:
            forb.add(tuple(f))

        # Precompute median scores
        score_table = {}
        for a in range(k):
            for b in range(k):
                for c in range(k):
                    vals = sorted([a, b, c])
                    med = vals[1]
                    if med == k - 1:
                        score_table[(a, b, c)] = 1
                    elif med == 0:
                        score_table[(a, b, c)] = -1
                    else:
                        score_table[(a, b, c)] = 0

        snap_result = []
        for b_val in range(k):
            row_sums = [ab[a][b_val] for a in range(k)]
            col_sums = [bc[b_val][c] for c in range(k)]

            # Check basic [REDACTED] total row sum must equal total col sum
            if sum(row_sums) != sum(col_sums):
                snap_result.append([])
                continue

            upper = [[ac[a][c] for c in range(k)] for a in range(k)]

            # Mark forbidden cells
            is_forb = [[False] * k for _ in range(k)]
            for a in range(k):
                for c in range(k):
                    if (a, b_val, c) in forb:
                        is_forb[a][c] = True
                        upper[a][c] = 0

            # Precompute for each cell, which future cells share its row or column
            # This helps with pruning
            n_cells = k * k

            # For each cell index, precompute the max capacity of remaining cells in same row/col
            # that come after it in the ordering
            row_remaining_cap = [[0] * n_cells for _ in range(k)]
            col_remaining_cap = [[0] * n_cells for _ in range(k)]
            for a in range(k):
                for idx in range(n_cells):
                    cap = 0
                    for c2 in range(k):
                        idx2 = a * k + c2
                        if idx2 > idx and not is_forb[a][c2]:
                            cap += upper[a][c2]
                    row_remaining_cap[a][idx] = cap
            for c in range(k):
                for idx in range(n_cells):
                    cap = 0
                    for a2 in range(k):
                        idx2 = a2 * k + c
                        if idx2 > idx and not is_forb[a2][c]:
                            cap += upper[a2][c]
                    col_remaining_cap[c][idx] = cap

            candidates = []
            mat = [0] * n_cells
            rem_row = list(row_sums)
            rem_col = list(col_sums)

            def backtrack(idx):
                if idx == n_cells:
                    if all(r == 0 for r in rem_row) and all(c == 0 for c in rem_col):
                        vec = list(mat)
                        score = 0
                        for i in range(n_cells):
                            if mat[i] > 0:
                                a = i // k
                                c = i % k
                                score += mat[i] * score_table[(a, b_val, c)]
                        candidates.append((vec, score))
                    return

                a = idx // k
                c = idx % k

                if is_forb[a][c]:
                    if rem_row[a] == 0:
                        backtrack(idx + 1)
                    # If rem_row[a] > 0 but cell is forbidden, infeasible only if
                    # no other cells in this row can absorb it - checked by pruning below
                    else:
                        # Check if remaining cells in row can still absorb rem_row[a]
                        if row_remaining_cap[a][idx] >= rem_row[a]:
                            backtrack(idx + 1)
                    return

                max_val = min(upper[a][c], rem_row[a], rem_col[c])

                # Lower bound: we need rem_row[a] to be achievable by remaining cells in row
                # After assigning v here, remaining row capacity must >= rem_row[a] - v
                # So v >= rem_row[a] - row_remaining_cap[a][idx]
                min_val = max(0, rem_row[a] - row_remaining_cap[a][idx])
                # Similarly for column
                min_val = max(min_val, rem_col[c] - col_remaining_cap[c][idx])

                if min_val > max_val:
                    return

                for v in range(min_val, max_val + 1):
                    mat[idx] = v
                    rem_row[a] -= v
                    rem_col[c] -= v
                    if rem_row[a] >= 0 and rem_col[c] >= 0:
                        backtrack(idx + 1)
                    mat[idx] = 0
                    rem_row[a] += v
                    rem_col[c] += v

            backtrack(0)

            # Sort by vector lexicographically
            candidates.sort(key=lambda x: x[0])
            snap_result.append([[vec, sc] for vec, sc in candidates])

        results.append(snap_result)
    return results
