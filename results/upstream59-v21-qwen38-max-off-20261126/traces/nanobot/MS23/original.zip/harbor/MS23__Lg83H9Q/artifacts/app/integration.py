def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.
    
    left: margin_constraints result - list of [compatible, ac_quota] per snapshot
    right: layer_candidates result - list of per-b candidate arrays per snapshot
    """
    snapshots = payload["snapshots"]
    results = []
    
    for si, snap in enumerate(snapshots):
        mc = left[si]  # [compatible, ac_quota]
        lc = right[si]  # list of per-b candidate arrays
        
        compatible = mc[0]
        ac_quota = mc[1]  # flattened ac in row-major order
        
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)
        
        forb = set()
        for f in forbidden:
            forb.add(tuple(f))
        
        def median_score(a, b, c):
            vals = sorted([a, b, c])
            med = vals[1]
            if med == k - 1:
                return 1
            elif med == 0:
                return -1
            else:
                return 0
        
        if not compatible:
            results.append(None)
            continue
        
        # Check total consistency: sum of ab should equal sum of bc should equal sum of ac
        total_ab = sum(sum(row) for row in ab)
        total_bc = sum(sum(row) for row in bc)
        total_ac = sum(sum(row) for row in ac)
        if total_ab != total_bc or total_bc != total_ac:
            results.append(None)
            continue
        
        # Also check bc marginal compatibility: for each c, sum_b bc[b][c] should be consistent
        # Actually we need: for each c, sum_a ac[a][c] = sum_b bc[b][c]
        col_compat = True
        for c in range(k):
            ac_col = sum(ac[a][c] for a in range(k))
            bc_col = sum(bc[b][c] for b in range(k))
            if ac_col != bc_col:
                col_compat = False
                break
        if not col_compat:
            results.append(None)
            continue
        
        # lc is a list of k arrays (one per b value)
        # Each array element is [vector, score]
        # We need to pick one candidate per b and check ac constraint
        
        # Build candidate lists per b
        b_candidates = []
        for b_val in range(k):
            b_candidates.append(lc[b_val])
        
        # If any b has no candidates, no valid table exists
        if any(len(cands) == 0 for cands in b_candidates):
            results.append(None)
            continue
        
        # Enumerate all combinations
        valid_tables = []  # list of (net_score, table_entries)
        
        # For efficiency, use iterative approach with ac tracking
        # ac_remaining starts as ac_quota
        
        def search(b_idx, ac_remaining, current_net, current_table):
            if b_idx == k:
                # Check ac_remaining is all zeros
                if all(v == 0 for v in ac_remaining):
                    valid_tables.append((current_net, list(current_table)))
                return
            
            for vec, layer_score in b_candidates[b_idx]:
                # Check if this layer fits within remaining ac
                fits = True
                new_ac = list(ac_remaining)
                for i in range(k * k):
                    if vec[i] > new_ac[i]:
                        fits = False
                        break
                    new_ac[i] -= vec[i]
                
                if fits:
                    # Add this layer's entries to current_table
                    entries = []
                    for a in range(k):
                        for c in range(k):
                            val = vec[a * k + c]
                            if val > 0:
                                entries.append((a, b_idx, c, val))
                    
                    current_table.extend(entries)
                    search(b_idx + 1, new_ac, current_net + layer_score, current_table)
                    # Remove entries
                    for _ in entries:
                        current_table.pop()
        
        search(0, list(ac_quota), 0, [])
        
        if len(valid_tables) == 0:
            results.append(None)
            continue
        
        num_tables = len(valid_tables)
        
        # Compute spectrum: group by net score, count tables per score
        from collections import Counter
        score_counts = Counter()
        for net, _ in valid_tables:
            score_counts[net] += 1
        
        spectrum = sorted([[score, count] for score, count in score_counts.items()], key=lambda x: x[0])
        
        # Guaranteed: cells that have >0 count in ALL valid tables
        # For each cell (a,b,c), find minimum count across all tables
        # A cell is guaranteed if its minimum count > 0
        
        # Build full table representation for each valid table
        all_tables = []
        for net, entries in valid_tables:
            tbl = {}
            for a, b, c, v in entries:
                tbl[(a, b, c)] = v
            all_tables.append(tbl)
        
        # Find all cells that appear in any table
        all_cells = set()
        for tbl in all_tables:
            all_cells.update(tbl.keys())
        
        guaranteed = []
        for cell in sorted(all_cells):
            min_count = min(tbl.get(cell, 0) for tbl in all_tables)
            if min_count > 0:
                guaranteed.append([cell[0], cell[1], cell[2], min_count])
        
        # Witness: the table with lowest net score; among ties, 
        # the one whose full cell vector (including zeros, in a->b->c order) is lex smallest
        # But only output non-zero entries
        
        # Sort valid_tables by (net_score, full_vector_lex)
        def make_full_vector(entries):
            """Create full k*k*k vector in a->b->c order."""
            vec = [0] * (k * k * k)
            for a, b, c, v in entries:
                vec[a * k * k + b * k + c] = v
            return vec
        
        # Sort by net score first, then by full vector lexicographically
        valid_tables.sort(key=lambda x: (x[0], make_full_vector(x[1])))
        
        witness_entries = valid_tables[0][1]
        # Sort witness entries by a, b, c
        witness_entries_sorted = sorted(witness_entries, key=lambda e: (e[0], e[1], e[2]))
        witness = [[a, b, c, v] for a, b, c, v in witness_entries_sorted]
        
        results.append({
            "tables": num_tables,
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": witness
        })
    
    return results
