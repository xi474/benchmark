# Workflow 可观测性报告

- Trial：`MS28__xhJ2sFu__env`
- Task：`MS28`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_b2a40ad6fdef4ab284189214 -> tool:nanobot-harness-v3:call_86c90fe91b3344e0b5419283 -> tool:nanobot-harness-v3:call_eaace86c6e9b498b836c3d89 -> tool:nanobot-harness-v3:call_9222b2de2f7e4516abe33f0a -> tool:nanobot-harness-v3:call_64d29d4485e147ed843ae144 -> tool:nanobot-harness-v3:call_d7a0ee9b222f40f986c5c5df -> tool:nanobot-harness-v3:call_3fde1aa23ee4477c8816a9de -> tool:nanobot-harness-v3:call_9fdda58ce9f34e05abf48fe0 -> tool:nanobot-harness-v3:call_e94e43d4d0f04fb4ab307612 -> tool:nanobot-harness-v3:call_9c09e88dbb6642ee82d73fca -> tool:nanobot-harness-v3:call_adc87a645a014b25924234f8 -> tool:nanobot-harness-v3:call_614231c37ca341bcb095b8d4 -> tool:nanobot-harness-v3:call_e2099322a28946d5ad08e7fa -> tool:nanobot-harness-v3:call_c1c9edd8c28c4742b44c4cff -> tool:nanobot-harness-v3:call_4cc2083926484c59881366a6 -> tool:nanobot-harness-v3:call_dd2ed96540714b9a8aa3429d -> tool:nanobot-harness-v3:call_af4460d85a6c4f529492ca41 -> tool:nanobot-harness-v3:call_83a7890b417f49dcb3da3a84 -> tool:nanobot-harness-v3:call_44906172315d4713b4b57646 -> tool:nanobot-harness-v3:call_f6efb13542d74c74b14b5f20 -> tool:nanobot-harness-v3:call_a337b69da0bc40938a9afe1a -> tool:nanobot-harness-v3:call_1d8e1e3d20964e729659841c -> tool:nanobot-harness-v3:call_4d96aa841f3e4b46806228ff -> tool:nanobot-harness-v3:call_339ff488988f4eb49f44c8d7 -> tool:nanobot-harness-v3:call_5d66a412c9df42cda937bc53 -> tool:nanobot-harness-v3:call_8f5b6d9009a04545a345317c -> tool:nanobot-harness-v3:call_0c74decc95f0482994f926f4 -> tool:nanobot-harness-v3:call_e21a72f87f17473692c4f8e4 -> tool:nanobot-harness-v3:call_539c922ba6d74542b722d9f6 -> tool:nanobot-harness-v3:call_f70257e3e85c481db55459c4 -> tool:nanobot-harness-v3:call_14305d22d5974c838519e0a6 -> tool:nanobot-harness-v3:call_a0040c8a6bfa46398b3ef5f6 -> tool:nanobot-harness-v3:call_d2ed852c45f84b5d818dad28 -> tool:nanobot-harness-v3:call_220f54398b284a9bb63ba96b -> tool:nanobot-harness-v3:call_b384c9c78a9447049f901635 -> tool:nanobot-harness-v3:call_d896032a2e2f459bbbe38a2b -> tool:nanobot-harness-v3:call_f47450f285394960a6e19a28
- 关键路径耗时：0.431707
- Makespan：84.366771
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
