def compute(payload):
    """为有截止日的作业返回 [需求,合格时段 ID 升序数组]，先按原始时段和七天半开窗口筛选。"""
    assignments = payload["assignments"]
    slots = payload["slots"]
    # Build slot lookup: slot_id -> day
    slot_day = {}
    for s in slots:
        slot_day[s[0]] = s[1]
    result = {}
    for a in assignments:
        aid, due, demand, slot_ids = a[0], a[1], a[2], a[3]
        if due is None:
            continue
        # Filter slots: due - 7 <= day < due
        valid = sorted([sid for sid in slot_ids if sid in slot_day and (due - 7) <= slot_day[sid] < due])
        result[aid] = [demand, valid]
    return result
