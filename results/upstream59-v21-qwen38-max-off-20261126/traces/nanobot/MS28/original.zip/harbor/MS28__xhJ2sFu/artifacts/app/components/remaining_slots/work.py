def compute(payload):
    """每个撤回情景返回仍可用的时段映射，时段 ID 对应 [时刻,容量]。"""
    slots = payload["slots"]
    withdrawals = payload["withdrawals"]
    # Build full slot map
    all_slots = {}
    for s in slots:
        all_slots[s[0]] = [s[1], s[2]]  # [day, capacity]
    result = []
    for w in withdrawals:
        withdrawn = set(w)
        remaining = {sid: [v[0], v[1]] for sid, v in all_slots.items() if sid not in withdrawn}
        result.append(remaining)
    return result
