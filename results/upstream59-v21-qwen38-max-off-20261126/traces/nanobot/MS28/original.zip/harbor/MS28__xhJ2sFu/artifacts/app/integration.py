from math import gcd
from itertools import combinations


def _reduce_fraction(num, den):
    g = gcd(num, den)
    return [num // g, den // g]


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md.

    left: dict  assignment_id -> [demand, [valid_slot_ids_sorted]]   (only assignments with due dates)
    right: list of dicts  slot_id -> [day, capacity]  (one per withdrawal scenario)
    """
    # left keys are all assignments that have a due date
    due_assignments = left  # {aid: [demand, [slot_ids]]}
    results = []

    for scenario_remaining in right:
        # For this withdrawal scenario, determine valid slots per assignment
        # An assignment's valid slots = intersection of its deadline-window slots and remaining slots
        active = {}  # aid -> (demand, set_of_valid_slot_ids)
        for aid, (demand, window_slots) in due_assignments.items():
            valid = [s for s in window_slots if s in scenario_remaining]
            if valid:
                active[aid] = (demand, set(valid))
            else:
                active[aid] = (demand, set())

        # Check for unserved assignments (have due date but no valid slots)
        unserved = sorted([aid for aid, (d, slots_set) in active.items() if len(slots_set) == 0])
        if unserved:
            results.append({"unserved": unserved})
            continue

        # If no assignments with due dates at all
        if not active:
            results.append({"empty": True})
            continue

        # Build slot capacity map for this scenario
        slot_cap = {sid: v[1] for sid, v in scenario_remaining.items()}

        aids = sorted(active.keys())
        n = len(aids)
        aid_idx = {a: i for i, a in enumerate(aids)}

        # Precompute demands and slot sets
        demands = [active[a][0] for a in aids]
        slot_sets = [active[a][1] for a in aids]

        # Find max load ratio over all non-empty subsets
        # Load ratio of S = sum(demands in S) / sum(capacities of union of slots in S)
        # We need to find peak ratio and all tight sets (achieving peak)

        best_num = 0
        best_den = 1
        tight_sets = []  # list of frozensets of indices

        # Enumerate all non-empty subsets (max 14 assignments per component, so 2^14 = 16384)
        for mask in range(1, 1 << n):
            total_demand = 0
            union_slots = set()
            for i in range(n):
                if mask & (1 << i):
                    total_demand += demands[i]
                    union_slots |= slot_sets[i]
            total_cap = sum(slot_cap[s] for s in union_slots)
            # Compare total_demand / total_cap with best_num / best_den
            # total_demand * best_den vs best_num * total_cap
            lhs = total_demand * best_den
            rhs = best_num * total_cap
            if lhs > rhs:
                best_num = total_demand
                best_den = total_cap
                tight_sets = [frozenset(i for i in range(n) if mask & (1 << i))]
            elif lhs == rhs:
                tight_sets.append(frozenset(i for i in range(n) if mask & (1 << i)))

        peak = _reduce_fraction(best_num, best_den)
        count = len(tight_sets)

        # Minimal tight sets by inclusion
        minimal_fs = []
        for ts in tight_sets:
            is_minimal = True
            for other in tight_sets:
                if other != ts and other < ts:  # proper subset
                    is_minimal = False
                    break
            if is_minimal:
                minimal_fs.append(ts)

        # Convert to sorted lists, sort by length then lexicographically
        minimal_lists = [sorted([aids[i] for i in fs]) for fs in minimal_fs]
        minimal_lists.sort(key=lambda x: (len(x), x))

        # implies: for each assignment appearing in at least one tight set,
        # list the other assignments that appear in EVERY tight set containing it
        # Only include assignments that appear in at least one tight set
        appears_in_tight = set()
        for ts in tight_sets:
            for i in ts:
                appears_in_tight.add(i)

        implies = []
        for idx in sorted(appears_in_tight):
            aid = aids[idx]
            # Find all tight sets containing idx
            containing = [ts for ts in tight_sets if idx in ts]
            # Intersection of all these sets, minus idx itself
            common = containing[0]
            for ts in containing[1:]:
                common = common & ts
            others = sorted([aids[j] for j in common if j != idx])
            implies.append([aid, others])

        results.append({
            "peak": peak,
            "count": count,
            "minimal": minimal_lists,
            "implies": implies
        })

    return results
