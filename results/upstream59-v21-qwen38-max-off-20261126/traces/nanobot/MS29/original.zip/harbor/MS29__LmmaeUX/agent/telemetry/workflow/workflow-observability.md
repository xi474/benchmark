# Workflow 可观测性报告

- Trial：`MS29__LmmaeUX__env`
- Task：`MS29`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_505de46faa264ae5a02d6dde -> tool:nanobot-harness-v3:call_045465f8d96c45cdb010f9d4 -> tool:nanobot-harness-v3:call_badecedb4b4a469bbda6fc03 -> tool:nanobot-harness-v3:call_da4213a076f740cdbbee3e93 -> tool:nanobot-harness-v3:call_a880d2e4952e42c8ac36bbbc -> tool:nanobot-harness-v3:call_fda5cf263bc8456eb72ba550 -> tool:nanobot-harness-v3:call_4f59ba314924409aab2596d4 -> tool:nanobot-harness-v3:call_ac3eeb4e71d5496a843c5eda -> tool:nanobot-harness-v3:call_bd7cb234c54747f8894d5a16 -> tool:nanobot-harness-v3:call_81fa243ae3e343d19f501f46 -> tool:nanobot-harness-v3:call_8165b9bbf5594a6ab740372b -> tool:nanobot-harness-v3:call_21d26dee0eab4f42afdd236d -> tool:nanobot-harness-v3:call_cbf418edee0e42ddb375f426 -> tool:nanobot-harness-v3:call_bd65b0c5aff647c88217a0cc -> tool:nanobot-harness-v3:call_2da91621d76e4191be6a71d7 -> tool:nanobot-harness-v3:call_75eea67ab1934c80bb77b5f1 -> tool:nanobot-harness-v3:call_4d365ae5235f4d639726c47a -> tool:nanobot-harness-v3:call_5c4659b993fd4f0381ec0cb6 -> tool:nanobot-harness-v3:call_ea8eb676705b40828df67850 -> tool:nanobot-harness-v3:call_5cdc113d07074f0eb0eb3ed4 -> tool:nanobot-harness-v3:call_eec119ca87d94692bd29cdcd -> tool:nanobot-harness-v3:call_535989ed2afb4d9da157b9c6 -> tool:nanobot-harness-v3:call_35b45db8fb014259912c0b44 -> tool:nanobot-harness-v3:call_d92f67ecd56b460e8fb25692 -> tool:nanobot-harness-v3:call_c43912cff88c4d9da040823c -> tool:nanobot-harness-v3:call_0e8d18cecbe045679f19a3fc -> tool:nanobot-harness-v3:call_7700a5874b104225b4126c71 -> tool:nanobot-harness-v3:call_51250f148947459094161a8c -> tool:nanobot-harness-v3:call_cf93d6ecae2f4219b959675f -> tool:nanobot-harness-v3:call_9ba01da80fc3448ab6ff38b4 -> tool:nanobot-harness-v3:call_958ee78594bc44e1a9e07370 -> tool:nanobot-harness-v3:call_579ba7d3cffb4f66b6f440e1 -> tool:nanobot-harness-v3:call_3f89f9ae64794ec79c2a0bf2 -> tool:nanobot-harness-v3:call_a06acd47c5f744a79769fc4c -> tool:nanobot-harness-v3:call_ad1dbf3a3514413b88a776cb -> tool:nanobot-harness-v3:call_09199fbe02804d87a277453a -> tool:nanobot-harness-v3:call_768d8124acf142959257312c -> tool:nanobot-harness-v3:call_1701f712952d4a9d8bf71f27 -> tool:nanobot-harness-v3:call_7d549d6815474e89bed801e6
- 关键路径耗时：0.393516
- Makespan：132.683
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
