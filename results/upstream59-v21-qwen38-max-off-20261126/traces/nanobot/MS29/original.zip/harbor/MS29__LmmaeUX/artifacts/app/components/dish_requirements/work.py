from itertools import combinations


def compute(payload):
    """返回合格的三类菜品组合及合并需求，格式 [菜品 ID 数组,原料到数量映射]，按菜品字典序枚举。"""
    dishes = payload["dishes"]
    max_diff = payload["max_difficulty"]

    # Filter by difficulty
    eligible = []
    for d in dishes:
        did, cat, diff, ing = d[0], d[1], d[2], d[3]
        if diff <= max_diff:
            eligible.append((did, cat, ing))

    # Group by category
    from collections import defaultdict
    by_cat = defaultdict(list)
    for did, cat, ing in eligible:
        by_cat[cat].append((did, ing))

    cats = sorted(by_cat.keys())
    results = []

    # Enumerate all triples of distinct categories
    for c_combo in combinations(cats, 3):
        # For each combination of categories, pick one dish from each
        dish_lists = [by_cat[c] for c in c_combo]
        _enumerate_combos(dish_lists, [], results)

    # Sort by sorted dish ID tuple (lexicographic)
    results.sort(key=lambda x: x[0])
    return results


def _enumerate_combos(dish_lists, chosen, results):
    if len(chosen) == len(dish_lists):
        ids = sorted([c[0] for c in chosen])
        merged = {}
        for _, ing in chosen:
            for k, v in ing.items():
                merged[k] = merged.get(k, 0) + v
        results.append([ids, merged])
        return
    idx = len(chosen)
    for did, ing in dish_lists[idx]:
        _enumerate_combos(dish_lists, chosen + [(did, ing)], results)
