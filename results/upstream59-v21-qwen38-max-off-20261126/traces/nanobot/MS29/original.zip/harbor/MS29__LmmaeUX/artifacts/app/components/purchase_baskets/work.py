def compute(payload):
    """输出所有限量采购篮 [总价,总件数,按排序后 offer 的购买数量向量]；按这三项升序排列。"""
    offers = payload["offers"]
    # Sort offers by offer ID
    sorted_offers = sorted(offers, key=lambda o: o[0])
    n = len(sorted_offers)

    # Enumerate all possible purchase vectors
    baskets = []
    _enumerate(sorted_offers, n, 0, [0] * n, 0, 0, baskets)

    # Sort by (cost, total_items, buy_vector)
    baskets.sort(key=lambda b: (b[0], b[1], b[2]))
    return baskets


def _enumerate(offers, n, idx, vec, cost, items, out):
    if idx == n:
        out.append([cost, items, list(vec)])
        return
    oid, contents, price, max_packs = offers[idx]
    for q in range(max_packs + 1):
        vec[idx] = q
        _enumerate(offers, n, idx + 1, vec,
                   cost + q * price, items + q, out)
    vec[idx] = 0
