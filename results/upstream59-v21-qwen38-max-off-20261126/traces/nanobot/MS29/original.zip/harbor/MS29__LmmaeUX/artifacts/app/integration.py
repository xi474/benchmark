from itertools import product
from collections import defaultdict


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    stock = payload.get("stock", {})
    offers = payload.get("offers", [])
    prep_defs = payload.get("prep", [])

    # Sort offers by ID to get canonical order
    sorted_offers = sorted(offers, key=lambda o: o[0])
    offer_contents = []  # list of {material: qty} per offer (sorted order)
    for o in sorted_offers:
        offer_contents.append(o[1])

    # Parse prep definitions
    preps = []  # (prep_id, consumes_dict, produces_dict, max_exec)
    for p in prep_defs:
        preps.append((p[0], dict(p[1]), dict(p[2]), p[3]))

    # left = dish_requirements result: list of [dish_ids, merged_ingredients]
    # right = purchase_baskets result: list of [cost, items, buy_vector]

    results = []
    for dish_ids, requirements in left:
        plan = _find_best_plan(stock, sorted_offers, offer_contents,
                               preps, requirements, right)
        results.append({"dishes": dish_ids, "plan": plan})

    return results


def _add_inventory(inv, materials, multiplier=1):
    """Add materials to inventory."""
    result = dict(inv)
    for k, v in materials.items():
        result[k] = result.get(k, 0) + v * multiplier
    return result


def _subtract_inventory(inv, materials):
    """Subtract materials from inventory. Returns None if insufficient."""
    result = dict(inv)
    for k, v in materials.items():
        result[k] = result.get(k, 0) - v
        if result[k] < 0:
            return None
    return result


def _can_execute(inv, consumes):
    """Check if we have enough materials to execute a prep step."""
    for k, v in consumes.items():
        if inv.get(k, 0) < v:
            return False
    return True


def _satisfies(inv, requirements):
    """Check if inventory satisfies all requirements."""
    for k, v in requirements.items():
        if inv.get(k, 0) < v:
            return False
    return True


def _leftover(inv, requirements):
    """Compute leftover after satisfying requirements. Only positive entries."""
    left = {}
    all_keys = set(inv.keys()) | set(requirements.keys())
    for k in all_keys:
        val = inv.get(k, 0) - requirements.get(k, 0)
        if val > 0:
            left[k] = val
    return left


def _find_best_plan(stock, sorted_offers, offer_contents, preps,
                    requirements, baskets):
    """Find the best plan for a given dish combination.
    
    Baskets are pre-sorted by (cost, items, buy_vector).
    For each basket, find minimal prep solution.
    Return first feasible (optimal by tiebreak).
    """
    best = None

    for cost, total_items, buy_vec in baskets:
        # Compute initial inventory from stock + purchases
        inv = dict(stock)
        for i, qty in enumerate(buy_vec):
            if qty > 0:
                inv = _add_inventory(inv, offer_contents[i], qty)

        # Check if already satisfied without any prep
        if _satisfies(inv, requirements):
            left = _leftover(inv, requirements)
            candidate = {
                "cost": cost,
                "buy": buy_vec,
                "steps": [],
                "left": left
            }
            if best is None or _plan_better(candidate, best):
                best = candidate
            # Since baskets are sorted by cost/items/buy_vec,
            # no future basket can beat this on first 3 criteria.
            # But we still need to check if same cost/items/buy_vec
            # could have fewer preps (0 is already minimal).
            # With 0 preps, this is optimal for this basket.
            # Continue to check other baskets with same cost? No -
            # 0 preps is already minimal. But another basket with same
            # cost could also have 0 preps. However since buy_vec differs
            # and we want lex smallest buy_vec, current one wins.
            # Actually wait - baskets are sorted by (cost, items, buy_vec)
            # so the first feasible one with 0 preps is optimal.
            if len(best["steps"]) == 0:
                return best
            continue

        # Need prep steps. Find minimal sequence via BFS.
        prep_result = _find_min_prep_sequence(inv, preps, requirements, 16)
        if prep_result is not None:
            steps, final_inv = prep_result
            left = _leftover(final_inv, requirements)
            candidate = {
                "cost": cost,
                "buy": buy_vec,
                "steps": steps,
                "left": left
            }
            if best is None or _plan_better(candidate, best):
                best = candidate
                # If this basket has strictly lower cost than any future,
                # we can potentially stop. But we need to be careful about
                # tiebreaking. Only stop if no future basket can match cost.
                # For safety, continue checking.

    return best


def _plan_better(a, b):
    """Return True if plan a is better than plan b."""
    # 1. cost
    if a["cost"] != b["cost"]:
        return a["cost"] < b["cost"]
    # 2. total packs
    a_packs = sum(a["buy"])
    b_packs = sum(b["buy"])
    if a_packs != b_packs:
        return a_packs < b_packs
    # 3. buy vector lex
    if a["buy"] != b["buy"]:
        return a["buy"] < b["buy"]
    # 4. total prep steps
    if len(a["steps"]) != len(b["steps"]):
        return len(a["steps"]) < len(b["steps"])
    # 5. step sequence lex
    return a["steps"] < b["steps"]


def _find_min_prep_sequence(inv, preps, requirements, max_steps):
    """BFS to find shortest valid prep sequence.
    Among same-length sequences, return lexicographically smallest.
    Returns (steps_list, final_inventory) or None.
    """
    # State: frozenset of inventory counts
    # We do BFS by number of steps
    # At each level, try all possible prep executions in sorted order
    
    # Sort preps by ID for lex ordering
    sorted_preps = sorted(preps, key=lambda p: p[0])
    
    # BFS: queue entries are (inventory_dict, steps_list, remaining_counts)
    # remaining_counts tracks how many times each prep can still be executed
    
    init_remaining = tuple(p[3] for p in sorted_preps)
    
    # Use iterative deepening or plain BFS
    # Given max 16 steps and small state space, BFS should work
    
    from collections import deque
    
    def inv_key(inv_dict):
        return tuple(sorted((k, v) for k, v in inv_dict.items() if v > 0))
    
    start_key = inv_key(inv)
    visited = {(start_key, init_remaining)}
    
    queue = deque()
    queue.append((dict(inv), [], init_remaining))
    
    while queue:
        cur_inv, cur_steps, cur_remaining = queue.popleft()
        
        if len(cur_steps) >= max_steps:
            continue
        
        # Try each prep in sorted order
        for pi, (pid, consumes, produces, max_exec) in enumerate(sorted_preps):
            if cur_remaining[pi] <= 0:
                continue
            if not _can_execute(cur_inv, consumes):
                continue
            
            # Execute this prep
            new_inv = _subtract_inventory(cur_inv, consumes)
            new_inv = _add_inventory(new_inv, produces)
            new_remaining = list(cur_remaining)
            new_remaining[pi] -= 1
            new_remaining = tuple(new_remaining)
            new_steps = cur_steps + [pid]
            
            # Check if requirements satisfied
            if _satisfies(new_inv, requirements):
                return (new_steps, new_inv)
            
            nk = (inv_key(new_inv), new_remaining)
            if nk not in visited:
                visited.add(nk)
                queue.append((new_inv, new_steps, new_remaining))
    
    return None
