# Workflow 可观测性报告

- Trial：`MS30__pQvYD8m__env`
- Task：`MS30`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（50 节点 / 49 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：50；执行边：49（observed=0，inferred=49）
- Execution Trace Graph：`observed`；temporal_next 边 49，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_39955a208f804169875b43f2 -> tool:nanobot-harness-v3:call_4cc06e42a88149e182420905 -> tool:nanobot-harness-v3:call_e2e1bb867a794bef92ad8454 -> tool:nanobot-harness-v3:call_8df7ee4ce2174c9e9a3a33bf -> tool:nanobot-harness-v3:call_8046d7839e3148fc9d79eb30 -> tool:nanobot-harness-v3:call_d4ada0a4aa7e4abdab892e31 -> tool:nanobot-harness-v3:call_a8b578730fdd4a6e90fda787 -> tool:nanobot-harness-v3:call_2428a50919184dfcb5698e98 -> tool:nanobot-harness-v3:call_31f3a5ce6eb047a092345378 -> tool:nanobot-harness-v3:call_2ff79c2a998c409387cef2db -> tool:nanobot-harness-v3:call_544f0bd35ce14e7582b7a510 -> tool:nanobot-harness-v3:call_7d492b5cfd45437eb9297929 -> tool:nanobot-harness-v3:call_190ff93882114fad90d1b2be -> tool:nanobot-harness-v3:call_35f3c66c16304c528c0514c3 -> tool:nanobot-harness-v3:call_b3cd25138cae4bf783db8702 -> tool:nanobot-harness-v3:call_59b077bdbe294204a9e1b167 -> tool:nanobot-harness-v3:call_886edb28f73242b1a2f0c96c -> tool:nanobot-harness-v3:call_efd643ceb6ca4e76865bf070 -> tool:nanobot-harness-v3:call_d93ea6991d074357b73d5bae -> tool:nanobot-harness-v3:call_852ce7cfb40742fea1e63b53 -> tool:nanobot-harness-v3:call_10359ccea5c3449c9a6783f1 -> tool:nanobot-harness-v3:call_97eefa6db4e946c4a41cb28e -> tool:nanobot-harness-v3:call_b18ea5310ee4448da47f0bbc -> tool:nanobot-harness-v3:call_50a9efdf80b74773b09ae2f2 -> tool:nanobot-harness-v3:call_67e918aa9cf5451992f8f14c -> tool:nanobot-harness-v3:call_0a2bacc9d5cd47ecbe50c931 -> tool:nanobot-harness-v3:call_55d852f6f3ff476f98f9f4af -> tool:nanobot-harness-v3:call_7d9990b95bd54c82963c25b9 -> tool:nanobot-harness-v3:call_71050c4e6cb54243a86c7430 -> tool:nanobot-harness-v3:call_06d756b501074e6385ec2667 -> tool:nanobot-harness-v3:call_2d91f856e6fd4811b53b1652 -> tool:nanobot-harness-v3:call_e93c401de5824083b3ec964a -> tool:nanobot-harness-v3:call_efe327402a4c45a19e89a85f -> tool:nanobot-harness-v3:call_17456c0d7dec44ebb5c11695 -> tool:nanobot-harness-v3:call_8daf90b72f5f4d809a8e46ad -> tool:nanobot-harness-v3:call_83c789e67a3449c1985f4ec4 -> tool:nanobot-harness-v3:call_189976b3388b4e4badddc2d1 -> tool:nanobot-harness-v3:call_de7d273da70b4eccb861568f -> tool:nanobot-harness-v3:call_4631252382e340c899789e0b -> tool:nanobot-harness-v3:call_5337505024c64b219d32a5e6 -> tool:nanobot-harness-v3:call_9342df87164d46878a6196f1 -> tool:nanobot-harness-v3:call_6120619cba334c94bb4491b8 -> tool:nanobot-harness-v3:call_776d7325f1e4435d98b9ac8c -> tool:nanobot-harness-v3:call_3471daa12b6d43d3a013872b -> tool:nanobot-harness-v3:call_599154a14a8f493b9317a177 -> tool:nanobot-harness-v3:call_5841f175b60c449eae8d95dd -> tool:nanobot-harness-v3:call_56a4a2bbbd634ae29e22afbb -> tool:nanobot-harness-v3:call_8e49c2a953fd4f1f8e6ff3e8 -> tool:nanobot-harness-v3:call_33a82b6d00f24684bd94ce47
- 关键路径耗时：0.764691
- Makespan：240.163782
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
