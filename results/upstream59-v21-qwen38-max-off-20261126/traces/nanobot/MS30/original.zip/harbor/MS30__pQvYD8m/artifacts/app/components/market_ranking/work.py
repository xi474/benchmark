def compute(payload):
    """按最新市场日的 30 天窗口、相对绝对涨跌幅和代号打破平局，返回前 top 个房间代号（保持排名）。"""
    market = payload["market"]
    top = payload["top"]

    # Find last teaching day L
    L = max(row[1] for row in market)

    # Filter events within [L-29, L]
    window_start = L - 29
    filtered = [row for row in market if window_start <= row[1] <= L]

    # Sort by abs(close-open)/open descending, then event ID ascending
    def sort_key(row):
        event_id, day, open_price, close_price = row[0], row[1], row[2], row[3]
        ratio = abs(close_price - open_price) / open_price
        return (-ratio, event_id)

    filtered.sort(key=sort_key)

    # Return top event IDs
    return [row[0] for row in filtered[:top]]
