from fractions import Fraction


def compute(payload):
    """使用 16、17 号课程非空成绩的精确分数比，按原门槛输出学生到 P/D/N 层级映射。"""
    grades = payload["grades"]
    # Collect scores per student for courses 16 and 17 (non-null)
    student_scores = {}  # student -> list of Fraction(score, max)
    for row in grades:
        student, course, score, max_score = row[0], row[1], row[2], row[3]
        if course not in (16, 17):
            continue
        if score is None:
            continue
        student_scores.setdefault(student, []).append(Fraction(score, max_score))

    result = {}
    threshold_n = Fraction(60, 100)   # 0.60
    threshold_d = Fraction(75, 100)   # 0.75

    for student, ratios in student_scores.items():
        avg = sum(ratios) / len(ratios)
        if avg < threshold_n:
            tier = "N"
        elif avg < threshold_d:
            tier = "D"
        else:
            tier = "P"
        result[student] = tier

    return result
