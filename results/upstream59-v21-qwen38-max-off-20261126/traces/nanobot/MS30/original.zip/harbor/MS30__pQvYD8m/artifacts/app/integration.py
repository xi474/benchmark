def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    tiers_map = left       # student -> "P"/"D"/"N"
    ranked_events = right  # ordered list of top event IDs

    rooms = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]

    results = []
    for cancelled in cancel_list:
        cancelled_set = set(cancelled)
        open_events = [e for e in ranked_events if e not in cancelled_set]
        open_set = set(open_events)

        students = sorted(tiers_map.keys())
        n = len(students)

        # Room tier priority: list of sets, highest priority first
        room_tier_sets = {}
        room_capacity = {}
        for ev in open_events:
            rinfo = rooms[ev]
            room_capacity[ev] = rinfo["capacity"]
            room_tier_sets[ev] = [set(g) for g in rinfo["tiers"]]

        def room_accepts(event, tier):
            return any(tier in g for g in room_tier_sets[event])

        def room_priority(event, tier):
            for i, g in enumerate(room_tier_sets[event]):
                if tier in g:
                    return i
            return None

        # Student preference groups over open, mutually-acceptable events
        student_pref_groups = {}
        student_acceptable = {}
        for s in students:
            if s not in prefs:
                student_pref_groups[s] = []
                student_acceptable[s] = set()
                continue
            groups = []
            acceptable = set()
            for group in prefs[s]:
                ok = {ev for ev in group if ev in open_set and room_accepts(ev, tiers_map[s])}
                if ok:
                    groups.append(ok)
                    acceptable |= ok
            student_pref_groups[s] = groups
            student_acceptable[s] = acceptable

        def student_strictly_prefers(s, new_ev, cur_ev):
            if cur_ev is None:
                return new_ev in student_acceptable[s]
            if new_ev == cur_ev:
                return False
            new_rank = cur_rank = None
            for i, g in enumerate(student_pref_groups[s]):
                if new_ev in g:
                    new_rank = i
                if cur_ev in g:
                    cur_rank = i
            if new_rank is None:
                return False
            if cur_rank is None:
                return True
            return new_rank < cur_rank

        def room_strictly_prefers(event, s, s2):
            ps = room_priority(event, tiers_map[s])
            ps2 = room_priority(event, tiers_map[s2])
            if ps is None:
                return False
            if ps2 is None:
                return True
            return ps < ps2

        acc_lists = [sorted(student_acceptable[s]) for s in students]

        def is_stable(assignment):
            occ = {ev: [] for ev in open_events}
            for i, ev in enumerate(assignment):
                if ev is not None:
                    occ[ev].append(i)
            for i in range(n):
                s = students[i]
                cur = assignment[i]
                for w in student_acceptable[s]:
                    if not student_strictly_prefers(s, w, cur):
                        continue
                    if room_capacity[w] == 0:
                        continue
                    occupants = occ[w]
                    if len(occupants) < room_capacity[w]:
                        return False
                    for j in occupants:
                        if room_strictly_prefers(w, s, students[j]):
                            return False
            return True

        # Enumerate all valid matchings via backtracking, collect stable ones by size
        all_by_size = {}

        def backtrack(idx, assignment, occ, matched):
            if idx == n:
                if is_stable(assignment):
                    all_by_size.setdefault(matched, []).append(tuple(assignment))
                return
            # Leave unassigned
            assignment.append(None)
            backtrack(idx + 1, assignment, occ, matched)
            assignment.pop()
            # Try each acceptable event with capacity
            for ev in acc_lists[idx]:
                if len(occ[ev]) < room_capacity[ev]:
                    occ[ev].append(idx)
                    assignment.append(ev)
                    backtrack(idx + 1, assignment, occ, matched + 1)
                    assignment.pop()
                    occ[ev].pop()

        backtrack(0, [], {ev: [] for ev in open_events}, 0)

        sizes = sorted([[sz, len(ms)] for sz, ms in all_by_size.items()])

        if all_by_size:
            max_sz = max(all_by_size)
            max_matchings = all_by_size[max_sz]
        else:
            max_sz = 0
            max_matchings = []

        # forced: pairs in every max-size stable matching
        forced = []
        if max_matchings:
            pair_sets = []
            for m in max_matchings:
                ps = {(students[i], ev) for i, ev in enumerate(m) if ev is not None}
                pair_sets.append(ps)
            common = pair_sets[0]
            for ps in pair_sets[1:]:
                common &= ps
            forced = sorted([list(p) for p in common])

        # example: lex-min assignment vector among max matchings
        def vec(m):
            return tuple(ev if ev is not None else "" for ev in m)

        if max_matchings:
            vectors = sorted(vec(m) for m in max_matchings)
            example = list(vectors[0])
        else:
            example = [""] * n

        results.append({"sizes": sizes, "forced": forced, "example": example})

    return results
