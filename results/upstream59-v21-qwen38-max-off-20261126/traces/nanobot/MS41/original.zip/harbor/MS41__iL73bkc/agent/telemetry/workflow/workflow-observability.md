# Workflow 可观测性报告

- Trial：`MS41__iL73bkc__env`
- Task：`MS41`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（53 节点 / 52 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：53；执行边：52（observed=0，inferred=52）
- Execution Trace Graph：`observed`；temporal_next 边 52，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_a407686fa675421a99101153 -> tool:nanobot-harness-v3:call_d8a8fec848d04ad691e1fe2b -> tool:nanobot-harness-v3:call_4848b3b28dec469288508548 -> tool:nanobot-harness-v3:call_0c97b09428e54abea094e7c1 -> tool:nanobot-harness-v3:call_546c20277e4945c292c3c084 -> tool:nanobot-harness-v3:call_294df5859aee4e5e8ce08d1f -> tool:nanobot-harness-v3:call_5808932c04c34dfca8fa7695 -> tool:nanobot-harness-v3:call_0c1dc1f7ef3947f99c86c114 -> tool:nanobot-harness-v3:call_59eccc0a5234483f942db369 -> tool:nanobot-harness-v3:call_5692ab18177a440b84d49973 -> tool:nanobot-harness-v3:call_4d3cb44c0fb84c059e2d0eda -> tool:nanobot-harness-v3:call_923ffcbe657a45fb9df015ec -> tool:nanobot-harness-v3:call_bef038c63cf145299e37bd63 -> tool:nanobot-harness-v3:call_4e1f944db4bb471fbd7b8b48 -> tool:nanobot-harness-v3:call_5469889a87cf4adebfb328dd -> tool:nanobot-harness-v3:call_369b81bb9e0f4d258fc48d07 -> tool:nanobot-harness-v3:call_f1acc82d8d5d4d879131fc6a -> tool:nanobot-harness-v3:call_395f8a9d5a364bab9d33402a -> tool:nanobot-harness-v3:call_579c4ea2dc5a41b6b0ab98a6 -> tool:nanobot-harness-v3:call_ee71334b62ff4d2493334fa5 -> tool:nanobot-harness-v3:call_de6110c8fa5f465fa0a307c6 -> tool:nanobot-harness-v3:call_eac7cf31ebe049f781dc272e -> tool:nanobot-harness-v3:call_d4480364dab24822a1773f97 -> tool:nanobot-harness-v3:call_6881b14d785c4694905d13f3 -> tool:nanobot-harness-v3:call_30cdee90c2384ef8892b37ea -> tool:nanobot-harness-v3:call_a5ec5c6e847242deaea0e76c -> tool:nanobot-harness-v3:call_b8c1a2c8045e427289e5184c -> tool:nanobot-harness-v3:call_04acb4a8b6f34a64a2a408ce -> tool:nanobot-harness-v3:call_edcb27aad17b43f48341f29d -> tool:nanobot-harness-v3:call_f65521c155ec4aa0a0274f61 -> tool:nanobot-harness-v3:call_3707c702b5ae4b7d8d53e192 -> tool:nanobot-harness-v3:call_5399e485a59d49ae8042397a -> tool:nanobot-harness-v3:call_6a0f85cc1bcf482e9a243134 -> tool:nanobot-harness-v3:call_bbb94fa8553f4ff29396799e -> tool:nanobot-harness-v3:call_293f43911f814b37a8440d90 -> tool:nanobot-harness-v3:call_36b525b0775e44b1a7f64bae -> tool:nanobot-harness-v3:call_b1d804e5a47944709c5ee41f -> tool:nanobot-harness-v3:call_4ba873eb47ff4fb6ac8d1e4f -> tool:nanobot-harness-v3:call_2e97fbd92d464816af3f8874 -> tool:nanobot-harness-v3:call_a56e1ee6420b48e5a4ebc6e6 -> tool:nanobot-harness-v3:call_1a9f4b58db544e7687707c50 -> tool:nanobot-harness-v3:call_3042cbb232e4474498ee2313 -> tool:nanobot-harness-v3:call_9d3c66ebaaec48f6b0f78b75 -> tool:nanobot-harness-v3:call_33e62f8061e6447e8da78803 -> tool:nanobot-harness-v3:call_ba07111fd6e14525ae2e5a60 -> tool:nanobot-harness-v3:call_c3e82db6ac624b3690d99730 -> tool:nanobot-harness-v3:call_6490271da6574d74a8ebb7c7 -> tool:nanobot-harness-v3:call_36c56f1953d241b5a5f27fa0 -> tool:nanobot-harness-v3:call_fab4339d69264f4090373c45 -> tool:nanobot-harness-v3:call_9f1231582b174e799868214e -> tool:nanobot-harness-v3:call_f6d8dc7a87d34c0d8229cab6 -> tool:nanobot-harness-v3:call_e5ccc87fbec9484087bcff52
- 关键路径耗时：0.737937
- Makespan：367.93743
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
