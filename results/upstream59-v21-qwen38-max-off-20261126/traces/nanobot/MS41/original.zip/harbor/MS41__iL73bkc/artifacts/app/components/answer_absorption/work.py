from fractions import Fraction


def compute(payload):
    """Per method ID, per profile name: [absorption_probs, weighted_cost_qualities].
    
    absorption_probs[i] = [num, den] probability of single ballot voting for answers[i]
    weighted_cost_qualities[i] = [num, den] = P(vote answers[i]) * E[cost | vote answers[i]]
    
    All fractions simplified. Answers order preserved.
    """
    methods = payload["methods"]
    profiles = payload["profiles"]
    answers = payload["answers"]
    n_answers = len(answers)
    answer_set = set(answers)
    answer_index = {a: i for i, a in enumerate(answers)}

    result = {}
    for method in methods:
        mid = method["id"]
        graphs = method["graphs"]
        start = method["start"]
        method_result = {}
        for pname in profiles:
            graph = graphs[pname]
            # Collect all transient states
            transient_states = sorted(graph.keys())
            n_trans = len(transient_states)
            state_idx = {s: i for i, s in enumerate(transient_states)}

            # For each answer, solve the linear system for f and g
            abs_probs = []
            wcq = []
            for a_idx, answer in enumerate(answers):
                # Solve for f(s, answer) for all transient states s
                # f(s) = sum_e (w_e / W_s) * f(target_e)
                # where f(answer') = delta(answer', answer)
                # Rearranged: f(s) - sum_{transient t} (w_e/W_s)*f(t) = sum_{answer targets} (w_e/W_s)*delta
                # => (I - Q) * f = b

                # Build system: A * x = b where x = f values for transient states
                # Also build system for g simultaneously
                # Actually let's solve them separately for clarity

                # System for f
                A_f = [[Fraction(0)] * n_trans for _ in range(n_trans)]
                b_f = [Fraction(0)] * n_trans
                for si, s in enumerate(transient_states):
                    edges = graph[s]
                    W = sum(e[1] for e in edges)
                    A_f[si][si] = Fraction(1)
                    for target, weight, cost in edges:
                        prob = Fraction(weight, W)
                        if target in answer_set:
                            if target == answer:
                                b_f[si] += prob
                        else:
                            ti = state_idx[target]
                            A_f[si][ti] -= prob

                f_vals = _solve_linear(A_f, b_f, n_trans)

                # System for g
                # g(s) = sum_e (w_e/W_s) * (cost_e * f(target_e) + g(target_e))
                # g(s) - sum_{transient t} (w_e/W_s)*g(t) = sum_e (w_e/W_s)*cost_e*f(target_e)
                # For transient target t: contributes to RHS via cost_e * f(t) and to LHS via -prob*g(t)
                # For answer target a': f(a') = delta, g(a') = 0, so contributes cost_e * delta to RHS
                A_g = [[Fraction(0)] * n_trans for _ in range(n_trans)]
                b_g = [Fraction(0)] * n_trans
                for si, s in enumerate(transient_states):
                    edges = graph[s]
                    W = sum(e[1] for e in edges)
                    A_g[si][si] = Fraction(1)
                    for target, weight, cost in edges:
                        prob = Fraction(weight, W)
                        if target in answer_set:
                            if target == answer:
                                b_g[si] += prob * Fraction(cost)
                        else:
                            ti = state_idx[target]
                            A_g[si][ti] -= prob
                            # f(target) for transient target
                            b_g[si] += prob * Fraction(cost) * f_vals[ti]

                g_vals = _solve_linear(A_g, b_g, n_trans)

                start_idx = state_idx[start]
                f_start = f_vals[start_idx]
                g_start = g_vals[start_idx]

                abs_probs.append([f_start.numerator, f_start.denominator])
                wcq.append([g_start.numerator, g_start.denominator])

            method_result[pname] = [abs_probs, wcq]
        result[mid] = method_result

    return result


def _solve_linear(A, b, n):
    """Solve Ax = b using Gaussian elimination with exact Fraction arithmetic."""
    # Augmented matrix
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    
    # Forward elimination with partial pivoting
    for col in range(n):
        # Find pivot
        pivot_row = None
        for row in range(col, n):
            if M[row][col] != 0:
                pivot_row = row
                break
        if pivot_row is None:
            continue
        # Swap
        M[col], M[pivot_row] = M[pivot_row], M[col]
        # Eliminate
        pivot_val = M[col][col]
        for row in range(n):
            if row == col:
                continue
            if M[row][col] != 0:
                factor = M[row][col] / pivot_val
                for j in range(n + 1):
                    M[row][j] -= factor * M[col][j]
    
    # Back substitution
    x = [Fraction(0)] * n
    for i in range(n):
        if M[i][i] != 0:
            x[i] = M[i][n] / M[i][i]
    
    return x
