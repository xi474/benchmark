from fractions import Fraction


def compute(payload):
    """Output [prior_map, method_decision_tables].
    
    prior_map: {profile_name: [num, den]} simplified fractions summing to 1.
    method_decision_tables: {method_id: {count_state_str: winner_index_or_null}}
    
    count_state_str is comma-separated vote counts per answer.
    A state maps to a winner index if that answer is guaranteed to win
    regardless of how remaining votes are allocated; otherwise null.
    States that are already decided are not expanded further.
    """
    profiles = payload["profiles"]
    methods = payload["methods"]
    answers = payload["answers"]
    n_answers = len(answers)

    # Build prior map: normalize profile weights to simplified fractions
    total_weight = sum(profiles.values())
    prior_map = {}
    for name, w in profiles.items():
        f = Fraction(w, total_weight)
        prior_map[name] = [f.numerator, f.denominator]

    # Build decision tables per method
    decision_tables = {}
    for method in methods:
        mid = method["id"]
        max_votes = method["votes"]
        table = {}
        # BFS from initial state (all zeros)
        initial = tuple([0] * n_answers)
        queue = [initial]
        visited = set()
        while queue:
            state = queue.pop(0)
            if state in visited:
                continue
            visited.add(state)
            total_cast = sum(state)
            # Check if any answer has already won
            winner = _check_winner(state, max_votes, n_answers)
            key = ",".join(str(c) for c in state)
            if winner is not None:
                table[key] = winner
                # Don't expand decided states
                continue
            else:
                table[key] = None
            # Expand: if we haven't used all votes, add one vote for each answer
            if total_cast < max_votes:
                for i in range(n_answers):
                    new_state = list(state)
                    new_state[i] += 1
                    new_state = tuple(new_state)
                    if new_state not in visited:
                        queue.append(new_state)
        decision_tables[mid] = table

    return [prior_map, decision_tables]


def _check_winner(counts, max_votes, n_answers):
    """Check if any answer is guaranteed to win given current counts and max_votes.
    
    Returns the index of the guaranteed winner, or None.
    The leader is the answer with most votes (ties broken by index order).
    The leader is guaranteed if even when ALL remaining votes go to any single
    other answer, the leader still wins (strictly more, or equal with better index).
    """
    total_cast = sum(counts)
    remaining = max_votes - total_cast
    
    if remaining < 0:
        return None
    
    # Find current leader(s)
    max_count = max(counts)
    leaders = [i for i in range(n_answers) if counts[i] == max_count]
    # Leader is the one with smallest index (best tie-break)
    leader = leaders[0]
    
    # Check if leader is guaranteed to win
    # For each other answer j, check if j could beat leader even getting all remaining votes
    guaranteed = True
    for j in range(n_answers):
        if j == leader:
            continue
        # Best case for j: all remaining votes go to j
        j_best = counts[j] + remaining
        leader_count = counts[leader]
        # j beats leader if j_best > leader_count, or j_best == leader_count and j < leader
        if j_best > leader_count:
            guaranteed = False
            break
        if j_best == leader_count and j < leader:
            guaranteed = False
            break
    
    if guaranteed:
        return leader
    return None
