from fractions import Fraction


def combine(payload, left, right):
    """Combine ballot_rules (left) and answer_absorption (right) to produce final output.
    
    left = [prior_map, decision_tables]
    right = {method_id: {profile_name: [abs_probs, wcq]}}
    
    Returns array of method results sorted by correct prob desc, then method id asc.
    """
    answers = payload["answers"]
    correct = payload["correct"]
    n_answers = len(answers)
    correct_idx = answers.index(correct)

    prior_map, decision_tables = left
    absorption_data = right

    results = []
    for method in payload["methods"]:
        mid = method["id"]
        table = decision_tables[mid]
        
        # Aggregate over profiles
        total_prob = [Fraction(0)] * n_answers
        total_unresolved = Fraction(0)
        total_launches = Fraction(0)
        total_cost_correct_num = Fraction(0)  # E[cost * I(winner=correct)]
        total_prob_correct = Fraction(0)

        for pname, prior_frac in prior_map.items():
            prior = Fraction(prior_frac[0], prior_frac[1])
            abs_probs_raw, wcq_raw = absorption_data[mid][pname]
            
            abs_probs = [Fraction(p[0], p[1]) for p in abs_probs_raw]
            wcq = [Fraction(w[0], w[1]) for w in wcq_raw]
            unresolved_ballot = Fraction(1) - sum(abs_probs)

            # DP over count states
            # State key: tuple of counts
            # Track P(state), C(state) = E[cost * I(reach state)]
            initial = tuple([0] * n_answers)
            
            # Use ordered processing by total votes
            P = {initial: Fraction(1)}
            C = {initial: Fraction(0)}
            
            # Process states in BFS order by total votes
            from collections import deque
            queue = deque([initial])
            visited = set()
            
            while queue:
                s = queue.popleft()
                if s in visited:
                    continue
                visited.add(s)
                
                ps = P[s]
                cs = C[s]
                
                if ps == 0:
                    continue
                
                key = ",".join(str(c) for c in s)
                winner = table.get(key)
                
                if winner is not None:
                    # Decided state
                    total_prob[winner] += prior * ps
                    if winner == correct_idx:
                        total_cost_correct_num += prior * cs
                        total_prob_correct += prior * ps
                else:
                    # Not decided: launch a ballot
                    # Unresolved contribution
                    if unresolved_ballot > 0:
                        total_unresolved += prior * ps * unresolved_ballot
                    
                    # Expected launches: each non-decided state visited contributes P(s) launches
                    total_launches += prior * ps
                    
                    # Transitions
                    for a in range(n_answers):
                        if abs_probs[a] == 0:
                            continue
                        s_new = list(s)
                        s_new[a] += 1
                        s_new = tuple(s_new)
                        
                        new_p = ps * abs_probs[a]
                        new_c = cs * abs_probs[a] + ps * wcq[a]
                        
                        if s_new in P:
                            P[s_new] += new_p
                            C[s_new] += new_c
                        else:
                            P[s_new] = new_p
                            C[s_new] = new_c
                            queue.append(s_new)

        # Build result
        prob_out = [[p.numerator, p.denominator] for p in total_prob]
        unresolved_out = [total_unresolved.numerator, total_unresolved.denominator]
        launches_out = [total_launches.numerator, total_launches.denominator]
        
        if total_prob_correct == 0:
            cost_if_correct_out = None
        else:
            cic = total_cost_correct_num / total_prob_correct
            cost_if_correct_out = [cic.numerator, cic.denominator]
        
        results.append({
            "id": mid,
            "prob": prob_out,
            "unresolved": unresolved_out,
            "launches": launches_out,
            "cost_if_correct": cost_if_correct_out,
            "_sort_key": (-total_prob[correct_idx], mid)
        })
    
    # Sort by correct prob descending, then method id ascending
    results.sort(key=lambda r: r["_sort_key"])
    for r in results:
        del r["_sort_key"]
    
    return results
