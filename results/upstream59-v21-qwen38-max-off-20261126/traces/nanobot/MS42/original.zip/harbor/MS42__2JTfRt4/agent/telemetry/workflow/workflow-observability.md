# Workflow 可观测性报告

- Trial：`MS42__2JTfRt4__env`
- Task：`MS42`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（61 节点 / 60 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：61；执行边：60（observed=0，inferred=60）
- Execution Trace Graph：`observed`；temporal_next 边 60，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_761eb315b3134b009b40909e -> tool:nanobot-harness-v3:call_3db9b1fbd46c4feb9c4377db -> tool:nanobot-harness-v3:call_c1a4a8748eba4c6788b8d055 -> tool:nanobot-harness-v3:call_e8fc9eb206114bcaa92fa571 -> tool:nanobot-harness-v3:call_b786d1c52a614ec9ae5e26c9 -> tool:nanobot-harness-v3:call_69175789a56e457b9325d0b1 -> tool:nanobot-harness-v3:call_38853ed786b84746b9245843 -> tool:nanobot-harness-v3:call_e705a64eac8c423fb879340b -> tool:nanobot-harness-v3:call_ff53952c3dd34726987600c2 -> tool:nanobot-harness-v3:call_36684b80f78147fdba1855c8 -> tool:nanobot-harness-v3:call_b93742ca03834406a3a4daa2 -> tool:nanobot-harness-v3:call_adddb8f1209a42d4874de46a -> tool:nanobot-harness-v3:call_ee6dc8c7a3e443f5b13e279a -> tool:nanobot-harness-v3:call_bb34633b652e4b2b986bf09c -> tool:nanobot-harness-v3:call_caed6d86d3d24cd99e3d266d -> tool:nanobot-harness-v3:call_cb1a8ab4ba14412798ff31fb -> tool:nanobot-harness-v3:call_2a66b303a14949e7832ef16a -> tool:nanobot-harness-v3:call_d55a772192ed42f5aa45ef1e -> tool:nanobot-harness-v3:call_f03d96176cfe4b34ae395115 -> tool:nanobot-harness-v3:call_a1ae7b2a7cf24d0cbd01840f -> tool:nanobot-harness-v3:call_035a3bc88cc14a9e84e3ad07 -> tool:nanobot-harness-v3:call_f9a67523956d45028aeb55f1 -> tool:nanobot-harness-v3:call_bfa160360f3a4151983340f1 -> tool:nanobot-harness-v3:call_3c5856755e0e449a99e5dd3d -> tool:nanobot-harness-v3:call_9791417654fb4781a0bd1d89 -> tool:nanobot-harness-v3:call_64400672ea09425c97a8933d -> tool:nanobot-harness-v3:call_d6f0405b51a04507a10a7a13 -> tool:nanobot-harness-v3:call_ca53a4ba9c3d48abbdd612b7 -> tool:nanobot-harness-v3:call_22ddbe50b89e40329f896c4a -> tool:nanobot-harness-v3:call_adfcbe41a9e442f2a56490b4 -> tool:nanobot-harness-v3:call_563ada1a3af04fe88336a2e5 -> tool:nanobot-harness-v3:call_ae0cf60aacf046bba3d03a67 -> tool:nanobot-harness-v3:call_7fd42be6ec0148ecb0f54a21 -> tool:nanobot-harness-v3:call_39653f694d334888bf518803 -> tool:nanobot-harness-v3:call_d04f3a5bd9114c479f997a11 -> tool:nanobot-harness-v3:call_6a587af5b25a458aa5af739a -> tool:nanobot-harness-v3:call_d44e31019a664ce4868f51de -> tool:nanobot-harness-v3:call_fcfffafc6e7347818d3d99ab -> tool:nanobot-harness-v3:call_1f67d22b821b4e229972b3ec -> tool:nanobot-harness-v3:call_e1859dd8e7734e4983a4dc5f -> tool:nanobot-harness-v3:call_4589cf4ca82c49c79f2c65bf -> tool:nanobot-harness-v3:call_823c68afda244023ae391b35 -> tool:nanobot-harness-v3:call_6049972cad604f7998b27b2e -> tool:nanobot-harness-v3:call_0d0d68c35be84c299180dfb1 -> tool:nanobot-harness-v3:call_8f90a0799bc94a418460b911 -> tool:nanobot-harness-v3:call_e3347867e1c34c78a5f95cd6 -> tool:nanobot-harness-v3:call_80d96bcdd4b8487198c82b9b -> tool:nanobot-harness-v3:call_dfe19ea10e1e47a9b51c16ac -> tool:nanobot-harness-v3:call_32f51bef0ea5415b8ad32bac -> tool:nanobot-harness-v3:call_d3c122e0870441bd90e3aa02 -> tool:nanobot-harness-v3:call_860fe04163c04adcae1b45cb -> tool:nanobot-harness-v3:call_f38a55119e024aaa8269d432 -> tool:nanobot-harness-v3:call_59ce2dcf12424ab5ba24a585 -> tool:nanobot-harness-v3:call_6d0aa5d3bcc24c4885a9670d -> tool:nanobot-harness-v3:call_982dad08a8794839820d17cb -> tool:nanobot-harness-v3:call_18d598f00f7e4de2801445bd -> tool:nanobot-harness-v3:call_45e78407d7ab422fbd30d8d0 -> tool:nanobot-harness-v3:call_e751cfa5f60d453abb6efff2 -> tool:nanobot-harness-v3:call_83581eb934bf44b592a3872f -> tool:nanobot-harness-v3:call_5fd89d918adb4e06885f5855
- 关键路径耗时：0.9951
- Makespan：300.468596
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
