from fractions import Fraction


def compute(payload):
    """为每门课生成 [项目统计,传递可达表]；统计行 [ID,标签,[成绩和分子,分母],非空数] 按 ID 排序，保留零成绩。可达表的值为有序 ID 数组。"""
    courses = payload["courses"]
    result = {}

    for course_key, course_data in courses.items():
        items = course_data["items"]
        edges = course_data.get("edges", [])

        # Build item stats
        stats = []
        item_ids = []
        for item in items:
            item_id = item[0]
            label = item[1]
            scores = item[2]
            item_ids.append(item_id)
            # Compute sum and count of non-null scores
            score_sum = 0
            count = 0
            for s in scores:
                if s is not None:
                    score_sum += s
                    count += 1
            # Store as [sum_numerator, denominator] where denominator = count
            # But we need to represent as fraction. The spec says [成绩和分子, 分母]
            # Looking at expected: score 30 with 1 non-null -> [30, 1]
            # score 80 with 1 non-null -> [80, 1]
            # So it's just [sum, count] as integers
            stats.append([item_id, label, [score_sum, count], count])

        # Sort by ID
        stats.sort(key=lambda x: x[0])

        # Build transitive reachability
        # edges are [prereq_id, successor_id], meaning prereq -> successor
        # We need transitive closure
        id_set = set(item_ids)
        # adjacency list: from prereq to successors
        adj = {iid: set() for iid in item_ids}
        for edge in edges:
            pre, suc = edge[0], edge[1]
            if pre in adj:
                adj[pre].add(suc)

        # Transitive closure using BFS/DFS from each node
        reach = {}
        for start in item_ids:
            visited = set()
            stack = list(adj.get(start, set()))
            while stack:
                node = stack.pop()
                if node in visited:
                    continue
                visited.add(node)
                stack.extend(adj.get(node, set()) - visited)
            reach[start] = sorted(visited)

        result[course_key] = [stats, reach]

    return result
