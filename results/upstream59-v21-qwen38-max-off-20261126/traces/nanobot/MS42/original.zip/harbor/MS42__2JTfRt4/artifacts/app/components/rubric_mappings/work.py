from itertools import permutations


def compute(payload):
    """返回 [所有可行映射位掩码,旧标签到各新标签的掩码映射]；位序按新标签升序的排列枚举。"""
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    # Collect all new labels and sort them
    new_labels_set = set()
    for allowed in rubrics.values():
        new_labels_set.update(allowed)
    new_labels = sorted(new_labels_set)
    n = len(old_labels)

    # Enumerate all permutations of new_labels (assigned to old_labels in sorted order)
    # perm[i] is the index into new_labels assigned to old_labels[i]
    all_valid_mask = 0
    # per_label[old_label][new_label] = bitmask of valid permutation indices
    per_label = {ol: {nl: 0 for nl in new_labels} for ol in old_labels}

    for idx, perm in enumerate(permutations(range(len(new_labels)))):
        # perm is a tuple of indices into new_labels
        # Check validity: for each old label i, new_labels[perm[i]] must be in rubrics[old_labels[i]]
        valid = True
        for i, ol in enumerate(old_labels):
            assigned_new = new_labels[perm[i]]
            if assigned_new not in rubrics[ol]:
                valid = False
                break
        if valid:
            all_valid_mask |= (1 << idx)
            for i, ol in enumerate(old_labels):
                assigned_new = new_labels[perm[i]]
                per_label[ol][assigned_new] |= (1 << idx)

    return [all_valid_mask, per_label]
