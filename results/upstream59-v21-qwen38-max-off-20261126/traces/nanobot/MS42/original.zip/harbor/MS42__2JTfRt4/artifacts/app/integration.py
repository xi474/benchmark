from fractions import Fraction
from itertools import combinations


def combine(payload, left, right):
    """Combine the two component JSON values under the business contract in TASK.md."""
    # left = rubric_mappings result: [all_valid_mask, per_label_masks]
    # right = course_evidence result: {course_key: [stats, reachability]}
    
    all_valid_mask = left[0]
    per_label = left[1]  # {old_label: {new_label: bitmask}}
    course_evidence = right  # {course_key: [stats, reach]}
    
    # Parse course prefixes: find pairs with both 2013J and 2014J
    courses = payload["courses"]
    prefix_map = {}  # prefix -> {"old": course_key, "new": course_key}
    for ck in courses:
        if ck.endswith("-2013J"):
            prefix = ck[:-6]  # remove "-2013J"
            if prefix not in prefix_map:
                prefix_map[prefix] = {}
            prefix_map[prefix]["old"] = ck
        elif ck.endswith("-2014J"):
            prefix = ck[:-6]
            if prefix not in prefix_map:
                prefix_map[prefix] = {}
            prefix_map[prefix]["new"] = ck
    
    # Only keep prefixes with both
    valid_prefixes = {p: v for p, v in prefix_map.items() if "old" in v and "new" in v}
    
    # For each valid prefix, build candidate pairs
    # A candidate pair: (prefix, old_id, new_id) where:
    #   - both have at least one non-null score
    #   - label mapping is allowed (per_label mask & all_valid_mask != 0)
    
    # Build per-prefix data
    prefix_data = {}
    for prefix, keys in valid_prefixes.items():
        old_key = keys["old"]
        new_key = keys["new"]
        old_stats, old_reach = course_evidence[old_key]
        new_stats, new_reach = course_evidence[new_key]
        
        # Build lookup dicts
        old_items = {}  # id -> {label, score_sum, count}
        for row in old_stats:
            oid, label, frac, count = row
            old_items[oid] = {"label": label, "sum": frac[0], "count": frac[1], "non_null": count}
        
        new_items = {}
        for row in new_stats:
            nid, label, frac, count = row
            new_items[nid] = {"label": label, "sum": frac[0], "count": frac[1], "non_null": count}
        
        # Generate candidate pairs
        candidates = []
        for oid, odata in old_items.items():
            if odata["non_null"] == 0:
                continue
            for nid, ndata in new_items.items():
                if ndata["non_null"] == 0:
                    continue
                ol = odata["label"]
                nl = ndata["label"]
                # Check if this label mapping is possible in any valid bijection
                if ol in per_label and nl in per_label[ol]:
                    mask = per_label[ol][nl] & all_valid_mask
                    if mask != 0:
                        candidates.append((oid, nid, ol, nl, mask,
                                          odata["non_null"], ndata["non_null"]))
        
        prefix_data[prefix] = {
            "old_items": old_items,
            "new_items": new_items,
            "old_reach": old_reach,
            "new_reach": new_reach,
            "candidates": candidates,
        }
    
    # Now find optimal alignments across all prefixes
    # An alignment is a set of triples (prefix, old_id, new_id)
    # Constraints:
    # 1. Each old_id and new_id used at most once (per course, since IDs are per-course)
    # 2. All label mappings simultaneously extendable to valid bijection
    #    i.e., intersection of all pair masks & all_valid_mask != 0
    # 3. Order preservation within each course
    
    # Since constraints are small (max 5 labels, 3 course pairs, 6 items each),
    # we can enumerate.
    
    # Strategy: for each prefix, enumerate valid subsets of candidates,
    # then combine across prefixes.
    
    # But we need global optimization. Let's collect all prefixes and do combined search.
    
    # For efficiency with small inputs, enumerate all valid alignments.
    
    # First, for each prefix, find all valid local matchings
    # A local matching is a subset of candidates where:
    #   - no duplicate old_id or new_id
    #   - order preserved
    #   - combined mask != 0
    
    def check_order(oid1, oid2, nid1, nid2, old_reach, new_reach):
        """Check if the order relationship between (oid1,oid2) matches (nid1,nid2)."""
        # oid1 reaches oid2?
        o1_to_o2 = oid2 in old_reach.get(oid1, [])
        o2_to_o1 = oid1 in old_reach.get(oid2, [])
        n1_to_n2 = nid2 in new_reach.get(nid1, [])
        n2_to_n1 = nid1 in new_reach.get(nid2, [])
        
        # Must be identical relationship
        if o1_to_o2 != n1_to_n2:
            return False
        if o2_to_o1 != n2_to_n1:
            return False
        return True
    
    def get_local_matchings(prefix):
        """Get all valid local matchings for a prefix using backtracking.
        Returns list of (pairs_list, combined_mask, support)."""
        pd = prefix_data[prefix]
        cands = pd["candidates"]
        old_reach = pd["old_reach"]
        new_reach = pd["new_reach"]
        
        results = []
        # Always include empty matching
        results.append(([], all_valid_mask, 0))
        
        # Group candidates by old_id for efficient backtracking
        # Each old item can match at most one new item
        old_ids_ordered = []
        seen_oids = set()
        for c in cands:
            if c[0] not in seen_oids:
                old_ids_ordered.append(c[0])
                seen_oids.add(c[0])
        
        # Map old_id -> list of candidate indices
        old_to_cands = {}
        for i, c in enumerate(cands):
            old_to_cands.setdefault(c[0], []).append(i)
        
        def backtrack(oid_idx, used_new, current_selected, current_mask, current_support):
            """Enumerate valid matchings by choosing at most one new item per old item."""
            if oid_idx == len(old_ids_ordered):
                if len(current_selected) > 0:
                    pairs_list = [(prefix, s[0], s[1]) for s in current_selected]
                    results.append((pairs_list, current_mask, current_support))
                return
            
            oid = old_ids_ordered[oid_idx]
            
            # Option 1: skip this old item
            backtrack(oid_idx + 1, used_new, current_selected, current_mask, current_support)
            
            # Option 2: match this old item with one of its candidates
            for ci in old_to_cands.get(oid, []):
                c = cands[ci]
                nid = c[1]
                if nid in used_new:
                    continue
                new_mask = current_mask & c[4]
                if new_mask == 0:
                    continue
                # Check order with all already selected pairs
                ok = True
                for s in current_selected:
                    if not check_order(s[0], c[0], s[1], c[1], old_reach, new_reach):
                        ok = False
                        break
                if not ok:
                    continue
                
                new_used = used_new | {nid}
                new_support = current_support + min(c[5], c[6])
                backtrack(oid_idx + 1, new_used,
                         current_selected + [c], new_mask, new_support)
        
        backtrack(0, set(), [], all_valid_mask, 0)
        return results
    
    # Get local matchings for each prefix
    all_prefix_matchings = {}
    for prefix in sorted(valid_prefixes.keys()):
        all_prefix_matchings[prefix] = get_local_matchings(prefix)
    
    # Combine across prefixes
    # An alignment picks one local matching from each prefix
    # Total pairs = sum of local pairs
    # Total support = sum of local supports
    # Combined mask = intersection of all local masks (must be != 0)
    
    prefixes = sorted(valid_prefixes.keys())
    
    best_pairs = -1
    best_support = -1
    best_alignments = []  # list of (pairs_set, combined_mask)
    
    def combine_recursive(idx, current_pairs, current_support, current_mask):
        nonlocal best_pairs, best_support, best_alignments
        
        if idx == len(prefixes):
            num_pairs = len(current_pairs)
            if num_pairs > best_pairs or (num_pairs == best_pairs and current_support > best_support):
                best_pairs = num_pairs
                best_support = current_support
                best_alignments = [(frozenset(current_pairs), current_mask)]
            elif num_pairs == best_pairs and current_support == best_support:
                best_alignments.append((frozenset(current_pairs), current_mask))
            return
        
        prefix = prefixes[idx]
        for pairs_list, mask, support in all_prefix_matchings[prefix]:
            new_mask = current_mask & mask
            if new_mask == 0 and len(pairs_list) > 0:
                # If adding pairs makes mask zero, skip
                # But empty matching with all_valid_mask is fine
                continue
            if len(pairs_list) == 0:
                # Empty matching: mask stays, support += 0
                combine_recursive(idx + 1, current_pairs, current_support, current_mask)
            else:
                if new_mask == 0:
                    continue
                combine_recursive(idx + 1,
                                current_pairs + pairs_list,
                                current_support + support,
                                new_mask)
    
    if not prefixes:
        # No valid prefix pairs at all
        best_pairs = 0
        best_support = 0
        best_alignments = [(frozenset(), all_valid_mask)]
    else:
        combine_recursive(0, [], 0, all_valid_mask)
    
    # If no alignments found (shouldn't happen since empty is always valid)
    if not best_alignments:
        best_pairs = 0
        best_support = 0
        best_alignments = [(frozenset(), all_valid_mask)]
    
    ways = len(best_alignments)
    
    # Forced pairs: intersection of all optimal alignment pair sets
    if ways == 0:
        forced = []
    else:
        forced_set = best_alignments[0][0]
        for ps, _ in best_alignments[1:]:
            forced_set = forced_set & ps
        forced = sorted([list(t) for t in forced_set])
    
    # Drift calculation
    if best_pairs == 0:
        drift = None
    else:
        # For each optimal alignment, compute drift
        # drift = mean(all new scores of participating items) - mean(all old scores of participating items)
        # "all participating new items' non-null submissions merged" vs same for old
        
        drifts = []
        for pair_set, _ in best_alignments:
            old_total = 0
            old_count = 0
            new_total = 0
            new_count = 0
            
            for prefix, oid, nid in pair_set:
                pd = prefix_data[prefix]
                oi = pd["old_items"][oid]
                ni = pd["new_items"][nid]
                old_total += oi["sum"]
                old_count += oi["count"]
                new_total += ni["sum"]
                new_count += ni["count"]
            
            if old_count == 0 or new_count == 0:
                # Shouldn't happen since we require non-null
                drift_val = Fraction(0)
            else:
                new_mean = Fraction(new_total, new_count)
                old_mean = Fraction(old_total, old_count)
                drift_val = new_mean - old_mean
            
            drifts.append(drift_val)
        
        min_drift = min(drifts)
        max_drift = max(drifts)
        
        # Convert to [numerator, positive_denominator] in simplest form
        def frac_to_list(f):
            # f is a Fraction
            num = f.numerator
            den = f.denominator
            if den < 0:
                num = -num
                den = -den
            return [num, den]
        
        drift = [frac_to_list(min_drift), frac_to_list(max_drift)]
    
    return {
        "pairs": best_pairs,
        "support": best_support,
        "ways": ways,
        "forced": forced,
        "drift": drift,
    }
