# Workflow 可观测性报告

- Trial：`N11__LagBxKy__env`
- Task：`N11`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_d25d1754408c420da95ef7c8 -> tool:nanobot-harness-v3:call_2595da83a93747d7824f8325 -> tool:nanobot-harness-v3:call_88f9cbb73aaa44db9dcc11d3 -> tool:nanobot-harness-v3:call_8e99426fb06747b7990dd19c -> tool:nanobot-harness-v3:call_2ebc508bb62a481eb501f531 -> tool:nanobot-harness-v3:call_c1c60cd1df384104837f9ab3 -> tool:nanobot-harness-v3:call_ac2b7f15c99340eeb6aceedd -> tool:nanobot-harness-v3:call_b0a237ce07644eb39f88c49a -> tool:nanobot-harness-v3:call_2b510fd8b9e44063a605e674 -> tool:nanobot-harness-v3:call_8b027bbbe4d3455c8c0174e0 -> tool:nanobot-harness-v3:call_796f7a20414d45c5a2c0771c -> tool:nanobot-harness-v3:call_289203c74013441e8b533bb7 -> tool:nanobot-harness-v3:call_f4f046dd0a084d8f8dc6ce0d -> tool:nanobot-harness-v3:call_b0e0012574104f28a24c541b -> tool:nanobot-harness-v3:call_395d60174b9942a7af2d3038 -> tool:nanobot-harness-v3:call_d8ecdc9b28924cf1a220e22a -> tool:nanobot-harness-v3:call_6f044e2a92124b5cabcf3001 -> tool:nanobot-harness-v3:call_1fad59820bcc4d8db1b1d5f1 -> tool:nanobot-harness-v3:call_e825ec808eab4632931bcf57 -> tool:nanobot-harness-v3:call_245b9e822d1946d8b6fea5f4 -> tool:nanobot-harness-v3:call_46cd852117f648cb882889a1 -> tool:nanobot-harness-v3:call_a20586282eb14c5a88eb7430 -> tool:nanobot-harness-v3:call_caaca5d03a5046e8a1a149c0 -> tool:nanobot-harness-v3:call_edf84439052f4995ba85ea69 -> tool:nanobot-harness-v3:call_3c52ac4027d54c3ebe158c61 -> tool:nanobot-harness-v3:call_9243ea1885624b26b1b71740 -> tool:nanobot-harness-v3:call_57256da5ef954b2fa205473f -> tool:nanobot-harness-v3:call_f0d3cc487f0446129e732150 -> tool:nanobot-harness-v3:call_a698365dd78f41ba82b34b21 -> tool:nanobot-harness-v3:call_c17eb1107bf840c9a7a9bf1e -> tool:nanobot-harness-v3:call_a9c44838598c4154a35b4112 -> tool:nanobot-harness-v3:call_a6c9215cbbc041fd9f46a7a3 -> tool:nanobot-harness-v3:call_a7e21aea7c02469d928a5f9e -> tool:nanobot-harness-v3:call_6bd2f44605b54360937baaa1 -> tool:nanobot-harness-v3:call_5b2bb745f2f546dd9aaeb4a2 -> tool:nanobot-harness-v3:call_5877fda817b94e1091cd2a58 -> tool:nanobot-harness-v3:call_6c2c09fb87134352997a328a
- 关键路径耗时：0.195547
- Makespan：140.512196
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
