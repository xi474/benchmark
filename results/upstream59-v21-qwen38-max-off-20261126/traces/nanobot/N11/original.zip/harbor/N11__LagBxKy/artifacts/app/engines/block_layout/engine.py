"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    matrix = payload["matrix"]
    row_sizes = []
    for i, block_row in enumerate(matrix):
        row_sizes.append(block_row[0]["rows"])
    col_sizes = []
    for j in range(len(matrix[0])):
        col_sizes.append(matrix[0][j]["cols"])
    return {"row_sizes": row_sizes, "col_sizes": col_sizes}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
