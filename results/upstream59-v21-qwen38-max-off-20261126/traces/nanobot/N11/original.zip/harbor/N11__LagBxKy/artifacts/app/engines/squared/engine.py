"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def _mat_mul(A, B, rows_a, cols_a, cols_b):
    """Multiply two dense integer matrices represented as 2D lists."""
    result = [[0] * cols_b for _ in range(rows_a)]
    for i in range(rows_a):
        for j in range(cols_b):
            s = 0
            for k in range(cols_a):
                s += A[i][k] * B[k][j]
            result[i][j] = s
    return result

def _is_zero_block(block):
    return block["data"] is None

def _zero_block(rows, cols):
    return {"rows": rows, "cols": cols, "data": None}

def _block_multiply(A_blocks, B_blocks, layout):
    """Multiply two block matrices with same layout, returning new block matrix."""
    row_sizes = layout["row_sizes"]
    col_sizes = layout["col_sizes"]
    n = len(row_sizes)
    result = []
    for i in range(n):
        row = []
        for j in range(n):
            # C[i][j] = sum_k A[i][k] * B[k][j]
            acc = None
            for k in range(n):
                a_block = A_blocks[i][k]
                b_block = B_blocks[k][j]
                if _is_zero_block(a_block) or _is_zero_block(b_block):
                    continue
                product = _mat_mul(
                    a_block["data"], b_block["data"],
                    a_block["rows"], a_block["cols"], b_block["cols"]
                )
                if acc is None:
                    acc = product
                else:
                    for r in range(len(acc)):
                        for c in range(len(acc[0])):
                            acc[r][c] += product[r][c]
            if acc is None:
                row.append(_zero_block(row_sizes[i], col_sizes[j]))
            else:
                row.append({"rows": row_sizes[i], "cols": col_sizes[j], "data": acc})
        result.append(row)
    return result

def transform(payload, contract):
    matrix = payload["matrix"]
    layout = payload["layout"]
    blocks = _block_multiply(matrix, matrix, layout)
    return {"layout": layout, "blocks": blocks}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
