"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module

def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    # Load contracts
    block_layout_contract = read(root / "engines/block_layout/contract.json")
    squared_contract = read(root / "engines/squared/contract.json")
    cubed_contract = read(root / "engines/cubed/contract.json")

    # Load engine modules
    block_layout_mod = module(root / "engines/block_layout", "engine.py")
    squared_mod = module(root / "engines/squared", "engine.py")
    cubed_mod = module(root / "engines/cubed", "engine.py")

    # Build components in dependency order
    # 1. block_layout (depends only on inputs/request.json)
    block_layout_result = block_layout_mod.build_component(root, block_layout_contract)

    # 2. squared (depends on inputs/request.json and outputs/block_layout.json)
    squared_result = squared_mod.build_component(root, squared_contract)

    # 3. cubed (depends on outputs/squared.json, inputs/request.json, outputs/block_layout.json)
    cubed_result = cubed_mod.build_component(root, cubed_contract)

    # Read result_file
    result_file_path = root / delivery["result_file"]
    result_value = read(result_file_path)

    # Build final report
    results = {}
    for comp_name, comp_path in delivery["component_outputs"].items():
        results[comp_name] = read(root / comp_path)

    final_report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value
    }

    output_dir = root / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "final_report.json"
    report_path.write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )

if __name__ == '__main__':
    main()
