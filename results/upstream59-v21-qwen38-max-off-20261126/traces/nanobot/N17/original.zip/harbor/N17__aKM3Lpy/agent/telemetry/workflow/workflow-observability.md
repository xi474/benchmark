# Workflow 可观测性报告

- Trial：`N17__aKM3Lpy__env`
- Task：`N17`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_3e83dc08c3904a0eba241f26 -> tool:nanobot-harness-v3:call_a4409e8912e94e4cb15516dc -> tool:nanobot-harness-v3:call_268abd1e7d894ef599305343 -> tool:nanobot-harness-v3:call_5b0a90ee49644a7d8a1a6dc3 -> tool:nanobot-harness-v3:call_de812cd6180b450db4294126 -> tool:nanobot-harness-v3:call_9734d7a586bc44ce904b89cf -> tool:nanobot-harness-v3:call_1c2fe1b6af9e42d1bbe53d38 -> tool:nanobot-harness-v3:call_102848d4c8294fc78000c0b5 -> tool:nanobot-harness-v3:call_f4ce93d7aa4e4bf3b23a32fa -> tool:nanobot-harness-v3:call_e09fc4eaa2b44352b5440935 -> tool:nanobot-harness-v3:call_6ba09026c5854dfcbaa4b30e -> tool:nanobot-harness-v3:call_c9f004a6153c4388aa59c5a6 -> tool:nanobot-harness-v3:call_9d87262e90494389b9563866 -> tool:nanobot-harness-v3:call_f87bfb1208864bbcb956feaa -> tool:nanobot-harness-v3:call_6085f61857b64016ae63c3c0 -> tool:nanobot-harness-v3:call_5d80a48b22914b89903398b0 -> tool:nanobot-harness-v3:call_f6f779d01e564903a08ffc2f -> tool:nanobot-harness-v3:call_38d8adbf4fac40a68bc23923 -> tool:nanobot-harness-v3:call_56373ca67bf4464c820fbf8a -> tool:nanobot-harness-v3:call_17fc7006f3e24f9c9ee33679 -> tool:nanobot-harness-v3:call_3d18b7195ec94d638d19a154 -> tool:nanobot-harness-v3:call_44002e3dbeab4e22a99cea99 -> tool:nanobot-harness-v3:call_37100033ffb343d4beae8b54 -> tool:nanobot-harness-v3:call_e652a6d3fcc84c5f8b5eb85d -> tool:nanobot-harness-v3:call_8b41487ac83948eb915d7b70 -> tool:nanobot-harness-v3:call_a3b3dcb892f04a1f95973d74 -> tool:nanobot-harness-v3:call_20b7e0aa5aa74e24891586db -> tool:nanobot-harness-v3:call_4ecc3679d65b4764967ab087 -> tool:nanobot-harness-v3:call_352c72fd4b284b77879ce26c -> tool:nanobot-harness-v3:call_a685449b5ff349cdb9653549 -> tool:nanobot-harness-v3:call_11fad7e683cc4ee2bf082744 -> tool:nanobot-harness-v3:call_6cd4b1b1052f4c43b358d0a3 -> tool:nanobot-harness-v3:call_2ea214b693744c3db9a8c792 -> tool:nanobot-harness-v3:call_88a87b9f1b46474ebfc1a840 -> tool:nanobot-harness-v3:call_68b9fcd70d284b2ca4dd8b81 -> tool:nanobot-harness-v3:call_fa9fc2d1292d4b66b920e553 -> tool:nanobot-harness-v3:call_402c1f0e90384374916c6d0c
- 关键路径耗时：0.248033
- Makespan：160.006204
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
