"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import re
import ast
from runtime import build


def _extract_conf_chains(node):
    """Recursively extract conf access chains from an AST node.
    Returns list of dot-separated chains like 'conf.x.y.z'."""
    chains = []
    if isinstance(node, ast.Attribute):
        # e.g. conf.auto_save.interval
        parts = []
        n = node
        while isinstance(n, ast.Attribute):
            parts.append(n.attr)
            n = n.value
        if isinstance(n, ast.Name) and n.id == 'conf':
            parts.reverse()
            chains.append('conf.' + '.'.join(parts))
        else:
            # recurse into the value
            chains.extend(_extract_conf_chains(n))
    elif isinstance(node, ast.Subscript):
        # e.g. conf.aliases['a'] or conf.aliases['a'].propname
        # First get the base chain from the value
        base_chains = _extract_conf_chains(node.value)
        # Check if the slice is a static string
        sl = node.slice
        if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
            suffix = sl.value
            for bc in base_chains:
                chains.append(bc + '.' + suffix)
        else:
            chains.extend(base_chains)
    elif isinstance(node, ast.BinOp):
        chains.extend(_extract_conf_chains(node.left))
        chains.extend(_extract_conf_chains(node.right))
    elif isinstance(node, ast.UnaryOp):
        chains.extend(_extract_conf_chains(node.operand))
    elif isinstance(node, ast.BoolOp):
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    elif isinstance(node, ast.Compare):
        chains.extend(_extract_conf_chains(node.left))
        for c in node.comparators:
            chains.extend(_extract_conf_chains(c))
    elif isinstance(node, ast.IfExp):
        chains.extend(_extract_conf_chains(node.test))
        chains.extend(_extract_conf_chains(node.body))
        chains.extend(_extract_conf_chains(node.orelse))
    elif isinstance(node, ast.Call):
        chains.extend(_extract_conf_chains(node.func))
        for a in node.args:
            chains.extend(_extract_conf_chains(a))
        for kw in node.keywords:
            chains.extend(_extract_conf_chains(kw.value))
    elif isinstance(node, ast.Tuple) or isinstance(node, ast.List) or isinstance(node, ast.Set):
        for elt in node.elts:
            chains.extend(_extract_conf_chains(elt))
    elif isinstance(node, ast.Dict):
        for k in node.keys:
            if k is not None:
                chains.extend(_extract_conf_chains(k))
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    elif isinstance(node, ast.FormattedValue):
        chains.extend(_extract_conf_chains(node.value))
    elif isinstance(node, ast.JoinedStr):
        for v in node.values:
            if isinstance(v, ast.FormattedValue):
                chains.extend(_extract_conf_chains(v))
    # Name nodes that are 'conf' alone - shouldn't normally appear as standalone
    # but handle gracefully
    return chains


def _resolve_chain_to_option(chain, options_set, sorted_options_by_len):
    """Given a conf.x.y.z chain, find the longest option prefix that matches.
    The chain starts with 'conf.', so we strip that and check prefixes."""
    if not chain.startswith('conf.'):
        return None
    dotted = chain[5:]  # strip 'conf.'
    # Try longest options first
    for opt in sorted_options_by_len:
        if dotted == opt or dotted.startswith(opt + '.'):
            return opt
    return None


def transform(payload, contract):
    templates = payload['templates']
    options = payload['options']
    options_set = set(options)
    # Sort options by length descending for longest-prefix matching
    sorted_options_by_len = sorted(options, key=lambda x: len(x), reverse=True)

    result = {}
    for tid, text in templates.items():
        # Find all {{ ... }} expressions
        exprs = re.findall(r'\{\{(.*?)\}\}', text)
        config_keys = set()
        for expr_str in exprs:
            expr_str = expr_str.strip()
            try:
                tree = ast.parse(expr_str, mode='eval')
            except SyntaxError:
                continue
            chains = _extract_conf_chains(tree.body)
            for chain in chains:
                opt = _resolve_chain_to_option(chain, options_set, sorted_options_by_len)
                if opt is not None:
                    config_keys.add(opt)
        result[tid] = sorted(config_keys)
    return result


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
