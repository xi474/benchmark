"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module

ROOT = Path(__file__).resolve().parent


def main():
    # Load delivery manifest
    delivery = read(ROOT / 'delivery.json')

    # Load contracts
    td_contract = read(ROOT / 'engines/template_dependencies/contract.json')
    ri_contract = read(ROOT / 'engines/reverse_index/contract.json')
    su_contract = read(ROOT / 'engines/stylesheet_updates/contract.json')

    # 1. template_dependencies (no upstream deps)
    td_mod = module(ROOT / 'engines/template_dependencies', 'engine.py')
    td_result = td_mod.build_component(ROOT, td_contract)

    # 2. reverse_index (depends on template_dependencies output)
    ri_mod = module(ROOT / 'engines/reverse_index', 'engine.py')
    ri_result = ri_mod.build_component(ROOT, ri_contract)

    # 3. stylesheet_updates (depends on template_dependencies + reverse_index outputs)
    su_mod = module(ROOT / 'engines/stylesheet_updates', 'engine.py')
    su_result = su_mod.build_component(ROOT, su_contract)

    # Build final report
    result_file_path = delivery['result_file']
    result_value = read(ROOT / result_file_path)

    report = {
        "task": delivery['task'],
        "results": {
            "template_dependencies": td_result,
            "stylesheet_updates": su_result,
            "reverse_index": ri_result
        },
        "result": result_value
    }

    out = ROOT / 'outputs/final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
