# Workflow 可观测性报告

- Trial：`N22__Cq6qwcC__env`
- Task：`N22`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（86 节点 / 85 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：86；执行边：85（observed=0，inferred=85）
- Execution Trace Graph：`observed`；temporal_next 边 85，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_8f4cd4d51f9c478b9d75f41f -> tool:nanobot-harness-v3:call_c60bdc7c50a64a6b91443ec4 -> tool:nanobot-harness-v3:call_1a9e681e0fec4ebcb562c599 -> tool:nanobot-harness-v3:call_e74c8a491cfd40da85257655 -> tool:nanobot-harness-v3:call_f18666ef51e84841a3caca94 -> tool:nanobot-harness-v3:call_6067bc39aeba4f5aaba2c342 -> tool:nanobot-harness-v3:call_cd74a8767612424bb2b3c7b9 -> tool:nanobot-harness-v3:call_9e343257f913407992cf1020 -> tool:nanobot-harness-v3:call_40f8bc05d3fd4e3fb1b5d945 -> tool:nanobot-harness-v3:call_a4260e24c4a344619dd0849e -> tool:nanobot-harness-v3:call_9d4131aef99d43a4855ca9df -> tool:nanobot-harness-v3:call_8a9a0612dd25427bbd803ef8 -> tool:nanobot-harness-v3:call_4fad5023288346e3848aa77f -> tool:nanobot-harness-v3:call_2c427509e76d40aca688f248 -> tool:nanobot-harness-v3:call_26db0536524b43e6a8589f86 -> tool:nanobot-harness-v3:call_68f2941c38c248f48ab03128 -> tool:nanobot-harness-v3:call_063e6e5ebdb94d7d96700f46 -> tool:nanobot-harness-v3:call_9762c63d098e4d1396eb54dc -> tool:nanobot-harness-v3:call_bc626712c0154e8bbce5a618 -> tool:nanobot-harness-v3:call_5bab40c9847147269662bb59 -> tool:nanobot-harness-v3:call_20e891cbaf914a379fd83b7b -> tool:nanobot-harness-v3:call_3322e53dfb754dd79cb011b8 -> tool:nanobot-harness-v3:call_7bda9f8d437345698b80a199 -> tool:nanobot-harness-v3:call_214855d6ab55467e9adb4867 -> tool:nanobot-harness-v3:call_e49842c4a19d4dac8394637e -> tool:nanobot-harness-v3:call_756887956a474d9ea6641806 -> tool:nanobot-harness-v3:call_b257eb836d7d46e2a7a217f0 -> tool:nanobot-harness-v3:call_27fdad099f01434d99a2d461 -> tool:nanobot-harness-v3:call_aa34a7a2ea8a4133a12a344b -> tool:nanobot-harness-v3:call_13a9245f09b745c9a5a05eff -> tool:nanobot-harness-v3:call_8e7cce633dba470886718e44 -> tool:nanobot-harness-v3:call_90c572ab49904344a0c1d3f2 -> tool:nanobot-harness-v3:call_97e44d8c3f514fa196d669a6 -> tool:nanobot-harness-v3:call_ee6aaa9d520a45cbba4a4d48 -> tool:nanobot-harness-v3:call_cd38a2750d9c4822809eef63 -> tool:nanobot-harness-v3:call_81c02ed0edbd42a6a8aa9ca6 -> tool:nanobot-harness-v3:call_b2b3b4e408a04bc28731b898 -> tool:nanobot-harness-v3:call_3334f946caf145e1bc0f0475 -> tool:nanobot-harness-v3:call_d19234b3da8946b9b47035f5 -> tool:nanobot-harness-v3:call_53a07f3269164e34ae62ec9b -> tool:nanobot-harness-v3:call_b32dd61f4c8f46559fc63f45 -> tool:nanobot-harness-v3:call_f873681097b54134bb5265af -> tool:nanobot-harness-v3:call_e27d805649d34a56ae8d4ed8 -> tool:nanobot-harness-v3:call_31c17024c4374402b47b177b -> tool:nanobot-harness-v3:call_788e18c7c8404fdaa0cac95c -> tool:nanobot-harness-v3:call_8f5ca42f819c4594b2e7c025 -> tool:nanobot-harness-v3:call_6d30c262bd224b269dee2867 -> tool:nanobot-harness-v3:call_0885aa7c2b5d4d948bd09fe2 -> tool:nanobot-harness-v3:call_7ca0715260fb454fb5a218b1 -> tool:nanobot-harness-v3:call_4e60466a096a4b359aac18c9 -> tool:nanobot-harness-v3:call_6b7a02bc303f4fe6b3c4bdd8 -> tool:nanobot-harness-v3:call_1dd1a38096f148d0b38c1cf2 -> tool:nanobot-harness-v3:call_390af20f555b41979309459a -> tool:nanobot-harness-v3:call_d4292236bb1f4eee9a40fb3d -> tool:nanobot-harness-v3:call_9e316831516748d59a9e44f9 -> tool:nanobot-harness-v3:call_0688134bea4f4378a3bbe0e0 -> tool:nanobot-harness-v3:call_42b5c9e41350475e9c01888b -> tool:nanobot-harness-v3:call_bcb1f47f0e0342a2a74ec63a -> tool:nanobot-harness-v3:call_d403f7bbd79b4752b628e827 -> tool:nanobot-harness-v3:call_977a29b0163e4239b40f0848 -> tool:nanobot-harness-v3:call_e81e2039399a4bbaafd4e3a4 -> tool:nanobot-harness-v3:call_7be08b223fc54a3e90e8f600 -> tool:nanobot-harness-v3:call_84e9d1037f9b43849d4f745e -> tool:nanobot-harness-v3:call_20cf6e6bbafb4a3392d1a713 -> tool:nanobot-harness-v3:call_68c9c4ec3d1e4eeca974f8de -> tool:nanobot-harness-v3:call_11a3bf7164c3412c8348abb8 -> tool:nanobot-harness-v3:call_eaf1122fb04647a093f97335 -> tool:nanobot-harness-v3:call_133a8e3add0d4aae9fc30842 -> tool:nanobot-harness-v3:call_23cc26af896a4bc68fabb96a -> tool:nanobot-harness-v3:call_55e64a3d302c48959edf948c -> tool:nanobot-harness-v3:call_1aa63c4f30384176aebe30e0 -> tool:nanobot-harness-v3:call_e775e1a01c23494685798f32 -> tool:nanobot-harness-v3:call_ed6c5b7e162c4e97ac019d35 -> tool:nanobot-harness-v3:call_d409fb674bf54c548088d396 -> tool:nanobot-harness-v3:call_3ba45d50fcd04848af76541a -> tool:nanobot-harness-v3:call_0063a91901bc410194ba8370 -> tool:nanobot-harness-v3:call_24e66720e3a848bc967bc521 -> tool:nanobot-harness-v3:call_dde5780a0c034d8ea3989c29 -> tool:nanobot-harness-v3:call_febdaf28cf924d40bfb5792f -> tool:nanobot-harness-v3:call_1a2860d097d641298878360b -> tool:nanobot-harness-v3:call_f09d9160c1534e4898603644 -> tool:nanobot-harness-v3:call_68947b7296ed4f25a73d8b33 -> tool:nanobot-harness-v3:call_54aa705fc6d84b0694665add -> tool:nanobot-harness-v3:call_3defea75bc344ef5a64cb6e2 -> tool:nanobot-harness-v3:call_b2cb9e7c6ac64a72991f8f52
- 关键路径耗时：1.219912
- Makespan：395.113578
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
