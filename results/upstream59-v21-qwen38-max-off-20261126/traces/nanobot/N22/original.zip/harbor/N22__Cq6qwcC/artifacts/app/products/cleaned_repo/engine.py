"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import tarfile
import io
import os
import subprocess
import hashlib
import tempfile
import shutil
from runtime import build

def transform(payload, contract):
    bundle_b64 = payload["bundle"]
    scan_result = payload["scan"]
    secret = scan_result["secret"]
    
    data = base64.b64decode(bundle_b64)
    
    with tempfile.TemporaryDirectory() as td:
        repo_dir = os.path.join(td, "repo")
        os.makedirs(repo_dir)
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            tf.extractall(repo_dir)
        
        env = {**os.environ, "GIT_DIR": os.path.join(repo_dir, ".git")}
        
        def git(*args):
            result = subprocess.run(
                ["git"] + list(args),
                capture_output=True, text=True, cwd=repo_dir, env=env
            )
            return result
        
        # Clear all reflogs first
        git("reflog", "expire", "--expire=now", "--all")
        
        # Remove ORIG_HEAD if it points to unreachable commit
        orig_head = os.path.join(repo_dir, ".git", "ORIG_HEAD")
        if os.path.exists(orig_head):
            os.remove(orig_head)
        
        # Run gc to prune unreachable objects
        git("gc", "--prune=now", "--aggressive")
        
        # Also run prune explicitly
        git("prune", "--expire=now")
        
        # Verify secret is gone by checking all remaining objects
        objects_dir = os.path.join(repo_dir, ".git", "objects")
        for dirpath, dirnames, filenames in os.walk(objects_dir):
            rel = os.path.relpath(dirpath, objects_dir)
            if rel.startswith("info") or rel.startswith("pack"):
                continue
            for f in filenames:
                prefix = os.path.basename(dirpath)
                oid = prefix + f
                result = subprocess.run(
                    ["git", "cat-file", "-p", oid],
                    capture_output=True, text=True, cwd=repo_dir
                )
                if secret in result.stdout:
                    # Manually remove this object file
                    obj_path = os.path.join(dirpath, f)
                    os.remove(obj_path)
        
        # If there are pack files, we need to repack without the secret objects
        # Re-run gc after manual removal
        git("reflog", "expire", "--expire=now", "--all")
        git("gc", "--prune=now", "--aggressive")
        git("prune", "--expire=now")
        
        # Ensure refs directory structure exists (git requires it)
        git_dir = os.path.join(repo_dir, ".git")
        for subdir in ["refs/heads", "refs/tags"]:
            os.makedirs(os.path.join(git_dir, subdir), exist_ok=True)
        
        # Collect working tree files and their SHA256
        files = {}
        for dirpath, dirnames, filenames in os.walk(repo_dir):
            # Skip .git directory
            rel = os.path.relpath(dirpath, repo_dir)
            if rel == "." or not rel.startswith("."):
                for fn in filenames:
                    full = os.path.join(dirpath, fn)
                    rel_path = os.path.relpath(full, repo_dir)
                    if rel_path.startswith(".git"):
                        continue
                    sha = hashlib.sha256(open(full, "rb").read()).hexdigest()
                    files[rel_path] = sha
        
        # Get commit messages (newest first)
        result = git("log", "--format=%s")
        messages = [line for line in result.stdout.strip().split("\n") if line]
        
        # Create tar.gz of the cleaned repo
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tf:
            for dirpath, dirnames, filenames in os.walk(repo_dir):
                # Add directory entries first
                arcdir = os.path.relpath(dirpath, repo_dir)
                if arcdir != ".":
                    tf.add(dirpath, arcname=arcdir, recursive=False)
                for fn in filenames:
                    full = os.path.join(dirpath, fn)
                    arcname = os.path.relpath(full, repo_dir)
                    tf.add(full, arcname=arcname)
        
        cleaned_bundle = base64.b64encode(buf.getvalue()).decode("ascii")
        
        return {
            "bundle": cleaned_bundle,
            "files": files,
            "messages": messages
        }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
