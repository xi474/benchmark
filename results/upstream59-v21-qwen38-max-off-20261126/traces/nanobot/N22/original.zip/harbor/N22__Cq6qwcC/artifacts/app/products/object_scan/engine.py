"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import tarfile
import io
import os
import subprocess
import re
import tempfile
from runtime import build

def transform(payload, contract):
    bundle_b64 = payload["bundle"]
    data = base64.b64decode(bundle_b64)
    
    with tempfile.TemporaryDirectory() as td:
        repo_dir = os.path.join(td, "repo")
        os.makedirs(repo_dir)
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            tf.extractall(repo_dir)
        
        # Enumerate all git objects and find secret[...] pattern
        secret = None
        objects_dir = os.path.join(repo_dir, ".git", "objects")
        for dirpath, dirnames, filenames in os.walk(objects_dir):
            # Skip info and pack directories
            rel = os.path.relpath(dirpath, objects_dir)
            if rel.startswith("info") or rel.startswith("pack"):
                continue
            for f in filenames:
                prefix = os.path.basename(dirpath)
                oid = prefix + f
                try:
                    result = subprocess.run(
                        ["git", "cat-file", "-p", oid],
                        capture_output=True, text=True, cwd=repo_dir
                    )
                    content = result.stdout
                    match = re.search(r'secret\[[^\]]+\]', content)
                    if match:
                        secret = match.group(0)
                        break
                except Exception:
                    pass
            if secret:
                break
        
        if secret is None:
            raise ValueError("No secret marker found in git objects")
        
        return {"secret": secret}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
