"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import tarfile
import io
import os
import subprocess
import hashlib
import tempfile
import re
from runtime import build

def transform(payload, contract):
    scan_result = payload["scan"]
    cleaned_result = payload["cleaned"]
    
    secret = scan_result["secret"]
    cleaned_bundle = cleaned_result["bundle"]
    
    # Extract cleaned repo
    data = base64.b64decode(cleaned_bundle)
    
    with tempfile.TemporaryDirectory() as td:
        repo_dir = os.path.join(td, "repo")
        os.makedirs(repo_dir)
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            tf.extractall(repo_dir)
        
        # Ensure refs directory structure exists (git requires it)
        git_dir = os.path.join(repo_dir, ".git")
        for subdir in ["refs/heads", "refs/tags"]:
            os.makedirs(os.path.join(git_dir, subdir), exist_ok=True)
        
        # Enumerate ALL objects in the cleaned repo and verify no secret
        remaining = 0
        objects_dir = os.path.join(repo_dir, ".git", "objects")
        
        # Check loose objects
        for dirpath, dirnames, filenames in os.walk(objects_dir):
            rel = os.path.relpath(dirpath, objects_dir)
            if rel.startswith("info"):
                continue
            if rel.startswith("pack"):
                # Check pack files
                for fn in filenames:
                    if fn.endswith(".pack"):
                        pack_path = os.path.join(dirpath, fn)
                        result = subprocess.run(
                            ["git", "verify-pack", "-v", pack_path],
                            capture_output=True, text=True, cwd=repo_dir
                        )
                        for line in result.stdout.split("\n"):
                            parts = line.split()
                            if len(parts) >= 2 and len(parts[0]) == 40:
                                oid = parts[0]
                                try:
                                    r = subprocess.run(
                                        ["git", "cat-file", "-p", oid],
                                        capture_output=True, text=True, cwd=repo_dir
                                    )
                                    if secret in r.stdout:
                                        remaining += 1
                                except Exception:
                                    pass
                continue
            for f in filenames:
                prefix = os.path.basename(dirpath)
                oid = prefix + f
                try:
                    result = subprocess.run(
                        ["git", "cat-file", "-p", oid],
                        capture_output=True, text=True, cwd=repo_dir
                    )
                    if secret in result.stdout:
                        remaining += 1
                except Exception:
                    pass
        
        # Use files and messages from cleaned result
        files = cleaned_result["files"]
        messages = cleaned_result["messages"]
        
        return {
            "secret": secret,
            "files": files,
            "messages": messages,
            "remaining_secret_objects": remaining
        }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
