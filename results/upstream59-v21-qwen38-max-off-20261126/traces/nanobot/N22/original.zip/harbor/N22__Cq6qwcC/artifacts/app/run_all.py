"""Implement the project entry point using the published business contracts."""
import json
import sys
from pathlib import Path
from runtime import read, module, payload_for, emit

def main():
    root = Path(".")
    delivery = read(root / "delivery.json")
    
    # Load contracts
    contracts = {}
    for comp_name in ["object_scan", "cleaned_repo", "recovery_report"]:
        contract_path = root / "products" / comp_name / "contract.json"
        contracts[comp_name] = read(contract_path)
    
    results = {}
    
    # 1. object_scan (no dependencies)
    comp = "object_scan"
    contract = contracts[comp]
    eng = module(root / "products" / comp, "engine.py")
    result = eng.build_component(str(root), contract)
    results[comp] = result
    
    # 2. cleaned_repo (depends on object_scan output)
    comp = "cleaned_repo"
    contract = contracts[comp]
    eng = module(root / "products" / comp, "engine.py")
    result = eng.build_component(str(root), contract)
    results[comp] = result
    
    # 3. recovery_report (depends on object_scan and cleaned_repo)
    comp = "recovery_report"
    contract = contracts[comp]
    eng = module(root / "products" / comp, "engine.py")
    result = eng.build_component(str(root), contract)
    results[comp] = result
    
    # Read the result_file
    result_file_path = root / delivery["result_file"]
    result_value = read(result_file_path)
    
    # Write final_report.json
    final_report = {
        "task": "N22",
        "results": results,
        "result": result_value
    }
    
    outputs_dir = root / "outputs"
    outputs_dir.mkdir(parents=True, exist_ok=True)
    (outputs_dir / "final_report.json").write_text(
        json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8"
    )

if __name__ == '__main__':
    main()
