# Workflow 可观测性报告

- Trial：`N24__MQLJCTs__env`
- Task：`N24`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（40 节点 / 39 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：40；执行边：39（observed=0，inferred=39）
- Execution Trace Graph：`observed`；temporal_next 边 39，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_55fdfd24929140a58b4dec1e -> tool:nanobot-harness-v3:call_df026029f55d4f1cbc65ae56 -> tool:nanobot-harness-v3:call_037e6909cb124bd2993d47a1 -> tool:nanobot-harness-v3:call_bca081e851bc4dce9e0b6249 -> tool:nanobot-harness-v3:call_e8ab1295c94e491d81fc8258 -> tool:nanobot-harness-v3:call_adddc4a6f7bd47ad976251fc -> tool:nanobot-harness-v3:call_673a213f39664cfeb1bc89c5 -> tool:nanobot-harness-v3:call_fdb0b361cd4544f4b33f5d3c -> tool:nanobot-harness-v3:call_14008498aa11422794d00481 -> tool:nanobot-harness-v3:call_1d4d52899ab34baca0953585 -> tool:nanobot-harness-v3:call_d2bb83efbe1946cfa3c6efd6 -> tool:nanobot-harness-v3:call_0a5312e83e3e4a5cbd8807ca -> tool:nanobot-harness-v3:call_2bfae8964521425ca9b69df6 -> tool:nanobot-harness-v3:call_6fb20566aef94e1daa6d7c77 -> tool:nanobot-harness-v3:call_7166a0b3d21e430e8938cbdf -> tool:nanobot-harness-v3:call_a58ddd09386045bfbfe5c4c5 -> tool:nanobot-harness-v3:call_55607fa5343c46ab987be324 -> tool:nanobot-harness-v3:call_2c7139c0d49d4044958fb164 -> tool:nanobot-harness-v3:call_2ea553646f80460ba2fd27e6 -> tool:nanobot-harness-v3:call_15f31985a08e433ebea8cd40 -> tool:nanobot-harness-v3:call_6ad3c9a42c6c4216a4bb80fb -> tool:nanobot-harness-v3:call_04f4d25d4d50472989bcd94c -> tool:nanobot-harness-v3:call_1b1a68a77d28407e9e710a99 -> tool:nanobot-harness-v3:call_2c392fac49b94a529bbc1e40 -> tool:nanobot-harness-v3:call_81be15686e1c42e8b2d79598 -> tool:nanobot-harness-v3:call_f249007493c04348bea21b90 -> tool:nanobot-harness-v3:call_d66791fa815d4ac98b3a644b -> tool:nanobot-harness-v3:call_bf6717a8d11a4abd95a92d88 -> tool:nanobot-harness-v3:call_702eec69e7954729bf55e777 -> tool:nanobot-harness-v3:call_c85d48db3dc14ffa82293b35 -> tool:nanobot-harness-v3:call_43b01a56a38846e4a0602247 -> tool:nanobot-harness-v3:call_848b4242f7284231abf93940 -> tool:nanobot-harness-v3:call_1472f8c4d38648b4b6bfb463 -> tool:nanobot-harness-v3:call_0d568502a7224b548645dcd1 -> tool:nanobot-harness-v3:call_677e431a8a37494ba04a0fcf -> tool:nanobot-harness-v3:call_57a1106ff4b64e1c93ccada5 -> tool:nanobot-harness-v3:call_1ea6ef049e2d466e923e835a -> tool:nanobot-harness-v3:call_e34bfab502b54b208d02e0be -> tool:nanobot-harness-v3:call_cd7359585555424bae6f7a79
- 关键路径耗时：0.175237
- Makespan：99.48287
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
