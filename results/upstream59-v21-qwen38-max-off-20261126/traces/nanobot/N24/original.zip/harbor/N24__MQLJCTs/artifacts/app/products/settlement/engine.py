"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def encode_accounts(accounts):
    parts = []
    for a in accounts:
        aid = a["id"]
        name = a["name"].ljust(20)
        bal = str(a["balance"]).zfill(10)
        parts.append(aid + name + bal)
    return "".join(parts)

def encode_books(books):
    parts = []
    for b in books:
        bid = b["id"]
        title = b["title"].ljust(20)
        owner = b["owner"]
        parts.append(bid + title + owner)
    return "".join(parts)

def transform(payload, contract):
    accounts = [dict(a) for a in payload["accounts"]]
    books = [dict(b) for b in payload["books"]]
    orders = payload["orders"]
    journal = payload.get("journal", "")

    acc_map = {a["id"]: a for a in accounts}
    book_map = {b["id"]: b for b in books}

    statuses = []
    for order in orders:
        buyer = order["buyer"]
        seller = order["seller"]
        book_id = order["book"]
        amount = order["amount"]

        book = book_map.get(book_id)
        buyer_acc = acc_map.get(buyer)
        seller_acc = acc_map.get(seller)

        if (book is not None and buyer_acc is not None and seller_acc is not None
                and buyer != seller and amount > 0
                and buyer_acc["balance"] >= amount
                and book["owner"] == seller):
            buyer_acc["balance"] -= amount
            seller_acc["balance"] += amount
            book["owner"] = buyer
            amt_str = str(amount).zfill(10)
            journal += book_id + amt_str + seller + buyer
            statuses.append("accepted")
        else:
            statuses.append("rejected")

    return {
        "accounts": encode_accounts(accounts),
        "books": encode_books(books),
        "journal": journal,
        "statuses": statuses
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
