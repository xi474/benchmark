"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module

def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    # Load contracts
    accounts_contract = read(root / "products/accounts/contract.json")
    books_contract = read(root / "products/books/contract.json")
    orders_contract = read(root / "products/orders/contract.json")
    settlement_contract = read(root / "products/settlement/contract.json")

    # Build components in dependency order
    accounts_mod = module(root, "products/accounts/engine.py")
    accounts_result = accounts_mod.build_component(root, accounts_contract)

    books_mod = module(root, "products/books/engine.py")
    books_result = books_mod.build_component(root, books_contract)

    orders_mod = module(root, "products/orders/engine.py")
    orders_result = orders_mod.build_component(root, orders_contract)

    settlement_mod = module(root, "products/settlement/engine.py")
    settlement_result = settlement_mod.build_component(root, settlement_contract)

    # Build final report
    result_file_path = delivery["result_file"]
    result_value = read(root / result_file_path)

    report = {
        "task": delivery["task"],
        "results": {
            "accounts": accounts_result,
            "books": books_result,
            "orders": orders_result,
            "settlement": settlement_result
        },
        "result": result_value
    }

    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")

if __name__ == '__main__':
    main()
