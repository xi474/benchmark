import re

MONTHS = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _clean_text(s):
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    if not s:
        return ""
    return re.sub(r'\D', '', s)


def _parse_internet(rec):
    f = rec['fields']
    name = f.get('full_name', '').strip()
    parts = name.split(None, 1)
    first = parts[0] if len(parts) > 0 else ''
    last = parts[1] if len(parts) > 1 else ''
    bd = f.get('birth_date', '')
    dob = ''
    if bd and '/' in bd:
        segs = bd.split('/')
        if len(segs) == 3:
            mm, dd, yyyy = segs
            dob = f"{yyyy}-{mm.zfill(2)}-{dd.zfill(2)}"
    return {
        'id': rec['id'],
        'first': _clean_text(first),
        'last': _clean_text(last),
        'dob': dob,
        'ssn': '',
        'mail': _clean_text(f.get('mail', '')),
        'phone': _digits_only(f.get('tel', '')),
        'address': _clean_text(f.get('street', '')),
    }


def _parse_streaming(rec):
    f = rec['fields']
    name = f.get('customer', '').strip()
    parts = name.split(None, 1)
    first = parts[0] if len(parts) > 0 else ''
    last = parts[1] if len(parts) > 1 else ''
    dob_raw = f.get('date_of_birth', '')
    dob = ''
    if dob_raw:
        tokens = dob_raw.strip().split()
        if len(tokens) == 3:
            dd, mon, yyyy = tokens
            mm = MONTHS.get(mon.lower().rstrip(','), '')
            if mm:
                dob = f"{yyyy}-{mm}-{dd.zfill(2)}"
    return {
        'id': rec['id'],
        'first': _clean_text(first),
        'last': _clean_text(last),
        'dob': dob,
        'ssn': '',
        'mail': _clean_text(f.get('email', '')),
        'phone': _digits_only(f.get('telephone', '')),
        'address': _clean_text(f.get('address', '')),
    }


def compute(payload):
    result = []
    for idx, rec in enumerate(payload.get('records', [])):
        src = rec.get('source', '')
        if src == 'internet':
            result.append([idx, _parse_internet(rec)])
        elif src == 'streaming':
            result.append([idx, _parse_streaming(rec)])
    return result
