import re


def _clean_text(s):
    if not s:
        return ""
    return re.sub(r'[^a-z0-9]', '', s.lower())


def _digits_only(s):
    if not s:
        return ""
    return re.sub(r'\D', '', s)


def _parse_mobile(rec):
    f = rec['fields']
    return {
        'id': rec['id'],
        'first': _clean_text(f.get('first', '')),
        'last': _clean_text(f.get('last', '')),
        'dob': f.get('dob', ''),
        'ssn': _digits_only(f.get('ssn', '')),
        'mail': _clean_text(f.get('email', '')),
        'phone': _digits_only(f.get('phone', '')),
        'address': _clean_text(f.get('address', '')),
    }


def _parse_cable(rec):
    f = rec['fields']
    lf = f.get('last_first', '')
    parts = lf.split(',', 1)
    last = parts[0].strip() if len(parts) > 0 else ''
    first = parts[1].strip() if len(parts) > 1 else ''
    birth = f.get('birth', '')
    if len(birth) == 8:
        dob = f"{birth[:4]}-{birth[4:6]}-{birth[6:8]}"
    else:
        dob = birth
    return {
        'id': rec['id'],
        'first': _clean_text(first),
        'last': _clean_text(last),
        'dob': dob,
        'ssn': _digits_only(f.get('government_id', '')),
        'mail': _clean_text(f.get('contact', '')),
        'phone': _digits_only(f.get('phone', '')),
        'address': _clean_text(f.get('location', '')),
    }


def compute(payload):
    result = []
    for idx, rec in enumerate(payload.get('records', [])):
        src = rec.get('source', '')
        if src == 'mobile':
            result.append([idx, _parse_mobile(rec)])
        elif src == 'cable':
            result.append([idx, _parse_cable(rec)])
    return result
