from collections import defaultdict


def combine(payload, left, right):
    records = []
    for _idx, obj in left:
        records.append(obj)
    for _idx, obj in right:
        records.append(obj)

    ambiguous = set()
    for n in payload.get('ambiguous_names', []):
        ambiguous.add(n.lower())

    n = len(records)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    def ssn_last4(s):
        if len(s) >= 4:
            return s[-4:]
        return ''

    def edit_dist_1(a, b):
        la, lb = len(a), len(b)
        if la == lb:
            diff = sum(1 for i in range(la) if a[i] != b[i])
            return diff <= 1
        if abs(la - lb) != 1:
            return False
        if la < lb:
            a, b = b, a
            la, lb = lb, la
        i = 0
        while i < lb and a[i] == b[i]:
            i += 1
        return a[i+1:] == b[i:]

    def mail_match(m1, m2):
        if not m1 or not m2:
            return False
        if m1 == m2:
            return True
        return edit_dist_1(m1, m2)

    def names_compatible(f1, f2):
        if f1 == f2:
            return True
        a1 = f1 in ambiguous
        a2 = f2 in ambiguous
        if a1 and a2:
            return True
        if a1 or a2:
            return True
        return False

    def definitely_different(i, j):
        ri, rj = records[i], records[j]
        ssn_i, ssn_j = ri['ssn'], rj['ssn']
        if len(ssn_i) == 9 and len(ssn_j) == 9 and ssn_i != ssn_j:
            return True
        if ri['dob'] and rj['dob'] and ri['dob'] != rj['dob']:
            return True
        if ssn_i and ssn_j:
            l4i = ssn_last4(ssn_i)
            l4j = ssn_last4(ssn_j)
            if l4i != l4j:
                return True
        return False

    def should_merge(i, j):
        if definitely_different(i, j):
            return False

        ri, rj = records[i], records[j]
        same_last = ri['last'] == rj['last']
        if not same_last:
            return False

        fi, fj = ri['first'], rj['first']
        same_dob = ri['dob'] == rj['dob'] and ri['dob'] != ''
        same_phone = ri['phone'] == rj['phone'] and ri['phone'] != ''
        same_mail = mail_match(ri['mail'], rj['mail'])
        same_addr = ri['address'] == rj['address'] and ri['address'] != ''

        ssn_i, ssn_j = ri['ssn'], rj['ssn']
        ssn9_i = len(ssn_i) == 9
        ssn9_j = len(ssn_j) == 9
        ssn4_i = len(ssn_i) == 4
        ssn4_j = len(ssn_j) == 4

        if ssn9_i and ssn9_j:
            return ssn_i == ssn_j

        if ssn9_i and ssn4_j:
            return ssn_i[-4:] == ssn_j and names_compatible(fi, fj)
        if ssn9_j and ssn4_i:
            return ssn_j[-4:] == ssn_i and names_compatible(fi, fj)

        if ssn4_i and ssn4_j and ssn_i == ssn_j and same_dob:
            return names_compatible(fi, fj)

        a1 = fi in ambiguous
        a2 = fj in ambiguous
        exact_name = fi == fj

        if not exact_name and not a1 and not a2:
            return False

        if (a1 and not a2) or (a2 and not a1):
            has_ssn_link = (ssn_i and ssn_j and ssn_last4(ssn_i) == ssn_last4(ssn_j))
            if not has_ssn_link:
                return False
            return same_dob or same_mail or same_phone

        if a1 and a2:
            if not same_dob:
                return False
            score = 0
            if same_phone:
                score += 2
            if same_mail:
                score += 2
            if same_addr:
                score += 1
            has_ssn_link = (ssn_i and ssn_j and ssn_last4(ssn_i) == ssn_last4(ssn_j))
            if has_ssn_link:
                score += 2
            return score >= 3

        score = 0
        if same_dob:
            score += 3
        if same_phone:
            score += 2
        if same_mail:
            score += 2
        if same_addr:
            score += 1
        has_ssn_link = (ssn_i and ssn_j and ssn_last4(ssn_i) == ssn_last4(ssn_j))
        if has_ssn_link:
            score += 2
        return score >= 4

    blocks = defaultdict(set)
    for i, r in enumerate(records):
        if r['dob'] and r['last']:
            blocks[('ld', r['last'], r['dob'])].add(i)
        if r['phone']:
            blocks[('ph', r['phone'])].add(i)
        if r['mail']:
            blocks[('ml', r['mail'])].add(i)
        if r['ssn']:
            l4 = ssn_last4(r['ssn'])
            if l4:
                blocks[('s4', l4, r['last'])].add(i)

    checked = set()
    for key, members in blocks.items():
        ml = sorted(members)
        for ai in range(len(ml)):
            for bi in range(ai + 1, len(ml)):
                i, j = ml[ai], ml[bi]
                pair = (min(i, j), max(i, j))
                if pair in checked:
                    continue
                checked.add(pair)
                if should_merge(i, j):
                    union(i, j)

    clusters_map = defaultdict(list)
    for i in range(n):
        clusters_map[find(i)].append(records[i]['id'])

    return {'clusters': list(clusters_map.values())}
