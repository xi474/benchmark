import re


MONTH_MAP = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
    'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12',
}


def _clean_text(s):
    return re.sub(r'[^a-z0-9]', '', s.lower()) if s else ''


def _digits_only(s):
    return re.sub(r'\D', '', s) if s else ''


def _parse_internet_dob(s):
    if not s:
        return ''
    parts = s.split('/')
    if len(parts) != 3:
        return ''
    mm, dd, yyyy = parts
    return f'{yyyy}-{mm.zfill(2)}-{dd.zfill(2)}'


def _parse_streaming_dob(s):
    if not s:
        return ''
    parts = s.strip().split()
    if len(parts) != 3:
        return ''
    dd, mon, yyyy = parts
    mm = MONTH_MAP.get(mon.lower()[:3], '')
    if not mm:
        return ''
    return f'{yyyy}-{mm}-{dd.zfill(2)}'


def compute(payload):
    results = []
    for idx, rec in enumerate(payload.get('records', [])):
        src = rec.get('source', '')
        if src not in ('internet', 'streaming'):
            continue
        f = rec.get('fields', {})
        rid = rec['id']
        if src == 'internet':
            name_parts = f.get('full_name', '').strip().split(None, 1)
            first = _clean_text(name_parts[0]) if len(name_parts) > 0 else ''
            last = _clean_text(name_parts[1]) if len(name_parts) > 1 else ''
            dob = _parse_internet_dob(f.get('birth_date', ''))
            ssn = ''
            mail = _clean_text(f.get('mail', ''))
            phone = _digits_only(f.get('tel', ''))
            address = _clean_text(f.get('street', ''))
        else:
            name_parts = f.get('customer', '').strip().split(None, 1)
            first = _clean_text(name_parts[0]) if len(name_parts) > 0 else ''
            last = _clean_text(name_parts[1]) if len(name_parts) > 1 else ''
            dob = _parse_streaming_dob(f.get('date_of_birth', ''))
            ssn = ''
            mail = _clean_text(f.get('email', ''))
            phone = _digits_only(f.get('telephone', ''))
            address = _clean_text(f.get('address', ''))
        results.append([idx, {
            'id': rid,
            'first': first,
            'last': last,
            'dob': dob,
            'ssn': ssn,
            'mail': mail,
            'phone': phone,
            'address': address,
        }])
    return results
