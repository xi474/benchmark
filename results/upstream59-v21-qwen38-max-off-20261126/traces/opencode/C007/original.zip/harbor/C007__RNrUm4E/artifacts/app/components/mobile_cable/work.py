import re


def _clean_text(s):
    return re.sub(r'[^a-z0-9]', '', s.lower()) if s else ''


def _digits_only(s):
    return re.sub(r'\D', '', s) if s else ''


def _parse_mobile_dob(s):
    return s


def _parse_cable_birth(s):
    if not s or len(s) != 8:
        return ''
    return f'{s[:4]}-{s[4:6]}-{s[6:8]}'


def compute(payload):
    results = []
    for idx, rec in enumerate(payload.get('records', [])):
        src = rec.get('source', '')
        if src not in ('mobile', 'cable'):
            continue
        f = rec.get('fields', {})
        rid = rec['id']
        if src == 'mobile':
            first = _clean_text(f.get('first', ''))
            last = _clean_text(f.get('last', ''))
            dob = _parse_mobile_dob(f.get('dob', ''))
            ssn = _digits_only(f.get('ssn', ''))
            mail = _clean_text(f.get('email', ''))
            phone = _digits_only(f.get('phone', ''))
            address = _clean_text(f.get('address', ''))
        else:
            lf = f.get('last_first', '')
            parts = lf.split(',', 1)
            last = _clean_text(parts[0]) if len(parts) > 0 else ''
            first = _clean_text(parts[1]) if len(parts) > 1 else ''
            dob = _parse_cable_birth(f.get('birth', ''))
            ssn = _digits_only(f.get('government_id', ''))
            mail = _clean_text(f.get('contact', ''))
            phone = _digits_only(f.get('phone', ''))
            address = _clean_text(f.get('location', ''))
        results.append([idx, {
            'id': rid,
            'first': first,
            'last': last,
            'dob': dob,
            'ssn': ssn,
            'mail': mail,
            'phone': phone,
            'address': address,
        }])
    return results
