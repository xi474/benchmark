def combine(payload, left, right):
    all_records = []
    for _, obj in left:
        all_records.append(obj)
    for _, obj in right:
        all_records.append(obj)

    ids = [r['id'] for r in all_records]
    n = len(ids)

    AMBIGUOUS = set()
    for name in payload.get('ambiguous_names', []):
        AMBIGUOUS.add(name.lower().strip())

    def is_amb(name):
        return name in AMBIGUOUS

    def ssn_last4(s):
        return s[-4:] if len(s) >= 4 else s

    def ssn_compatible(a, b):
        sa, sb = a['ssn'], b['ssn']
        if not sa or not sb:
            return True
        la, lb = ssn_last4(sa), ssn_last4(sb)
        if len(sa) == 9 and len(sb) == 9:
            return sa == sb
        if len(sa) == 9 and len(sb) <= 4:
            return la == lb
        if len(sb) == 9 and len(sa) <= 4:
            return la == lb
        return la == lb

    def mail_dist(a, b):
        if not a or not b:
            return 999
        if a == b:
            return 0
        la, lb = len(a), len(b)
        if la == lb:
            return sum(1 for x, y in zip(a, b) if x != y)
        if abs(la - lb) == 1:
            shorter, longer = (a, b) if la < lb else (b, a)
            diffs = 0
            i = j = 0
            while i < len(shorter) and j < len(longer):
                if shorter[i] != longer[j]:
                    diffs += 1
                    j += 1
                    if diffs > 1:
                        return 999
                else:
                    i += 1
                    j += 1
            return diffs + (len(longer) - j)
        return 999

    parent = list(range(n))
    uf_rank = [0] * n

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        if uf_rank[ra] < uf_rank[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        if uf_rank[ra] == uf_rank[rb]:
            uf_rank[ra] += 1
        return True

    blocks = {}
    for i, r in enumerate(all_records):
        key = (r['last'], r['dob'])
        blocks.setdefault(key, []).append(i)

    edge_set = set()

    def add_edge(ai, bi):
        edge_set.add((min(ai, bi), max(ai, bi)))

    def has_edge(ai, bi):
        return (min(ai, bi), max(ai, bi)) in edge_set

    for key, members in blocks.items():
        if len(members) < 2:
            continue
        nonamb_by_name = {}
        amb_list = []
        for m in members:
            fn = all_records[m]['first']
            if is_amb(fn):
                amb_list.append(m)
            else:
                nonamb_by_name.setdefault(fn, []).append(m)

        for fn, group in nonamb_by_name.items():
            for ii in range(len(group)):
                for jj in range(ii + 1, len(group)):
                    ai, bi = group[ii], group[jj]
                    a, b = all_records[ai], all_records[bi]
                    if ssn_compatible(a, b):
                        ma, mb = a['mail'], b['mail']
                        if not (ma and mb and mail_dist(ma, mb) > 1):
                            add_edge(ai, bi)

        for am in amb_list:
            a_rec = all_records[am]
            best_fn = None
            best_score = -1
            for fn, group in nonamb_by_name.items():
                score = 0
                for gm in group:
                    g_rec = all_records[gm]
                    if not ssn_compatible(a_rec, g_rec):
                        continue
                    ma, mb = a_rec['mail'], g_rec['mail']
                    if ma and mb and mail_dist(ma, mb) > 1:
                        continue
                    s = 0
                    sa, sb = a_rec['ssn'], g_rec['ssn']
                    if sa and sb:
                        if len(sa) == 9 or len(sb) == 9:
                            s += 10
                        elif len(sa) <= 4 and len(sb) <= 4 and sa == sb:
                            s += 5
                    if ma and mb and mail_dist(ma, mb) <= 1:
                        s += 3
                    pa, pb = a_rec['phone'], g_rec['phone']
                    aa, ab = a_rec['address'], g_rec['address']
                    if (pa and pb and pa == pb) or (aa and ab and aa == ab):
                        s += 1
                    score += s
                if score > best_score:
                    best_score = score
                    best_fn = fn
            if best_fn is not None and best_score > 0:
                target = nonamb_by_name[best_fn][0]
                add_edge(am, target)

        unassigned_amb = [am for am in amb_list if not any(has_edge(am, gm) for fn, group in nonamb_by_name.items() for gm in group)]
        for ii in range(len(unassigned_amb)):
            for jj in range(ii + 1, len(unassigned_amb)):
                ai, bi = unassigned_amb[ii], unassigned_amb[jj]
                a, b = all_records[ai], all_records[bi]
                if ssn_compatible(a, b):
                    ma, mb = a['mail'], b['mail']
                    if not (ma and mb and mail_dist(ma, mb) > 1):
                        sa, sb = a['ssn'], b['ssn']
                        has_ssn = (sa and sb and (len(sa) == 9 or len(sb) == 9 or (len(sa) <= 4 and len(sb) <= 4 and sa == sb)))
                        mail_close = ma and mb and mail_dist(ma, mb) <= 1
                        shared = (a['phone'] and b['phone'] and a['phone'] == b['phone']) or \
                                 (a['address'] and b['address'] and a['address'] == b['address'])
                        if has_ssn or mail_close or shared:
                            add_edge(ai, bi)

    mail_idx = {}
    for i, r in enumerate(all_records):
        m = r['mail']
        if m:
            mail_idx.setdefault(m, []).append(i)

    for m, members in mail_idx.items():
        if len(members) < 2:
            continue
        for ii in range(len(members)):
            for jj in range(ii + 1, len(members)):
                ai, bi = members[ii], members[jj]
                if has_edge(ai, bi):
                    continue
                a, b = all_records[ai], all_records[bi]
                if a['last'] != b['last'] or a['dob'] != b['dob']:
                    continue
                fa, fb = a['first'], b['first']
                if not is_amb(fa) and not is_amb(fb) and fa != fb:
                    continue
                if not ssn_compatible(a, b):
                    continue
                add_edge(ai, bi)

    mail_keys = list(mail_idx.keys())
    near_pairs = []
    for ki in range(len(mail_keys)):
        for kj in range(ki + 1, len(mail_keys)):
            if mail_dist(mail_keys[ki], mail_keys[kj]) <= 1:
                near_pairs.append((mail_keys[ki], mail_keys[kj]))

    for ma, mb in near_pairs:
        for ai in mail_idx[ma]:
            for bi in mail_idx[mb]:
                if has_edge(ai, bi):
                    continue
                a, b = all_records[ai], all_records[bi]
                if a['last'] != b['last'] or a['dob'] != b['dob']:
                    continue
                fa, fb = a['first'], b['first']
                if not is_amb(fa) and not is_amb(fb) and fa != fb:
                    continue
                if not ssn_compatible(a, b):
                    continue
                add_edge(ai, bi)

    for e_ai, e_bi in edge_set:
        union(e_ai, e_bi)

    clusters_map = {}
    for i in range(n):
        root = find(i)
        clusters_map.setdefault(root, []).append(ids[i])

    return {'clusters': list(clusters_map.values())}
