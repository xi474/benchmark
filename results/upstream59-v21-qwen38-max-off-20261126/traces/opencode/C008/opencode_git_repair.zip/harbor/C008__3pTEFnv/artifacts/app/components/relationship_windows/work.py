def compute(payload):
    result = []
    for link in payload.get("links", []):
        result.append([link["a"], link["b"], 0, 10**18])
    for merge in payload.get("merges", []):
        result.append([merge["a"], merge["b"], merge.get("from", 0), merge.get("to", 10**18)])
    return result
