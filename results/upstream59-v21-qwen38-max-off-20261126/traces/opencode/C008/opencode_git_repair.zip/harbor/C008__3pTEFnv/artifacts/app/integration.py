import json
import hashlib


def combine(payload, left, right):
    seed = payload["seed"]
    windows = left
    recs = right

    out_records = []
    for table, rid, t, subj in recs:
        tenant, subject = subj
        node = (tenant, subject)

        parent = {node: node}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                if ra > rb:
                    ra, rb = rb, ra
                parent[rb] = ra

        for edge in windows:
            a_pair = tuple(edge[0])
            b_pair = tuple(edge[1])
            ef, et = edge[2], edge[3]
            if ef <= t < et:
                if a_pair not in parent:
                    parent[a_pair] = a_pair
                if b_pair not in parent:
                    parent[b_pair] = b_pair
                union(a_pair, b_pair)

        root = find(node)
        members = [k for k in parent if find(k) == root]
        canonical = min(members)
        canonical_tenant, canonical_subject = canonical

        raw = json.dumps(
            [str(seed), canonical_tenant, canonical_subject],
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8")
        h = hashlib.sha256(raw).hexdigest()[:12]
        token = "ref_" + h

        out_records.append({
            "table": table,
            "id": rid,
            "time": t,
            "token": token,
        })

    return {"records": out_records}
