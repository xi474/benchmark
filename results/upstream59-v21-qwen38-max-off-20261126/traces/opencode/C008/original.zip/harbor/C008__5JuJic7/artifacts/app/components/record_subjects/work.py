def compute(payload):
    result = []
    for rec in payload.get("records", []):
        result.append([rec["table"], rec["id"], rec["time"], [rec["tenant"], rec["subject"]]])
    return result
