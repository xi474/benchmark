def compute(payload):
    INF = 10**18
    result = []
    for link in payload.get("links", []):
        result.append([link["a"], link["b"], 0, INF])
    for merge in payload.get("merges", []):
        result.append([merge["a"], merge["b"], merge.get("from", 0), merge.get("to", INF)])
    return result
