import json
import hashlib


def combine(payload, left, right):
    seed = payload["seed"]
    windows = left
    records_info = right

    all_times = sorted(set(r[2] for r in records_info))

    time_components = {}
    for t in all_times:
        active_edges = []
        for w in windows:
            if w[2] <= t < w[3]:
                active_edges.append((tuple(w[0]), tuple(w[1])))

        nodes = set()
        for a, b in active_edges:
            nodes.add(a)
            nodes.add(b)

        parent = {}
        rank = {}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            rx, ry = find(x), find(y)
            if rx == ry:
                return
            if rank[rx] < rank[ry]:
                rx, ry = ry, rx
            parent[ry] = rx
            if rank[rx] == rank[ry]:
                rank[rx] += 1

        for n in nodes:
            parent[n] = n
            rank[n] = 0

        for a, b in active_edges:
            union(a, b)

        components = {}
        for n in nodes:
            root = find(n)
            if root not in components:
                components[root] = []
            components[root].append(n)

        canonical_map = {}
        for members in components.values():
            canon = min(members)
            for m in members:
                canonical_map[m] = canon

        time_components[t] = canonical_map

    result_records = []
    for rec in records_info:
        table, rid, t, subject_tuple = rec[0], rec[1], rec[2], tuple(rec[3])
        canon = time_components[t].get(subject_tuple, subject_tuple)
        raw = json.dumps(
            [str(seed), canon[0], canon[1]],
            ensure_ascii=True,
            separators=(",", ":"),
        )
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]
        token = "ref_" + h
        result_records.append({
            "table": table,
            "id": rid,
            "time": t,
            "token": token,
        })

    return {"records": result_records}
