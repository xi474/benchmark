def compute(payload):
    vehicles = payload["vehicles"]
    drivers = payload["drivers"]
    result = {}
    for v in vehicles:
        vtype = v["type"]
        compatible = [d["id"] for d in drivers if vtype in d["types"]]
        result[v["id"]] = compatible
    return result
