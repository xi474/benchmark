from itertools import product


def combine(payload, sorted_events, crew_compat):
    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    rounds = payload["rounds"]

    committed = []
    committed_jobs = set()
    cancelled_set = set()
    result_rounds = []

    for rnd in rounds:
        cutoff = rnd["cutoff"]
        do_commit = rnd["commit"]

        visible = [e for e in sorted_events if e["visible"] <= cutoff]

        pending_requests = {}
        cancel_targets = []
        for e in visible:
            if e["kind"] == "request":
                jid = e["job"]["id"]
                if jid not in committed_jobs and jid not in cancelled_set:
                    pending_requests[jid] = e["job"]
            elif e["kind"] == "cancel":
                cancel_targets.append(e["job"])

        ignored_cancellations = []
        new_cancelled = []
        for jid in cancel_targets:
            if jid in cancelled_set:
                continue
            if jid in committed_jobs:
                a = None
                for ca in committed:
                    if ca["job"] == jid:
                        a = ca
                        break
                if a and a["start"] < cutoff:
                    ignored_cancellations.append(jid)
                else:
                    committed = [ca for ca in committed if ca["job"] != jid]
                    committed_jobs.discard(jid)
                    new_cancelled.append(jid)
            else:
                if jid in pending_requests:
                    del pending_requests[jid]
                new_cancelled.append(jid)

        cancelled_set.update(new_cancelled)

        jobs_to_schedule = {}
        for jid, job in pending_requests.items():
            if job["type"] not in [v["type"] for v in vehicles.values()]:
                continue
            jobs_to_schedule[jid] = job

        best = _optimize(jobs_to_schedule, vehicles, drivers, suppliers, crew_compat, committed, cutoff)

        new_assignments = best["assignments"]
        new_profit = best["profit"]

        if do_commit:
            committed.extend(new_assignments)
            for a in new_assignments:
                committed_jobs.add(a["job"])

        all_assignments = committed + (new_assignments if not do_commit else [])

        all_assignments_sorted = sorted(all_assignments, key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))

        total_profit = sum(a["profit"] for a in all_assignments_sorted)

        ign_sorted = sorted(set(ignored_cancellations))
        canc_sorted = sorted(set(new_cancelled))

        result_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments_sorted,
            "profit": total_profit,
            "cancelled": canc_sorted,
            "ignored_cancellations": ign_sorted,
        })

    return {"rounds": result_rounds}


def _optimize(jobs, vehicles, drivers, suppliers, crew_compat, committed, cutoff):
    job_list = sorted(jobs.keys())
    if not job_list:
        return {"assignments": [], "profit": 0}

    committed_vehicle_slots = []
    committed_driver_slots = []
    supplier_used = {}
    driver_work = {}
    driver_tasks = {}

    for ca in committed:
        committed_vehicle_slots.append((ca["vehicle"], ca["start"], ca["end"]))
        committed_driver_slots.append((ca["driver"], ca["start"], ca["end"]))
        sid = ca["supplier"]
        supplier_used[sid] = supplier_used.get(sid, 0) + ca["quantity"]
        did = ca["driver"]
        dur = ca["end"] - ca["start"]
        if did not in driver_work:
            driver_work[did] = 0
            driver_tasks[did] = []
        driver_work[did] += dur
        driver_tasks[did].append((ca["start"], ca["end"]))

    vid_list = sorted(vehicles.keys())
    did_list = sorted(drivers.keys())

    options = {}
    for jid in job_list:
        job = jobs[jid]
        jtype = job["type"]
        qty = job["quantity"]
        release = job["release"]
        deadline = job["deadline"]
        duration = job["duration"]
        revenue = job["revenue"]
        sup_ids = job["suppliers"]

        earliest = max(cutoff, release)
        opts = []
        for vid in vid_list:
            v = vehicles[vid]
            if v["type"] != jtype or v["capacity"] < qty:
                continue
            compat_drivers = crew_compat.get(vid, [])
            for did in compat_drivers:
                for sid in sup_ids:
                    s = suppliers[sid]
                    latest_start = min(deadline - duration, s["close"])
                    for st in range(earliest, latest_start + 1):
                        en = st + duration
                        profit = revenue - qty * s["unit_cost"] - v["cost"] * duration
                        opts.append((jid, vid, did, sid, st, en, qty, profit))
        options[jid] = opts

    best_result = {"assignments": [], "profit": 0}

    def search(idx, current_assignments, current_profit, used_vehicles, used_drivers, sup_consumed, d_work, d_tasks_map, assigned_jobs):
        nonlocal best_result

        if idx == len(job_list):
            count = len(current_assignments)
            best_count = len(best_result["assignments"])
            if current_profit > best_result["profit"]:
                best_result = {"assignments": list(current_assignments), "profit": current_profit}
            elif current_profit == best_result["profit"]:
                if count > best_count:
                    best_result = {"assignments": list(current_assignments), "profit": current_profit}
                elif count == best_count:
                    cur_tuple = tuple((a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]) for a in sorted(current_assignments, key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])))
                    best_tuple = tuple((a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]) for a in sorted(best_result["assignments"], key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])))
                    if cur_tuple < best_tuple:
                        best_result = {"assignments": list(current_assignments), "profit": current_profit}
            return

        jid = job_list[idx]

        search(idx + 1, current_assignments, current_profit, used_vehicles, used_drivers, sup_consumed, d_work, d_tasks_map, assigned_jobs)

        for opt in options[jid]:
            _, vid, did, sid, st, en, qty, profit = opt

            overlap_v = False
            for uv, us, ue in used_vehicles:
                if uv == vid and st < ue and en > us:
                    overlap_v = True
                    break
            if overlap_v:
                continue

            overlap_d = False
            for ud, us, ue in used_drivers:
                if ud == did and st < ue and en > us:
                    overlap_d = True
                    break
            if overlap_d:
                continue

            s = suppliers[sid]
            used_so_far = sup_consumed.get(sid, 0)
            if used_so_far + qty > s["stock"]:
                continue

            d = drivers[did]
            cur_work = d_work.get(did, 0)
            new_work = cur_work + (en - st)
            if new_work > d["max_work"]:
                continue

            cur_tasks = d_tasks_map.get(did, [])
            all_tasks = sorted(cur_tasks + [(st, en)])
            max_cont = d["max_continuous"]
            brk = d["break"]

            cont = 0
            valid = True
            for i in range(len(all_tasks)):
                ts, te = all_tasks[i]
                if i == 0:
                    cont = te - ts
                else:
                    gap = ts - all_tasks[i - 1][1]
                    if gap >= brk:
                        cont = te - ts
                    else:
                        cont += te - ts
                if cont > max_cont:
                    valid = False
                    break
            if not valid:
                continue

            assignment = {
                "job": jid,
                "vehicle": vid,
                "driver": did,
                "supplier": sid,
                "start": st,
                "end": en,
                "quantity": qty,
                "profit": profit,
            }

            new_sup = dict(sup_consumed)
            new_sup[sid] = new_sup.get(sid, 0) + qty
            new_dwork = dict(d_work)
            new_dwork[did] = new_work
            new_dtasks = dict(d_tasks_map)
            new_dtasks[did] = all_tasks

            current_assignments.append(assignment)
            used_vehicles.append((vid, st, en))
            used_drivers.append((did, st, en))
            assigned_jobs.add(jid)

            search(idx + 1, current_assignments, current_profit + profit, used_vehicles, used_drivers, new_sup, new_dwork, new_dtasks, assigned_jobs)

            current_assignments.pop()
            used_vehicles.pop()
            used_drivers.pop()
            assigned_jobs.discard(jid)

    search(0, [], 0, list(committed_vehicle_slots), list(committed_driver_slots), dict(supplier_used), dict(driver_work), {k: list(v) for k, v in driver_tasks.items()}, set())

    return best_result
