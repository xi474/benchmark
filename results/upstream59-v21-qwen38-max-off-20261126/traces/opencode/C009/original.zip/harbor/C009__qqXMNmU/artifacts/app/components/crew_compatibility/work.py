def compute(payload):
    vehicles = payload["vehicles"]
    drivers = payload["drivers"]
    result = {}
    for v in vehicles:
        compatible = []
        for d in drivers:
            if v["type"] in d["types"]:
                compatible.append(d["id"])
        result[v["id"]] = compatible
    return result
