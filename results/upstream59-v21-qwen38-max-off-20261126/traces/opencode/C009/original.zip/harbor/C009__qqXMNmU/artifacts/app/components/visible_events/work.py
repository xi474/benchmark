def compute(payload):
    events = payload["events"]
    return sorted(events, key=lambda e: (e["visible"], e["id"]))
