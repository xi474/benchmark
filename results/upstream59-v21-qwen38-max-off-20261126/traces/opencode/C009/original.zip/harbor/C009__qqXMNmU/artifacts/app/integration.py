from itertools import product


def combine(payload, sorted_events, crew_compat):
    vehicles = {v["id"]: v for v in payload["vehicles"]}
    drivers = {d["id"]: d for d in payload["drivers"]}
    suppliers = {s["id"]: s for s in payload["suppliers"]}
    rounds = payload["rounds"]

    committed = []
    all_cancelled = set()
    all_ignored = set()
    completed_jobs = set()
    result_rounds = []

    for rnd in rounds:
        cutoff = rnd["cutoff"]
        do_commit = rnd["commit"]

        visible = [e for e in sorted_events if e["visible"] <= cutoff]

        pending_requests = {}
        cancel_ids = set()
        for e in visible:
            if e["kind"] == "request":
                jid = e["job"]["id"]
                if jid not in completed_jobs and jid not in all_cancelled:
                    pending_requests[jid] = e["job"]
            elif e["kind"] == "cancel":
                cancel_ids.add(e["job"])

        ignored_cancellations = set()
        new_cancelled = set()
        for cid in cancel_ids:
            if cid in all_cancelled:
                continue
            found_committed = False
            for a in committed:
                if a["job"] == cid and a["start"] < cutoff:
                    found_committed = True
                    break
            if found_committed:
                ignored_cancellations.add(cid)
            elif cid in pending_requests:
                new_cancelled.add(cid)
            else:
                new_cancelled.add(cid)

        all_cancelled |= new_cancelled
        all_ignored |= ignored_cancellations

        for cid in new_cancelled:
            pending_requests.pop(cid, None)

        committed_job_ids = {a["job"] for a in committed}
        available_jobs = {jid: j for jid, j in pending_requests.items()
                         if jid not in committed_job_ids}

        supplier_used = {}
        for a in committed:
            supplier_used[a["supplier"]] = supplier_used.get(a["supplier"], 0) + a["quantity"]

        driver_tasks = {}
        for a in committed:
            driver_tasks.setdefault(a["driver"], []).append((a["start"], a["end"]))

        vehicle_tasks = {}
        for a in committed:
            vehicle_tasks.setdefault(a["vehicle"], []).append((a["start"], a["end"]))

        def calc_profit(job, vehicle_id, supplier_id):
            v = vehicles[vehicle_id]
            s = suppliers[supplier_id]
            return job["revenue"] - job["quantity"] * s["unit_cost"] - v["cost"] * job["duration"]

        def check_time_overlap(existing, start, end):
            for es, ee in existing:
                if start < ee and end > es:
                    return True
            return False

        def check_driver_constraints(driver_id, new_start, new_end, extra_tasks=None):
            d = drivers[driver_id]
            tasks = list(driver_tasks.get(driver_id, []))
            if extra_tasks:
                tasks.extend(extra_tasks)
            tasks.append((new_start, new_end))
            tasks.sort()

            total_work = sum(e - s for s, e in tasks)
            if total_work > d["max_work"]:
                return False

            continuous = 0
            brk = d["break"]
            for i in range(len(tasks)):
                dur = tasks[i][1] - tasks[i][0]
                if i == 0:
                    continuous = dur
                else:
                    gap = tasks[i][0] - tasks[i - 1][1]
                    if gap >= brk:
                        continuous = dur
                    else:
                        continuous += dur
                if continuous > d["max_continuous"]:
                    return False
            return True

        def get_feasible_options(job):
            options = []
            jid = job["id"]
            jtype = job["type"]
            qty = job["quantity"]
            release = job["release"]
            deadline = job["deadline"]
            duration = job["duration"]
            job_suppliers = job["suppliers"]

            for vid in sorted(vehicles.keys()):
                v = vehicles[vid]
                if v["type"] != jtype or v["capacity"] < qty:
                    continue
                compatible_drivers = crew_compat.get(vid, [])

                for sid in sorted(job_suppliers):
                    s = suppliers[sid]
                    used = supplier_used.get(sid, 0)
                    if used + qty > s["stock"]:
                        continue

                    earliest = max(cutoff, release)
                    latest_start = min(deadline - duration, s["close"])
                    if earliest > latest_start:
                        continue

                    for did in compatible_drivers:
                        for start in range(earliest, latest_start + 1):
                            end = start + duration
                            vtasks = vehicle_tasks.get(vid, [])
                            if check_time_overlap(vtasks, start, end):
                                continue
                            if not check_driver_constraints(did, start, end):
                                continue
                            p = calc_profit(job, vid, sid)
                            options.append((p, jid, start, vid, did, sid, end, qty))
            return options

        best_assignment = None
        best_profit = None
        best_count = -1
        best_tuple = None

        job_list = sorted(available_jobs.values(), key=lambda j: j["id"])

        def solve(idx, current_assignments, current_profit, used_jobs, supp_used, drv_tasks_new, veh_tasks_new):
            nonlocal best_assignment, best_profit, best_count, best_tuple

            if idx == len(job_list):
                count = len(current_assignments)
                tup = tuple(sorted([(a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"])
                                    for a in current_assignments]))
                if (best_profit is None or current_profit > best_profit or
                    (current_profit == best_profit and count > best_count) or
                    (current_profit == best_profit and count == best_count and tup < best_tuple)):
                    best_profit = current_profit
                    best_count = count
                    best_tuple = tup
                    best_assignment = [dict(a) for a in current_assignments]
                return

            job = job_list[idx]
            jid = job["id"]

            solve(idx + 1, current_assignments, current_profit, used_jobs, supp_used, drv_tasks_new, veh_tasks_new)

            options = []
            jtype = job["type"]
            qty = job["quantity"]
            release = job["release"]
            deadline = job["deadline"]
            duration = job["duration"]
            job_suppliers = job["suppliers"]

            for vid in sorted(vehicles.keys()):
                v = vehicles[vid]
                if v["type"] != jtype or v["capacity"] < qty:
                    continue
                compatible_drivers = crew_compat.get(vid, [])

                for sid in sorted(job_suppliers):
                    s = suppliers[sid]
                    used = supp_used.get(sid, 0)
                    if used + qty > s["stock"]:
                        continue

                    earliest = max(cutoff, release)
                    latest_start = min(deadline - duration, s["close"])
                    if earliest > latest_start:
                        continue

                    for did in compatible_drivers:
                        for start in range(earliest, latest_start + 1):
                            end = start + duration
                            all_vtasks = list(vehicle_tasks.get(vid, [])) + list(veh_tasks_new.get(vid, []))
                            if check_time_overlap(all_vtasks, start, end):
                                continue

                            all_dtasks = list(driver_tasks.get(did, [])) + list(drv_tasks_new.get(did, []))
                            combined_dtasks = all_dtasks + [(start, end)]
                            combined_dtasks.sort()
                            d = drivers[did]
                            total_work = sum(e - s for s, e in combined_dtasks)
                            if total_work > d["max_work"]:
                                continue
                            continuous = 0
                            brk = d["break"]
                            valid = True
                            for i in range(len(combined_dtasks)):
                                dur = combined_dtasks[i][1] - combined_dtasks[i][0]
                                if i == 0:
                                    continuous = dur
                                else:
                                    gap = combined_dtasks[i][0] - combined_dtasks[i - 1][1]
                                    if gap >= brk:
                                        continuous = dur
                                    else:
                                        continuous += dur
                                if continuous > d["max_continuous"]:
                                    valid = False
                                    break
                            if not valid:
                                continue

                            p = calc_profit(job, vid, sid)
                            options.append((p, start, vid, did, sid, end))

            for p, start, vid, did, sid, end in options:
                new_supp = dict(supp_used)
                new_supp[sid] = new_supp.get(sid, 0) + qty
                new_drv = dict(drv_tasks_new)
                new_drv.setdefault(did, []).append((start, end))
                new_veh = dict(veh_tasks_new)
                new_veh.setdefault(vid, []).append((start, end))

                assignment = {
                    "job": jid,
                    "vehicle": vid,
                    "driver": did,
                    "supplier": sid,
                    "start": start,
                    "end": end,
                    "quantity": qty,
                    "profit": p
                }
                solve(idx + 1,
                      current_assignments + [assignment],
                      current_profit + p,
                      used_jobs | {jid},
                      new_supp, new_drv, new_veh)

        solve(0, [], 0, set(), dict(supplier_used), {}, {})

        new_assignments = best_assignment if best_assignment else []

        if do_commit:
            committed.extend(new_assignments)
            for a in new_assignments:
                supplier_used[a["supplier"]] = supplier_used.get(a["supplier"], 0) + a["quantity"]

        all_assignments = list(committed)
        all_assignments_sorted = sorted(all_assignments,
                                        key=lambda a: (a["job"], a["start"], a["vehicle"], a["driver"], a["supplier"]))

        total_profit = sum(a["profit"] for a in all_assignments_sorted)

        cancelled_list = sorted(all_cancelled)
        ignored_list = sorted(all_ignored)

        result_rounds.append({
            "cutoff": cutoff,
            "assignments": all_assignments_sorted,
            "profit": total_profit,
            "cancelled": cancelled_list,
            "ignored_cancellations": ignored_list
        })

    return {"rounds": result_rounds}
