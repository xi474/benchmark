def compute(payload):
    orders = payload["orders"]
    released = set(payload["released"])
    routing = payload["routing"]
    lines = payload["lines"]
    wip_list = payload["wip"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]

    wip_by_line = {}
    for w in wip_list:
        ln = w["line"]
        if ln not in wip_by_line or w["end"] > wip_by_line[ln]:
            wip_by_line[ln] = w["end"]

    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]
        if sku not in released:
            result[oid] = []
            continue
        rt = routing[sku]
        duration = rt["setup"] + rt["per_unit"] * qty
        triples = []
        for line in lines:
            lid = line["id"]
            if sku not in line["qualified"]:
                continue
            earliest = freeze
            if lid in wip_by_line:
                earliest = max(earliest, wip_by_line[lid] + changeover)
            for ws, we in line["windows"]:
                s_min = max(earliest, ws)
                s_max = we - duration
                for s in range(s_min, s_max + 1):
                    e = s + duration
                    if e <= due:
                        triples.append([lid, s, e])
        result[oid] = triples
    return result
