def compute(payload):
    orders = payload["orders"]
    bom = payload["bom"]

    def expand(sku, multiplier, acc):
        if sku not in bom:
            acc[sku] = acc.get(sku, 0) + multiplier
        else:
            for child, qty in bom[sku].items():
                expand(child, multiplier * qty, acc)

    result = {}
    for order in orders:
        demand = {}
        expand(order["sku"], order["qty"], demand)
        result[order["id"]] = demand
    return result
