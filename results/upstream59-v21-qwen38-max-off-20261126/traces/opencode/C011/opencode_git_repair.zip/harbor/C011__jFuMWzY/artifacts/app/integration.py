from itertools import combinations


def combine(payload, left, right):
    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    lines_info = payload["lines"]
    lots = payload["lots"]
    orders = payload["orders"]
    wip_list = payload["wip"]
    substitutes = payload.get("substitutes", {})

    demand_map = left
    windows_map = right

    order_by_id = {o["id"]: o for o in orders}

    valid_lots = [lt for lt in lots if lt["status"] == "PASS"]
    valid_lots_sorted = sorted(valid_lots, key=lambda lt: lt["id"])

    def get_substitutes(comp):
        return substitutes.get(comp, [comp])

    def find_lex_min_alloc(selected_ids, assignments):
        sorted_oids = sorted(selected_ids)
        lot_cap = {lt["id"]: lt["qty"] for lt in valid_lots}

        per_order_needs = []
        for oid in sorted_oids:
            end_time = assignments[oid][2]
            needs = demand_map[oid]
            comps = []
            for comp in sorted(needs.keys()):
                qty_needed = needs[comp]
                sub_mats = set(get_substitutes(comp))
                eligible = [lt for lt in valid_lots_sorted
                            if lt["material"] in sub_mats and lt["expiry"] >= end_time]
                comps.append((comp, qty_needed, eligible))
            per_order_needs.append((oid, comps))

        best_alloc = None

        def recurse(idx, remaining_caps, current_alloc):
            nonlocal best_alloc
            if idx == len(per_order_needs):
                sched = build_st(selected_ids, assignments, current_alloc)
                if best_alloc is None or sched < best_alloc[0]:
                    best_alloc = (sched, {k: list(v) for k, v in current_alloc.items()})
                return
            oid, comps = per_order_needs[idx]
            _alloc_comps(oid, comps, 0, remaining_caps, current_alloc, idx)

        def _alloc_comps(oid, comps, ci, caps, current_alloc, order_idx):
            nonlocal best_alloc
            if ci == len(comps):
                recurse(order_idx + 1, caps, current_alloc)
                return
            comp, qty_needed, eligible = comps[ci]
            if qty_needed == 0:
                _alloc_comps(oid, comps, ci + 1, caps, current_alloc, order_idx)
                return
            ways = _enum_splits(qty_needed, eligible, caps)
            for way in ways:
                new_caps = dict(caps)
                alloc_entries = []
                for lt_id, take in way:
                    new_caps[lt_id] -= take
                    alloc_entries.append((comp, lt_id, take))
                old = current_alloc.get(oid, [])
                current_alloc[oid] = old + alloc_entries
                _alloc_comps(oid, comps, ci + 1, new_caps, current_alloc, order_idx)
                current_alloc[oid] = old

        def _enum_splits(qty, eligible, caps):
            if qty == 0:
                yield []
                return
            if not eligible:
                return
            lt = eligible[0]
            rest = eligible[1:]
            avail = caps.get(lt["id"], 0)
            max_take = min(qty, avail)
            for take in range(1, max_take + 1):
                for sub in _enum_splits(qty - take, rest, caps):
                    yield [(lt["id"], take)] + sub
            for sub in _enum_splits(qty, rest, caps):
                yield sub

        recurse(0, lot_cap, {})
        if best_alloc is None:
            return None
        return best_alloc[1]

    def build_st(selected_ids, assignments, alloc_result):
        entries = []
        for oid in sorted(selected_ids):
            line, start, end = assignments[oid]
            alloc = tuple(sorted(alloc_result.get(oid, [])))
            entries.append((oid, line, start, end, alloc))
        return tuple(entries)

    priority_groups = {}
    for o in orders:
        p = o["priority"]
        if p not in priority_groups:
            priority_groups[p] = []
        priority_groups[p].append(o["id"])

    all_priorities = sorted(priority_groups.keys())

    best_selected = None
    best_assignments = None
    best_alloc = None
    best_st = None

    def search(current_selected, current_assignments, pri_idx):
        nonlocal best_selected, best_assignments, best_alloc, best_st

        if pri_idx >= len(all_priorities):
            alloc_result = find_lex_min_alloc(current_selected, current_assignments)
            if alloc_result is None:
                return
            st = build_st(current_selected, current_assignments, alloc_result)
            if best_st is None or _is_better(current_selected, st, best_selected, best_st):
                best_selected = list(current_selected)
                best_assignments = dict(current_assignments)
                best_alloc = alloc_result
                best_st = st
            return

        pri = all_priorities[pri_idx]
        candidates = priority_groups[pri]
        for size in range(len(candidates), -1, -1):
            for combo in combinations(candidates, size):
                new_selected = list(current_selected) + list(combo)
                if not _can_beat(new_selected, pri_idx):
                    continue
                for asgn in _enum_placements(list(combo), current_assignments):
                    merged = dict(current_assignments)
                    merged.update(asgn)
                    search(new_selected, merged, pri_idx + 1)
            if best_selected is not None:
                cur_pri_qty = sum(order_by_id[oid]["qty"] for oid in current_selected if order_by_id[oid]["priority"] == pri)
                added_qty = sum(order_by_id[oid]["qty"] for oid in combo)
                best_pri_qty = sum(order_by_id[oid]["qty"] for oid in best_selected if order_by_id[oid]["priority"] == pri)
                if cur_pri_qty + added_qty < best_pri_qty:
                    break

    def _can_beat(candidate_selected, pri_idx):
        if best_selected is None:
            return True
        for i in range(pri_idx):
            p = all_priorities[i]
            cq = sum(order_by_id[oid]["qty"] for oid in candidate_selected if order_by_id[oid]["priority"] == p)
            bq = sum(order_by_id[oid]["qty"] for oid in best_selected if order_by_id[oid]["priority"] == p)
            if cq != bq:
                return cq > bq
        return True

    def _is_better(sel_a, st_a, sel_b, st_b):
        for p in all_priorities:
            qa = sum(order_by_id[oid]["qty"] for oid in sel_a if order_by_id[oid]["priority"] == p)
            qb = sum(order_by_id[oid]["qty"] for oid in sel_b if order_by_id[oid]["priority"] == p)
            if qa != qb:
                return qa > qb
        order_key = lambda x: (order_by_id[x]["priority"], order_by_id[x]["due"], x)
        vec_a = tuple(1 if oid in set(sel_a) else 0 for oid in sorted(order_by_id.keys(), key=order_key))
        vec_b = tuple(1 if oid in set(sel_b) else 0 for oid in sorted(order_by_id.keys(), key=order_key))
        if vec_a != vec_b:
            return vec_a > vec_b
        return st_a < st_b

    def _enum_placements(order_ids, existing):
        if not order_ids:
            yield {}
            return
        oid = order_ids[0]
        rest = order_ids[1:]
        for lid, s, e in windows_map.get(oid, []):
            if _conflicts(lid, s, e, existing):
                continue
            ext = dict(existing)
            ext[oid] = (lid, s, e)
            for sub in _enum_placements(rest, ext):
                r = {oid: (lid, s, e)}
                r.update(sub)
                yield r

    def _conflicts(lid, s, e, assignments):
        for _, (ol, os, oe) in assignments.items():
            if ol != lid:
                continue
            if s < oe + changeover and os < e + changeover:
                return True
        return False

    init_asgn = {}
    for w in wip_list:
        init_asgn[w["id"]] = (w["line"], w["start"], w["end"])

    search([], init_asgn, 0)

    if best_selected is None:
        selected_sorted = []
        erp_orders = []
        mes_entries = []
        wms_entries = []
    else:
        selected_sorted = sorted(best_selected)
        assignments = best_assignments
        alloc_result = best_alloc

        erp_orders = []
        for oid in selected_sorted:
            o = order_by_id[oid]
            line, start, end = assignments[oid]
            erp_orders.append({
                "wo": oid, "run": run_id, "sku": o["sku"], "qty": o["qty"],
                "due": o["due"], "start": start, "end": end, "line": line,
                "status": "PLANNED", "parent": oid
            })
        for w in wip_list:
            erp_orders.append({
                "wo": w["id"], "run": run_id, "sku": w["sku"], "qty": w["qty"],
                "due": w["due"], "start": w["start"], "end": w["end"], "line": w["line"],
                "status": "WIP_CONT", "parent": None
            })
        erp_orders.sort(key=lambda x: x["wo"])

        mes_all = []
        for oid in selected_sorted:
            o = order_by_id[oid]
            line, start, end = assignments[oid]
            mes_all.append({"run": run_id, "line": line, "wo": oid, "qty": o["qty"],
                            "start": start, "end": end, "status": "PLANNED"})
        for w in wip_list:
            mes_all.append({"run": run_id, "line": w["line"], "wo": w["id"], "qty": w["qty"],
                            "start": w["start"], "end": w["end"], "status": "WIP_CONT"})
        mes_all.sort(key=lambda x: (x["line"], x["start"], x["wo"]))
        mes_entries = []
        lc = {}
        for entry in mes_all:
            ln = entry["line"]
            seq = lc.get(ln, 0) + 1
            lc[ln] = seq
            mes_entries.append({"run": entry["run"], "line": ln, "seq": seq, "wo": entry["wo"],
                                "qty": entry["qty"], "start": entry["start"], "end": entry["end"],
                                "status": entry["status"]})

        wms_raw = []
        for oid in selected_sorted:
            for comp, lot_id, qty in alloc_result.get(oid, []):
                wms_raw.append((oid, comp, lot_id, qty))
        wms_raw.sort()
        wms_entries = []
        for idx, (wo, comp, lot_id, qty) in enumerate(wms_raw, 1):
            wms_entries.append({"reservation": f"r{idx:04d}", "run": run_id, "wo": wo,
                                "component": comp, "lot": lot_id, "qty": qty, "status": "RESERVED"})

    return {
        "selected": selected_sorted,
        "erp": {"run": {"id": run_id, "freeze": freeze}, "orders": erp_orders},
        "mes": mes_entries,
        "wms": wms_entries
    }
