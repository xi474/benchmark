def compute(payload):
    orders = payload["orders"]
    released = set(payload["released"])
    routing = payload["routing"]
    lines = payload["lines"]
    wip_list = payload.get("wip", [])
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    wip_end_by_line = {}
    for w in wip_list:
        ln = w["line"]
        e = w["end"]
        if ln not in wip_end_by_line or e > wip_end_by_line[ln]:
            wip_end_by_line[ln] = e
    result = {}
    for order in orders:
        oid = order["id"]
        sku = order["sku"]
        qty = order["qty"]
        due = order["due"]
        if sku not in released:
            result[oid] = []
            continue
        rt = routing[sku]
        duration = rt["setup"] + rt["per_unit"] * qty
        triples = []
        for line in lines:
            lid = line["id"]
            if sku not in line["qualified"]:
                continue
            min_start = freeze
            if lid in wip_end_by_line:
                min_start = max(min_start, wip_end_by_line[lid] + changeover)
            for ws, we in line["windows"]:
                lo = max(min_start, ws)
                hi = min(we - duration, due - duration)
                for s in range(lo, hi + 1):
                    triples.append([lid, s, s + duration])
        result[oid] = triples
    return result
