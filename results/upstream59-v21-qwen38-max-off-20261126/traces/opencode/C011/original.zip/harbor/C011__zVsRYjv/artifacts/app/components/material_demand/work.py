def compute(payload):
    orders = payload["orders"]
    bom = payload["bom"]
    result = {}
    for order in orders:
        demand = {}
        stack = [(order["sku"], order["qty"])]
        while stack:
            item, qty = stack.pop()
            if item in bom:
                for child, mult in bom[item].items():
                    stack.append((child, qty * mult))
            else:
                demand[item] = demand.get(item, 0) + qty
        result[order["id"]] = demand
    return result
