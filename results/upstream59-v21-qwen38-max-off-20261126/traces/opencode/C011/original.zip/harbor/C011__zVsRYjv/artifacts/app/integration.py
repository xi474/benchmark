import itertools


def combine(payload, demands, windows):
    run_id = payload["run_id"]
    freeze = payload["freeze"]
    changeover = payload["changeover"]
    lines_info = {l["id"]: l for l in payload["lines"]}
    lots = payload.get("lots", [])
    substitutes = payload.get("substitutes", {})
    orders = payload["orders"]
    wip_list = payload.get("wip", [])
    order_map = {o["id"]: o for o in orders}

    valid_lots = []
    for lot in lots:
        if lot["status"] == "PASS":
            valid_lots.append(lot)
    lot_map = {lot["id"]: lot for lot in valid_lots}

    wip_by_line = {}
    for w in wip_list:
        ln = w["line"]
        if ln not in wip_by_line:
            wip_by_line[ln] = []
        wip_by_line[ln].append(w)

    def get_eligible_lot_ids(component, task_end):
        subs = set(substitutes.get(component, [component]))
        return [lot["id"] for lot in valid_lots if lot["material"] in subs and lot["expiry"] >= task_end]

    def enumerate_allocations_for_component(needed, eligible_lot_ids, lot_remaining):
        if needed <= 0:
            yield []
            return
        if not eligible_lot_ids:
            return
        lid = eligible_lot_ids[0]
        rest = eligible_lot_ids[1:]
        avail = lot_remaining.get(lid, 0)
        max_take = min(needed, avail)
        for take in range(max_take + 1):
            if take == 0:
                yield from enumerate_allocations_for_component(needed, rest, lot_remaining)
            else:
                lot_remaining[lid] -= take
                for sub in enumerate_allocations_for_component(needed - take, rest, lot_remaining):
                    yield [(lid, take)] + sub
                lot_remaining[lid] += take

    def try_all_allocations(assignments):
        sorted_asgn = sorted(assignments, key=lambda a: (order_map[a[0]]["priority"], order_map[a[0]]["due"], a[0]))
        best_full_alloc = None
        _search_alloc(sorted_asgn, 0, {lot["id"]: lot["qty"] for lot in valid_lots}, {}, best_full_alloc_holder := [None])
        return best_full_alloc_holder[0]

    def _search_alloc(sorted_asgn, idx, lot_remaining, partial_allocs, holder):
        if idx == len(sorted_asgn):
            candidate = dict(partial_allocs)
            if holder[0] is None or alloc_tuple(candidate, sorted_asgn) < alloc_tuple(holder[0], sorted_asgn):
                holder[0] = candidate
            return
        oid, line_id, start, end = sorted_asgn[idx]
        demand = demands[oid]
        comps = sorted(demand.keys())
        _search_comp(comps, 0, {}, lot_remaining, oid, end, sorted_asgn, idx, partial_allocs, holder)

    def _search_comp(comps, ci, comp_partial, lot_remaining, oid, end, sorted_asgn, idx, partial_allocs, holder):
        if ci == len(comps):
            full_alloc = []
            for c in comps:
                for lid, qty in comp_partial[c]:
                    full_alloc.append((c, lid, qty))
            partial_allocs[oid] = full_alloc
            _search_alloc(sorted_asgn, idx + 1, lot_remaining, partial_allocs, holder)
            del partial_allocs[oid]
            return
        comp = comps[ci]
        needed = demands[oid][comp]
        eligible = get_eligible_lot_ids(comp, end)
        for alloc_pieces in enumerate_allocations_for_component(needed, eligible, lot_remaining):
            comp_partial[comp] = alloc_pieces
            _search_comp(comps, ci + 1, comp_partial, lot_remaining, oid, end, sorted_asgn, idx, partial_allocs, holder)
            del comp_partial[comp]

    def alloc_tuple(allocs_dict, sorted_asgn):
        result = []
        for oid, line_id, start, end in sorted_asgn:
            a = tuple(sorted(allocs_dict.get(oid, [])))
            result.append((oid, line_id, start, end, a))
        return tuple(result)

    priorities = sorted(set(o["priority"] for o in orders))
    order_ids = [o["id"] for o in orders]

    best_selected = []
    best_assignments = []
    best_allocs = {}

    all_orders_sorted = sorted(order_ids, key=lambda oid: (order_map[oid]["priority"], order_map[oid]["due"], oid))

    def is_better_candidate(sel, asgn, allocs, bsel, basgn, ballocs):
        if not bsel:
            return True
        for p in priorities:
            sp = sum(order_map[oid]["qty"] for oid in sel if order_map[oid]["priority"] == p)
            bp = sum(order_map[oid]["qty"] for oid in bsel if order_map[oid]["priority"] == p)
            if sp != bp:
                return sp > bp
        sel_set = set(sel)
        bsel_set = set(bsel)
        for oid in all_orders_sorted:
            sv = 1 if oid in sel_set else 0
            bv = 1 if oid in bsel_set else 0
            if sv != bv:
                return sv > bv
        s_at = alloc_tuple(allocs, sorted(asgn, key=lambda a: a[0]))
        b_at = alloc_tuple(ballocs, sorted(basgn, key=lambda a: a[0]))
        return s_at < b_at

    def solve():
        nonlocal best_selected, best_assignments, best_allocs
        for r in range(len(order_ids), -1, -1):
            found = False
            for combo in itertools.combinations(order_ids, r):
                feasible = find_feasible_schedules(list(combo))
                if not feasible:
                    continue
                for assignments in feasible:
                    holder = [None]
                    _search_alloc(
                        sorted(assignments, key=lambda a: (order_map[a[0]]["priority"], order_map[a[0]]["due"], a[0])),
                        0,
                        {lot["id"]: lot["qty"] for lot in valid_lots},
                        {},
                        holder
                    )
                    allocs = holder[0]
                    if allocs is None:
                        continue
                    if is_better_candidate(list(combo), assignments, allocs, best_selected, best_assignments, best_allocs):
                        best_selected = list(combo)
                        best_assignments = assignments
                        best_allocs = allocs
                        found = True
            if found:
                break

    def find_feasible_schedules(selected_ids):
        order_triples = {}
        for oid in selected_ids:
            triples = windows.get(oid, [])
            if not triples:
                return []
            order_triples[oid] = triples
        results = []
        _enumerate_schedules(selected_ids, order_triples, {}, results)
        return results

    def _enumerate_schedules(selected_ids, order_triples, current, results):
        if len(current) == len(selected_ids):
            results.append(list(current.values()))
            if len(results) > 500:
                return
            return
        remaining = [oid for oid in selected_ids if oid not in current]
        if not remaining:
            return
        oid = remaining[0]
        for triple in order_triples[oid]:
            line_id, start, end = triple
            if is_compatible(line_id, start, end, current):
                current[oid] = (oid, line_id, start, end)
                _enumerate_schedules(selected_ids, order_triples, current, results)
                del current[oid]
                if len(results) > 500:
                    return

    def is_compatible(line_id, start, end, current):
        line_tasks = [(s, e) for _, (_, lid, s, e) in current.items() if lid == line_id]
        for w in wip_by_line.get(line_id, []):
            line_tasks.append((w["start"], w["end"]))
        for s, e in line_tasks:
            if start < e and end > s:
                return False
        all_tasks = line_tasks + [(start, end)]
        all_tasks.sort()
        for i in range(1, len(all_tasks)):
            if all_tasks[i][0] < all_tasks[i - 1][1] + changeover:
                return False
        return True

    solve()

    selected_sorted = sorted(best_selected)
    erp_orders = []
    for w in wip_list:
        erp_orders.append({
            "wo": w["id"],
            "run": run_id,
            "sku": w["sku"],
            "qty": w["qty"],
            "due": w["due"],
            "start": w["start"],
            "end": w["end"],
            "line": w["line"],
            "status": "WIP_CONT",
            "parent": None
        })
    for oid, line_id, start, end in best_assignments:
        o = order_map[oid]
        erp_orders.append({
            "wo": oid,
            "run": run_id,
            "sku": o["sku"],
            "qty": o["qty"],
            "due": o["due"],
            "start": start,
            "end": end,
            "line": line_id,
            "status": "PLANNED",
            "parent": oid
        })
    erp_orders.sort(key=lambda x: x["wo"])

    mes_items = []
    for w in wip_list:
        mes_items.append({
            "run": run_id,
            "line": w["line"],
            "wo": w["id"],
            "qty": w["qty"],
            "start": w["start"],
            "end": w["end"],
            "status": "WIP_CONT"
        })
    for oid, line_id, start, end in best_assignments:
        o = order_map[oid]
        mes_items.append({
            "run": run_id,
            "line": line_id,
            "wo": oid,
            "qty": o["qty"],
            "start": start,
            "end": end,
            "status": "PLANNED"
        })
    mes_items.sort(key=lambda x: (x["line"], x["start"], x["wo"]))
    mes_result = []
    cur_line = None
    seq = 0
    for item in mes_items:
        if item["line"] != cur_line:
            cur_line = item["line"]
            seq = 0
        seq += 1
        mes_result.append({
            "run": item["run"],
            "line": item["line"],
            "seq": seq,
            "wo": item["wo"],
            "qty": item["qty"],
            "start": item["start"],
            "end": item["end"],
            "status": item["status"]
        })

    wms_items = []
    for oid in sorted(best_allocs.keys()):
        for comp, lot_id, qty in sorted(best_allocs[oid]):
            wms_items.append({
                "wo": oid,
                "component": comp,
                "lot": lot_id,
                "qty": qty
            })
    wms_items.sort(key=lambda x: (x["wo"], x["component"], x["lot"], x["qty"]))
    wms_result = []
    for idx, item in enumerate(wms_items, 1):
        wms_result.append({
            "reservation": f"r{idx:04d}",
            "run": run_id,
            "wo": item["wo"],
            "component": item["component"],
            "lot": item["lot"],
            "qty": item["qty"],
            "status": "RESERVED"
        })

    return {
        "selected": selected_sorted,
        "erp": {
            "run": {"id": run_id, "freeze": freeze},
            "orders": erp_orders
        },
        "mes": mes_result,
        "wms": wms_result
    }
