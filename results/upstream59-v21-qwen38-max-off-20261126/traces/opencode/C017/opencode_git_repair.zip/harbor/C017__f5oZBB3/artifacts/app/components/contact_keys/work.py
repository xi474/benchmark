import re

def compute(payload):
    result = []
    for batch in payload["batches"]:
        row = []
        for record in batch:
            row.append(record["email"].strip().lower())
        result.append(row)
    return result
