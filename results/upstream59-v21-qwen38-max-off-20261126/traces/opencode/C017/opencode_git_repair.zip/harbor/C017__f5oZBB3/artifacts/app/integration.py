def combine(payload, left, right):
    ledger = {}
    batch_results = []

    for bi in range(len(left)):
        emails = left[bi]
        profiles = right[bi]

        snapshot = {}
        for e in ledger:
            snapshot[e] = {
                "name": ledger[e]["name"],
                "city": ledger[e]["city"],
                "first_contact": ledger[e]["first_contact"],
                "sources": set(ledger[e]["sources"]),
            }

        temp_new = {}
        temp_items = []
        conflict = False

        for idx in range(len(emails)):
            email = emails[idx]
            prof = profiles[idx]
            name = prof["name"]
            city = prof["city"]
            source = prof["source"]
            time_val = prof["time"]

            ref = ledger.get(email)
            if ref is None:
                ref = temp_new.get(email)

            if ref is not None:
                ex_name = ref["name"]
                ex_city = ref["city"]
                complete = bool(ex_name and ex_city)

                if name and ex_name and name != ex_name:
                    conflict = True
                    break
                if city and ex_city and city != ex_city:
                    conflict = True
                    break

                if complete:
                    temp_items.append("duplicate")
                    ref["sources"].add(source)
                else:
                    new_name = name if name else ex_name
                    new_city = city if city else ex_city
                    now_complete = bool(new_name and new_city)
                    was_complete = bool(ex_name and ex_city)

                    if now_complete and not was_complete:
                        temp_items.append("promoted")
                    else:
                        temp_items.append("incomplete")

                    ref["name"] = new_name
                    ref["city"] = new_city
                    ref["sources"].add(source)
            else:
                has_name = bool(name)
                has_city = bool(city)
                if has_name and has_city:
                    temp_items.append("accepted")
                else:
                    temp_items.append("incomplete")
                rec = {
                    "email": email,
                    "name": name,
                    "city": city,
                    "first_contact": time_val,
                    "sources": {source},
                }
                temp_new[email] = rec

        if conflict:
            batch_results.append({"status": "rejected", "items": []})
        else:
            for e in temp_new:
                ledger[e] = temp_new[e]
            batch_results.append({"status": "committed", "items": temp_items})

    accepted = []
    incomplete = []
    for email in sorted(ledger.keys()):
        rec = ledger[email]
        entry = {
            "email": rec["email"],
            "name": rec["name"],
            "city": rec["city"],
            "first_contact": rec["first_contact"],
            "sources": sorted(rec["sources"]),
        }
        if rec["name"] and rec["city"]:
            accepted.append(entry)
        else:
            incomplete.append(entry)

    sources_map = {}
    for email in sorted(ledger.keys()):
        for src in ledger[email]["sources"]:
            if src not in sources_map:
                sources_map[src] = []
            sources_map[src].append(email)
    for src in sources_map:
        sources_map[src] = sorted(set(sources_map[src]))
    sources_map = dict(sorted(sources_map.items()))

    return {
        "batches": batch_results,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_map,
    }
