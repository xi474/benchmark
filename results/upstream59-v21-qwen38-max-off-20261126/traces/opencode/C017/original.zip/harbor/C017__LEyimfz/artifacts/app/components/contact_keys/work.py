import re


def compute(payload):
    result = []
    for batch in payload["batches"]:
        keys = []
        for record in batch:
            email = record["email"].strip().lower()
            keys.append(email)
        result.append(keys)
    return result
