import re


def _fold(s):
    return re.sub(r'\s+', ' ', s).strip() if s else ""


def compute(payload):
    result = []
    for batch in payload["batches"]:
        profiles = []
        for record in batch:
            profiles.append({
                "name": _fold(record.get("name", "")),
                "city": _fold(record.get("city", "")),
                "source": record["source"],
                "time": record["time"],
            })
        result.append(profiles)
    return result
