import copy


def combine(payload, left, right):
    ledger = {}
    batch_results = []

    for batch_idx in range(len(left)):
        keys = left[batch_idx]
        profiles = right[batch_idx]
        temp_records = []
        conflict = False

        for i, email in enumerate(keys):
            prof = profiles[i]
            name = prof["name"]
            city = prof["city"]
            source = prof["source"]
            time_val = prof["time"]

            if email in ledger:
                existing = ledger[email]
                if existing["complete"]:
                    if (name and existing["name"] and name != existing["name"]) or \
                       (city and existing["city"] and city != existing["city"]):
                        conflict = True
                        break
                    temp_records.append({
                        "email": email,
                        "name": name,
                        "city": city,
                        "source": source,
                        "time": time_val,
                        "status": "duplicate",
                    })
                else:
                    if (name and existing["name"] and name != existing["name"]) or \
                       (city and existing["city"] and city != existing["city"]):
                        conflict = True
                        break
                    merged_name = existing["name"] if existing["name"] else name
                    merged_city = existing["city"] if existing["city"] else city
                    now_complete = bool(merged_name and merged_city)
                    if now_complete and not existing["complete"]:
                        status = "promoted"
                    elif existing["complete"]:
                        status = "duplicate"
                    else:
                        status = "incomplete"
                    temp_records.append({
                        "email": email,
                        "name": merged_name,
                        "city": merged_city,
                        "source": source,
                        "time": time_val,
                        "first_contact": existing["first_contact"],
                        "status": status,
                        "was_complete_before": existing["complete"],
                    })
            else:
                is_complete = bool(name and city)
                temp_records.append({
                    "email": email,
                    "name": name,
                    "city": city,
                    "source": source,
                    "time": time_val,
                    "first_contact": time_val,
                    "status": "accepted" if is_complete else "incomplete",
                    "is_new": True,
                })

        if conflict:
            batch_results.append({"status": "rejected", "items": []})
            continue

        items = []
        for rec in temp_records:
            email = rec["email"]
            if rec.get("is_new"):
                is_complete = bool(rec["name"] and rec["city"])
                ledger[email] = {
                    "name": rec["name"],
                    "city": rec["city"],
                    "first_contact": rec["first_contact"],
                    "sources": {rec["source"]},
                    "complete": is_complete,
                }
            elif rec["status"] == "duplicate":
                ledger[email]["sources"].add(rec["source"])
            else:
                existing = ledger[email]
                existing["sources"].add(rec["source"])
                if rec["name"] and not existing["name"]:
                    existing["name"] = rec["name"]
                if rec["city"] and not existing["city"]:
                    existing["city"] = rec["city"]
                was_incomplete = not existing["complete"]
                now_complete = bool(existing["name"] and existing["city"])
                if now_complete:
                    existing["complete"] = True
            items.append(rec["status"])

        batch_results.append({"status": "committed", "items": items})

    accepted = []
    incomplete = []
    for email in sorted(ledger.keys()):
        entry = ledger[email]
        row = {
            "email": email,
            "name": entry["name"],
            "city": entry["city"],
            "first_contact": entry["first_contact"],
            "sources": sorted(entry["sources"]),
        }
        if entry["complete"]:
            accepted.append(row)
        else:
            incomplete.append(row)

    sources_map = {}
    for email in sorted(ledger.keys()):
        for src in ledger[email]["sources"]:
            if src not in sources_map:
                sources_map[src] = []
            if email not in sources_map[src]:
                sources_map[src].append(email)
    for src in sources_map:
        sources_map[src] = sorted(sources_map[src])
    sources_map = dict(sorted(sources_map.items()))

    return {
        "batches": batch_results,
        "accepted": accepted,
        "incomplete": incomplete,
        "sources": sources_map,
    }
