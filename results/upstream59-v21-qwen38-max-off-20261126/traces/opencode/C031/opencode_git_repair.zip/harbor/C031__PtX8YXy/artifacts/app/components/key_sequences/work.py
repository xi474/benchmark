KEY_MAP = {
    "Enter": b"\r",
    "C-c": b"\x03",
    "C-d": b"\x04",
    "C-u": b"\x15",
    "Tab": b"\t",
    "Backspace": b"\x7f",
}


def compute(payload):
    result = []
    for step in payload["steps"]:
        buf = bytearray()
        for key in step["keys"]:
            if key in KEY_MAP:
                buf.extend(KEY_MAP[key])
            else:
                buf.extend(key.encode("utf-8"))
        result.append(buf.hex())
    return result
