def compute(payload):
    startup = payload.get("startup", "") or ""
    timeout = payload.get("timeout_seconds", 4)
    if timeout is None:
        timeout = 4

    rc_lines = [
        "PS1='PROMPT> '",
        "PS2='CONT> '",
        "HISTFILE=/dev/null",
        "",
    ]
    if startup:
        rc_lines.append(startup)
    rc = "\n".join(rc_lines) + "\n"

    markers = [step.get("until") for step in payload["steps"]]

    return {
        "rc": rc,
        "timeout": timeout,
        "markers": markers,
    }
