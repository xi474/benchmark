import os
import pty
import signal
import struct
import tempfile
import time


def _normalize(text):
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "\n")
    return text


def combine(payload, key_hex_list, session_cfg):
    rc_content = session_cfg["rc"]
    timeout = session_cfg["timeout"]
    markers = session_cfg["markers"]

    tmpdir = tempfile.mkdtemp()
    rc_path = os.path.join(tmpdir, ".bashrc_custom")
    with open(rc_path, "w") as f:
        f.write(rc_content)

    hushlogin = os.path.join(tmpdir, ".hushlogin")
    with open(hushlogin, "w") as f:
        pass

    master_fd, slave_fd = pty.openpty()

    pid = os.fork()
    if pid == 0:
        os.close(master_fd)
        os.setsid()
        import fcntl
        import termios
        fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)
        os.dup2(slave_fd, 0)
        os.dup2(slave_fd, 1)
        os.dup2(slave_fd, 2)
        os.close(slave_fd)

        env = os.environ.copy()
        env["HOME"] = tmpdir
        env["TERM"] = "dumb"
        env["LC_ALL"] = "C"
        env["HISTFILE"] = "/dev/null"

        os.execvpe(
            "/bin/bash",
            ["/bin/bash", "--noprofile", "--rcfile", rc_path, "-i"],
            env,
        )

    os.close(slave_fd)

    chunks = []
    closed = False

    def read_until(marker, deadline):
        buf = b""
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                rlist, _, _ = __import__("select").select([master_fd], [], [], min(remaining, 0.1))
            except (OSError, ValueError):
                break
            if not rlist:
                continue
            try:
                data = os.read(master_fd, 65536)
            except OSError:
                closed_flag = True
                return buf, True
            if not data:
                return buf, True
            buf += data
            if marker is not None and marker.encode("utf-8") in buf:
                return buf, False
        return buf, False

    try:
        deadline = time.monotonic() + timeout
        initial_data, eof = read_until("PROMPT> ", deadline)
        chunks.append(_normalize(initial_data.decode("utf-8", errors="replace")))
        if eof:
            closed = True

        for i, hex_str in enumerate(key_hex_list):
            if closed:
                chunks.append("")
                continue
            raw = bytes.fromhex(hex_str)
            try:
                os.write(master_fd, raw)
            except OSError:
                closed = True
                chunks.append("")
                continue

            marker = markers[i]
            deadline = time.monotonic() + timeout
            step_data, eof = read_until(marker, deadline)
            chunks.append(_normalize(step_data.decode("utf-8", errors="replace")))
            if eof:
                closed = True
    finally:
        try:
            os.killpg(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        try:
            os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            pass
        try:
            os.close(master_fd)
        except OSError:
            pass
        import shutil
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass

    return {"chunks": chunks, "closed": closed}
