KEY_MAP = {
    "Enter": b"\x0d",
    "C-c": b"\x03",
    "C-d": b"\x04",
    "C-u": b"\x15",
    "Tab": b"\x09",
    "Backspace": b"\x7f",
}


def compute(payload):
    result = []
    for step in payload["steps"]:
        buf = b""
        for k in step["keys"]:
            if k in KEY_MAP:
                buf += KEY_MAP[k]
            else:
                buf += k.encode("utf-8")
        result.append(buf.hex())
    return result
