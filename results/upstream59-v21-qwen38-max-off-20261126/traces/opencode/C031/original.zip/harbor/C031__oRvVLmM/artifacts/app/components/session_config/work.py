def compute(payload):
    startup = payload.get("startup", "")
    timeout = payload.get("timeout_seconds", 4)
    if timeout is None:
        timeout = 4
    markers = [step["until"] for step in payload["steps"]]
    rc = "PS1='PROMPT> '\nPS2='CONT> '\nHISTFILE=/dev/null\n" + startup + "\n"
    return {"rc": rc, "timeout": timeout, "markers": markers}
