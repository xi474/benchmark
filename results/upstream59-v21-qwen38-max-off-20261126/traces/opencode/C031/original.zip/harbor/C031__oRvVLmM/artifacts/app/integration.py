import os
import pty
import select
import signal
import tempfile
import time


def combine(payload, left, right):
    hex_list = left
    cfg = right
    rc_content = cfg["rc"]
    timeout = cfg["timeout"]
    markers = cfg["markers"]

    tmpdir = tempfile.mkdtemp()
    hushlogin = os.path.join(tmpdir, ".hushlogin")
    with open(hushlogin, "w") as f:
        pass

    rc_file = os.path.join(tmpdir, ".bashrc_custom")
    with open(rc_file, "w") as f:
        f.write(rc_content)

    env = os.environ.copy()
    env["HOME"] = tmpdir
    env["TERM"] = "dumb"
    env["LC_ALL"] = "C"
    env["HISTFILE"] = "/dev/null"

    master_fd, slave_fd = pty.openpty()

    pid = os.fork()
    if pid == 0:
        os.close(master_fd)
        os.setsid()
        import fcntl
        import termios
        fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)
        os.dup2(slave_fd, 0)
        os.dup2(slave_fd, 1)
        os.dup2(slave_fd, 2)
        os.close(slave_fd)
        os.execvpe("/bin/bash", ["/bin/bash", "--noprofile", "--rcfile", rc_file, "-i"], env)

    os.close(slave_fd)

    chunks = []
    closed = False

    def read_until(marker_bytes, tmo):
        buf = b""
        deadline = time.monotonic() + tmo
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                rlist, _, _ = select.select([master_fd], [], [], min(remaining, 0.1))
            except (OSError, ValueError):
                break
            if rlist:
                try:
                    data = os.read(master_fd, 65536)
                except OSError:
                    return buf, True
                if not data:
                    return buf, True
                buf += data
                if marker_bytes is not None and marker_bytes in buf:
                    return buf, False
        return buf, False

    initial_data, eof = read_until(b"PROMPT> ", timeout)
    if eof:
        closed = True
    text = initial_data.decode("utf-8", errors="replace")
    text = text.replace("\r\n", "\n").replace("\r", "")
    chunks.append(text)

    for i, hex_str in enumerate(hex_list):
        raw = bytes.fromhex(hex_str)
        marker = markers[i]
        if not closed:
            try:
                os.write(master_fd, raw)
            except OSError:
                closed = True
        if not closed:
            step_data, eof = read_until(marker.encode("utf-8") if marker is not None else None, timeout)
            if eof:
                closed = True
            text = step_data.decode("utf-8", errors="replace")
            text = text.replace("\r\n", "\n").replace("\r", "")
            chunks.append(text)
        else:
            chunks.append("")

    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except (OSError, ProcessLookupError):
        pass
    try:
        os.waitpid(pid, os.WNOHANG)
    except ChildProcessError:
        pass
    try:
        os.close(master_fd)
    except OSError:
        pass

    import shutil
    try:
        shutil.rmtree(tmpdir)
    except OSError:
        pass

    return {"chunks": chunks, "closed": closed}
