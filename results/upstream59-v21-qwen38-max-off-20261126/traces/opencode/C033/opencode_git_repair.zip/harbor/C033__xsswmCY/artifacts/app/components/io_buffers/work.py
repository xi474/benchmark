def compute(payload):
    files = {}
    for name, hex_str in payload.get("files", {}).items():
        files[name] = list(bytes.fromhex(hex_str))
    stdin_hex = payload.get("stdin_hex", "")
    stdin_bytes = list(bytes.fromhex(stdin_hex)) if stdin_hex else []
    return [files, stdin_bytes]
