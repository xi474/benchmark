def combine(payload, left, right):
    entry_addr, mem_pairs = left
    files_map, stdin_bytes = right

    memory = {}
    for addr, byte_val in mem_pairs:
        memory[addr] = byte_val & 0xFF

    regs = [0] * 32
    regs[29] = payload.get("stack_pointer", 0x7FFF0000)
    state = {"hi": 0, "lo": 0}

    file_contents = {}
    for name, byte_arr in files_map.items():
        file_contents[name] = bytearray(byte_arr)

    fds = {0: {"type": "stdin", "data": bytearray(stdin_bytes), "pos": 0},
           1: {"type": "stdout", "data": bytearray()},
           2: {"type": "stderr", "data": bytearray()}}
    next_fd = [3]

    max_steps = payload.get("max_steps", 20000)
    inspect_list = payload.get("inspect", [])
    syscall_log = []

    def signext16(v):
        v &= 0xFFFF
        return (v | 0xFFFF0000) if v & 0x8000 else v

    def signext8(v):
        v &= 0xFF
        return (v | 0xFFFFFF00) if v & 0x80 else v

    def s32(v):
        v &= 0xFFFFFFFF
        return v - 0x100000000 if v >= 0x80000000 else v

    def rmb(addr):
        return memory.get(addr & 0xFFFFFFFF, 0)

    def rmh(addr):
        a = addr & 0xFFFFFFFF
        return (memory.get(a + 1, 0) << 8) | memory.get(a, 0)

    def rmw(addr):
        a = addr & 0xFFFFFFFF
        return (memory.get(a + 3, 0) << 24) | (memory.get(a + 2, 0) << 16) | (memory.get(a + 1, 0) << 8) | memory.get(a, 0)

    def wmb(addr, val):
        memory[addr & 0xFFFFFFFF] = val & 0xFF

    def wmh(addr, val):
        a = addr & 0xFFFFFFFF
        v = val & 0xFFFF
        memory[a] = v & 0xFF
        memory[a + 1] = (v >> 8) & 0xFF

    def wmw(addr, val):
        a = addr & 0xFFFFFFFF
        v = val & 0xFFFFFFFF
        memory[a] = v & 0xFF
        memory[a + 1] = (v >> 8) & 0xFF
        memory[a + 2] = (v >> 16) & 0xFF
        memory[a + 3] = (v >> 24) & 0xFF

    def do_syscall():
        nonlocal next_fd
        sn = regs[2]
        a0, a1, a2 = regs[4], regs[5], regs[6]
        syscall_log.append({"number": sn, "args": [a0, a1, a2]})
        if sn == 4001:
            return True, a0 & 0xFF
        elif sn == 4003:
            result = 0
            if a0 in fds:
                fobj = fds[a0]
                if fobj["type"] == "stdin":
                    avail = len(fobj["data"]) - fobj["pos"]
                    n = min(a2, avail)
                    for i in range(n):
                        wmb(a1 + i, fobj["data"][fobj["pos"] + i])
                    fobj["pos"] += n
                    result = n
                elif fobj["type"] in ("file_r", "file_rw", "file_append"):
                    data = file_contents[fobj["name"]]
                    avail = len(data) - fobj["pos"]
                    n = min(a2, avail)
                    for i in range(n):
                        wmb(a1 + i, data[fobj["pos"] + i])
                    fobj["pos"] += n
                    result = n
            regs[2] = result & 0xFFFFFFFF
            regs[7] = 0
        elif sn == 4004:
            result = 0
            if a0 in fds:
                fobj = fds[a0]
                for i in range(a2):
                    fobj["data"].append(rmb(a1 + i))
                result = a2
            regs[2] = result & 0xFFFFFFFF
            regs[7] = 0
        elif sn == 4005:
            nb = []
            p = a0
            while True:
                b = rmb(p)
                if b == 0:
                    break
                nb.append(b)
                p += 1
            fname = bytes(nb).decode("utf-8")
            fd = next_fd[0]
            next_fd[0] += 1
            if a1 == 0:
                if fname not in file_contents:
                    file_contents[fname] = bytearray()
                fds[fd] = {"type": "file_r", "name": fname, "pos": 0}
            elif a1 == 1:
                file_contents[fname] = bytearray()
                fds[fd] = {"type": "file_rw", "name": fname, "pos": 0}
            elif a1 == 9:
                if fname not in file_contents:
                    file_contents[fname] = bytearray()
                fds[fd] = {"type": "file_append", "name": fname, "pos": len(file_contents[fname])}
            regs[2] = fd & 0xFFFFFFFF
            regs[7] = 0
        elif sn == 4006:
            if a0 in fds and a0 >= 3:
                del fds[a0]
            regs[2] = 0
            regs[7] = 0
        return False, 0

    def exec_insn(insn):
        opcode = (insn >> 26) & 0x3F
        rs_i = (insn >> 21) & 0x1F
        rt_i = (insn >> 16) & 0x1F
        rd_i = (insn >> 11) & 0x1F
        shamt_i = (insn >> 6) & 0x1F
        funct_i = insn & 0x3F
        imm_i = insn & 0xFFFF

        if opcode == 0:
            if funct_i == 0:
                if rd_i != 0:
                    regs[rd_i] = (regs[rt_i] << shamt_i) & 0xFFFFFFFF
            elif funct_i == 2:
                if rd_i != 0:
                    regs[rd_i] = (regs[rt_i] >> shamt_i) & 0xFFFFFFFF
            elif funct_i == 3:
                v = s32(regs[rt_i])
                if shamt_i > 0:
                    v = v >> shamt_i
                if rd_i != 0:
                    regs[rd_i] = v & 0xFFFFFFFF
            elif funct_i == 8:
                return "branch", regs[rs_i] & 0xFFFFFFFF, 0, 0
            elif funct_i == 9:
                return "branch_link", regs[rs_i] & 0xFFFFFFFF, 31, 0
            elif funct_i == 12:
                return "syscall", 0, 0, 0
            elif funct_i == 16:
                if rd_i != 0:
                    regs[rd_i] = state["hi"]
            elif funct_i == 17:
                state["hi"] = regs[rs_i] & 0xFFFFFFFF
            elif funct_i == 18:
                if rd_i != 0:
                    regs[rd_i] = state["lo"]
            elif funct_i == 19:
                state["lo"] = regs[rs_i] & 0xFFFFFFFF
            elif funct_i == 24:
                p = s32(regs[rs_i]) * s32(regs[rt_i])
                p &= 0xFFFFFFFFFFFFFFFF
                state["hi"] = (p >> 32) & 0xFFFFFFFF
                state["lo"] = p & 0xFFFFFFFF
            elif funct_i == 25:
                p = (regs[rs_i] & 0xFFFFFFFF) * (regs[rt_i] & 0xFFFFFFFF)
                p &= 0xFFFFFFFFFFFFFFFF
                state["hi"] = (p >> 32) & 0xFFFFFFFF
                state["lo"] = p & 0xFFFFFFFF
            elif funct_i == 26:
                sa = s32(regs[rs_i])
                sb = s32(regs[rt_i])
                if sb != 0:
                    q = int(sa / sb) if (sa < 0) != (sb < 0) and sa % sb != 0 else sa // sb
                    r = sa - q * sb
                    state["lo"] = q & 0xFFFFFFFF
                    state["hi"] = r & 0xFFFFFFFF
            elif funct_i == 27:
                ua = regs[rs_i] & 0xFFFFFFFF
                ub = regs[rt_i] & 0xFFFFFFFF
                if ub != 0:
                    state["lo"] = (ua // ub) & 0xFFFFFFFF
                    state["hi"] = (ua % ub) & 0xFFFFFFFF
            elif funct_i == 32:
                if rd_i != 0:
                    regs[rd_i] = (s32(regs[rs_i]) + s32(regs[rt_i])) & 0xFFFFFFFF
            elif funct_i == 33:
                if rd_i != 0:
                    regs[rd_i] = ((regs[rs_i] & 0xFFFFFFFF) + (regs[rt_i] & 0xFFFFFFFF)) & 0xFFFFFFFF
            elif funct_i == 34:
                if rd_i != 0:
                    regs[rd_i] = (s32(regs[rs_i]) - s32(regs[rt_i])) & 0xFFFFFFFF
            elif funct_i == 35:
                if rd_i != 0:
                    regs[rd_i] = ((regs[rs_i] & 0xFFFFFFFF) - (regs[rt_i] & 0xFFFFFFFF)) & 0xFFFFFFFF
            elif funct_i == 36:
                if rd_i != 0:
                    regs[rd_i] = regs[rs_i] & regs[rt_i]
            elif funct_i == 37:
                if rd_i != 0:
                    regs[rd_i] = (regs[rs_i] | regs[rt_i]) & 0xFFFFFFFF
            elif funct_i == 38:
                if rd_i != 0:
                    regs[rd_i] = (regs[rs_i] ^ regs[rt_i]) & 0xFFFFFFFF
            elif funct_i == 39:
                if rd_i != 0:
                    regs[rd_i] = (~(regs[rs_i] | regs[rt_i])) & 0xFFFFFFFF
            elif funct_i == 42:
                if rd_i != 0:
                    regs[rd_i] = 1 if s32(regs[rs_i]) < s32(regs[rt_i]) else 0
            elif funct_i == 43:
                if rd_i != 0:
                    regs[rd_i] = 1 if (regs[rs_i] & 0xFFFFFFFF) < (regs[rt_i] & 0xFFFFFFFF) else 0
        elif opcode == 2:
            target26 = insn & 0x3FFFFFF
            return "branch", None, 0, 0
        elif opcode == 3:
            target26 = insn & 0x3FFFFFF
            return "branch_link", None, 31, 0
        elif opcode == 4:
            if regs[rs_i] == regs[rt_i]:
                offset = signext16(imm_i) << 2
                return "branch_rel", offset, 0, 0
        elif opcode == 5:
            if regs[rs_i] != regs[rt_i]:
                offset = signext16(imm_i) << 2
                return "branch_rel", offset, 0, 0
        elif opcode == 6:
            if s32(regs[rs_i]) <= 0:
                offset = signext16(imm_i) << 2
                return "branch_rel", offset, 0, 0
        elif opcode == 7:
            if s32(regs[rs_i]) > 0:
                offset = signext16(imm_i) << 2
                return "branch_rel", offset, 0, 0
        elif opcode == 8 or opcode == 9:
            if rt_i != 0:
                regs[rt_i] = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
        elif opcode == 10:
            if rt_i != 0:
                regs[rt_i] = 1 if s32(regs[rs_i]) < signext16(imm_i) else 0
        elif opcode == 11:
            if rt_i != 0:
                regs[rt_i] = 1 if (regs[rs_i] & 0xFFFFFFFF) < (signext16(imm_i) & 0xFFFFFFFF) else 0
        elif opcode == 12:
            if rt_i != 0:
                regs[rt_i] = regs[rs_i] & imm_i
        elif opcode == 13:
            if rt_i != 0:
                regs[rt_i] = (regs[rs_i] | imm_i) & 0xFFFFFFFF
        elif opcode == 14:
            if rt_i != 0:
                regs[rt_i] = (regs[rs_i] ^ imm_i) & 0xFFFFFFFF
        elif opcode == 15:
            if rt_i != 0:
                regs[rt_i] = (imm_i << 16) & 0xFFFFFFFF
        elif opcode == 32:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            v = signext8(rmb(addr)) & 0xFFFFFFFF
            if rt_i != 0:
                regs[rt_i] = v
        elif opcode == 33:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            v = rmh(addr)
            if v & 0x8000:
                v |= 0xFFFF0000
            v &= 0xFFFFFFFF
            if rt_i != 0:
                regs[rt_i] = v
        elif opcode == 35:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            if rt_i != 0:
                regs[rt_i] = rmw(addr)
        elif opcode == 36:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            if rt_i != 0:
                regs[rt_i] = rmb(addr)
        elif opcode == 37:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            if rt_i != 0:
                regs[rt_i] = rmh(addr)
        elif opcode == 40:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            wmb(addr, regs[rt_i] & 0xFF)
        elif opcode == 41:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            wmh(addr, regs[rt_i] & 0xFFFF)
        elif opcode == 43:
            addr = (s32(regs[rs_i]) + signext16(imm_i)) & 0xFFFFFFFF
            wmw(addr, regs[rt_i])
        return None, 0, 0, 0

    pc = entry_addr & 0xFFFFFFFF
    steps = 0
    exited = False
    exit_code = 0

    while not exited and steps < max_steps:
        insn = rmw(pc)
        result = exec_insn(insn)
        kind, val, link_reg, _ = result

        regs[0] = 0
        steps += 1

        if kind == "syscall":
            did_exit, ec = do_syscall()
            if did_exit:
                exit_code = ec
                exited = True
                regs[0] = 0
                break
            pc = (pc + 4) & 0xFFFFFFFF
        elif kind in ("branch", "branch_link", "branch_rel"):
            if kind == "branch_rel":
                target_pc = (pc + 4 + val) & 0xFFFFFFFF
            elif kind == "branch" and val is None:
                target26 = insn & 0x3FFFFFF
                target_pc = ((pc + 4) & 0xF0000000) | (target26 << 2)
            elif kind == "branch_link" and val is None:
                target26 = insn & 0x3FFFFFF
                target_pc = ((pc + 4) & 0xF0000000) | (target26 << 2)
            else:
                target_pc = val & 0xFFFFFFFF

            delay_insn = rmw((pc + 4) & 0xFFFFFFFF)
            d_result = exec_insn(delay_insn)
            d_kind, d_val, d_link_reg, _ = d_result

            regs[0] = 0

            if d_kind == "syscall":
                did_exit, ec = do_syscall()
                if did_exit:
                    exit_code = ec
                    exited = True
                    regs[0] = 0
                    steps += 1
                    break

            if link_reg:
                regs[link_reg] = (pc + 8) & 0xFFFFFFFF

            steps += 1
            pc = target_pc & 0xFFFFFFFF
        else:
            pc = (pc + 4) & 0xFFFFFFFF

    regs[0] = 0

    stdout_hex = "".join(format(b, "02x") for b in fds[1]["data"])
    stderr_hex = "".join(format(b, "02x") for b in fds[2]["data"])

    out_files = {}
    for name, data in file_contents.items():
        out_files[name] = "".join(format(b, "02x") for b in data)

    inspect_result = []
    for item in inspect_list:
        addr = item["address"]
        length = item["length"]
        hex_str = ""
        for i in range(length):
            b = memory.get((addr + i) & 0xFFFFFFFF, 0)
            hex_str += format(b, "02x")
        inspect_result.append({"address": addr, "hex": hex_str})

    return {
        "exit_code": exit_code,
        "registers": list(regs),
        "hi": state["hi"],
        "lo": state["lo"],
        "steps": steps,
        "stdout_hex": stdout_hex,
        "stderr_hex": stderr_hex,
        "files": out_files,
        "inspect": inspect_result,
        "syscalls": syscall_log,
    }
