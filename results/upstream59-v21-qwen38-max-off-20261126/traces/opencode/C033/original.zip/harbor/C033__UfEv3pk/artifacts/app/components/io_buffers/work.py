def compute(payload):
    files = {}
    if "files" in payload and payload["files"]:
        for name, hex_str in payload["files"].items():
            files[name] = list(bytes.fromhex(hex_str))
    stdin = []
    if "stdin_hex" in payload and payload["stdin_hex"]:
        stdin = list(bytes.fromhex(payload["stdin_hex"]))
    return [files, stdin]
