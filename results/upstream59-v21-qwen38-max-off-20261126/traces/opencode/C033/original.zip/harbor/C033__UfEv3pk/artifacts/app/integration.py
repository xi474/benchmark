import struct


def combine(payload, left, right):
    entry_addr, mem_pairs = left
    file_map, stdin_bytes = right

    mem = {}
    for addr, val in mem_pairs:
        mem[addr] = val

    regs = [0] * 32
    sp_default = payload.get("stack_pointer", 0x7fff0000)
    regs[29] = sp_default
    hi = 0
    lo = 0

    files_content = {}
    for name, byte_list in file_map.items():
        files_content[name] = bytearray(byte_list)

    fd_table = {}
    fd_table[0] = {"data": bytearray(stdin_bytes), "offset": 0, "mode": "r"}
    fd_table[1] = {"data": bytearray(), "offset": 0, "mode": "w"}
    fd_table[2] = {"data": bytearray(), "offset": 0, "mode": "w"}
    next_fd = 3

    stdout_buf = bytearray()
    stderr_buf = bytearray()

    max_steps = payload.get("max_steps", 20000)
    inspect_list = payload.get("inspect", [])

    syscalls_log = []
    exit_code = 0
    steps = 0
    pc = entry_addr

    def read_mem8(addr):
        return mem.get(addr & 0xFFFFFFFF, 0)

    def write_mem8(addr, val):
        mem[addr & 0xFFFFFFFF] = val & 0xFF

    def read_mem16(addr):
        b0 = read_mem8(addr)
        b1 = read_mem8(addr + 1)
        return (b1 << 8) | b0

    def read_mem32(addr):
        b0 = read_mem8(addr)
        b1 = read_mem8(addr + 1)
        b2 = read_mem8(addr + 2)
        b3 = read_mem8(addr + 3)
        return (b3 << 24) | (b2 << 16) | (b1 << 8) | b0

    def write_mem32(addr, val):
        val = val & 0xFFFFFFFF
        write_mem8(addr, val & 0xFF)
        write_mem8(addr + 1, (val >> 8) & 0xFF)
        write_mem8(addr + 2, (val >> 16) & 0xFF)
        write_mem8(addr + 3, (val >> 24) & 0xFF)

    def sign_ext(val, bits):
        mask = 1 << (bits - 1)
        return (val & (mask - 1)) - (val & mask)

    def to_u32(v):
        return v & 0xFFFFFFFF

    def to_s32(v):
        v = v & 0xFFFFFFFF
        if v >= 0x80000000:
            return v - 0x100000000
        return v

    running = True
    while running and steps < max_steps:
        insn_word = read_mem32(pc)
        op = (insn_word >> 26) & 0x3F
        rs_idx = (insn_word >> 21) & 0x1F
        rt_idx = (insn_word >> 16) & 0x1F
        rd_idx = (insn_word >> 11) & 0x1F
        shamt = (insn_word >> 6) & 0x1F
        funct = insn_word & 0x3F
        imm16 = insn_word & 0xFFFF
        target26 = insn_word & 0x3FFFFFF

        steps += 1
        next_pc = pc + 4
        delayed_pc = None

        if op == 0:
            if funct == 0:
                regs[rd_idx] = to_u32((regs[rt_idx] << shamt))
            elif funct == 2:
                regs[rd_idx] = to_u32(regs[rt_idx] >> shamt)
            elif funct == 3:
                s = to_s32(regs[rt_idx])
                regs[rd_idx] = to_u32(s >> shamt)
            elif funct == 8:
                delayed_pc = regs[rs_idx] & 0xFFFFFFFF
            elif funct == 9:
                delayed_pc = regs[rs_idx] & 0xFFFFFFFF
                regs[rd_idx] = to_u32(pc + 8)
            elif funct == 32:
                regs[rd_idx] = to_u32(to_s32(regs[rs_idx]) + to_s32(regs[rt_idx]))
            elif funct == 33:
                regs[rd_idx] = to_u32(regs[rs_idx] + regs[rt_idx])
            elif funct == 34:
                regs[rd_idx] = to_u32(to_s32(regs[rs_idx]) - to_s32(regs[rt_idx]))
            elif funct == 35:
                regs[rd_idx] = to_u32(regs[rs_idx] - regs[rt_idx])
            elif funct == 36:
                regs[rd_idx] = regs[rs_idx] & regs[rt_idx]
            elif funct == 37:
                regs[rd_idx] = regs[rs_idx] | regs[rt_idx]
            elif funct == 38:
                regs[rd_idx] = regs[rs_idx] ^ regs[rt_idx]
            elif funct == 39:
                regs[rd_idx] = to_u32(~(regs[rs_idx] | regs[rt_idx]))
            elif funct == 42:
                regs[rd_idx] = 1 if to_s32(regs[rs_idx]) < to_s32(regs[rt_idx]) else 0
            elif funct == 43:
                regs[rd_idx] = 1 if regs[rs_idx] < regs[rt_idx] else 0
            elif funct == 16:
                regs[rd_idx] = hi
            elif funct == 17:
                regs[rd_idx] = lo
            elif funct == 18:
                hi = regs[rs_idx]
            elif funct == 19:
                lo = regs[rs_idx]
            elif funct == 24:
                result = to_s32(regs[rs_idx]) * to_s32(regs[rt_idx])
                result = result & 0xFFFFFFFFFFFFFFFF
                hi = to_u32(result >> 32)
                lo = to_u32(result & 0xFFFFFFFF)
            elif funct == 25:
                result = (regs[rs_idx] * regs[rt_idx]) & 0xFFFFFFFFFFFFFFFF
                hi = to_u32(result >> 32)
                lo = to_u32(result & 0xFFFFFFFF)
            elif funct == 26:
                s_rs = to_s32(regs[rs_idx])
                s_rt = to_s32(regs[rt_idx])
                if s_rt != 0:
                    q = int(s_rs / s_rt) if (s_rs < 0) != (s_rt < 0) and s_rs % s_rt != 0 else s_rs // s_rt
                    r = s_rs - q * s_rt
                    lo = to_u32(q)
                    hi = to_u32(r)
            elif funct == 27:
                u_rs = regs[rs_idx]
                u_rt = regs[rt_idx]
                if u_rt != 0:
                    lo = to_u32(u_rs // u_rt)
                    hi = to_u32(u_rs % u_rt)
            elif funct == 12:
                syscall_num = regs[2]
                a0 = regs[4]
                a1 = regs[5]
                a2 = regs[6]
                syscalls_log.append({"number": syscall_num, "args": [a0, a1, a2]})
                if syscall_num == 4001:
                    exit_code = a0 & 0xFF
                    running = False
                    regs[0] = 0
                    continue
                elif syscall_num == 4003:
                    fd = a0
                    buf_addr = a1
                    count = a2
                    info = fd_table.get(fd)
                    if info is None:
                        regs[2] = to_u32(-1)
                        regs[7] = to_u32(1)
                    else:
                        data = info["data"]
                        off = info["offset"]
                        avail = len(data) - off
                        n = min(count, avail) if avail > 0 else 0
                        for i in range(n):
                            write_mem8(buf_addr + i, data[off + i])
                        info["offset"] = off + n
                        regs[2] = to_u32(n)
                        regs[7] = 0
                elif syscall_num == 4004:
                    fd = a0
                    buf_addr = a1
                    count = a2
                    written = bytearray()
                    for i in range(count):
                        written.append(read_mem8(buf_addr + i))
                    if fd == 1:
                        stdout_buf.extend(written)
                    elif fd == 2:
                        stderr_buf.extend(written)
                    elif fd in fd_table:
                        info = fd_table[fd]
                        d = info["data"]
                        off = info["offset"]
                        for i, b in enumerate(written):
                            pos = off + i
                            if pos < len(d):
                                d[pos] = b
                            else:
                                d.append(b)
                        info["offset"] = off + len(written)
                    regs[2] = to_u32(count)
                    regs[7] = 0
                elif syscall_num == 4005:
                    path_addr = a0
                    flags = a1
                    mode = a2
                    path_bytes = bytearray()
                    while True:
                        b = read_mem8(path_addr)
                        if b == 0:
                            break
                        path_bytes.append(b)
                        path_addr += 1
                    path_str = path_bytes.decode("utf-8")
                    new_fd = next_fd
                    next_fd += 1
                    if flags == 0:
                        content = bytearray(files_content.get(path_str, bytearray()))
                        fd_table[new_fd] = {"data": content, "offset": 0, "mode": "r"}
                    elif flags == 1:
                        fd_table[new_fd] = {"data": bytearray(), "offset": 0, "mode": "w"}
                        files_content[path_str] = fd_table[new_fd]["data"]
                    elif flags == 9:
                        existing = bytearray(files_content.get(path_str, bytearray()))
                        fd_table[new_fd] = {"data": existing, "offset": len(existing), "mode": "a"}
                        files_content[path_str] = fd_table[new_fd]["data"]
                    regs[2] = to_u32(new_fd)
                    regs[7] = 0
                elif syscall_num == 4006:
                    fd = a0
                    if fd in fd_table and fd >= 3:
                        del fd_table[fd]
                    regs[2] = 0
                    regs[7] = 0
                regs[0] = 0
        elif op == 2:
            delayed_pc = ((pc + 4) & 0xF0000000) | (target26 << 2)
        elif op == 3:
            regs[31] = to_u32(pc + 8)
            delayed_pc = ((pc + 4) & 0xF0000000) | (target26 << 2)
        elif op == 4:
            simm = sign_ext(imm16, 16)
            if regs[rs_idx] == regs[rt_idx]:
                delayed_pc = to_u32(pc + 4 + (simm << 2))
        elif op == 5:
            simm = sign_ext(imm16, 16)
            if regs[rs_idx] != regs[rt_idx]:
                delayed_pc = to_u32(pc + 4 + (simm << 2))
        elif op == 6:
            simm = sign_ext(imm16, 16)
            if to_s32(regs[rs_idx]) <= 0:
                delayed_pc = to_u32(pc + 4 + (simm << 2))
        elif op == 7:
            simm = sign_ext(imm16, 16)
            if to_s32(regs[rs_idx]) > 0:
                delayed_pc = to_u32(pc + 4 + (simm << 2))
        elif op == 8 or op == 9:
            simm = sign_ext(imm16, 16)
            regs[rt_idx] = to_u32(to_s32(regs[rs_idx]) + simm)
        elif op == 10:
            simm = sign_ext(imm16, 16)
            regs[rt_idx] = 1 if to_s32(regs[rs_idx]) < simm else 0
        elif op == 11:
            simm = sign_ext(imm16, 16)
            regs[rt_idx] = 1 if regs[rs_idx] < to_u32(simm) else 0
        elif op == 12:
            regs[rt_idx] = regs[rs_idx] & imm16
        elif op == 13:
            regs[rt_idx] = regs[rs_idx] | imm16
        elif op == 14:
            regs[rt_idx] = regs[rs_idx] ^ imm16
        elif op == 15:
            regs[rt_idx] = to_u32(imm16 << 16)
        elif op == 32:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            val = read_mem8(addr)
            if val & 0x80:
                val = val | 0xFFFFFF00
            regs[rt_idx] = to_u32(val)
        elif op == 33:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            val = read_mem16(addr)
            if val & 0x8000:
                val = val | 0xFFFF0000
            regs[rt_idx] = to_u32(val)
        elif op == 35:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            regs[rt_idx] = read_mem32(addr)
        elif op == 36:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            regs[rt_idx] = read_mem8(addr)
        elif op == 37:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            regs[rt_idx] = read_mem16(addr)
        elif op == 40:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            write_mem8(addr, regs[rt_idx] & 0xFF)
        elif op == 41:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            val = regs[rt_idx] & 0xFFFF
            write_mem8(addr, val & 0xFF)
            write_mem8(addr + 1, (val >> 8) & 0xFF)
        elif op == 43:
            simm = sign_ext(imm16, 16)
            addr = to_u32(to_s32(regs[rs_idx]) + simm)
            write_mem32(addr, regs[rt_idx])

        regs[0] = 0

        if delayed_pc is not None:
            delay_insn = read_mem32(next_pc)
            steps += 1
            dop = (delay_insn >> 26) & 0x3F
            drs = (delay_insn >> 21) & 0x1F
            drt = (delay_insn >> 16) & 0x1F
            drd = (delay_insn >> 11) & 0x1F
            dsh = (delay_insn >> 6) & 0x1F
            dfn = delay_insn & 0x3F
            dimm = delay_insn & 0xFFFF
            if dop == 0:
                if dfn == 0:
                    regs[drd] = to_u32(regs[drt] << dsh)
                elif dfn == 2:
                    regs[drd] = to_u32(regs[drt] >> dsh)
                elif dfn == 3:
                    regs[drd] = to_u32(to_s32(regs[drt]) >> dsh)
                elif dfn == 32:
                    regs[drd] = to_u32(to_s32(regs[drs]) + to_s32(regs[drt]))
                elif dfn == 33:
                    regs[drd] = to_u32(regs[drs] + regs[drt])
                elif dfn == 34:
                    regs[drd] = to_u32(to_s32(regs[drs]) - to_s32(regs[drt]))
                elif dfn == 35:
                    regs[drd] = to_u32(regs[drs] - regs[drt])
                elif dfn == 36:
                    regs[drd] = regs[drs] & regs[drt]
                elif dfn == 37:
                    regs[drd] = regs[drs] | regs[drt]
                elif dfn == 38:
                    regs[drd] = regs[drs] ^ regs[drt]
                elif dfn == 39:
                    regs[drd] = to_u32(~(regs[drs] | regs[drt]))
                elif dfn == 42:
                    regs[drd] = 1 if to_s32(regs[drs]) < to_s32(regs[drt]) else 0
                elif dfn == 43:
                    regs[drd] = 1 if regs[drs] < regs[drt] else 0
                elif dfn == 16:
                    regs[drd] = hi
                elif dfn == 17:
                    regs[drd] = lo
                elif dfn == 18:
                    hi = regs[drs]
                elif dfn == 19:
                    lo = regs[drs]
                elif dfn == 24:
                    r = to_s32(regs[drs]) * to_s32(regs[drt])
                    r = r & 0xFFFFFFFFFFFFFFFF
                    hi = to_u32(r >> 32)
                    lo = to_u32(r & 0xFFFFFFFF)
                elif dfn == 25:
                    r = (regs[drs] * regs[drt]) & 0xFFFFFFFFFFFFFFFF
                    hi = to_u32(r >> 32)
                    lo = to_u32(r & 0xFFFFFFFF)
                elif dfn == 26:
                    s_rs = to_s32(regs[drs])
                    s_rt = to_s32(regs[drt])
                    if s_rt != 0:
                        q = int(s_rs / s_rt) if (s_rs < 0) != (s_rt < 0) and s_rs % s_rt != 0 else s_rs // s_rt
                        rem = s_rs - q * s_rt
                        lo = to_u32(q)
                        hi = to_u32(rem)
                elif dfn == 27:
                    if regs[drt] != 0:
                        lo = to_u32(regs[drs] // regs[drt])
                        hi = to_u32(regs[drs] % regs[drt])
                elif dfn == 12:
                    sc_num = regs[2]
                    sc_a0 = regs[4]
                    sc_a1 = regs[5]
                    sc_a2 = regs[6]
                    syscalls_log.append({"number": sc_num, "args": [sc_a0, sc_a1, sc_a2]})
                    if sc_num == 4001:
                        exit_code = sc_a0 & 0xFF
                        running = False
                    elif sc_num == 4003:
                        fd = sc_a0
                        buf_addr = sc_a1
                        count = sc_a2
                        info = fd_table.get(fd)
                        if info is None:
                            regs[2] = to_u32(-1)
                            regs[7] = to_u32(1)
                        else:
                            data = info["data"]
                            off = info["offset"]
                            avail = len(data) - off
                            n = min(count, avail) if avail > 0 else 0
                            for i in range(n):
                                write_mem8(buf_addr + i, data[off + i])
                            info["offset"] = off + n
                            regs[2] = to_u32(n)
                            regs[7] = 0
                    elif sc_num == 4004:
                        fd = sc_a0
                        buf_addr = sc_a1
                        count = sc_a2
                        wb = bytearray()
                        for i in range(count):
                            wb.append(read_mem8(buf_addr + i))
                        if fd == 1:
                            stdout_buf.extend(wb)
                        elif fd == 2:
                            stderr_buf.extend(wb)
                        elif fd in fd_table:
                            info = fd_table[fd]
                            d = info["data"]
                            off = info["offset"]
                            for i, b in enumerate(wb):
                                pos = off + i
                                if pos < len(d):
                                    d[pos] = b
                                else:
                                    d.append(b)
                            info["offset"] = off + len(wb)
                        regs[2] = to_u32(count)
                        regs[7] = 0
                    elif sc_num == 4005:
                        pa = sc_a0
                        fl = sc_a1
                        md = sc_a2
                        pb = bytearray()
                        while True:
                            b = read_mem8(pa)
                            if b == 0:
                                break
                            pb.append(b)
                            pa += 1
                        ps = pb.decode("utf-8")
                        nf = next_fd
                        next_fd += 1
                        if fl == 0:
                            fd_table[nf] = {"data": bytearray(files_content.get(ps, bytearray())), "offset": 0, "mode": "r"}
                        elif fl == 1:
                            fd_table[nf] = {"data": bytearray(), "offset": 0, "mode": "w"}
                            files_content[ps] = fd_table[nf]["data"]
                        elif fl == 9:
                            ex = bytearray(files_content.get(ps, bytearray()))
                            fd_table[nf] = {"data": ex, "offset": len(ex), "mode": "a"}
                            files_content[ps] = fd_table[nf]["data"]
                        regs[2] = to_u32(nf)
                        regs[7] = 0
                    elif sc_num == 4006:
                        fd = sc_a0
                        if fd in fd_table and fd >= 3:
                            del fd_table[fd]
                        regs[2] = 0
                        regs[7] = 0
            elif dop == 8 or dop == 9:
                si = sign_ext(dimm, 16)
                regs[drt] = to_u32(to_s32(regs[drs]) + si)
            elif dop == 10:
                si = sign_ext(dimm, 16)
                regs[drt] = 1 if to_s32(regs[drs]) < si else 0
            elif dop == 11:
                si = sign_ext(dimm, 16)
                regs[drt] = 1 if regs[drs] < to_u32(si) else 0
            elif dop == 12:
                regs[drt] = regs[drs] & dimm
            elif dop == 13:
                regs[drt] = regs[drs] | dimm
            elif dop == 14:
                regs[drt] = regs[drs] ^ dimm
            elif dop == 15:
                regs[drt] = to_u32(dimm << 16)
            elif dop == 32:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                v = read_mem8(ad)
                if v & 0x80:
                    v |= 0xFFFFFF00
                regs[drt] = to_u32(v)
            elif dop == 33:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                v = read_mem16(ad)
                if v & 0x8000:
                    v |= 0xFFFF0000
                regs[drt] = to_u32(v)
            elif dop == 35:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                regs[drt] = read_mem32(ad)
            elif dop == 36:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                regs[drt] = read_mem8(ad)
            elif dop == 37:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                regs[drt] = read_mem16(ad)
            elif dop == 40:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                write_mem8(ad, regs[drt] & 0xFF)
            elif dop == 41:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                v = regs[drt] & 0xFFFF
                write_mem8(ad, v & 0xFF)
                write_mem8(ad + 1, (v >> 8) & 0xFF)
            elif dop == 43:
                si = sign_ext(dimm, 16)
                ad = to_u32(to_s32(regs[drs]) + si)
                write_mem32(ad, regs[drt])
            regs[0] = 0
            if not running:
                break
            pc = delayed_pc
        else:
            pc = next_pc

    out_files = {}
    for name, data in files_content.items():
        out_files[name] = bytes(data).hex()

    inspect_result = []
    for item in inspect_list:
        addr = item["address"]
        length = item["length"]
        hex_parts = []
        for i in range(length):
            hex_parts.append(f"{read_mem8(addr + i):02x}")
        inspect_result.append({"address": addr, "hex": "".join(hex_parts)})

    return {
        "exit_code": exit_code,
        "registers": list(regs),
        "hi": hi,
        "lo": lo,
        "steps": steps,
        "stdout_hex": bytes(stdout_buf).hex(),
        "stderr_hex": bytes(stderr_buf).hex(),
        "files": out_files,
        "inspect": inspect_result,
        "syscalls": syscalls_log,
    }
