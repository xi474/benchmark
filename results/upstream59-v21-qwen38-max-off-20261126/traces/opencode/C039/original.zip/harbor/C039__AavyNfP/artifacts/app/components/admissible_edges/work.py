def compute(payload):
    nodes = payload["nodes"]
    allowed = payload["allowed"]
    root = payload["root"]
    idx = {n: i for i, n in enumerate(nodes)}
    ri = idx[root]
    result = []
    for p, c in allowed:
        ci = idx[c]
        if ci != ri:
            result.append([idx[p], ci])
    return result
