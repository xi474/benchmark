def compute(payload):
    nodes = payload["nodes"]
    cov = payload["covariance"]
    allowed = payload["allowed"]
    root = payload["root"]
    max_parents = payload["max_parents"]
    n = len(nodes)
    idx = {nd: i for i, nd in enumerate(nodes)}
    ri = idx[root]
    parents_of = [[] for _ in range(n)]
    for p, c in allowed:
        pi, ci = idx[p], idx[c]
        if ci != ri:
            parents_of[ci].append(pi)
    result = []
    for node_i in range(n):
        table = {}
        candidates = [p for p in parents_of[node_i]]
        for sz in range(min(len(candidates), max_parents) + 1):
            from itertools import combinations
            for combo in combinations(sorted(candidates), sz):
                key = ",".join(str(x) for x in combo) if combo else ""
                if not combo:
                    table[key] = []
                else:
                    plist = list(combo)
                    k = len(plist)
                    cpp = [[cov[plist[a]][plist[b]] for b in range(k)] for a in range(k)]
                    cpy = [cov[plist[a]][node_i] for a in range(k)]
                    inv = _invert(cpp, k)
                    beta = [sum(inv[a][b] * cpy[b] for b in range(k)) for a in range(k)]
                    table[key] = beta
        result.append(table)
    return result


def _invert(m, n):
    aug = [row[:] + [1.0 if j == i else 0.0 for j in range(n)] for i, row in enumerate(m)]
    for col in range(n):
        pivot = col
        for row in range(col + 1, n):
            if abs(aug[row][col]) > abs(aug[pivot][col]):
                pivot = row
        aug[col], aug[pivot] = aug[pivot], aug[col]
        pv = aug[col][col]
        for j in range(2 * n):
            aug[col][j] /= pv
        for row in range(n):
            if row != col:
                f = aug[row][col]
                for j in range(2 * n):
                    aug[row][j] -= f * aug[col][j]
    return [aug[i][n:] for i in range(n)]
