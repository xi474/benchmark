import math
from itertools import combinations


def combine(payload, left, right):
    nodes = payload["nodes"]
    cov = payload["covariance"]
    mean = payload["mean"]
    sample_size = payload["sample_size"]
    edge_count = payload["edge_count"]
    max_parents = payload["max_parents"]
    intervention = payload["intervention"]
    n = len(nodes)
    idx = {nd: i for i, nd in enumerate(nodes)}

    admissible = left
    reg_tables = right

    def get_residual_var(child_i, parent_indices):
        if not parent_indices:
            return cov[child_i][child_i]
        key = ",".join(str(x) for x in sorted(parent_indices))
        plist = sorted(parent_indices)
        k = len(plist)
        cpp = [[cov[plist[a]][plist[b]] for b in range(k)] for a in range(k)]
        cpy = [cov[plist[a]][child_i] for a in range(k)]
        inv = _invert(cpp, k)
        beta = [sum(inv[a][b] * cpy[b] for b in range(k)) for a in range(k)]
        var_y = cov[child_i][child_i]
        explained = sum(beta[a] * sum(cov[plist[a]][plist[b]] * beta[b] for b in range(k)) for a in range(k))
        cross = 2.0 * sum(beta[a] * cpy[a] for a in range(k))
        return var_y - cross + explained

    def score_dag(edges_by_child):
        total = 0.0
        for ci in range(n):
            pset = edges_by_child.get(ci, [])
            rv = get_residual_var(ci, pset)
            total += sample_size * math.log(rv) + len(pset) * math.log(sample_size)
        return total

    def has_cycle(edges_list):
        adj = [[] for _ in range(n)]
        for p, c in edges_list:
            adj[p].append(c)
        visited = [0] * n
        def dfs(u):
            visited[u] = 1
            for v in adj[u]:
                if visited[v] == 1:
                    return True
                if visited[v] == 0 and dfs(v):
                    return True
            visited[u] = 2
            return False
        for i in range(n):
            if visited[i] == 0 and dfs(i):
                return True
        return False

    best_score = None
    best_edges = None
    best_rounded = None

    for combo in combinations(admissible, edge_count):
        edges_list = list(combo)
        in_degree = [0] * n
        edges_by_child = {}
        valid = True
        for p, c in edges_list:
            in_degree[c] += 1
            if in_degree[c] > max_parents:
                valid = False
                break
            edges_by_child.setdefault(c, []).append(p)
        if not valid:
            continue
        if has_cycle(edges_list):
            continue
        s = score_dag(edges_by_child)
        rs = round(s, 9)
        sorted_edges = sorted(edges_list, key=lambda e: (e[0], e[1]))
        if best_score is None or rs < best_rounded or (rs == best_rounded and sorted_edges < best_edges):
            best_score = s
            best_rounded = rs
            best_edges = sorted_edges

    if best_edges is None:
        return {"feasible": False}

    edges_by_child = {}
    for p, c in best_edges:
        edges_by_child.setdefault(c, []).append(p)

    coefficients = []
    for p, c in best_edges:
        pset = sorted(edges_by_child[c])
        key = ",".join(str(x) for x in pset)
        betas = reg_tables[c][key]
        pos = pset.index(p)
        coefficients.append([p, c, betas[pos]])

    interv_node = idx[intervention["node"]]
    interv_value = intervention["value"]

    intercepts = [0.0] * n
    for ci in range(n):
        pset = edges_by_child.get(ci, [])
        if pset:
            key = ",".join(str(x) for x in sorted(pset))
            betas = reg_tables[ci][key]
            sp = sorted(pset)
            pred = sum(betas[j] * mean[sp[j]] for j in range(len(sp)))
            intercepts[ci] = mean[ci] - pred

    post_mean = [0.0] * n
    topo = _topo_sort(best_edges, n)
    for ni in topo:
        if ni == interv_node:
            post_mean[ni] = interv_value
        else:
            pset = edges_by_child.get(ni, [])
            if not pset:
                post_mean[ni] = mean[ni]
            else:
                key = ",".join(str(x) for x in sorted(pset))
                betas = reg_tables[ni][key]
                sp = sorted(pset)
                val = intercepts[ni] + sum(betas[j] * post_mean[sp[j]] for j in range(len(sp)))
                post_mean[ni] = val

    out_edges = [[nodes[p], nodes[c]] for p, c in best_edges]
    out_coeff = [[nodes[p], nodes[c], round(slope, 6)] for p, c, slope in coefficients]
    intervened_edges = [[nodes[p], nodes[c]] for p, c in best_edges if c != interv_node]
    intervened_edges.sort(key=lambda e: (e[0], e[1]))
    out_mean = [round(post_mean[idx[nd]], 6) for nd in nodes]

    return {
        "feasible": True,
        "edges": out_edges,
        "score": round(best_score, 6),
        "coefficients": out_coeff,
        "intervened_edges": intervened_edges,
        "mean": out_mean,
    }


def _topo_sort(edges, n):
    adj = [[] for _ in range(n)]
    indeg = [0] * n
    for p, c in edges:
        adj[p].append(c)
        indeg[c] += 1
    queue = [i for i in range(n) if indeg[i] == 0]
    order = []
    while queue:
        queue.sort()
        u = queue.pop(0)
        order.append(u)
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                queue.append(v)
    return order


def _invert(m, n):
    aug = [row[:] + [1.0 if j == i else 0.0 for j in range(n)] for i, row in enumerate(m)]
    for col in range(n):
        pivot = col
        for row in range(col + 1, n):
            if abs(aug[row][col]) > abs(aug[pivot][col]):
                pivot = row
        aug[col], aug[pivot] = aug[pivot], aug[col]
        pv = aug[col][col]
        for j in range(2 * n):
            aug[col][j] /= pv
        for row in range(n):
            if row != col:
                f = aug[row][col]
                for j in range(2 * n):
                    aug[row][j] -= f * aug[col][j]
    return [aug[i][n:] for i in range(n)]
