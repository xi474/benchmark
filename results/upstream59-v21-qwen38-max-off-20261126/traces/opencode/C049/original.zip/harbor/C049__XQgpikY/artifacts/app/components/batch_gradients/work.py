import numpy as np


def compute(payload):
    layers = payload["layers"]
    microbatches = payload["microbatches"]
    L = len(layers)

    weights = [np.array(l["weight"], dtype=np.float64) for l in layers]
    biases = [np.array(l["bias"], dtype=np.float64) for l in layers]

    total_loss = 0.0
    grad_w = [np.zeros_like(w) for w in weights]
    grad_b = [np.zeros_like(b) for b in biases]

    num_mb = len(microbatches)

    for mb in microbatches:
        inputs = np.array(mb["inputs"], dtype=np.float64)
        targets = mb["targets"]
        B = inputs.shape[0]

        activations = [inputs]
        pre_activations = []

        h = inputs
        for i in range(L):
            z = h @ weights[i].T + biases[i]
            pre_activations.append(z)
            if i < L - 1:
                h = np.tanh(z)
            else:
                h = z
            activations.append(h)

        logits = activations[-1]
        max_logits = np.max(logits, axis=1, keepdims=True)
        shifted = logits - max_logits
        exp_shifted = np.exp(shifted)
        sum_exp = np.sum(exp_shifted, axis=1, keepdims=True)
        log_sum_exp = np.log(sum_exp) + max_logits
        probs = exp_shifted / sum_exp

        mb_loss = 0.0
        for b_idx in range(B):
            mb_loss += -logits[b_idx, targets[b_idx]] + log_sum_exp[b_idx, 0]
        mb_loss /= B
        total_loss += mb_loss

        d_logits = probs.copy()
        for b_idx in range(B):
            d_logits[b_idx, targets[b_idx]] -= 1.0
        d_logits /= B

        delta = d_logits
        for i in range(L - 1, -1, -1):
            grad_w[i] += delta.T @ activations[i]
            grad_b[i] += np.sum(delta, axis=0)

            if i > 0:
                delta = delta @ weights[i]
                tanh_out = activations[i]
                delta = delta * (1.0 - tanh_out ** 2)

    total_loss /= num_mb
    for i in range(L):
        grad_w[i] /= num_mb
        grad_b[i] /= num_mb

    gradients = []
    for i in range(L):
        gradients.append({
            "weight": grad_w[i].tolist(),
            "bias": grad_b[i].tolist()
        })

    return {
        "loss": float(total_loss),
        "gradients": gradients
    }
