import math


def compute(payload):
    layers = payload["layers"]
    world_size = payload["world_size"]
    microbatches = payload["microbatches"]
    L = len(layers)
    M = len(microbatches)

    partitions = []
    for r in range(world_size):
        start = math.floor(L * r / world_size)
        stop = math.floor(L * (r + 1) / world_size)
        partitions.append({"stage": r, "start": start, "stop": stop})

    num_stages = world_size
    events = []

    for m in range(M):
        for s in range(num_stages):
            events.append({"kind": "forward", "microbatch": m, "stage": s})
            if s < num_stages - 1:
                events.append({"kind": "send_activation", "source": s, "target": s + 1})

    for m in range(M - 1, -1, -1):
        for s in range(num_stages - 1, -1, -1):
            events.append({"kind": "backward", "microbatch": m, "stage": s})
            if s > 0:
                events.append({"kind": "send_gradient", "source": s, "target": s - 1})

    return {
        "partitions": partitions,
        "events": events
    }
