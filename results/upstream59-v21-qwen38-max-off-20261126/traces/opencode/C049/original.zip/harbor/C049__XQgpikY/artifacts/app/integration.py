def combine(payload, left, right):
    return {
        "loss": left["loss"],
        "gradients": left["gradients"],
        "partitions": right["partitions"],
        "events": right["events"]
    }
