import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from yaml_parser import resolve_source


def compute(payload):
    sources = payload['sources']
    result = {}
    for i, s in enumerate(sources):
        if not s['trusted']:
            r = resolve_source(i, s)
            for k, v in r.items():
                result[k] = v
    return result
