import json
import re


def combine(payload, left, right):
    tags = payload.get('tags', False)
    keys = payload.get('keys', {})

    merged = {}
    for bindings in (left, right):
        for key, entry in bindings.items():
            src_idx = entry[0]
            if key not in merged or src_idx >= merged[key][0]:
                merged[key] = entry

    final = {}
    for key, entry in merged.items():
        src_idx, decl_pos, val_info = entry
        val_pos, text, is_vault, trusted = val_info
        final[key] = {
            'decl_pos': decl_pos,
            'val_pos': val_pos,
            'text': text,
            'is_vault': is_vault,
            'trusted': trusted,
        }

    if not tags:
        for key, info in final.items():
            if info['is_vault']:
                if key not in keys:
                    return {"status": "sealed"}

    render_cache = {}

    def get_render(key):
        if key in render_cache:
            return render_cache[key]
        info = final[key]
        if info['is_vault']:
            if tags:
                render_cache[key] = "[sealed]"
                return "[sealed]"
            else:
                plain = keys[key]
                result = _resolve_refs(plain, get_render)
                render_cache[key] = result
                return result
        if not info['trusted']:
            render_cache[key] = info['text']
            return info['text']
        result = _resolve_refs(info['text'], get_render)
        render_cache[key] = result
        return result

    entries = []
    for key in sorted(final.keys()):
        info = final[key]
        if info['is_vault'] and tags:
            trusted_out = False
        elif info['is_vault']:
            trusted_out = True
        else:
            trusted_out = info['trusted']
        render_val = get_render(key)
        entries.append([key, info['decl_pos'], info['val_pos'], trusted_out, render_val])

    dump_lines = []
    for key in sorted(final.keys()):
        info = final[key]
        raw_text = info['text']
        if info['is_vault'] and tags:
            line = f'{key}: !vault {json.dumps(raw_text)}'
        else:
            line = f'{key}: {json.dumps(raw_text)}'
        dump_lines.append(line)
    dump = '\n'.join(dump_lines) + '\n'

    return {"status": "ok", "entries": entries, "dump": dump}


def _resolve_refs(text, get_render):
    if '${' not in text:
        return text

    def replacer(m):
        ref_key = m.group(1)
        try:
            return get_render(ref_key)
        except (KeyError, RecursionError):
            return m.group(0)

    return re.sub(r'\$\{(\w+)\}', replacer, text)
