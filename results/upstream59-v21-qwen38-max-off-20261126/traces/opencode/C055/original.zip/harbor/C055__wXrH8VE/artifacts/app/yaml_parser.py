def parse_yaml_lines(yaml_text):
    lines = yaml_text.split('\n')
    if lines and lines[-1] == '':
        lines = lines[:-1]
    entries = []
    for line_idx, line in enumerate(lines):
        lineno = line_idx + 1
        stripped = line.strip()
        if stripped == '' or stripped == '---':
            continue
        colon_pos = line.index(': ')
        key = line[:colon_pos]
        raw_value = line[colon_pos + 2:]
        value_col = colon_pos + 3
        entries.append((key, raw_value, lineno, value_col))
    return entries


def resolve_source(source_index, source):
    name = source['name']
    trusted = source['trusted']
    yaml_text = source['yaml']
    entries = parse_yaml_lines(yaml_text)
    anchors = {}
    result = {}
    for key, raw_value, lineno, value_col in entries:
        decl_pos = [name, lineno, 1]
        is_vault = False
        anchor_name = None
        alias_ref = None
        text = raw_value
        actual_value_col = value_col
        if raw_value.startswith('&'):
            parts = raw_value.split(' ', 1)
            anchor_name = parts[0][1:]
            text = parts[1] if len(parts) > 1 else ''
        elif raw_value.startswith('*'):
            alias_ref = raw_value[1:].strip()
        elif raw_value.startswith('!vault '):
            is_vault = True
            text = raw_value[7:]
            rest = text
            if rest.startswith('&'):
                parts = rest.split(' ', 1)
                anchor_name = parts[0][1:]
                text = parts[1] if len(parts) > 1 else ''
        if alias_ref is not None:
            if alias_ref in anchors:
                ref_val_pos, ref_text, ref_is_vault = anchors[alias_ref]
                val_info = [ref_val_pos, ref_text, ref_is_vault, trusted]
            else:
                val_info = [[name, lineno, value_col], text, is_vault, trusted]
        else:
            val_pos = [name, lineno, actual_value_col]
            val_info = [val_pos, text, is_vault, trusted]
            if anchor_name is not None:
                anchors[anchor_name] = (val_pos, text, is_vault)
        result[key] = [source_index, decl_pos, val_info]
    return result
