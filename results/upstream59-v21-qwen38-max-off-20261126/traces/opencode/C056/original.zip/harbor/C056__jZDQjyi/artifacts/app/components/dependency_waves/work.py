def compute(payload):
    tasks = payload["tasks"]
    task_map = {t["id"]: t for t in tasks}
    remaining = set(task_map.keys())
    done = set()
    waves = []
    while remaining:
        wave = sorted(tid for tid in remaining if all(n in done for n in task_map[tid]["needs"]))
        if not wave:
            break
        waves.append(wave)
        done.update(wave)
        remaining -= set(wave)
    return waves
