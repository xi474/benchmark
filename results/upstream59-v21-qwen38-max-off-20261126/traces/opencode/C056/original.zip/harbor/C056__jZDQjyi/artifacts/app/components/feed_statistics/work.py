def compute(payload):
    feeds = payload["feeds"]
    result = {}
    for host in sorted(feeds.keys()):
        result[host] = {}
        for stream in sorted(feeds[host].keys()):
            batches = feeds[host][stream]
            result[host][stream] = [[b, len(b), sum(b)] for b in batches]
    return result
