def combine(payload, left, right):
    waves = left
    task_map = {t["id"]: t for t in payload["tasks"]}
    pools = payload["pools"]
    initial = dict(payload["initial"])
    facts = dict(initial)

    pool_counters = {p: 0 for p in pools}
    feed_counters = {}
    for host in payload["feeds"]:
        feed_counters[host] = {s: 0 for s in payload["feeds"][host]}

    pool_reads = {p: 0 for p in pools}
    feed_reads = {}
    for host in payload["feeds"]:
        feed_reads[host] = {s: 0 for s in payload["feeds"][host]}

    task_results = {}
    task_deltas = {}

    for wave in waves:
        wave_base = dict(facts)
        host_delta_accum = {}

        for tid in wave:
            t = task_map[tid]
            pool_name = t["pool"]
            stream_name = t["stream"]

            pool_list = pools[pool_name]
            host = pool_list[pool_counters[pool_name] % len(pool_list)]
            pool_counters[pool_name] += 1
            pool_reads[pool_name] += 1

            feed_list = payload["feeds"][host][stream_name]
            batch_idx = feed_counters[host][stream_name] % len(feed_list)
            items = feed_list[batch_idx]
            feed_counters[host][stream_name] += 1
            feed_reads[host][stream_name] += 1

            base = wave_base[host]
            parent = sum(task_deltas[n] for n in t["needs"])

            delta = sum((base + item) * (1 + parent) for item in items)

            task_results[tid] = {
                "host": host,
                "items": items,
                "base": base,
                "parent": parent,
                "delta": delta,
                "attempts": t["attempts"],
            }
            task_deltas[tid] = delta

            host_delta_accum[host] = host_delta_accum.get(host, 0) + delta

        for h, d in host_delta_accum.items():
            facts[h] = facts[h] + d

    return {
        "tasks": task_results,
        "facts": facts,
        "pool_reads": pool_reads,
        "feed_reads": feed_reads,
    }
