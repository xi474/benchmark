def compute(payload):
    handlers = payload.get("handlers", [])
    program = payload.get("program", {})
    handler_order = {}
    for i, h in enumerate(handlers):
        handler_order[h] = i
    leaf_notifs = {}
    _walk_program(program, leaf_notifs, [], handler_order)
    return [handler_order, leaf_notifs]


def _walk_program(program, leaf_notifs, prefix, handler_order):
    phases = ["pre", "roles", "includes", "tasks", "post"]
    for pi, phase in enumerate(phases):
        items = program.get(phase, [])
        if not isinstance(items, list):
            continue
        for ii, item in enumerate(items):
            path = prefix + [pi, ii]
            _walk_item(item, leaf_notifs, path, handler_order)


def _walk_item(item, leaf_notifs, path, handler_order):
    key = "/".join(str(p) for p in path)
    if "block" in item:
        blk = item["block"]
        sub_phases = [("tasks", 0), ("rescue", 1), ("always", 2)]
        for sp_name, sp_idx in sub_phases:
            sub_items = blk.get(sp_name, [])
            if not isinstance(sub_items, list):
                continue
            for si, sub_item in enumerate(sub_items):
                sub_path = path + [sp_idx, si]
                _walk_item(sub_item, leaf_notifs, sub_path, handler_order)
    else:
        notify = item.get("notify")
        if notify and isinstance(notify, list) and len(notify) > 0:
            seen = set()
            ordered = []
            for n in notify:
                if n not in seen and n in handler_order:
                    seen.add(n)
                    ordered.append(n)
            ordered.sort(key=lambda x: handler_order[x])
            if ordered:
                leaf_notifs[key] = ordered
