def compute(payload):
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})
    result = {}
    for h in hosts:
        table = {}
        _walk_program(program, h, table, [])
        result[h] = table
    return result


def _walk_program(program, host, table, prefix):
    phases = ["pre", "roles", "includes", "tasks", "post"]
    for pi, phase in enumerate(phases):
        items = program.get(phase, [])
        if not isinstance(items, list):
            continue
        for ii, item in enumerate(items):
            path = prefix + [pi, ii]
            _walk_item(item, host, table, path)


def _walk_item(item, host, table, path):
    key = "/".join(str(p) for p in path)
    if "block" in item:
        blk = item["block"]
        only = item.get("only")
        executable = _host_matches(host, only)
        table[key] = [executable, False]
        sub_phases = [("tasks", 0), ("rescue", 1), ("always", 2)]
        for sp_name, sp_idx in sub_phases:
            sub_items = blk.get(sp_name, [])
            if not isinstance(sub_items, list):
                continue
            for si, sub_item in enumerate(sub_items):
                sub_path = path + [sp_idx, si]
                _walk_item(sub_item, host, table, sub_path)
    else:
        only = item.get("only")
        executable = _host_matches(host, only)
        fail_hosts = item.get("fail_hosts")
        will_fail = False
        if fail_hosts is not None:
            will_fail = host in fail_hosts
        table[key] = [executable, will_fail]


def _host_matches(host, only):
    if only is None:
        return True
    if isinstance(only, list):
        return host in only
    if isinstance(only, set):
        return host in only
    return host == only
