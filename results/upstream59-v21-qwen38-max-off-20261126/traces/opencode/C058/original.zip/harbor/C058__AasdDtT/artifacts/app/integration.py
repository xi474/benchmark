def combine(payload, host_conds, handler_info):
    hosts = payload.get("hosts", [])
    program = payload.get("program", {})
    handler_order_map = handler_info[0] if handler_info else {}
    leaf_notifs = handler_info[1] if handler_info else {}

    nodes = []
    _build_node_list(program, nodes)

    if not nodes:
        return {"batches": [], "final": {h: "ok" for h in hosts}}

    all_positions = []
    for i, n in enumerate(nodes):
        all_positions.append(i)
        if n["phase_end"]:
            all_positions.append(("flush", n["phase_idx"]))

    def pos_key(entry):
        if isinstance(entry, tuple) and entry[0] == "flush":
            return (entry[1], 1, 999999)
        n = nodes[entry]
        return (n["phase_idx"], 0, tuple(n["sort_key"]))

    host_state = {}
    for h in hosts:
        host_state[h] = {
            "cond_table": host_conds.get(h, {}),
            "pos": 0,
            "failed": False,
            "block_stack": [],
            "notifications": {},
            "done": False,
        }

    batches = []
    final = {h: "ok" for h in hosts}

    while True:
        active_hosts = [h for h in hosts if not host_state[h]["done"]]
        if not active_hosts:
            break

        candidates = []
        for h in active_hosts:
            st = host_state[h]
            pos = st["pos"]
            if pos >= len(all_positions):
                st["done"] = True
                continue
            candidates.append((pos_key(all_positions[pos]), h))

        if not candidates:
            break

        best_key = min(candidates, key=lambda c: c[0])[0]
        round_hosts = [h for h in active_hosts
                       if not host_state[h]["done"]
                       and pos_key(all_positions[host_state[h]["pos"]]) == best_key]

        entry = all_positions[host_state[round_hosts[0]]["pos"]]

        if isinstance(entry, tuple) and entry[0] == "flush":
            phase_idx = entry[1]
            batch = []
            for h in round_hosts:
                st = host_state[h]
                notifs = st["notifications"].get(phase_idx, set())
                if notifs:
                    sorted_h = sorted(notifs, key=lambda x: handler_order_map.get(x, 999999))
                    batch.append({"host": h, "task": None, "kind": "flush", "status": "ok", "handlers": sorted_h})
                    for hn in sorted_h:
                        batch.append({"host": h, "task": None, "kind": "handler", "status": "ok"})
                st["notifications"].pop(phase_idx, None)
                st["pos"] += 1
            if batch:
                batches.append(batch)
            else:
                for h in round_hosts:
                    host_state[h]["pos"] += 1
        else:
            node_idx = entry
            node = nodes[node_idx]

            if node["kind"] == "block_exit":
                for h in round_hosts:
                    st = host_state[h]
                    _resolve_block(st)
                    st["pos"] += 1
                continue

            batch = []
            for h in round_hosts:
                st = host_state[h]
                path_key = node["path_key"]
                cond = st["cond_table"].get(path_key, [True, False])
                executable = cond[0]
                will_fail = cond[1]

                if node["kind"] == "block_enter":
                    parent_inactive = _is_any_parent_inactive(st)
                    if parent_inactive or st["failed"] or not executable:
                        st["block_stack"].append({"active": False, "had_failure": False, "rescue_ok": False, "skip_normal": False})
                    else:
                        st["block_stack"].append({"active": True, "had_failure": False, "rescue_ok": False, "skip_normal": False})
                    st["pos"] += 1
                    continue

                branch = node["branch"]
                in_rescue = branch == 1
                in_always = branch == 2
                in_normal = branch == 0

                top = st["block_stack"][-1] if st["block_stack"] else None

                if top and not top["active"]:
                    st["pos"] += 1
                    continue

                if st["failed"] and not in_always:
                    if in_rescue and top and top["active"] and top["had_failure"]:
                        pass
                    else:
                        st["pos"] += 1
                        continue

                if in_normal and top and top["skip_normal"]:
                    st["pos"] += 1
                    continue

                if in_rescue and top and not top["had_failure"]:
                    st["pos"] += 1
                    continue

                if not executable:
                    st["pos"] += 1
                    continue

                task_id = node["task_id"]

                if will_fail:
                    batch.append({"host": h, "task": task_id, "kind": "task", "status": "failed"})
                    if in_normal:
                        if top and top["active"]:
                            top["skip_normal"] = True
                            top["had_failure"] = True
                        else:
                            st["failed"] = True
                    elif in_rescue:
                        if top and top["active"]:
                            top["had_failure"] = True
                        else:
                            st["failed"] = True
                    elif in_always:
                        st["failed"] = True
                else:
                    batch.append({"host": h, "task": task_id, "kind": "task", "status": "ok"})
                    notifs_list = leaf_notifs.get(path_key, [])
                    if notifs_list:
                        pi = node["phase_idx"]
                        if pi not in st["notifications"]:
                            st["notifications"][pi] = set()
                        for n_name in notifs_list:
                            st["notifications"][pi].add(n_name)
                    if in_rescue and top and top["active"]:
                        top["rescue_ok"] = True

                st["pos"] += 1

            if batch:
                batches.append(batch)

        for h in round_hosts:
            st = host_state[h]
            if st["pos"] >= len(all_positions):
                st["done"] = True

    for h in hosts:
        if host_state[h]["failed"]:
            final[h] = "failed"

    return {"batches": batches, "final": final}


def _is_any_parent_inactive(st):
    for blk in st["block_stack"]:
        if not blk["active"]:
            return True
    return False


def _resolve_block(st):
    if not st["block_stack"]:
        return
    blk = st["block_stack"].pop()
    if blk["active"] and blk["had_failure"] and not blk["rescue_ok"]:
        propagated = False
        if st["block_stack"]:
            for b in reversed(st["block_stack"]):
                if b["active"]:
                    b["had_failure"] = True
                    propagated = True
                    break
        if not propagated:
            st["failed"] = True


def _build_node_list(program, nodes_out):
    phases = ["pre", "roles", "includes", "tasks", "post"]
    for pi, phase in enumerate(phases):
        items = program.get(phase, [])
        if not isinstance(items, list):
            continue
        phase_start = len(nodes_out)
        for ii, item in enumerate(items):
            path = [pi, ii]
            _walk_item_nodes(item, nodes_out, path, pi)
        for i in range(phase_start, len(nodes_out)):
            nodes_out[i]["phase_end"] = False
        if len(nodes_out) > phase_start:
            nodes_out[-1]["phase_end"] = True


def _walk_item_nodes(item, nodes, path, phase_idx):
    path_key = "/".join(str(p) for p in path)
    if "block" in item:
        nodes.append({
            "path_key": path_key,
            "kind": "block_enter",
            "task_id": None,
            "phase_idx": phase_idx,
            "sort_key": path + [0],
            "branch": -1,
            "phase_end": False,
        })
        sub_phases = [("tasks", 0), ("rescue", 1), ("always", 2)]
        for sp_name, sp_idx in sub_phases:
            sub_items = item["block"].get(sp_name, [])
            if not isinstance(sub_items, list):
                continue
            for si, sub_item in enumerate(sub_items):
                sub_path = path + [sp_idx, si]
                _walk_item_nodes(sub_item, nodes, sub_path, phase_idx)
        nodes.append({
            "path_key": path_key,
            "kind": "block_exit",
            "task_id": None,
            "phase_idx": phase_idx,
            "sort_key": path + [3],
            "branch": -1,
            "phase_end": False,
        })
    else:
        task_id = item.get("id", "")
        actual_branch = 0
        if len(path) >= 2:
            parent_idx = path[-2]
            if parent_idx in (0, 1, 2):
                actual_branch = parent_idx
        nodes.append({
            "path_key": path_key,
            "kind": "task",
            "task_id": task_id,
            "phase_idx": phase_idx,
            "sort_key": path,
            "branch": actual_branch,
            "phase_end": False,
        })
