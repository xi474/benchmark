def compute(payload):
    result = {}
    for i, ev in enumerate(payload["events"]):
        if ev["op"] == "complete":
            changed = ev.get("changed", False)
            new_rev = ev.get("revision") if changed else None
            event_name = "snapshot_updated" if changed else "poll_unchanged"
            result[str(i)] = [event_name, new_rev]
    return result
