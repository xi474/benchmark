def compute(payload):
    result = {}
    for i, ev in enumerate(payload["events"]):
        if ev["op"] == "open":
            result[str(i)] = {
                "backend": ev["backend"],
                "state": "open",
                "job": None,
                "revision": ev.get("revision", 0),
                "closed_at": None,
                "updates": 0,
            }
    return result
