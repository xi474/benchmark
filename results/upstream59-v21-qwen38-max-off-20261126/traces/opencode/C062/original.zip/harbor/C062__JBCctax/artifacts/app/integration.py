def combine(payload, left, right):
    events = payload["events"]
    stores = {}
    for k, v in left.items():
        idx = int(k)
        ev = events[idx]
        stores[ev["store"]] = {
            "backend": v["backend"],
            "state": v["state"],
            "job": v["job"],
            "revision": v["revision"],
            "closed_at": v["closed_at"],
            "updates": v["updates"],
        }

    output_events = []
    cancel_pending = {}
    close_waiters = {}

    for i, ev in enumerate(events):
        t = ev["time"]
        s = ev["store"]
        op = ev["op"]
        st = stores[s]

        if op == "open":
            output_events.append({"time": t, "store": s, "event": "opened"})

        elif op == "poll":
            job = ev["job"]
            if st["state"] in ("closing", "closed"):
                output_events.append({"time": t, "store": s, "event": "poll_rejected"})
            elif st["job"] is not None:
                output_events.append({"time": t, "store": s, "event": "poll_coalesced"})
            else:
                st["job"] = job
                output_events.append({"time": t, "store": s, "event": "poll_started", "job": job})

        elif op == "complete":
            job = ev["job"]
            comp_info = right.get(str(i))
            cancelled = s in cancel_pending and cancel_pending[s] == job

            if cancelled:
                output_events.append({"time": t, "store": s, "event": "callback_cancelled", "job": job})
                del cancel_pending[s]
                st["job"] = None
                if s in close_waiters:
                    st["state"] = "closed"
                    st["closed_at"] = t
                    for w in close_waiters[s]:
                        output_events.append({"time": t, "store": s, "event": "close_returned"})
                    del close_waiters[s]
            else:
                changed = ev.get("changed", False)
                if changed:
                    new_rev = ev.get("revision")
                    st["revision"] = new_rev
                    st["updates"] += 1
                    output_events.append({"time": t, "store": s, "event": "snapshot_updated", "job": job})
                else:
                    output_events.append({"time": t, "store": s, "event": "poll_unchanged", "job": job})
                st["job"] = None

        elif op == "close":
            if st["state"] == "closed":
                output_events.append({"time": t, "store": s, "event": "close_returned"})
            elif st["state"] == "closing":
                output_events.append({"time": t, "store": s, "event": "close_waiting"})
                if s not in close_waiters:
                    close_waiters[s] = []
                close_waiters[s].append(t)
            elif st["job"] is not None:
                st["state"] = "closing"
                job = st["job"]
                cancel_pending[s] = job
                output_events.append({"time": t, "store": s, "event": "cancel_sent", "job": job})
                output_events.append({"time": t, "store": s, "event": "close_waiting"})
                if s not in close_waiters:
                    close_waiters[s] = []
                close_waiters[s].append(t)
            else:
                st["state"] = "closed"
                st["closed_at"] = t
                output_events.append({"time": t, "store": s, "event": "close_returned"})

    return {"events": output_events, "stores": stores}
