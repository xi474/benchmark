COL_TYPES = {"key": "text", "body": "text", "rank": "int"}

_SENTINEL = object()


def decode_value(col):
    name = col["name"]
    typ = col["type"]
    val = col["value"]
    expected = COL_TYPES.get(name)
    if expected is None or typ != expected:
        return _SENTINEL
    if val is None:
        return None
    if typ == "text":
        if not isinstance(val, str):
            return _SENTINEL
        return val
    if typ == "int":
        if not isinstance(val, str):
            return _SENTINEL
        try:
            return int(val)
        except (ValueError, TypeError):
            return _SENTINEL
    return _SENTINEL


def compute(payload):
    result = []
    for tx in payload.get("txs", []):
        tx_stmts = []
        for stmt in tx.get("statements", []):
            stmt_changes = []
            for change in stmt:
                op = change["op"]
                if op == "D":
                    stmt_changes.append({})
                else:
                    cols = change.get("cols", [])
                    decoded = {}
                    type_error = False
                    for c in cols:
                        v = decode_value(c)
                        if v is _SENTINEL:
                            type_error = True
                            break
                        decoded[c["name"]] = v
                    if type_error:
                        stmt_changes.append(None)
                    else:
                        stmt_changes.append(decoded)
            tx_stmts.append(stmt_changes)
        result.append(tx_stmts)
    return result
