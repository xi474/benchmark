def compute(payload):
    result = []
    for tx in payload.get("txs", []):
        tx_keys = []
        for stmt in tx.get("statements", []):
            seen = set()
            keys = []
            for change in stmt:
                if change["op"] in ("U", "D"):
                    old = change["old"]
                    if old not in seen:
                        seen.add(old)
                        keys.append(old)
            tx_keys.append(keys)
        result.append(tx_keys)
    return result
