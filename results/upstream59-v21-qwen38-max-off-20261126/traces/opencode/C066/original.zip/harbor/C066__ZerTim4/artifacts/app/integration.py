def combine(payload, left, right):
    initial = payload.get("initial", {})
    txs = payload.get("txs", [])
    rows = {}
    for pk, data in initial.items():
        rows[pk] = {"body": data["body"], "rank": data["rank"]}

    committed_lsns = set()
    log = []

    for tx_idx, tx in enumerate(txs):
        lsn = tx["lsn"]
        if lsn in committed_lsns:
            log.append([lsn, "REPLAY"])
            continue

        statements = tx.get("statements", [])
        tx_old_keys = left[tx_idx] if tx_idx < len(left) else []
        tx_decoded = right[tx_idx] if tx_idx < len(right) else []

        snapshot = {k: dict(v) for k, v in rows.items()}
        aborted = False

        for stmt_idx, stmt in enumerate(statements):
            decoded_changes = tx_decoded[stmt_idx] if stmt_idx < len(tx_decoded) else []

            for ci, change in enumerate(stmt):
                decoded = decoded_changes[ci] if ci < len(decoded_changes) else None
                if decoded is None and change["op"] != "D":
                    aborted = True
                    break

            if aborted:
                break

            current_rows = {k: dict(v) for k, v in rows.items()}
            old_keys_in_stmt = set()
            new_rows = {}

            for ci, change in enumerate(stmt):
                op = change["op"]
                decoded = decoded_changes[ci] if ci < len(decoded_changes) else {}

                if op in ("U", "D"):
                    old_key = change["old"]
                    if old_key not in current_rows:
                        aborted = True
                        break
                    if old_key in old_keys_in_stmt:
                        aborted = True
                        break
                    old_keys_in_stmt.add(old_key)

                if op == "I":
                    if "key" not in decoded:
                        aborted = True
                        break
                    new_key = decoded["key"]
                    if new_key in new_rows:
                        aborted = True
                        break
                    body_val = decoded.get("body")
                    rank_val = decoded.get("rank")
                    if "body" not in decoded or "rank" not in decoded:
                        aborted = True
                        break
                    new_rows[new_key] = {"body": body_val, "rank": rank_val}

                elif op == "U":
                    old_key = change["old"]
                    old_row = current_rows[old_key]
                    new_key = decoded.get("key", old_key)
                    body_val = decoded.get("body", old_row["body"])
                    rank_val = decoded.get("rank", old_row["rank"])
                    if new_key in new_rows:
                        aborted = True
                        break
                    new_rows[new_key] = {"body": body_val, "rank": rank_val}

                elif op == "D":
                    pass

            if aborted:
                break

            for ok in old_keys_in_stmt:
                if ok in current_rows:
                    del current_rows[ok]

            for nk, nv in new_rows.items():
                if nk in current_rows and nk not in old_keys_in_stmt:
                    aborted = True
                    break

            if aborted:
                break

            for nk, nv in new_rows.items():
                current_rows[nk] = nv

            rows = current_rows

        if aborted:
            rows = snapshot
            log.append([lsn, "ABORT"])
        else:
            committed_lsns.add(lsn)
            log.append([lsn, "COMMIT"])

    return {"log": log, "rows": rows}
