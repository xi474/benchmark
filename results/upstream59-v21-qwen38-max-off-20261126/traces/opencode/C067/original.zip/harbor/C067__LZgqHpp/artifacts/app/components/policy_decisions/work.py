def compute(payload):
    policies = {u: list(rules) for u, rules in payload.get("policies", {}).items()}
    result = {}
    idx = 0
    for ev in payload.get("events", []):
        op = ev.get("op")
        if op == "policy":
            user = ev["user"]
            policies[user] = list(ev.get("allow", []))
        elif op == "request":
            user = ev.get("user", "")
            cluster = ev.get("cluster", "")
            verb = ev.get("verb", "")
            service = ev.get("service", "")
            allowed = False
            for rule in policies.get(user, []):
                if rule.get("cluster") == cluster and rule.get("verb") == verb:
                    svc = rule.get("service")
                    if svc is None or svc == "*":
                        allowed = True
                        break
                    if svc == service:
                        allowed = True
                        break
            result[str(idx)] = allowed
            idx += 1
    return result
