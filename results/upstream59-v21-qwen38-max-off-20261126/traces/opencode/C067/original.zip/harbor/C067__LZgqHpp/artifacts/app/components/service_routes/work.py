def compute(payload):
    clusters = {}
    for cname, cdata in payload.get("clusters", {}).items():
        clusters[cname] = {
            "mode": cdata.get("mode", "local"),
            "services": dict(cdata.get("services", {}))
        }
    result = {}
    idx = 0
    for ev in payload.get("events", []):
        op = ev.get("op")
        if op == "service":
            cluster = ev["cluster"]
            service = ev["service"]
            available = ev.get("available", True)
            if cluster in clusters:
                clusters[cluster]["services"][service] = available
        elif op == "request":
            cluster = ev.get("cluster", "")
            service = ev.get("service", "")
            cinfo = clusters.get(cluster)
            if cinfo is None:
                mode = "local"
                avail = False
            else:
                mode = cinfo["mode"]
                avail = cinfo["services"].get(service, False)
            result[str(idx)] = [mode, avail]
            idx += 1
    return result
