def combine(payload, left, right):
    ttl = payload.get("ttl", 0)
    events = payload.get("events", [])
    replies = []
    authorizer_calls = 0
    service_lookups = 0
    remote_routes = 0
    certificates_issued = 0
    cert_counter = 0
    cache = {}
    now = 0
    req_idx = 0
    for ev in events:
        op = ev.get("op")
        if op == "request":
            now = ev.get("time", now)
            auth_key = str(req_idx)
            authorized = left.get(auth_key, False)
            authorizer_calls += 1
            if not authorized:
                replies.append({"id": ev["id"], "status": "denied"})
                req_idx += 1
                continue
            route_info = right.get(auth_key, ["local", False])
            mode = route_info[0]
            avail = route_info[1]
            service_lookups += 1
            if not avail:
                replies.append({"id": ev["id"], "status": "not_found"})
                req_idx += 1
                continue
            user = ev.get("user", "")
            cluster = ev.get("cluster", "")
            service = ev.get("service", "")
            if mode == "local":
                replies.append({
                    "id": ev["id"],
                    "status": "ok",
                    "credential": "local",
                    "route": "local"
                })
            else:
                remote_routes += 1
                ckey = (user, cluster, service)
                entry = cache.get(ckey)
                if entry is not None and entry["expires"] > now:
                    cred = entry["credential"]
                else:
                    cert_counter += 1
                    certificates_issued += 1
                    cred = f"cert-{cert_counter}"
                    cache[ckey] = {"credential": cred, "expires": now + ttl}
                replies.append({
                    "id": ev["id"],
                    "status": "ok",
                    "credential": cred,
                    "route": "reverse_tunnel"
                })
            req_idx += 1
    final_cache = []
    for key in sorted(cache.keys()):
        u, c, s = key
        e = cache[key]
        final_cache.append({
            "user": u,
            "cluster": c,
            "service": s,
            "credential": e["credential"],
            "expires": e["expires"]
        })
    return {
        "replies": replies,
        "authorizer_calls": authorizer_calls,
        "service_lookups": service_lookups,
        "remote_routes": remote_routes,
        "certificates_issued": certificates_issued,
        "cache": final_cache
    }
