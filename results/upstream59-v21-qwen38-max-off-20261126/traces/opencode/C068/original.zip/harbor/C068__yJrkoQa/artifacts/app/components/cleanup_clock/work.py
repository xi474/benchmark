def compute(payload):
    ttl = payload["ttl"]
    events = payload["events"]
    next_cleanup = 16 * ttl
    result = {}
    for i, ev in enumerate(events):
        if ev["op"] != "get":
            continue
        now = ev["time"]
        if now >= next_cleanup:
            next_cleanup = now + 16 * ttl
            result[str(i)] = next_cleanup
    return result
