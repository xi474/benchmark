def compute(payload):
    events = payload["events"]
    result = {}
    for i, ev in enumerate(events):
        if ev["op"] != "get":
            continue
        finished = ev["time"] + ev["delay"]
        result[str(i)] = [finished, ev["value"], ev.get("error")]
    return result
