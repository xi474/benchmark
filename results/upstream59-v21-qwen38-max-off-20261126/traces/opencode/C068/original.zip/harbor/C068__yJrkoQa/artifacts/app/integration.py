def combine(payload, cleanup_clock_data, load_proposals_data):
    ttl = payload["ttl"]
    events = payload["events"]

    cache = {}
    next_cleanup = 16 * ttl
    in_flight = {}
    loads = []
    result_by_id = {}

    def complete_loads(up_to_time):
        completed_keys = []
        for key, info in in_flight.items():
            if info["finished_at"] <= up_to_time:
                completed_keys.append(key)
        completed_keys.sort(key=lambda k: in_flight[k]["started_at"])
        for key in completed_keys:
            info = in_flight.pop(key)
            proposal = info["proposal"]
            finished_at = info["finished_at"]
            val = proposal[1]
            err = proposal[2]
            cache[key] = {"value": val, "error": err, "expires": finished_at + ttl}
            loads.append({"key": key, "started_at": info["started_at"], "finished_at": finished_at})
            for w in info.get("waiters", []):
                if w["cancelled"]:
                    result_by_id[w["id"]] = {"id": w["id"], "status": "cancelled", "value": None, "error": "cancelled", "finished_at": finished_at}
                elif err is not None:
                    result_by_id[w["id"]] = {"id": w["id"], "status": "error", "value": None, "error": err, "finished_at": finished_at}
                else:
                    result_by_id[w["id"]] = {"id": w["id"], "status": "ok", "value": val, "error": None, "finished_at": finished_at}

    def do_cleanup(now):
        expired = [k for k, v in cache.items() if v["expires"] <= now]
        for k in expired:
            del cache[k]

    for i, ev in enumerate(events):
        current_time = ev["time"]

        if ev["op"] == "advance":
            complete_loads(current_time)
            continue

        if ev["op"] == "cancel":
            target_id = ev["id"]
            for key, info in in_flight.items():
                for w in info.get("waiters", []):
                    if w["id"] == target_id and not w["cancelled"]:
                        w["cancelled"] = True
            continue

        if ev["op"] == "get":
            complete_loads(current_time)

            pos = str(i)
            now = current_time

            if pos in cleanup_clock_data:
                do_cleanup(now)
                next_cleanup = cleanup_clock_data[pos]

            key = ev["key"]

            if key in cache and cache[key]["expires"] > now:
                entry = cache[key]
                err = entry["error"]
                val = entry["value"]
                if err is not None:
                    result_by_id[ev["id"]] = {"id": ev["id"], "status": "error", "value": None, "error": err, "finished_at": now}
                else:
                    result_by_id[ev["id"]] = {"id": ev["id"], "status": "ok", "value": val, "error": None, "finished_at": now}
                continue

            if key in cache:
                del cache[key]

            if key in in_flight:
                in_flight[key]["waiters"].append({"id": ev["id"], "cancelled": False})
                continue

            proposal = load_proposals_data[pos]
            finished_at = proposal[0]

            if finished_at <= now:
                val = proposal[1]
                err = proposal[2]
                cache[key] = {"value": val, "error": err, "expires": finished_at + ttl}
                loads.append({"key": key, "started_at": now, "finished_at": finished_at})
                if err is not None:
                    result_by_id[ev["id"]] = {"id": ev["id"], "status": "error", "value": None, "error": err, "finished_at": finished_at}
                else:
                    result_by_id[ev["id"]] = {"id": ev["id"], "status": "ok", "value": val, "error": None, "finished_at": finished_at}
            else:
                in_flight[key] = {
                    "started_at": now,
                    "finished_at": finished_at,
                    "proposal": proposal,
                    "waiters": [{"id": ev["id"], "cancelled": False}]
                }

    complete_loads(float('inf'))

    final_results = []
    seen = set()
    for ev in events:
        if ev["op"] == "get":
            rid = ev["id"]
            if rid not in seen and rid in result_by_id:
                final_results.append(result_by_id[rid])
                seen.add(rid)

    sorted_cache = sorted(cache.items(), key=lambda x: x[0])
    cache_out = [{"key": k, "value": v["value"], "error": v["error"], "expires": v["expires"]} for k, v in sorted_cache]

    return {
        "results": final_results,
        "loads": loads,
        "cache": cache_out,
        "next_cleanup": next_cleanup
    }
