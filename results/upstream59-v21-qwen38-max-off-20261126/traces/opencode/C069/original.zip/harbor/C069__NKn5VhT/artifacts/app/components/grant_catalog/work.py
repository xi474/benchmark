def compute(payload):
    access_requests = payload.get("access_requests", {})
    result = {}
    for req_id, req in access_requests.items():
        result[req_id] = {
            "approved": req.get("approved", False),
            "expiry": req.get("expiry"),
            "roles": list(req.get("roles", [])),
            "resources": list(req.get("resources", [])),
        }
    return result
