import copy


def compute(payload):
    events = payload.get("events", [])
    user = payload.get("user", {})
    current_user = copy.deepcopy(user)
    result = {}
    for idx, ev in enumerate(events):
        if ev.get("op") == "update_user":
            updates = ev.get("user", {})
            if "roles" in updates:
                current_user["roles"] = list(updates["roles"])
            if "traits" in updates:
                current_user["traits"] = copy.deepcopy(updates["traits"])
        elif ev.get("op") == "renew":
            result[str(idx)] = copy.deepcopy(current_user)
    return result
