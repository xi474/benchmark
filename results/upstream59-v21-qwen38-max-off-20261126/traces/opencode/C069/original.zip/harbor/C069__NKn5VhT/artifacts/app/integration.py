import base64
import copy
import json


def _encode_cert(prefix, obj):
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    b = base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii").rstrip("=")
    return prefix + b


def combine(payload, user_history, grant_catalog):
    user = payload["user"]
    start_time = payload["start_time"]
    session_ttl = payload["session_ttl"]
    events = payload.get("events", [])
    initial_id = payload.get("initial_id", "s0")

    sessions = {}
    session_ids = [initial_id]
    sessions[initial_id] = {
        "cached_user": copy.deepcopy(user),
        "login_time": start_time,
        "expiry": start_time + session_ttl,
        "active_requests": {},
    }

    replies = []

    for ev in events:
        op = ev.get("op")
        if op == "update_user":
            updates = ev.get("user", {})
            if "roles" in updates:
                user["roles"] = list(updates["roles"])
            if "traits" in updates:
                user["traits"] = copy.deepcopy(updates["traits"])
        elif op == "renew":
            new_id = ev["id"]
            prev_id = ev["prev"]
            now = ev["time"]
            reload_user = ev.get("reload_user", False)
            switchback = ev.get("switchback", False)
            access_request = ev.get("access_request", None)

            if prev_id not in sessions:
                replies.append({"id": new_id, "status": "expired"})
                continue

            prev = sessions[prev_id]

            if prev["expiry"] <= now:
                replies.append({"id": new_id, "status": "expired"})
                continue

            if reload_user:
                cached_user = copy.deepcopy(user)
            else:
                cached_user = copy.deepcopy(prev["cached_user"])

            if switchback:
                active_requests = {}
            else:
                active_requests = dict(prev["active_requests"])

            if access_request is not None:
                req_id = access_request
                if req_id not in grant_catalog:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue
                req = grant_catalog[req_id]
                if not req["approved"]:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue
                if req["expiry"] <= now:
                    replies.append({"id": new_id, "status": "request_unavailable"})
                    continue

                has_resources = len(req.get("resources", [])) > 0
                if has_resources:
                    for existing_req_id, existing_req in active_requests.items():
                        cat_entry = grant_catalog.get(existing_req_id, {})
                        if len(cat_entry.get("resources", [])) > 0:
                            replies.append({"id": new_id, "status": "resource_already_active"})
                            break
                    else:
                        active_requests[req_id] = {"expiry": req["expiry"], "roles": list(req.get("roles", [])), "resources": list(req.get("resources", []))}
                        # fall through to success below
                    if any(len(grant_catalog.get(eid, {}).get("resources", [])) > 0 for eid in active_requests if eid != req_id):
                        continue

                active_requests[req_id] = {"expiry": req["expiry"], "roles": list(req.get("roles", [])), "resources": list(req.get("resources", []))}

            expired_ids = [rid for rid, rdata in active_requests.items() if rdata["expiry"] <= now]
            for rid in expired_ids:
                replies.append({"id": new_id, "status": "request_unavailable"})
                break
            if expired_ids:
                continue

            all_roles = set(cached_user.get("roles", []))
            all_resources = set()
            min_expiry = now + session_ttl
            for rid, rdata in active_requests.items():
                all_roles.update(rdata.get("roles", []))
                all_resources.update(rdata.get("resources", []))
                if rdata["expiry"] < min_expiry:
                    min_expiry = rdata["expiry"]

            sorted_roles = sorted(all_roles)
            sorted_resources = sorted(all_resources)

            login_time = prev["login_time"]

            ssh_obj = {
                "roles": sorted_roles,
                "allowed_resources": sorted_resources,
                "extensions": copy.deepcopy(cached_user.get("traits", {})),
                "login_time": login_time,
                "expires": min_expiry,
            }
            tls_obj = {
                "user": cached_user["name"],
                "active_requests": sorted(active_requests.keys()),
                "login_time": login_time,
                "expires": min_expiry,
            }

            sessions[new_id] = {
                "cached_user": cached_user,
                "login_time": login_time,
                "expiry": min_expiry,
                "active_requests": active_requests,
            }
            session_ids.append(new_id)

            replies.append({
                "id": new_id,
                "status": "ok",
                "ssh_certificate": _encode_cert("SSH-MODEL1.", ssh_obj),
                "tls_certificate": _encode_cert("TLS-MODEL1.", tls_obj),
            })

    return {
        "replies": replies,
        "session_ids": session_ids,
    }
