import copy


def _resolve_node(logical_path, mounts, nodes):
    parts = logical_path.split("/")
    mount_name = parts[0]
    node_id = mounts[mount_name]
    for segment in parts[1:]:
        node = nodes[node_id]
        ignored = set(node.get("ignore", []))
        if segment in ignored:
            return None
        dirs = node.get("dirs", {})
        if segment not in dirs:
            return None
        node_id = dirs[segment]
    return node_id


def compute(payload):
    nodes = copy.deepcopy(payload["nodes"])
    mounts = payload["mounts"]
    result = []
    for scan in payload["scans"]:
        for nid, ndef in scan.get("replace", {}).items():
            nodes[nid] = copy.deepcopy(ndef)
        snap = {}
        for lp in scan["finish"]:
            nid = _resolve_node(lp, mounts, nodes)
            node = nodes[nid]
            ignored = set(node.get("ignore", []))
            files = {k: v for k, v in node.get("files", {}).items() if k not in ignored}
            subdirs = sorted(k for k in node.get("dirs", {}) if k not in ignored)
            snap[lp] = [files, subdirs]
        result.append(snap)
    return result
