def compute(payload):
    result = []
    for scan in payload["scans"]:
        finish = scan["finish"]
        indexed = list(enumerate(finish))
        indexed.sort(key=lambda pair: (pair[1].count("/"), pair[0]))
        result.append([p for _, p in indexed])
    return result
