def combine(payload, left, right):
    index = dict(payload.get("initial", {}))
    results = []
    for scan_idx, scan in enumerate(payload["scans"]):
        old_index = dict(index)
        snapshots = left[scan_idx]
        ordered_paths = right[scan_idx]
        finished_set = set(ordered_paths)
        for lp in ordered_paths:
            files_map, visible_subdirs = snapshots[lp]
            prefix = lp + "/"
            visible_entries = set(files_map.keys()) | set(visible_subdirs)
            to_remove = []
            for path in list(index.keys()):
                if path == lp or not path.startswith(prefix):
                    continue
                remainder = path[len(prefix):]
                slash_pos = remainder.find("/")
                if slash_pos == -1:
                    direct_name = remainder
                else:
                    direct_name = remainder[:slash_pos]
                if direct_name not in visible_entries:
                    to_remove.append(path)
                elif slash_pos != -1 and direct_name in set(visible_subdirs) and (prefix + direct_name) not in finished_set:
                    pass
            for p in to_remove:
                del index[p]
            for fname, tid in files_map.items():
                index[lp + "/" + fname] = tid
        new_index = index
        changed = {}
        all_tracks = set(old_index.values()) | set(new_index.values())
        for tid in all_tracks:
            old_paths = sorted(p for p, t in old_index.items() if t == tid)
            new_paths = sorted(p for p, t in new_index.items() if t == tid)
            if old_paths != new_paths:
                changed[tid] = [old_paths, new_paths]
        results.append({"index": dict(new_index), "changed": changed})
    return results
