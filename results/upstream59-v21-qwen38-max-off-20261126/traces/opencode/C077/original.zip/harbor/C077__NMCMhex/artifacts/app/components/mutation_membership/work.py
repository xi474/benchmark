def compute(payload):
    events = payload.get("events", [])
    active = []
    result = {}
    for i, ev in enumerate(events):
        op = ev.get("op")
        if op == "start":
            eid = ev["id"]
            if eid not in active:
                active.append(eid)
            result[str(i)] = list(active)
        elif op == "finish":
            eid = ev["id"]
            if eid in active:
                active.remove(eid)
            result[str(i)] = list(active)
    return result
