def compute(payload):
    events = payload.get("events", [])
    result = {}
    for i, ev in enumerate(events):
        if ev.get("op") != "response":
            continue
        failed = ev.get("failed", False)
        stale = ev.get("stale", 0)
        t = ev["time"]
        if failed:
            result[str(i)] = ["failure", t + 2000]
        elif stale == 1:
            result[str(i)] = ["stale", t + 1000]
        else:
            result[str(i)] = None
    return result
