def combine(payload, membership_map, deadline_map):
    events = payload.get("events", [])
    fetches = []
    commits = []
    audit = []
    active = []
    owed = False
    loading = False
    in_flight = None
    retry_at = None
    items = []
    fetch_counter = 0

    def emit_fetch(t):
        nonlocal fetch_counter, in_flight, loading
        fetch_counter += 1
        fid = "fetch-" + str(fetch_counter)
        fetches.append({"id": fid, "time": t})
        audit.append({"time": t, "event": "fetch", "id": fid})
        in_flight = fid
        loading = True
        return fid

    def do_commit(t, new_items, fid):
        nonlocal items
        items = list(new_items)
        commits.append({"time": t, "items": list(new_items)})
        audit.append({"time": t, "event": "committed", "id": fid})

    time_groups = {}
    for i, ev in enumerate(events):
        t = ev["time"]
        if t not in time_groups:
            time_groups[t] = []
        time_groups[t].append((i, ev))

    sorted_times = sorted(time_groups.keys())

    pending_retry = None

    for t in sorted_times:
        group = time_groups[t]

        if retry_at is not None and retry_at <= t:
            old_in_flight = in_flight
            in_flight = None
            retry_at = None
            if len(active) == 0:
                emit_fetch(t)
            else:
                owed = True

        for idx, ev in group:
            op = ev.get("op")

            if op == "start":
                eid = ev["id"]
                if eid not in active:
                    active.append(eid)
                audit.append({"time": t, "event": "modification_started", "id": eid})

            elif op == "finish":
                eid = ev["id"]
                if eid in active:
                    active.remove(eid)
                audit.append({"time": t, "event": "modification_finished", "id": eid})
                owed = True

            elif op == "refresh":
                owed = True

            elif op == "response":
                fid = ev["id"]
                dl_info = deadline_map.get(str(idx))

                if isinstance(dl_info, list):
                    reason = dl_info[0]
                    due = dl_info[1]
                    audit.append({"time": t, "event": "retry_scheduled", "due": due, "reason": reason})
                    if retry_at is None:
                        retry_at = due
                        pending_retry = reason
                    in_flight = fid
                    loading = True

                else:
                    new_items = ev.get("items", [])
                    do_commit(t, new_items, fid)
                    in_flight = None

                    if owed and len(active) == 0:
                        emit_fetch(t)
                    elif owed:
                        loading = True
                    else:
                        loading = False

        if owed and in_flight is None and retry_at is None and len(active) == 0:
            emit_fetch(t)
            owed = False

        if owed and in_flight is None and retry_at is None and len(active) > 0:
            loading = True

    placeholders = loading

    state = {
        "active": list(active),
        "owed": owed,
        "loading": loading,
        "placeholders": placeholders,
        "in_flight": in_flight,
        "retry_at": retry_at,
        "items": items,
    }

    return {
        "fetches": fetches,
        "commits": commits,
        "events": audit,
        "state": state,
    }
