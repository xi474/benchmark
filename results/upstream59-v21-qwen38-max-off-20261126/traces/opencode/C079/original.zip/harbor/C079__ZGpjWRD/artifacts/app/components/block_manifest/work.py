def compute(payload):
    file_hex = payload.get("file_hex", "")
    chunk_size = payload.get("chunk_size", 1)
    thumbnail_hex = payload.get("thumbnail_hex")

    blocks = []
    if thumbnail_hex is not None:
        blocks.append(["thumbnail", 0, thumbnail_hex])

    file_bytes = bytes.fromhex(file_hex)
    idx = 0
    for i in range(0, len(file_bytes), chunk_size):
        chunk = file_bytes[i:i + chunk_size]
        blocks.append(["file", idx, chunk.hex()])
        idx += 1

    return blocks
