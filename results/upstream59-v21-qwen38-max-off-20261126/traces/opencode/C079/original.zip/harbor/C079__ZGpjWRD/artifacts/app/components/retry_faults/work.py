def compute(payload):
    corrupt_attempts = payload.get("corrupt_attempts", {})
    max_retries = payload.get("max_retries", 0)

    result = {}
    for label, attempts in corrupt_attempts.items():
        valid = sorted(set(a for a in attempts if 0 <= a <= max_retries))
        if valid:
            result[label] = valid

    return result
