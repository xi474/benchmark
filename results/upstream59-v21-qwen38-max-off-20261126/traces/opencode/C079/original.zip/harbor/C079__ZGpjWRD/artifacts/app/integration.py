import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def combine(payload, block_manifest, retry_faults):
    session_key = bytes.fromhex(payload["session_key_hex"])
    base_nonce_int = int(payload["base_nonce_hex"], 16)
    max_retries = payload.get("max_retries", 0)

    aesgcm = AESGCM(session_key)

    blocks_out = []
    attempts_out = []
    notifications_out = []
    file_sha = hashlib.sha256()
    failed_block = None
    global_attempt = 0

    for kind, index, hex_data in block_manifest:
        label = f"{kind}:{index}"
        plaintext = bytes.fromhex(hex_data)
        aad = label.encode("utf-8")
        corrupt_set = set(retry_faults.get(label, []))
        max_attempts = 1 + max_retries
        verified = False
        success_nonce_hex = None
        success_ciphertext_hex = None

        for attempt in range(max_attempts):
            nonce_int = base_nonce_int + global_attempt
            nonce = nonce_int.to_bytes(12, "big")
            raw_ciphertext = aesgcm.encrypt(nonce, plaintext, aad)

            check_ciphertext = raw_ciphertext
            if attempt in corrupt_set:
                ct_bytes = bytearray(raw_ciphertext)
                ct_bytes[-1] ^= 0x01
                check_ciphertext = bytes(ct_bytes)

            try:
                decrypted = aesgcm.decrypt(nonce, check_ciphertext, aad)
                if decrypted == plaintext:
                    verified = True
                    success_nonce_hex = nonce.hex()
                    success_ciphertext_hex = raw_ciphertext.hex()
            except Exception:
                pass

            attempts_out.append({
                "block": label,
                "attempt": attempt,
                "verified": verified,
            })

            global_attempt += 1

            if verified:
                break

        if not verified:
            notifications_out.append({
                "block": label,
                "error": "verification_failed",
            })
            failed_block = label
            break

        blocks_out.append({
            "kind": kind,
            "index": index,
            "nonce_hex": success_nonce_hex,
            "ciphertext_hex": success_ciphertext_hex,
            "plaintext_sha256": hashlib.sha256(plaintext).hexdigest(),
        })

        if kind == "file":
            file_sha.update(plaintext)

    status = "ok" if failed_block is None else "verification_failed"

    return {
        "status": status,
        "failed_block": failed_block,
        "blocks": blocks_out,
        "attempts": attempts_out,
        "notifications": notifications_out,
        "file_sha256": file_sha.hexdigest(),
    }
