import copy


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    classes = data.get("classes")
    sample_weight = data.get("sample_weight")
    members = data.get("members")

    if classes is None or sample_weight is None or members is None:
        raise ValueError("missing required field")
    if not isinstance(classes, list) or not isinstance(sample_weight, list) or not isinstance(members, list):
        raise ValueError("invalid type")

    global_classes_set = set()
    for c in classes:
        if not isinstance(c, str) or not c.strip():
            raise ValueError("class must be non-empty string")
        if c in global_classes_set:
            raise ValueError("duplicate class")
        global_classes_set.add(c)

    n_samples = len(sample_weight)
    for sw in sample_weight:
        if isinstance(sw, bool) or not isinstance(sw, (int, float)):
            raise ValueError("sample_weight must be non-negative number")
        if sw < 0:
            raise ValueError("sample_weight must be non-negative")

    seen_ids = set()
    active_members = []
    for m in members:
        if not isinstance(m, dict):
            raise ValueError("member must be object")
        mid = m.get("id")
        active = m.get("active")
        if mid is None or active is None:
            raise ValueError("member missing id or active")
        if not isinstance(mid, str) or not mid.strip():
            raise ValueError("member id must be non-empty string")
        if not isinstance(active, bool):
            raise ValueError("active must be bool")
        if mid in seen_ids:
            raise ValueError("duplicate member id")
        seen_ids.add(mid)

        if not active:
            continue

        weight = m.get("weight")
        predictions = m.get("predictions")
        m_classes = m.get("classes")
        probabilities = m.get("probabilities")

        if weight is None or predictions is None or m_classes is None or probabilities is None:
            raise ValueError("active member missing required field")

        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            raise ValueError("weight must be non-negative number")
        if weight < 0:
            raise ValueError("weight must be non-negative")

        if not isinstance(predictions, list):
            raise ValueError("predictions must be list")
        if len(predictions) != n_samples:
            raise ValueError("predictions length mismatch")
        for p in predictions:
            if not isinstance(p, str):
                raise ValueError("prediction must be string")
            if p not in global_classes_set:
                raise ValueError(f"prediction '{p}' not in global classes")

        if not isinstance(m_classes, list):
            raise ValueError("classes must be list")
        if set(m_classes) != global_classes_set:
            raise ValueError("member classes must be permutation of global classes")
        if len(m_classes) != len(global_classes_set):
            raise ValueError("duplicate in member classes")

        if not isinstance(probabilities, list):
            raise ValueError("probabilities must be list")
        if len(probabilities) != n_samples:
            raise ValueError("probabilities row count mismatch")
        n_cls = len(m_classes)
        for row in probabilities:
            if not isinstance(row, list):
                raise ValueError("probability row must be list")
            if len(row) != n_cls:
                raise ValueError("probability column count mismatch")
            row_sum = 0.0
            for v in row:
                if isinstance(v, bool) or not isinstance(v, (int, float)):
                    raise ValueError("probability must be number")
                if v < 0:
                    raise ValueError("probability must be >= 0")
                row_sum += v
            if abs(row_sum - 1.0) > 1e-9:
                raise ValueError("probability row must sum to 1")

        active_members.append(copy.deepcopy(m))

    if not active_members:
        raise ValueError("at least one active member required")

    total_weight = sum(m["weight"] for m in active_members)
    if total_weight <= 0:
        raise ValueError("active member weight sum must be > 0")

    result_members = []
    for m in active_members:
        mc = copy.deepcopy(m)
        mc["fit_weight"] = list(sample_weight)
        result_members.append(mc)

    return {
        "name": contract["name"],
        "result": {
            "classes": list(classes),
            "sample_count": n_samples,
            "members": result_members,
        },
    }
