import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core["components"]

    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        triggered = False
        if result.get("blocked") is True:
            triggered = True
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and isinstance(val, list) and len(val) > 0:
                triggered = True
        if triggered:
            attention.append(name)

    attention = sorted(set(attention))

    core_str = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    sha = hashlib.sha256(core_str.encode("utf-8")).hexdigest()

    report = {
        "title": "\u53ef\u5173\u95ed\u6210\u5458\u7684\u786c/\u8f6f\u52a0\u6743\u6295\u7968",
        "component_count": len(components),
        "sha256": sha,
        "attention": attention,
    }

    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
