import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = (cp, c)

    built = set()
    order = []

    def resolve(name):
        if name in built:
            return
        cp, c = contract_map[name]
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                dep_name = Path(inp).stem
                if dep_name in contract_map:
                    resolve(dep_name)
        order.append((cp, c))
        built.add(name)

    for name in contract_map:
        resolve(name)

    for cp, c in order:
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {c['name']}")
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )

    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
