def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    hard_result = payloads[0]
    soft_result = payloads[1]

    if isinstance(hard_result, dict) and set(hard_result.keys()) == {"name", "result"}:
        hard_result = hard_result["result"]
    if isinstance(soft_result, dict) and set(soft_result.keys()) == {"name", "result"}:
        soft_result = soft_result["result"]

    hard_preds = hard_result["predictions"]
    soft_preds = soft_result["predictions"]

    if len(hard_preds) != len(soft_preds):
        raise ValueError("sample count mismatch")

    disagreements = []
    for i in range(len(hard_preds)):
        if hard_preds[i] != soft_preds[i]:
            disagreements.append(i)

    return {
        "name": contract["name"],
        "result": {
            "hard": hard_preds,
            "soft": soft_preds,
            "disagreements": disagreements,
        },
    }
