def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    fit_result = payloads[0]
    if isinstance(fit_result, dict) and set(fit_result.keys()) == {"name", "result"}:
        fit_result = fit_result["result"]

    global_classes = fit_result["classes"]
    members = fit_result["members"]
    sample_count = fit_result["sample_count"]

    n_cls = len(global_classes)
    class_index = {c: i for i, c in enumerate(global_classes)}

    scores = [[0.0] * n_cls for _ in range(sample_count)]

    for m in members:
        w = m["weight"]
        preds = m["predictions"]
        for s in range(sample_count):
            cls = preds[s]
            scores[s][class_index[cls]] += w

    predictions = []
    for s in range(sample_count):
        best_idx = 0
        best_val = scores[s][0]
        for i in range(1, n_cls):
            if scores[s][i] > best_val:
                best_val = scores[s][i]
                best_idx = i
        predictions.append(global_classes[best_idx])

    return {
        "name": contract["name"],
        "result": {
            "predictions": predictions,
            "scores": scores,
        },
    }
