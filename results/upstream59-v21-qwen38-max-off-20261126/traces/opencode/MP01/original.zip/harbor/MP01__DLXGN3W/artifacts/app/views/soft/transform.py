def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    fit_result = payloads[0]
    if isinstance(fit_result, dict) and set(fit_result.keys()) == {"name", "result"}:
        fit_result = fit_result["result"]

    global_classes = fit_result["classes"]
    members = fit_result["members"]
    sample_count = fit_result["sample_count"]

    n_cls = len(global_classes)
    class_index = {c: i for i, c in enumerate(global_classes)}

    total_weight = sum(m["weight"] for m in members)
    probabilities = [[0.0] * n_cls for _ in range(sample_count)]

    for m in members:
        w = m["weight"]
        m_classes = m["classes"]
        probs = m["probabilities"]
        m_class_index = {c: i for i, c in enumerate(m_classes)}
        for s in range(sample_count):
            for gc in global_classes:
                gi = class_index[gc]
                mi = m_class_index[gc]
                probabilities[s][gi] += w * probs[s][mi]

    if total_weight > 0:
        for s in range(sample_count):
            for i in range(n_cls):
                probabilities[s][i] /= total_weight

    predictions = []
    for s in range(sample_count):
        best_idx = 0
        best_val = probabilities[s][0]
        for i in range(1, n_cls):
            if probabilities[s][i] > best_val:
                best_val = probabilities[s][i]
                best_idx = i
        predictions.append(global_classes[best_idx])

    return {
        "name": contract["name"],
        "result": {
            "predictions": predictions,
            "probabilities": probabilities,
        },
    }
