import json
import math
from pathlib import Path


def _check_finite(v):
    if isinstance(v, bool):
        raise ValueError("bool is not a finite number")
    if isinstance(v, (int, float)):
        if not math.isfinite(v):
            raise ValueError("non-finite number")
        return
    if isinstance(v, list):
        for item in v:
            _check_finite(item)
    elif isinstance(v, dict):
        for item in v.values():
            _check_finite(item)


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}")
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _check_finite(data)
    return data
