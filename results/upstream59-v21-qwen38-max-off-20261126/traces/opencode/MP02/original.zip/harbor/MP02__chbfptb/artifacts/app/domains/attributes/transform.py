import json


def _deep_equal(a, b):
    if type(a) != type(b):
        return False
    if isinstance(a, dict):
        if set(a.keys()) != set(b.keys()):
            return False
        return all(_deep_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        if len(a) != len(b):
            return False
        return all(_deep_equal(x, y) for x, y in zip(a, b))
    return a == b


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]

    pieces = payload.get("pieces")
    attribute_policy = payload.get("attribute_policy")

    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if attribute_policy not in ("drop_conflicts", "first"):
        raise ValueError("invalid attribute_policy")

    merged = {}
    conflicts = set()

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be object")
        attrs = piece.get("attrs")
        if not isinstance(attrs, dict):
            raise ValueError("attrs must be object")
        for key, val in attrs.items():
            if key not in merged:
                merged[key] = val
            else:
                if not _deep_equal(merged[key], val):
                    conflicts.add(key)

    if attribute_policy == "drop_conflicts":
        final_attrs = {k: v for k, v in merged.items() if k not in conflicts}
    else:
        final_attrs = dict(merged)

    conflict_list = sorted(conflicts)

    result = {"attrs": final_attrs, "conflicts": conflict_list}
    return {"name": contract["name"], "result": result}
