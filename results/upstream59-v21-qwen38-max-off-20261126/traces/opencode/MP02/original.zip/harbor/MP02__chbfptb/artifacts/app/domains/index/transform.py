import math


def _is_finite(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return math.isfinite(v)
    return False


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]

    columns = payload.get("columns")
    pieces = payload.get("pieces")
    attribute_policy = payload.get("attribute_policy")

    if not isinstance(columns, list):
        raise ValueError("columns must be a list")
    if not isinstance(pieces, list):
        raise ValueError("pieces must be a list")
    if attribute_policy not in ("drop_conflicts", "first"):
        raise ValueError("invalid attribute_policy")

    col_names = []
    for c in columns:
        if not isinstance(c, str):
            raise ValueError("column name must be string")
        if c in col_names:
            raise ValueError("duplicate column name")
        col_names.append(c)

    seen_ids = set()
    all_coords = set()
    order = []

    for piece in pieces:
        if not isinstance(piece, dict):
            raise ValueError("piece must be object")
        pid = piece.get("id")
        if not isinstance(pid, str):
            raise ValueError("piece id must be string")
        if pid in seen_ids:
            raise ValueError("duplicate piece id")
        seen_ids.add(pid)

        coords = piece.get("coordinates")
        if not isinstance(coords, list):
            raise ValueError("coordinates must be a list")
        data = piece.get("data")
        if not isinstance(data, list):
            raise ValueError("data must be a list")

        if len(coords) != len(data):
            raise ValueError("coordinates/data length mismatch")

        for c in coords:
            if not _is_finite(c):
                raise ValueError("coordinate must be finite number")
            if c in all_coords:
                raise ValueError("overlapping coordinate")
            all_coords.add(c)

        for row_idx, row in enumerate(data):
            if not isinstance(row, list):
                raise ValueError("data row must be a list")
            if len(row) != len(col_names):
                raise ValueError("data row width mismatch")
            for v in row:
                if not _is_finite(v):
                    raise ValueError("data value must be finite number")

        for ci, coord in enumerate(coords):
            order.append({"coordinate": coord, "piece": pid, "row": ci})

    order.sort(key=lambda x: x["coordinate"])

    result = {"columns": col_names, "order": order}
    return {"name": contract["name"], "result": result}
