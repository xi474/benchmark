import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = (cp, c)

    resolved = set()
    order = []

    def resolve(name):
        if name in resolved:
            return
        _, c = contract_map[name]
        for inp in c["inputs"]:
            p = ROOT / inp
            if str(p).startswith(str(ROOT / "outputs")):
                dep_name = None
                for n2, (_, c2) in contract_map.items():
                    if c2["output"] == inp:
                        dep_name = n2
                        break
                if dep_name and dep_name in contract_map:
                    resolve(dep_name)
        order.append(name)
        resolved.add(name)

    for name in sorted(contract_map.keys()):
        resolve(name)

    for name in order:
        cp, c = contract_map[name]
        render_py = cp.parent / "render.py"
        if not render_py.is_file():
            raise FileNotFoundError(f"render.py not found for {name}")
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    integrate = ROOT / "integrate.py"
    if integrate.is_file():
        subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    final_report = ROOT / "final_report.py"
    if final_report.is_file():
        subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )


if __name__ == "__main__":
    main()
