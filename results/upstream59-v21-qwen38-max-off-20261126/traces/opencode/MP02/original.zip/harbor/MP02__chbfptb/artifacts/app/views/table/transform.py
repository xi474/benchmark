def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    raw_input = payloads[0]
    index_result = payloads[1]
    attrs_result = payloads[2]

    if isinstance(index_result, dict) and set(index_result.keys()) == {"name", "result"}:
        index_data = index_result["result"]
    else:
        index_data = index_result

    if isinstance(attrs_result, dict) and set(attrs_result.keys()) == {"name", "result"}:
        attrs_data = attrs_result["result"]
    else:
        attrs_data = attrs_result

    columns = index_data["columns"]
    order = index_data["order"]

    pieces_map = {}
    for piece in raw_input["pieces"]:
        pieces_map[piece["id"]] = piece

    coordinates = []
    data = []
    for entry in order:
        coord = entry["coordinate"]
        pid = entry["piece"]
        row_idx = entry["row"]
        coordinates.append(coord)
        data.append(pieces_map[pid]["data"][row_idx])

    result = {
        "coordinates": coordinates,
        "columns": columns,
        "data": data,
        "attrs": attrs_data["attrs"],
        "attribute_conflicts": attrs_data["conflicts"],
    }
    return {"name": contract["name"], "result": result}
