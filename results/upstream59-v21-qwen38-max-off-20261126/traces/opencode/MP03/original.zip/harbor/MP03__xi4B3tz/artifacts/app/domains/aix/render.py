import json
import sys
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    return result


if __name__ == '__main__':
    here = Path(__file__).resolve().parent
    cp = here / 'contract.json'
    root = Path.cwd()
    result = build_component(root, cp)
    contract = load_payload(cp)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )
