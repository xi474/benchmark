def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data.keys()) == {'name', 'result'}:
        data = data['result']
    aix_str = data['aix']
    records = []
    current_mount = None
    current_attrs = {}
    known_keys = {'dev', 'vfs', 'options'}

    def flush():
        nonlocal current_mount, current_attrs
        if current_mount is not None:
            if 'dev' not in current_attrs:
                raise ValueError(f"missing dev for mount {current_mount}")
            device = current_attrs['dev']
            fstype = current_attrs.get('vfs', 'jfs2')
            options_raw = current_attrs.get('options', 'rw')
            opts = sorted(set(options_raw.split(',')))
            options = ','.join(opts)
            records.append({
                'device': device,
                'mount': current_mount,
                'fstype': fstype,
                'options': options,
            })
            current_mount = None
            current_attrs = {}

    for line in aix_str.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        if not line[0:1].isspace() and stripped.endswith(':'):
            flush()
            current_mount = stripped[:-1]
            current_attrs = {}
        elif '=' in stripped:
            if current_mount is None:
                raise ValueError("attribute without section header")
            idx = stripped.index('=')
            key = stripped[:idx].strip()
            val = stripped[idx+1:].strip()
            if key not in known_keys:
                raise ValueError(f"unknown key: {key}")
            if key in current_attrs:
                raise ValueError(f"duplicate key: {key}")
            current_attrs[key] = val
        else:
            if current_mount is None:
                raise ValueError("line outside section")
            raise ValueError(f"invalid line in section: {stripped}")
    flush()
    return {'name': contract['name'], 'result': {'records': records}}
