def _unescape(s):
    s = s.replace('\\040', ' ')
    s = s.replace('\\011', '\t')
    s = s.replace('\\134', '\\')
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data.keys()) == {'name', 'result'}:
        data = data['result']
    fstab_str = data['fstab']
    records = []
    for line in fstab_str.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        if len(parts) < 4 or len(parts) > 6:
            raise ValueError(f"invalid fstab line: {line}")
        device = _unescape(parts[0])
        mount = _unescape(parts[1])
        fstype = _unescape(parts[2])
        options_raw = _unescape(parts[3])
        opts = sorted(set(options_raw.split(',')))
        options = ','.join(opts)
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': options,
        })
    return {'name': contract['name'], 'result': {'records': records}}
