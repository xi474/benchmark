def _unescape(s):
    s = s.replace('\\040', ' ')
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if isinstance(data, dict) and set(data.keys()) == {'name', 'result'}:
        data = data['result']
    mount_str = data['mount']
    records = []
    for line in mount_str.splitlines():
        line = line.strip()
        if not line:
            continue
        idx_on = line.find(' on ')
        if idx_on < 0:
            raise ValueError(f"invalid mount line: {line}")
        device_raw = line[:idx_on]
        rest = line[idx_on+4:]
        idx_type = rest.find(' type ')
        if idx_type < 0:
            raise ValueError(f"invalid mount line: {line}")
        mount_raw = rest[:idx_type]
        rest2 = rest[idx_type+6:]
        idx_paren = rest2.find(' (')
        if idx_paren < 0:
            raise ValueError(f"invalid mount line: {line}")
        fstype = rest2[:idx_paren]
        opts_part = rest2[idx_paren+2:]
        if not opts_part.endswith(')'):
            raise ValueError(f"invalid mount line: {line}")
        options_raw = opts_part[:-1]
        if not options_raw:
            raise ValueError(f"empty options in mount line: {line}")
        device = _unescape(device_raw)
        mount = _unescape(mount_raw)
        opts = sorted(set(options_raw.split(',')))
        options = ','.join(opts)
        records.append({
            'device': device,
            'mount': mount,
            'fstype': fstype,
            'options': options,
        })
    return {'name': contract['name'], 'result': {'records': records}}
