import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    if not contracts:
        raise ValueError('no contracts found')
    graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        deps = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                    if other_c['output'] == inp:
                        deps.add(other_c['name'])
        graph[c['name']] = {'path': cp, 'deps': deps}
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"dependency cycle involving {name}")
        visiting.add(name)
        for dep in graph[name]['deps']:
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(graph.keys()):
        visit(name)
    for name in ordered:
        cp = graph[name]['path']
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"component {name} failed")
    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=30)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=30)


if __name__ == '__main__':
    main()
