def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    sources = ['fstab', 'aix', 'mount']
    all_records = []
    for i, src in enumerate(sources):
        data = payloads[i]
        if isinstance(data, dict) and set(data.keys()) == {'name', 'result'}:
            data = data['result']
        for rec in data['records']:
            all_records.append({
                'device': rec['device'],
                'mount': rec['mount'],
                'fstype': rec['fstype'],
                'options': rec['options'],
                'source': src,
            })
    seen = {}
    for rec in all_records:
        m = rec['mount']
        if m not in seen:
            seen[m] = rec
    winners = sorted(seen.values(), key=lambda r: r['mount'])
    by_mount = {}
    for rec in all_records:
        by_mount.setdefault(rec['mount'], []).append(rec)
    conflicts = []
    for m in sorted(by_mount.keys()):
        entries = by_mount[m]
        ref = entries[0]
        has_conflict = False
        for e in entries[1:]:
            if (e['device'] != ref['device'] or
                    e['fstype'] != ref['fstype'] or
                    e['options'] != ref['options']):
                has_conflict = True
                break
        if has_conflict:
            evidence = []
            for e in entries:
                evidence.append({
                    'device': e['device'],
                    'mount': e['mount'],
                    'fstype': e['fstype'],
                    'options': e['options'],
                    'source': e['source'],
                })
            conflicts.append({'mount': m, 'evidence': evidence})
    return {
        'name': contract['name'],
        'result': {
            'records': winners,
            'conflicts': conflicts,
        },
    }
