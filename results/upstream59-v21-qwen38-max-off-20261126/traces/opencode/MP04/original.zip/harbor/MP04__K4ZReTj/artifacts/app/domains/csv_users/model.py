import json
from pathlib import Path


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    return data
