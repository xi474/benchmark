import csv
import io
import re


def _parse_date(s):
    if not isinstance(s, str):
        raise ValueError(f"joined must be string, got {type(s).__name__}")
    s = s.strip()
    if not s:
        return None
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    raise ValueError(f"invalid date format: {s}")


def _normalize_id(raw_id):
    if isinstance(raw_id, bool):
        raise ValueError("id cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        stripped = raw_id.strip()
        if not stripped:
            raise ValueError("id cannot be empty after strip")
        return stripped
    raise ValueError(f"id must be str or int, got {type(raw_id).__name__}")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if 'csv_text' not in payload:
        raise ValueError("missing csv_text field")
    csv_text = payload['csv_text']
    if not isinstance(csv_text, str):
        raise ValueError("csv_text must be string")

    if not csv_text.strip():
        return {"name": contract["name"], "result": {"records": []}}

    reader = csv.DictReader(io.StringIO(csv_text))
    headers = reader.fieldnames
    if headers is None:
        return {"name": contract["name"], "result": {"records": []}}

    has_id = 'id' in headers
    has_user_id = 'user_id' in headers
    if not has_id and not has_user_id:
        raise ValueError("CSV must have id or user_id column")

    users = {}
    for row in reader:
        raw_id = row.get('user_id') if has_user_id else row.get('id')
        if raw_id is None or (isinstance(raw_id, str) and raw_id.strip() == ''):
            continue
        uid = _normalize_id(raw_id)

        name_val = None
        if 'full_name' in row and row['full_name'] != '':
            name_val = row['full_name']
        elif 'name' in row and row['name'] != '':
            name_val = row['name']

        email_val = None
        if 'mail' in row and row['mail'] != '':
            email_val = row['mail']
        elif 'email' in row and row['email'] != '':
            email_val = row['email']

        joined_val = None
        if 'joined_at' in row and row['joined_at'] != '':
            joined_val = row['joined_at']
        elif 'joined' in row and row['joined'] != '':
            joined_val = row['joined']

        entry = users.setdefault(uid, {})
        if name_val is not None:
            entry['name'] = name_val
        if email_val is not None:
            entry['email'] = email_val
        if joined_val is not None:
            parsed = _parse_date(joined_val)
            if parsed is not None:
                entry['joined'] = parsed

    result_records = []
    for uid in sorted(users.keys()):
        rec = {'id': uid}
        u = users[uid]
        if 'name' in u:
            rec['name'] = u['name']
        if 'email' in u:
            rec['email'] = u['email']
        if 'joined' in u:
            rec['joined'] = u['joined']
        result_records.append(rec)

    return {"name": contract["name"], "result": {"records": result_records}}
