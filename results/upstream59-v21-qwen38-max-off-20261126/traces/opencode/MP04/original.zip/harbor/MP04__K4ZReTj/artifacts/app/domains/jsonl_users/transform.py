import json
import re


def _parse_date(s):
    if not isinstance(s, str):
        raise ValueError(f"joined must be string, got {type(s).__name__}")
    s = s.strip()
    if not s:
        return None
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    m = re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{y:04d}-{mo:02d}-{d:02d}"
        raise ValueError(f"invalid date: {s}")
    raise ValueError(f"invalid date format: {s}")


def _normalize_id(raw_id):
    if isinstance(raw_id, bool):
        raise ValueError("id cannot be bool")
    if isinstance(raw_id, int):
        return str(raw_id)
    if isinstance(raw_id, str):
        stripped = raw_id.strip()
        if not stripped:
            raise ValueError("id cannot be empty after strip")
        return stripped
    raise ValueError(f"id must be str or int, got {type(raw_id).__name__}")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    if 'jsonl_text' not in payload:
        raise ValueError("missing jsonl_text field")
    jsonl_text = payload['jsonl_text']
    if not isinstance(jsonl_text, str):
        raise ValueError("jsonl_text must be string")

    users = {}
    for line in jsonl_text.split('\n'):
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as e:
            raise ValueError(f"bad JSONL line: {e}") from e
        if not isinstance(obj, dict):
            raise ValueError("each JSONL line must be object")

        if 'id' not in obj and 'user_id' not in obj:
            raise ValueError("record missing id/user_id")
        raw_id = obj.get('user_id', obj.get('id'))
        uid = _normalize_id(raw_id)

        name_val = None
        if 'name' in obj:
            name_val = obj['name']
        if 'full_name' in obj:
            name_val = obj['full_name']

        email_val = None
        if 'email' in obj:
            email_val = obj['email']
        if 'mail' in obj:
            email_val = obj['mail']

        joined_val = None
        if 'joined' in obj:
            joined_val = obj['joined']
        if 'joined_at' in obj:
            joined_val = obj['joined_at']

        entry = users.setdefault(uid, {})
        if name_val is not None:
            entry['name'] = name_val
        if email_val is not None:
            entry['email'] = email_val
        if joined_val is not None:
            parsed = _parse_date(joined_val)
            if parsed is not None:
                entry['joined'] = parsed

    result_records = []
    for uid in sorted(users.keys()):
        rec = {'id': uid}
        u = users[uid]
        if 'name' in u:
            rec['name'] = u['name']
        if 'email' in u:
            rec['email'] = u['email']
        if 'joined' in u:
            rec['joined'] = u['joined']
        result_records.append(rec)

    return {"name": contract["name"], "result": {"records": result_records}}
