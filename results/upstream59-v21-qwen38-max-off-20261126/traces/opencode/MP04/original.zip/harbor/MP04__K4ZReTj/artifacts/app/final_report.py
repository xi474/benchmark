import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core.get('components', {})
    component_count = len(components)

    core_json = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    sha256 = hashlib.sha256(core_json.encode('utf-8')).hexdigest()

    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        flagged = False
        if result.get('blocked') is True:
            flagged = True
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                flagged = True
                break
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            if key in result:
                val = result[key]
                if isinstance(val, list) and len(val) > 0:
                    flagged = True
                    break
                elif isinstance(val, dict) and len(val) > 0:
                    flagged = True
                    break
                elif isinstance(val, str) and val:
                    flagged = True
                    break
        if flagged:
            attention.append(name)

    attention = sorted(set(attention))

    report = {
        "title": "多格式用户合并与完整冲突报告",
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
