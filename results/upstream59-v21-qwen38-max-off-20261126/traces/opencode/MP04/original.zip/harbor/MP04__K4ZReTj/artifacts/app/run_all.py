import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    domain_contracts = []
    view_contracts = []
    for cp in contracts:
        rel = cp.relative_to(ROOT)
        if rel.parts[0] == 'domains':
            domain_contracts.append(cp)
        elif rel.parts[0] == 'views':
            view_contracts.append(cp)

    for cp in domain_contracts:
        render_py = cp.with_name('render.py')
        subprocess.run([sys.executable, str(render_py)], cwd=ROOT, check=True, timeout=60)

    for cp in view_contracts:
        render_py = cp.with_name('render.py')
        subprocess.run([sys.executable, str(render_py)], cwd=ROOT, check=True, timeout=60)

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=60)

    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=60)


if __name__ == '__main__':
    main()
