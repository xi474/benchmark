def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    sources = ['json', 'csv', 'jsonl']
    source_records = {}
    for i, src in enumerate(sources):
        payload = payloads[i]
        if not isinstance(payload, dict) or 'result' not in payload:
            raise ValueError(f"invalid {src} input: missing result")
        res = payload['result']
        if not isinstance(res, dict) or 'records' not in res:
            raise ValueError(f"invalid {src} input: missing records")
        records = res['records']
        if not isinstance(records, list):
            raise ValueError(f"invalid {src} input: records must be list")
        source_records[src] = records

    all_users = {}
    field_sources = {}

    for src in sources:
        for rec in source_records[src]:
            uid = rec['id']
            if uid not in all_users:
                all_users[uid] = {}
                field_sources[uid] = {}
            for field in ('name', 'email', 'joined'):
                if field in rec:
                    val = rec[field]
                    if field not in field_sources[uid]:
                        all_users[uid][field] = val
                        field_sources[uid][field] = [(src, val)]
                    else:
                        existing_vals = field_sources[uid][field]
                        found = False
                        for s, v in existing_vals:
                            if s == src:
                                found = True
                                break
                        if not found:
                            existing_vals.append((src, val))

    users_list = []
    conflicts_list = []

    for uid in sorted(all_users.keys()):
        user = {'id': uid}
        u = all_users[uid]
        if 'name' in u:
            user['name'] = u['name']
        if 'email' in u:
            user['email'] = u['email']
        if 'joined' in u:
            user['joined'] = u['joined']
        users_list.append(user)

        fs = field_sources[uid]
        for field in sorted(fs.keys()):
            vals = fs[field]
            unique_values = {}
            for src, val in vals:
                if val not in unique_values:
                    unique_values[val] = []
                unique_values[val].append(src)
            if len(unique_values) > 1:
                conflict_entry = {
                    'id': uid,
                    'field': field,
                    'values': [{'source': src, 'value': val} for src, val in vals]
                }
                conflicts_list.append(conflict_entry)

    return {
        "name": contract["name"],
        "result": {
            "users": users_list,
            "conflicts": conflicts_list
        }
    }
