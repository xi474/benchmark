def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    contacts = data['contacts']
    self_id = data['self_id']
    window = data['window']
    events = data['events']

    w_start, w_end = window[0], window[1]

    contact_map = {}
    for c in contacts:
        cid = c['id']
        age = c['age']
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError("age must be non-negative integer")
        contact_map[cid] = age

    minutes = {}
    for cid in contact_map:
        if cid != self_id:
            minutes[cid] = 0

    for ev in events:
        attendees = ev['attendees']
        ev_start = ev['start']
        ev_end = ev['end']

        unique_attendees = set(attendees)
        if self_id not in unique_attendees:
            continue

        clip_start = max(ev_start, w_start)
        clip_end = min(ev_end, w_end)
        duration = max(0, clip_end - clip_start)

        for a in unique_attendees:
            if a == self_id:
                continue
            if a not in contact_map:
                raise ValueError(f"attendee {a} not in contacts")
            minutes[a] += duration

    return {"name": contract["name"], "result": {"minutes": minutes}}
