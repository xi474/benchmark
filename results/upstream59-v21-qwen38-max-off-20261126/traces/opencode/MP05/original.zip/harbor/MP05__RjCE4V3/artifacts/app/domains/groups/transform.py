def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    contacts = data['contacts']
    self_id = data['self_id']
    keyword = data['keyword']
    groups = data['groups']

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")

    contact_map = {}
    for c in contacts:
        cid = c['id']
        age = c['age']
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError("age must be non-negative integer")
        contact_map[cid] = age

    candidates = set()
    kw_lower = keyword.casefold()
    for g in groups:
        members = g['members']
        messages = g['messages']
        match = False
        for msg in messages:
            if not isinstance(msg, str):
                raise ValueError("message must be string")
            if kw_lower in msg.casefold():
                match = True
                break
        if match:
            for m in members:
                if m not in contact_map:
                    raise ValueError(f"member {m} not in contacts")
                if m != self_id:
                    candidates.add(m)

    return {"name": contract["name"], "result": {"ids": sorted(candidates)}}
