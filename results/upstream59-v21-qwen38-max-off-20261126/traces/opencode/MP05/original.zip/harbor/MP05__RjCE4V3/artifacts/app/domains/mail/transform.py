def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    contacts = data['contacts']
    self_id = data['self_id']
    keyword = data['keyword']
    emails = data['emails']

    if not isinstance(keyword, str) or not keyword.strip():
        raise ValueError("keyword must be non-empty string")

    contact_map = {}
    for c in contacts:
        cid = c['id']
        age = c['age']
        if not isinstance(age, int) or isinstance(age, bool) or age < 0:
            raise ValueError("age must be non-negative integer")
        contact_map[cid] = age

    candidates = set()
    kw_lower = keyword.casefold()
    for e in emails:
        sender = e['sender']
        subject = e['subject']
        if sender not in contact_map:
            raise ValueError(f"sender {sender} not in contacts")
        if not isinstance(subject, str):
            raise ValueError("subject must be string")
        if kw_lower in subject.casefold():
            if sender != self_id:
                candidates.add(sender)

    return {"name": contract["name"], "result": {"ids": sorted(candidates)}}
