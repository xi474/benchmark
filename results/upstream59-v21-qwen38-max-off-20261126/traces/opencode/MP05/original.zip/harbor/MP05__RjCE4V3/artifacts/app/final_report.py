import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    title = '跨应用候选并集与相处时长排名'
    component_count = len(core['components'])

    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(serialized).hexdigest()

    attention = []
    for name, result in core['components'].items():
        flagged = False
        if isinstance(result, dict):
            if result.get('blocked') is True:
                flagged = True
            for key in ('complete', 'checkout', 'committed', 'ok'):
                if key in result and result[key] is False:
                    flagged = True
            for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
                val = result.get(key)
                if val is not None and val != [] and val != {} and val != '' and val != 0 and val is not False:
                    if isinstance(val, (list, dict)) and len(val) > 0:
                        flagged = True
                    elif isinstance(val, str) and len(val) > 0:
                        flagged = True
                    elif isinstance(val, (int, float)) and not isinstance(val, bool) and val != 0:
                        flagged = True
        if flagged:
            attention.append(name)

    attention.sort()

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out_path = ROOT / 'outputs' / 'final_report.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
