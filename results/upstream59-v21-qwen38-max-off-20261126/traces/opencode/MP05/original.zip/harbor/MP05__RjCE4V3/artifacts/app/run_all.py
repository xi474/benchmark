import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    components = [
        ROOT / 'domains' / 'groups',
        ROOT / 'domains' / 'mail',
        ROOT / 'domains' / 'calendar',
        ROOT / 'views' / 'ranking',
    ]
    for comp_dir in components:
        render_py = comp_dir / 'render.py'
        if not render_py.is_file():
            print(f"Missing render.py in {comp_dir}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"Component {comp_dir.name} failed", file=sys.stderr)
            sys.exit(result.returncode)

    integrate_result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        timeout=60
    )
    if integrate_result.returncode != 0:
        print("integrate.py failed", file=sys.stderr)
        sys.exit(integrate_result.returncode)

    report_result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        timeout=60
    )
    if report_result.returncode != 0:
        print("final_report.py failed", file=sys.stderr)
        sys.exit(report_result.returncode)


if __name__ == '__main__':
    main()
