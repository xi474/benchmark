def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case_data = payloads[0]
    groups_result = payloads[1]
    mail_result = payloads[2]
    calendar_result = payloads[3]

    def _unwrap(obj):
        if isinstance(obj, dict) and 'name' in obj and 'result' in obj:
            return obj['result']
        return obj

    groups_r = _unwrap(groups_result)
    mail_r = _unwrap(mail_result)
    calendar_r = _unwrap(calendar_result)

    contacts = case_data['contacts']
    contact_map = {}
    for c in contacts:
        contact_map[c['id']] = c['age']

    group_ids = set(groups_r.get('ids', []))
    mail_ids = set(mail_r.get('ids', []))
    cal_minutes = calendar_r.get('minutes', {})

    union_ids = group_ids | mail_ids | set(cal_minutes.keys())

    ranking = []
    for cid in union_ids:
        mins = cal_minutes.get(cid, 0)
        age = contact_map[cid]
        ranking.append({"id": cid, "minutes": mins, "age": age})

    ranking.sort(key=lambda x: (-x['minutes'], -x['age'], x['id']))

    winner = ranking[0]['id'] if ranking else None

    return {"name": contract["name"], "result": {"ranking": ranking, "winner": winner}}
