def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    events = case['events']
    day = case['day']
    if not isinstance(day, int) or isinstance(day, bool) or day < 0:
        raise ValueError("invalid day")
    lo = day * 1440
    hi = lo + 720
    cancelled_ids = []
    snapshots = {}
    remaining = {}
    for ev in events:
        eid = ev['id']
        start = ev['start']
        end = ev['end']
        social = ev['social']
        was_cancelled = ev['cancelled']
        if (isinstance(start, int) and not isinstance(start, bool)
                and isinstance(end, int) and not isinstance(end, bool)
                and isinstance(social, bool) and isinstance(was_cancelled, bool)
                and lo <= start < hi
                and social
                and not was_cancelled
                and end > start):
            cancelled_ids.append(eid)
            snapshots[eid] = ev
        else:
            remaining[eid] = ev
    cancelled_ids.sort()
    return {
        'name': contract['name'],
        'result': {
            'cancelled': cancelled_ids,
            'snapshots': snapshots,
            'remaining': remaining,
        }
    }
