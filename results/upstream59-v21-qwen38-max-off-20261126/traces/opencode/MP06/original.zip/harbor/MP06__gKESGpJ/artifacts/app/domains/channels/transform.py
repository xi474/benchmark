def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    contacts = case['contacts']
    seen = set()
    result_contacts = {}
    for c in contacts:
        cid = c['id']
        if cid in seen:
            raise ValueError(f"duplicate contact id: {cid}")
        seen.add(cid)
        email = c['email']
        message = c['message']
        chat = c['chat']
        if email is not None and (not isinstance(email, str) or not email.strip()):
            raise ValueError(f"invalid email for {cid}")
        if message is not None and (not isinstance(message, str) or not message.strip()):
            raise ValueError(f"invalid message for {cid}")
        if chat is not None and (not isinstance(chat, str) or not chat.strip()):
            raise ValueError(f"invalid chat for {cid}")
        primary = None
        address = None
        via = None
        if message is not None:
            primary = message
            address = message
            via = 'message'
        elif chat is not None:
            primary = chat
            address = chat
            via = 'chat'
        result_contacts[cid] = {
            'email': email,
            'primary': primary,
            'address': address,
            'via': via,
        }
    return {
        'name': contract['name'],
        'result': {
            'contacts': result_contacts,
        }
    }
