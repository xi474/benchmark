import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        raise ValueError("no contracts found")
    graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        deps = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                    if other_c['output'] == inp:
                        deps.add(other_c['name'])
        graph[name] = {'path': cp, 'deps': deps}
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            raise ValueError(f"cycle detected involving {name}")
        if name in visited:
            return
        visiting.add(name)
        for dep in sorted(graph[name]['deps']):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(graph.keys()):
        visit(name)
    for name in ordered:
        cp = graph[name]['path']
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"component {name} failed with code {result.returncode}")
    integrate_py = ROOT / 'integrate.py'
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"integrate failed with code {result.returncode}")
    final_report_py = ROOT / 'final_report.py'
    if final_report_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"final_report failed with code {result.returncode}")


if __name__ == '__main__':
    main()
