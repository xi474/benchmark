def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    cal = payloads[0]
    chan = payloads[1]
    if isinstance(cal, dict) and set(cal.keys()) == {'name', 'result'}:
        cal_result = cal['result']
    else:
        cal_result = cal
    if isinstance(chan, dict) and set(chan.keys()) == {'name', 'result'}:
        chan_result = chan['result']
    else:
        chan_result = chan
    cancelled_ids = sorted(cal_result['cancelled'])
    snapshots = cal_result['snapshots']
    contacts_dir = chan_result['contacts']
    attendee_ids = set()
    for eid in cancelled_ids:
        ev = snapshots[eid]
        for aid in ev['attendees']:
            attendee_ids.add(aid)
    for aid in attendee_ids:
        if aid not in contacts_dir:
            raise ValueError(f"unknown contact id: {aid}")
    outbox = []
    unreachable = []
    group_members = []
    for aid in sorted(attendee_ids):
        info = contacts_dir[aid]
        email = info['email']
        via = info.get('via')
        has_email = email is not None
        if has_email:
            outbox.append({
                'channel': 'email',
                'to': aid,
                'recipients': [aid],
                'requires': cancelled_ids,
            })
        if via == 'message':
            group_members.append(aid)
        elif via == 'chat':
            outbox.append({
                'channel': 'chat',
                'to': aid,
                'recipients': [aid],
                'requires': cancelled_ids,
            })
        else:
            unreachable.append(aid)
    group_members.sort()
    if group_members:
        group = {
            'id': 'cancelled-social',
            'members': group_members,
            'requires': cancelled_ids,
        }
        outbox.append({
            'channel': 'message_group',
            'to': 'cancelled-social',
            'recipients': group_members,
            'requires': cancelled_ids,
        })
    else:
        group = None
    outbox.sort(key=lambda x: (x['channel'], x['to']))
    unreachable.sort()
    return {
        'name': contract['name'],
        'result': {
            'outbox': outbox,
            'unreachable': unreachable,
            'group': group,
        }
    }
