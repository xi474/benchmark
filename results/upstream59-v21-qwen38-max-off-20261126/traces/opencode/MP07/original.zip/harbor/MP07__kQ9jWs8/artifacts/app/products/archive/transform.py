def _extract(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    case = payloads[0]
    receipts_data = _extract(payloads[1])
    cleanup_data = _extract(payloads[2])

    files = case["files"]
    attachments = case["attachments"]
    archive_prefix = case["archive_prefix"]

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be list")
    if not isinstance(archive_prefix, str):
        raise ValueError("archive_prefix must be string")

    file_map = {}
    for f in files:
        path = f["path"]
        hex_data = f["hex"]
        file_map[path] = hex_data

    receipts_list = receipts_data["receipts"]
    all_ok = all(r["ok"] for r in receipts_list)
    has_recipients = len(receipts_list) > 0

    delete_list = cleanup_data["delete"]

    blocked = not (all_ok and has_recipients)

    moves = []
    if not blocked:
        unique_attachments = sorted(set(attachments))
        targets_seen = set()
        for att_path in unique_attachments:
            to_path = archive_prefix + "/" + att_path
            if to_path in targets_seen:
                raise ValueError(f"duplicate target {to_path}")
            targets_seen.add(to_path)
            if to_path in file_map:
                raise ValueError(f"target {to_path} already exists")
            moves.append({"from": att_path, "to": to_path})

    move_sources = set(m["from"] for m in moves)
    delete_set = set(delete_list)
    overlap = move_sources & delete_set
    if overlap:
        raise ValueError(f"cleanup and move source overlap: {overlap}")

    moves.sort(key=lambda m: m["from"])

    remaining_files = {}
    for f in files:
        remaining_files[f["path"]] = f["hex"]

    for d in delete_list:
        if d in remaining_files:
            del remaining_files[d]

    for m in moves:
        src = m["from"]
        dst = m["to"]
        if src in remaining_files:
            hex_val = remaining_files.pop(src)
            remaining_files[dst] = hex_val

    files_result = []
    for p in sorted(remaining_files.keys()):
        files_result.append({"path": p, "hex": remaining_files[p]})

    deleted_sorted = sorted(delete_list)

    return {
        "name": contract["name"],
        "result": {
            "moves": moves,
            "deleted": deleted_sorted,
            "blocked": blocked,
            "files": files_result,
        },
    }
