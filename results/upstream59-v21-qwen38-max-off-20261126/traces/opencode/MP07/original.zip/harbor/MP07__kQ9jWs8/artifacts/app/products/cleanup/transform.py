def transform(payloads, contract):
    case = payloads[0]

    files = case["files"]
    cleanup_prefix = case["cleanup_prefix"]

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(cleanup_prefix, str):
        raise ValueError("cleanup_prefix must be string")

    prefix_parts = cleanup_prefix.split("/")
    delete = []
    for f in files:
        path = f["path"]
        if not isinstance(path, str):
            raise ValueError("file path must be string")
        file_parts = path.split("/")
        if len(file_parts) <= len(prefix_parts):
            continue
        if file_parts[:len(prefix_parts)] == prefix_parts:
            if path.endswith(".tmp"):
                delete.append(path)

    delete.sort()

    return {
        "name": contract["name"],
        "result": {
            "delete": delete,
        },
    }
