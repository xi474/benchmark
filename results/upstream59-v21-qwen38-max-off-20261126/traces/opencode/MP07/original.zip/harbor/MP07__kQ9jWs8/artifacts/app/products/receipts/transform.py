import hashlib


def transform(payloads, contract):
    case = payloads[0]

    files = case["files"]
    attachments = case["attachments"]
    recipients = case["recipients"]
    send_ok = case["send_ok"]

    if not isinstance(files, list):
        raise ValueError("files must be list")
    if not isinstance(attachments, list):
        raise ValueError("attachments must be list")
    if not isinstance(recipients, list):
        raise ValueError("recipients must be list")
    if not isinstance(send_ok, dict):
        raise ValueError("send_ok must be dict")

    file_map = {}
    for f in files:
        path = f["path"]
        hex_data = f["hex"]
        if not isinstance(path, str) or not isinstance(hex_data, str):
            raise ValueError("file entry must have string path and hex")
        file_map[path] = hex_data

    unique_attachments = sorted(set(attachments))
    for a in unique_attachments:
        if a not in file_map:
            raise ValueError(f"attachment {a} not found in files")

    att_result = []
    for a in unique_attachments:
        raw = bytes.fromhex(file_map[a])
        sha = hashlib.sha256(raw).hexdigest()
        att_result.append({"path": a, "sha256": sha})

    seen_recipients = set()
    for r in recipients:
        if not isinstance(r, str) or not r.strip():
            raise ValueError("recipient must be non-empty string")
        if r in seen_recipients:
            raise ValueError(f"duplicate recipient {r}")
        seen_recipients.add(r)

    receipts = []
    for r in sorted(recipients):
        if r not in send_ok:
            raise ValueError(f"missing send_ok for {r}")
        ok = send_ok[r]
        if not isinstance(ok, bool):
            raise ValueError(f"send_ok[{r}] must be bool")
        receipts.append({"recipient": r, "ok": ok})

    return {
        "name": contract["name"],
        "result": {
            "attachments": att_result,
            "receipts": receipts,
        },
    }
