def transform(payloads, contract):
    case = payloads[0]
    files = case['files']
    photos = case['photos']
    festivals = case['festivals']
    destination = case['destination']
    recipient = case['recipient']

    if not isinstance(festivals, list):
        raise ValueError("festivals must be a list")
    for f in festivals:
        if not isinstance(f, str) or not f.strip():
            raise ValueError("festival must be non-empty string")
    if len(set(festivals)) != len(festivals):
        raise ValueError("duplicate festivals")

    if not isinstance(destination, str) or not destination.strip():
        raise ValueError("destination must be non-empty string")
    _check_safe_path(destination)

    if not isinstance(recipient, str) or not recipient.strip():
        raise ValueError("recipient must be non-empty string")

    file_paths = set()
    for fi in files:
        if not isinstance(fi.get('path'), str) or not fi['path'].strip():
            raise ValueError("file path must be non-empty string")
        if not isinstance(fi.get('hex'), str):
            raise ValueError("file hex must be string")
        if fi['path'] in file_paths:
            raise ValueError("duplicate file path")
        file_paths.add(fi['path'])

    photo_paths = set()
    for ph in photos:
        if not isinstance(ph.get('path'), str) or not ph['path'].strip():
            raise ValueError("photo path must be non-empty string")
        if not isinstance(ph.get('festival'), str) or not ph['festival'].strip():
            raise ValueError("photo festival must be non-empty string")
        if ph['path'] not in file_paths:
            raise ValueError("photo path not in files")
        if ph['path'] in photo_paths:
            raise ValueError("duplicate photo path")
        photo_paths.add(ph['path'])

    festival_set = set(festivals)
    selected = []
    for ph in photos:
        if ph['festival'] in festival_set:
            selected.append({'path': ph['path'], 'festival': ph['festival']})
    selected.sort(key=lambda x: (x['festival'], x['path']))

    used_festivals = set(s['festival'] for s in selected)
    missing = sorted(f for f in festivals if f not in used_festivals)

    return {
        'name': contract['name'],
        'result': {
            'selected': selected,
            'missing': missing
        }
    }


def _check_safe_path(p):
    if not p or p.startswith('/') or '\\' in p or ':' in p:
        raise ValueError("unsafe path")
    parts = p.split('/')
    for part in parts:
        if not part or part == '.' or part == '..':
            raise ValueError("unsafe path segment")
