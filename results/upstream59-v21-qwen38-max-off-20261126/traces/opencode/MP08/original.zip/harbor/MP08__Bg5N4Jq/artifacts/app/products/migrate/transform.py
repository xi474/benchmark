def transform(payloads, contract):
    case = payloads[0]
    classify_result = payloads[1]['result']

    files = case['files']
    destination = case['destination']
    selected = classify_result['selected']

    file_map = {}
    for fi in files:
        file_map[fi['path']] = fi['hex']

    moves = []
    new_files = []
    target_paths = set()

    for sel in selected:
        src = sel['path']
        dst = destination + '/' + src
        if dst in target_paths:
            raise ValueError(f"duplicate target path: {dst}")
        target_paths.add(dst)
        hex_val = file_map[src]
        moves.append({'from': src, 'to': dst, 'festival': sel['festival']})
        new_files.append({'path': dst, 'hex': hex_val})

    moves.sort(key=lambda x: (x['from'], x['to']))
    new_files.sort(key=lambda x: x['path'])

    return {
        'name': contract['name'],
        'result': {
            'moves': moves,
            'files': new_files
        }
    }
