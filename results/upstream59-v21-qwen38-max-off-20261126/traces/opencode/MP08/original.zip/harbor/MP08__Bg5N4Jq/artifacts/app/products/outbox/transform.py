def transform(payloads, contract):
    case = payloads[0]
    classify_result = payloads[1]['result']
    migrate_result = payloads[2]['result']

    recipient = case['recipient']
    missing = classify_result['missing']
    migrated_files = migrate_result['files']

    attachments = sorted([f['path'] for f in migrated_files])

    if not missing:
        message = "Photos ready"
    else:
        message = "Missing: " + ", ".join(missing)

    return {
        'name': contract['name'],
        'result': {
            'to': recipient,
            'attachments': attachments,
            'missing': missing,
            'message': message
        }
    }
