import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        c = json.loads(cp.read_text(encoding='utf-8'))
        contracts.append((cp, c))

    if not contracts:
        raise ValueError("no contracts found")

    name_to_cp = {c['name']: cp for cp, c in contracts}
    name_to_c = {c['name']: c for cp, c in contracts}

    deps = {}
    for name, c in name_to_c.items():
        d = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                dep_name = Path(inp).stem
                if dep_name in name_to_c:
                    d.add(dep_name)
        deps[name] = d

    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        visiting.add(name)
        for dep in sorted(deps.get(name, set())):
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(name_to_c.keys()):
        visit(name)

    for name in ordered:
        cp = name_to_cp[name]
        render_py = cp.with_name('render.py')
        if not render_py.exists():
            raise ValueError(f"render.py not found for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            raise RuntimeError(f"component {name} failed with exit code {result.returncode}")

    subprocess.run([sys.executable, str(ROOT / 'integrate.py')], cwd=ROOT, check=True, timeout=30)
    subprocess.run([sys.executable, str(ROOT / 'final_report.py')], cwd=ROOT, check=True, timeout=30)


if __name__ == '__main__':
    main()
