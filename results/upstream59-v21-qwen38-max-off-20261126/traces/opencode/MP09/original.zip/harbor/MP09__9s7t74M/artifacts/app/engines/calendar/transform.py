def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    now = case["now"]
    windows = case["windows"]
    busy = case.get("busy", [])
    duration = case["duration"]
    gap = case["gap"]

    if not isinstance(now, int) or isinstance(now, bool):
        raise ValueError("now must be int")
    if not isinstance(duration, int) or isinstance(duration, bool) or duration < 1:
        raise ValueError("duration must be int >= 1")
    if not isinstance(gap, int) or isinstance(gap, bool) or gap < 0:
        raise ValueError("gap must be int >= 0")

    free = []
    for w in windows:
        s = max(w["start"], now)
        e = w["end"]
        if s < e:
            free.append((s, e))
    free.sort()

    merged = []
    for s, e in free:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    busy_sorted = sorted(busy, key=lambda b: b["start"])

    def subtract_busy(intervals):
        result = []
        for s, e in intervals:
            cur_s = s
            for b in busy_sorted:
                bs, be = b["start"], b["end"]
                if be <= cur_s:
                    continue
                if bs >= e:
                    break
                if bs > cur_s:
                    result.append((cur_s, bs))
                cur_s = max(cur_s, be)
            if cur_s < e:
                result.append((cur_s, e))
        return result

    available = subtract_busy(merged)

    slot1 = None
    for s, e in available:
        if e - s >= duration:
            slot1 = {"start": s, "end": s + duration}
            break

    slots = []
    complete = False
    if slot1 is not None:
        slots.append(slot1)
        earliest2 = slot1["end"] + gap
        for s, e in available:
            start2 = max(s, earliest2)
            if start2 + duration <= e:
                slots.append({"start": start2, "end": start2 + duration})
                complete = True
                break

    return {"name": contract["name"], "result": {"slots": slots, "complete": complete}}
