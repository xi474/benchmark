def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    slots_result = payloads[0]
    invitees_result = payloads[1]
    supplies_result = payloads[2]

    if isinstance(slots_result, dict) and set(slots_result.keys()) == {"name", "result"}:
        slots_data = slots_result["result"]
    else:
        slots_data = slots_result

    if isinstance(invitees_result, dict) and set(invitees_result.keys()) == {"name", "result"}:
        invitees_data = invitees_result["result"]
    else:
        invitees_data = invitees_result

    if isinstance(supplies_result, dict) and set(supplies_result.keys()) == {"name", "result"}:
        supplies_data = supplies_result["result"]
    else:
        supplies_data = supplies_result

    complete = slots_data.get("complete", False)
    slots = slots_data.get("slots", [])
    group_id = invitees_data["group_id"]
    members = invitees_data["members"]

    events = []
    notification = None

    if complete and len(slots) == 2:
        events = [
            {"id": group_id + "-1", "start": slots[0]["start"], "end": slots[0]["end"], "members": members},
            {"id": group_id + "-2", "start": slots[1]["start"], "end": slots[1]["end"], "members": members},
        ]
        notification = {
            "group_id": group_id,
            "members": members,
            "event_ids": [group_id + "-1", group_id + "-2"],
        }

    return {
        "name": contract["name"],
        "result": {
            "events": events,
            "notification": notification,
            "purchase": supplies_data,
        },
    }
