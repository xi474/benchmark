def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    products = case["products"]
    requirements = case["requirements"]

    items = []
    unavailable = []

    for req in requirements:
        cat = req["category"]
        qty = req["quantity"]
        if not isinstance(qty, int) or isinstance(qty, bool) or qty < 1:
            raise ValueError("quantity must be int >= 1")

        candidates = [p for p in products if p["category"] == cat and p["stock"] >= qty]
        if not candidates:
            unavailable.append(cat)
            continue

        best = min(candidates, key=lambda p: (-p["rating"], p["price_cents"], p["id"]))
        items.append({
            "category": cat,
            "id": best["id"],
            "quantity": qty,
            "total_cents": best["price_cents"] * qty,
        })

    items.sort(key=lambda x: x["category"])
    unavailable.sort()

    return {
        "name": contract["name"],
        "result": {"items": items, "unavailable": unavailable},
    }
