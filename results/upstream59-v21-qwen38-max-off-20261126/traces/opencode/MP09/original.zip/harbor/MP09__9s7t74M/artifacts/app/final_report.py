import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    raw = json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    sha = hashlib.sha256(raw).hexdigest()

    attention = []
    components = core.get("components", {})
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.append(name)
            continue
        triggered = False
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True
                break
        if triggered:
            attention.append(name)
            continue
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if isinstance(val, list) and len(val) > 0:
                triggered = True
                break
        if triggered:
            attention.append(name)

    attention = sorted(set(attention))

    report = {
        "title": "\u4e24\u573a\u5ea7\u8c08\u4f1a\u3001\u7fa4\u9080\u8bf7\u4e0e\u7269\u8d44\u91c7\u8d2d",
        "component_count": len(components),
        "sha256": sha,
        "attention": attention,
    }

    out = ROOT / "outputs" / "final_report.json"
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
