import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = (cp, c)

    done = set()
    order = []

    def resolve(name):
        if name in done:
            return
        _, c = contract_map[name]
        for inp in c["inputs"]:
            p = ROOT / inp
            if str(p).startswith(str(ROOT / "outputs")):
                for n2, (_, c2) in contract_map.items():
                    if c2["output"] == inp:
                        resolve(n2)
                        break
        order.append(name)
        done.add(name)

    for name in sorted(contract_map.keys()):
        resolve(name)

    for name in order:
        cp, _ = contract_map[name]
        render_py = cp.with_name("render.py")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"component {name} failed")

    subprocess.run([sys.executable, str(ROOT / "integrate.py")], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / "final_report.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
