import json
import sys
from pathlib import Path


def _get_loader():
    try:
        from .model import load_payload
        return load_payload
    except ImportError:
        pass
    pkg_dir = Path(__file__).resolve().parent
    sys.path.insert(0, str(pkg_dir))
    from model import load_payload
    return load_payload


def _get_transformer():
    try:
        from .transform import transform
        return transform
    except ImportError:
        pass
    pkg_dir = Path(__file__).resolve().parent
    if str(pkg_dir) not in sys.path:
        sys.path.insert(0, str(pkg_dir))
    from transform import transform
    return transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    load_payload = _get_loader()
    transform = _get_transformer()
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    result = transform(payloads, contract)
    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
    return result


if __name__ == "__main__":
    root = Path.cwd()
    contract_path = Path(__file__).resolve().parent / 'contract.json'
    build_component(root, contract_path)
