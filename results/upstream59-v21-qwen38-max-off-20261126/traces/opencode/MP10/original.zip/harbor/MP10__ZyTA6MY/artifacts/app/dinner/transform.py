from datetime import date, timedelta


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    today_str = case['today']
    weekday = case['weekday']
    hour = case['hour']
    guest_count = case['guest_count']

    if not isinstance(today_str, str):
        raise ValueError("today must be string")
    if not isinstance(weekday, int) or isinstance(weekday, bool):
        raise ValueError("weekday must be int")
    if weekday < 0 or weekday > 6:
        raise ValueError("weekday out of range")
    if not isinstance(hour, int) or isinstance(hour, bool):
        raise ValueError("hour must be int")
    if hour < 0 or hour > 23:
        raise ValueError("hour out of range")
    if not isinstance(guest_count, int) or isinstance(guest_count, bool):
        raise ValueError("guest_count must be int")
    if guest_count < 1:
        raise ValueError("guest_count must be >= 1")

    today = date.fromisoformat(today_str)
    today_weekday = today.weekday()
    delta = (weekday - today_weekday) % 7
    if delta == 0:
        delta = 7
    dinner_date = today + timedelta(days=delta)
    start = f"{dinner_date.isoformat()}T{hour:02d}:00"

    return {
        "name": contract["name"],
        "result": {
            "start": start,
            "guest_count": guest_count
        }
    }
