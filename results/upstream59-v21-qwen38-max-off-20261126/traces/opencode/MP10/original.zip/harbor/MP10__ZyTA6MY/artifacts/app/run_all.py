import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    dep_graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        deps = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                    if other_c['output'] == inp:
                        deps.add(other_c['name'])
        dep_graph[name] = (cp, deps)

    executed = set()
    order = []
    def resolve(name):
        if name in executed:
            return
        _, deps = dep_graph[name]
        for d in sorted(deps):
            resolve(d)
        executed.add(name)
        order.append(name)

    for name in sorted(dep_graph):
        resolve(name)

    for name in order:
        cp, _ = dep_graph[name]
        render_py = cp.with_name('render.py')
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT, check=True, timeout=60
        )

    subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT, check=True, timeout=60
    )

    subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT, check=True, timeout=60
    )


if __name__ == '__main__':
    main()
