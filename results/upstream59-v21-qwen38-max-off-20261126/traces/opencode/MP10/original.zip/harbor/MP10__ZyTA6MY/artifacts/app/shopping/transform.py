def _unwrap(obj):
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    dinner_result = _unwrap(payloads[1])
    contact_result = _unwrap(payloads[2])

    variants = case['variants']
    wanted = case['wanted']
    guest_count = dinner_result['guest_count']
    start = dinner_result['start']
    recipient = contact_result.get('contact_id')

    if not isinstance(variants, list):
        raise ValueError("variants must be list")
    if not isinstance(wanted, list):
        raise ValueError("wanted must be list")

    items = []
    unavailable = []

    for w in wanted:
        kind = w['kind']
        attrs = w['attributes']
        candidates = []
        for v in variants:
            if v['kind'] == kind and v['attributes'] == attrs and v['stock'] >= guest_count:
                candidates.append(v)
        if not candidates:
            unavailable.append(kind)
        else:
            candidates.sort(key=lambda x: (x['price_cents'], x['id']))
            best = candidates[0]
            items.append({
                "id": best['id'],
                "kind": kind,
                "quantity": guest_count
            })

    items.sort(key=lambda x: x['kind'])
    unavailable.sort()

    total_cents = sum(
        next(v['price_cents'] for v in variants if v['id'] == it['id']) * it['quantity']
        for it in items
    )

    checkout = len(unavailable) == 0 and recipient is not None

    return {
        "name": contract["name"],
        "result": {
            "items": items,
            "total_cents": total_cents,
            "checkout": checkout,
            "recipient": recipient,
            "start": start,
            "unavailable": unavailable
        }
    }
