def _unwrap(p):
    if isinstance(p, dict) and set(p.keys()) == {"name", "result"}:
        return p["result"]
    return p


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    original = payloads[0]
    files_result = _unwrap(payloads[1])
    mail_result = _unwrap(payloads[2])
    reply_result = _unwrap(payloads[3])

    trash_ids = set(mail_result["trash_ids"])
    reply_email_id = reply_result["email_id"]
    if reply_email_id in trash_ids:
        raise ValueError("reply email is in trash_ids: conflict")

    moves = files_result["moves"]
    move_map = {}
    for m in moves:
        move_map[m["from"]] = m["to"]

    out_files = []
    for f in original["files"]:
        new_path = move_map.get(f["path"], f["path"])
        out_files.append({"path": new_path, "hex": f["hex"]})
    out_files.sort(key=lambda x: x["path"])

    out_emails = []
    for em in original["emails"]:
        e = dict(em)
        if e["id"] in trash_ids:
            e["folder"] = "TRASH"
        out_emails.append(e)
    out_emails.sort(key=lambda x: x["id"])

    return {
        "name": contract["name"],
        "result": {
            "files": out_files,
            "emails": out_emails,
            "reply": reply_result,
        },
    }
