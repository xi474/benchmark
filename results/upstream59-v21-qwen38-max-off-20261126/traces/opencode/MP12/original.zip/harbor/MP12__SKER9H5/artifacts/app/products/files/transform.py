import os


def _safe_rel(p):
    if not p or os.path.isabs(p):
        raise ValueError("unsafe path")
    parts = p.replace("\\", "/").split("/")
    for seg in parts:
        if seg in ("", ".", "..") or ":" in seg:
            raise ValueError("unsafe path segment")
    return "/".join(parts)


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    files = case["files"]
    download_prefix = case["download_prefix"]
    archive_prefix = case["archive_prefix"]
    extensions = case["extensions"]

    ext_map = {}
    for ext, subdir in extensions.items():
        ext_map[ext.lower()] = subdir

    moves = []
    targets_seen = set()
    for f in files:
        fpath = f["path"]
        _safe_rel(fpath)
        parent = os.path.dirname(fpath)
        if parent != download_prefix:
            continue
        basename = os.path.basename(fpath)
        _, ext = os.path.splitext(basename)
        ext_lower = ext.lower()
        if ext_lower not in ext_map:
            continue
        subdir = ext_map[ext_lower]
        dest = archive_prefix + "/" + subdir + "/" + basename
        _safe_rel(dest)
        if dest in targets_seen:
            raise ValueError("duplicate target: " + dest)
        targets_seen.add(dest)
        moves.append({"from": fpath, "to": dest})

    moves.sort(key=lambda m: m["from"])
    return {"name": contract["name"], "result": {"moves": moves}}
