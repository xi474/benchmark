import datetime


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    emails = case["emails"]
    month = case["month"]
    trash_keyword = case["trash_keyword"]

    ym = month.split("-")
    if len(ym) != 2:
        raise ValueError("invalid month format")
    target_year = int(ym[0])
    target_month = int(ym[1])

    keyword_cf = trash_keyword.casefold()
    trash_ids = []
    for em in emails:
        d = em["date"]
        parts = d.split("-")
        if len(parts) != 3:
            raise ValueError("invalid date format")
        try:
            dt = datetime.date(int(parts[0]), int(parts[1]), int(parts[2]))
        except ValueError:
            raise ValueError("invalid date: " + d)
        if dt.year == target_year and dt.month == target_month:
            if keyword_cf in em["subject"].casefold():
                if em["folder"] != "TRASH":
                    trash_ids.append(em["id"])

    trash_ids.sort()
    return {"name": contract["name"], "result": {"trash_ids": trash_ids}}
