def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    emails = case["emails"]
    reply_email_id = case["reply_email_id"]
    manager = case["manager"]
    reply_text = case["reply_text"]

    target = None
    for em in emails:
        if em["id"] == reply_email_id:
            target = em
            break
    if target is None:
        raise ValueError("reply_email_id not found: " + reply_email_id)
    if target["sender"] != manager:
        raise ValueError("sender mismatch: expected " + manager)

    return {
        "name": contract["name"],
        "result": {
            "email_id": reply_email_id,
            "thread_id": target["thread_id"],
            "to": manager,
            "text": reply_text,
        },
    }
