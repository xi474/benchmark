import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        [p for p in ROOT.rglob("contract.json") if "outputs" not in p.relative_to(ROOT).parts]
    )
    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)

    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["output"]] = cp

    order = []
    remaining = {str(cp): cp for cp in contracts}
    while remaining:
        progress = False
        for key, cp in list(remaining.items()):
            c = json.loads(cp.read_text(encoding="utf-8"))
            deps_ok = True
            for inp in c["inputs"]:
                if inp.startswith("outputs/"):
                    if inp not in contract_map:
                        deps_ok = False
                        break
                    dep_cp = contract_map[inp]
                    if str(dep_cp) in remaining:
                        deps_ok = False
                        break
            if deps_ok:
                order.append(cp)
                del remaining[key]
                progress = True
        if not progress:
            print("unresolvable dependencies", file=sys.stderr)
            sys.exit(1)

    for cp in order:
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            print(f"missing render.py for {cp}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print(f"render failed for {cp}", file=sys.stderr)
            sys.exit(1)

    integrate = ROOT / "integrate.py"
    if integrate.exists():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate failed", file=sys.stderr)
            sys.exit(1)

    final = ROOT / "final_report.py"
    if final.exists():
        result = subprocess.run(
            [sys.executable, str(final)],
            cwd=str(ROOT),
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
