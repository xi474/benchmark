def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    records = case["records"]
    vocabulary = case["vocabulary"]
    vocab_set = set(vocabulary)
    if len(vocab_set) != len(vocabulary):
        raise ValueError("duplicate vocabulary entries")
    groups = {}
    for r in records:
        k = r["key"]
        if k not in groups:
            groups[k] = []
        groups[k].append(r)
    rows = []
    for k in sorted(groups.keys()):
        cats = set()
        has_non_null = False
        for r in groups[k]:
            c = r["category"]
            if c is not None:
                has_non_null = True
                if c in vocab_set:
                    cats.add(c)
        if not has_non_null:
            continue
        values = {}
        for v in vocabulary:
            values[v] = v in cats
        rows.append({"key": k, "values": values})
    return {"name": contract["name"], "result": {"rows": rows}}
