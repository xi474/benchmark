def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    records = case["records"]
    ids_seen = set()
    for r in records:
        rid = r["id"]
        if rid in ids_seen:
            raise ValueError(f"duplicate record id: {rid}")
        ids_seen.add(rid)
    groups = {}
    for r in records:
        k = r["key"]
        if k not in groups:
            groups[k] = []
        groups[k].append(r)
    rows = []
    for k in sorted(groups.keys()):
        vals = [r["value"] for r in groups[k] if r["value"] is not None]
        cnt = len(vals)
        s = sum(vals) if cnt > 0 else 0
        mean = s / cnt if cnt > 0 else None
        rows.append({"key": k, "values": {"count": cnt, "sum": s, "mean": mean}})
    return {"name": contract["name"], "result": {"rows": rows}}
