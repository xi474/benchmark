def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    records = case["records"]
    groups = {}
    for r in records:
        k = r["key"]
        if k not in groups:
            groups[k] = []
        groups[k].append(r)
    rows = []
    for k in sorted(groups.keys()):
        times = [r["time"] for r in groups[k] if r["time"] is not None]
        if not times:
            continue
        first = min(times)
        last = max(times)
        span = last - first
        rows.append({"key": k, "values": {"first": first, "last": last, "span": span}})
    return {"name": contract["name"], "result": {"rows": rows}}
