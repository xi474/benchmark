def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    num_result = payloads[0]
    cat_result = payloads[1]
    time_result = payloads[2]
    def _unwrap(obj):
        if isinstance(obj, dict) and set(obj.keys()) == {"name", "result"}:
            return obj["result"]
        return obj
    num_data = _unwrap(num_result)
    cat_data = _unwrap(cat_result)
    time_data = _unwrap(time_result)
    all_keys = set()
    num_map = {}
    for row in num_data["rows"]:
        k = row["key"]
        all_keys.add(k)
        num_map[k] = row["values"]
    cat_map = {}
    for row in cat_data["rows"]:
        k = row["key"]
        all_keys.add(k)
        cat_map[k] = row["values"]
    time_map = {}
    for row in time_data["rows"]:
        k = row["key"]
        all_keys.add(k)
        time_map[k] = row["values"]
    columns = set()
    for k, v in num_map.items():
        for col in v:
            columns.add(f"num.{col}")
    for k, v in cat_map.items():
        for col in v:
            columns.add(f"cat.{col}")
    for k, v in time_map.items():
        for col in v:
            columns.add(f"time.{col}")
    columns = sorted(columns)
    index = sorted(all_keys)
    data = []
    for k in index:
        row = []
        for col in columns:
            if col.startswith("num."):
                field = col[4:]
                if k in num_map and field in num_map[k]:
                    row.append(num_map[k][field])
                else:
                    row.append(None)
            elif col.startswith("cat."):
                field = col[4:]
                if k in cat_map and field in cat_map[k]:
                    row.append(cat_map[k][field])
                else:
                    row.append(None)
            elif col.startswith("time."):
                field = col[5:]
                if k in time_map and field in time_map[k]:
                    row.append(time_map[k][field])
                else:
                    row.append(None)
            else:
                row.append(None)
        data.append(row)
    return {"name": contract["name"], "result": {"index": index, "columns": columns, "data": data}}
