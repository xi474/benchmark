import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)
    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)
    graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        deps = set()
        for inp in c["inputs"]:
            for other_cp in contracts:
                other_c = json.loads(other_cp.read_text(encoding="utf-8"))
                if other_c["output"] == inp:
                    deps.add(other_c["name"])
        graph[name] = {"path": cp, "deps": deps}
    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            print(f"cycle detected involving {name}", file=sys.stderr)
            sys.exit(1)
        visiting.add(name)
        for dep in graph[name]["deps"]:
            visit(dep)
        visiting.discard(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(graph.keys()):
        visit(name)
    for name in ordered:
        cp = graph[name]["path"]
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            print(f"missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"component {name} failed", file=sys.stderr)
            sys.exit(1)
    integrate = ROOT / "integrate.py"
    if integrate.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("integrate.py failed", file=sys.stderr)
            sys.exit(1)
    final_report = ROOT / "final_report.py"
    if final_report.is_file():
        result = subprocess.run(
            [sys.executable, str(final_report)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print("final_report.py failed", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
