import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    sys.path.insert(0, str(root))
    from model import load_payload
    from transform import transform
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    out = root / contract["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )
    return result


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    root = here.parent
    cp = here / "contract.json"
    build_component(root, cp)
