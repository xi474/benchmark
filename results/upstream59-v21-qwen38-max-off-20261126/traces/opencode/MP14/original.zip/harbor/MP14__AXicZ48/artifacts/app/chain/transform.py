def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if "root" not in data or "nodes" not in data:
        raise ValueError("missing required fields")
    root_id = data["root"]
    nodes_list = data["nodes"]
    if not isinstance(root_id, str) or not isinstance(nodes_list, list):
        raise ValueError("invalid types")

    node_map = {}
    for n in nodes_list:
        if not isinstance(n, dict):
            raise ValueError("node must be object")
        for field in ("id", "type", "message", "cause", "context", "suppress_context", "frames"):
            if field not in n:
                raise ValueError(f"missing field {field}")
        nid = n["id"]
        if not isinstance(nid, str):
            raise ValueError("id must be string")
        if nid in node_map:
            raise ValueError(f"duplicate id {nid}")
        if not isinstance(n["type"], str):
            raise ValueError("type must be string")
        if not isinstance(n["message"], str):
            raise ValueError("message must be string")
        if n["cause"] is not None and not isinstance(n["cause"], str):
            raise ValueError("cause must be string or null")
        if n["context"] is not None and not isinstance(n["context"], str):
            raise ValueError("context must be string or null")
        if not isinstance(n["suppress_context"], bool):
            raise ValueError("suppress_context must be bool")
        if not isinstance(n["frames"], list):
            raise ValueError("frames must be list")
        for f in n["frames"]:
            if not isinstance(f, dict):
                raise ValueError("frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in f:
                    raise ValueError(f"missing frame field {ff}")
            if not isinstance(f["file"], str):
                raise ValueError("file must be string")
            if not isinstance(f["function"], str):
                raise ValueError("function must be string")
            if not isinstance(f["line"], int) or isinstance(f["line"], bool) or f["line"] < 1:
                raise ValueError("line must be positive integer")
            if not isinstance(f["locals"], dict):
                raise ValueError("locals must be object")
        node_map[nid] = n

    if root_id not in node_map:
        raise ValueError("root not found")

    chain = []
    visited = set()
    current_id = root_id
    link_for_current = None

    while current_id is not None:
        if current_id in visited:
            raise ValueError("cycle detected")
        if len(chain) >= 8:
            raise ValueError("chain exceeds length 8")
        if current_id not in node_map:
            raise ValueError(f"node {current_id} not found")
        visited.add(current_id)
        node = node_map[current_id]
        chain.append({
            "id": node["id"],
            "type": node["type"],
            "message": node["message"],
            "link": link_for_current
        })

        next_id = None
        next_link = None
        if node["cause"] is not None:
            next_id = node["cause"]
            next_link = "cause"
        elif not node["suppress_context"] and node["context"] is not None:
            next_id = node["context"]
            next_link = "context"

        current_id = next_id
        link_for_current = next_link

    chain.reverse()

    for i, item in enumerate(chain):
        if i == 0:
            item["link"] = None
        else:
            prev_id = chain[i - 1]["id"]
            cur_node = node_map[item["id"]]
            if cur_node["cause"] == prev_id:
                item["link"] = "cause"
            elif cur_node["context"] == prev_id and not cur_node["suppress_context"]:
                item["link"] = "context"
            else:
                item["link"] = None

    return {"name": contract["name"], "result": {"chain": chain}}
