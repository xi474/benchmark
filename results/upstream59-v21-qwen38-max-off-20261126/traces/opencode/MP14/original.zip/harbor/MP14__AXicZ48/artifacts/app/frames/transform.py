import json
import os


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if "nodes" not in data:
        raise ValueError("missing nodes")
    nodes_list = data["nodes"]
    if not isinstance(nodes_list, list):
        raise ValueError("nodes must be list")

    result_frames = {}
    for n in nodes_list:
        if not isinstance(n, dict):
            raise ValueError("node must be object")
        for field in ("id", "type", "message", "cause", "context", "suppress_context", "frames"):
            if field not in n:
                raise ValueError(f"missing field {field}")
        nid = n["id"]
        if not isinstance(nid, str):
            raise ValueError("id must be string")
        if not isinstance(n["frames"], list):
            raise ValueError("frames must be list")

        frame_list = []
        for f in n["frames"]:
            if not isinstance(f, dict):
                raise ValueError("frame must be object")
            for ff in ("file", "line", "function", "locals"):
                if ff not in f:
                    raise ValueError(f"missing frame field {ff}")
            filepath = f["file"]
            if not isinstance(filepath, str):
                raise ValueError("file must be string")
            filepath = filepath.replace("\\", "/")
            basename = os.path.basename(filepath)
            line = f["line"]
            if not isinstance(line, int) or isinstance(line, bool) or line < 1:
                raise ValueError("line must be positive integer")
            func = f["function"]
            if not isinstance(func, str):
                raise ValueError("function must be string")
            if not func.strip():
                raise ValueError("function must be non-empty")
            locals_obj = f["locals"]
            if not isinstance(locals_obj, dict):
                raise ValueError("locals must be object")

            normalized_locals = {}
            for k, v in locals_obj.items():
                normalized_locals[k] = json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

            frame_list.append({
                "file": basename,
                "line": line,
                "function": func,
                "locals": normalized_locals
            })
        result_frames[nid] = frame_list

    return {"name": contract["name"], "result": {"frames": result_frames}}
