def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    chain_data = payloads[0]
    frames_data = payloads[1]

    if not isinstance(chain_data, dict) or "result" not in chain_data:
        if isinstance(chain_data, dict) and "name" in chain_data and "result" in chain_data:
            chain_result = chain_data["result"]
        else:
            chain_result = chain_data
    else:
        chain_result = chain_data["result"]

    if not isinstance(frames_data, dict) or "result" not in frames_data:
        if isinstance(frames_data, dict) and "name" in frames_data and "result" in frames_data:
            frames_result = frames_data["result"]
        else:
            frames_result = frames_data
    else:
        frames_result = frames_data["result"]

    if isinstance(chain_data, dict) and set(chain_data.keys()) == {"name", "result"}:
        chain_result = chain_data["result"]
    if isinstance(frames_data, dict) and set(frames_data.keys()) == {"name", "result"}:
        frames_result = frames_data["result"]

    chain_list = chain_result["chain"]
    all_frames = frames_result["frames"]

    nodes = []
    lines = []

    for i, entry in enumerate(chain_list):
        eid = entry["id"]
        etype = entry["type"]
        emessage = entry["message"]
        elink = entry["link"]

        if i > 0:
            if elink == "cause":
                lines.append("--- direct cause ---")
            elif elink == "context":
                lines.append("--- during handling ---")

        node_frames_raw = all_frames.get(eid, [])
        frame_entries = []
        for fr in node_frames_raw:
            lines.append(f"  {fr['file']}:{fr['line']} in {fr['function']}")
            frame_entries.append({
                "file": fr["file"],
                "line": fr["line"],
                "function": fr["function"],
                "locals": fr["locals"]
            })

        lines.append(f"{etype}: {emessage}")

        nodes.append({
            "id": eid,
            "type": etype,
            "message": emessage,
            "link": elink,
            "frames": frame_entries
        })

    text = ""
    if lines:
        text = "\n".join(lines) + "\n"

    return {"name": contract["name"], "result": {"nodes": nodes, "text": text}}
