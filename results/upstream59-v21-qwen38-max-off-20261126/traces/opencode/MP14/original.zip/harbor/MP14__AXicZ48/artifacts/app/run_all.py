import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    dep_order = {}
    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        contract_map[c["name"]] = cp
        deps = set()
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding="utf-8"))
                    if other_c["output"] == inp:
                        deps.add(other_c["name"])
        dep_order[c["name"]] = deps

    ordered = []
    resolved = set()
    def resolve(name):
        if name in resolved:
            return
        for dep in dep_order.get(name, set()):
            resolve(dep)
        resolved.add(name)
        ordered.append(name)

    for name in sorted(dep_order.keys()):
        resolve(name)

    for name in ordered:
        cp = contract_map[name]
        comp_dir = cp.parent
        render_py = comp_dir / "render.py"
        if not render_py.is_file():
            print(f"missing render.py for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print(f"component {name} failed", file=sys.stderr)
            sys.exit(result.returncode)

    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("integrate failed", file=sys.stderr)
            sys.exit(result.returncode)

    final_py = ROOT / "final_report.py"
    if final_py.is_file():
        result = subprocess.run(
            [sys.executable, str(final_py)],
            cwd=ROOT,
            timeout=60
        )
        if result.returncode != 0:
            print("final_report failed", file=sys.stderr)
            sys.exit(result.returncode)


if __name__ == "__main__":
    main()
