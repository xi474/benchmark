import ast


def transform(payloads, contract):
    source_data = payloads[0]
    ordinary_result = payloads[1]
    annotation_result = payloads[2]
    comment_result = payloads[3]

    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing source field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")

    tree = ast.parse(source)

    _check_global_nonlocal(tree)
    _check_no_star_imports(tree)

    module_imports = {}
    func_imports = {}
    func_stores = {}

    _collect_imports_and_stores(tree, module_imports, func_imports, func_stores)

    ordinary_uses = ordinary_result.get("result", {}).get("uses", [])
    annotation_uses = annotation_result.get("result", {}).get("uses", [])
    comment_uses = comment_result.get("result", {}).get("uses", [])

    all_imports = []
    for (scope, name), info in sorted(module_imports.items()):
        all_imports.append({
            "scope": scope,
            "name": name,
            "module": info["module"],
            "line": info["line"],
            "used_by": []
        })
    for scope in sorted(func_imports.keys()):
        for name, info in sorted(func_imports[scope].items()):
            all_imports.append({
                "scope": scope,
                "name": name,
                "module": info["module"],
                "line": info["line"],
                "used_by": []
            })

    import_lookup = {}
    for imp in all_imports:
        key = (imp["scope"], imp["name"])
        import_lookup[key] = imp

    def resolve_use(use_scope, use_name, category):
        if use_scope != "module":
            key = (use_scope, use_name)
            if key in import_lookup:
                if category not in import_lookup[key]["used_by"]:
                    import_lookup[key]["used_by"].append(category)
                return
            stores = func_stores.get(use_scope, set())
            if use_name in stores:
                return
            key_mod = ("module", use_name)
            if key_mod in import_lookup:
                if category not in import_lookup[key_mod]["used_by"]:
                    import_lookup[key_mod]["used_by"].append(category)
                return
        else:
            key = ("module", use_name)
            if key in import_lookup:
                if category not in import_lookup[key]["used_by"]:
                    import_lookup[key]["used_by"].append(category)
                return

    for u in ordinary_uses:
        resolve_use(u["scope"], u["name"], "ordinary")
    for u in annotation_uses:
        resolve_use(u["scope"], u["name"], "annotation")
    for u in comment_uses:
        resolve_use(u["scope"], u["name"], "comment")

    result_imports = sorted(all_imports, key=lambda i: (i["scope"], i["line"], i["name"]))

    unused = []
    for imp in result_imports:
        if not imp["used_by"]:
            unused.append(f"{imp['scope']}:{imp['name']}")
    unused.sort()

    return {
        "name": contract["name"],
        "result": {
            "imports": result_imports,
            "unused": unused
        }
    }


def _check_global_nonlocal(tree):
    for node in ast.walk(tree):
        if isinstance(node, ast.Global):
            raise ValueError("global statement not supported")
        if isinstance(node, ast.Nonlocal):
            raise ValueError("nonlocal statement not supported")


def _check_no_star_imports(tree):
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    raise ValueError("star import not supported")


def _collect_imports_and_stores(tree, module_imports, func_imports, func_stores):
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound = alias.asname if alias.asname else alias.name.split(".")[0]
                module_name = alias.name
                key = ("module", bound)
                if key in module_imports:
                    raise ValueError(f"duplicate import: {bound} in module")
                module_imports[key] = {"module": module_name, "line": node.lineno}
        elif isinstance(node, ast.ImportFrom):
            if node.level and node.level > 0:
                raise ValueError("relative import not supported")
            module_name = node.module or ""
            for alias in node.names:
                bound = alias.asname if alias.asname else alias.name
                key = ("module", bound)
                if key in module_imports:
                    raise ValueError(f"duplicate import: {bound} in module")
                module_imports[key] = {"module": module_name, "line": node.lineno}
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            fname = node.name
            func_imports[fname] = {}
            func_stores[fname] = set()
            _collect_func_scope(node, fname, func_imports, func_stores)


def _collect_func_scope(func_node, fname, func_imports, func_stores):
    args = func_node.args
    for arg in args.posonlyargs + args.args + args.kwonlyargs:
        func_stores[fname].add(arg.arg)
    if args.vararg:
        func_stores[fname].add(args.vararg.arg)
    if args.kwarg:
        func_stores[fname].add(args.kwarg.arg)

    for node in ast.walk(func_node):
        if node is func_node:
            continue
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound = alias.asname if alias.asname else alias.name.split(".")[0]
                module_name = alias.name
                key = (fname, bound)
                if key in func_imports[fname]:
                    raise ValueError(f"duplicate import: {bound} in {fname}")
                func_imports[fname][bound] = {"module": module_name, "line": node.lineno}
        elif isinstance(node, ast.ImportFrom):
            if node.level and node.level > 0:
                raise ValueError("relative import not supported")
            module_name = node.module or ""
            for alias in node.names:
                bound = alias.asname if alias.asname else alias.name
                key = (fname, bound)
                if key in func_imports[fname]:
                    raise ValueError(f"duplicate import: {bound} in {fname}")
                func_imports[fname][bound] = {"module": module_name, "line": node.lineno}
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                _collect_store_names(target, func_stores[fname])
        elif isinstance(node, ast.AnnAssign) and node.target:
            _collect_store_names(node.target, func_stores[fname])
        elif isinstance(node, ast.For):
            _collect_store_names(node.target, func_stores[fname])
        elif isinstance(node, ast.With):
            for item in node.items:
                if item.optional_vars:
                    _collect_store_names(item.optional_vars, func_stores[fname])


def _collect_store_names(node, stores):
    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
        stores.add(node.id)
    elif isinstance(node, (ast.Tuple, ast.List)):
        for elt in node.elts:
            _collect_store_names(elt, stores)
