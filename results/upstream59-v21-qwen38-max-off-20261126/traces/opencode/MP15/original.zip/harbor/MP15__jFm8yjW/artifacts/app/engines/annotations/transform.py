import ast


def _extract_annotation_loads(source):
    tree = ast.parse(source)
    uses = []
    seen = set()

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.AsyncFunctionDef):
            raise ValueError("async function not supported")
        elif isinstance(node, ast.FunctionDef):
            _check_function_valid(node)
            _collect_func_signature_annotations(node, "module", uses, seen)
            _collect_func_body_annotations(node, uses, seen)
        elif isinstance(node, ast.ClassDef):
            raise ValueError("class not supported")
        else:
            _collect_module_annotations(node, uses, seen)

    result = sorted(uses, key=lambda u: (u["scope"], u["line"], u["name"]))
    return {"uses": result}


def _check_function_valid(func_node):
    for child in ast.walk(func_node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child is not func_node:
            raise ValueError("nested function not supported")
        if isinstance(child, ast.Lambda):
            raise ValueError("lambda not supported")
        if isinstance(child, ast.ClassDef):
            raise ValueError("class not supported")


def _add_load(name, scope, line, uses, seen):
    key = (scope, line, name)
    if key not in seen:
        seen.add(key)
        uses.append({"scope": scope, "name": name, "line": line})


def _walk_annotation_for_loads(node, scope, line, uses, seen):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return
    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
        _add_load(node.id, scope, line, uses, seen)
    for child in ast.iter_child_nodes(node):
        _walk_annotation_for_loads(child, scope, line, uses, seen)


def _process_annotation(annotation, scope, uses, seen):
    if annotation is None:
        return
    line = annotation.lineno
    if isinstance(annotation, ast.Constant) and isinstance(annotation.value, str):
        expr_str = annotation.value
        try:
            parsed = ast.parse(expr_str, mode="eval")
        except SyntaxError as e:
            raise ValueError(f"bad forward reference expression: {e}") from e
        _walk_annotation_for_loads(parsed.body, scope, line, uses, seen)
    else:
        _walk_annotation_for_loads(annotation, scope, line, uses, seen)


def _collect_func_signature_annotations(func_node, scope, uses, seen):
    args = func_node.args
    for arg in args.posonlyargs + args.args + args.kwonlyargs:
        if arg.annotation is not None:
            _process_annotation(arg.annotation, scope, uses, seen)
    if args.vararg and args.vararg.annotation:
        _process_annotation(args.vararg.annotation, scope, uses, seen)
    if args.kwarg and args.kwarg.annotation:
        _process_annotation(args.kwarg.annotation, scope, uses, seen)
    if func_node.returns is not None:
        _process_annotation(func_node.returns, scope, uses, seen)


def _collect_func_body_annotations(func_node, uses, seen):
    fname = func_node.name
    for stmt in ast.walk(func_node):
        if isinstance(stmt, ast.AnnAssign):
            if stmt.annotation is not None:
                _process_annotation(stmt.annotation, fname, uses, seen)


def _collect_module_annotations(node, uses, seen):
    if isinstance(node, ast.AnnAssign):
        if node.annotation is not None:
            _process_annotation(node.annotation, "module", uses, seen)


def transform(payloads, contract):
    source_data = payloads[0]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing source field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    result = _extract_annotation_loads(source)
    return {"name": contract["name"], "result": result}
