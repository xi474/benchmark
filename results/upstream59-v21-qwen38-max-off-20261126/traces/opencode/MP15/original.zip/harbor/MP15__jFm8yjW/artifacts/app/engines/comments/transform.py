import ast


def _extract_type_comment_loads(source):
    tree = ast.parse(source, type_comments=True)
    uses = []
    seen = set()

    _check_forbidden_type_comments(tree)

    _walk_tree_for_assign_type_comments(tree, "module", uses, seen)

    result = sorted(uses, key=lambda u: (u["scope"], u["line"], u["name"]))
    return {"uses": result}


def _check_forbidden_type_comments(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.type_comment is not None:
                raise ValueError("function signature type_comment not supported")
        if isinstance(node, ast.For):
            if node.type_comment is not None:
                raise ValueError("for type comment not supported")
        if isinstance(node, ast.With):
            if node.type_comment is not None:
                raise ValueError("with type comment not supported")


def _add_load(name, scope, line, uses, seen):
    key = (scope, line, name)
    if key not in seen:
        seen.add(key)
        uses.append({"scope": scope, "name": name, "line": line})


def _walk_for_loads(node, scope, line, uses, seen):
    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
        _add_load(node.id, scope, line, uses, seen)
    for child in ast.iter_child_nodes(node):
        _walk_for_loads(child, scope, line, uses, seen)


def _walk_tree_for_assign_type_comments(node, current_scope, uses, seen):
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            _walk_tree_for_assign_type_comments(child, child.name, uses, seen)
        elif isinstance(child, ast.Assign) and child.type_comment is not None:
            tc = child.type_comment.strip()
            if tc == "ignore" or tc.startswith("ignore[") or tc.startswith("ignore "):
                continue
            line = child.lineno
            try:
                parsed = ast.parse(tc, mode="eval")
            except SyntaxError as e:
                raise ValueError(f"bad type comment expression: {e}") from e
            _walk_for_loads(parsed.body, current_scope, line, uses, seen)
        else:
            _walk_tree_for_assign_type_comments(child, current_scope, uses, seen)


def transform(payloads, contract):
    source_data = payloads[0]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing source field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    result = _extract_type_comment_loads(source)
    return {"name": contract["name"], "result": result}
