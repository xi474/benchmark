import ast


def _extract_ordinary_loads(source):
    tree = ast.parse(source)
    uses = []
    seen = set()

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.AsyncFunctionDef):
            raise ValueError("async function not supported")
        elif isinstance(node, ast.FunctionDef):
            _check_function_valid(node)
            _collect_decorator_and_default_loads(node, "module", uses, seen)
            _collect_func_body_loads(node, uses, seen)
        elif isinstance(node, ast.ClassDef):
            raise ValueError("class not supported")
        else:
            _collect_module_level_loads(node, uses, seen)

    result = sorted(uses, key=lambda u: (u["scope"], u["line"], u["name"]))
    return {"uses": result}


def _check_function_valid(func_node):
    for child in ast.walk(func_node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child is not func_node:
            raise ValueError("nested function not supported")
        if isinstance(child, ast.Lambda):
            raise ValueError("lambda not supported")
        if isinstance(child, ast.ClassDef):
            raise ValueError("class not supported")


def _add_load(node, scope, uses, seen):
    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
        key = (scope, node.lineno, node.id)
        if key not in seen:
            seen.add(key)
            uses.append({"scope": scope, "name": node.id, "line": node.lineno})


def _walk_for_loads(node, scope, uses, seen):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return
    if isinstance(node, ast.ClassDef):
        return
    if isinstance(node, ast.AnnAssign):
        return
    if isinstance(node, ast.arguments):
        return
    _add_load(node, scope, uses, seen)
    for child in ast.iter_child_nodes(node):
        _walk_for_loads(child, scope, uses, seen)


def _collect_decorator_and_default_loads(func_node, scope, uses, seen):
    for dec in func_node.decorator_list:
        _walk_for_loads(dec, scope, uses, seen)
    args = func_node.args
    for d in args.defaults:
        _walk_for_loads(d, scope, uses, seen)
    for d in args.kw_defaults:
        if d is not None:
            _walk_for_loads(d, scope, uses, seen)


def _collect_module_level_loads(node, uses, seen):
    if isinstance(node, ast.AnnAssign):
        return
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        return
    _walk_for_loads(node, "module", uses, seen)


def _collect_func_body_loads(func_node, uses, seen):
    fname = func_node.name
    for stmt in func_node.body:
        if isinstance(stmt, ast.AnnAssign):
            continue
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError("nested function not supported")
        if isinstance(stmt, ast.ClassDef):
            raise ValueError("class not supported")
        _walk_for_loads(stmt, fname, uses, seen)


def transform(payloads, contract):
    source_data = payloads[0]
    if not isinstance(source_data, dict) or "source" not in source_data:
        raise ValueError("missing source field")
    source = source_data["source"]
    if not isinstance(source, str):
        raise ValueError("source must be string")
    result = _extract_ordinary_loads(source)
    return {"name": contract["name"], "result": result}
