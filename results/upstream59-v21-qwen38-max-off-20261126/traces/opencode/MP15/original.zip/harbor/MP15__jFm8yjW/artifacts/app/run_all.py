import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    dep_graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        deps = set()
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding="utf-8"))
                    if other_c["output"] == inp:
                        deps.add(other_c["name"])
        dep_graph[name] = (cp, deps)

    ordered = _topological_sort(dep_graph)

    for name in ordered:
        cp = dep_graph[name][0]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            raise ValueError(f"missing render.py for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"render.py failed for {name}: {result.stderr}")

    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"integrate.py failed: {result.stderr}")

    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"final_report.py failed: {result.stderr}")


def _topological_sort(graph):
    visited = set()
    temp_mark = set()
    order = []

    def visit(name):
        if name in temp_mark:
            raise ValueError(f"circular dependency involving {name}")
        if name in visited:
            return
        temp_mark.add(name)
        _, deps = graph[name]
        for dep in sorted(deps):
            if dep not in graph:
                raise ValueError(f"missing dependency {dep} for {name}")
            visit(dep)
        temp_mark.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(graph.keys()):
        visit(name)

    return order


if __name__ == "__main__":
    main()
