import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    comp_dir = contract_path.parent

    sys.path.insert(0, str(root))
    sys.path.insert(0, str(comp_dir))

    from model import load_payload
    from transform import transform

    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    result = transform(payloads, contract)
    return result


def _write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    contract_path = Path(__file__).resolve().parent / "contract.json"
    result = build_component(root, contract_path)
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    _write_json(root / contract["output"], result)
