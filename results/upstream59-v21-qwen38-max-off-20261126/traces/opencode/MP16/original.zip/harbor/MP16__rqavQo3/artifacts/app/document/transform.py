import re


def _replace_aliases_in_type(type_str, aliases):
    if type_str is None:
        return None

    def replacer(m):
        ident = m.group(0)
        if ident in aliases:
            return aliases[ident]
        return ident

    result = re.sub(r'(?<!\.)(?<![.\w])([A-Za-z_]\w*)(?![.\w])', replacer, type_str)
    return result


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    sig_data = payloads[0]
    param_data = payloads[1]
    inherit_data = payloads[2]

    if isinstance(sig_data, dict) and set(sig_data.keys()) == {"name", "result"}:
        sig_result = sig_data["result"]
    else:
        sig_result = sig_data

    if isinstance(param_data, dict) and set(param_data.keys()) == {"name", "result"}:
        param_result = param_data["result"]
    else:
        param_result = param_data

    if isinstance(inherit_data, dict) and set(inherit_data.keys()) == {"name", "result"}:
        inherit_result = inherit_data["result"]
    else:
        inherit_result = inherit_data

    overloads = sig_result["overloads"]
    docs = param_result["docs"]
    provider = inherit_result.get("provider")
    namespace = inherit_result.get("namespace")
    aliases = inherit_result.get("aliases", {})

    if provider is not None and provider in docs:
        raw_params = docs[provider]
        parameters = []
        for p in raw_params:
            new_type = _replace_aliases_in_type(p["type"], aliases)
            parameters.append({
                "name": p["name"],
                "type": new_type,
                "description": p["description"],
            })
    else:
        parameters = []

    return {
        "name": contract["name"],
        "result": {
            "overloads": overloads,
            "provider": provider,
            "namespace": namespace,
            "parameters": parameters,
        },
    }
