def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    objects = payload["objects"]
    target = payload["target"]

    obj_map = {o["id"]: o for o in objects}
    if target not in obj_map:
        raise ValueError(f"target {target} not found")

    target_obj = obj_map[target]
    candidates = [target] + target_obj.get("mro", [])

    provider_id = None
    provider_obj = None
    for cid in candidates:
        if cid not in obj_map:
            raise ValueError(f"mro id {cid} not found")
        obj = obj_map[cid]
        doc = obj.get("doc", "")
        if doc.strip():
            provider_id = cid
            provider_obj = obj
            break

    if provider_obj is not None:
        return {
            "name": contract["name"],
            "result": {
                "provider": provider_id,
                "namespace": provider_obj["namespace"],
                "aliases": provider_obj.get("aliases", {}),
            },
        }
    else:
        return {
            "name": contract["name"],
            "result": {
                "provider": None,
                "namespace": None,
                "aliases": {},
            },
        }
