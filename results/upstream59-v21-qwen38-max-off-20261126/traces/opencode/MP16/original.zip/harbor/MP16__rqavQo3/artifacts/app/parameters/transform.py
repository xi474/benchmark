import re


def _parse_doc(doc_str):
    params = {}
    types = {}
    for line in doc_str.split("\n"):
        m_param_typed = re.match(r"^:param\s+(.+?)\s+(\w+)\s*:\s*(.*)", line)
        m_param_plain = re.match(r"^:param\s+(\w+)\s*:\s*(.*)", line)
        m_type = re.match(r"^:type\s+(\w+)\s*:\s*(.*)", line)

        if m_param_typed:
            type_part = m_param_typed.group(1).strip()
            name = m_param_typed.group(2)
            desc = m_param_typed.group(3).strip()
            if not _is_identifier(name):
                raise ValueError(f"bad param name: {name}")
            _validate_balanced_parens(type_part)
            if name in params:
                raise ValueError(f"duplicate param: {name}")
            params[name] = {"name": name, "type": type_part, "description": desc}
        elif m_param_plain and not m_type:
            name = m_param_plain.group(1)
            desc = m_param_plain.group(2).strip()
            if not _is_identifier(name):
                raise ValueError(f"bad param name: {name}")
            if name in params:
                raise ValueError(f"duplicate param: {name}")
            params[name] = {"name": name, "type": None, "description": desc}
        elif m_type:
            name = m_type.group(1)
            type_str = m_type.group(2).strip()
            if not _is_identifier(name):
                raise ValueError(f"bad type name: {name}")
            _validate_balanced_parens(type_str)
            if name in types:
                raise ValueError(f"duplicate type: {name}")
            types[name] = type_str
        else:
            stripped = line.strip()
            if stripped.startswith(":param") or stripped.startswith(":type"):
                raise ValueError(f"bad directive: {line}")

    for name, type_str in types.items():
        if name in params:
            params[name]["type"] = type_str
        else:
            params[name] = {"name": name, "type": type_str, "description": ""}

    return sorted(params.values(), key=lambda p: p["name"])


def _is_identifier(s):
    return s.isidentifier()


def _validate_balanced_parens(s):
    depth = 0
    for ch in s:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if depth < 0:
            raise ValueError("unbalanced parens")
    if depth != 0:
        raise ValueError("unbalanced parens")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    objects = payload["objects"]
    docs = {}
    for obj in objects:
        obj_id = obj["id"]
        doc_str = obj.get("doc", "")
        parsed = _parse_doc(doc_str)
        docs[obj_id] = parsed
    return {"name": contract["name"], "result": {"docs": docs}}
