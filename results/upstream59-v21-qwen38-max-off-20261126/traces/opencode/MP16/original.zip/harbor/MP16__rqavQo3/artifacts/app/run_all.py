import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    dep_graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        deps = set()
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding="utf-8"))
                    if other_c["output"] == inp:
                        deps.add(other_c["name"])
        dep_graph[name] = (cp, deps)

    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        visiting.add(name)
        cp, deps = dep_graph[name]
        for d in sorted(deps):
            visit(d)
        visiting.discard(name)
        visited.add(name)
        ordered.append((name, cp))

    for name in sorted(dep_graph.keys()):
        visit(name)

    for name, cp in ordered:
        render_py = cp.parent / "render.py"
        if not render_py.is_file():
            raise FileNotFoundError(f"render.py not found for {name}")
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    integrate_py = ROOT / "integrate.py"
    if integrate_py.is_file():
        subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )

    final_report_py = ROOT / "final_report.py"
    if final_report_py.is_file():
        subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )


if __name__ == "__main__":
    main()
