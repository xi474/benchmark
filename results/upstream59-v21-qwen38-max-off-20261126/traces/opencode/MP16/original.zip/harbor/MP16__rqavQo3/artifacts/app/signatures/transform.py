import ast


def _parse_signature(sig_str):
    func_def = ast.parse(f"def {sig_str}: ...").body[0]
    name = func_def.name
    args = func_def.args

    parameters = []

    posonlyargs = getattr(args, 'posonlyargs', [])
    for a in posonlyargs:
        parameters.append({
            "name": a.arg,
            "kind": "posonly",
            "annotation": ast.unparse(a.annotation) if a.annotation else None,
            "default": None,
        })

    num_positional_defaults = len(args.defaults)
    num_positional_args = len(args.args)
    positional_default_offset = num_positional_args - num_positional_defaults

    for i, a in enumerate(args.args):
        default_idx = i - positional_default_offset
        default_val = None
        if default_idx >= 0:
            default_val = ast.unparse(args.defaults[default_idx])
        parameters.append({
            "name": a.arg,
            "kind": "positional",
            "annotation": ast.unparse(a.annotation) if a.annotation else None,
            "default": default_val,
        })

    if args.vararg:
        parameters.append({
            "name": args.vararg.arg,
            "kind": "vararg",
            "annotation": ast.unparse(args.vararg.annotation) if args.vararg.annotation else None,
            "default": None,
        })

    kwonlyargs = args.kwonlyargs
    kw_defaults = args.kw_defaults
    for i, a in enumerate(kwonlyargs):
        default_val = None
        if kw_defaults[i] is not None:
            default_val = ast.unparse(kw_defaults[i])
        parameters.append({
            "name": a.arg,
            "kind": "kwonly",
            "annotation": ast.unparse(a.annotation) if a.annotation else None,
            "default": default_val,
        })

    if args.kwarg:
        parameters.append({
            "name": args.kwarg.arg,
            "kind": "kwarg",
            "annotation": ast.unparse(args.kwarg.annotation) if args.kwarg.annotation else None,
            "default": None,
        })

    returns = ast.unparse(func_def.returns) if func_def.returns else None

    return {"name": name, "parameters": parameters, "returns": returns}


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    payload = payloads[0]
    overloads_raw = payload["overloads"]
    parsed = [_parse_signature(s) for s in overloads_raw]
    return {"name": contract["name"], "result": {"overloads": parsed}}
