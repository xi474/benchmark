import json
import math
import sys
from pathlib import Path


def _load_payload(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    def _check_finite(obj):
        if isinstance(obj, float):
            if not math.isfinite(obj):
                raise ValueError("non-finite number")
        elif isinstance(obj, dict):
            for v in obj.values():
                _check_finite(v)
        elif isinstance(obj, list):
            for v in obj:
                _check_finite(v)
    _check_finite(data)
    return data


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = _load_payload(contract_path)
    payloads = [_load_payload(root / p) for p in contract['inputs']]

    comp_dir = str(contract_path.parent)
    if comp_dir not in sys.path:
        sys.path.insert(0, comp_dir)
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

    from transform import transform as do_transform
    result = do_transform(payloads, contract)

    out = root / contract['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )
    return result


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    cp = Path(__file__).resolve().with_name('contract.json')
    build_component(root, cp)
