import re


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    snapshot = payloads[0]
    encoding_data = payloads[1]

    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be object")
    if not isinstance(encoding_data, dict):
        raise ValueError("encoding data must be object")

    boundary = snapshot.get('boundary')
    if boundary is None:
        raise ValueError("missing boundary")
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("boundary must be non-empty string")
    if not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError("invalid boundary characters")

    enc_parts = encoding_data.get('result', {}).get('parts') if 'result' in encoding_data else encoding_data.get('parts')
    if enc_parts is None:
        raise ValueError("missing parts in encoding data")

    boundary_bytes = boundary.encode('ascii')

    for part in enc_parts:
        payload_hex = part.get('payload_hex', '')
        payload_bytes = bytes.fromhex(payload_hex)
        if boundary_bytes in payload_bytes:
            raise ValueError("boundary found in payload")

    chunks = []

    for part in enc_parts:
        chunks.append(b'--' + boundary_bytes + b'\r\n')

        if part.get('encoding') == 'base64':
            chunks.append(b'Content-Transfer-Encoding: base64\r\n')

        mimetype = part.get('mimetype', 'application/octet-stream')
        chunks.append(f'Content-Type: {mimetype}\r\n'.encode('utf-8'))

        name = part.get('name', '')
        filename = part.get('filename')
        if filename is not None:
            disp = f'form-data; name="{name}"; filename="{filename}"\r\n'
        else:
            disp = f'form-data; name="{name}"\r\n'
        chunks.append(disp.encode('utf-8'))

        chunks.append(b'\r\n')

        payload_bytes = bytes.fromhex(part.get('payload_hex', ''))
        chunks.append(payload_bytes)
        chunks.append(b'\r\n')

    chunks.append(b'--' + boundary_bytes + b'--\r\n')

    body = b''.join(chunks)

    return {
        'name': contract['name'],
        'result': {
            'content_type': f'multipart/form-data; boundary={boundary}',
            'body_hex': body.hex(),
        },
    }
