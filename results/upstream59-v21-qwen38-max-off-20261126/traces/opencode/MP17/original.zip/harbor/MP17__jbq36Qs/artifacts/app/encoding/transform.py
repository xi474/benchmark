import base64


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("input must be object")

    parts_in = inp.get('result', {}).get('parts') if 'result' in inp else inp.get('parts')
    if parts_in is None:
        raise ValueError("missing parts")

    out_parts = []
    for part in parts_in:
        encoding = part.get('encoding')
        hex_data = part.get('hex')

        if encoding not in ('raw', 'base64'):
            raise ValueError(f"unknown encoding: {encoding}")

        raw_bytes = bytes.fromhex(hex_data)

        if encoding == 'raw':
            payload_hex = raw_bytes.hex()
        else:
            encoded = base64.b64encode(raw_bytes).decode('ascii')
            lines = []
            for i in range(0, len(encoded), 76):
                lines.append(encoded[i:i+76])
            payload_str = '\r\n'.join(lines)
            payload_hex = payload_str.encode('ascii').hex()

        new_part = {}
        for k, v in part.items():
            new_part[k] = v
        new_part['payload_hex'] = payload_hex
        out_parts.append(new_part)

    return {
        'name': contract['name'],
        'result': {
            'parts': out_parts,
        },
    }
