import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    components = core.get('components', {})

    title = '\u6587\u672c\u3001\u5185\u8054\u5185\u5bb9\u548c\u6587\u4ef6\u7684 multipart \u7ec4\u88c5'
    component_count = len(components)

    core_str = json.dumps(
        core,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False,
    )
    sha256 = hashlib.sha256(core_str.encode('utf-8')).hexdigest()

    attention = set()
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get('blocked') is True:
            attention.add(name)
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if key in result and result[key] is False:
                attention.add(name)
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0:
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(name)
                elif isinstance(val, bool) and val is True:
                    attention.add(name)

    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': sorted(attention),
    }

    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )


if __name__ == '__main__':
    main()
