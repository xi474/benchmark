import re


_FIELD_NAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_SAFE_BASENAME_RE = re.compile(r'^[A-Za-z0-9_.\-]+$')
_MIME_RE = re.compile(r'^[^\s/]+/[^\s]+$')

_EXT_MAP = {
    '.txt': 'text/plain',
    '.json': 'application/json',
    '.jpg': 'image/jpeg',
}


def _safe_relative_path(p):
    if not p or not isinstance(p, str):
        raise ValueError("invalid path")
    if '\\' in p or ':' in p:
        raise ValueError("unsafe path characters")
    parts = p.split('/')
    for seg in parts:
        if not seg or seg == '.' or seg == '..':
            raise ValueError(f"unsafe path segment: {seg}")
    return p


def _guess_mime(filename):
    if filename is None:
        return 'application/octet-stream'
    dot = filename.rfind('.')
    if dot >= 0:
        ext = filename[dot:].lower()
        return _EXT_MAP.get(ext, 'application/octet-stream')
    return 'application/octet-stream'


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    inp = payloads[0]
    if not isinstance(inp, dict):
        raise ValueError("input must be object")

    fields = inp.get('fields')
    files = inp.get('files')
    boundary = inp.get('boundary')

    if fields is None or files is None or boundary is None:
        raise ValueError("missing required field")

    if not isinstance(fields, dict):
        raise ValueError("fields must be object")
    if not isinstance(files, dict):
        raise ValueError("files must be object")
    if not isinstance(boundary, str) or not boundary:
        raise ValueError("boundary must be non-empty string")
    if not re.match(r'^[A-Za-z0-9\-]+$', boundary):
        raise ValueError("boundary must be alphanumeric and hyphen only")

    for fpath in files:
        _safe_relative_path(fpath)

    parts_list = []

    for name, value in fields.items():
        if not _FIELD_NAME_RE.match(name):
            raise ValueError(f"invalid field name: {name}")

        if isinstance(value, str):
            raw_bytes = value.encode('utf-8')
            parts_list.append({
                'name': name,
                'filename': None,
                'mimetype': 'text/plain',
                'encoding': 'raw',
                'hex': raw_bytes.hex(),
            })
        elif isinstance(value, dict):
            if not value:
                raise ValueError(f"empty field object for {name}")

            content = value.get('content')
            filename = value.get('filename')
            mimetype = value.get('mimetype')

            if content is not None:
                if not isinstance(content, str):
                    raise ValueError("content must be str")
                raw_bytes = content.encode('utf-8')
                encoding = 'raw'
                if filename is not None:
                    if not isinstance(filename, str) or not filename:
                        raise ValueError("invalid filename")
                    basename = filename.split('/')[-1] if '/' in filename else filename
                    if not _SAFE_BASENAME_RE.match(basename):
                        raise ValueError(f"unsafe basename: {basename}")
                    fn = basename
                else:
                    fn = None
            elif filename is not None:
                if not isinstance(filename, str) or not filename:
                    raise ValueError("invalid filename")
                _safe_relative_path(filename)
                basename = filename.split('/')[-1] if '/' in filename else filename
                if not _SAFE_BASENAME_RE.match(basename):
                    raise ValueError(f"unsafe basename: {basename}")
                if filename not in files:
                    raise ValueError(f"file not found: {filename}")
                hex_str = files[filename]
                raw_bytes = bytes.fromhex(hex_str)
                encoding = 'base64'
                fn = basename
            else:
                raise ValueError(f"field {name} has neither content nor filename")

            if mimetype is not None:
                if not isinstance(mimetype, str) or not _MIME_RE.match(mimetype):
                    raise ValueError(f"invalid mimetype: {mimetype}")
                mt = mimetype
            else:
                mt = _guess_mime(fn)

            parts_list.append({
                'name': name,
                'filename': fn,
                'mimetype': mt,
                'encoding': encoding,
                'hex': raw_bytes.hex(),
            })
        else:
            raise ValueError(f"invalid field value type for {name}")

    parts_list.sort(key=lambda p: p['name'])

    return {
        'name': contract['name'],
        'result': {
            'parts': parts_list,
        },
    }
