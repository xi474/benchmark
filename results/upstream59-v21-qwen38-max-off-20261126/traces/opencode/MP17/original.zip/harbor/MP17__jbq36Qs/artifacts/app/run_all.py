import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        if 'outputs' in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)

    dep_graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        deps = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                dep_name = inp.split('/')[1].replace('.json', '')
                deps.add(dep_name)
        dep_graph[name] = (cp, deps)

    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visiting:
            print(f"circular dependency detected: {name}", file=sys.stderr)
            sys.exit(1)
        if name in visited:
            return
        visiting.add(name)
        if name not in dep_graph:
            print(f"missing dependency: {name}", file=sys.stderr)
            sys.exit(1)
        cp, deps = dep_graph[name]
        for d in sorted(deps):
            visit(d)
        visiting.discard(name)
        visited.add(name)
        ordered.append((name, cp))

    for name in sorted(dep_graph.keys()):
        visit(name)

    for name, cp in ordered:
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f"render.py not found for {name}", file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            print(f"component {name} failed", file=sys.stderr)
            sys.exit(1)

    integrate_result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        timeout=60,
    )
    if integrate_result.returncode != 0:
        print("integrate.py failed", file=sys.stderr)
        sys.exit(1)

    final_result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        timeout=60,
    )
    if final_result.returncode != 0:
        print("final_report.py failed", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
