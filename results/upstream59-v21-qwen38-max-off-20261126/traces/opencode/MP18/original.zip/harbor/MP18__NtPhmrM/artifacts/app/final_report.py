import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core_text = core_path.read_text(encoding="utf-8")
    core = json.loads(core_text)

    components = core.get("components", {})

    sha_input = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256_hex = hashlib.sha256(sha_input).hexdigest()

    attention = set()
    for comp_name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.add(comp_name)
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                attention.add(comp_name)
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict)) and len(val) > 0:
                    attention.add(comp_name)
                elif isinstance(val, str) and len(val) > 0:
                    attention.add(comp_name)

    report = {
        "title": "\u96c6\u5408\u6587\u4ef6\u6e05\u5355\u7684\u6307\u4ee4\u9009\u62e9\u4e0e\u5f52\u6863\u5143\u6570\u636e",
        "component_count": len(components),
        "sha256": sha256_hex,
        "attention": sorted(attention),
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
