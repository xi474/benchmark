import hashlib


def transform(payloads, contract):
    if len(payloads) != 2:
        raise ValueError(f"expected 2 payloads, got {len(payloads)}")
    inventory_data = payloads[0]
    selection_data = payloads[1]

    if not isinstance(inventory_data, dict):
        raise ValueError("inventory payload must be object")
    if not isinstance(selection_data, dict):
        raise ValueError("selection payload must be object")

    inv = inventory_data.get("result", inventory_data)
    sel = selection_data.get("result", selection_data)

    file_map = {}
    for f in inv.get("files", []):
        file_map[f["path"]] = f["hex"]

    selected = sel.get("selected", [])
    if not isinstance(selected, list):
        raise ValueError("selected must be array")

    seen = set()
    entries = []
    total_bytes = 0

    for path in selected:
        if path in seen:
            raise ValueError(f"duplicate in selected: {path!r}")
        seen.add(path)
        if path not in file_map:
            raise ValueError(f"selected path not in inventory: {path!r}")
        hex_str = file_map[path]
        raw_bytes = bytes.fromhex(hex_str)
        size = len(raw_bytes)
        sha = hashlib.sha256(raw_bytes).hexdigest()
        entries.append({"path": path, "size": size, "sha256": sha})
        total_bytes += size

    result = {"entries": entries, "total_bytes": total_bytes}
    return {"name": contract["name"], "result": result}
