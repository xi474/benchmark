def _validate_safe_relative_path(p):
    if not p or not isinstance(p, str):
        raise ValueError(f"invalid path: {p!r}")
    if "\\" in p or ":" in p:
        raise ValueError(f"unsafe path: {p!r}")
    parts = p.split("/")
    for part in parts:
        if part == "" or part == "." or part == "..":
            raise ValueError(f"unsafe path segment in: {p!r}")


def _validate_hex(h):
    if not isinstance(h, str):
        raise ValueError(f"hex must be string, got {type(h).__name__}")
    try:
        bytes.fromhex(h)
    except ValueError:
        raise ValueError(f"invalid hex: {h!r}")


def transform(payloads, contract):
    if len(payloads) != 1:
        raise ValueError(f"expected 1 payload, got {len(payloads)}")
    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("payload must be object")
    if "files" not in data:
        raise ValueError("missing 'files' field")
    files_list = data["files"]
    if not isinstance(files_list, list):
        raise ValueError("'files' must be array")

    seen_paths = set()
    regular_files = []
    symlinks = []

    for entry in files_list:
        if not isinstance(entry, dict):
            raise ValueError("each file entry must be object")
        if "path" not in entry or "kind" not in entry:
            raise ValueError("file entry missing required fields")
        path = entry["path"]
        kind = entry["kind"]
        if not isinstance(path, str) or not isinstance(kind, str):
            raise ValueError("path and kind must be strings")
        if kind not in ("file", "symlink"):
            raise ValueError(f"invalid kind: {kind!r}")

        _validate_safe_relative_path(path)

        if path in seen_paths:
            raise ValueError(f"duplicate path: {path!r}")
        seen_paths.add(path)

        if kind == "file":
            if "hex" not in entry:
                raise ValueError(f"file entry missing hex: {path!r}")
            hex_val = entry["hex"]
            _validate_hex(hex_val)
            target = entry.get("target")
            if target is not None:
                raise ValueError(f"file entry should have null target: {path!r}")
            regular_files.append({"path": path, "hex": hex_val})
        elif kind == "symlink":
            if "target" not in entry:
                raise ValueError(f"symlink entry missing target: {path!r}")
            target = entry["target"]
            if not isinstance(target, str):
                raise ValueError(f"symlink target must be string: {path!r}")
            _validate_safe_relative_path(target)
            hex_val = entry.get("hex")
            if hex_val is not None and hex_val != "":
                pass
            symlinks.append(path)

    regular_files.sort(key=lambda x: x["path"])
    symlinks.sort()

    result = {"files": regular_files, "symlinks": symlinks}
    return {"name": contract["name"], "result": result}
