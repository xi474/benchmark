import fnmatch


def _is_under_git(path):
    parts = path.split("/")
    for part in parts:
        if part == ".git":
            return True
    return False


def _matches_any_glob(path, patterns):
    for pat in patterns:
        if fnmatch.fnmatchcase(path, pat):
            return True
    return False


def _basename(path):
    idx = path.rfind("/")
    if idx < 0:
        return path
    return path[idx + 1:]


def transform(payloads, contract):
    if len(payloads) != 2:
        raise ValueError(f"expected 2 payloads, got {len(payloads)}")
    case_data = payloads[0]
    inventory_result = payloads[1]

    if not isinstance(case_data, dict):
        raise ValueError("case payload must be object")
    if not isinstance(inventory_result, dict):
        raise ValueError("inventory payload must be object")

    if "name" in inventory_result and "result" in inventory_result:
        inv = inventory_result["result"]
    else:
        inv = inventory_result

    all_file_paths = [f["path"] for f in inv.get("files", [])]

    manifest = case_data.get("manifest")
    build_ignore = case_data.get("build_ignore")

    if manifest is not None and build_ignore is not None:
        raise ValueError("manifest and build_ignore cannot both be non-null")

    if manifest is None:
        selected = set(all_file_paths)
        if build_ignore is not None:
            if not isinstance(build_ignore, list):
                raise ValueError("build_ignore must be array")
            filtered = set()
            for p in selected:
                if not _matches_any_glob(p, build_ignore):
                    filtered.add(p)
            selected = filtered
    else:
        if not isinstance(manifest, str):
            raise ValueError("manifest must be string")
        selected = set()
        lines = manifest.split("\n")
        for line in lines:
            stripped = line.strip()
            if stripped == "" or stripped.startswith("#"):
                continue
            tokens = stripped.split(None, 1)
            cmd = tokens[0]
            if cmd == "include":
                if len(tokens) < 2:
                    raise ValueError(f"include requires pattern: {stripped!r}")
                pattern = tokens[1]
                for p in all_file_paths:
                    if fnmatch.fnmatchcase(p, pattern):
                        selected.add(p)
            elif cmd == "exclude":
                if len(tokens) < 2:
                    raise ValueError(f"exclude requires pattern: {stripped!r}")
                pattern = tokens[1]
                to_remove = set()
                for p in selected:
                    if fnmatch.fnmatchcase(p, pattern):
                        to_remove.add(p)
                selected -= to_remove
            elif cmd == "recursive-include":
                if len(tokens) < 2:
                    raise ValueError(f"recursive-include requires DIR PATTERN: {stripped!r}")
                rest = tokens[1]
                parts = rest.split(None, 1)
                if len(parts) < 2:
                    raise ValueError(f"recursive-include requires DIR PATTERN: {stripped!r}")
                dir_prefix = parts[0]
                pattern = parts[1]
                if not dir_prefix.endswith("/"):
                    dir_prefix_slash = dir_prefix + "/"
                else:
                    dir_prefix_slash = dir_prefix
                for p in all_file_paths:
                    if p.startswith(dir_prefix_slash) or p == dir_prefix:
                        bn = _basename(p)
                        if fnmatch.fnmatchcase(bn, pattern):
                            selected.add(p)
            elif cmd == "global-exclude":
                if len(tokens) < 2:
                    raise ValueError(f"global-exclude requires pattern: {stripped!r}")
                pattern = tokens[1]
                to_remove = set()
                for p in selected:
                    bn = _basename(p)
                    if fnmatch.fnmatchcase(bn, pattern):
                        to_remove.add(p)
                selected -= to_remove
            else:
                raise ValueError(f"unknown manifest command: {cmd!r}")

    final = set()
    for p in selected:
        if _is_under_git(p):
            continue
        bn = _basename(p)
        if bn.endswith(".pyc"):
            continue
        if p == "MANIFEST.in":
            continue
        final.add(p)

    result = {"selected": sorted(final)}
    return {"name": contract["name"], "result": result}
