import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)

    graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        deps = set()
        for inp in c["inputs"]:
            inp_path = ROOT / inp
            for other_cp in contracts:
                other_c = json.loads(other_cp.read_text(encoding="utf-8"))
                if ROOT / other_c["output"] == inp_path:
                    deps.add(other_c["name"])
        graph[name] = {"cp": cp, "deps": deps}

    ordered = []
    visited = set()
    visiting = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            raise ValueError(f"circular dependency involving {name}")
        visiting.add(name)
        for dep in graph[name]["deps"]:
            visit(dep)
        visiting.remove(name)
        visited.add(name)
        ordered.append(name)

    for name in sorted(graph.keys()):
        visit(name)

    for name in ordered:
        cp = graph[name]["cp"]
        render_py = cp.with_name("render.py")
        if not render_py.exists():
            raise ValueError(f"render.py missing for {name}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"component {name} failed with code {result.returncode}")

    integrate_py = ROOT / "integrate.py"
    if integrate_py.exists():
        result = subprocess.run(
            [sys.executable, str(integrate_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"integrate.py failed with code {result.returncode}")

    final_report_py = ROOT / "final_report.py"
    if final_report_py.exists():
        result = subprocess.run(
            [sys.executable, str(final_report_py)],
            cwd=ROOT,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(f"final_report.py failed with code {result.returncode}")


if __name__ == "__main__":
    main()
