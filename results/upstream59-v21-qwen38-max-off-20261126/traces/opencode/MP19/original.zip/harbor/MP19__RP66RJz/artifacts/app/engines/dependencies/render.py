import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    c = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in c["inputs"]]
    return transform(payloads, c)


if __name__ == "__main__":
    cp = Path(__file__).with_name("contract.json")
    root = Path(__file__).resolve().parents[2]
    result = build_component(root, cp)
    c = load_payload(cp)
    out = root / c["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
