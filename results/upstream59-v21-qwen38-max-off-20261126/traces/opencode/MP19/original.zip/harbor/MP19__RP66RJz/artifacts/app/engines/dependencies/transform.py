from collections import deque


def _path_to_module(path):
    if path.endswith("/__init__.py"):
        p = path[: -len("/__init__.py")]
        return p.replace("/", ".") if p else ""
    if path == "__init__.py":
        return ""
    if path.endswith(".py"):
        return path[:-3].replace("/", ".")
    raise ValueError(f"not a python file: {path}")


def _module_to_paths(mod_name):
    if mod_name == "":
        return ["__init__.py"]
    parts = mod_name.split(".")
    return ["/".join(parts) + "/__init__.py", "/".join(parts) + ".py"]


def transform(payloads, contract):
    case = payloads[0]
    scan_result = payloads[1]

    if isinstance(scan_result, dict) and set(scan_result.keys()) == {"name", "result"}:
        scan_data = scan_result["result"]
    else:
        scan_data = scan_result

    modules = case["modules"]
    entry = case["entry"]
    externals = set(case.get("externals", []))
    aliases = case.get("aliases", {})

    imports_map = scan_data["imports"]
    module_paths = scan_data["module_paths"]

    local_mod_set = set(module_paths.keys())

    reverse_map = {}
    for mod_name, p in module_paths.items():
        reverse_map[p] = mod_name

    visited_paths = set()
    external_used = set()
    queue = deque()

    queue.append(entry)
    visited_paths.add(entry)

    while queue:
        current_path = queue.popleft()
        if current_path not in imports_map:
            continue

        dep_names = imports_map[current_path]
        for dep in dep_names:
            resolved = aliases.get(dep, dep)

            is_local = False
            if dep in local_mod_set:
                is_local = True
            elif resolved in local_mod_set:
                is_local = True
            else:
                for lm in local_mod_set:
                    if lm.startswith(dep + ".") or lm.startswith(resolved + "."):
                        is_local = True
                        break

            if is_local:
                target_mod = dep if dep in local_mod_set else resolved
                target_path = module_paths[target_mod]
                if target_path not in visited_paths:
                    visited_paths.add(target_path)
                    queue.append(target_path)

                parts = target_mod.split(".") if target_mod else []
                for i in range(len(parts)):
                    parent_mod = ".".join(parts[: i + 1])
                    if parent_mod in module_paths:
                        pp = module_paths[parent_mod]
                        if pp not in visited_paths:
                            visited_paths.add(pp)
                            queue.append(pp)
            else:
                top = resolved.split(".")[0]
                if top in externals or resolved in externals:
                    external_used.add(resolved)
                else:
                    raise ValueError(f"unknown external module: {dep}")

    all_paths = sorted(visited_paths)
    external_sorted = sorted(external_used)

    return {
        "name": contract["name"],
        "result": {"paths": all_paths, "external": external_sorted},
    }
