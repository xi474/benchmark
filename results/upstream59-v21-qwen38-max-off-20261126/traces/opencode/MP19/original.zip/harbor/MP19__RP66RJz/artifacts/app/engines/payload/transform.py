import hashlib
import io
import struct
import time
import zipfile


def transform(payloads, contract):
    case = payloads[0]
    dep_result = payloads[1]

    if isinstance(dep_result, dict) and set(dep_result.keys()) == {"name", "result"}:
        dep_data = dep_result["result"]
    else:
        dep_data = dep_result

    modules = case["modules"]
    paths = dep_data["paths"]
    external = dep_data["external"]

    seen = set()
    for p in paths:
        if p in seen:
            raise ValueError(f"duplicate path: {p}")
        seen.add(p)

    has_root_init = "__init__.py" in paths
    zip_paths = list(paths)
    if not has_root_init:
        zip_paths.append("__init__.py")
        zip_paths.sort()

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_STORED) as zf:
        for p in zip_paths:
            if p == "__init__.py" and p not in modules:
                data = b""
            elif p in modules:
                data = modules[p].encode("utf-8")
            else:
                raise ValueError(f"source path not found: {p}")

            info = zipfile.ZipInfo(filename=p)
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o644 << 16
            zf.writestr(info, data)

    zip_bytes = buf.getvalue()
    zip_hex = zip_bytes.hex()
    sha256 = hashlib.sha256(zip_bytes).hexdigest()

    return {
        "name": contract["name"],
        "result": {
            "paths": zip_paths,
            "zip_hex": zip_hex,
            "sha256": sha256,
            "external": external,
        },
    }
