import ast


def _path_to_module(path):
    if path.endswith("/__init__.py"):
        p = path[: -len("/__init__.py")]
        return p.replace("/", ".") if p else ""
    if path == "__init__.py":
        return ""
    if path.endswith(".py"):
        return path[:-3].replace("/", ".")
    raise ValueError(f"not a python file: {path}")


def _is_local(mod_name, local_set):
    if mod_name in local_set:
        return True
    for lm in local_set:
        if lm.startswith(mod_name + "."):
            return True
    return False


def _resolve_import(name, local_set, externals, aliases):
    if _is_local(name, local_set):
        return name, True
    resolved = aliases.get(name, name)
    top = resolved.split(".")[0]
    if top in externals or resolved in externals:
        return name, False
    raise ValueError(f"unknown module: {name}")


def transform(payloads, contract):
    case = payloads[0]
    modules = case["modules"]
    externals = set(case.get("externals", []))
    aliases = case.get("aliases", {})

    local_set = set()
    module_paths = {}
    for p in modules:
        mod_name = _path_to_module(p)
        local_set.add(mod_name)
        module_paths[mod_name] = p

    imports = {}

    for path in modules:
        source = modules[path]
        try:
            tree = ast.parse(source, filename=path)
        except SyntaxError:
            imports[path] = []
            continue

        current_mod = _path_to_module(path)
        if "/" in path:
            pkg_parts = path.split("/")[:-1]
        else:
            pkg_parts = []

        deps = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias_node in node.names:
                    name = alias_node.name
                    _resolve_import(name, local_set, externals, aliases)
                    deps.add(name)

            elif isinstance(node, ast.ImportFrom):
                if node.level == 0 and node.module is None:
                    raise ValueError("bare from import forbidden")
                if node.names and any(a.name == "*" for a in node.names):
                    raise ValueError("from * import forbidden")

                if node.level > 0:
                    up = node.level - 1
                    if up > len(pkg_parts):
                        raise ValueError(f"relative import beyond root in {path}")
                    if up > 0:
                        base_parts = pkg_parts[:-up]
                    else:
                        base_parts = pkg_parts[:]
                    if node.module:
                        full_parts = base_parts + node.module.split(".")
                    else:
                        full_parts = base_parts
                    base_mod = ".".join(full_parts)

                    found = False
                    for a in node.names:
                        candidate = (base_mod + "." + a.name) if base_mod else a.name
                        if candidate in local_set:
                            deps.add(candidate)
                            found = True
                        else:
                            has_sub = any(lm.startswith(candidate + ".") for lm in local_set)
                            if has_sub:
                                deps.add(candidate)
                                found = True

                    if not found:
                        if base_mod in local_set:
                            pass
                        has_sub = any(lm.startswith(base_mod + ".") for lm in local_set)
                        if not has_sub and base_mod not in local_set:
                            resolved = aliases.get(base_mod, base_mod)
                            top = resolved.split(".")[0]
                            if top in externals or resolved in externals:
                                deps.add(base_mod)
                            else:
                                raise ValueError(f"unknown relative module: {base_mod}")
                else:
                    mod = node.module
                    found = False
                    for a in node.names:
                        candidate = mod + "." + a.name
                        if candidate in local_set:
                            deps.add(candidate)
                            found = True
                        else:
                            has_sub = any(lm.startswith(candidate + ".") for lm in local_set)
                            if has_sub:
                                deps.add(candidate)
                                found = True

                    if not found:
                        if mod in local_set:
                            pass
                        has_sub = any(lm.startswith(mod + ".") for lm in local_set)
                        if not has_sub and mod not in local_set:
                            resolved = aliases.get(mod, mod)
                            top = resolved.split(".")[0]
                            if top in externals or resolved in externals:
                                deps.add(mod)
                            else:
                                raise ValueError(f"unknown module: {mod}")

        imports[path] = sorted(deps)

    return {
        "name": contract["name"],
        "result": {"imports": imports, "module_paths": module_paths},
    }
