import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = sorted(
        [x for x in ROOT.rglob("contract.json") if "outputs" not in x.relative_to(ROOT).parts]
    )
    if not contracts:
        raise ValueError("no contracts found")

    remaining = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        remaining[cp] = c

    produced = set()
    order = []

    while remaining:
        progress = False
        for cp, c in list(remaining.items()):
            deps_met = True
            for inp in c["inputs"]:
                if inp.startswith("outputs/"):
                    if inp not in produced:
                        deps_met = False
                        break
                else:
                    p = ROOT / inp
                    if not p.exists():
                        deps_met = False
                        break
            if deps_met:
                order.append((cp, c))
                del remaining[cp]
                produced.add(c["output"])
                progress = True
        if not progress:
            raise ValueError("circular or unresolvable dependencies")

    for cp, c in order:
        render_py = cp.with_name("render.py")
        if not render_py.is_file():
            raise ValueError(f"missing render.py for {c['name']}")
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            print(result.stderr, file=sys.stderr)
            raise RuntimeError(f"component {c['name']} failed")

    integrate = ROOT / "integrate.py"
    result = subprocess.run(
        [sys.executable, str(integrate)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        raise RuntimeError("integrate failed")

    final_report = ROOT / "final_report.py"
    result = subprocess.run(
        [sys.executable, str(final_report)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        raise RuntimeError("final_report failed")


if __name__ == "__main__":
    main()
