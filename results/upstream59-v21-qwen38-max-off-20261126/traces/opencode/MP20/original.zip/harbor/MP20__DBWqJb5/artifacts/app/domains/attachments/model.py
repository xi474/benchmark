import json
from pathlib import Path


def _validate_finite(obj, path=""):
    if isinstance(obj, bool):
        return
    if isinstance(obj, float):
        if not (obj == obj) or obj in (float('inf'), float('-inf')):
            raise ValueError(f"non-finite number at {path}")
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            _validate_finite(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _validate_finite(v, f"{path}[{i}]")


def load_payload(path):
    p = Path(path)
    text = p.read_text(encoding='utf-8')
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"invalid JSON: {e}") from e
    if not isinstance(data, (dict, list)):
        raise ValueError("top-level must be object or array")
    _validate_finite(data)
    return data
