import json
from pathlib import Path

from model import load_payload
from transform import transform


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract['inputs']]
    return transform(payloads, contract)


if __name__ == "__main__":
    import sys
    root = Path(__file__).resolve().parents[2]
    contract_path = Path(__file__).resolve().with_name('contract.json')
    result = build_component(root, contract_path)
    out = root / json.loads(contract_path.read_text(encoding='utf-8'))['output']
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )
