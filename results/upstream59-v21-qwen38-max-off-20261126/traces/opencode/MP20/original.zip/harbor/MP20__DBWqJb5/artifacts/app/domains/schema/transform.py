import copy


def _validate_string(val, context):
    if not isinstance(val, str):
        raise ValueError(f"{context}: expected string")
    if not val or not val.strip():
        raise ValueError(f"{context}: empty or blank string")


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    for key in ('flags', 'segments'):
        if key not in data:
            raise ValueError(f"missing field: {key}")

    flags = data['flags']
    segments = data['segments']

    if not isinstance(flags, list):
        raise ValueError("flags must be array")
    if not isinstance(segments, list):
        raise ValueError("segments must be array")

    flag_ids = set()
    for fi, flag in enumerate(flags):
        if not isinstance(flag, dict):
            raise ValueError(f"flag[{fi}] must be object")
        if 'id' not in flag:
            raise ValueError(f"flag[{fi}] missing id")
        _validate_string(flag['id'], f"flag[{fi}].id")
        if flag['id'] in flag_ids:
            raise ValueError(f"duplicate flag id: {flag['id']}")
        flag_ids.add(flag['id'])

        if 'variants' not in flag:
            raise ValueError(f"flag[{fi}] missing variants")
        if 'rules' not in flag:
            raise ValueError(f"flag[{fi}] missing rules")

        variants = flag['variants']
        rules = flag['rules']

        if not isinstance(variants, list):
            raise ValueError(f"flag[{fi}].variants must be array")
        if not isinstance(rules, list):
            raise ValueError(f"flag[{fi}].rules must be array")

        variant_ids = set()
        for vi, variant in enumerate(variants):
            if not isinstance(variant, dict):
                raise ValueError(f"flag[{fi}].variant[{vi}] must be object")
            if 'id' not in variant:
                raise ValueError(f"flag[{fi}].variant[{vi}] missing id")
            _validate_string(variant['id'], f"flag[{fi}].variant[{vi}].id")
            if variant['id'] in variant_ids:
                raise ValueError(f"duplicate variant id in flag {flag['id']}: {variant['id']}")
            variant_ids.add(variant['id'])
            if 'attachment' not in variant:
                raise ValueError(f"flag[{fi}].variant[{vi}] missing attachment")

        rule_ids = set()
        for ri, rule in enumerate(rules):
            if not isinstance(rule, dict):
                raise ValueError(f"flag[{fi}].rule[{ri}] must be object")
            if 'id' not in rule:
                raise ValueError(f"flag[{fi}].rule[{ri}] missing id")
            _validate_string(rule['id'], f"flag[{fi}].rule[{ri}].id")
            if rule['id'] in rule_ids:
                raise ValueError(f"duplicate rule id in flag {flag['id']}: {rule['id']}")
            rule_ids.add(rule['id'])
            if 'segment' not in rule:
                raise ValueError(f"flag[{fi}].rule[{ri}] missing segment")
            _validate_string(rule['segment'], f"flag[{fi}].rule[{ri}].segment")
            if 'variant' not in rule:
                raise ValueError(f"flag[{fi}].rule[{ri}] missing variant")
            _validate_string(rule['variant'], f"flag[{fi}].rule[{ri}].variant")

    segment_ids = set()
    for si, seg in enumerate(segments):
        if not isinstance(seg, dict):
            raise ValueError(f"segment[{si}] must be object")
        if 'id' not in seg:
            raise ValueError(f"segment[{si}] missing id")
        _validate_string(seg['id'], f"segment[{si}].id")
        if seg['id'] in segment_ids:
            raise ValueError(f"duplicate segment id: {seg['id']}")
        segment_ids.add(seg['id'])

    result = {
        "flags": copy.deepcopy(flags),
        "segments": copy.deepcopy(segments)
    }

    return {"name": contract["name"], "result": result}
