import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    if not contracts:
        print("no contracts found", file=sys.stderr)
        sys.exit(1)

    contract_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        contract_map[c['name']] = (cp, c)

    produced = set()
    order = []

    def resolve(name):
        if name in produced:
            return
        cp, c = contract_map[name]
        for inp in c['inputs']:
            inp_path = ROOT / inp
            if inp_path.exists():
                continue
            for other_name, (_, other_c) in contract_map.items():
                if other_c['output'] == inp:
                    resolve(other_name)
                    break
        order.append(name)
        produced.add(name)

    for name in sorted(contract_map.keys()):
        resolve(name)

    for name in order:
        cp, c = contract_map[name]
        render_py = cp.with_name('render.py')
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(f"Component {name} failed:", file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            sys.exit(1)

    integrate_result = subprocess.run(
        [sys.executable, str(ROOT / 'integrate.py')],
        cwd=ROOT,
        capture_output=True,
        text=True
    )
    if integrate_result.returncode != 0:
        print("integrate.py failed:", file=sys.stderr)
        print(integrate_result.stderr, file=sys.stderr)
        sys.exit(1)

    final_result = subprocess.run(
        [sys.executable, str(ROOT / 'final_report.py')],
        cwd=ROOT,
        capture_output=True,
        text=True
    )
    if final_result.returncode != 0:
        print("final_report.py failed:", file=sys.stderr)
        print(final_result.stderr, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
