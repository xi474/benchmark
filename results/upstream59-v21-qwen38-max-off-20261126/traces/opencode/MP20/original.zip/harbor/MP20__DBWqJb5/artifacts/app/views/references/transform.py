def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    schema_result = payloads[0]
    if not isinstance(schema_result, dict):
        raise ValueError("schema result must be object")

    if 'result' in schema_result and 'name' in schema_result and len(schema_result) == 2:
        data = schema_result['result']
    else:
        data = schema_result

    flags = data.get('flags', [])
    segments = data.get('segments', [])

    segment_ids = set()
    for seg in segments:
        segment_ids.add(seg['id'])

    sorted_flags = sorted(flags, key=lambda f: f['id'])
    for flag in sorted_flags:
        flag_id = flag['id']
        sorted_rules = sorted(flag.get('rules', []), key=lambda r: r['id'])
        for rule in sorted_rules:
            rule_id = rule['id']
            target_seg = rule['segment']
            if target_seg not in segment_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "segment",
                            "flag": flag_id,
                            "rule": rule_id,
                            "target": target_seg
                        }
                    }
                }

    for flag in sorted_flags:
        flag_id = flag['id']
        variant_ids = set()
        for v in flag.get('variants', []):
            variant_ids.add(v['id'])

        sorted_rules = sorted(flag.get('rules', []), key=lambda r: r['id'])
        for rule in sorted_rules:
            rule_id = rule['id']
            target_var = rule['variant']
            if target_var not in variant_ids:
                return {
                    "name": contract["name"],
                    "result": {
                        "ok": False,
                        "error": {
                            "kind": "variant",
                            "flag": flag_id,
                            "rule": rule_id,
                            "target": target_var
                        }
                    }
                }

    return {
        "name": contract["name"],
        "result": {
            "ok": True,
            "error": None
        }
    }
