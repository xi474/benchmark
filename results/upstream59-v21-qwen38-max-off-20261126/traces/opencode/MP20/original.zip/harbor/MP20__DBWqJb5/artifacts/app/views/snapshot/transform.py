import copy
import json


def transform(payloads, contract):
    if len(payloads) != len(contract['inputs']):
        raise ValueError("payload count mismatch")

    raw_input = payloads[0]
    schema_result = payloads[1]
    attachments_result = payloads[2]
    references_result = payloads[3]

    def unwrap(obj):
        if isinstance(obj, dict) and 'result' in obj and 'name' in obj and len(obj) == 2:
            return obj['result']
        return obj

    schema_data = unwrap(schema_result)
    attachments_data = unwrap(attachments_result)
    references_data = unwrap(references_result)

    old_snapshot = raw_input.get('old_snapshot', {})

    if not references_data.get('ok', False):
        error = references_data.get('error')
        return {
            "name": contract["name"],
            "result": {
                "committed": False,
                "snapshot": old_snapshot,
                "error": error,
                "export": None
            }
        }

    flags = schema_data.get('flags', [])
    segments = schema_data.get('segments', [])
    attachments_map = attachments_data.get('attachments', {})

    snapshot_flags = []
    for flag in sorted(flags, key=lambda f: f['id']):
        flag_id = flag['id']
        flag_attachments = attachments_map.get(flag_id, {})

        variants_out = []
        for variant in sorted(flag.get('variants', []), key=lambda v: v['id']):
            vid = variant['id']
            att_info = flag_attachments.get(vid, {})
            value = att_info.get('value', variant.get('attachment'))
            variants_out.append({"id": vid, "attachment": value})

        rules_out = []
        for rule in sorted(flag.get('rules', []), key=lambda r: r['id']):
            rules_out.append(copy.deepcopy(rule))

        snapshot_flags.append({
            "id": flag_id,
            "variants": variants_out,
            "rules": rules_out
        })

    snapshot_segments = []
    for seg in sorted(segments, key=lambda s: s['id']):
        snapshot_segments.append(copy.deepcopy(seg))

    snapshot = {
        "flags": snapshot_flags,
        "segments": snapshot_segments
    }

    export_str = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

    return {
        "name": contract["name"],
        "result": {
            "committed": True,
            "snapshot": snapshot,
            "error": None,
            "export": export_str
        }
    }
