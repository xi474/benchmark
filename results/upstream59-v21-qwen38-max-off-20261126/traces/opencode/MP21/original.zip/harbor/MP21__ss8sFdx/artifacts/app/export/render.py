import json
import sys
from pathlib import Path


def build_component(root, contract_path):
    root = Path(root)
    contract_path = Path(contract_path)
    pkg_dir = str(Path(__file__).resolve().parent)
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)
    root_str = str(root)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)
    from model import load_payload
    from transform import transform
    contract = load_payload(contract_path)
    payloads = [load_payload(root / p) for p in contract["inputs"]]
    return transform(payloads, contract)


if __name__ == "__main__":
    cp = Path(__file__).resolve().with_name("contract.json")
    root = cp.resolve().parents[1]
    result = build_component(root, cp)
    out = root / json.loads(cp.read_text(encoding="utf-8"))["output"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
