from decimal import Decimal, ROUND_HALF_UP


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")
    if set(data) != {"name", "result"}:
        pass
    if "result" in data and "name" in data:
        inner = data["result"]
    else:
        inner = data

    if not isinstance(inner, dict):
        raise ValueError("playlist result must be object")
    if "playlist" not in inner:
        raise ValueError("missing playlist")
    if "tracks" not in inner:
        raise ValueError("missing tracks")

    playlist = inner["playlist"]
    tracks = inner["tracks"]

    name = playlist["name"]
    if "\r" in name or "\n" in name:
        raise ValueError("playlist name contains CR/LF")

    lines = ["#EXTM3U", f"#PLAYLIST:{name}"]

    for t in tracks:
        title = t.get("title", "")
        artist = t.get("artist", "")
        path = t.get("path", "")
        duration = t.get("duration", 0)

        if "\r" in title or "\n" in title:
            raise ValueError("title contains CR/LF")
        if "\r" in artist or "\n" in artist:
            raise ValueError("artist contains CR/LF")
        if "\r" in path or "\n" in path:
            raise ValueError("path contains CR/LF")

        d = Decimal(str(duration))
        seconds = int(d.quantize(Decimal("1"), rounding=ROUND_HALF_UP))

        lines.append(f"#EXTINF:{seconds},{artist} - {title}")
        lines.append(path)

    m3u = "\n".join(lines) + "\n"

    return {
        "name": contract["name"],
        "result": {
            "m3u": m3u,
        },
    }
