import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return False
        return True
    return False


def _validate_track(t):
    if not isinstance(t, dict):
        raise ValueError("track must be object")
    for k in ("id", "title", "artist", "path"):
        if k not in t:
            raise ValueError(f"missing track field: {k}")
        if not isinstance(t[k], str):
            raise ValueError(f"track field {k} must be string")
    if "duration" not in t:
        raise ValueError("missing track field: duration")
    if not _is_finite_number(t["duration"]):
        raise ValueError("duration must be finite number")
    if t["duration"] < 0:
        raise ValueError("duration must be non-negative")


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    for key in ("tracks", "playlist", "replacement", "criteria"):
        if key not in data:
            raise ValueError(f"missing field: {key}")

    tracks_list = data["tracks"]
    if not isinstance(tracks_list, list):
        raise ValueError("tracks must be array")

    track_map = {}
    for t in tracks_list:
        _validate_track(t)
        if t["id"] in track_map:
            raise ValueError(f"duplicate track id: {t['id']}")
        track_map[t["id"]] = t

    playlist = data["playlist"]
    if not isinstance(playlist, dict):
        raise ValueError("playlist must be object")
    for k in ("id", "name", "track_ids", "track_count", "duration"):
        if k not in playlist:
            raise ValueError(f"missing playlist field: {k}")
    if not isinstance(playlist["id"], str):
        raise ValueError("playlist id must be string")
    if not isinstance(playlist["name"], str):
        raise ValueError("playlist name must be string")
    if not isinstance(playlist["track_ids"], list):
        raise ValueError("track_ids must be array")
    if not isinstance(playlist["track_count"], int) or isinstance(playlist["track_count"], bool):
        raise ValueError("track_count must be int")
    if not _is_finite_number(playlist["duration"]):
        raise ValueError("playlist duration must be finite number")

    replacement = data["replacement"]
    if not isinstance(replacement, list):
        raise ValueError("replacement must be array")

    new_tracks = []
    total_duration = 0
    for tid in replacement:
        if not isinstance(tid, str):
            raise ValueError("replacement id must be string")
        if tid not in track_map:
            raise ValueError(f"unknown replacement track id: {tid}")
        t = track_map[tid]
        new_tracks.append({
            "id": t["id"],
            "title": t["title"],
            "artist": t["artist"],
            "path": t["path"],
            "duration": t["duration"],
        })
        total_duration += t["duration"]

    result_playlist = {
        "id": playlist["id"],
        "name": playlist["name"],
        "track_ids": list(replacement),
        "track_count": len(replacement),
        "duration": total_duration,
    }

    return {
        "name": contract["name"],
        "result": {
            "playlist": result_playlist,
            "tracks": new_tracks,
        },
    }
