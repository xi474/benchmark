import math


def _is_finite_number(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return False
        return True
    return False


_VALID_FIELDS = {"id", "name", "track_count", "duration"}
_VALID_OPS = {"eq", "ne", "gt", "ge", "lt", "le"}
_STR_FIELDS = {"id", "name"}
_NUM_FIELDS = {"track_count", "duration"}

_OP_MAP = {
    "eq": "=",
    "ne": "!=",
    "gt": ">",
    "ge": ">=",
    "lt": "<",
    "le": "<=",
}


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")

    data = payloads[0]
    if not isinstance(data, dict):
        raise ValueError("input must be object")

    if "criteria" not in data:
        raise ValueError("missing field: criteria")

    criteria = data["criteria"]
    if not isinstance(criteria, dict):
        raise ValueError("criteria must be object")

    if "filters" not in criteria:
        raise ValueError("missing field: filters")
    if "limit" not in criteria:
        raise ValueError("missing field: limit")

    filters = criteria["filters"]
    if not isinstance(filters, list):
        raise ValueError("filters must be array")

    limit = criteria["limit"]
    if isinstance(limit, bool) or not isinstance(limit, int):
        raise ValueError("limit must be int")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be 1..100")

    clauses = []
    params = []

    for f in filters:
        if not isinstance(f, dict):
            raise ValueError("filter must be object")
        for k in ("field", "op", "value"):
            if k not in f:
                raise ValueError(f"missing filter field: {k}")

        field = f["field"]
        op = f["op"]
        value = f["value"]

        if not isinstance(field, str) or field not in _VALID_FIELDS:
            raise ValueError(f"invalid field: {field}")
        if not isinstance(op, str) or op not in _VALID_OPS:
            raise ValueError(f"invalid op: {op}")

        if field in _STR_FIELDS:
            if not isinstance(value, str):
                raise ValueError(f"value for {field} must be string")
            if op not in ("eq", "ne"):
                raise ValueError(f"field {field} only supports eq/ne")
        elif field in _NUM_FIELDS:
            if not _is_finite_number(value):
                raise ValueError(f"value for {field} must be finite number")
            if isinstance(value, bool):
                raise ValueError(f"value for {field} must not be bool")
            if value < 0:
                raise ValueError(f"value for {field} must be non-negative")

        sql_op = _OP_MAP[op]
        clauses.append(f"{field} {sql_op} ?")
        params.append(value)

    sql = "SELECT id FROM playlists"
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)

    return {
        "name": contract["name"],
        "result": {
            "sql": sql,
            "params": params,
        },
    }
