import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        contracts.append(cp)

    if not contracts:
        raise ValueError("no contracts found")

    dep_map = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        dep_map[c["name"]] = {
            "contract_path": cp,
            "inputs": c["inputs"],
            "output": c["output"],
        }

    resolved = set()
    order = []

    def resolve(name):
        if name in resolved:
            return
        info = dep_map[name]
        for inp in info["inputs"]:
            for other_name, other_info in dep_map.items():
                if other_info["output"] == inp and other_name != name:
                    resolve(other_name)
        order.append(name)
        resolved.add(name)

    for name in sorted(dep_map.keys()):
        resolve(name)

    for name in order:
        info = dep_map[name]
        render_py = info["contract_path"].with_name("render.py")
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            check=True,
        )

    subprocess.run(
        [sys.executable, str(ROOT / "integrate.py")],
        cwd=ROOT,
        check=True,
    )

    subprocess.run(
        [sys.executable, str(ROOT / "final_report.py")],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
