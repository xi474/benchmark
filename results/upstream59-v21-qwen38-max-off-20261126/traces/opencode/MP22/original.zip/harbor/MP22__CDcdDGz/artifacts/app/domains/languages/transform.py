import re


def transform(payloads, contract):
    if len(payloads) != 2:
        raise ValueError("languages expects exactly 2 input payloads")
    case = payloads[0]
    reader_result = payloads[1]

    if not isinstance(case, dict):
        raise ValueError("first input must be object")
    if "language_codes" not in case:
        raise ValueError("missing language_codes")
    valid_codes = case["language_codes"]
    if not isinstance(valid_codes, list):
        raise ValueError("language_codes must be array")
    for c in valid_codes:
        if not isinstance(c, str) or not re.fullmatch(r"[a-z]{3}", c):
            raise ValueError(f"invalid language code: {c}")
    valid_set = set(valid_codes)

    if not isinstance(reader_result, dict):
        raise ValueError("second input must be object")
    if set(reader_result.keys()) == {"name", "result"}:
        data = reader_result["result"]
    else:
        data = reader_result

    records_in = data.get("records", [])
    records_out = []

    for rec in records_in:
        rec_id = rec["id"]
        controls = rec.get("controls", {})
        fields = rec.get("fields", [])
        langs = []

        if "008" in controls:
            field008 = controls["008"]
            if len(field008) >= 38:
                code_008 = field008[35:38]
                if re.fullmatch(r"[a-z]{3}", code_008) and code_008 in valid_set:
                    langs.append(code_008)

        for f in fields:
            if f["tag"] == "041":
                for sf in f["subfields"]:
                    if sf["code"] in ("a", "d", "h"):
                        val = sf["value"].strip()
                        if len(val) % 3 != 0:
                            raise ValueError(f"041 subfield value length not multiple of 3: {val!r}")
                        for i in range(0, len(val), 3):
                            chunk = val[i:i+3]
                            if re.fullmatch(r"[a-z]{3}", chunk) and chunk in valid_set:
                                langs.append(chunk)

        seen = set()
        deduped = []
        for l in langs:
            if l not in seen:
                seen.add(l)
                deduped.append(l)
        deduped.sort()

        records_out.append({
            "id": rec_id,
            "languages": deduped,
        })

    records_out.sort(key=lambda r: r["id"])
    return {"name": contract["name"], "result": {"records": records_out}}
