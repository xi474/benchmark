import re


def _clean_text(s):
    s = re.sub(r"\s+", " ", s).strip()
    while s and s[-1] in "/,;:":
        s = s[:-1].rstrip()
    return s


def transform(payloads, contract):
    if len(payloads) != 1:
        raise ValueError("names expects exactly 1 input payload")
    reader_result = payloads[0]
    if not isinstance(reader_result, dict):
        raise ValueError("input must be object")

    if set(reader_result.keys()) == {"name", "result"}:
        data = reader_result["result"]
    else:
        data = reader_result

    records_in = data.get("records", [])
    records_out = []

    for rec in records_in:
        rec_id = rec["id"]
        fields = rec.get("fields", [])

        tag880_map = {}
        for f in fields:
            if f["tag"] == "880":
                sf6 = None
                for sf in f["subfields"]:
                    if sf["code"] == "6":
                        sf6 = sf["value"]
                        break
                if sf6 is not None:
                    ref_match = re.match(r"^(\d{3})-(\d{2})(?:/.*)?$", sf6)
                    if ref_match:
                        ref_tag = ref_match.group(1)
                        ref_nn = ref_match.group(2)
                        key = (ref_tag, ref_nn)
                        if key not in tag880_map:
                            tag880_map[key] = []
                        tag880_map[key].append(f)

        authors = []
        titles = []

        for f in fields:
            if f["tag"] == "100":
                sf6 = None
                parts_a = []
                parts_b = []
                for sf in f["subfields"]:
                    if sf["code"] == "6":
                        sf6 = sf["value"]
                    elif sf["code"] == "a":
                        parts_a.append(sf["value"])
                    elif sf["code"] == "b":
                        parts_b.append(sf["value"])
                name_raw = "".join(parts_a) + (" " + "".join(parts_b) if parts_b else "")
                name_clean = _clean_text(name_raw)

                alternates = []
                if sf6 is not None:
                    link_match = re.match(r"^880-(\d{2})(?:/.*)?$", sf6)
                    if link_match:
                        nn = link_match.group(1)
                        key = ("100", nn)
                        if key in tag880_map:
                            for alt_f in tag880_map[key]:
                                alt_parts = []
                                for sf in alt_f["subfields"]:
                                    if sf["code"] == "a":
                                        alt_parts.append(sf["value"])
                                    elif sf["code"] == "b":
                                        alt_parts.append(sf["value"])
                                alt_text = _clean_text(" ".join(alt_parts))
                                if alt_text and alt_text not in alternates:
                                    alternates.append(alt_text)
                alternates.sort()
                authors.append({"name": name_clean, "alternates": alternates})

            elif f["tag"] == "245":
                sf6 = None
                parts_a = []
                parts_b = []
                for sf in f["subfields"]:
                    if sf["code"] == "6":
                        sf6 = sf["value"]
                    elif sf["code"] == "a":
                        parts_a.append(sf["value"])
                    elif sf["code"] == "b":
                        parts_b.append(sf["value"])
                title_raw = "".join(parts_a) + (" " + "".join(parts_b) if parts_b else "")
                title_clean = _clean_text(title_raw)

                alternates = []
                if sf6 is not None:
                    link_match = re.match(r"^880-(\d{2})(?:/.*)?$", sf6)
                    if link_match:
                        nn = link_match.group(1)
                        key = ("245", nn)
                        if key in tag880_map:
                            for alt_f in tag880_map[key]:
                                alt_parts = []
                                for sf in alt_f["subfields"]:
                                    if sf["code"] == "a":
                                        alt_parts.append(sf["value"])
                                    elif sf["code"] == "b":
                                        alt_parts.append(sf["value"])
                                alt_text = _clean_text(" ".join(alt_parts))
                                if alt_text and alt_text not in alternates:
                                    alternates.append(alt_text)
                alternates.sort()
                titles.append({"title": title_clean, "alternates": alternates})

        records_out.append({
            "id": rec_id,
            "authors": authors,
            "titles": titles,
        })

    records_out.sort(key=lambda r: r["id"])
    return {"name": contract["name"], "result": {"records": records_out}}
