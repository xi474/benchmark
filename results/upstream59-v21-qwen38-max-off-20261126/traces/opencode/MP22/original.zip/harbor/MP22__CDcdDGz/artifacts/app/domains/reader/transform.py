import re
import xml.etree.ElementTree as ET


def transform(payloads, contract):
    if len(payloads) != 1:
        raise ValueError("reader expects exactly 1 input payload")
    case = payloads[0]
    if not isinstance(case, dict):
        raise ValueError("input must be object")
    if "xml" not in case or "language_codes" not in case:
        raise ValueError("missing required fields xml/language_codes")
    xml_str = case["xml"]
    if not isinstance(xml_str, str):
        raise ValueError("xml must be string")

    if re.search(r"<!DOCTYPE", xml_str, re.IGNORECASE):
        raise ValueError("DOCTYPE not allowed")
    if re.search(r"<!ENTITY", xml_str, re.IGNORECASE):
        raise ValueError("ENTITY not allowed")

    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError as e:
        raise ValueError(f"bad XML: {e}") from e

    ns_match = re.match(r"\{(.+?)\}", root.tag)
    ns = ns_match.group(1) if ns_match else ""

    def strip_ns(tag):
        m = re.match(r"\{.+?\}(.+)", tag)
        return m.group(1) if m else tag

    local_root = strip_ns(root.tag)
    if local_root not in ("collection", "record"):
        raise ValueError(f"root must be collection or record, got {local_root}")

    records_out = []
    seen_ids = set()

    if local_root == "collection":
        record_elems = [child for child in root if strip_ns(child.tag) == "record"]
    else:
        record_elems = [root]

    for rec_elem in record_elems:
        controls = {}
        fields = []
        rec_id = None

        for child in rec_elem:
            lt = strip_ns(child.tag)
            if lt == "controlfield":
                tag = child.get("tag")
                if tag is None:
                    raise ValueError("controlfield missing tag")
                if not re.fullmatch(r"\d{3}", tag):
                    raise ValueError(f"controlfield tag must be 3 digits: {tag}")
                text = child.text or ""
                if tag == "001":
                    if not text.strip():
                        raise ValueError("001 controlfield must be non-empty ID")
                    rec_id = text
                if tag in controls:
                    raise ValueError(f"duplicate controlfield tag {tag}")
                controls[tag] = text
            elif lt == "datafield":
                tag = child.get("tag")
                if tag is None:
                    raise ValueError("datafield missing tag")
                if not re.fullmatch(r"\d{3}", tag):
                    raise ValueError(f"datafield tag must be 3 digits: {tag}")
                subfields = []
                for sf in child:
                    slt = strip_ns(sf.tag)
                    if slt != "subfield":
                        continue
                    code = sf.get("code")
                    if code is None:
                        raise ValueError("subfield missing code")
                    if not re.fullmatch(r"[a-zA-Z0-9]", code):
                        raise ValueError(f"subfield code must be single alnum: {code}")
                    value = sf.text or ""
                    subfields.append({"code": code, "value": value})
                fields.append({"tag": tag, "subfields": subfields})
            else:
                raise ValueError(f"unknown element in record: {lt}")

        if rec_id is None:
            raise ValueError("record missing 001 controlfield")
        if rec_id in seen_ids:
            raise ValueError(f"duplicate record ID: {rec_id}")
        seen_ids.add(rec_id)

        records_out.append({
            "id": rec_id,
            "controls": controls,
            "fields": fields,
        })

    records_out.sort(key=lambda r: r["id"])

    return {"name": contract["name"], "result": {"records": records_out}}
