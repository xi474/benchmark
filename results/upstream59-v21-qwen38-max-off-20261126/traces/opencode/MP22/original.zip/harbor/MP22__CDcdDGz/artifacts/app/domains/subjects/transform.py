import re


TAG_CATEGORY = {
    "600": "people",
    "610": "organizations",
    "611": "meetings",
    "630": "works",
    "650": "topics",
    "651": "places",
}

ALL_CATEGORIES = ["people", "organizations", "meetings", "works", "topics", "places"]


def _clean_segment(s):
    s = re.sub(r"\s+", " ", s).strip()
    while s and s[-1] in "/,;:":
        s = s[:-1].rstrip()
    return s


def transform(payloads, contract):
    if len(payloads) != 1:
        raise ValueError("subjects expects exactly 1 input payload")
    reader_result = payloads[0]

    if not isinstance(reader_result, dict):
        raise ValueError("input must be object")
    if set(reader_result.keys()) == {"name", "result"}:
        data = reader_result["result"]
    else:
        data = reader_result

    records_in = data.get("records", [])
    records_out = []

    for rec in records_in:
        rec_id = rec["id"]
        fields = rec.get("fields", [])

        subjects = {cat: {} for cat in ALL_CATEGORIES}

        for f in fields:
            tag = f["tag"]
            if tag not in TAG_CATEGORY:
                continue
            category = TAG_CATEGORY[tag]

            main_parts = []
            subdivisions = []
            for sf in f["subfields"]:
                code = sf["code"]
                val = sf["value"]
                if code in ("a", "b"):
                    main_parts.append(val)
                elif code in ("v", "x", "y", "z"):
                    subdivisions.append(_clean_segment(val))

            main_text = _clean_segment(" ".join(main_parts))
            if not main_text:
                continue

            if subdivisions:
                full_value = main_text + " -- " + " -- ".join(subdivisions)
            else:
                full_value = main_text

            if full_value in subjects[category]:
                subjects[category][full_value] += 1
            else:
                subjects[category][full_value] = 1

        subj_out = {}
        for cat in ALL_CATEGORIES:
            items = [{"value": v, "count": c} for v, c in subjects[cat].items()]
            items.sort(key=lambda x: x["value"])
            subj_out[cat] = items

        records_out.append({
            "id": rec_id,
            "subjects": subj_out,
        })

    records_out.sort(key=lambda r: r["id"])
    return {"name": contract["name"], "result": {"records": records_out}}
