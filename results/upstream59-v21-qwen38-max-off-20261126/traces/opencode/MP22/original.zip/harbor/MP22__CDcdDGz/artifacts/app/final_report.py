import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    components = core.get("components", {})

    title = "MARC 作者标题、语言和主题导入"
    component_count = len(components)

    core_bytes = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(core_bytes).hexdigest()

    attention = []
    for name, result in components.items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.append(name)
            continue
        triggered = False
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True
                break
        if triggered:
            attention.append(name)
            continue
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0 and val is not False:
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.append(name)
                    break
                elif not isinstance(val, (list, dict, str, int, float, bool)):
                    attention.append(name)
                    break

    attention = sorted(set(attention))

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention,
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
