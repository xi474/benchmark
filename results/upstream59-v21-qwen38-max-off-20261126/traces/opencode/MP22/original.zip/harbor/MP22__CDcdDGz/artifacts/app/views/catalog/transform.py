def transform(payloads, contract):
    if len(payloads) != 3:
        raise ValueError("catalog expects exactly 3 input payloads")
    names_result = payloads[0]
    languages_result = payloads[1]
    subjects_result = payloads[2]

    def extract_data(r):
        if isinstance(r, dict) and set(r.keys()) == {"name", "result"}:
            return r["result"]
        return r

    names_data = extract_data(names_result)
    languages_data = extract_data(languages_result)
    subjects_data = extract_data(subjects_result)

    names_records = {r["id"]: r for r in names_data.get("records", [])}
    languages_records = {r["id"]: r for r in languages_data.get("records", [])}
    subjects_records = {r["id"]: r for r in subjects_data.get("records", [])}

    ids_names = set(names_records.keys())
    ids_languages = set(languages_records.keys())
    ids_subjects = set(subjects_records.keys())

    if ids_names != ids_languages or ids_names != ids_subjects:
        raise ValueError("record ID sets differ across inputs")

    all_ids = sorted(ids_names)
    records_out = []
    for rid in all_ids:
        nr = names_records[rid]
        lr = languages_records[rid]
        sr = subjects_records[rid]
        records_out.append({
            "id": rid,
            "authors": nr.get("authors", []),
            "titles": nr.get("titles", []),
            "languages": lr.get("languages", []),
            "subjects": sr.get("subjects", {}),
        })

    return {
        "name": contract["name"],
        "result": {
            "records": records_out,
            "record_count": len(records_out),
        },
    }
