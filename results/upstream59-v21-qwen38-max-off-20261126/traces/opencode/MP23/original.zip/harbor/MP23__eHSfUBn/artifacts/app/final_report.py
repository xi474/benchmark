import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / 'outputs' / 'core_manifest.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))

    title = '受目录容量限制的可逆文件重分片'
    component_count = len(core['components'])

    core_bytes = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False
    ).encode('utf-8')
    sha256 = hashlib.sha256(core_bytes).hexdigest()

    attention = set()
    for name, result in core['components'].items():
        if not isinstance(result, dict):
            continue
        if result.get('blocked') is True:
            attention.add(name)
        for key in ('complete', 'checkout', 'committed', 'ok'):
            if result.get(key) is False:
                attention.add(name)
        for key in ('unavailable', 'missing', 'conflicts', 'unreachable'):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != '' and val != 0 and val is not False:
                if isinstance(val, (list, dict, str)) and len(val) > 0:
                    attention.add(name)

    report = {
        'title': title,
        'component_count': component_count,
        'sha256': sha256,
        'attention': sorted(attention)
    }

    out = ROOT / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    main()
