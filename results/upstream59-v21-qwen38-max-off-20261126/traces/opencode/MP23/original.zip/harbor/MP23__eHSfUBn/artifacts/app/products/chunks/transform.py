import hashlib


def transform(payloads, contract):
    inp = payloads[0]
    files = inp['files']
    max_file_bytes = inp['max_file_bytes']

    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError('max_file_bytes must be int >= 16')
    if not isinstance(files, list):
        raise ValueError('files must be a list')

    sorted_files = sorted(files, key=lambda f: f['path'])

    seen_paths = set()
    for f in sorted_files:
        if f['path'] in seen_paths:
            raise ValueError(f'duplicate path: {f["path"]}')
        seen_paths.add(f['path'])

    file_chunks = []
    total_chunks = 0
    for f in sorted_files:
        raw = bytes.fromhex(f['hex'])
        n = (len(raw) + max_file_bytes - 1) // max_file_bytes if len(raw) > 0 else 0
        file_chunks.append((f, raw, n))
        total_chunks += n

    width = max(6, len(str(total_chunks - 1)) if total_chunks > 0 else 6)

    all_chunks = []
    manifest_files = []
    global_idx = 0

    for f, raw, n in file_chunks:
        path = f['path']
        size = len(raw)
        sha = hashlib.sha256(raw).hexdigest()
        parts = []

        offset = 0
        while offset < size:
            end = min(offset + max_file_bytes, size)
            chunk_data = raw[offset:end]
            name = f'd{global_idx:0{width}d}.bin'
            all_chunks.append({'name': name, 'hex': chunk_data.hex()})
            parts.append(name)
            global_idx += 1
            offset = end

        manifest_files.append({
            'path': path,
            'size': size,
            'sha256': sha,
            'parts': parts
        })

    result = {
        'chunks': all_chunks,
        'manifest': {
            'files': manifest_files
        }
    }

    return {'name': contract['name'], 'result': result}
