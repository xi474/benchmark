import json


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    original_input = payloads[0]
    chunks_result = _unwrap(payloads[1])

    max_file_bytes = original_input['max_file_bytes']
    max_entries = original_input['max_entries']

    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError('max_entries must be int >= 2')

    manifest = chunks_result['manifest']
    data_chunks = chunks_result['chunks']

    manifest_json = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    manifest_bytes = manifest_json.encode('utf-8')

    total_meta = (len(manifest_bytes) + max_file_bytes - 1) // max_file_bytes if len(manifest_bytes) > 0 else 0
    m_width = max(6, len(str(total_meta - 1)) if total_meta > 0 else 6)

    meta_chunks = []
    offset = 0
    m_idx = 0
    while offset < len(manifest_bytes):
        end = min(offset + max_file_bytes, len(manifest_bytes))
        chunk_data = manifest_bytes[offset:end]
        name = f'm{m_idx:0{m_width}d}.bin'
        meta_chunks.append({'name': name, 'hex': chunk_data.hex()})
        m_idx += 1
        offset = end

    all_items = []
    for c in data_chunks:
        all_items.append((c['name'], c['hex']))
    for c in meta_chunks:
        all_items.append((c['name'], c['hex']))

    all_items.sort(key=lambda x: x[0])
    n = len(all_items)

    if n == 0:
        return {'name': contract['name'], 'result': {'tree': [], 'max_entries': max_entries, 'max_file_bytes': max_file_bytes}}

    h = 1
    while max_entries ** h < n:
        h += 1

    tree = []
    for i, (name, hexdata) in enumerate(all_items):
        digits = []
        val = i
        for _ in range(h):
            digits.append(val % max_entries)
            val //= max_entries
        digits.reverse()

        if h == 1:
            path = name
        else:
            dir_parts = [f'n{d}' for d in digits[:-1]]
            path = '/'.join(dir_parts + [name])

        tree.append({'path': path, 'hex': hexdata})

    tree.sort(key=lambda x: x['path'])

    result = {
        'tree': tree,
        'max_entries': max_entries,
        'max_file_bytes': max_file_bytes
    }

    return {'name': contract['name'], 'result': result}
