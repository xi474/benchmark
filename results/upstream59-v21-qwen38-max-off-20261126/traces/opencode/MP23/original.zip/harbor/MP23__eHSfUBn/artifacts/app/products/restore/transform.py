import hashlib
import json
import re


def _unwrap(obj):
    if isinstance(obj, dict) and set(obj.keys()) == {'name', 'result'}:
        return obj['result']
    return obj


def transform(payloads, contract):
    layout = _unwrap(payloads[0])
    tree = layout['tree']
    max_entries = layout['max_entries']
    max_file_bytes = layout['max_file_bytes']

    if not isinstance(max_entries, int) or isinstance(max_entries, bool) or max_entries < 2:
        raise ValueError('max_entries must be int >= 2')
    if not isinstance(max_file_bytes, int) or isinstance(max_file_bytes, bool) or max_file_bytes < 16:
        raise ValueError('max_file_bytes must be int >= 16')

    basename_set = set()
    path_set = set()
    dir_children = {}

    for entry in tree:
        p = entry['path']
        hexdata = entry['hex']
        raw = bytes.fromhex(hexdata)

        if len(raw) > max_file_bytes:
            raise ValueError(f'file {p} exceeds max_file_bytes')

        _validate_safe_path(p)

        bn = p.rsplit('/', 1)[-1] if '/' in p else p
        if bn in basename_set:
            raise ValueError(f'duplicate basename: {bn}')
        basename_set.add(bn)

        if not (re.fullmatch(r'd\d+\.bin', bn) or re.fullmatch(r'm\d+\.bin', bn)):
            raise ValueError(f'invalid basename: {bn}')

        if p in path_set:
            raise ValueError(f'duplicate path: {p}')
        path_set.add(p)

        parent = p.rsplit('/', 1)[0] if '/' in p else ''
        if parent not in dir_children:
            dir_children[parent] = set()
        dir_children[parent].add(bn)

        ancestors = []
        parts = p.split('/')
        for i in range(len(parts) - 1):
            anc = '/'.join(parts[:i+1])
            ancestors.append(anc)
        for anc in ancestors:
            if anc in path_set:
                raise ValueError(f'path conflict: {anc} is both file and directory')

    all_dirs = set(dir_children.keys())
    for p in path_set:
        parts = p.split('/')
        for i in range(len(parts) - 1):
            anc = '/'.join(parts[:i+1])
            all_dirs.add(anc)

    for d in all_dirs:
        children = dir_children.get(d, set())
        subdirs = set()
        for other_p in path_set:
            if '/' in other_p:
                parent = other_p.rsplit('/', 1)[0]
                if parent == d:
                    pass
            parts = other_p.split('/')
            for i in range(len(parts) - 1):
                anc = '/'.join(parts[:i+1])
                if anc == d and i < len(parts) - 2:
                    child_dir = parts[i+1]
                    subdirs.add(child_dir)

        direct_items = children | subdirs
        if len(direct_items) > max_entries:
            raise ValueError(f'directory {d!r} has {len(direct_items)} entries > max_entries')

    d_chunks = {}
    m_chunks = {}
    for entry in tree:
        bn = entry['path'].rsplit('/', 1)[-1] if '/' in entry['path'] else entry['path']
        raw = bytes.fromhex(entry['hex'])
        if bn.startswith('d'):
            idx = int(bn[1:-4])
            d_chunks[idx] = raw
        elif bn.startswith('m'):
            idx = int(bn[1:-4])
            m_chunks[idx] = raw

    if m_chunks:
        max_m = max(m_chunks.keys())
        expected_m = list(range(max_m + 1))
        for i in expected_m:
            if i not in m_chunks:
                raise ValueError(f'missing meta chunk m{i:06d}.bin')
        manifest_bytes = b''.join(m_chunks[i] for i in expected_m)
    else:
        manifest_bytes = b''

    manifest = json.loads(manifest_bytes.decode('utf-8'))

    referenced_d = set()
    restored_files = []
    total_bytes = 0

    for finfo in manifest['files']:
        orig_path = finfo['path']
        expected_size = finfo['size']
        expected_sha = finfo['sha256']
        parts = finfo['parts']

        _validate_safe_path(orig_path)

        file_bytes = b''
        for part_name in parts:
            idx_match = re.fullmatch(r'd(\d+)\.bin', part_name)
            if not idx_match:
                raise ValueError(f'invalid part name: {part_name}')
            idx = int(idx_match.group(1))
            if idx not in d_chunks:
                raise ValueError(f'missing data chunk: {part_name}')
            if idx in referenced_d:
                raise ValueError(f'duplicate reference to chunk: {part_name}')
            referenced_d.add(idx)
            file_bytes += d_chunks[idx]

        if len(file_bytes) != expected_size:
            raise ValueError(f'size mismatch for {orig_path}: got {len(file_bytes)}, expected {expected_size}')

        actual_sha = hashlib.sha256(file_bytes).hexdigest()
        if actual_sha != expected_sha:
            raise ValueError(f'sha256 mismatch for {orig_path}')

        restored_files.append({'path': orig_path, 'hex': file_bytes.hex()})
        total_bytes += len(file_bytes)

    extra_d = set(d_chunks.keys()) - referenced_d
    if extra_d:
        raise ValueError(f'unreferenced data chunks: {extra_d}')

    restored_files.sort(key=lambda x: x['path'])

    result = {
        'files': restored_files,
        'total_bytes': total_bytes
    }

    return {'name': contract['name'], 'result': result}


def _validate_safe_path(p):
    if not p or p.startswith('/') or '\\' in p or ':' in p:
        raise ValueError(f'unsafe path: {p}')
    parts = p.split('/')
    for part in parts:
        if not part or part == '.' or part == '..':
            raise ValueError(f'unsafe path segment in: {p}')
