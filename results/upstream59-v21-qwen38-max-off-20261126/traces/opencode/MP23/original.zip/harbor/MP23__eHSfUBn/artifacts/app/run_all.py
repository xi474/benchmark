import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob('contract.json')):
        rel = cp.relative_to(ROOT)
        if 'outputs' in rel.parts:
            continue
        contracts.append(cp)

    dep_graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding='utf-8'))
        name = c['name']
        deps = set()
        for inp in c['inputs']:
            if inp.startswith('outputs/'):
                for other_cp in contracts:
                    other_c = json.loads(other_cp.read_text(encoding='utf-8'))
                    if other_c['output'] == inp:
                        deps.add(other_c['name'])
        dep_graph[name] = (cp, deps)

    ordered = []
    visited = set()
    temp = set()

    def visit(name):
        if name in temp:
            raise ValueError(f'circular dependency involving {name}')
        if name in visited:
            return
        temp.add(name)
        cp, deps = dep_graph[name]
        for d in sorted(deps):
            visit(d)
        temp.remove(name)
        visited.add(name)
        ordered.append(cp)

    for name in sorted(dep_graph.keys()):
        visit(name)

    for cp in ordered:
        render_py = cp.with_name('render.py')
        if not render_py.is_file():
            print(f'Missing render.py for {cp}', file=sys.stderr)
            sys.exit(1)
        result = subprocess.run(
            [sys.executable, str(render_py)],
            cwd=str(cp.parent),
            timeout=60
        )
        if result.returncode != 0:
            print(f'render.py failed for {cp}', file=sys.stderr)
            sys.exit(1)

    integrate = ROOT / 'integrate.py'
    result = subprocess.run([sys.executable, str(integrate)], cwd=str(ROOT), timeout=30)
    if result.returncode != 0:
        print('integrate.py failed', file=sys.stderr)
        sys.exit(1)

    final_report = ROOT / 'final_report.py'
    result = subprocess.run([sys.executable, str(final_report)], cwd=str(ROOT), timeout=30)
    if result.returncode != 0:
        print('final_report.py failed', file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
