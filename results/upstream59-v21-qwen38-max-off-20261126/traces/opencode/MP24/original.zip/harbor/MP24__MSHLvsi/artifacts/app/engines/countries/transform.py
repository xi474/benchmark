def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    departments = {d["id"]: d for d in case["departments"]}
    professors = case["professors"]
    countries = {}
    for prof in professors:
        dept_ids = set(prof["departments"])
        country_set = set()
        for did in dept_ids:
            country_set.add(departments[did]["country"])
        countries[prof["id"]] = sorted(country_set)
    return {"name": contract["name"], "result": {"countries": countries}}
