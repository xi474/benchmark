def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    departments = {d["id"]: d for d in case["departments"]}
    eu_set = set(case["eu"])
    as_of = case["as_of"]
    professors = case["professors"]
    ids = []
    for prof in professors:
        dept_ids = set(prof["departments"])
        for did in dept_ids:
            if departments[did]["country"] in eu_set:
                ids.append(prof["id"])
                break
    ids.sort()
    return {"name": contract["name"], "result": {"ids": ids}}
