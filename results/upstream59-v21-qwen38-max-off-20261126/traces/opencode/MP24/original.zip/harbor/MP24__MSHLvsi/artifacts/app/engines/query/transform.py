def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    eu_result = payloads[1]
    students_result = payloads[2]
    countries_result = payloads[3]
    if isinstance(eu_result, dict) and "result" in eu_result and "name" in eu_result:
        eu_data = eu_result["result"]
    else:
        eu_data = eu_result
    if isinstance(students_result, dict) and "result" in students_result and "name" in students_result:
        students_data = students_result["result"]
    else:
        students_data = students_result
    if isinstance(countries_result, dict) and "result" in countries_result and "name" in countries_result:
        countries_data = countries_result["result"]
    else:
        countries_data = countries_result
    eu_ids = set(eu_data["ids"])
    dept_counts = students_data["counts"]
    prof_countries = countries_data["countries"]
    professors = []
    for pid in sorted(eu_ids):
        eligible = []
        for dept_id, cnt in dept_counts.items():
            if cnt > 10:
                departments = case["departments"]
                prof_dept_ids = None
                for p in case["professors"]:
                    if p["id"] == pid:
                        prof_dept_ids = set(p["departments"])
                        break
                if prof_dept_ids is not None and dept_id in prof_dept_ids:
                    eligible.append(dept_id)
        if eligible:
            eligible.sort()
            professors.append({
                "id": pid,
                "countries": prof_countries.get(pid, []),
                "eligible_departments": eligible
            })
    return {"name": contract["name"], "result": {"professors": professors}}
