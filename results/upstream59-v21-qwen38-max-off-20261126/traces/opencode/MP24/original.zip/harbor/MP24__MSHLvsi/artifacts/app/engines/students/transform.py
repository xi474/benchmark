def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = payloads[0]
    departments = {d["id"]: d for d in case["departments"]}
    as_of = case["as_of"]
    students = case["students"]
    counts = {}
    for dept in case["departments"]:
        counts[dept["id"]] = 0
    for student in students:
        seen_depts = set()
        for enr in student["enrolments"]:
            dept_id = enr["department"]
            start = enr["start"]
            end = enr["end"]
            if start > as_of:
                continue
            if end is not None:
                if end <= start:
                    continue
                if as_of >= end:
                    continue
            if dept_id not in seen_depts:
                seen_depts.add(dept_id)
                counts[dept_id] = counts.get(dept_id, 0) + 1
    return {"name": contract["name"], "result": {"counts": counts}}
