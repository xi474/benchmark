import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))

    title = "\u5927\u5b66\u4efb\u804c\u3001\u5728\u8bfb\u4eba\u6570\u4e0e\u56fd\u5bb6\u96c6\u5408\u67e5\u8be2"
    component_count = len(core["components"])

    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()

    attention = []
    for name, result in core["components"].items():
        if not isinstance(result, dict):
            continue
        if result.get("blocked") is True:
            attention.append(name)
            continue
        triggered = False
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True
                break
        if triggered:
            attention.append(name)
            continue
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "":
                if isinstance(val, (list, dict)) and len(val) > 0:
                    triggered = True
                    break
                elif isinstance(val, str) and len(val) > 0:
                    triggered = True
                    break
                elif isinstance(val, bool):
                    pass
                elif val is not None:
                    triggered = True
                    break
        if triggered:
            attention.append(name)

    attention = sorted(set(attention))

    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention
    }

    out_path = ROOT / "outputs" / "final_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8"
    )


if __name__ == "__main__":
    main()
