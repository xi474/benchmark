import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        if "outputs" in cp.relative_to(ROOT).parts:
            continue
        c = json.loads(cp.read_text(encoding="utf-8"))
        contracts.append((cp, c))

    rendered = set()
    max_iterations = len(contracts) * 2
    iteration = 0
    while len(rendered) < len(contracts):
        iteration += 1
        if iteration > max_iterations:
            raise RuntimeError("dependency cycle or unresolvable inputs")
        progress = False
        for cp, c in contracts:
            if c["name"] in rendered:
                continue
            deps_ready = True
            for inp in c["inputs"]:
                inp_path = ROOT / inp
                if not inp_path.exists():
                    deps_ready = False
                    break
            if not deps_ready:
                continue
            render_script = cp.with_name("render.py")
            if not render_script.exists():
                raise FileNotFoundError(f"render.py missing for {c['name']}")
            subprocess.run(
                [sys.executable, str(render_script)],
                cwd=ROOT,
                check=True,
                timeout=60
            )
            rendered.add(c["name"])
            progress = True
        if not progress:
            raise RuntimeError("no progress in dependency resolution")

    integrate = ROOT / "integrate.py"
    if integrate.exists():
        subprocess.run([sys.executable, str(integrate)], cwd=ROOT, check=True, timeout=60)

    final_report = ROOT / "final_report.py"
    if final_report.exists():
        subprocess.run([sys.executable, str(final_report)], cwd=ROOT, check=True, timeout=60)


if __name__ == "__main__":
    main()
