import re


def _parse_amount(raw):
    s = raw.strip()
    if s.upper().startswith("USD"):
        s = s[3:].strip()
    s = s.replace(",", "")
    if not re.fullmatch(r"\d+\.\d{2}", s):
        raise ValueError(f"invalid amount format: {raw}")
    return s


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    documents = payloads[0]
    if not isinstance(documents, dict) or "documents" not in documents:
        raise ValueError("missing documents field")
    docs = documents["documents"]
    if not isinstance(docs, list):
        raise ValueError("documents must be a list")
    seen_ids = set()
    amounts = {}
    for doc in docs:
        doc_id = doc.get("id")
        text = doc.get("text")
        if doc_id is None or text is None:
            raise ValueError("missing required fields")
        if not isinstance(doc_id, str) or not isinstance(text, str):
            raise ValueError("invalid field types")
        if doc_id in seen_ids:
            raise ValueError(f"duplicate id: {doc_id}")
        seen_ids.add(doc_id)
        total_val = None
        amount_due_val = None
        vat_val = None
        has_total = False
        has_amount_due = False
        has_vat = False
        for line in text.split("\n"):
            stripped = line.strip()
            m_total = re.match(r"^total:\s*(.+)$", stripped, re.IGNORECASE)
            m_amount = re.match(r"^amount\s+due:\s*(.+)$", stripped, re.IGNORECASE)
            m_vat = re.match(r"^vat:\s*(.+)$", stripped, re.IGNORECASE)
            if m_total:
                if has_total:
                    raise ValueError(f"duplicate Total for {doc_id}")
                has_total = True
                total_val = _parse_amount(m_total.group(1))
            elif m_amount:
                if has_amount_due:
                    raise ValueError(f"duplicate Amount Due for {doc_id}")
                has_amount_due = True
                amount_due_val = _parse_amount(m_amount.group(1))
            elif m_vat:
                if has_vat:
                    raise ValueError(f"duplicate VAT for {doc_id}")
                has_vat = True
                vat_val = _parse_amount(m_vat.group(1))
        if has_total:
            final_total = total_val
        elif has_amount_due:
            final_total = amount_due_val
        else:
            final_total = None
        if vat_val is None:
            vat_val = "0.00"
        amounts[doc_id] = {"total": final_total, "vat": vat_val}
    return {"name": contract["name"], "result": {"amounts": amounts}}
