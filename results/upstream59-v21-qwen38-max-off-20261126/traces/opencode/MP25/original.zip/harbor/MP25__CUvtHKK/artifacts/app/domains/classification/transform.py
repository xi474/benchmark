import re


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    documents = payloads[0]
    if not isinstance(documents, dict) or "documents" not in documents:
        raise ValueError("missing documents field")
    docs = documents["documents"]
    if not isinstance(docs, list):
        raise ValueError("documents must be a list")
    seen_ids = set()
    classes = {}
    for doc in docs:
        doc_id = doc.get("id")
        text = doc.get("text")
        if doc_id is None or text is None:
            raise ValueError("missing required fields")
        if not isinstance(doc_id, str) or not isinstance(text, str):
            raise ValueError("invalid field types")
        if doc_id in seen_ids:
            raise ValueError(f"duplicate id: {doc_id}")
        seen_ids.add(doc_id)
        words = re.findall(r"[a-zA-Z]+", text)
        lower_words = [w.lower() for w in words]
        if "invoice" in lower_words:
            kind = "invoice"
        elif "receipt" in lower_words:
            kind = "receipt"
        else:
            kind = "other"
        classes[doc_id] = kind
    return {"name": contract["name"], "result": {"classes": classes}}
