import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    core_path = ROOT / "outputs" / "core_manifest.json"
    core = json.loads(core_path.read_text(encoding="utf-8"))
    title = "\u6587\u672c\u7968\u636e\u5206\u7c7b\u3001\u91d1\u989d\u63d0\u53d6\u4e0e\u5f52\u6863\u6c47\u603b"
    component_count = len(core["components"])
    serialized = json.dumps(
        core, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    sha256 = hashlib.sha256(serialized).hexdigest()
    attention = []
    for comp_name, result in core["components"].items():
        if not isinstance(result, dict):
            continue
        triggered = False
        if result.get("blocked") is True:
            triggered = True
        for key in ("complete", "checkout", "committed", "ok"):
            if key in result and result[key] is False:
                triggered = True
        for key in ("unavailable", "missing", "conflicts", "unreachable"):
            val = result.get(key)
            if val is not None and val != [] and val != {} and val != "" and val != 0 and val is not False:
                if isinstance(val, (list, dict)) and len(val) > 0:
                    triggered = True
                elif isinstance(val, str) and len(val) > 0:
                    triggered = True
                elif isinstance(val, (int, float)) and val != 0:
                    triggered = True
        if triggered:
            attention.append(comp_name)
    attention = sorted(set(attention))
    report = {
        "title": title,
        "component_count": component_count,
        "sha256": sha256,
        "attention": attention,
    }
    out = ROOT / "outputs" / "final_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
