import csv
import io


def _is_safe_path_segment(s):
    if not s or not isinstance(s, str):
        return False
    if "\\" in s or ":" in s:
        return False
    parts = s.split("/")
    for p in parts:
        if p == "" or p == "." or p == "..":
            return False
    if s.startswith("/"):
        return False
    return True


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    documents_data = payloads[0]
    classification_data = payloads[1]
    amounts_data = payloads[2]
    if not isinstance(documents_data, dict) or "documents" not in documents_data:
        raise ValueError("missing documents")
    docs = documents_data["documents"]
    classes = classification_data.get("classes", {})
    amts = amounts_data.get("amounts", {})
    archives = []
    rows = []
    invoice_total_sum = 0.0
    receipt_total_sum = 0.0
    for doc in docs:
        doc_id = doc["id"]
        filename = doc["filename"]
        text = doc["text"]
        kind = classes.get(doc_id, "other")
        amt_info = amts.get(doc_id, {"total": None, "vat": "0.00"})
        total = amt_info.get("total")
        vat = amt_info.get("vat", "0.00")
        if kind in ("invoice", "receipt") and total is None:
            raise ValueError(f"{kind} document {doc_id} missing total")
        if not _is_safe_path_segment(doc_id):
            raise ValueError(f"unsafe id segment: {doc_id}")
        archive_path = f"classified/{kind}/{doc_id}/{filename}"
        hex_val = text.encode("utf-8").hex()
        archives.append({"path": archive_path, "hex": hex_val})
        rows.append({
            "id": doc_id,
            "filename": filename,
            "kind": kind,
            "total": total if total is not None else "",
            "vat": vat,
        })
        if kind == "invoice" and total is not None:
            invoice_total_sum += float(total)
        elif kind == "receipt" and total is not None:
            receipt_total_sum += float(total)
    archives.sort(key=lambda x: x["path"])
    rows.sort(key=lambda x: x["id"])
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(["id", "filename", "kind", "total", "vat"])
    for r in rows:
        writer.writerow([r["id"], r["filename"], r["kind"], r["total"], r["vat"]])
    csv_str = buf.getvalue()
    result = {
        "archives": archives,
        "rows": rows,
        "csv": csv_str,
        "totals": {
            "invoice": f"{invoice_total_sum:.2f}",
            "receipt": f"{receipt_total_sum:.2f}",
        },
    }
    return {"name": contract["name"], "result": result}
