def _extract_result(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    calendar_result = _extract_result(payloads[0])
    plan_result = _extract_result(payloads[1])
    notifications_result = _extract_result(payloads[2])
    old_events = calendar_result["events"]
    cancelled_set = set(plan_result["cancelled"])
    added = plan_result["added"]
    remaining = [ev for ev in old_events if ev["id"] not in cancelled_set]
    final_events = remaining + list(added)
    final_events.sort(key=lambda e: e["id"])
    return {
        "name": contract["name"],
        "result": {
            "events": final_events,
            "outbox": notifications_result["outbox"],
        },
    }
