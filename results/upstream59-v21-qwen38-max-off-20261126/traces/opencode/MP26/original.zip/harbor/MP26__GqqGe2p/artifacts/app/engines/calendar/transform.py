from datetime import datetime


def _extract_result(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = _extract_result(payloads[0])
    contacts = set(case["contacts"])
    events_in = case["events"]
    processed_events = []
    existing_dinner_dates = set()
    for ev in events_in:
        eid = ev["id"]
        start_str = ev["start"]
        end_str = ev["end"]
        kind = ev["kind"]
        attendees_raw = ev["attendees"]
        attendees_sorted = sorted(set(attendees_raw))
        start_dt = datetime.fromisoformat(start_str)
        end_dt = datetime.fromisoformat(end_str)
        if kind == "dinner":
            if start_dt.hour == 19 and start_dt.minute == 0:
                dinner_date = start_dt.date().isoformat()
                existing_dinner_dates.add(dinner_date)
        processed_events.append({
            "id": eid,
            "start": start_str,
            "end": end_str,
            "kind": kind,
            "attendees": attendees_sorted,
        })
    processed_events.sort(key=lambda e: (e["id"], e["attendees"]))
    existing_dinners = sorted(existing_dinner_dates)
    return {
        "name": contract["name"],
        "result": {
            "events": processed_events,
            "existing_dinners": existing_dinners,
        },
    }
