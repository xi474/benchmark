from datetime import date, timedelta


def _extract_result(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    case = _extract_result(payloads[0])
    today_str = case["today"]
    today = date.fromisoformat(today_str)
    current_week_monday = today - timedelta(days=today.weekday())
    next_week_friday = current_week_monday + timedelta(days=11)
    dates = []
    d = today
    while d <= next_week_friday:
        dates.append(d.isoformat())
        d += timedelta(days=1)
    return {"name": contract["name"], "result": {"dates": dates}}
