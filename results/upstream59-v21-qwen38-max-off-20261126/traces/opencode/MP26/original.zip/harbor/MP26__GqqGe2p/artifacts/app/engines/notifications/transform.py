def _extract_result(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    plan_result = _extract_result(payloads[0])
    snapshots = plan_result["snapshots"]
    contact_events = {}
    for ev in snapshots:
        for attendee in ev["attendees"]:
            if attendee not in contact_events:
                contact_events[attendee] = set()
            contact_events[attendee].add(ev["id"])
    outbox = []
    for to_id in sorted(contact_events.keys()):
        event_ids = sorted(contact_events[to_id])
        outbox.append({"to": to_id, "event_ids": event_ids})
    return {
        "name": contract["name"],
        "result": {
            "outbox": outbox,
        },
    }
