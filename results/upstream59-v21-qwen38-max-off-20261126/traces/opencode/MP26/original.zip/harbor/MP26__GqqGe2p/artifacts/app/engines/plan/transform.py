from datetime import datetime


def _extract_result(payload):
    if isinstance(payload, dict) and set(payload.keys()) == {"name", "result"}:
        return payload["result"]
    return payload


def transform(payloads, contract):
    if len(payloads) != len(contract["inputs"]):
        raise ValueError("payload count mismatch")
    dates_result = _extract_result(payloads[0])
    calendar_result = _extract_result(payloads[1])
    all_dates = dates_result["dates"]
    existing_dinners = set(calendar_result["existing_dinners"])
    old_events = calendar_result["events"]
    new_dates = [d for d in all_dates if d not in existing_dinners]
    added = []
    for d in new_dates:
        start_str = f"{d}T19:00"
        end_str = f"{d}T20:00"
        new_id = f"dinner-{d}"
        for ev in old_events:
            if ev["id"] == new_id:
                raise ValueError(f"new ID {new_id} conflicts with existing event")
        added.append({
            "id": new_id,
            "start": start_str,
            "end": end_str,
            "kind": "dinner",
            "attendees": [],
        })
    added.sort(key=lambda e: e["start"])
    cancelled_ids = set()
    snapshots = []
    for ev in old_events:
        ev_start = datetime.fromisoformat(ev["start"])
        ev_end = datetime.fromisoformat(ev["end"])
        should_cancel = False
        for nd in new_dates:
            new_start = datetime.fromisoformat(f"{nd}T19:00")
            new_end = datetime.fromisoformat(f"{nd}T20:00")
            if ev_start < new_end and ev_end > new_start:
                should_cancel = True
                break
        if should_cancel:
            cancelled_ids.add(ev["id"])
            snapshots.append(ev)
    cancelled_sorted = sorted(cancelled_ids)
    snapshots.sort(key=lambda e: e["id"])
    return {
        "name": contract["name"],
        "result": {
            "added": added,
            "cancelled": cancelled_sorted,
            "snapshots": snapshots,
        },
    }
