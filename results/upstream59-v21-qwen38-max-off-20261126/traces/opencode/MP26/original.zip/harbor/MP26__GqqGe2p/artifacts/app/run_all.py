import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    contracts = []
    for cp in sorted(ROOT.rglob("contract.json")):
        rel = cp.relative_to(ROOT)
        if "outputs" in rel.parts:
            continue
        contracts.append(cp)
    if not contracts:
        raise ValueError("no contracts found")
    graph = {}
    for cp in contracts:
        c = json.loads(cp.read_text(encoding="utf-8"))
        name = c["name"]
        deps = []
        for inp in c["inputs"]:
            if inp.startswith("outputs/"):
                dep_name = None
                for cp2 in contracts:
                    c2 = json.loads(cp2.read_text(encoding="utf-8"))
                    if c2["output"] == inp:
                        dep_name = c2["name"]
                        break
                if dep_name is None:
                    raise ValueError(f"unresolved dependency {inp}")
                deps.append(dep_name)
        graph[name] = {"path": cp, "deps": deps}
    order = []
    visited = set()
    visiting = set()

    def topo(name):
        if name in visiting:
            raise ValueError("cycle detected")
        if name in visited:
            return
        visiting.add(name)
        for dep in graph[name]["deps"]:
            topo(dep)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(graph.keys()):
        topo(name)
    for name in order:
        cp = graph[name]["path"]
        render_py = cp.with_name("render.py")
        subprocess.run(
            [sys.executable, str(render_py)],
            cwd=ROOT,
            check=True,
            timeout=60,
        )
    integrate_py = ROOT / "integrate.py"
    subprocess.run(
        [sys.executable, str(integrate_py)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )
    final_report_py = ROOT / "final_report.py"
    subprocess.run(
        [sys.executable, str(final_report_py)],
        cwd=ROOT,
        check=True,
        timeout=60,
    )


if __name__ == "__main__":
    main()
