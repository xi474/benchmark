def compute(payload):
    topics = payload["topics"]
    papers = payload["papers"]
    result = []
    for topic in topics:
        scores = {}
        for paper in papers:
            methods_set = set(paper["methods"])
            best = None
            for claim in paper["claims"]:
                if claim[0] == topic and claim[1] in methods_set:
                    q = claim[2]
                    if best is None or q > best:
                        best = q
            if best is not None:
                scores[paper["id"]] = best
        result.append(scores)
    return result
