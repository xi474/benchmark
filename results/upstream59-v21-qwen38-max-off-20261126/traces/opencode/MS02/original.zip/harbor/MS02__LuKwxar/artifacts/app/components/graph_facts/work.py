def compute(payload):
    graph = payload["graph"]
    seen = set()
    result = []
    for edge in graph:
        key = (edge[0], edge[1], edge[2])
        if key not in seen:
            seen.add(key)
            result.append(edge)
    result.sort(key=lambda e: (e[0], e[1], e[2]))
    return result
