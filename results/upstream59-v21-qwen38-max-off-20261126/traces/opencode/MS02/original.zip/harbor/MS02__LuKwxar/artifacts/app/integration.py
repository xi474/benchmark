from itertools import product as iter_product


def combine(payload, left, right):
    topics = payload["topics"]
    n = len(topics)
    score_tables = left
    existing_edges = right

    candidates = []
    for i, topic in enumerate(topics):
        table = score_tables[i]
        cands = sorted(table.keys())
        if not cands:
            return None
        candidates.append([(pid, table[pid]) for pid in cands])

    best = None

    def solve(idx, used, assignment, min_q, total_q):
        nonlocal best
        if idx == n:
            key = tuple(a[0] for a in assignment)
            if best is None:
                best = (min_q, total_q, key, list(assignment))
            else:
                b_min, b_total, b_key, _ = best
                if (min_q > b_min or
                    (min_q == b_min and total_q > b_total) or
                    (min_q == b_min and total_q == b_total and key < b_key)):
                    best = (min_q, total_q, key, list(assignment))
            return

        upper_possible_min = min_q
        for j in range(idx, n):
            max_for_j = max(q for _, q in candidates[j])
            upper_possible_min = min(upper_possible_min, max_for_j)
        if best is not None and upper_possible_min < best[0]:
            return

        for pid, q in candidates[idx]:
            if pid in used:
                continue
            new_min = min(min_q, q)
            if best is not None and new_min < best[0]:
                continue
            solve(idx + 1, used | {pid}, assignment + [(pid, q)], new_min, total_q + q)

    solve(0, set(), [], float('inf'), 0)

    if best is None:
        return None

    _, _, _, assignment = best
    review = []
    new_edges = list(existing_edges)
    for i, topic in enumerate(topics):
        pid, q = assignment[i]
        review.append([topic, pid, q])
        new_edges.append([pid, "supports", topic])

    seen = set()
    deduped = []
    for e in new_edges:
        key = (e[0], e[1], e[2])
        if key not in seen:
            seen.add(key)
            deduped.append(e)
    deduped.sort(key=lambda e: (e[0], e[1], e[2]))

    return {"review": review, "graph": deduped}
