def compute(payload):
    buyers = payload["buyers"]
    orders = payload["orders"]
    totals = {b: 0 for b in buyers}
    for order in orders:
        buyer = order["buyer"]
        if buyer not in totals:
            continue
        for line in order["lines"]:
            cats, qty, price = line[0], line[1], line[2]
            has_target = any(c in ("Electronics", "Cameras") for c in cats)
            if has_target:
                totals[buyer] += qty * price
    return totals
