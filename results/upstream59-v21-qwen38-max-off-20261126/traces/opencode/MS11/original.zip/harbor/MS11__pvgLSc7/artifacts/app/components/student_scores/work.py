def compute(payload):
    grades = payload["grades"]
    data = {}
    for row in grades:
        student, course, score = row[0], row[1], row[2]
        if course not in (1, 2) or score is None:
            continue
        if student not in data:
            data[student] = {"sum": 0, "count": 0}
        data[student]["sum"] += score
        data[student]["count"] += 1
    result = {}
    for sid in sorted(data.keys()):
        d = data[sid]
        result[sid] = (d["sum"] * 100) // d["count"]
    return result
