from itertools import product


def combine(payload, left, right):
    students = payload["students"]
    buyers = payload["buyers"]
    evidence_raw = payload["evidence"]
    drop_list = payload["drop"]

    student_scores = left
    buyer_totals = right

    results = []
    for drop_entry in drop_list:
        result = _solve(students, buyers, evidence_raw, student_scores, buyer_totals, drop_entry)
        results.append({"drop": drop_entry, "result": result})
    return results


def _solve(students, buyers, evidence_raw, student_scores, buyer_totals, drop_source):
    if drop_source is not None:
        ev = [e for e in evidence_raw if e[0] != drop_source]
    else:
        ev = list(evidence_raw)

    conf = {}
    for src, sid, bid, strength in ev:
        key = (src, sid, bid)
        if key not in conf or strength > conf[key]:
            conf[key] = strength

    pair_conf = {}
    for (src, sid, bid), val in conf.items():
        p = (sid, bid)
        pair_conf[p] = pair_conf.get(p, 0) + val

    allowed = set(pair_conf.keys())

    adj_s = {s: [] for s in students}
    adj_b = {b: [] for b in buyers}
    for (s, b) in allowed:
        adj_s[s].append(b)
        adj_b[b].append(s)

    components = _find_components(students, buyers, adj_s, adj_b)

    all_component_matchings = []
    for comp_students, comp_buyers in components:
        if len(comp_students) != len(comp_buyers):
            return None
        matchings = _enumerate_perfect_matchings(comp_students, comp_buyers, allowed)
        if not matchings:
            return None
        all_component_matchings.append(matchings)

    global_matchings = _combine_components(all_component_matchings)

    best_floor = -1
    best_total = -1
    for m in global_matchings:
        floor_val = min(pair_conf[(s, b)] for s, b in m)
        total_val = sum(pair_conf[(s, b)] for s, b in m)
        if floor_val > best_floor or (floor_val == best_floor and total_val > best_total):
            best_floor = floor_val
            best_total = total_val

    optimal = []
    for m in global_matchings:
        floor_val = min(pair_conf[(s, b)] for s, b in m)
        total_val = sum(pair_conf[(s, b)] for s, b in m)
        if floor_val == best_floor and total_val == best_total:
            optimal.append(m)

    n = len(students)
    sorted_students = sorted(students)
    x_vals = [student_scores[s] for s in sorted_students]
    sum_x = sum(x_vals)

    numerators = []
    buyer_vectors = []
    for m in optimal:
        mapping = dict(m)
        y_vals = [buyer_totals[mapping[s]] for s in sorted_students]
        sum_y = sum(y_vals)
        num = n * sum(x * y for x, y in zip(x_vals, y_vals)) - sum_x * sum_y
        numerators.append(num)
        buyer_vectors.append([mapping[s] for s in sorted_students])

    min_num = min(numerators)
    max_num = max(numerators)

    min_buyers = None
    max_buyers = None
    for i, num in enumerate(numerators):
        if num == min_num:
            if min_buyers is None or buyer_vectors[i] < min_buyers:
                min_buyers = buyer_vectors[i]
        if num == max_num:
            if max_buyers is None or buyer_vectors[i] < max_buyers:
                max_buyers = buyer_vectors[i]

    forced = []
    if optimal:
        opt_sets = [set(m) for m in optimal]
        common = opt_sets[0]
        for s in opt_sets[1:]:
            common = common & s
        forced = sorted([[s, b] for s, b in common], key=lambda x: x[0])

    return {
        "floor": best_floor,
        "total": best_total,
        "count": len(optimal),
        "min_num": min_num,
        "max_num": max_num,
        "min_buyers": min_buyers,
        "max_buyers": max_buyers,
        "forced": forced,
    }


def _find_components(students, buyers, adj_s, adj_b):
    visited_s = set()
    visited_b = set()
    components = []
    for s in students:
        if s in visited_s:
            continue
        comp_s = []
        comp_b = []
        queue_s = [s]
        visited_s.add(s)
        while queue_s:
            cs = queue_s.pop()
            comp_s.append(cs)
            for b in adj_s[cs]:
                if b not in visited_b:
                    visited_b.add(b)
                    comp_b.append(b)
                    for ns in adj_b[b]:
                        if ns not in visited_s:
                            visited_s.add(ns)
                            queue_s.append(ns)
        components.append((comp_s, comp_b))
    return components


def _enumerate_perfect_matchings(comp_students, comp_buyers, allowed):
    n = len(comp_students)
    buyer_set = set(comp_buyers)
    matchings = []
    _backtrack(comp_students, buyer_set, allowed, 0, [], matchings)
    return matchings


def _backtrack(students, remaining_buyers, allowed, idx, current, matchings):
    if idx == len(students):
        matchings.append(tuple(current))
        return
    s = students[idx]
    for b in sorted(remaining_buyers):
        if (s, b) in allowed:
            remaining_buyers.remove(b)
            current.append((s, b))
            _backtrack(students, remaining_buyers, allowed, idx + 1, current, matchings)
            current.pop()
            remaining_buyers.add(b)


def _combine_components(component_matchings):
    if not component_matchings:
        return [()]
    result = [()]
    for cm in component_matchings:
        new_result = []
        for existing in result:
            for m in cm:
                new_result.append(existing + m)
        result = new_result
    return result
