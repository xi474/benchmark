def compute(payload):
    recipes = payload["recipes"]
    groups = payload["groups"]
    delivery = payload["delivery"]
    all_forbidden = set()
    for g in groups:
        for ing in g[2]:
            all_forbidden.add(ing)
    result = {}
    for signal, available_ingredients in delivery.items():
        avail_set = set(available_ingredients)
        eligible = []
        for r in recipes:
            if r["difficulty"] > 4:
                continue
            if not all(ing in avail_set for ing in r["ingredients"]):
                continue
            if any(ing in all_forbidden for ing in r["ingredients"]):
                continue
            eligible.append(r["id"])
        result[signal] = eligible
    return result
