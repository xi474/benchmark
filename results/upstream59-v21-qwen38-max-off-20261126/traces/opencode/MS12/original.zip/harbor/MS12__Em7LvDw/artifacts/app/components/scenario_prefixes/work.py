def compute(payload):
    scenarios = payload["scenarios"]
    prefix_map = {}
    for sc in scenarios:
        signals = sc["signals"]
        weight = sc["weight"]
        for i in range(1, len(signals) + 1):
            prefix = tuple(signals[:i])
            if prefix not in prefix_map:
                prefix_map[prefix] = None
            if i == len(signals):
                prefix_map[prefix] = weight
    sorted_prefixes = sorted(prefix_map.keys())
    return [[list(p), prefix_map[p]] for p in sorted_prefixes]
