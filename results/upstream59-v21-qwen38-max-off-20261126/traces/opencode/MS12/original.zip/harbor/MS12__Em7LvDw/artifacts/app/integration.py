def combine(payload, left, right):
    recipes = payload["recipes"]
    groups = payload["groups"]
    budget = payload["budget"]
    scenarios = payload["scenarios"]

    recipe_map = {r["id"]: r for r in recipes}
    prefixes_with_weights = left
    eligible_by_signal = right

    histories = [tuple(h) for h, w in prefixes_with_weights]
    prefix_weight = {}
    for h, w in prefixes_with_weights:
        key = tuple(h)
        if w is not None:
            prefix_weight[key] = w

    prefix_index = {h: i for i, h in enumerate(histories)}
    num_prefixes = len(histories)

    children_map = {i: [] for i in range(num_prefixes)}
    parent_of = {}
    for i, h in enumerate(histories):
        if len(h) > 1:
            par = h[:-1]
            pi = prefix_index[par]
            children_map[pi].append(i)
            parent_of[i] = pi

    leaf_set = set()
    scenario_weights = []
    for sc in scenarios:
        sigs = tuple(sc["signals"])
        idx = prefix_index[sigs]
        leaf_set.add(idx)
        scenario_weights.append((idx, sc["weight"]))

    root_indices = [i for i, h in enumerate(histories) if len(h) == 1]

    def get_eligible(prefix_idx):
        h = histories[prefix_idx]
        signal = h[-1]
        return eligible_by_signal.get(signal, [])

    def get_path(node_idx):
        path = []
        cur = node_idx
        while cur is not None:
            path.append(cur)
            cur = parent_of.get(cur)
        path.reverse()
        return path

    assignment = [None] * num_prefixes
    best_floor = -1
    best_utility = -1
    best_cost = float('inf')
    best_policies = []

    def eval_policy():
        floors = []
        weighted_utility = 0
        weighted_cost = 0
        for leaf_idx, w in scenario_weights:
            path = get_path(leaf_idx)
            dishes = [assignment[pi] for pi in path]
            total_cost = sum(recipe_map[d]["cost"] for d in dishes)
            if total_cost > budget:
                return None
            group_scores = []
            for g in groups:
                liked = set(g[3])
                per_person = sum(1 for d in dishes if recipe_map[d]["cat"] in liked)
                group_scores.append(per_person)
            sf = min(group_scores)
            floors.append(sf)
            person_score = sum(gs * groups[gi][1] for gi, gs in enumerate(group_scores))
            weighted_utility += person_score * w
            weighted_cost += total_cost * w
        overall_floor = min(floors)
        return (overall_floor, weighted_utility, weighted_cost)

    node_order = list(range(num_prefixes))

    def backtrack(pos, path_states):
        nonlocal best_floor, best_utility, best_cost, best_policies

        if pos == num_prefixes:
            result = eval_policy()
            if result is None:
                return
            of, ou, oc = result
            if (of > best_floor or
                (of == best_floor and ou > best_utility) or
                (of == best_floor and ou == best_utility and oc < best_cost)):
                best_floor = of
                best_utility = ou
                best_cost = oc
                best_policies = [list(assignment)]
            elif of == best_floor and ou == best_utility and oc == best_cost:
                best_policies.append(list(assignment))
            return

        ni = node_order[pos]
        eligible = get_eligible(ni)
        par = parent_of.get(ni)
        if par is not None:
            par_dish = assignment[par]
            par_cat = recipe_map[par_dish]["cat"]
        else:
            par_cat = None

        path_dishes = set()
        cur = par
        while cur is not None:
            path_dishes.add(assignment[cur])
            cur = parent_of.get(cur)

        for did in eligible:
            r = recipe_map[did]
            if did in path_dishes:
                continue
            if par_cat is not None and r["cat"] == par_cat:
                continue

            assignment[ni] = did
            new_states = dict(path_states)
            backtrack(pos + 1, new_states)
            assignment[ni] = None

    backtrack(0, {})

    if not best_policies:
        return {"histories": [list(h) for h in histories], "optimal": None}

    prefix_dish_sets = [set() for _ in range(num_prefixes)]
    for policy in best_policies:
        for i in range(num_prefixes):
            if policy[i] is not None:
                prefix_dish_sets[i].add(policy[i])

    menu = []
    allowed = []
    for i in range(num_prefixes):
        opts = sorted(prefix_dish_sets[i])
        menu.append(opts[0])
        allowed.append(opts)

    distinct_mappings = set()
    for policy in best_policies:
        key = tuple(policy)
        distinct_mappings.add(key)
    count = len(distinct_mappings)

    return {
        "histories": [list(h) for h in histories],
        "optimal": {
            "floor": best_floor,
            "utility": best_utility,
            "cost": best_cost,
            "count": count,
            "menu": menu,
            "allowed": allowed
        }
    }
