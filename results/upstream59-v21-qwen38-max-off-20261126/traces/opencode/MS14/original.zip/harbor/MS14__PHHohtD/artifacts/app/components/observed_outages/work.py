def compute(payload):
    queries = payload["queries"]
    log = payload["log"]
    result = []
    for q in queries:
        as_of = q["as_of"]
        start = q["start"]
        end = q["end"]
        visible = [entry for entry in log if entry[2] <= as_of]
        domain_records = {}
        for entry in visible:
            d, eff, seen, status = entry
            if d not in domain_records:
                domain_records[d] = []
            domain_records[d].append((eff, seen, status))
        slots = []
        for t in range(start, end):
            down_domains = []
            for d, records in domain_records.items():
                candidates = [(eff, seen, st) for eff, seen, st in records if eff <= t]
                if not candidates:
                    continue
                candidates.sort(key=lambda x: (x[0], x[1]))
                best = candidates[-1]
                if best[2] != "up":
                    down_domains.append(d)
            down_domains.sort()
            slots.append(down_domains)
        result.append(slots)
    return result
