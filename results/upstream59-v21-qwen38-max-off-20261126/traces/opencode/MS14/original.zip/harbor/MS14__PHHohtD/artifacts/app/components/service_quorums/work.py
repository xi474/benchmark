def compute(payload):
    services = payload["services"]
    result = {}
    for svc in services:
        result[svc["id"]] = [svc["need"], list(svc["inputs"])]
    return result
