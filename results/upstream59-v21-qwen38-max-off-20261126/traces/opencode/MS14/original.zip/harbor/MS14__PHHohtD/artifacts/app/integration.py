from itertools import combinations


def _eval_service(svc_id, quorums, domain_status, cache):
    if svc_id in cache:
        return cache[svc_id]
    if svc_id not in quorums:
        avail = domain_status.get(svc_id, True)
        cache[svc_id] = avail
        return avail
    need, inputs = quorums[svc_id]
    count = 0
    for inp in inputs:
        if inp in quorums:
            if _eval_service(inp, quorums, domain_status, cache):
                count += 1
        else:
            if domain_status.get(inp, True):
                count += 1
        if count >= need:
            cache[svc_id] = True
            return True
    cache[svc_id] = False
    return False


def _targets_available(targets, quorums, domain_status):
    cache = {}
    for t in targets:
        if t in quorums:
            if not _eval_service(t, quorums, domain_status, cache):
                return False
        else:
            if not domain_status.get(t, True):
                return False
    return True


def combine(payload, left, right):
    queries = payload["queries"]
    domains = payload["domains"]
    quorums = right
    results = []

    for qi, q in enumerate(queries):
        start = q["start"]
        end = q["end"]
        targets = q["targets"]
        slots_down = left[qi]

        target_unavail = {tgt: [] for tgt in targets}
        for si, t in enumerate(range(start, end)):
            down_set = set(slots_down[si])
            domain_status = {d: (d not in down_set) for d in domains}
            cache = {}
            for tgt in targets:
                if tgt in quorums:
                    avail = _eval_service(tgt, quorums, domain_status, cache)
                else:
                    avail = domain_status.get(tgt, True)
                if not avail:
                    target_unavail[tgt].append(t)

        incidents = []
        for tgt in sorted(targets):
            times = target_unavail[tgt]
            if not times:
                continue
            intervals = []
            seg_start = times[0]
            prev = times[0]
            for tt in times[1:]:
                if tt == prev + 1:
                    prev = tt
                else:
                    intervals.append([tgt, seg_start, prev + 1])
                    seg_start = tt
                    prev = tt
            intervals.append([tgt, seg_start, prev + 1])
            incidents.extend(intervals)

        failing_slots = []
        for si, t in enumerate(range(start, end)):
            down_set = set(slots_down[si])
            domain_status = {d: (d not in down_set) for d in domains}
            if not _targets_available(targets, quorums, domain_status):
                failing_slots.append((si, t, down_set))

        if not failing_slots:
            repairs = [[]]
        else:
            all_domains_sorted = sorted(domains)
            found_repairs = []
            for size in range(1, len(all_domains_sorted) + 1):
                for combo in combinations(all_domains_sorted, size):
                    repair_set = set(combo)
                    ok = True
                    for si, t, down_set in failing_slots:
                        effective_down = down_set - repair_set
                        domain_status = {d: (d not in effective_down) for d in domains}
                        if not _targets_available(targets, quorums, domain_status):
                            ok = False
                            break
                    if ok:
                        found_repairs.append(list(combo))
                if found_repairs:
                    break
            repairs = found_repairs if found_repairs else [[]]

        results.append({
            "incidents": incidents,
            "repairs": repairs
        })

    return results
