def compute(payload):
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        bc = snap["bc"]
        ac = snap["ac"]
        forbidden = snap.get("forbidden", [])
        k = len(ab)

        forbidden_set = set()
        for f in forbidden:
            forbidden_set.add((f[0], f[1], f[2]))

        snap_layers = []
        for b in range(k):
            row_sums = [ab[a][b] for a in range(k)]
            col_sums = [bc[b][c] for c in range(k)]
            upper = [[ac[a][c] for c in range(k)] for a in range(k)]
            for a in range(k):
                for c in range(k):
                    if (a, b, c) in forbidden_set:
                        upper[a][c] = 0

            candidates = []
            grid = [[0] * k for _ in range(k)]
            rem_col = list(col_sums)
            _fill(0, 0, k, row_sums, rem_col, upper, grid, candidates, b)
            candidates.sort(key=lambda x: x[0])

            layer_entries = []
            for vec, net in candidates:
                layer_entries.append([vec, net])
            snap_layers.append(layer_entries)
        results.append(snap_layers)
    return results


def _fill(pos, remaining_in_row, k, row_sums, rem_col, upper, grid, candidates, b):
    if pos == k * k:
        if remaining_in_row == 0 and all(v == 0 for v in rem_col):
            vec = []
            for a in range(k):
                for c in range(k):
                    vec.append(grid[a][c])
            net = 0
            for a in range(k):
                for c in range(k):
                    cnt = grid[a][c]
                    if cnt == 0:
                        continue
                    vals = sorted([a, b, c])
                    med = vals[1]
                    if med == k - 1:
                        net += cnt
                    elif med == 0:
                        net -= cnt
            candidates.append((vec, net))
        return

    a = pos // k
    c = pos % k

    if c == 0:
        remaining_in_row = row_sums[a]

    cap = min(upper[a][c], rem_col[c], remaining_in_row)
    for v in range(cap + 1):
        grid[a][c] = v
        rem_col[c] -= v
        new_rem = remaining_in_row - v
        if c == k - 1:
            if new_rem == 0:
                _fill(pos + 1, 0, k, row_sums, rem_col, upper, grid, candidates, b)
        else:
            _fill(pos + 1, new_rem, k, row_sums, rem_col, upper, grid, candidates, b)
        rem_col[c] += v
        grid[a][c] = 0
