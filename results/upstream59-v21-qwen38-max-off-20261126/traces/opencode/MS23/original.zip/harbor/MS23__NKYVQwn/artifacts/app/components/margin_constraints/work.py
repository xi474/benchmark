def compute(payload):
    results = []
    for snap in payload["snapshots"]:
        ab = snap["ab"]
        ac = snap["ac"]
        k = len(ab)
        compatible = True
        for a in range(k):
            ab_row_sum = sum(ab[a])
            ac_row_sum = sum(ac[a])
            if ab_row_sum != ac_row_sum:
                compatible = False
                break
        ac_quota = []
        for a in range(k):
            for c in range(k):
                ac_quota.append(ac[a][c])
        results.append([compatible, ac_quota])
    return results
