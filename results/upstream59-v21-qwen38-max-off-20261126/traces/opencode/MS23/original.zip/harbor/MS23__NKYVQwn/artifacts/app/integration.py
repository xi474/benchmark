def combine(payload, margin_result, layer_result):
    snapshots = payload["snapshots"]
    results = []
    for idx, snap in enumerate(snapshots):
        ac = snap["ac"]
        k = len(ac)
        compatible = margin_result[idx][0]
        if not compatible:
            results.append(None)
            continue

        layers_per_b = layer_result[idx]

        valid_tables = []
        _combine_layers(0, k, layers_per_b, ac, [], valid_tables)

        if not valid_tables:
            results.append(None)
            continue

        table_count = len(valid_tables)

        score_counts = {}
        for tbl_net, grid_flat in valid_tables:
            score_counts[tbl_net] = score_counts.get(tbl_net, 0) + 1

        spectrum = sorted([[s, c] for s, c in score_counts.items()], key=lambda x: x[0])

        num_cells = k * k * k
        min_per_cell = [None] * num_cells
        for tbl_net, grid_flat in valid_tables:
            for i in range(num_cells):
                if min_per_cell[i] is None or grid_flat[i] < min_per_cell[i]:
                    min_per_cell[i] = grid_flat[i]

        guaranteed = []
        for a in range(k):
            for b in range(k):
                for c in range(k):
                    idx_cell = a * k * k + b * k + c
                    if min_per_cell[idx_cell] > 0:
                        guaranteed.append([a, b, c, min_per_cell[idx_cell]])

        lowest_net = spectrum[0][0]
        lowest_tables = [gf for tn, gf in valid_tables if tn == lowest_net]
        lowest_tables.sort()
        witness_flat = lowest_tables[0]

        witness = []
        for a in range(k):
            for b in range(k):
                for c in range(k):
                    idx_cell = a * k * k + b * k + c
                    v = witness_flat[idx_cell]
                    if v > 0:
                        witness.append([a, b, c, v])

        results.append({
            "tables": table_count,
            "spectrum": spectrum,
            "guaranteed": guaranteed,
            "witness": witness
        })
    return results


def _combine_layers(b, k, layers_per_b, ac, chosen, valid_tables):
    if b == k:
        grid_flat = [0] * (k * k * k)
        total_net = 0
        for bi, (vec, net) in enumerate(chosen):
            total_net += net
            for a in range(k):
                for c in range(k):
                    idx = a * k * k + bi * k + c
                    grid_flat[idx] = vec[a * k + c]

        ok = True
        for a in range(k):
            for c in range(k):
                s = 0
                for bi in range(k):
                    s += grid_flat[a * k * k + bi * k + c]
                if s != ac[a][c]:
                    ok = False
                    break
            if not ok:
                break

        if ok:
            valid_tables.append((total_net, grid_flat))
        return

    for vec, net in layers_per_b[b]:
        chosen.append((vec, net))
        _combine_layers(b + 1, k, layers_per_b, ac, chosen, valid_tables)
        chosen.pop()
