def compute(payload):
    assignments = payload["assignments"]
    slots = payload["slots"]
    slot_map = {s[0]: s for s in slots}
    result = {}
    for a in assignments:
        aid, due, demand, slot_ids = a[0], a[1], a[2], a[3]
        if due is None:
            continue
        valid = []
        for sid in slot_ids:
            if sid in slot_map:
                day = slot_map[sid][1]
                if due - 7 <= day < due:
                    valid.append(sid)
        valid.sort()
        result[aid] = [demand, valid]
    return result
