def compute(payload):
    slots = payload["slots"]
    withdrawals = payload["withdrawals"]
    results = []
    for w in withdrawals:
        removed = set(w)
        remaining = {}
        for s in slots:
            sid, day, cap = s[0], s[1], s[2]
            if sid not in removed:
                remaining[sid] = [day, cap]
        results.append(remaining)
    return results
