from fractions import Fraction


def combine(payload, deadline_windows, remaining_slots_list):
    results = []
    for scenario_remaining in remaining_slots_list:
        result = _solve_scenario(deadline_windows, scenario_remaining)
        results.append(result)
    return results


def _solve_scenario(deadline_windows, remaining_slots):
    assignments_with_deadline = {}
    for aid, (demand, valid_slot_ids) in deadline_windows.items():
        filtered = [sid for sid in valid_slot_ids if sid in remaining_slots]
        if len(filtered) > 0:
            assignments_with_deadline[aid] = (demand, filtered)

    all_assignment_ids = sorted(deadline_windows.keys())

    if len(all_assignment_ids) == 0:
        return {"empty": True}

    unserved = []
    for aid in all_assignment_ids:
        if aid not in assignments_with_deadline:
            unserved.append(aid)
    if unserved:
        return {"unserved": sorted(unserved)}

    served = assignments_with_deadline
    served_ids = sorted(served.keys())
    n = len(served_ids)
    aid_index = {aid: i for i, aid in enumerate(served_ids)}

    adj_assign = [[] for _ in range(n)]
    adj_slot = {}
    all_slots_in_play = set()
    for i, aid in enumerate(served_ids):
        demand, slot_ids = served[aid]
        for sid in slot_ids:
            all_slots_in_play.add(sid)
            if sid not in adj_slot:
                adj_slot[sid] = []
            adj_slot[sid].append(i)
            adj_assign[i].append(sid)

    visited_assign = [False] * n
    components = []
    for start in range(n):
        if visited_assign[start]:
            continue
        comp_assigns = []
        comp_slots = set()
        stack = [start]
        visited_assign[start] = True
        while stack:
            ai = stack.pop()
            comp_assigns.append(ai)
            for sid in adj_assign[ai]:
                comp_slots.add(sid)
                for neighbor_ai in adj_slot[sid]:
                    if not visited_assign[neighbor_ai]:
                        visited_assign[neighbor_ai] = True
                        stack.append(neighbor_ai)
        components.append((comp_assigns, comp_slots))

    global_peak = Fraction(0)
    global_tight_sets = []

    for comp_assigns, comp_slots in components:
        slot_cap = {}
        for sid in comp_slots:
            slot_cap[sid] = remaining_slots[sid][1]

        m = len(comp_assigns)
        demands = []
        slot_lists = []
        for ai in comp_assigns:
            aid = served_ids[ai]
            d, sids = served[aid]
            demands.append(d)
            slot_lists.append(sids)

        best_ratio = Fraction(0)
        tight_masks = []

        for mask in range(1, 1 << m):
            total_demand = 0
            used_slots = set()
            for bit in range(m):
                if mask & (1 << bit):
                    total_demand += demands[bit]
                    for sid in slot_lists[bit]:
                        used_slots.add(sid)
            total_cap = sum(slot_cap[sid] for sid in used_slots)
            if total_cap == 0:
                continue
            ratio = Fraction(total_demand, total_cap)
            if ratio > best_ratio:
                best_ratio = ratio
                tight_masks = [mask]
            elif ratio == best_ratio:
                tight_masks.append(mask)

        if best_ratio > global_peak:
            global_peak = best_ratio
            global_tight_sets = []

        if best_ratio == global_peak:
            for mask in tight_masks:
                aids_in_set = []
                for bit in range(m):
                    if mask & (1 << bit):
                        aids_in_set.append(served_ids[comp_assigns[bit]])
                global_tight_sets.append(tuple(sorted(aids_in_set)))

    global_tight_sets = list(set(global_tight_sets))
    count = len(global_tight_sets)

    minimal = []
    for ts in global_tight_sets:
        is_minimal = True
        for other in global_tight_sets:
            if other != ts and set(other).issubset(set(ts)):
                is_minimal = False
                break
        if is_minimal:
            minimal.append(list(ts))

    minimal.sort(key=lambda x: (len(x), x))

    appears_in = {}
    for ts in global_tight_sets:
        for aid in ts:
            if aid not in appears_in:
                appears_in[aid] = set()
            appears_in[aid].add(ts)

    implies = []
    for aid in sorted(appears_in.keys()):
        others = set()
        for ts in appears_in[aid]:
            for other_aid in ts:
                if other_aid != aid:
                    others.add(other_aid)
        implies.append([aid, sorted(others)])

    peak_num = global_peak.numerator
    peak_den = global_peak.denominator

    return {
        "peak": [peak_num, peak_den],
        "count": count,
        "minimal": minimal,
        "implies": implies,
    }
