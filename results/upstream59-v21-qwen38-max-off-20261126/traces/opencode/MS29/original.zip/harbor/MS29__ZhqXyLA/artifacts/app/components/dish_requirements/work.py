from itertools import combinations


def compute(payload):
    dishes = payload["dishes"]
    max_diff = payload["max_difficulty"]
    eligible = [(d[0], d[1], d[3]) for d in dishes if d[2] <= max_diff]
    by_cat = {}
    for did, cat, req in eligible:
        by_cat.setdefault(cat, []).append((did, req))
    cats = sorted(by_cat.keys())
    results = []
    for c_combo in combinations(cats, 3):
        pools = [by_cat[c] for c in c_combo]
        for pick in _product(pools):
            ids = sorted([p[0] for p in pick])
            merged = {}
            for _, req in pick:
                for k, v in req.items():
                    merged[k] = merged.get(k, 0) + v
            results.append([ids, merged])
    results.sort(key=lambda x: x[0])
    return results


def _product(pools):
    if not pools:
        yield ()
        return
    for item in pools[0]:
        for rest in _product(pools[1:]):
            yield (item,) + rest
