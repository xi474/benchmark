from itertools import product as iproduct


def compute(payload):
    offers = payload["offers"]
    sorted_offers = sorted(offers, key=lambda o: o[0])
    prices = [o[2] for o in sorted_offers]
    maxes = [o[3] for o in sorted_offers]
    n = len(sorted_offers)
    ranges = [range(m + 1) for m in maxes]
    results = []
    for vec in iproduct(*ranges):
        cost = sum(vec[i] * prices[i] for i in range(n))
        packs = sum(vec)
        results.append([cost, packs, list(vec)])
    results.sort(key=lambda x: (x[0], x[1], x[2]))
    return results
