from collections import deque


def combine(payload, left, right):
    stock = payload.get("stock", {})
    offers_raw = payload.get("offers", [])
    prep_raw = payload.get("prep", [])
    sorted_offers = sorted(offers_raw, key=lambda o: o[0])
    offer_materials = [o[1] for o in sorted_offers]

    prep_steps = []
    for p in prep_raw:
        prep_steps.append({
            "id": p[0],
            "consume": p[1],
            "produce": p[2],
            "max": p[3],
        })
    prep_steps.sort(key=lambda s: s["id"])
    prep_ids = [s["id"] for s in prep_steps]

    results = []
    for combo_dishes, combo_req in left:
        plan = _solve(combo_req, stock, sorted_offers, offer_materials, prep_steps, prep_ids, right)
        results.append({"dishes": combo_dishes, "plan": plan})
    return results


def _add(inv, mat, qty):
    inv[mat] = inv.get(mat, 0) + qty


def _sub(inv, mat, qty):
    inv[mat] -= qty
    if inv[mat] == 0:
        del inv[mat]


def _can_consume(inv, consume):
    for m, q in consume.items():
        if inv.get(m, 0) < q:
            return False
    return True


def _apply_step(inv, step):
    for m, q in step["consume"].items():
        _sub(inv, m, q)
    for m, q in step["produce"].items():
        _add(inv, m, q)


def _meets(inv, req):
    for m, q in req.items():
        if inv.get(m, 0) < q:
            return False
    return True


def _leftover(inv, req):
    left = {}
    for m, q in inv.items():
        remain = q - req.get(m, 0)
        if remain > 0:
            left[m] = remain
    return left


def _inv_key(inv):
    return tuple(sorted(inv.items()))


def _solve(req, stock, sorted_offers, offer_materials, prep_steps, prep_ids, baskets):
    best = None
    for cost, packs, buy_vec in baskets:
        inv = dict(stock)
        for i, qty in enumerate(buy_vec):
            if qty > 0:
                for m, q in offer_materials[i].items():
                    _add(inv, m, q * qty)
        seq = _find_steps(inv, req, prep_steps, prep_ids)
        if seq is not None:
            plan = {
                "cost": cost,
                "buy": buy_vec,
                "steps": seq,
                "left": _leftover_after_seq(inv, seq, req, prep_steps),
            }
            return plan
    return None


def _leftover_after_seq(inv, seq, req, prep_steps):
    inv = dict(inv)
    step_map = {s["id"]: s for s in prep_steps}
    for sid in seq:
        _apply_step(inv, step_map[sid])
    return _leftover(inv, req)


def _find_steps(inv, req, prep_steps, prep_ids):
    if _meets(inv, req):
        return []
    step_map = {s["id"]: s for s in prep_steps}
    max_total = 16
    queue = deque()
    queue.append((dict(inv), [], {}, 0))
    visited = set()
    start_key = (_inv_key(inv),)
    visited.add(start_key)
    while queue:
        cur_inv, cur_seq, used_counts, depth = queue.popleft()
        if depth >= max_total:
            continue
        for sid in prep_ids:
            step = step_map[sid]
            prev_used = used_counts.get(sid, 0)
            if prev_used >= step["max"]:
                continue
            if not _can_consume(cur_inv, step["consume"]):
                continue
            new_inv = dict(cur_inv)
            _apply_step(new_inv, step)
            new_used = dict(used_counts)
            new_used[sid] = prev_used + 1
            new_seq = cur_seq + [sid]
            if _meets(new_inv, req):
                return new_seq
            state_key = (_inv_key(new_inv), tuple(sorted(new_used.items())))
            if state_key not in visited:
                visited.add(state_key)
                queue.append((new_inv, new_seq, new_used, depth + 1))
    return None
