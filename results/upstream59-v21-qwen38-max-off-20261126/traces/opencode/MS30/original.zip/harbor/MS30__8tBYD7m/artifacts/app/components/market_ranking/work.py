from fractions import Fraction


def compute(payload):
    market = payload["market"]
    top = payload["top"]
    L = max(row[1] for row in market)
    lo = L - 29
    filtered = [row for row in market if lo <= row[1] <= L]
    scored = []
    for row in filtered:
        eid, day, opn, cls = row[0], row[1], row[2], row[3]
        ratio = Fraction(abs(cls - opn), opn)
        scored.append((ratio, eid))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [eid for _, eid in scored[:top]]
