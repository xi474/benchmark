from fractions import Fraction


def compute(payload):
    grades = payload["grades"]
    student_scores = {}
    for row in grades:
        student, course, score, total = row[0], row[1], row[2], row[3]
        if course not in (16, 17):
            continue
        if score is None or total is None:
            continue
        if student not in student_scores:
            student_scores[student] = []
        student_scores[student].append(Fraction(score, total))
    result = {}
    for student, ratios in student_scores.items():
        avg = sum(ratios) / len(ratios)
        if avg < Fraction(60, 100):
            result[student] = "N"
        elif avg < Fraction(75, 100):
            result[student] = "D"
        else:
            result[student] = "P"
    return result
