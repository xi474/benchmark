from itertools import product


def combine(payload, student_tiers, market_ranking):
    rooms_info = payload["rooms"]
    prefs = payload["prefs"]
    cancel_list = payload["cancel"]

    open_events = list(market_ranking)

    results = []
    for cancelled in cancel_list:
        cancelled_set = set(cancelled)
        available = [e for e in open_events if e not in cancelled_set]
        result = solve_scenario(student_tiers, rooms_info, prefs, available)
        results.append(result)
    return results


def solve_scenario(student_tiers, rooms_info, prefs, available):
    room_caps = {}
    room_tier_order = {}
    for e in available:
        info = rooms_info[e]
        cap = info["capacity"]
        if cap <= 0:
            continue
        room_caps[e] = cap
        tier_map = {}
        for rank, group in enumerate(info["tiers"]):
            for t in group:
                tier_map[t] = rank
        room_tier_order[e] = tier_map

    students = sorted(student_tiers.keys())
    students = [s for s in students if s in prefs]

    acceptable = {}
    for s in students:
        tier = student_tiers[s]
        acc = []
        for group in prefs[s]:
            group_acc = []
            for e in group:
                if e in room_caps and tier in room_tier_order.get(e, {}):
                    group_acc.append(e)
            if group_acc:
                acc.append(group_acc)
        acceptable[s] = acc

    all_workshops = set(room_caps.keys())

    def get_student_pref_rank(s, w):
        for rank, group in enumerate(acceptable[s]):
            if w in group:
                return rank
        return None

    def get_room_tier_rank(w, s):
        tier = student_tiers[s]
        return room_tier_order[w].get(tier)

    def is_strictly_preferred_by_room(w, s1, s2):
        r1 = get_room_tier_rank(w, s1)
        r2 = get_room_tier_rank(w, s2)
        if r1 is None or r2 is None:
            return False
        return r1 < r2

    components = find_components(students, acceptable, all_workshops)

    all_stable = enumerate_all_stable_matchings(
        students, room_caps, acceptable, components,
        get_student_pref_rank, is_strictly_preferred_by_room
    )

    if not all_stable:
        return {"sizes": [[0, 1]], "forced": [], "example": [""] * len(students)}

    max_size = max(len(m) for m in all_stable)
    max_matchings = [m for m in all_stable if len(m) == max_size]

    size_counts = {}
    for m in all_stable:
        sz = len(m)
        size_counts[sz] = size_counts.get(sz, 0) + 1
    sizes = sorted([[sz, cnt] for sz, cnt in size_counts.items()])

    forced_pairs = set(max_matchings[0].items())
    for m in max_matchings[1:]:
        forced_pairs &= set(m.items())
    forced = sorted([[s, w] for s, w in forced_pairs])

    best_example = None
    for m in max_matchings:
        vec = []
        for s in students:
            vec.append(m.get(s, ""))
        if best_example is None or vec < best_example:
            best_example = vec

    return {"sizes": sizes, "forced": forced, "example": best_example}


def find_components(students, acceptable, all_workshops):
    adj_s = {s: set() for s in students}
    adj_w = {w: set() for w in all_workshops}
    for s in students:
        for group in acceptable[s]:
            for w in group:
                adj_s[s].add(w)
                adj_w[w].add(s)

    visited_s = set()
    visited_w = set()
    components = []
    for s in students:
        if s in visited_s:
            continue
        comp_s = []
        comp_w = []
        stack = [("s", s)]
        while stack:
            kind, node = stack.pop()
            if kind == "s":
                if node in visited_s:
                    continue
                visited_s.add(node)
                comp_s.append(node)
                for w in adj_s[node]:
                    if w not in visited_w:
                        stack.append(("w", w))
            else:
                if node in visited_w:
                    continue
                visited_w.add(node)
                comp_w.append(node)
                for ss in adj_w[node]:
                    if ss not in visited_s:
                        stack.append(("s", ss))
        components.append((sorted(comp_s), sorted(comp_w)))
    return components


def enumerate_all_stable_matchings(
    students, room_caps, acceptable, components,
    get_student_pref_rank, is_strictly_preferred_by_room
):
    all_matchings = []
    comp_results = []
    for comp_students, comp_workshops in components:
        comp_matchings = enumerate_component_matchings(
            comp_students, comp_workshops, room_caps, acceptable,
            get_student_pref_rank, is_strictly_preferred_by_room
        )
        comp_results.append(comp_matchings)

    if not comp_results:
        return [{}]

    for combo in product(*comp_results):
        merged = {}
        for m in combo:
            merged.update(m)
        all_matchings.append(merged)
    return all_matchings


def enumerate_component_matchings(
    comp_students, comp_workshops, room_caps, acceptable,
    get_student_pref_rank, is_strictly_preferred_by_room
):
    n = len(comp_students)
    student_idx = {s: i for i, s in enumerate(comp_students)}

    student_options = []
    for s in comp_students:
        opts = []
        for group in acceptable[s]:
            for w in group:
                if w in set(comp_workshops):
                    opts.append(w)
        opts.append(None)
        student_options.append(opts)

    local_caps = {w: room_caps.get(w, 0) for w in comp_workshops}

    stable_matchings = []

    def is_stable(assignment):
        assigned = {}
        workshop_members = {w: [] for w in comp_workshops}
        for i, s in enumerate(comp_students):
            w = assignment[i]
            if w is not None:
                assigned[s] = w
                workshop_members[w].append(s)

        for i, s in enumerate(comp_students):
            cur_w = assignment[i]
            cur_rank = None
            if cur_w is not None:
                cur_rank = get_student_pref_rank(s, cur_w)

            for group in acceptable[s]:
                for w in group:
                    if w not in set(comp_workshops):
                        continue
                    w_rank = get_student_pref_rank(s, w)
                    if w_rank is None:
                        continue
                    if cur_rank is not None and w_rank >= cur_rank:
                        continue

                    cap = local_caps[w]
                    members = workshop_members[w]
                    if len(members) < cap:
                        return False
                    can_block = False
                    for ms in members:
                        if is_strictly_preferred_by_room(w, s, ms):
                            can_block = True
                            break
                    if can_block:
                        return False
        return True

    def backtrack(idx, assignment, workshop_count):
        if idx == n:
            if is_stable(assignment):
                stable_matchings.append(dict(zip(comp_students, 
                    [w if w is not None else None for w in assignment])))
            return
        s = comp_students[idx]
        for w in student_options[idx]:
            if w is not None:
                if workshop_count.get(w, 0) >= local_caps.get(w, 0):
                    continue
                workshop_count[w] = workshop_count.get(w, 0) + 1
                assignment.append(w)
                backtrack(idx + 1, assignment, workshop_count)
                assignment.pop()
                workshop_count[w] -= 1
            else:
                assignment.append(None)
                backtrack(idx + 1, assignment, workshop_count)
                assignment.pop()

    backtrack(0, [], {})

    result = []
    for m in stable_matchings:
        clean = {s: w for s, w in m.items() if w is not None}
        result.append(clean)
    return result
