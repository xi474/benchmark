from fractions import Fraction


def _from_frac(f):
    return [f.numerator, f.denominator]


def _solve_linear(A, b, n):
    M = [[A[i][j] for j in range(n)] for i in range(n)]
    rhs = [b[i] for i in range(n)]
    for col in range(n):
        pivot = None
        for row in range(col, n):
            if M[row][col] != 0:
                pivot = row
                break
        if pivot is None:
            continue
        M[col], M[pivot] = M[pivot], M[col]
        rhs[col], rhs[pivot] = rhs[pivot], rhs[col]
        inv = Fraction(1, M[col][col])
        for j in range(n):
            M[col][j] *= inv
        rhs[col] *= inv
        for row in range(n):
            if row == col:
                continue
            factor = M[row][col]
            if factor == 0:
                continue
            for j in range(n):
                M[row][j] -= factor * M[col][j]
            rhs[row] -= factor * rhs[col]
    return rhs


def compute(payload):
    methods = payload["methods"]
    profiles = payload["profiles"]
    answers = payload["answers"]
    ans_set = set(answers)
    n_ans = len(answers)
    ans_idx = {a: i for i, a in enumerate(answers)}

    result = {}
    for m in methods:
        mid = m["id"]
        start = m["start"]
        graphs = m["graphs"]
        result[mid] = {}

        for pname in profiles:
            graph = graphs[pname]
            states = list(graph.keys())
            n_states = len(states)
            si = {s: i for i, s in enumerate(states)}

            Q = [[Fraction(0)] * n_states for _ in range(n_states)]
            QC = [[Fraction(0)] * n_states for _ in range(n_states)]
            R = [[Fraction(0)] * n_ans for _ in range(n_states)]
            RC = [[Fraction(0)] * n_ans for _ in range(n_states)]

            for s_name, edges in graph.items():
                s = si[s_name]
                total_w = sum(e[1] for e in edges)
                for target, w, cost in edges:
                    prob = Fraction(w, total_w)
                    cost_f = Fraction(cost)
                    if target in ans_set:
                        ai = ans_idx[target]
                        R[s][ai] += prob
                        RC[s][ai] += prob * cost_f
                    else:
                        t = si[target]
                        Q[s][t] += prob
                        QC[s][t] += prob * cost_f

            A = [[Fraction(int(i == j)) - Q[i][j] for j in range(n_states)] for i in range(n_states)]

            p_sol = [[Fraction(0)] * n_states for _ in range(n_ans)]
            for ai in range(n_ans):
                b = [R[s][ai] for s in range(n_states)]
                sol = _solve_linear(A, b, n_states)
                for s in range(n_states):
                    p_sol[ai][s] = sol[s]

            c_sol = [[Fraction(0)] * n_states for _ in range(n_ans)]
            for ai in range(n_ans):
                b = [Fraction(0)] * n_states
                for s in range(n_states):
                    val = RC[s][ai]
                    for t in range(n_states):
                        val += QC[s][t] * p_sol[ai][t]
                    b[s] = val
                sol = _solve_linear(A, b, n_states)
                for s in range(n_states):
                    c_sol[ai][s] = sol[s]

            start_idx = si[start]
            abs_probs = [_from_frac(p_sol[ai][start_idx]) for ai in range(n_ans)]
            cost_quals = [_from_frac(c_sol[ai][start_idx]) for ai in range(n_ans)]
            result[mid][pname] = [abs_probs, cost_quals]

    return result
