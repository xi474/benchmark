from math import gcd
from itertools import product


def _frac(n, d):
    g = gcd(n, d)
    return [n // g, d // g]


def compute(payload):
    profiles = payload["profiles"]
    methods = payload["methods"]
    answers = payload["answers"]
    n_ans = len(answers)

    total_w = sum(profiles.values())
    prior = {}
    for pname, w in profiles.items():
        prior[pname] = _frac(w, total_w)

    decision_tables = {}
    for m in methods:
        mid = m["id"]
        max_votes = m["votes"]
        table = {}

        def current_leader(counts):
            best_idx = 0
            for i in range(1, n_ans):
                if counts[i] > counts[best_idx]:
                    best_idx = i
            return best_idx

        def leader_wins(counts):
            used = sum(counts)
            remaining = max_votes - used
            if remaining < 0:
                return None
            best_idx = current_leader(counts)
            if remaining == 0:
                return best_idx
            for i in range(n_ans):
                if i == best_idx:
                    continue
                if counts[best_idx] <= counts[i] + remaining:
                    return None
            return best_idx

        queue = [tuple([0] * n_ans)]
        visited = set()
        visited.add(queue[0])
        while queue:
            state = queue.pop(0)
            result = leader_wins(state)
            key = ",".join(str(c) for c in state)
            table[key] = result
            if result is not None:
                continue
            if sum(state) >= max_votes:
                continue
            for i in range(n_ans):
                nxt = list(state)
                nxt[i] += 1
                nxt_t = tuple(nxt)
                if nxt_t not in visited:
                    visited.add(nxt_t)
                    queue.append(nxt_t)

        decision_tables[mid] = table

    return [prior, decision_tables]
