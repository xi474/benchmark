from fractions import Fraction


def _frac(n, d):
    from math import gcd
    g = gcd(n, d)
    return [n // g, d // g]


def combine(payload, left, right):
    answers = payload["answers"]
    correct = payload["correct"]
    methods = payload["methods"]
    n_ans = len(answers)
    correct_idx = answers.index(correct)

    prior_map = left[0]
    decision_tables = left[1]
    absorption = right

    results = []

    for m in methods:
        mid = m["id"]
        max_votes = m["votes"]
        table = decision_tables[mid]

        method_prob = [Fraction(0)] * n_ans
        method_unresolved = Fraction(0)
        method_launches = Fraction(0)
        method_correct_cost = Fraction(0)
        method_correct_prob = Fraction(0)

        for pname, prior_frac in prior_map.items():
            prior_val = Fraction(prior_frac[0], prior_frac[1])
            abs_data = absorption[mid][pname]
            abs_probs = [Fraction(abs_data[0][i][0], abs_data[0][i][1]) for i in range(n_ans)]
            cost_quals = [Fraction(abs_data[1][i][0], abs_data[1][i][1]) for i in range(n_ans)]
            absorb_sum = sum(abs_probs)
            unresolve_ballot = Fraction(1) - absorb_sum

            dp_prob = {}
            dp_cost = {}
            start_key = ",".join(["0"] * n_ans)
            dp_prob[start_key] = Fraction(1)
            dp_cost[start_key] = Fraction(0)

            profile_prob = [Fraction(0)] * n_ans
            profile_unresolved = Fraction(0)
            profile_launches = Fraction(0)
            profile_correct_cost = Fraction(0)
            profile_correct_prob = Fraction(0)

            processed = set()
            queue = [start_key]
            while queue:
                key = queue.pop(0)
                if key in processed:
                    continue
                processed.add(key)

                rp = dp_prob.get(key, Fraction(0))
                rc = dp_cost.get(key, Fraction(0))
                if rp == 0:
                    continue

                counts = list(map(int, key.split(",")))

                profile_launches += rp

                if unresolve_ballot > 0:
                    profile_unresolved += rp * unresolve_ballot

                for ai in range(n_ans):
                    if abs_probs[ai] == 0:
                        continue
                    new_counts = counts[:]
                    new_counts[ai] += 1
                    new_key = ",".join(str(c) for c in new_counts)

                    contrib_prob = rp * abs_probs[ai]
                    contrib_cost = rc * abs_probs[ai] + rp * cost_quals[ai]

                    winner = table.get(new_key)
                    if winner is not None:
                        profile_prob[winner] += contrib_prob
                        if winner == correct_idx:
                            profile_correct_prob += contrib_prob
                            profile_correct_cost += contrib_cost
                    elif new_key in table:
                        dp_prob[new_key] = dp_prob.get(new_key, Fraction(0)) + contrib_prob
                        dp_cost[new_key] = dp_cost.get(new_key, Fraction(0)) + contrib_cost
                        if new_key not in processed:
                            queue.append(new_key)
                    else:
                        if sum(new_counts) >= max_votes:
                            best = 0
                            for j in range(1, n_ans):
                                if new_counts[j] > new_counts[best]:
                                    best = j
                            profile_prob[best] += contrib_prob
                            if best == correct_idx:
                                profile_correct_prob += contrib_prob
                                profile_correct_cost += contrib_cost

            for ai in range(n_ans):
                method_prob[ai] += prior_val * profile_prob[ai]
            method_unresolved += prior_val * profile_unresolved
            method_launches += prior_val * profile_launches
            method_correct_cost += prior_val * profile_correct_cost
            method_correct_prob += prior_val * profile_correct_prob

        prob_out = [_frac(method_prob[ai].numerator, method_prob[ai].denominator) for ai in range(n_ans)]
        unresolved_out = _frac(method_unresolved.numerator, method_unresolved.denominator)
        launches_out = _frac(method_launches.numerator, method_launches.denominator)

        if method_correct_prob == 0:
            cic = None
        else:
            cic_frac = method_correct_cost / method_correct_prob
            cic = _frac(cic_frac.numerator, cic_frac.denominator)

        results.append({
            "id": mid,
            "prob": prob_out,
            "unresolved": unresolved_out,
            "launches": launches_out,
            "cost_if_correct": cic,
            "_correct_prob": method_prob[correct_idx]
        })

    results.sort(key=lambda x: (-x["_correct_prob"], x["id"]))
    for r in results:
        del r["_correct_prob"]

    return results
