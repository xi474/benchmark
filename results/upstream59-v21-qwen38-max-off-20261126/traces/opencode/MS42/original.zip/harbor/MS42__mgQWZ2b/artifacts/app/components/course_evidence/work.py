def compute(payload):
    courses = payload["courses"]
    result = {}
    for course_key, course_data in courses.items():
        items = course_data["items"]
        edges = course_data["edges"]

        stats = []
        ids = []
        for item in items:
            item_id, label, scores = item[0], item[1], item[2]
            non_null = [s for s in scores if s is not None]
            total = sum(non_null)
            cnt = len(non_null)
            stats.append([item_id, label, [total, cnt], cnt])
            ids.append(item_id)
        stats.sort(key=lambda x: x[0])

        adj = {item_id: set() for item_id in ids}
        for src, dst in edges:
            adj[src].add(dst)

        reach = {}
        for node in ids:
            visited = set()
            stack = list(adj[node])
            while stack:
                cur = stack.pop()
                if cur in visited:
                    continue
                visited.add(cur)
                stack.extend(adj[cur] - visited)
            reach[node] = sorted(visited)

        result[course_key] = [stats, reach]
    return result
