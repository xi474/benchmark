from itertools import permutations


def compute(payload):
    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    new_labels_set = set()
    for allowed in rubrics.values():
        new_labels_set.update(allowed)
    new_labels = sorted(new_labels_set)
    n = len(old_labels)

    allowed_map = {}
    for ol in old_labels:
        allowed_map[ol] = set(rubrics[ol])

    valid_bijections = []
    for perm in permutations(new_labels):
        mapping = dict(zip(old_labels, perm))
        if all(mapping[ol] in allowed_map[ol] for ol in old_labels):
            valid_bijections.append(mapping)

    all_mask = 0
    label_masks = {ol: {} for ol in old_labels}
    for idx, bij in enumerate(valid_bijections):
        all_mask |= (1 << idx)
        for ol in old_labels:
            nl = bij[ol]
            if nl not in label_masks[ol]:
                label_masks[ol][nl] = 0
            label_masks[ol][nl] |= (1 << idx)

    return [all_mask, label_masks]
