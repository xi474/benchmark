from itertools import product
from math import gcd
from fractions import Fraction


def combine(payload, rubric_result, course_result):
    all_mask, label_masks = rubric_result
    course_evidence = course_result

    rubrics = payload["rubrics"]
    old_labels = sorted(rubrics.keys())
    new_labels_set = set()
    for allowed in rubrics.values():
        new_labels_set.update(allowed)
    new_labels = sorted(new_labels_set)
    n_labels = len(old_labels)

    bijections = []
    for idx in range(all_mask + 1):
        if not (all_mask & (1 << idx)):
            continue
        mapping = {}
        for ol in old_labels:
            for nl in new_labels:
                if nl in label_masks[ol] and (label_masks[ol][nl] & (1 << idx)):
                    mapping[ol] = nl
                    break
        if len(mapping) == n_labels:
            bijections.append(mapping)

    courses = payload["courses"]
    prefixes = set()
    for key in courses:
        parts = key.rsplit("-", 1)
        if len(parts) == 2:
            prefixes.add(parts[0])

    valid_prefixes = []
    for pfx in sorted(prefixes):
        old_key = pfx + "-2013J"
        new_key = pfx + "-2014J"
        if old_key in courses and new_key in courses:
            valid_prefixes.append(pfx)

    prefix_data = {}
    for pfx in valid_prefixes:
        old_key = pfx + "-2013J"
        new_key = pfx + "-2014J"
        old_stats = course_evidence[old_key][0]
        old_reach = course_evidence[old_key][1]
        new_stats = course_evidence[new_key][0]
        new_reach = course_evidence[new_key][1]
        prefix_data[pfx] = (old_stats, old_reach, new_stats, new_reach)

    def get_comparable(reach_table, id_a, id_b):
        if id_b in reach_table.get(id_a, []):
            return -1
        if id_a in reach_table.get(id_b, []):
            return 1
        return 0

    def check_order_consistency(pairs, old_reach, new_reach):
        for i in range(len(pairs)):
            for j in range(i + 1, len(pairs)):
                _, old_i, new_i = pairs[i]
                _, old_j, new_j = pairs[j]
                old_cmp = get_comparable(old_reach, old_i, old_j)
                new_cmp = get_comparable(new_reach, new_i, new_j)
                if old_cmp != new_cmp:
                    return False
        return True

    best_pairs = 0
    best_support = 0
    best_alignments = []

    for bij in bijections:
        for pfx in valid_prefixes:
            old_stats, old_reach, new_stats, new_reach = prefix_data[pfx]

            compatible = []
            for os_row in old_stats:
                old_id, old_label, old_score_info, old_cnt = os_row
                if old_cnt == 0:
                    continue
                mapped_label = bij.get(old_label)
                if mapped_label is None:
                    continue
                for ns_row in new_stats:
                    new_id, new_label, new_score_info, new_cnt = ns_row
                    if new_cnt == 0:
                        continue
                    if new_label == mapped_label:
                        compatible.append((old_id, new_id, old_cnt, new_cnt))

            best_for_this = _find_best_matching(compatible, old_reach, new_reach, pfx)
            for matching in best_for_this:
                full_alignment = [(pfx, o, n) for o, n in matching]
                pair_count = len(full_alignment)
                sup = sum(min(oc, nc) for o, n, oc, nc in
                          [(o, n, next(r[2] for r in compatible if r[0] == o and r[1] == n),
                            next(r[3] for r in compatible if r[0] == o and r[1] == n))
                           for o, n in matching])

                if pair_count > best_pairs or (pair_count == best_pairs and sup > best_support):
                    best_pairs = pair_count
                    best_support = sup
                    best_alignments = [frozenset(full_alignment)]
                elif pair_count == best_pairs and sup == best_support:
                    fs = frozenset(full_alignment)
                    if fs not in best_alignments:
                        best_alignments.append(fs)

    # Handle multiple prefixes - need to combine across prefixes
    # Actually, let me redo this properly with cross-prefix combinations
    best_pairs = 0
    best_support = 0
    best_alignments = []

    for bij in bijections:
        per_prefix_matchings = {}
        for pfx in valid_prefixes:
            old_stats, old_reach, new_stats, new_reach = prefix_data[pfx]
            compatible = []
            for os_row in old_stats:
                old_id, old_label, old_score_info, old_cnt = os_row
                if old_cnt == 0:
                    continue
                mapped_label = bij.get(old_label)
                if mapped_label is None:
                    continue
                for ns_row in new_stats:
                    new_id, new_label, new_score_info, new_cnt = ns_row
                    if new_cnt == 0:
                        continue
                    if new_label == mapped_label:
                        compatible.append((old_id, new_id, old_cnt, new_cnt))

            matchings = _find_best_matching(compatible, old_reach, new_reach, pfx)
            per_prefix_matchings[pfx] = (matchings, compatible)

        if not valid_prefixes:
            alignment = frozenset()
            if 0 > best_pairs or (0 == best_pairs and 0 > best_support):
                best_pairs = 0
                best_support = 0
                best_alignments = [alignment]
            elif 0 == best_pairs and 0 == best_support:
                if alignment not in best_alignments:
                    best_alignments.append(alignment)
            continue

        combo_lists = []
        for pfx in valid_prefixes:
            matchings, compatible = per_prefix_matchings[pfx]
            pfx_combos = []
            for matching in matchings:
                sup = sum(min(oc, nc) for o, n, oc, nc in
                          [(o, n, next(r[2] for r in compatible if r[0] == o and r[1] == n),
                            next(r[3] for r in compatible if r[0] == o and r[1] == n))
                           for o, n in matching])
                pfx_combos.append((matching, len(matching), sup))
            combo_lists.append((pfx, pfx_combos))

        for combo in product(*[cl[1] for cl in combo_lists]):
            total_pairs = sum(c[1] for c in combo)
            total_support = sum(c[2] for c in combo)
            alignment_set = set()
            for idx, (pfx, _) in enumerate(combo_lists):
                for o, n in combo[idx][0]:
                    alignment_set.add((pfx, o, n))
            fs = frozenset(alignment_set)

            if total_pairs > best_pairs or (total_pairs == best_pairs and total_support > best_support):
                best_pairs = total_pairs
                best_support = total_support
                best_alignments = [fs]
            elif total_pairs == best_pairs and total_support == best_support:
                if fs not in best_alignments:
                    best_alignments.append(fs)

    ways = len(best_alignments)

    if best_pairs == 0:
        forced = []
        drift = None
    else:
        common = best_alignments[0]
        for a in best_alignments[1:]:
            common = common & a
        forced = sorted([list(t) for t in common])

        drift_values = []
        for alignment in best_alignments:
            new_sum = 0
            new_cnt = 0
            old_sum = 0
            old_cnt = 0
            for pfx, old_id, new_id in alignment:
                old_stats, _, new_stats, _ = prefix_data[pfx]
                for row in old_stats:
                    if row[0] == old_id:
                        old_sum += row[2][0]
                        old_cnt += row[3]
                        break
                for row in new_stats:
                    if row[0] == new_id:
                        new_sum += row[2][0]
                        new_cnt += row[3]
                        break
            if new_cnt > 0 and old_cnt > 0:
                diff = Fraction(new_sum, new_cnt) - Fraction(old_sum, old_cnt)
            else:
                diff = Fraction(0)
            drift_values.append(diff)

        min_drift = min(drift_values)
        max_drift = max(drift_values)
        drift = [
            [min_drift.numerator, min_drift.denominator],
            [max_drift.numerator, max_drift.denominator]
        ]

    return {
        "pairs": best_pairs,
        "support": best_support,
        "ways": ways,
        "forced": forced,
        "drift": drift
    }


def _find_best_matching(compatible, old_reach, new_reach, pfx):
    if not compatible:
        return [[]]

    n = len(compatible)
    best_size = 0
    best_support_val = 0
    best_matchings = []

    def backtrack(idx, chosen_old, chosen_new, current, cur_support):
        nonlocal best_size, best_support_val, best_matchings
        remaining = n - idx
        if len(current) + remaining < best_size:
            return

        if idx == n:
            sz = len(current)
            if sz > best_size or (sz == best_size and cur_support > best_support_val):
                best_size = sz
                best_support_val = cur_support
                best_matchings = [list(current)]
            elif sz == best_size and cur_support == best_support_val:
                best_matchings.append(list(current))
            return

        old_id, new_id, old_cnt, new_cnt = compatible[idx]
        if old_id not in chosen_old and new_id not in chosen_new:
            ok = True
            for co, cn in current:
                old_cmp = get_comparable_local(old_reach, co, old_id)
                new_cmp = get_comparable_local(new_reach, cn, new_id)
                if old_cmp != new_cmp:
                    ok = False
                    break
            if ok:
                chosen_old.add(old_id)
                chosen_new.add(new_id)
                current.append((old_id, new_id))
                backtrack(idx + 1, chosen_old, chosen_new, current,
                          cur_support + min(old_cnt, new_cnt))
                current.pop()
                chosen_old.remove(old_id)
                chosen_new.remove(new_id)

        backtrack(idx + 1, chosen_old, chosen_new, current, cur_support)

    backtrack(0, set(), set(), [], 0)
    return best_matchings


def get_comparable_local(reach_table, id_a, id_b):
    if id_b in reach_table.get(id_a, []):
        return -1
    if id_a in reach_table.get(id_b, []):
        return 1
    return 0
