"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def _mat_mul(a, b):
    ra, ca = len(a), len(a[0])
    rb, cb = len(b), len(b[0])
    result = [[0] * cb for _ in range(ra)]
    for i in range(ra):
        for j in range(cb):
            s = 0
            for k in range(ca):
                s += a[i][k] * b[k][j]
            result[i][j] = s
    return result


def _mat_add(a, b):
    r, c = len(a), len(a[0])
    return [[a[i][j] + b[i][j] for j in range(c)] for i in range(r)]


def _is_zero_block(block):
    return block["data"] is None


def _zero_block(rows, cols):
    return {"rows": rows, "cols": cols, "data": None}


def _block_multiply(A_blocks, B_blocks, layout):
    n = len(layout["row_sizes"])
    m = len(layout["col_sizes"])
    row_sizes = layout["row_sizes"]
    col_sizes = layout["col_sizes"]
    p = len(B_blocks[0])
    result = []
    for i in range(n):
        row = []
        for j in range(m):
            ri = row_sizes[i]
            cj = col_sizes[j]
            acc = None
            all_zero = True
            for k in range(p):
                a_blk = A_blocks[i][k]
                b_blk = B_blocks[k][j]
                if _is_zero_block(a_blk) or _is_zero_block(b_blk):
                    continue
                prod = _mat_mul(a_blk["data"], b_blk["data"])
                if acc is None:
                    acc = prod
                else:
                    acc = _mat_add(acc, prod)
                all_zero = False
            if all_zero or acc is None:
                row.append(_zero_block(ri, cj))
            else:
                row.append({"rows": ri, "cols": cj, "data": acc})
        result.append(row)
    return result


def transform(payload, contract):
    matrix = payload["matrix"]
    layout = payload["layout"]
    blocks = _block_multiply(matrix, matrix, layout)
    return {"layout": layout, "blocks": blocks}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
