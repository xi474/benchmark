"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module

def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    bl_contract = read(root / "engines/block_layout/contract.json")
    bl_mod = module(root / "engines/block_layout", "engine.py")
    bl_result = bl_mod.build_component(root, bl_contract)

    sq_contract = read(root / "engines/squared/contract.json")
    sq_mod = module(root / "engines/squared", "engine.py")
    sq_result = sq_mod.build_component(root, sq_contract)

    cu_contract = read(root / "engines/cubed/contract.json")
    cu_mod = module(root / "engines/cubed", "engine.py")
    cu_result = cu_mod.build_component(root, cu_contract)

    results = {
        "block_layout": bl_result,
        "squared": sq_result,
        "cubed": cu_result,
    }

    result_file_path = root / delivery["result_file"]
    result_value = read(result_file_path)

    report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value,
    }

    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == '__main__':
    main()
