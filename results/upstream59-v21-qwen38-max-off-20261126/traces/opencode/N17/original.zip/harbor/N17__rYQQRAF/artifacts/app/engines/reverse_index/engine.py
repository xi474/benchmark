"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build


def transform(payload, contract):
    dependencies = payload['dependencies']
    result = {}
    for tid, keys in dependencies.items():
        for k in keys:
            if k not in result:
                result[k] = []
            result[k].append(tid)
    for k in result:
        result[k] = sorted(result[k])
    return result


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
