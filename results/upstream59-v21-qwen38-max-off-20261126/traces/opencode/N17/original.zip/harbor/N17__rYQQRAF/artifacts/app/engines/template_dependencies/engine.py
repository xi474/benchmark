"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import re
import ast
from runtime import build


def _build_chain_parts(node):
    parts = []
    cur = node
    while True:
        if isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        elif isinstance(cur, ast.Subscript):
            sl = cur.slice
            if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
                parts.append(sl.value)
            else:
                return None
            cur = cur.value
        else:
            break
    if isinstance(cur, ast.Name) and cur.id == 'conf':
        parts.reverse()
        return parts
    return None


def _extract_conf_chains(node):
    chains = []
    if isinstance(node, (ast.Attribute, ast.Subscript)):
        parts = _build_chain_parts(node)
        if parts is not None:
            chains.append('conf.' + '.'.join(parts))
        else:
            if isinstance(node, ast.Attribute):
                chains.extend(_extract_conf_chains(node.value))
            else:
                chains.extend(_extract_conf_chains(node.value))
                chains.extend(_extract_conf_chains(node.slice))
    elif isinstance(node, ast.BinOp):
        chains.extend(_extract_conf_chains(node.left))
        chains.extend(_extract_conf_chains(node.right))
    elif isinstance(node, ast.UnaryOp):
        chains.extend(_extract_conf_chains(node.operand))
    elif isinstance(node, ast.BoolOp):
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    elif isinstance(node, ast.Compare):
        chains.extend(_extract_conf_chains(node.left))
        for c in node.comparators:
            chains.extend(_extract_conf_chains(c))
    elif isinstance(node, ast.IfExp):
        chains.extend(_extract_conf_chains(node.test))
        chains.extend(_extract_conf_chains(node.body))
        chains.extend(_extract_conf_chains(node.orelse))
    elif isinstance(node, ast.Call):
        chains.extend(_extract_conf_chains(node.func))
        for a in node.args:
            chains.extend(_extract_conf_chains(a))
        for kw in node.keywords:
            chains.extend(_extract_conf_chains(kw.value))
    elif isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        for e in node.elts:
            chains.extend(_extract_conf_chains(e))
    elif isinstance(node, ast.Dict):
        for k in node.keys:
            if k is not None:
                chains.extend(_extract_conf_chains(k))
        for v in node.values:
            chains.extend(_extract_conf_chains(v))
    return chains


def _match_longest_prefix(chain, options_set):
    if chain.startswith('conf.'):
        chain = chain[5:]
    parts = chain.split('.')
    for i in range(len(parts), 0, -1):
        candidate = '.'.join(parts[:i])
        if candidate in options_set:
            return candidate
    return None


def transform(payload, contract):
    templates = payload['templates']
    options = payload['options']
    options_set = set(options)
    result = {}
    expr_pattern = re.compile(r'\{\{(.*?)\}\}', re.DOTALL)
    for tid, text in templates.items():
        keys = set()
        for m in expr_pattern.finditer(text):
            expr_str = m.group(1).strip()
            try:
                tree = ast.parse(expr_str, mode='eval')
            except SyntaxError:
                continue
            chains = _extract_conf_chains(tree.body)
            for chain in chains:
                matched = _match_longest_prefix(chain, options_set)
                if matched:
                    keys.add(matched)
        result[tid] = sorted(keys)
    return result


def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_component(root, contract):
    return build(root, contract, transform)
