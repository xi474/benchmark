"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module


def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / 'delivery.json')

    td_contract = read(root / 'engines' / 'template_dependencies' / 'contract.json')
    td_mod = module(root / 'engines' / 'template_dependencies', 'engine.py')
    td_result = td_mod.build_component(root, td_contract)

    ri_contract = read(root / 'engines' / 'reverse_index' / 'contract.json')
    ri_mod = module(root / 'engines' / 'reverse_index', 'engine.py')
    ri_result = ri_mod.build_component(root, ri_contract)

    su_contract = read(root / 'engines' / 'stylesheet_updates' / 'contract.json')
    su_mod = module(root / 'engines' / 'stylesheet_updates', 'engine.py')
    su_result = su_mod.build_component(root, su_contract)

    result_file = delivery['result_file']
    result_value = read(root / result_file)

    report = {
        "task": delivery["task"],
        "results": {
            "template_dependencies": td_result,
            "stylesheet_updates": su_result,
            "reverse_index": ri_result
        },
        "result": result_value
    }

    out = root / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


if __name__ == '__main__':
    main()
