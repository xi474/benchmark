"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import tarfile
import io
import os
import subprocess
import tempfile
import hashlib
import shutil
import re
from runtime import build

def _do_clean(bundle_b64, scan_result):
    bundle = base64.b64decode(bundle_b64)
    td = tempfile.mkdtemp(prefix='n22-clean-')
    tf = tarfile.open(fileobj=io.BytesIO(bundle), mode='r:gz')
    tf.extractall(td, filter='data')
    repo = td

    secret = scan_result['secret']

    for d in ['logs']:
        p = os.path.join(repo, '.git', d)
        if os.path.exists(p):
            shutil.rmtree(p)

    orig_head = os.path.join(repo, '.git', 'ORIG_HEAD')
    if os.path.exists(orig_head):
        os.unlink(orig_head)

    subprocess.run(['git', 'reflog', 'expire', '--expire=now', '--all'],
                   cwd=repo, capture_output=True, text=True)
    subprocess.run(['git', 'gc', '--prune=now', '--aggressive'],
                   cwd=repo, capture_output=True, text=True)
    subprocess.run(['git', 'repack', '-a', '-d'],
                   cwd=repo, capture_output=True, text=True)

    r = subprocess.run(['git', 'fsck', '--unreachable', '--no-reflogs'],
                       cwd=repo, capture_output=True, text=True)
    for line in (r.stdout + r.stderr).splitlines():
        parts = line.strip().split()
        if len(parts) >= 3:
            ohash = parts[2]
            r2 = subprocess.run(['git', 'cat-file', '-p', ohash],
                                cwd=repo, capture_output=True, text=True)
            if secret in r2.stdout:
                obj_path = os.path.join(repo, '.git', 'objects', ohash[:2], ohash[2:])
                if os.path.exists(obj_path):
                    os.unlink(obj_path)

    files = {}
    for fname in os.listdir(repo):
        fpath = os.path.join(repo, fname)
        if os.path.isfile(fpath) and not fname.startswith('.'):
            data = open(fpath, 'rb').read()
            files[fname] = hashlib.sha256(data).hexdigest()

    r = subprocess.run(['git', 'log', '--format=%s'],
                       cwd=repo, capture_output=True, text=True)
    messages = [l for l in r.stdout.strip().splitlines() if l]

    out_buf = io.BytesIO()
    with tarfile.open(fileobj=out_buf, mode='w:gz') as tw:
        tw.add(repo, arcname='.')
    cleaned_bundle = base64.b64encode(out_buf.getvalue()).decode('ascii')

    return {
        "bundle": cleaned_bundle,
        "files": files,
        "messages": messages
    }

def transform(payload, contract):
    return _do_clean(payload['bundle'], payload['scan'])

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
