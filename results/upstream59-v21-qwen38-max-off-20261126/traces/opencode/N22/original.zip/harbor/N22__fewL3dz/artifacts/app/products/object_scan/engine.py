"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import tarfile
import io
import os
import subprocess
import tempfile
import re
from runtime import build

def _extract_and_scan(bundle_b64):
    bundle = base64.b64decode(bundle_b64)
    td = tempfile.mkdtemp(prefix='n22-scan-')
    tf = tarfile.open(fileobj=io.BytesIO(bundle), mode='r:gz')
    tf.extractall(td, filter='data')
    repo = td

    r = subprocess.run(['git', 'fsck', '--unreachable', '--no-reflogs'],
                       cwd=repo, capture_output=True, text=True)
    unreachable = []
    for line in (r.stdout + r.stderr).splitlines():
        parts = line.strip().split()
        if len(parts) >= 3 and parts[1] in ('commit', 'blob', 'tree'):
            unreachable.append((parts[1], parts[2]))

    secret = None
    for otype, ohash in unreachable:
        r2 = subprocess.run(['git', 'cat-file', '-p', ohash],
                            cwd=repo, capture_output=True, text=True)
        content = r2.stdout
        m = re.search(r'secret\[.*?\]', content)
        if m:
            secret = m.group(0)
            break
    return secret

def transform(payload, contract):
    secret = _extract_and_scan(payload['bundle'])
    return {"secret": secret}

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
