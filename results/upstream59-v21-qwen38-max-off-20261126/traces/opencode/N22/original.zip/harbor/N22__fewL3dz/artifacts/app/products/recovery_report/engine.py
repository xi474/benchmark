"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
import base64
import tarfile
import io
import os
import subprocess
import tempfile
import hashlib
import re
from runtime import build

def _do_report(scan_result, cleaned_result):
    secret = scan_result['secret']
    files = cleaned_result['files']
    messages = cleaned_result['messages']

    bundle = base64.b64decode(cleaned_result['bundle'])
    td = tempfile.mkdtemp(prefix='n22-report-')
    tf = tarfile.open(fileobj=io.BytesIO(bundle), mode='r:gz')
    tf.extractall(td, filter='data')
    repo = td

    remaining = 0
    r = subprocess.run(['git', 'rev-list', '--objects', '--all'],
                       cwd=repo, capture_output=True, text=True)
    for line in r.stdout.strip().splitlines():
        ohash = line.split()[0]
        r2 = subprocess.run(['git', 'cat-file', '-p', ohash],
                            cwd=repo, capture_output=True, text=True)
        if secret in r2.stdout:
            remaining += 1

    r = subprocess.run(['git', 'fsck', '--unreachable', '--no-reflogs'],
                       cwd=repo, capture_output=True, text=True)
    for line in (r.stdout + r.stderr).splitlines():
        parts = line.strip().split()
        if len(parts) >= 3:
            ohash = parts[2]
            r2 = subprocess.run(['git', 'cat-file', '-p', ohash],
                                cwd=repo, capture_output=True, text=True)
            if secret in r2.stdout:
                remaining += 1

    return {
        "secret": secret,
        "files": files,
        "messages": messages,
        "remaining_secret_objects": remaining
    }

def transform(payload, contract):
    return _do_report(payload['scan'], payload['cleaned'])

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
