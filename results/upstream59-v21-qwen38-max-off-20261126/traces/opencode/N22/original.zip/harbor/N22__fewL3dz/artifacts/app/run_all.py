"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, module, payload_for, emit

def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / 'delivery.json')

    object_scan_contract = read(root / 'products' / 'object_scan' / 'contract.json')
    object_scan_mod = module(root / 'products' / 'object_scan', 'engine.py')
    object_scan_result = object_scan_mod.build_component(root, object_scan_contract)

    cleaned_repo_contract = read(root / 'products' / 'cleaned_repo' / 'contract.json')
    cleaned_repo_mod = module(root / 'products' / 'cleaned_repo', 'engine.py')
    cleaned_repo_result = cleaned_repo_mod.build_component(root, cleaned_repo_contract)

    recovery_report_contract = read(root / 'products' / 'recovery_report' / 'contract.json')
    recovery_report_mod = module(root / 'products' / 'recovery_report', 'engine.py')
    recovery_report_result = recovery_report_mod.build_component(root, recovery_report_contract)

    result_file_path = root / delivery['result_file']
    result_value = read(result_file_path)

    final_report = {
        "task": "N22",
        "results": {
            "object_scan": object_scan_result,
            "cleaned_repo": cleaned_repo_result,
            "recovery_report": recovery_report_result
        },
        "result": result_value
    }

    out = root / 'outputs' / 'final_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(final_report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")

if __name__ == '__main__':
    main()
