"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    text = payload["text"]
    accounts = []
    for i in range(0, len(text), 34):
        rec = text[i:i+34]
        if len(rec) < 34:
            break
        aid = rec[0:4]
        name = rec[4:24].rstrip()
        balance = int(rec[24:34])
        accounts.append({"id": aid, "name": name, "balance": balance})
    return accounts

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
