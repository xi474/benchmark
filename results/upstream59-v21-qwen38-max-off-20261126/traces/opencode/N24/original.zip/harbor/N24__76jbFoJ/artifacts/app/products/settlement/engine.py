"""Implement the business transform. I/O helpers are supplied and editable here."""
from pathlib import Path
import json
from runtime import build

def transform(payload, contract):
    accounts = [dict(a) for a in payload["accounts"]]
    books = [dict(b) for b in payload["books"]]
    orders = payload["orders"]
    journal = payload["journal"]

    acc_map = {a["id"]: a for a in accounts}
    book_map = {b["id"]: b for b in books}

    statuses = []
    for order in orders:
        buyer_id = order["buyer"]
        seller_id = order["seller"]
        book_id = order["book"]
        amount = order["amount"]

        buyer = acc_map.get(buyer_id)
        seller = acc_map.get(seller_id)
        book = book_map.get(book_id)

        if (buyer and seller and book
                and buyer_id != seller_id
                and amount > 0
                and buyer["balance"] >= amount
                and book["owner"] == seller_id):
            buyer["balance"] -= amount
            seller["balance"] += amount
            book["owner"] = buyer_id
            journal += f"{book_id}{amount:010d}{seller_id}{buyer_id}"
            statuses.append("accepted")
        else:
            statuses.append("rejected")

    def encode_accounts(accs):
        parts = []
        for a in accs:
            parts.append(f"{a['id']}{a['name']:<20s}{a['balance']:010d}")
        return "".join(parts)

    def encode_books(bks):
        parts = []
        for b in bks:
            parts.append(f"{b['id']}{b['title']:<20s}{b['owner']}")
        return "".join(parts)

    return {
        "accounts": encode_accounts(accounts),
        "books": encode_books(books),
        "journal": journal,
        "statuses": statuses,
    }

def load_payload(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def build_component(root, contract):
    return build(root, contract, transform)
