"""Implement the project entry point using the published business contracts."""
import json
from pathlib import Path
from runtime import read, build, module

def main():
    root = Path(__file__).resolve().parent
    delivery = read(root / "delivery.json")

    component_order = ["accounts", "books", "orders", "settlement"]
    results = {}

    for comp_name in component_order:
        contract_path = root / "products" / comp_name / "contract.json"
        contract = read(contract_path)
        eng = module(root / "products" / comp_name, "engine.py")
        value = build(root, contract, eng.transform)
        results[comp_name] = value

    result_file_path = root / delivery["result_file"]
    result_value = read(result_file_path)

    report = {
        "task": delivery["task"],
        "results": results,
        "result": result_value,
    }
    out = root / delivery["report"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")

if __name__ == '__main__':
    main()
