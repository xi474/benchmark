# Workflow 可观测性报告

- Trial：`C011__ByMWhLh__env`
- Task：`C011`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（59 节点 / 58 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：59；执行边：58（observed=0，inferred=58）
- Execution Trace Graph：`observed`；temporal_next 边 58，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_q1wFCpqwvO4MQI2mVSun7368 -> tool:dsh:lead:call_00_kM9HF4mPBHKyB5Dgz2225058 -> tool:dsh:lead:call_01_zZNRMdMegntY3v7ymlLS5907 -> tool:dsh:lead:call_02_HNxEOfosNWHMnu9BCLW30737 -> tool:dsh:lead:call_03_5ud0haoz3QuKYHDV0QpY9138 -> tool:dsh:lead:call_04_vgfJyWNb0h3LBnb1ykd53048 -> tool:dsh:lead:call_05_dGTGY695wStK9xOJsnac1403 -> tool:dsh:lead:call_00_0MuWHUct9zzzULvkBvHw9068 -> tool:dsh:lead:call_01_oYiafp9UewPnFiDiaH512315 -> tool:dsh:lead:call_02_qUDhwnQJbscgeFvOErDW0804 -> tool:dsh:lead:call_03_0SesScEbGGtcVm08d77A9951 -> tool:dsh:lead:call_04_Dbwd31Mor2UkboEspuxe7954 -> tool:dsh:lead:call_00_zNygdbAPnCDAgpTdzDBu2490 -> tool:dsh:lead:call_01_IJWrLnzwRqhWxHJcq3Ls3868 -> tool:dsh:lead:call_02_1RfcIKvfMBPb18orqYZY1515 -> tool:dsh:lead:call_03_yDDAOYXYjiSnB7Da2JCK4759 -> tool:dsh:lead:call_04_d4S0xv0ws3KeiEXHtr435111 -> tool:dsh:lead:call_05_U5IRW42FfRWHpz0XI3SH6698 -> tool:dsh:lead:call_06_VR1irRP4QVl7NyKl7srC3025 -> tool:dsh:lead:call_07_HrBtHcFlbX5XmKJt9idb8255 -> tool:dsh:lead:call_00_TWD4A3OmjK8S4v1Gi0Mb0865 -> tool:dsh:lead:call_01_HLmsn4NsQAjqGKpP7vVz3555 -> tool:dsh:lead:call_02_7qCxr7jNm9bHcdXkIKlv1874 -> tool:dsh:lead:call_03_PVuN4eL3Tn9mYcFCYus60341 -> tool:dsh:lead:call_04_FGWJwueLU1OoOlSgvtJq3391 -> tool:dsh:lead:call_05_V2gnOavTDAjpnubnLCva1651 -> tool:dsh:lead:call_06_4vFlxBtrxjke4Cr4Cdid7333 -> tool:dsh:lead:call_00_BfdxqUBM8DejOBdpZIOs4505 -> tool:dsh:lead:call_00_auXikas0Zyl57QOb6IEM8565 -> tool:dsh:lead:call_00_lrftWMnVfbRc9yYPvBG87618 -> tool:dsh:lead:call_00_sGQsS4RmJM0rh8K7mlxF2365 -> tool:dsh:lead:call_00_gSpKszjKkiccsV3vA46e3363 -> tool:dsh:lead:call_00_sbIZyAj66fzAJfUS4tP76285 -> tool:dsh:lead:call_00_vgEZZC0cpONB8NyPad124163 -> tool:dsh:lead:call_00_TDwvU92SRMe6ZsPZwFmT2689 -> tool:dsh:lead:call_00_yuDSEFSakQNDG1fvfv2m3578 -> tool:dsh:lead:call_00_Nwk360ayP3ACKwTnyK3b7847 -> tool:dsh:lead:call_00_oeC4wkviIk4KkbOj36Fu3826 -> tool:dsh:lead:call_00_8nXGhwOrPQbaghf6awzO6406 -> tool:dsh:lead:call_00_zKVnxzHx0rM4B5uvXRLb6326 -> tool:dsh:lead:call_00_GToeKxd44JAg8mNpgYX92099 -> tool:dsh:lead:call_00_BBtaUlz84z9IVjNmglgW6371 -> tool:dsh:lead:call_00_ygJwMmSZhs46nmIRpncO5720 -> tool:dsh:lead:call_00_qOQlEJ6JgeAq0lkGZwIB8625 -> tool:dsh:lead:call_00_VzIhpSuBzBKHr5mJbM2S3236 -> tool:dsh:lead:call_00_MzPZRWpBPqiqQlVETCB02364 -> tool:dsh:lead:call_00_IurIpJvHHNpXxe41mVQA0033 -> tool:dsh:lead:call_00_LKErqCNSDlHWicxBo1FB9601 -> tool:dsh:lead:call_00_uaTj1M2NHQA2tZmrTgRh4192 -> tool:dsh:lead:call_00_LfSYXgu2TS34pYYqI0K25205 -> tool:dsh:lead:call_00_nnmPQIrbg3Fq3CAGQwSd6372 -> tool:dsh:lead:call_00_scp2dABeTOikxgDfWrIY6665 -> tool:dsh:lead:call_00_j8PJyuyzZZHPuPxDITz89942 -> tool:dsh:lead:call_00_cWEKn5xqYZPKSRvzg0zu2812 -> tool:dsh:lead:call_00_Ea58Zw6T9F520H5Z9bay0038 -> tool:dsh:lead:call_00_PWTnO9EVjSbQzcN915LD8255 -> tool:dsh:lead:call_00_CTrV5zwEy7kmPIVO8J4y8602 -> tool:dsh:lead:call_00_nwcVRtq4Gwj0FUtBkVQm2914
- 关键路径耗时：68.311
- Makespan：802.378
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
