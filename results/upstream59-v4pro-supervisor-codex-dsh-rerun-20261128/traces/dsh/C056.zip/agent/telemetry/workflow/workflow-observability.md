# Workflow 可观测性报告

- Trial：`C056__AxQt2Tr__env`
- Task：`C056`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（29 节点 / 28 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：29；执行边：28（observed=0，inferred=28）
- Execution Trace Graph：`observed`；temporal_next 边 28，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_yrXQqhPjzjhLVNbtqbwE3344 -> tool:dsh:lead:call_00_08aEPYrK79xKE5BMJRoK9381 -> tool:dsh:lead:call_01_l89xSQlhWZgaMIAOhyJw4855 -> tool:dsh:lead:call_02_VNexsP4io1N1AKJNlVIn0893 -> tool:dsh:lead:call_03_Qo1YSrwn0EI0DE851Zku7092 -> tool:dsh:lead:call_04_2X0N0Pd2814YwcHEEVQG3334 -> tool:dsh:lead:call_05_805596LpSCVVw4WIuJIV3053 -> tool:dsh:lead:call_06_OzbTo3K6Oe600TPspZBv5950 -> tool:dsh:lead:call_07_odmbva8jKDstmNLZJONz7323 -> tool:dsh:lead:call_08_6tQJG4m4rBH2sEdrTId40912 -> tool:dsh:lead:call_09_UDxyJ64yMIMsPSEV37Bq8537 -> tool:dsh:lead:call_10_hwcb8eddn8gxvjBxuooQ9776 -> tool:dsh:lead:call_00_lCbeb4dNxp4tcWdeVQNE7181 -> tool:dsh:lead:call_01_8oMZSviiQhjcSgwCxfnD3035 -> tool:dsh:lead:call_00_kPR9bU2blwuSFtbzfxvz3836 -> tool:dsh:lead:call_00_ARgHFz5QtaqvoNDiKIEX6674 -> tool:dsh:lead:call_01_AGSfO2ZrXEj2B4lC3i8Q3006 -> tool:dsh:lead:call_02_g8ouhy5FExoaFFWCBsLU4936 -> tool:dsh:lead:call_00_Bch6nDa2JT9MGmBPd1920651 -> tool:dsh:lead:call_01_MFtNEnrBx5vAuwXM3Bk27150 -> tool:dsh:lead:call_00_Gt58wmwbF1DT6KzZJ9mX0656 -> tool:dsh:lead:call_01_cQXHLyCB27jf3zkNt2k29842 -> tool:dsh:lead:call_00_C30c0OTLcCj4XhtmuQAn5529 -> tool:dsh:lead:call_00_lhh7oCUpwwvFFE0gJJdX4309 -> tool:dsh:lead:call_00_Fu5KMdyIzHDr0u9eAF1i3186 -> tool:dsh:lead:call_00_Za1Ru9JMJReyXHVaPwia9464 -> tool:dsh:lead:call_00_XQB4gcJNRoqJLf30TnNn9149 -> tool:dsh:lead:call_00_X2sGtXqJqcOEOKysfSNn1910
- 关键路径耗时：0.778
- Makespan：174.314
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
