# Workflow 可观测性报告

- Trial：`C062__Wf4qQS2__env`
- Task：`C062`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（41 节点 / 40 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：41；执行边：40（observed=0，inferred=40）
- Execution Trace Graph：`observed`；temporal_next 边 40，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_mWFKuuR2lRp2242ofpbI8430 -> tool:dsh:lead:call_01_fKiRdEKG6DTcJREm2lhF6903 -> tool:dsh:lead:call_00_PXYQ7RRN1RVoV9HpYzmF7866 -> tool:dsh:lead:call_01_yXQVOwuSZLuRrK4SyTqq2046 -> tool:dsh:lead:call_02_FAxC0j3uNi9iw37zooSs3008 -> tool:dsh:lead:call_03_KwPyZolqSJNQhcrOWiFF2567 -> tool:dsh:lead:call_04_QSN8htW3A8dphGE5i0Bz7169 -> tool:dsh:lead:call_05_1YmySvxdRJl3jLY4i4UH7423 -> tool:dsh:lead:call_00_GwXX2CdmXRFv3lH6pbSg9179 -> tool:dsh:lead:call_01_g21GV7IDy5HrpUuBGzhl2993 -> tool:dsh:lead:call_02_mtrsHa2J4e8alaPwgMMq2405 -> tool:dsh:lead:call_03_VQxdk8hGIvWysQOwMhOK4252 -> tool:dsh:lead:call_04_Klrj4M4tnACIkGeIEtRK5447 -> tool:dsh:lead:call_05_Pa8stozVUgXgGhg1VCxs3471 -> tool:dsh:lead:call_06_dfgpnLSHO6BPd0y7cqJp5995 -> tool:dsh:lead:call_00_NPi4nqMdHmBfazhiOc419743 -> tool:dsh:lead:call_01_OW3Vn8KkFUnnskFnyB1C3523 -> tool:dsh:lead:call_02_nPQlqZtRlp02bHdgYYhA6445 -> tool:dsh:lead:call_03_6XUSxe0iZpj03HULgnlt3728 -> tool:dsh:lead:call_04_rgAL9O9G3tYuNv2a4WA00300 -> tool:dsh:lead:call_05_lDpLY9OT4LzGNB27YbI53305 -> tool:dsh:lead:call_00_8eJaJb0GcarFrVl5gJjG1719 -> tool:dsh:lead:call_01_9yNu9dTJtAtHGoa9nHlt6050 -> tool:dsh:lead:call_02_VOMkdgW1bGqMbpzq88Ov9509 -> tool:dsh:lead:call_03_hlXAsoiEfMCKtRceqd9w9297 -> tool:dsh:lead:call_04_Yk83N1pyO4IlkBfLPI8k8837 -> tool:dsh:lead:call_05_2Kxig1u5vhPjeuqECeEg1700 -> tool:dsh:lead:call_06_6BAq9PvdKREoyp1A9xJ71496 -> tool:dsh:lead:call_07_tyMuAtaBYmz3ZDzYvMaH1128 -> tool:dsh:lead:call_00_6cDn2x4Yj7fayERWUkQB2946 -> tool:dsh:lead:call_01_sCuiWfcxpBYRTZLxniW96566 -> tool:dsh:lead:call_00_JDYvw6rs4HNhv9jKrloL1469 -> tool:dsh:lead:call_00_RekBtUV8EiShHfqpfoAf9221 -> tool:dsh:lead:call_00_awZDueid9vwQbUzXJ1rM8028 -> tool:dsh:lead:call_00_Hdo7F4QZyMQNrx2mmb8z7916 -> tool:dsh:lead:call_00_ji9rlNXoTYozR0Y7fPkC1661 -> tool:dsh:lead:call_00_ZGCu8PWGk4TaKEfSh3y50076 -> tool:dsh:lead:call_00_OTQ2SCArJH6neuJ74lWt5737 -> tool:dsh:lead:call_00_NzsahoFs5U4KujEP84Ur2333 -> tool:dsh:lead:call_00_Ze22qWmG0lRtjcAUWW697515
- 关键路径耗时：2.759
- Makespan：225.249
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
