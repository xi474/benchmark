# Workflow 可观测性报告

- Trial：`MS12__cf68enr__env`
- Task：`MS12`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（20 节点 / 19 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：20；执行边：19（observed=0，inferred=19）
- Execution Trace Graph：`observed`；temporal_next 边 19，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_guOCLMwl2WUolDi9DD7u1753 -> tool:dsh:lead:call_00_H7GQQOLLneriTMShx2Dg0991 -> tool:dsh:lead:call_00_mhUPZaKsPpO3DKUqlSxX2096 -> tool:dsh:lead:call_00_TzqiTgctc7BNT3jea8aG4788 -> tool:dsh:lead:call_00_Wn85RktYkzcenFKivaOR9900 -> tool:dsh:lead:call_00_aZiamwvKjx4iQRkUdNPQ3395 -> tool:dsh:lead:call_00_WTJNAdtNpgOwZzEkagXu9802 -> tool:dsh:lead:call_01_cJPgis7SMfSEq6VzWHqA0556 -> tool:dsh:lead:call_00_nSuAuSybWa6Cr6rimc5v6962 -> tool:dsh:lead:call_01_R12Q11VSdyRYQJgNQwKn7935 -> tool:dsh:lead:call_02_UaORKPWOyWJUvuHXA9kK3870 -> tool:dsh:lead:call_00_MAxiLgNASP9BOj2KuCmK6598 -> tool:dsh:lead:call_01_7VmDB78Pt8HPUv3NRcgR6648 -> tool:dsh:lead:call_02_32sgGbffZLtUXWf1YtjI8125 -> tool:dsh:lead:call_00_VcsZsouwVXptQVldk95D2489 -> tool:dsh:lead:call_00_qhTUmZer7cuhsav6xfNw1103 -> tool:dsh:lead:call_00_RsEbHQrLKNC3aZhGcwJk7515 -> tool:dsh:lead:call_00_s95Ss9tTL8PXfZ3kYTZ76696 -> tool:dsh:lead:call_00_586hEaZYy61fpEW3VS4G4572
- 关键路径耗时：0.819
- Makespan：315.109
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
