# Workflow 可观测性报告

- Trial：`MS23__D8AZ7oM__env`
- Task：`MS23`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（66 节点 / 65 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：66；执行边：65（observed=0，inferred=65）
- Execution Trace Graph：`observed`；temporal_next 边 65，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_flpZ2gBAnqLDJI84zA6t9633 -> tool:dsh:lead:call_01_zYoZnql4YUsQry2qJpsL0467 -> tool:dsh:lead:call_00_MY6fsyc1WdycrlNzWNdF7655 -> tool:dsh:lead:call_01_0lh67FieS2Gsj87Gx4kx7248 -> tool:dsh:lead:call_02_Fg2xhfJskcNZgbwcThAS8305 -> tool:dsh:lead:call_03_e1jEQqoCh118uGcfKndA5539 -> tool:dsh:lead:call_04_TlBxsrUiBvKf3D7kZDqw5396 -> tool:dsh:lead:call_05_g6EVWgSM1rMqD7NtO8LR6777 -> tool:dsh:lead:call_06_0RvNgimHOA4ghXXQJtD12367 -> tool:dsh:lead:call_07_F2svve3EOKAw3SmTgP7e7662 -> tool:dsh:lead:call_08_BltdiabbuZm3Nx984klB9071 -> tool:dsh:lead:call_09_bf3XHJduha0U64S3TYK36732 -> tool:dsh:lead:call_10_QkkN3KCsbAQvslc8MDCK1489 -> tool:dsh:lead:call_00_JOyRjSD6mhsRHJSWEnVM4788 -> tool:dsh:lead:call_00_tRAa37E02fSulyjrajsX7734 -> tool:dsh:lead:call_01_6gdT76LYoGreetT2wFpL4598 -> tool:dsh:lead:call_02_49r5690oWgiCWf4dtsh20838 -> tool:dsh:lead:call_03_lqh45ukHVXOEdnrUhSaz5468 -> tool:dsh:lead:call_04_B1Z729efedIXlnDF6Yx61826 -> tool:dsh:lead:call_05_ZbSNe5fT1uKGeziltm9Q1022 -> tool:dsh:lead:call_06_oaBY17OApspQyb15qB7h5172 -> tool:dsh:lead:call_07_kDg9Ixs44S6mWJzY9OD85702 -> tool:dsh:lead:call_08_VO9nYMfVEJFQItbNgYSl7099 -> tool:dsh:lead:call_09_zceHIHOv4808QIydfmVk1154 -> tool:dsh:lead:call_10_vjbLXizfrebCvU8nsJTQ7252 -> tool:dsh:lead:call_11_2D81acQLSPQvGuZyRGF16742 -> tool:dsh:lead:call_12_RpCkaKxdVZOzuHTXfHjE6903 -> tool:dsh:lead:call_00_dLLjKSvEI7voIVdGmx3t1150 -> tool:dsh:lead:call_00_uUtmnbefkn1XpJVg5be53717 -> tool:dsh:lead:call_00_zzukn1B8Dxm05zgqHavX6707 -> tool:dsh:lead:call_00_DbpuEdYRPYJ2srRGJVBq8342 -> tool:dsh:lead:call_00_OR2RgikhdGvMVS8ZeNHq0051 -> tool:dsh:lead:call_00_7IHbvtJMCrohz8g4nqfS5827 -> tool:dsh:lead:call_00_7flIe0SP7p7mIWD10Xhm1364 -> tool:dsh:lead:call_00_SIBDO1qmOwCULWmEJjpN3386 -> tool:dsh:lead:call_00_ZHlwSUIau1izyPTdkN7y8390 -> tool:dsh:lead:call_00_n3rMb2oZ8OU7MeQTajFv4869 -> tool:dsh:lead:call_00_GKHTFsAPf1WarcZM9xso1069 -> tool:dsh:lead:call_00_RqsZEkETMjvH7pSFfxhA5974 -> tool:dsh:lead:call_00_N57WiX6eiVwPM0z9W5up8028 -> tool:dsh:lead:call_00_C0IbnKYItmfEPZxeWyod4907 -> tool:dsh:lead:call_00_y8DZSGZqblYkfXuVo2Zh2656 -> tool:dsh:lead:call_00_ZaF1WwsGBP6lTFIx4Mwx3080 -> tool:dsh:lead:call_00_fMDkliMIXslgwgjSgIfo6608 -> tool:dsh:lead:call_00_HWiRHdvf5SVbjnkccvMW4995 -> tool:dsh:lead:call_00_48tAYZqtw9IWOCwYBFVr5265 -> tool:dsh:lead:call_00_BWpckOid1u9dHjsMk0Y42530 -> tool:dsh:lead:call_00_CxgNjpn899kwg50boTA66322 -> tool:dsh:lead:call_00_NrmDK4oqcoHnZDrmPImg0692 -> tool:dsh:lead:call_00_G2nkTJDYSIjhxdmVJrZB2684 -> tool:dsh:lead:call_00_zDZlC0MKI4QUtopuREVc9303 -> tool:dsh:lead:call_00_rzDxJAh3gYzxcmeaXLq61263 -> tool:dsh:lead:call_00_0FMz4RHWaq9dTlhrQ6Rp5915 -> tool:dsh:lead:call_00_kMusDVuWSvybN7WOmgXm8316 -> tool:dsh:lead:call_00_Dzzw2uUNkkEFeTgOKj6C8781 -> tool:dsh:lead:call_00_gbCBbEQrZwUbnRM7T50Y7873 -> tool:dsh:lead:call_00_JRIxdeesknf7ASCeIHkW3993 -> tool:dsh:lead:call_00_XIoWBpR0vRgp6OysXdZh1196 -> tool:dsh:lead:call_00_xC36swcE6DhKewyCSEiA3997 -> tool:dsh:lead:call_00_U0KIwV25PzANvDgawGGe9562 -> tool:dsh:lead:call_00_8r0go5cdnfAVIy3gaNp66577 -> tool:dsh:lead:call_00_gwAAENLhYrmxdrXrTY6K9277 -> tool:dsh:lead:call_00_h6AAY8uAncQRKpMd3VSK1146 -> tool:dsh:lead:call_00_f0sARGorGbVjKWqoKIzw1667 -> tool:dsh:lead:call_00_sjBqrE12988bFRBOhD258803
- 关键路径耗时：260.634
- Makespan：771.487
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
