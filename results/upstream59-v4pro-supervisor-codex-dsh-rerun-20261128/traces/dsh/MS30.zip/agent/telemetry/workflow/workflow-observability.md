# Workflow 可观测性报告

- Trial：`MS30__QrmcCZD__env`
- Task：`MS30`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（30 节点 / 29 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：30；执行边：29（observed=0，inferred=29）
- Execution Trace Graph：`observed`；temporal_next 边 29，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_X1bR23AgGXq6aHSuCkAC1714 -> tool:dsh:lead:call_01_7We6b6IVKFwuBIPGufxP3490 -> tool:dsh:lead:call_00_O0fFa6tPffeKYgRhjlea5120 -> tool:dsh:lead:call_01_2STIW2uH13IQ1M7Crt1B1836 -> tool:dsh:lead:call_02_7cC8q0N9CrwWZ2Ctysvy9575 -> tool:dsh:lead:call_03_xjfPihZq1iBDMdoR8SyA6586 -> tool:dsh:lead:call_04_ua9NMPwQWCVNzFQV246O4369 -> tool:dsh:lead:call_05_Af7qi2cRFPPZf8yDM3o91841 -> tool:dsh:lead:call_06_ywBm92A9g3tecSMeFhsL0202 -> tool:dsh:lead:call_07_yQ098o0ZIE0KVz0ieVsh3637 -> tool:dsh:lead:call_08_W9IgfWU9vmMdY1ujk57Q7999 -> tool:dsh:lead:call_09_Yn0qNB7KB6mGwxG6R5OP7176 -> tool:dsh:lead:call_00_tFxGVq0dKNYzPpjCYtsh7729 -> tool:dsh:lead:call_00_7DR3pilADGQ0aJRIec4K8600 -> tool:dsh:lead:call_01_MOUMHYknKOLvK5VKrHZk1114 -> tool:dsh:lead:call_00_0pblEgk9BqzqY7z2YEuR9125 -> tool:dsh:lead:call_01_3aans9sNNTgSMM9vh4yx7279 -> tool:dsh:lead:call_02_Yk8WNI5c6FO3kmjXKqCQ9456 -> tool:dsh:lead:call_00_XqYmcGJkp3HcegnyOlmn2695 -> tool:dsh:lead:call_01_apDvOQLoPAEkuQGB9H0Y5766 -> tool:dsh:lead:call_00_LgPpGVfIYFcENjBLpijU4109 -> tool:dsh:lead:call_00_04RFZk0myF0moofoiIwh3004 -> tool:dsh:lead:call_00_XLLYqPU55oozfw8FqORy7812 -> tool:dsh:lead:call_00_u6mpHc2OTLUfEwiH7Zi21526 -> tool:dsh:lead:call_00_VGcOiq9GllPstXyoxd626643 -> tool:dsh:lead:call_00_D1qI9ZK22v8JUQKpxylS1796 -> tool:dsh:lead:call_00_7bwZtgTFo8zpfI78N6kN8334 -> tool:dsh:lead:call_00_wBjGP8Gpg86HH4zDKOMQ7353 -> tool:dsh:lead:call_00_AyLKG8LswS8r6SrqNjCD3668
- 关键路径耗时：0.786
- Makespan：234.044
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
