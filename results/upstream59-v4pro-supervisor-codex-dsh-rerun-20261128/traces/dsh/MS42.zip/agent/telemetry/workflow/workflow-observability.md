# Workflow 可观测性报告

- Trial：`MS42__XtCd6hj__env`
- Task：`MS42`
- Harness：`deepseek-harness`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（51 节点 / 50 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：51；执行边：50（observed=0，inferred=50）
- Execution Trace Graph：`observed`；temporal_next 边 50，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:dsh:lead:call_00_hu0WUtLMCvcGlKQwclhF3058 -> tool:dsh:lead:call_01_elWtprIYRSTk5Vl8d2R92681 -> tool:dsh:lead:call_00_mY87yD9XzhtsSOMYVdwH5903 -> tool:dsh:lead:call_01_tQCl2X0TF5L0Wj2AfrEP0914 -> tool:dsh:lead:call_02_5omLDPVig73NvFuvewjo5470 -> tool:dsh:lead:call_03_7tt5FRINeNtfyBmBQKqE0689 -> tool:dsh:lead:call_04_zRsKdjxOSbU1V1z47jCP2455 -> tool:dsh:lead:call_05_b35cF46EM2MKcBAKppwJ3671 -> tool:dsh:lead:call_06_9dlYjKF6uciOk0eHg4Q07528 -> tool:dsh:lead:call_07_EeD1XVgTz9tZxf60QwvQ0290 -> tool:dsh:lead:call_08_CjcMoaJCTgOmfVQtdgG96629 -> tool:dsh:lead:call_09_VkMmxPugXA2hHebQnenH8004 -> tool:dsh:lead:call_00_8sbSJ35zhXcGh2zDYhy09736 -> tool:dsh:lead:call_00_m54PXdfaTqCp2B4rexab4484 -> tool:dsh:lead:call_00_kMnY8ZXyxozEeBYOgzq12025 -> tool:dsh:lead:call_01_V8OXs30KyU7poFSwVUHr3796 -> tool:dsh:lead:call_00_KjEOAkC5WXmPhpRQGs4C8553 -> tool:dsh:lead:call_01_lYW0VJsw8txeeWJPwzhr3026 -> tool:dsh:lead:call_00_DgC4ghrKedNvIiWpZoiw9942 -> tool:dsh:lead:call_01_jPUO2iSIr3vjbOlNQtC63641 -> tool:dsh:lead:call_00_MN1IjsBhzBhEnlLXnD531331 -> tool:dsh:lead:call_00_9iWVHf8e1ncUZ858X1Rm2365 -> tool:dsh:lead:call_00_pKrpJa8mc4gQlD5fzsNC0273 -> tool:dsh:lead:call_00_pegsTh8OjQTSB32rX4M86214 -> tool:dsh:lead:call_00_1W2NveSKK6XniM4l5R150027 -> tool:dsh:lead:call_00_ub42oFLOG4hlw9gmEJTk2103 -> tool:dsh:lead:call_00_elB1rW9CZKeT0CFS7TMK9440 -> tool:dsh:lead:call_00_8xL2EqT41mdxmOXCmlOB9924 -> tool:dsh:lead:call_00_PAllxrApMUTOGTLWO3gy6922 -> tool:dsh:lead:call_00_rZWpGwXNSt6nQmEhmMRm8109 -> tool:dsh:lead:call_00_JpuAkaMj9aLp7hmU0Wtc9455 -> tool:dsh:lead:call_00_YIlcyuvlWGwMsFzrGoIm1550 -> tool:dsh:lead:call_00_Qnt8g43TeDGvOReZFo8u9392 -> tool:dsh:lead:call_00_wTO8UoGVtgmYcjiRHuog7446 -> tool:dsh:lead:call_00_DtAy41Z9SYogxwPPAM0m0843 -> tool:dsh:lead:call_00_mHeAhQdrGoT4KkbZMWRL6485 -> tool:dsh:lead:call_00_iSkTJr1OqkCQ5IOdWrQW1190 -> tool:dsh:lead:call_00_NQaujnso4G9oBS3L21WF4497 -> tool:dsh:lead:call_00_sfpEPNVGbMW0iXDYY1ww4812 -> tool:dsh:lead:call_00_4N9XSrrf51xxBT9Y4IKq1751 -> tool:dsh:lead:call_00_NwGmJPr340Adu3ESOo9E9617 -> tool:dsh:lead:call_00_rtXMfjSm2Aedhw2tZlvf6644 -> tool:dsh:lead:call_00_9SJv3o3eRVQlsLeSjmAl3658 -> tool:dsh:lead:call_00_zGzruHtXB4G9pwKkocgt5961 -> tool:dsh:lead:call_00_gaVKrxOD4M2sYH6hITd31956 -> tool:dsh:lead:call_00_Dr23kBnQbSAQJEFEmWVr2613 -> tool:dsh:lead:call_00_GiQaspZVBbZlBAGfz3Ts3941 -> tool:dsh:lead:call_00_7xIcmfkWOXB1rL6vtuIz5161 -> tool:dsh:lead:call_00_xekWUo0a6CdUTiE0kY5c0094 -> tool:dsh:lead:call_00_EbnZZD7ipmbR2v2sHOgc4640
- 关键路径耗时：126.158
- Makespan：658.459
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
