# Workflow 可观测性报告

- Trial：`C011__ZtEGHc8__env`
- Task：`C011`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（44 节点 / 43 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：44；执行边：43（observed=0，inferred=43）
- Execution Trace Graph：`observed`；temporal_next 边 43，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_IxMt2FbxxdIOmu63nDZT1020 -> tool:nanobot-harness-v3:call_00_4sKG5mCdPMiwGDeViLqC9024 -> tool:nanobot-harness-v3:call_01_ee7F5Lux97u0oBhLTv952423 -> tool:nanobot-harness-v3:call_02_vFB5X41TO7q0hstNzhBL7690 -> tool:nanobot-harness-v3:call_03_0DPDrzD4qYOWNGBQMFmT2191 -> tool:nanobot-harness-v3:call_04_7O21CsLGtpgaqMlISnVR0278 -> tool:nanobot-harness-v3:call_05_zL1heZ6AxVAiTscBaScJ6158 -> tool:nanobot-harness-v3:call_00_QHb215XF3EYXMJSNJqtU0086 -> tool:nanobot-harness-v3:call_01_QgBJIrwjjGFHzZYt5S7d1198 -> tool:nanobot-harness-v3:call_02_afEOjxb5FSKQHmy1Q5PE1097 -> tool:nanobot-harness-v3:call_03_nc0A9Zs0YmGzjq4DBOlG9439 -> tool:nanobot-harness-v3:call_00_t3ES4WVh74K3dzMFBa9O3309 -> tool:nanobot-harness-v3:call_01_5l267FV3d4t7aTF0Fz919700 -> tool:nanobot-harness-v3:call_02_P22VZvsvOKJP9s7YjhHI8041 -> tool:nanobot-harness-v3:call_03_wqQJwls0mUTil1W4QOKt0575 -> tool:nanobot-harness-v3:call_04_DSrnylTdUQblWfptBloK8012 -> tool:nanobot-harness-v3:call_05_LScAypR3eVUtdJqCDYYN0774 -> tool:nanobot-harness-v3:call_00_M0aTAl4Tx7gL71Vtzxev2529 -> tool:nanobot-harness-v3:call_01_0gNtpq4zPiYJCrtIae8D7772 -> tool:nanobot-harness-v3:call_02_j2lRyBDl86hNpCjWg3yl5637 -> tool:nanobot-harness-v3:call_03_D5kOU727b3hNX3ub3QKz9704 -> tool:nanobot-harness-v3:call_00_QoMNia1Ibor5DNON6YJ24416 -> tool:nanobot-harness-v3:call_01_yBYbdh8GzsII6fM81qOb5473 -> tool:nanobot-harness-v3:call_00_zmNAbhzIObwt8kTlNTmV5347 -> tool:nanobot-harness-v3:call_00_JerKSACpQkaOT6xREr1E4152 -> tool:nanobot-harness-v3:call_00_4ZBmvxkMhivZiFPRDsyX6436 -> tool:nanobot-harness-v3:call_00_VDFSbCtrRQnQVxtx47Mc9700 -> tool:nanobot-harness-v3:call_00_CJBQa8fdF5w5Vh1c2EeX2735 -> tool:nanobot-harness-v3:call_00_TcrzoUQ4F3f0dULuVwqW8243 -> tool:nanobot-harness-v3:call_01_ieidkP2nE4k2I0X53Geo1050 -> tool:nanobot-harness-v3:call_02_eajPO377nlYnhZiXIsjr5626 -> tool:nanobot-harness-v3:call_00_dkrOPDOjC8v6lAV8ApET0596 -> tool:nanobot-harness-v3:call_01_RwyfF7laLsHatLRmpuy48524 -> tool:nanobot-harness-v3:call_02_PEvNtBv54VqfPGbIhDAo9672 -> tool:nanobot-harness-v3:call_03_p34ME4YgGnC87bF2xBJC0155 -> tool:nanobot-harness-v3:call_00_atZ2y2fW2Wh88qxxO60Y0054 -> tool:nanobot-harness-v3:call_01_uG3vDW7fojMoP7XlNEuN6113 -> tool:nanobot-harness-v3:call_02_PvnqL94e9HZk1bBlDZil0528 -> tool:nanobot-harness-v3:call_03_IoNMjFWQ2lY1MIBFki1m1468 -> tool:nanobot-harness-v3:call_00_yJbOxrqiLX6U8mZyNtK71087 -> tool:nanobot-harness-v3:call_00_y2N3S3MWmGGDLdFDbcAs8363 -> tool:nanobot-harness-v3:call_00_8rLR7itMXsiPp9ARoO7g4051 -> tool:nanobot-harness-v3:call_00_pY8bSZUqC46p4XtzCd9f3173
- 关键路径耗时：0.220573
- Makespan：459.44619
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
