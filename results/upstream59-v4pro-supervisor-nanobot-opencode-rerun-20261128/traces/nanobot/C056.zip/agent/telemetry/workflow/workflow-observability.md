# Workflow 可观测性报告

- Trial：`C056__6iUSnPy__env`
- Task：`C056`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（35 节点 / 34 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：35；执行边：34（observed=0，inferred=34）
- Execution Trace Graph：`observed`；temporal_next 边 34，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_BjWq9VawG8GM3EA4oGWb4411 -> tool:nanobot-harness-v3:call_00_w8hliKgDGXt7qFvyZj899155 -> tool:nanobot-harness-v3:call_01_zsWvGvKctk08fMKnJIJ12160 -> tool:nanobot-harness-v3:call_02_1UoHA4GcTTVdI887FQf29148 -> tool:nanobot-harness-v3:call_03_Up7mhhz4YBQHrXpqL0EZ1752 -> tool:nanobot-harness-v3:call_04_nDElIbtSZdDscWfSEwNb7146 -> tool:nanobot-harness-v3:call_05_bfAQcizxWBrcvBLv5Ar91064 -> tool:nanobot-harness-v3:call_06_95yA5ASgD2Kv8a4GO2vX9865 -> tool:nanobot-harness-v3:call_07_RAMdW2sHZhNAst1FY7zb0380 -> tool:nanobot-harness-v3:call_08_wWUPtcWelU68EYStuxwA9539 -> tool:nanobot-harness-v3:call_00_lIhmg8YUoFQreLiojZRf0636 -> tool:nanobot-harness-v3:call_01_sUxRsnvCTIdiM5KXs49n5041 -> tool:nanobot-harness-v3:call_02_eCIvpqB6W3nZzA6s7ja38637 -> tool:nanobot-harness-v3:call_00_aT0aulBIrTvnwrqIWEEy3768 -> tool:nanobot-harness-v3:call_01_It1cqwq7fAkCRhORYXsN0317 -> tool:nanobot-harness-v3:call_02_7GVH91aA2plgDMGD1ZhF2650 -> tool:nanobot-harness-v3:call_03_a4K0gmoyZEnqqpNoBI7O6241 -> tool:nanobot-harness-v3:call_04_yIOwKRn0XBMyhTyfkbt10499 -> tool:nanobot-harness-v3:call_05_JCHuSXwet3FfmeU5zihk0152 -> tool:nanobot-harness-v3:call_06_upbmkL2c6DWeEKCmQro88250 -> tool:nanobot-harness-v3:call_07_vUdy8dqYCqCQF4Q4hCmJ0299 -> tool:nanobot-harness-v3:call_08_xBdTxDN9QjA6BJX2VUZR9166 -> tool:nanobot-harness-v3:call_09_3dNAQvB6x7cgCEEJSbdp8756 -> tool:nanobot-harness-v3:call_10_SDCGaybyF7LK6sc6eGep1330 -> tool:nanobot-harness-v3:call_11_1riMphz1sApyXbbsu9Wu3534 -> tool:nanobot-harness-v3:call_00_X9p6F1zJSJSQxpcSxoSP2137 -> tool:nanobot-harness-v3:call_01_viJS733jRoImKa9aVU7z0105 -> tool:nanobot-harness-v3:call_00_XHHlhhVwdMNS7kxtqXwa5982 -> tool:nanobot-harness-v3:call_00_SlDgiTuIMLpix5WF8D4E0806 -> tool:nanobot-harness-v3:call_00_QzEMDbOYtXXzEYWmyCqu5332 -> tool:nanobot-harness-v3:call_00_S0O8K27xeckKsWLSf59M5266 -> tool:nanobot-harness-v3:call_00_3JxzXrly8jVdyzX3EgMK0215 -> tool:nanobot-harness-v3:call_00_rzQIC0dhLJPke22X0lhe0507 -> tool:nanobot-harness-v3:call_00_BlvQUshLVfWagTCjETQe1694
- 关键路径耗时：0.709929
- Makespan：106.244941
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
