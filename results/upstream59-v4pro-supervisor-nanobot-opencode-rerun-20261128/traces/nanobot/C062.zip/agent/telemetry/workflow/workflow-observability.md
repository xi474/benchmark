# Workflow 可观测性报告

- Trial：`C062__ZZo8qT5__env`
- Task：`C062`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（38 节点 / 37 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：38；执行边：37（observed=0，inferred=37）
- Execution Trace Graph：`observed`；temporal_next 边 37，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_J2chFj3oaiLmbtRG7WI43471 -> tool:nanobot-harness-v3:call_00_NOC7pCzNnuvcXS5uohpB6968 -> tool:nanobot-harness-v3:call_01_QPKo3gylHfOXg2uhuVRw1673 -> tool:nanobot-harness-v3:call_02_npw2mbTpvz35Z9iag4vs2139 -> tool:nanobot-harness-v3:call_03_4UlNtlrFB9GtlkyDQyY63673 -> tool:nanobot-harness-v3:call_00_df93IsHwKgm2FJbGvaO67329 -> tool:nanobot-harness-v3:call_01_Pc7sK4tc9ks1ZxNNbTA85529 -> tool:nanobot-harness-v3:call_02_NAls6H7HtWRC3UFbcXJL2767 -> tool:nanobot-harness-v3:call_03_SQAm8nq8EA1mnBQZHDdX9649 -> tool:nanobot-harness-v3:call_04_jmstRplLEB8Eh09u9I096509 -> tool:nanobot-harness-v3:call_00_ZkNqfyirRLIm0xIXBM1l6350 -> tool:nanobot-harness-v3:call_01_IlvZT6m9AbbyvKkGbhyj9176 -> tool:nanobot-harness-v3:call_02_z2wNEABNJAfW5KyMoYnF1166 -> tool:nanobot-harness-v3:call_00_2wFHaTiCT3pYR2bqcMOE9632 -> tool:nanobot-harness-v3:call_01_ovY6NOBsZ1hEVF9f2iK99895 -> tool:nanobot-harness-v3:call_02_fsyQatzbDoAXDOPysMkw1931 -> tool:nanobot-harness-v3:call_03_F05514KYMas23vNJrKSX2129 -> tool:nanobot-harness-v3:call_04_fkzucciSVgU86RaEF60f2493 -> tool:nanobot-harness-v3:call_05_aLxtx6MyPIl5SBc4gQTv3435 -> tool:nanobot-harness-v3:call_00_sbgY2vYleZUPCMbajseV3838 -> tool:nanobot-harness-v3:call_01_JfMNayEULq1JN4uFEMAk4069 -> tool:nanobot-harness-v3:call_02_jYoRX9vD6SZBUuqsIMnz7968 -> tool:nanobot-harness-v3:call_03_L5lTxSvhUGhOo6oQY2HR2113 -> tool:nanobot-harness-v3:call_04_0jocsk2gzLPFLZyfgP4p5198 -> tool:nanobot-harness-v3:call_05_zjpY1deEjzpJhCl7ctBc1578 -> tool:nanobot-harness-v3:call_00_h5CKRtCAiEc1FQkbi6Qo7023 -> tool:nanobot-harness-v3:call_01_9CpYJpRBRqtaLMHeQ0Nr0758 -> tool:nanobot-harness-v3:call_00_VC6cwniZZvvDCOd28oyc5902 -> tool:nanobot-harness-v3:call_00_Qv3ksD0rsoGC6BmGPQQO0389 -> tool:nanobot-harness-v3:call_00_i7Jt7Q7r9oUKJZ14LJEb5472 -> tool:nanobot-harness-v3:call_00_t8Cfz75AnTpByvg8zf5a6360 -> tool:nanobot-harness-v3:call_00_Fj03GofX8IYzU4HLMYfs5565 -> tool:nanobot-harness-v3:call_00_6LCQAYIz4M4czZcJ6Kv94775 -> tool:nanobot-harness-v3:call_00_SOlKbtWLNVRen4AjjLq80253 -> tool:nanobot-harness-v3:call_00_0s42dceCoRP6ShczYT9T7850 -> tool:nanobot-harness-v3:call_00_Dl4aU9B2N8TObZXFPTiw3830 -> tool:nanobot-harness-v3:call_00_AhJBK9PyiXBJ8t1sSLmd1944
- 关键路径耗时：0.609399
- Makespan：243.065561
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
