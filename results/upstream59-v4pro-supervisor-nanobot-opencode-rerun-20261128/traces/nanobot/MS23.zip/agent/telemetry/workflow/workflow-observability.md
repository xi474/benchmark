# Workflow 可观测性报告

- Trial：`MS23__sQ7EzCG__env`
- Task：`MS23`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（48 节点 / 47 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：48；执行边：47（observed=0，inferred=47）
- Execution Trace Graph：`observed`；temporal_next 边 47，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_YnLJimgA9HoUwvbTX4KK8971 -> tool:nanobot-harness-v3:call_00_5IgKKvrIZoK9fljM9XsX3093 -> tool:nanobot-harness-v3:call_01_4TnpyKFQy0QZGhjVjamd5813 -> tool:nanobot-harness-v3:call_02_SQWKayiZeFw7bJ1v70a03317 -> tool:nanobot-harness-v3:call_03_FDLgZEmnL1s44UITmfeg0917 -> tool:nanobot-harness-v3:call_04_qyqg0nVJUNe4oZQBqF5o1960 -> tool:nanobot-harness-v3:call_05_4mgumfHBzNX3TAjqgxFD8408 -> tool:nanobot-harness-v3:call_00_UeocCPVgbpGClEFn281F2973 -> tool:nanobot-harness-v3:call_01_VL8Heo4MVYFoVWrKpvoj6152 -> tool:nanobot-harness-v3:call_02_FEajDKUXElFIKg5HSXbN0589 -> tool:nanobot-harness-v3:call_03_D6SQf63gooCwUy5wmsJT6895 -> tool:nanobot-harness-v3:call_04_8urxSyUNCTCuaQRrnCc07023 -> tool:nanobot-harness-v3:call_00_EZsWmMrHKjXpSBp0b2DB2834 -> tool:nanobot-harness-v3:call_00_AQSWGipThz5wWm7Ph2wN3547 -> tool:nanobot-harness-v3:call_01_Ix7kenw1ee91tnidjwbZ2562 -> tool:nanobot-harness-v3:call_02_qB9qELhES3bO0tG3GIMn4174 -> tool:nanobot-harness-v3:call_03_wpwnr60qwZgnLLaFDOdj3318 -> tool:nanobot-harness-v3:call_04_sppYklIXluv9Drqe4b6l0815 -> tool:nanobot-harness-v3:call_05_TVYVKxnr0nCdmcTivhDy6695 -> tool:nanobot-harness-v3:call_06_o2C0fz5F9cJlYra0rhCZ9298 -> tool:nanobot-harness-v3:call_07_6IMD7heaGPaQCeA1UhE69235 -> tool:nanobot-harness-v3:call_00_DAWouV4h0kOX2UeUNRex0668 -> tool:nanobot-harness-v3:call_01_Ks2OBZoAOCWJSHlleFh84633 -> tool:nanobot-harness-v3:call_02_XoDt3m5Iv0FEPXqMsPgC1599 -> tool:nanobot-harness-v3:call_03_eQgQrLOM7FLCNV1YjkKh9613 -> tool:nanobot-harness-v3:call_04_3PonukKU1c2LpfZN7l870406 -> tool:nanobot-harness-v3:call_05_StU5EdCxbkuNiNKB1TA60494 -> tool:nanobot-harness-v3:call_00_uIJ2jZglFuJRGL0eLwKs2898 -> tool:nanobot-harness-v3:call_01_NDvg5xI1IWqyRHXqltsg4899 -> tool:nanobot-harness-v3:call_00_TkHDyi9Ji9W1v2vXD6PA3702 -> tool:nanobot-harness-v3:call_00_Yg2ZceLijq0ZrWiECSnW4051 -> tool:nanobot-harness-v3:call_00_CNMSDtIWG9vaOD56lxMV3889 -> tool:nanobot-harness-v3:call_00_qIB6SU7fXpz3LR0aN3Iv3774 -> tool:nanobot-harness-v3:call_00_futFpA6lxmO2MsT5zyHB3525 -> tool:nanobot-harness-v3:call_00_yrdB4QFBAIeMUE4gdAVO5661 -> tool:nanobot-harness-v3:call_00_t8g3uvYe0V9q4tmnFeue5473 -> tool:nanobot-harness-v3:call_00_B22MpZw7Di7kQpUWMbqo4338 -> tool:nanobot-harness-v3:call_00_XSMbra2Cpp0aF8eBiGGc5544 -> tool:nanobot-harness-v3:call_00_pwQWmGcIFTHHjfUg3DfO6103 -> tool:nanobot-harness-v3:call_00_gPfaAqtphQTOwuSc1rIG6296 -> tool:nanobot-harness-v3:call_00_l58pA9vcgEIy9GLgWvUV5855 -> tool:nanobot-harness-v3:call_00_MaezIzv3kcxfWNZIgRBI0496 -> tool:nanobot-harness-v3:call_00_09ASJLAkPsEPvtSapBJY1873 -> tool:nanobot-harness-v3:call_00_pTnljalcRSwFfRd7Vom06507 -> tool:nanobot-harness-v3:call_00_ZvT4bP7u8E0APICPL6gI1907 -> tool:nanobot-harness-v3:call_00_YbA6n4WPdNJhgVU8yY4T8493 -> tool:nanobot-harness-v3:call_00_XWzZQMJz6MYo0LksEqLm5743
- 关键路径耗时：121.315679
- Makespan：507.387809
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
