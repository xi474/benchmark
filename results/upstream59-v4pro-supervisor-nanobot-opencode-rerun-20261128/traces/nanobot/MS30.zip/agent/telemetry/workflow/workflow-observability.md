# Workflow 可观测性报告

- Trial：`MS30__9Tj4Tcw__env`
- Task：`MS30`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（32 节点 / 31 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：32；执行边：31（observed=0，inferred=31）
- Execution Trace Graph：`observed`；temporal_next 边 31，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_hDEgB4Uxi8svpt30t94B3083 -> tool:nanobot-harness-v3:call_00_c6I41NsQ6aclsZPbnLxy1486 -> tool:nanobot-harness-v3:call_01_OmyhCChvtuctdHMjgGQI5181 -> tool:nanobot-harness-v3:call_02_mC6SIcEuHOfTr9LagTu59334 -> tool:nanobot-harness-v3:call_03_Nrn4wnATdQRCwNzjOImn9052 -> tool:nanobot-harness-v3:call_04_USoM0Ut7OgvF5eZzHwqJ1886 -> tool:nanobot-harness-v3:call_05_PcWX94bBSKlKXteCtOck2736 -> tool:nanobot-harness-v3:call_06_uZmkjAaCsajHCQ8xY3jG2421 -> tool:nanobot-harness-v3:call_07_M4YFEo2oZajHB1wS533u3464 -> tool:nanobot-harness-v3:call_08_wPu2nH2JgrExyPztyUvP1703 -> tool:nanobot-harness-v3:call_00_HkZkdWKg9MqU6q2rNkpQ5751 -> tool:nanobot-harness-v3:call_01_MWdroy4mfQK3iZA8ayoP5203 -> tool:nanobot-harness-v3:call_02_B6FighPdpQVFKE3vtUTT4636 -> tool:nanobot-harness-v3:call_00_7fYkFdulsqh9bC7yYk4N6905 -> tool:nanobot-harness-v3:call_01_N6eJUvhDYMD1nmZhpsjx3942 -> tool:nanobot-harness-v3:call_02_PuCp7W98g3c7l1RMCvu96518 -> tool:nanobot-harness-v3:call_03_LpKFNoHCtCRQjDEWpjOo4704 -> tool:nanobot-harness-v3:call_04_Z0AxHhzWAyFtBSH7HntH1126 -> tool:nanobot-harness-v3:call_05_cUIDCFxT4tfeJBiCnX843540 -> tool:nanobot-harness-v3:call_06_Uqo1PJEDEFEVuxovX15f8025 -> tool:nanobot-harness-v3:call_07_JsXXFw4jUSbEqoRtAKm63601 -> tool:nanobot-harness-v3:call_08_mDv4LJjL65qKD1PRYoPI3968 -> tool:nanobot-harness-v3:call_09_PUBfGwy9OcL6nHwAThGn7102 -> tool:nanobot-harness-v3:call_10_OqpE2a7XxOPdmjzPa7UE4814 -> tool:nanobot-harness-v3:call_11_ORnjsCuQmXZqS1DV0ERP6276 -> tool:nanobot-harness-v3:call_00_fOqQ2vYSQINskRtp7Kir9756 -> tool:nanobot-harness-v3:call_01_ysjmU3JFPQHZQEEEAPGE5367 -> tool:nanobot-harness-v3:call_02_B2xuusqHrqjvNTCmEtsx1075 -> tool:nanobot-harness-v3:call_00_CjYY4K45ABpu1q5VmihN1248 -> tool:nanobot-harness-v3:call_01_2PWfc62y1b16jnR3p8nv1012 -> tool:nanobot-harness-v3:call_00_NlZR7U4xdXgHHzZQVHSX1233
- 关键路径耗时：0.018253
- Makespan：289.164886
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
