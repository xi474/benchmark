# Workflow 可观测性报告

- Trial：`MS42__oHaVtPZ__env`
- Task：`MS42`
- Harness：`nanobot`
- 规划等级：`P0`
- 规划来源：`not-observed`
- 是否观察到模型显式计划：否

## 1. 六类图状态

- Provided DAG：未观察到（`No Provided DAG was supplied for this trial.`）
- Harness Control DAG：未观察到（`No Harness Control DAG was declared.`）
- Observed Model Plan DAG：未观察到（`No explicit model-created plan event was emitted.`）
- Execution DAG：已观察到（42 节点 / 41 边）
- Agent Topology：已观察到（1 Agent / 0 子 Agent）
- Data Dependency DAG：未观察到（0 artifact / 0 message）

## 2. 规划证据

- planning_level：`P0`
- plan_source：`not-observed`
- 证据事件：无
- Plan 快照数：0
- Plan revision 数：0
- 未观察到模型计划的原因：Only root-Agent/model/tool execution events were observed; no local control decision or plan exists.

> 静态 LangGraph / Strands Graph 属于 Harness Control DAG，不是模型自主 Plan DAG。
> 工具调用顺序和 Execution DAG 不能反推模型计划。

## 3. 执行与并行

- 执行节点：42；执行边：41（observed=0，inferred=41）
- Execution Trace Graph：`observed`；temporal_next 边 41，均为 inferred/low confidence，不是任务依赖。
- Execution Dependency DAG：`not_observed`；observed dependency 边 0，inferred dependency 边 0。
- 关键路径：tool:nanobot-harness-v3:call_00_pNPkAERRsHpdSbd3N88I6097 -> tool:nanobot-harness-v3:call_00_DpJFARyyMXL8AeqGSM596181 -> tool:nanobot-harness-v3:call_01_2h7q6tT0Y86M0Ieky6ln6175 -> tool:nanobot-harness-v3:call_02_yXnox1Tm9vBkELFRmtSy5947 -> tool:nanobot-harness-v3:call_03_ghwhulqKkjVeydS9gCSl7014 -> tool:nanobot-harness-v3:call_04_B872Ae2IbfykdKHCsVJi7810 -> tool:nanobot-harness-v3:call_05_WZKJXANrKOPotw6wT4tC0445 -> tool:nanobot-harness-v3:call_06_ReTbKre5jpCG7zaJBnPB9890 -> tool:nanobot-harness-v3:call_07_np4ACqlWJdWDFjx7ipoR5485 -> tool:nanobot-harness-v3:call_08_G5LbXyvRJBFhFyuVKjzy3229 -> tool:nanobot-harness-v3:call_00_i4UIDGczE77t6DRMwe321515 -> tool:nanobot-harness-v3:call_01_xguw2uJSk00VM6qUzXVh0051 -> tool:nanobot-harness-v3:call_02_3NylDTrAiiluXJyXg2nM2595 -> tool:nanobot-harness-v3:call_00_Eb38YxOpxf8dE0rF2IC86675 -> tool:nanobot-harness-v3:call_01_loBaMTODS8TL765RIDP55929 -> tool:nanobot-harness-v3:call_02_ch9FhQJVhLj2Yek705mA9311 -> tool:nanobot-harness-v3:call_03_9LLcoarFymMzOM5rqmbD5252 -> tool:nanobot-harness-v3:call_04_ddiFQvrLJutcMsrWaF561706 -> tool:nanobot-harness-v3:call_05_ugJW9EC9gpiLLTLKlRey6762 -> tool:nanobot-harness-v3:call_06_lOREtVYmFIiriUZVOwyG3218 -> tool:nanobot-harness-v3:call_07_UF2nxRpoQI89kisiRNrV4730 -> tool:nanobot-harness-v3:call_08_hM4wRRZU3TTaXOGSQ17R6932 -> tool:nanobot-harness-v3:call_09_ACg2tOEc28yWvt4fjWH02732 -> tool:nanobot-harness-v3:call_10_JxiYGlXQuJshnstWJG8R9060 -> tool:nanobot-harness-v3:call_11_UzDg1zQfDsmyUbQZ3BGB9263 -> tool:nanobot-harness-v3:call_00_3Wti26R0h9HnAFZWFeOR8166 -> tool:nanobot-harness-v3:call_01_knJ1i5dAhUdqNmWFYKNB9469 -> tool:nanobot-harness-v3:call_00_xtcImUd32D8Qc03yl2NV7505 -> tool:nanobot-harness-v3:call_00_AdQR6O2szPAFW1aecHnD1154 -> tool:nanobot-harness-v3:call_00_lUcm6IiqjMQqvFWxY4Kb2785 -> tool:nanobot-harness-v3:call_00_GwDRbWisNiU2aOGULEFT7702 -> tool:nanobot-harness-v3:call_00_QeLC8d5WQwG4s8D4b6fl4383 -> tool:nanobot-harness-v3:call_00_NhSD1EbYrk7jOMzrLH0x0770 -> tool:nanobot-harness-v3:call_00_AZy3NwDyqEeawgl8swiZ7776 -> tool:nanobot-harness-v3:call_00_56URoZsw2rsGfCyyEv273763 -> tool:nanobot-harness-v3:call_00_hBLGpmxpz7YiaahQJmJW5723 -> tool:nanobot-harness-v3:call_00_MC2qYM4JItjXFIBCfzdN8461 -> tool:nanobot-harness-v3:call_00_POJAnOGWBcFKusfnJqYW4941 -> tool:nanobot-harness-v3:call_00_jpXF8ISbt3krvUrbFywM1589 -> tool:nanobot-harness-v3:call_00_R6lZKTNTY6dAiQzLttU07475 -> tool:nanobot-harness-v3:call_00_Y7s51LUvi9FiGudp7ReD6897
- 关键路径耗时：0.385999
- Makespan：290.89586
- 子 Agent 并行宽度：0
- 委派：0；handoff：0

## 4. 分支、重试、取消、汇合

- 跳过节点：无
- 重试节点：无
- 取消节点：无
- 剪枝分支：无
- 汇合等待：None

## 5. Workflow 一致性

| 对比 | 状态 | 计划节点 | 执行节点 | 计划未执行 | 执行未计划 | 节点重合比 | 边重合比 |
|---|---|---:|---:|---|---|---:|---:|
| Provided vs Execution | not_observed | - | - | - | - | - | - |
| Harness Control vs Execution | not_observed | - | - | - | - | - | - |
| Observed Model Plan vs Execution | not_observed | - | - | - | - | - | - |

## 6. 结论边界

- **observed**：事件或图中直接存在，且带 evidence_event_ids。
- **inferred**：没有直接依赖证据时按时间顺序补的边，confidence=0.3，不能当真实依赖。
- **not_observed**：没有数据/能力；不能填 0。
- 本报告不把静态 Graph 写成模型计划，也不从工具调用顺序推断模型规划。
